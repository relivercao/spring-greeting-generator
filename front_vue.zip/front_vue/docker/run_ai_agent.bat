@echo off
:: Set UTF-8 encoding
chcp 65001 >nul 2>&1

echo =============================================
echo AI Agent Startup Script
echo =============================================

:: Check if Docker is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Docker is not running. Please start Docker Desktop first.
    pause
    exit /b 1
)

:: Start containers
echo Starting containers...
docker run -d -p 8000:8000 --name fw-agent-backend fw-agent-backend:latest
docker run -d -p 80:80 --name fw-agent-frontend fw-agent-frontend:latest

:: Display result
echo =============================================
echo Operation completed!
echo Frontend URL: http://localhost
echo Backend API URL: http://localhost:8000
echo =============================================

:: Check container status
echo Container status:
docker ps | find "fw-agent"

pause