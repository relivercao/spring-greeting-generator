# CLAUDE.md — Macode FW AI Agent Frontend (Vue)

Development standards for the `front_vue/` frontend. Claude Code must strictly follow all rules.

> Global standards: project root `CLAUDE.md`; backend standards: `backend/CLAUDE.md`.

**Frontend directory**: `E:\work_mt\01_Agent\Macode_claude\front_vue`

---

## Language Policy (MANDATORY)

**All code in the frontend MUST be entirely in English.** This includes:
- Source code (variables, functions, component names)
- Comments (inline, block, JSDoc)
- Commit messages (Conventional Commits, English only)
- UI text (labels, placeholders, tooltips, error messages)
- Console/log output
- CSS class names and comments
- Test descriptions and assertion messages

**Forbidden**: Chinese or any non-English text anywhere in the codebase.

---

## Project Overview

**Vue 3 + Vite SPA** — frontend for the AI firmware development assistance platform. Communicates with the FastAPI backend (`http://127.0.0.1:8000`) via Vite proxy at `/api`.

| Technology | Version | Notes |
|------------|---------|-------|
| Vue 3 | ^3.4 | Composition API + `<script setup>` |
| Vue Router | ^4.6 | SPA routing, meta.agentId controls Agent |
| Pinia | ^3.0 | State management with localStorage persistence |
| Element Plus | ^2.7 | UI component library, auto-imported on demand |
| Vite | ^5.0 | Build tool, dev server on `:5173` |

---

## Development Commands

```bash
npm run dev        # Start dev server (http://localhost:5173)
npm run build      # Production build (dist/)
npm run preview    # Preview build output
npm run lint       # ESLint check + auto-fix
npm run format     # Prettier formatting
```

---

## Directory Structure

```
src/
├── main.js                  # App entry (registers Pinia / Router / Element Plus icons)
├── App.vue                  # Root component (RouterView + global styles)
├── router/index.js          # Route config (guards: token/guest validation)
├── stores/
│   ├── auth.js              # Auth state (token / user / guest, localStorage persistence)
│   ├── chat.js              # Chat history (up to 100 sessions × 200 messages, localStorage)
│   └── workspace.js         # Workspace state (isolated by agentId, localStorage persistence)
├── api/
│   ├── http.js              # Unified HTTP wrapper (auto-attaches token, global 401 handling)
│   ├── auth.js              # Auth + send message API
│   └── unittest.js          # Unittest generation API (multipart + SSE EventSource)
├── views/
│   ├── Home.vue             # Main layout (Sidebar + Header + content area routing)
│   └── Login.vue            # Login/Register (with guest mode, left brand animation)
└── components/
    ├── Sidebar.vue          # Sidebar (72px icon bar + 228px history panel)
    ├── Header.vue           # Top nav (Agent name + user menu)
    ├── ChatWindow.vue       # Chat window (Markdown rendering + typewriter effect)
    ├── AgentWorkspace.vue   # Generic workspace (file upload + Pipeline + result display)
    ├── UnittestWorkspace.vue# Unittest-specific workspace (SSE real-time progress, 1000+ lines)
    ├── RagWorkspace.vue     # RAG-specific workspace (doc upload + chat panel)
    ├── WelcomePage.vue      # Welcome page (Agent grid + Quick Prompts)
    ├── SettingsPanel.vue    # Settings panel (model config, Router management)
    └── shared/              # Shared components (MarkdownRenderer, FileUploader, etc.)
```

---

## Core Conventions

### State Management

- All cross-component state lives in Pinia stores
- Components must not use `localStorage` directly — go through stores
- Workspace state is isolated by `agentId`; switching agents does not bleed state

### HTTP Requests

- All requests must go through `api/http.js` — do not import `axios`/`fetch` directly in components
- SSE long-polling uses `apiWaitForTask` pattern from `api/unittest.js`
- Never hardcode `/api` prefix in components — it is handled by the http wrapper

### Component Design

- Use `<script setup>` + Composition API; do not mix Options API
- Declare all `props` and `emits` explicitly
- Components over 400 lines should be split; workspace-class components may reference `UnittestWorkspace.vue` structure
- Do not introduce new UI libraries — use Element Plus only

### Routing

- Each Agent maps to a route with `meta.agentId`
- Route guards in `router/index.js` handle token and guest validation
- Adding a new Agent requires updating three places: `router/index.js`, the `agents` array in `Home.vue`, and `agentBackendMap`

---

## Naming Conventions

| Type | Convention | Example |
|------|------------|---------|
| Component file | `PascalCase` | `ChatWindow.vue` |
| Store file | `camelCase` | `auth.js` |
| API file | `camelCase` | `unittest.js` |
| CSS class | `kebab-case` | `.chat-window` |
| Event name (emit) | `kebab-case` | `@select-agent` |
| Props | `camelCase` | `activeAgent` |

---

## Development Workflow

**Before starting a new feature:**
- Confirm the corresponding backend API endpoint exists (see `FastAPI Interface Design Doc - Optimized.html`)
- New Agent types require syncing updates to `router/index.js`, the `agents` array in `Home.vue`, and `agentBackendMap`

**While coding:**
- Reuse the existing `http.js` wrapper — do not introduce new HTTP libraries
- Split components over 400 lines; workspace-class components may reference `UnittestWorkspace.vue` structure
- SSE task polling is handled uniformly via the `apiWaitForTask` pattern in `api/unittest.js`

**Pre-commit checklist:**
- [ ] No hardcoded tokens / API Keys
- [ ] New Agent has updated all three mappings (router / agents array / agentBackendMap)
- [ ] File uploads have client-side extension + size pre-validation
- [ ] `npm run lint` passes with no errors
- [ ] Component props / emits are declared

---

## Known Issues and Conventions

### UnittestWorkspace is currently a mock flow
`startGeneration()` uses fixed delays to simulate LangGraph nodes and writes mock test code at the end.
When connecting to the real backend, replace with `apiGenerateTests` + `apiWaitForTask`; Pipeline nodes must strictly match the backend.

### AgentWorkspace non-Unittest Agents are mocked
The generation logic for Driver / MCU Review / RAG (AgentWorkspace render path) is currently mocked.
When connecting, replace the `generate()` method and call the corresponding backend endpoint.

### Global 401 logout
`http.js` automatically clears localStorage and dispatches `auth:logout` on receiving a 401.
The route guard listens for this event and redirects to `/login`. **No need to handle 401 in individual components.**
