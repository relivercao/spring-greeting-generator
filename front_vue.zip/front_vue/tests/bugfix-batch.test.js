import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../src/stores/auth.js'
import BatchBugFixWorkspace from '../src/components/BatchBugFixWorkspace.vue'
import BugFixWorkspace from '../src/components/BugFixWorkspace.vue'
import * as api from '../src/api/bugfix.js'

vi.mock('../src/api/bugfix.js', () => ({
  apiCancelBugFixBatch: vi.fn(), apiCreateBugFixBatch: vi.fn(),
  apiGetBugFixBatch: vi.fn(), apiGetBugFixTask: vi.fn(), apiListBugFixBatches: vi.fn(),
  apiPollBugFixBatch: vi.fn(), getBugFixIntegrations: vi.fn(),
}))

let wrapper
let poll
let stop
const identityToken = sub => `header.${btoa(JSON.stringify({ sub }))}.signature`
const snapshot = (status = 'running', overrides = {}) => ({
  task_id: 'batch-1', status, progress: 20, message: 'Processing defects',
  counts: { total: 2, queued: 1, running: 1, completed: 0, failed: 0, cancelled: 0 },
  items: [
    { task_id: 'child-1', label: 'FW-1', issue_id: 'FW-1', status: 'running', progress: 40, repo: 'firmware', branch: 'main', source_files: ['src/driver.c', 'include/driver.h'] },
    { task_id: 'child-2', label: 'FW-2', issue_id: 'FW-2', status: 'queued', progress: 0, repo: 'firmware', branch: 'main', source_files: ['src/driver.c', 'include/driver.h'] },
  ], ...overrides,
})
const mountBatch = () => shallowMount(BatchBugFixWorkspace, { global: { config: { warnHandler: () => {} } } })

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  useAuthStore().token = identityToken('owner')
  vi.resetAllMocks()
  stop = vi.fn()
  api.getBugFixIntegrations.mockResolvedValue({ jira: { available: true } })
  api.apiListBugFixBatches.mockResolvedValue({ batches: [] })
  api.apiCreateBugFixBatch.mockResolvedValue(snapshot())
  api.apiPollBugFixBatch.mockImplementation((_id, callback) => { poll = callback; return stop })
  api.apiGetBugFixTask.mockResolvedValue({ status: 'running', progress: 40, workflow_nodes: [] })
})
afterEach(() => wrapper?.unmount())

async function configureAndAdd() {
  wrapper.findComponent({ name: 'BugFixJiraSource' }).vm.$emit('batch-selected', [
    { key: 'FW-1', summary: 'UART overflow' }, { key: 'FW-2', summary: 'SPI timeout' },
  ])
  await wrapper.find('#batch-bugfix-repo').setValue('firmware')
  await wrapper.find('#batch-bugfix-paths').setValue('src/driver.c\ninclude/driver.h')
  await wrapper.find('#batch-bugfix-context').setValue('Reproduce with a full buffer')
  await wrapper.find('.add-to-queue').trigger('click')
  await flushPromises()
}

it('offers single and batch modes and locks mode switching during an active batch', async () => {
  wrapper = shallowMount(BugFixWorkspace, { global: { config: { warnHandler: () => {} } } })
  const tabs = wrapper.findAll('.bugfix-mode-tabs button')
  expect(tabs[0].attributes('aria-pressed')).toBe('true')
  await tabs[1].trigger('click')
  const batch = wrapper.findComponent({ name: 'BatchBugFixWorkspace' })
  expect(batch.exists()).toBe(true)
  batch.vm.$emit('busy', true)
  await flushPromises()
  expect(tabs[0].attributes('disabled')).toBeDefined()
})

it('queues complete defect contexts, freezes inputs, honors selection and order', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  expect(wrapper.findAll('.queue-list > li')).toHaveLength(2)
  await wrapper.find('#batch-bugfix-repo').setValue('different-repository')
  await wrapper.find('[aria-label="Move FW-2 up"]').trigger('click')
  await wrapper.find('[aria-label="Include FW-1"]').setValue(false)
  await wrapper.find('.run-batch').trigger('click')
  await flushPromises()
  expect(api.apiCreateBugFixBatch).toHaveBeenCalledTimes(1)
  expect(api.apiCreateBugFixBatch).toHaveBeenCalledWith([{
    issue_id: 'FW-2', repo: 'firmware', branch: 'main',
    source_files: ['src/driver.c', 'include/driver.h'], bug_description: 'Reproduce with a full buffer',
  }])
  expect(wrapper.find('.cancel-batch').exists()).toBe(true)
  expect(wrapper.find('.add-to-queue').exists()).toBe(false)
  expect(wrapper.findAll('.item-status').map(item => item.text())).toContain('running')
  expect(api.apiPollBugFixBatch).toHaveBeenCalledWith('batch-1', expect.any(Function))
})

it('rejects unsafe paths, duplicate defects and queues larger than 100', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  await wrapper.find('.add-to-queue').trigger('click')
  expect(wrapper.text()).toContain('already in the queue')
  await wrapper.find('#batch-bugfix-paths').setValue('../private.c')
  await wrapper.find('.add-to-queue').trigger('click')
  expect(wrapper.text()).toContain('repository-relative source paths')
  await wrapper.find('#batch-bugfix-paths').setValue('src/safe.c')
  wrapper.findComponent({ name: 'BugFixJiraSource' }).vm.$emit('batch-selected', Array.from({ length: 100 }, (_, index) => ({ key: `FW-${index + 10}` })))
  await wrapper.find('.add-to-queue').trigger('click')
  expect(wrapper.text()).toContain('at most 100 defects')
  expect(api.apiCreateBugFixBatch).not.toHaveBeenCalled()
})

it('displays saved reports and individual failures without hiding later successful items', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  await wrapper.find('.run-batch').trigger('click')
  await flushPromises()
  const final = snapshot('failed', { progress: 100 })
  final.items[0].status = 'failed'
  final.items[0].error = 'Patch validation failed'
  final.items[1].status = 'completed'
  api.apiGetBugFixTask.mockResolvedValue({ status: 'completed', result: { summary: 'Repair for FW-2', patches: {} } })
  poll(final)
  await flushPromises()
  await wrapper.findAll('.item-select')[1].trigger('click')
  await flushPromises()
  expect(wrapper.text()).toContain('Patch validation failed')
  const report = wrapper.findComponent({ name: 'BugFixResultReport' })
  expect(report.props('result').summary).toBe('Repair for FW-2')
  expect(report.props('showReset')).toBe(false)
  expect(stop).toHaveBeenCalled()
  expect(wrapper.find('.run-batch').exists()).toBe(false)
})

it('reconnects to server-owned work on mount and unmount never cancels the server batch', async () => {
  api.apiListBugFixBatches.mockResolvedValue({ batches: [{ task_id: 'batch-1', status: 'running' }] })
  api.apiGetBugFixBatch.mockResolvedValue(snapshot())
  wrapper = mountBatch()
  await flushPromises()
  expect(api.apiGetBugFixBatch).toHaveBeenCalledWith('batch-1')
  expect(api.apiCreateBugFixBatch).not.toHaveBeenCalled()
  expect(wrapper.find('.cancel-batch').exists()).toBe(true)
  wrapper.unmount()
  wrapper = null
  expect(stop).toHaveBeenCalled()
  expect(api.apiCancelBugFixBatch).not.toHaveBeenCalled()
})

it('keeps monitoring when cancellation fails and accepts cancellation after retry', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  await wrapper.find('.run-batch').trigger('click')
  await flushPromises()
  api.apiCancelBugFixBatch.mockRejectedValueOnce(new Error('Connection interrupted'))
  await wrapper.find('.cancel-batch').trigger('click')
  await flushPromises()
  expect(wrapper.text()).toContain('Monitoring continues')
  expect(stop).not.toHaveBeenCalled()
  expect(wrapper.find('.cancel-batch').attributes('disabled')).toBeUndefined()
  api.apiCancelBugFixBatch.mockResolvedValue(snapshot('cancelled'))
  await wrapper.find('.cancel-batch').trigger('click')
  await flushPromises()
  expect(wrapper.find('.cancel-batch').exists()).toBe(false)
  expect(stop).toHaveBeenCalled()
})

it('preserves the last known state on polling errors and rejects late running cancellation responses', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  await wrapper.find('.run-batch').trigger('click')
  await flushPromises()
  poll({ status: 'running', error: 'Connection interrupted' })
  expect(wrapper.vm.snapshot.status).toBe('running')
  expect(wrapper.vm.snapshot.items).toHaveLength(2)
  let resolve
  api.apiCancelBugFixBatch.mockReturnValue(new Promise(done => { resolve = done }))
  await wrapper.find('.cancel-batch').trigger('click')
  poll(snapshot('completed'))
  await flushPromises()
  resolve(snapshot())
  await flushPromises()
  expect(wrapper.vm.snapshot.status).toBe('completed')
})

it('does not display delayed results or resume polling after account changes', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  let resolve
  api.apiCreateBugFixBatch.mockReturnValue(new Promise(done => { resolve = done }))
  await wrapper.find('.run-batch').trigger('click')
  useAuthStore().token = identityToken('other-user')
  resolve(snapshot())
  await flushPromises()
  expect(api.apiPollBugFixBatch).not.toHaveBeenCalled()
  expect(api.apiGetBugFixTask).not.toHaveBeenCalled()
})

it('ignores a delayed report from a previously selected defect', async () => {
  wrapper = mountBatch()
  await configureAndAdd()
  let resolveFirst
  api.apiGetBugFixTask.mockImplementation(id => id === 'child-1'
    ? new Promise(done => { resolveFirst = done })
    : Promise.resolve({ status: 'completed', result: { summary: 'Second defect report' } }))
  await wrapper.find('.run-batch').trigger('click')
  await flushPromises()
  const data = snapshot('completed')
  data.items.forEach(item => { item.status = 'completed' })
  poll(data)
  await wrapper.findAll('.item-select')[1].trigger('click')
  await flushPromises()
  resolveFirst({ status: 'completed', result: { summary: 'Stale first report' } })
  await flushPromises()
  expect(wrapper.findComponent({ name: 'BugFixResultReport' }).props('result').summary).toBe('Second defect report')
})
