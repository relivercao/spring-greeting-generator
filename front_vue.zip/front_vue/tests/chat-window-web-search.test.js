import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import ChatWindow from '../src/components/ChatWindow.vue'

const preferenceKey = 'macode.chat.web-search-enabled.v1'
const wrappers = []

function mountChatWindow() {
  const wrapper = mount(ChatWindow, {
    props: { session: { id: 'session-1', messages: [] }, agent: { id: 1, name: 'Chat Agent' } },
    global: {
      stubs: {
        ElIcon: { template: '<span><slot /></span>' },
        ElTooltip: { template: '<span><slot /></span>' },
        ArrowDown: true,
        ArrowUp: true,
        ChatDotRound: true,
        Delete: true,
        Paperclip: true,
        Promotion: true,
        Close: true,
      },
    },
  })
  wrappers.push(wrapper)
  return wrapper
}

beforeEach(() => localStorage.removeItem(preferenceKey))
afterEach(() => {
  wrappers.splice(0).forEach(wrapper => wrapper.unmount())
  localStorage.removeItem(preferenceKey)
})

describe('Chat web search preference', () => {
  it('defaults to enabled and sends that setting with the message', async () => {
    const wrapper = mountChatWindow()
    expect(wrapper.find('.web-search-toggle input').element.checked).toBe(true)

    await wrapper.find('textarea').setValue('Explain ARM TrustZone')
    await wrapper.find('.send-btn').trigger('click')

    expect(wrapper.emitted('send-message')).toEqual([['Explain ARM TrustZone', true]])
  })

  it('remembers an opt-out and sends the updated preference', async () => {
    const wrapper = mountChatWindow()
    await wrapper.find('.web-search-toggle input').setValue(false)
    expect(localStorage.getItem(preferenceKey)).toBe('false')

    const restored = mountChatWindow()
    expect(restored.find('.web-search-toggle input').element.checked).toBe(false)

    await restored.find('textarea').setValue('Explain this code')
    await restored.find('.send-btn').trigger('click')
    expect(restored.emitted('send-message')).toEqual([['Explain this code', false]])
  })

  it('queues readable source attachments and allows sending without a typed prompt', async () => {
    const wrapper = mountChatWindow()
    const file = new File(['int main(void) { return 0; }'], 'firmware.c', { type: 'text/plain' })
    const input = wrapper.find('.attachment-input').element
    Object.defineProperty(input, 'files', { configurable: true, value: [file] })
    await wrapper.find('.attachment-input').trigger('change')

    expect(wrapper.text()).toContain('firmware.c')
    expect(wrapper.text()).toContain('Web search paused for private files')
    expect(wrapper.find('.web-search-toggle input').element.disabled).toBe(true)
    await wrapper.find('.send-btn').trigger('click')

    expect(wrapper.emitted('send-message')).toEqual([[
      'Please analyze the attached files.', true, [file],
    ]])
    expect(wrapper.find('.attachment-chip').exists()).toBe(false)
  })

  it('accepts image attachments for Claude Code OCR analysis', async () => {
    const wrapper = mountChatWindow()
    const file = new File(['image bytes'], 'schematic.png', { type: 'image/png' })
    const input = wrapper.find('.attachment-input').element
    Object.defineProperty(input, 'files', { configurable: true, value: [file] })
    await wrapper.find('.attachment-input').trigger('change')

    expect(wrapper.text()).toContain('schematic.png')
    expect(wrapper.find('.send-btn').element.disabled).toBe(false)
  })

  it('rejects unsupported files before they can be sent', async () => {
    const wrapper = mountChatWindow()
    const file = new File(['binary'], 'firmware.bin', { type: 'application/octet-stream' })
    const input = wrapper.find('.attachment-input').element
    Object.defineProperty(input, 'files', { configurable: true, value: [file] })
    await wrapper.find('.attachment-input').trigger('change')

    expect(wrapper.text()).toContain('firmware.bin: unsupported file type')
    expect(wrapper.find('.send-btn').element.disabled).toBe(true)
  })

  it('does not expose file analysis in specialist Agent chats', () => {
    const wrapper = mount(ChatWindow, {
      props: { session: { id: 'session-2', messages: [] }, agent: { id: 3, name: 'Driver Agent' } },
      global: { stubs: { ElIcon: true, ElTooltip: true } },
    })

    expect(wrapper.find('.attachment-input').exists()).toBe(false)
    expect(wrapper.find('.attach-btn').exists()).toBe(false)
    wrapper.unmount()
  })
})
