import { beforeEach, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { nextTick } from 'vue'
import { useAuthStore } from '../src/stores/auth.js'
import { useChatStore } from '../src/stores/chat.js'
import { AGENT_BACKEND_MAP, AGENT_ROUTE_MAP, BUILT_IN_AGENTS } from '../src/config/agentCatalog.js'

const token = sub => `header.${btoa(JSON.stringify({ sub }))}.signature`
beforeEach(() => { localStorage.clear(); setActivePinia(createPinia()) })

it('separates sidebar conversations across accounts, logout, and guest access', async () => {
  const auth = useAuthStore()
  auth.token = token('first-user')
  const store = useChatStore()
  const session = store.createSession({ id: 1, name: 'Chat' })
  store.addMessage(session.id, { id: 'message', content: 'Private conversation' })
  auth.token = token('second-user')
  expect(store.history).toEqual([])
  await nextTick()
  auth.token = token('first-user')
  expect(store.findSession(session.id).messages[0].content).toBe('Private conversation')
  auth.logout()
  expect(store.history).toEqual([])
  auth.enterGuest()
  expect(store.history).toEqual([])
})

it('does not adopt legacy conversations with unknown ownership', () => {
  const legacy = JSON.stringify([{ id: 'old-session', messages: [], agentId: 1 }])
  localStorage.setItem('agent_chat_history', legacy)
  useAuthStore().token = token('new-owner')
  expect(useChatStore().history).toEqual([])
  expect(localStorage.getItem('agent_chat_history')).toBe(legacy)
})

it('keeps Chat Agent registered with a route and backend mapping', () => {
  const agent = BUILT_IN_AGENTS.find(item => item.id === 1)
  expect(agent?.name).toBe('Chat Agent')
  expect(AGENT_ROUTE_MAP[1]).toBe('/chat')
  expect(AGENT_BACKEND_MAP[1]).toBe('chat')
})
