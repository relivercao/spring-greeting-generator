import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import GlobalEmailSettings from '../src/components/GlobalEmailSettings.vue'
import {
  getGlobalEmailSettings,
  saveGlobalEmailSettings,
  checkGlobalEmailConnection,
} from '../src/api/settings.js'

vi.mock('../src/api/settings.js', () => ({
  getGlobalEmailSettings: vi.fn(),
  saveGlobalEmailSettings: vi.fn(),
  checkGlobalEmailConnection: vi.fn(),
}))

const savedConfiguration = {
  provider: 'gmail',
  host: 'smtp.gmail.com',
  port: 587,
  security: 'starttls',
  username: 'system@gmail.com',
  sender: 'system@gmail.com',
  approval_enabled: false,
  approval_use_global: true,
  approval_recipients: '',
  configured: true,
  password_configured: true,
}
const buttonStub = {
  props: ['disabled', 'loading'],
  template: '<button :disabled="disabled || loading"><slot /></button>',
}
const inputStub = {
  props: ['modelValue', 'disabled'],
  emits: ['update:modelValue'],
  template:
    '<input :value="modelValue" :disabled="disabled" @input="$emit(\'update:modelValue\', $event.target.value)" />',
}
const selectStub = {
  props: ['modelValue'],
  emits: ['update:modelValue', 'change'],
  template:
    '<select :value="modelValue" @change="$emit(\'update:modelValue\', $event.target.value); $emit(\'change\', $event.target.value)"><slot /></select>',
}
const optionStub = {
  props: ['value', 'label'],
  template: '<option :value="value">{{ label }}</option>',
}
const alertStub = {
  props: ['title', 'type'],
  template: "<p :role=\"type === 'error' ? 'alert' : 'status'\">{{ title }}</p>",
}
let wrapper

async function openSettings() {
  wrapper = shallowMount(GlobalEmailSettings, {
    global: {
      config: { warnHandler: () => {} },
      stubs: {
        ElButton: buttonStub,
        ElInput: inputStub,
        ElSelect: selectStub,
        ElOption: optionStub,
        ElAlert: alertStub,
      },
    },
  })
  expect(getGlobalEmailSettings).not.toHaveBeenCalled()
  Object.defineProperty(wrapper.find('details').element, 'open', {
    value: true,
    configurable: true,
  })
  await wrapper.find('details').trigger('toggle')
  await flushPromises()
}

function button(label) {
  return wrapper.findAll('button').find(item => item.text() === label)
}

beforeEach(() => {
  vi.clearAllMocks()
  getGlobalEmailSettings.mockResolvedValue({ ...savedConfiguration })
  saveGlobalEmailSettings.mockResolvedValue({ ...savedConfiguration })
  checkGlobalEmailConnection.mockResolvedValue({
    success: true,
    message: 'SMTP connection verified.',
  })
})

afterEach(() => {
  wrapper?.unmount()
})

it('preserves the saved password and keeps approval notifications disabled when saving', async () => {
  await openSettings()
  expect(wrapper.find('#global-mail-password').element.value).toBe('')
  await button('Save email settings').trigger('click')
  await flushPromises()
  const { configured, password_configured, ...form } = savedConfiguration
  expect(saveGlobalEmailSettings).toHaveBeenCalledWith({ ...form, password: null })
  expect(checkGlobalEmailConnection).not.toHaveBeenCalled()
})

it('sets the Gmail host and matching encrypted ports from provider selections', async () => {
  getGlobalEmailSettings.mockResolvedValue({
    ...savedConfiguration,
    provider: 'custom',
    host: 'smtp.example.com',
    port: 2525,
  })
  await openSettings()
  await wrapper.find('#global-mail-provider').setValue('gmail')
  expect(wrapper.find('#global-mail-host').element.value).toBe('smtp.gmail.com')
  expect(wrapper.find('#global-mail-host').element.disabled).toBe(true)
  expect(wrapper.find('#global-mail-port').element.value).toBe('587')
  await wrapper.find('#global-mail-security').setValue('ssl')
  expect(wrapper.find('#global-mail-port').element.value).toBe('465')
  await wrapper.find('#global-mail-security').setValue('starttls')
  expect(wrapper.find('#global-mail-port').element.value).toBe('587')
  expect(wrapper.find('#global-mail-security').text()).not.toContain('None')
})

it('checks saved credentials without sending and blocks checks while settings are edited', async () => {
  await openSettings()
  const check = button('Check saved connection')
  expect(check.element.disabled).toBe(false)
  await check.trigger('click')
  await flushPromises()
  expect(checkGlobalEmailConnection).toHaveBeenCalledTimes(1)
  expect(wrapper.text()).toContain('SMTP connection verified.')
  await wrapper.find('#global-mail-password').setValue('new-app-password')
  expect(check.element.disabled).toBe(true)
  await button('Save email settings').trigger('click')
  await flushPromises()
  expect(saveGlobalEmailSettings.mock.calls[0][0].password).toBe('new-app-password')
  expect(wrapper.find('#global-mail-password').element.value).toBe('')
  expect(check.element.disabled).toBe(false)
})

it('does not allow connection checks before a mailbox has been configured', async () => {
  getGlobalEmailSettings.mockResolvedValue({
    ...savedConfiguration,
    provider: 'custom',
    host: '',
    username: '',
    sender: '',
    configured: false,
    password_configured: false,
  })
  await openSettings()
  expect(wrapper.find('#global-mail-provider').element.value).toBe('gmail')
  expect(button('Check saved connection').element.disabled).toBe(true)
  expect(wrapper.text()).toContain('Setup required')
})

it('shows authentication failures and keeps edits after a failed save', async () => {
  await openSettings()
  checkGlobalEmailConnection.mockRejectedValue(new Error('SMTP authentication failed.'))
  await button('Check saved connection').trigger('click')
  await flushPromises()
  expect(wrapper.find('[role="alert"]').text()).toBe('SMTP authentication failed.')
  saveGlobalEmailSettings.mockRejectedValue(new Error('Email settings could not be saved.'))
  await wrapper.find('#global-mail-username').setValue('different@gmail.com')
  await button('Save email settings').trigger('click')
  await flushPromises()
  expect(wrapper.find('[role="alert"]').text()).toBe('Email settings could not be saved.')
  expect(wrapper.find('#global-mail-username').element.value).toBe('different@gmail.com')
  expect(button('Check saved connection').element.disabled).toBe(true)
})

it('allows retry after the configuration cannot be loaded', async () => {
  getGlobalEmailSettings.mockRejectedValueOnce(new Error('Email settings unavailable.'))
  await openSettings()
  expect(wrapper.text()).toContain('Email settings unavailable.')
  expect(button('Save email settings')).toBeUndefined()
  await button('Retry').trigger('click')
  await flushPromises()
  expect(getGlobalEmailSettings).toHaveBeenCalledTimes(2)
  expect(button('Save email settings')).toBeDefined()
})
