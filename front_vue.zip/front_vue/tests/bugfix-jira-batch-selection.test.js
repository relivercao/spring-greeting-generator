import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import BugFixJiraSource from '../src/components/bugfix-workspace/BugFixJiraSource.vue'
import { apiGetJiraBug, apiGetJiraBugs } from '../src/api/bugfix.js'

vi.mock('vue-router', () => ({ useRoute: () => ({ query: {} }) }))
vi.mock('../src/api/bugfix.js', () => ({ apiGetJiraBug: vi.fn(), apiGetJiraBugs: vi.fn() }))
let wrapper
const visible = [
  { key: 'FW-1', summary: 'First defect' }, { key: 'FW-2', summary: 'Second defect' },
]
beforeEach(() => {
  vi.resetAllMocks()
  apiGetJiraBugs.mockResolvedValue({ issues: visible })
  wrapper = shallowMount(BugFixJiraSource, {
    props: { multiple: true, integration: { available: false } },
    global: { config: { warnHandler: () => {} } },
  })
})
afterEach(() => wrapper.unmount())

it('selects visible issues, supports individual exclusion, and preserves selection across searches', async () => {
  await wrapper.find('.load-button').trigger('click')
  await flushPromises()
  await wrapper.find('[aria-label="Select all visible Jira Bugs"]').setValue(true)
  expect(wrapper.emitted('batch-selected').at(-1)[0]).toEqual(visible)
  await wrapper.find('[aria-label="Select FW-1"]').setValue(false)
  expect(wrapper.emitted('batch-selected').at(-1)[0]).toEqual([visible[1]])
  apiGetJiraBugs.mockResolvedValue({ issues: [{ key: 'OTHER-1', summary: 'Another project' }] })
  await wrapper.find('#bugfix-jira-query').setValue('OTHER')
  await wrapper.find('.load-button').trigger('click')
  await flushPromises()
  await wrapper.find('[aria-label="Select OTHER-1"]').setValue(true)
  expect(wrapper.emitted('batch-selected').at(-1)[0].map(issue => issue.key)).toEqual(['FW-2', 'OTHER-1'])
})

it('adds a directly opened issue to the batch selector without duplicating it', async () => {
  apiGetJiraBug.mockResolvedValue({ key: 'FW-3', summary: 'Direct defect' })
  await wrapper.find('#bugfix-jira-query').setValue('FW-3')
  await wrapper.find('.load-button').trigger('click')
  await flushPromises()
  expect(wrapper.find('[aria-label="Select FW-3"]').element.checked).toBe(true)
  expect(wrapper.emitted('batch-selected').at(-1)[0]).toEqual([{ key: 'FW-3', summary: 'Direct defect' }])
  await wrapper.find('.ticket-option').trigger('click')
  await flushPromises()
  expect(wrapper.findAll('.ticket-option')).toHaveLength(1)
})

it('disables batch selection during execution and leaves single selection intact', async () => {
  await wrapper.find('.load-button').trigger('click')
  await flushPromises()
  await wrapper.setProps({ disabled: true })
  expect(wrapper.find('[aria-label="Select FW-1"]').attributes('disabled')).toBeDefined()
  await wrapper.setProps({ disabled: false, multiple: false })
  expect(wrapper.find('[aria-label="Select FW-1"]').exists()).toBe(false)
  apiGetJiraBug.mockResolvedValue(visible[0])
  await wrapper.findAll('.ticket-option')[0].trigger('click')
  await flushPromises()
  expect(wrapper.emitted('selected').at(-1)[0]).toEqual(visible[0])
})
