import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { ElMessageBox } from 'element-plus'
import RagWorkspace from '../src/components/RagWorkspace.vue'
import { useAuthStore } from '../src/stores/auth.js'
import * as api from '../src/api/knowledgeBase.js'

vi.mock('../src/api/knowledgeBase.js', () => ({
  askKnowledgeBase: vi.fn(), buildKnowledgeMkdocs: vi.fn(), deleteKnowledgeDocument: vi.fn(),
  getKnowledgeRepositoryStatus: vi.fn(), importGithubReference: vi.fn(), importObsidianVault: vi.fn(),
  listKnowledgeDocuments: vi.fn(), previewKnowledgeChunks: vi.fn(), searchKnowledgeRegisters: vi.fn(),
  syncKnowledgeRepository: vi.fn(),
  uploadKnowledgeDocument: vi.fn(),
}))

let wrapper
function deferred() {
  let resolve
  const promise = new Promise(done => { resolve = done })
  return { promise, resolve }
}
function switchAccount() {
  useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'second-user' }))}.signature`
}
beforeEach(async () => {
  localStorage.clear()
  setActivePinia(createPinia())
  useAuthStore().enterGuest()
  vi.resetAllMocks()
  api.listKnowledgeDocuments.mockResolvedValue({ documents: [{ id: 'private-doc', title: 'Design' }] })
  api.getKnowledgeRepositoryStatus.mockResolvedValue({})
  api.searchKnowledgeRegisters.mockResolvedValue({ results: [] })
  wrapper = shallowMount(RagWorkspace, {
    props: { agent: { id: 5, name: 'Knowledge', color: '#2563eb' } },
    global: { config: { warnHandler: () => {} } },
  })
  await flushPromises()
})
afterEach(() => wrapper?.vm && wrapper.unmount())

it('does not delete a document under another account after confirmation', async () => {
  const pending = deferred()
  vi.spyOn(ElMessageBox, 'confirm').mockReturnValue(pending.promise)
  const deleting = wrapper.vm.removeDocument('private-doc')
  switchAccount()
  pending.resolve('confirm')
  await deleting
  expect(api.deleteKnowledgeDocument).not.toHaveBeenCalled()
  expect(wrapper.vm.documents).toEqual([])
})

it('discards an answer and private conversation after an account change', async () => {
  const pending = deferred()
  api.askKnowledgeBase.mockReturnValue(pending.promise)
  wrapper.vm.question = 'Private register question'
  const asking = wrapper.vm.submitQuestion()
  await flushPromises()
  switchAccount()
  pending.resolve({ answer: 'Private answer', exact_hits: [], evidence: [] })
  await asking
  expect(wrapper.vm.messages).toEqual([])
})

it('does not refresh under new credentials after leaving during an upload', async () => {
  const pending = deferred()
  api.uploadKnowledgeDocument.mockReturnValue(pending.promise)
  wrapper.vm.setSelectedFile(new File(['notes'], 'notes.md', { type: 'text/markdown' }))
  const uploading = wrapper.vm.importDocument()
  wrapper.unmount()
  pending.resolve({ document_id: 'new-doc', stats: { registers: 0, bitfields: 0 } })
  await uploading
  expect(api.listKnowledgeDocuments).toHaveBeenCalledTimes(1)
})

it('automatically imports selected files with their filename as the default name', async () => {
  api.uploadKnowledgeDocument.mockResolvedValue({
    document_id: 'uploaded-doc',
    stats: { chunks: 2, registers: 0, bitfields: 0 },
  })
  api.listKnowledgeDocuments.mockResolvedValueOnce({ documents: [{
    id: 'uploaded-doc',
    title: 'quick-start',
    chip: 'GENERAL',
    chunk_count: 2,
    source_lines: 3,
    register_count: 0,
    bitfield_count: 0,
    index_status: 'ready',
  }] })
  const file = new File(['reference notes'], 'quick-start.md', { type: 'text/markdown' })

  await wrapper.vm.handleFileChange({ target: { files: [file], value: 'quick-start.md' } })

  expect(api.uploadKnowledgeDocument).toHaveBeenCalledWith(file, expect.objectContaining({ title: 'quick-start' }))
  expect(wrapper.vm.selectedFile).toBeNull()
  expect(wrapper.vm.form.title).toBe('')
  expect(wrapper.text()).toContain('2 search chunks')
  expect(wrapper.text()).toContain('Indexed | 0 registers | 0 fields')
  expect(wrapper.find('.advanced-imports').element.open).toBe(false)
})

it('automatically converts selected PDFs to Markdown before indexing', async () => {
  const pending = deferred()
  api.uploadKnowledgeDocument.mockReturnValue(pending.promise)
  const file = new File(['pdf bytes'], 'datasheet.pdf', { type: 'application/pdf' })

  const importing = wrapper.vm.handleFileChange({
    target: { files: [file], value: 'datasheet.pdf' },
  })
  await flushPromises()

  expect(api.uploadKnowledgeDocument).toHaveBeenCalledWith(file, expect.objectContaining({
    title: 'datasheet',
    llmOcr: true,
  }))
  expect(wrapper.text()).toContain('Converting PDF to Markdown and indexing')

  pending.resolve({
    document_id: 'converted-pdf',
    repository_path: 'docs/general/converted-pdf.md',
    stats: { chunks: 4, registers: 2, bitfields: 1 },
    conversion: { pages: 3, tables: 1, lossless_verified: true },
  })
  await importing

  expect(wrapper.vm.selectedFile).toBeNull()
  expect(wrapper.vm.activeDocumentId).toBe('converted-pdf')
})

it('automatically imports dropped files and keeps a user-provided name', async () => {
  api.uploadKnowledgeDocument.mockResolvedValue({
    document_id: 'uploaded-doc',
    stats: { registers: 0, bitfields: 0 },
  })
  wrapper.vm.form.title = 'Board bring-up guide'
  const file = new File(['bring-up notes'], 'notes.txt', { type: 'text/plain' })

  await wrapper.vm.handleDrop({ dataTransfer: { files: [file] } })

  expect(api.uploadKnowledgeDocument).toHaveBeenCalledWith(file, expect.objectContaining({ title: 'Board bring-up guide' }))
  expect(wrapper.vm.selectedFile).toBeNull()
  expect(wrapper.vm.form.title).toBe('')
})

it('uses the next filename after a failed automatic upload instead of reusing the previous name', async () => {
  api.uploadKnowledgeDocument
    .mockRejectedValueOnce(new Error('Conversion failed'))
    .mockResolvedValueOnce({ document_id: 'uploaded-doc', stats: { registers: 0, bitfields: 0 } })
  const firstFile = new File(['first'], 'first-guide.md', { type: 'text/markdown' })
  const secondFile = new File(['second'], 'second-guide.md', { type: 'text/markdown' })

  await wrapper.vm.handleFileChange({ target: { files: [firstFile], value: 'first-guide.md' } })
  expect(wrapper.vm.form.title).toBe('first-guide')
  expect(wrapper.vm.selectedFile).toBe(firstFile)

  await wrapper.vm.handleDrop({ dataTransfer: { files: [secondFile] } })

  expect(api.uploadKnowledgeDocument).toHaveBeenLastCalledWith(secondFile, expect.objectContaining({ title: 'second-guide' }))
  expect(wrapper.vm.form.title).toBe('')
})

it('discards chunk preview when a different file is selected during its local read', async () => {
  const pending = deferred()
  wrapper.vm.setSelectedFile({ name: 'first.md', text: () => pending.promise })
  const previewing = wrapper.vm.previewSelectedFile()
  wrapper.vm.setSelectedFile({ name: 'second.md', text: async () => 'second' })
  pending.resolve('first')
  await previewing
  expect(api.previewKnowledgeChunks).not.toHaveBeenCalled()
  expect(wrapper.vm.chunkPreviewVisible).toBe(false)
})

it('shows answers and chunk previews for the current account and selected file', async () => {
  api.askKnowledgeBase.mockResolvedValue({ answer: 'Register evidence', exact_hits: [], evidence: [], warnings: [] })
  wrapper.vm.question = 'Explain the register'
  await wrapper.vm.submitQuestion()
  expect(wrapper.vm.messages[1].result.answer).toBe('Register evidence')
  api.previewKnowledgeChunks.mockResolvedValue({ chunks: [], chunk_count: 0 })
  wrapper.vm.setSelectedFile({ name: 'current.md', text: async () => 'Current notes' })
  await wrapper.vm.previewSelectedFile()
  expect(api.previewKnowledgeChunks).toHaveBeenCalledWith('Current notes')
  expect(wrapper.vm.chunkPreviewVisible).toBe(true)
})

it('suggests questions from indexed register data and targets its source document', async () => {
  api.searchKnowledgeRegisters.mockResolvedValue({ results: [{
    document_id: 'private-doc',
    chip: 'STM32F4',
    register_name: 'LCR',
    field_name: 'WLS',
    bit_range: '1:0',
  }] })
  api.askKnowledgeBase.mockResolvedValue({
    answer: 'WLS evidence', exact_hits: [], evidence: [], warnings: [],
  })

  await wrapper.vm.refreshWorkspace()
  await flushPromises()
  const suggestion = wrapper.find('.example-queries button')
  expect(suggestion.text()).toBe('LCR WLS bits 1:0')
  await suggestion.trigger('click')
  await wrapper.vm.submitQuestion()

  expect(api.askKnowledgeBase).toHaveBeenCalledWith(expect.objectContaining({
    question: 'LCR WLS bits 1:0',
    chip: 'STM32F4',
    document_id: 'private-doc',
  }))
})

it('keeps a failed question available for retry and displays a persistent error', async () => {
  api.askKnowledgeBase.mockRejectedValue(new Error('The knowledge request timed out. Please try again.'))
  wrapper.vm.question = 'What is the startup delay?'
  await wrapper.vm.submitQuestion()
  expect(wrapper.vm.asking).toBe(false)
  expect(wrapper.vm.question).toBe('What is the startup delay?')
  expect(wrapper.find('[role="alert"]').text()).toContain('timed out')
})
