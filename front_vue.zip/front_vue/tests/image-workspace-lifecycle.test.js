import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { reactive } from 'vue'
import ImageGenerationWorkspace from '../src/components/ImageGenerationWorkspace.vue'
import { createImageGenerationTask, getImageGenerationSettings } from '../src/api/imageGeneration.js'
import { listKnowledgeDocuments } from '../src/api/knowledgeBase.js'
import { ElMessageBox } from 'element-plus'

const { store } = vi.hoisted(() => ({ store: {
  taskHistory: [], accountRevision: 0, loading: false,
  loadHistory: vi.fn(), refreshTask: vi.fn(), upsertTask: vi.fn(), removeTask: vi.fn(),
} }))
vi.mock('../src/stores/imageGeneration.js', async () => {
  const { reactive } = await import('vue')
  return { useImageGenerationStore: () => reactive(store) }
})
vi.mock('../src/api/imageGeneration.js', () => ({
  createImageGenerationTask: vi.fn(), getImageGenerationSettings: vi.fn(), cancelImageGenerationTask: vi.fn(),
}))
vi.mock('../src/api/knowledgeBase.js', () => ({ listKnowledgeDocuments: vi.fn() }))

let wrapper
function deferred() {
  let resolve
  const promise = new Promise(done => { resolve = done })
  return { promise, resolve }
}
function mount() {
  wrapper = shallowMount(ImageGenerationWorkspace, { global: { config: { warnHandler: () => {} } } })
  return wrapper
}
beforeEach(() => {
  vi.useFakeTimers()
  vi.resetAllMocks()
  store.accountRevision = 0
  store.taskHistory = [{ id: 'task-running', status: 'running' }]
  store.loadHistory.mockResolvedValue([])
  listKnowledgeDocuments.mockResolvedValue({ documents: [] })
})
afterEach(() => { wrapper?.unmount(); vi.useRealTimers(); vi.unstubAllGlobals() })

it('does not restart polling or request knowledge after leaving during history loading', async () => {
  const pending = deferred()
  store.loadHistory.mockReturnValue(pending.promise)
  mount().unmount()
  pending.resolve([])
  await flushPromises()
  await vi.advanceTimersByTimeAsync(4000)
  expect(listKnowledgeDocuments).not.toHaveBeenCalled()
  expect(store.refreshTask).not.toHaveBeenCalled()
  expect(vi.getTimerCount()).toBe(0)
})

it('does not submit generation after leaving during the settings request', async () => {
  const pending = deferred()
  getImageGenerationSettings.mockReturnValue(pending.promise)
  mount()
  await flushPromises()
  await wrapper.find('.prompt-input').setValue('Draw a blue box')
  const generating = wrapper.vm.generate()
  wrapper.unmount()
  pending.resolve({ configured: true })
  await generating
  expect(createImageGenerationTask).not.toHaveBeenCalled()
})

it('does not delete a task under another account after confirmation', async () => {
  const pending = deferred()
  vi.spyOn(ElMessageBox, 'confirm').mockReturnValue(pending.promise)
  mount()
  await flushPromises()
  const deleting = wrapper.vm.deleteTask({ id: 'task-running' })
  store.accountRevision += 1
  pending.resolve('confirm')
  await deleting
  expect(store.removeTask).not.toHaveBeenCalled()
})

it('retains live polling and completion events while the workspace is mounted', async () => {
  store.refreshTask.mockResolvedValue({ id: 'task-running', status: 'completed' })
  mount()
  await flushPromises()
  await vi.advanceTimersByTimeAsync(2000)
  expect(store.refreshTask).toHaveBeenCalledWith('task-running')
  expect(wrapper.emitted('task-updated')[0][0].status).toBe('completed')
})

it('clears private inputs, reference images and open previews at an account boundary', async () => {
  vi.stubGlobal('URL', { createObjectURL: vi.fn(() => 'blob:private-reference'), revokeObjectURL: vi.fn() })
  mount()
  await flushPromises()
  await wrapper.find('.prompt-input').setValue('Private design')
  wrapper.vm.addReferenceFiles([new File(['image'], 'private.png', { type: 'image/png' })])
  wrapper.vm.openPreview({ task: { input: { prompt: 'Private output' } }, image: { url: '/private.png' } })
  reactive(store).accountRevision += 1
  await flushPromises()
  expect(wrapper.find('.prompt-input').element.value).toBe('')
  expect(wrapper.vm.referenceImages).toEqual([])
  expect(wrapper.vm.previewVisible).toBe(false)
  expect(wrapper.vm.previewItem).toBeNull()
  expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:private-reference')
  expect(vi.getTimerCount()).toBe(0)
})
