import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../src/stores/auth.js'
import BugFixWorkspace from '../src/components/BugFixWorkspace.vue'
import * as api from '../src/api/bugfix.js'

vi.mock('../src/api/bugfix.js', () => ({
  apiCancelBugFixTask: vi.fn(), apiCreateBugFixTask: vi.fn(),
  apiPollBugFixTask: vi.fn(), getBugFixIntegrations: vi.fn(),
}))

let wrapper
let poll
let stop

beforeEach(async () => {
  localStorage.clear()
  setActivePinia(createPinia())
  useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'test-user' }))}.signature`
  vi.resetAllMocks()
  stop = vi.fn()
  api.getBugFixIntegrations.mockResolvedValue({})
  api.apiCreateBugFixTask.mockResolvedValue({ task_id: 'task-first' })
  api.apiPollBugFixTask.mockImplementation((_id, callback) => {
    poll = callback
    return stop
  })
  wrapper = shallowMount(BugFixWorkspace, { global: { config: { warnHandler: () => {} } } })
  wrapper.findComponent({ name: 'BugFixJiraSource' }).vm.$emit('selected', { key: 'TEST-1' })
  await wrapper.find('#bugfix-repo').setValue('example/repository')
  await wrapper.find('#bugfix-paths').setValue('src/example.c')
  await wrapper.find('.generate-btn').trigger('click')
  await flushPromises()
})

afterEach(() => wrapper.unmount())

it('requires sign-in before starting a BugFix task', async () => {
  useAuthStore().token = null
  await flushPromises()
  api.apiCreateBugFixTask.mockClear()
  expect(wrapper.text()).toContain('Sign in to run BugFix')
  expect(wrapper.find('.generate-btn').attributes('disabled')).toBeDefined()
  await wrapper.vm.runBugFix()
  expect(api.apiCreateBugFixTask).not.toHaveBeenCalled()
})

it('keeps observing after a cancellation request fails and allows retry', async () => {
  api.apiCancelBugFixTask.mockRejectedValue(new Error('Connection interrupted'))
  await wrapper.find('.cancel-btn-top-right').trigger('click')
  await flushPromises()
  expect(wrapper.find('.loading-area').exists()).toBe(true)
  expect(wrapper.find('.error-area').exists()).toBe(false)
  expect(stop).not.toHaveBeenCalled()
  expect(wrapper.find('.cancel-btn-top-right').attributes('disabled')).toBeUndefined()
  expect(wrapper.findComponent({ name: 'DriverWorkflowProgress' }).props('description')).toContain('Connection interrupted')
  poll({ status: 'completed', result: { summary: 'Finished after connection recovered' } })
  await flushPromises()
  expect(wrapper.findComponent({ name: 'BugFixResultReport' }).props('result').summary).toBe('Finished after connection recovered')
})

it('keeps observing while the server is still cancelling', async () => {
  api.apiCancelBugFixTask.mockResolvedValue({ status: 'running', progress: 40 })
  await wrapper.find('.cancel-btn-top-right').trigger('click')
  await flushPromises()
  expect(wrapper.find('.loading-area').exists()).toBe(true)
  expect(stop).not.toHaveBeenCalled()
  expect(wrapper.find('.cancel-btn-top-right').attributes('disabled')).toBeUndefined()
  poll({ status: 'cancelled', message: 'Cancelled by user' })
  await flushPromises()
  expect(wrapper.find('.error-area').text()).toContain('Cancelled by user')
  expect(stop).toHaveBeenCalledTimes(1)
})

it('accepts a terminal cancellation response', async () => {
  api.apiCancelBugFixTask.mockResolvedValue({ status: 'cancelled', message: 'Cancelled by user' })
  await wrapper.find('.cancel-btn-top-right').trigger('click')
  await flushPromises()
  expect(wrapper.find('.error-area').text()).toContain('Cancelled by user')
  expect(stop).toHaveBeenCalledTimes(1)
})

it('preserves completion when a delayed cancellation failure arrives', async () => {
  let reject
  api.apiCancelBugFixTask.mockReturnValue(new Promise((_resolve, fail) => { reject = fail }))
  await wrapper.find('.cancel-btn-top-right').trigger('click')
  poll({ status: 'completed', result: { summary: 'Finished' } })
  await flushPromises()
  reject(new Error('Late connection failure'))
  await flushPromises()
  expect(wrapper.findComponent({ name: 'BugFixResultReport' }).exists()).toBe(true)
  expect(wrapper.find('.error-area').exists()).toBe(false)
})

it('does not apply an old cancellation response to a new task', async () => {
  let resolve
  api.apiCancelBugFixTask.mockReturnValue(new Promise(done => { resolve = done }))
  await wrapper.find('.cancel-btn-top-right').trigger('click')
  poll({ status: 'completed', result: {} })
  await flushPromises()
  wrapper.findComponent({ name: 'BugFixResultReport' }).vm.$emit('reset')
  api.apiCreateBugFixTask.mockResolvedValue({ task_id: 'task-second' })
  await wrapper.find('.generate-btn').trigger('click')
  await flushPromises()
  resolve({ status: 'cancelled', message: 'First task cancelled' })
  await flushPromises()
  expect(wrapper.find('.task-reference').text()).toContain('task-second')
  expect(wrapper.find('.loading-area').exists()).toBe(true)
})

it('does not start polling when task creation completes after navigation', async () => {
  poll({ status: 'completed', result: {} })
  await flushPromises()
  wrapper.vm.resetResult()
  let resolve
  api.apiCreateBugFixTask.mockReturnValue(new Promise(done => { resolve = done }))
  const pending = wrapper.vm.runBugFix()
  wrapper.unmount()
  resolve({ task_id: 'late-task' })
  await pending
  expect(api.apiPollBugFixTask).toHaveBeenCalledTimes(1)
})

it('invalidates task observation immediately when the account changes', async () => {
  useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'another-user' }))}.signature`
  expect(stop).toHaveBeenCalledTimes(1)
  poll({ status: 'completed', result: { summary: 'Private result' } })
  await flushPromises()
  expect(wrapper.vm.result).toBeNull()
})
