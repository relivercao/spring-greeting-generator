import { describe, expect, it } from 'vitest'
import { renderChatContent } from '../src/utils/chatContent.js'

describe('chat document links', () => {
  it('turns generated artifact paths into links that can be opened in a new tab', () => {
    const content = 'Generated document: [D:/outputs/chat/guide.docx](/api/v1/chat/artifacts/owner/session/id/guide.docx?expires=1&signature=abc)'
    const html = renderChatContent(content)
    const link = document.createElement('div')
    link.innerHTML = html

    const anchor = link.querySelector('.chat-link')
    expect(anchor?.textContent).toBe('D:/outputs/chat/guide.docx')
    expect(anchor?.getAttribute('href')).toContain('/api/v1/chat/artifacts/owner/session/id/guide.docx?expires=1&signature=abc')
    expect(anchor?.getAttribute('target')).toBe('_blank')
    expect(anchor?.getAttribute('rel')).toContain('noopener')
  })

  it('links document paths returned as plain text and retains code blocks', () => {
    const html = renderChatContent('Saved at D:\\outputs\\chat\\report.xlsx.\n\n```txt\nD:\\outputs\\chat\\report.xlsx\n```')
    const rendered = document.createElement('div')
    rendered.innerHTML = html

    expect(rendered.querySelector('.chat-file-link')?.getAttribute('href')).toBe('file:///D:/outputs/chat/report.xlsx')
    expect(rendered.querySelector('pre code')?.textContent).toBe('D:\\outputs\\chat\\report.xlsx')
    expect(rendered.querySelector('pre .chat-file-link')).toBeNull()
  })

  it('escapes assistant HTML and rejects unsafe link schemes', () => {
    const html = renderChatContent('<img src=x onerror=alert(1)> [open](javascript:alert(1))')
    const rendered = document.createElement('div')
    rendered.innerHTML = html

    expect(rendered.querySelector('img')).toBeNull()
    expect(rendered.querySelector('[onerror]')).toBeNull()
    expect(rendered.querySelector('a')).toBeNull()
    expect(rendered.textContent).toContain('<img src=x onerror=alert(1)>')
    expect(rendered.textContent).toContain('[open](javascript:alert(1))')
  })

  it('keeps document links inside normal external URLs as web links', () => {
    const html = renderChatContent('Reference: https://docs.example.com/manual.md')
    const rendered = document.createElement('div')
    rendered.innerHTML = html

    expect(rendered.querySelector('a')?.getAttribute('href')).toBe('https://docs.example.com/manual.md')
    expect(rendered.querySelector('.chat-file-link')).toBeNull()
  })

  it('keeps bare signed API URLs as HTTP links with the entire query', () => {
    const url = '/api/v1/chat/artifacts/u/s/id/report.md?expires=123&signature=a%2Bb'
    const rendered = document.createElement('div')
    rendered.innerHTML = renderChatContent(`Open ${url}`)
    expect(rendered.querySelector('a')?.getAttribute('href')).toBe(url)
    expect(rendered.querySelector('.chat-file-link')).toBeNull()
  })

  it('retains generated Agent links without treating them as local paths', () => {
    const url = '/api/v1/agent-generator/agents/writer/outputs/output-id'
    const rendered = document.createElement('div')
    rendered.innerHTML = renderChatContent(`[result.xlsx](${url})`)
    expect(rendered.querySelector('a')?.getAttribute('href')).toBe(url)
    expect(rendered.querySelector('.chat-file-link')).toBeNull()
  })
})
