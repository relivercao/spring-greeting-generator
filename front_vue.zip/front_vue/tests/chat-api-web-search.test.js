import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { apiSendMessage } from '../src/api/auth.js'
import { http } from '../src/api/http.js'

vi.mock('../src/api/http.js', () => ({ http: { post: vi.fn(), upload: vi.fn() } }))

const key = 'macode.chat.web-search-enabled.v1'
beforeEach(() => {
  localStorage.removeItem(key)
  vi.clearAllMocks()
})
afterEach(() => localStorage.removeItem(key))

it('enables public search by default for Chat API calls', () => {
  apiSendMessage('chat', 'Explain DMA', 'session-1')
  expect(http.post).toHaveBeenCalledWith('/v1/chat', {
    agent: 'chat', message: 'Explain DMA', session_id: 'session-1', web_search_enabled: true,
  })
})

it('honors the saved preference in chat surfaces without an explicit flag', () => {
  localStorage.setItem(key, 'false')
  apiSendMessage('chat', 'Explain DMA', 'session-1')
  expect(http.post.mock.calls[0][1].web_search_enabled).toBe(false)

  apiSendMessage('chat', 'Explain DMA', 'session-1', true)
  expect(http.post.mock.calls[1][1].web_search_enabled).toBe(true)
})

it('sends selected attachments as multipart data without setting its content type', async () => {
  const file = new File(['int main(void) {}'], 'main.c', { type: 'text/plain' })
  apiSendMessage('chat', 'Explain this source', 'session-2', true, [file])

  const [path, formData] = http.upload.mock.calls[0]
  expect(path).toBe('/v1/chat/with-files')
  expect(formData.get('agent')).toBe('chat')
  expect(formData.get('message')).toBe('Explain this source')
  expect(formData.get('session_id')).toBe('session-2')
  const attachedFile = formData.get('files')
  expect(attachedFile).toMatchObject({ name: 'main.c', size: file.size })
  const contents = new Promise((resolve) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.readAsText(attachedFile)
  })
  expect(await contents).toBe('int main(void) {}')
})
