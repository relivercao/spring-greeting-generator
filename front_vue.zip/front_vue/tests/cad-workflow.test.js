import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../src/stores/auth.js'
import CadWorkspace from '../src/components/CadWorkspace.vue'
import * as cadApi from '../src/api/cad.js'

vi.mock('../src/api/cad.js', () => ({
  getCadStatus: vi.fn(),
  getCadTasks: vi.fn(),
  getCadTask: vi.fn(),
  createCadTask: vi.fn(),
  fetchCadArtifact: vi.fn(),
  cancelCadTask: vi.fn(),
  repairCadModelScript: vi.fn(),
  startCadBuild: vi.fn(),
}))

const wrappers = []
const buttonStub = {
  props: ['disabled', 'loading'],
  template: '<button :disabled="disabled || loading"><slot /></button>',
}

function mountWorkspace() {
  const wrapper = shallowMount(CadWorkspace, {
    global: {
      stubs: { ElButton: buttonStub, ElTooltip: { template: '<div><slot /></div>' } },
      config: { warnHandler: () => {} },
    },
  })
  wrappers.push(wrapper)
  return wrapper
}

function completedTask(taskId = 'built-model') {
  return {
    task_id: taskId,
    status: 'completed',
    message: 'CAD model and review artifacts generated',
    input: { prompt: 'Create a box', output_format: 'step' },
    result: {
      phase: 'completed',
      model_file: 'model.py',
      artifacts: [
        { type: 'model_source', filename: 'model.py' },
        { type: 'step', filename: 'STEP/model.step' },
        { type: 'preview', filename: 'preview.png' },
      ],
    },
  }
}

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  useAuthStore().enterGuest()
  vi.useFakeTimers()
  vi.clearAllMocks()
  cadApi.getCadStatus.mockResolvedValue({ skill_available: true, build_available: true })
  cadApi.getCadTasks.mockResolvedValue({ tasks: [] })
  cadApi.fetchCadArtifact.mockImplementation(async (_id, type) => (
    type === 'model_source' ? { text: async () => 'parametric model source' } : new Blob(['preview'])
  ))
  vi.stubGlobal('URL', {
    createObjectURL: vi.fn(() => 'blob:cad-preview'),
    revokeObjectURL: vi.fn(),
  })
})

afterEach(() => {
  wrappers.splice(0).forEach((wrapper) => wrapper.unmount())
  vi.useRealTimers()
  vi.unstubAllGlobals()
})

describe('CAD single workflow UI', () => {
  it('clears private history and preview when the account changes', async () => {
    cadApi.getCadTasks.mockResolvedValue({ tasks: [completedTask()] })
    const wrapper = mountWorkspace()
    await flushPromises()
    expect(wrapper.find('.cad-preview img').exists()).toBe(true)
    useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'second-user' }))}.signature`
    await flushPromises()
    expect(wrapper.findAll('.cad-task-row')).toHaveLength(0)
    expect(wrapper.find('.cad-preview img').exists()).toBe(false)
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:cad-preview')
    expect(vi.getTimerCount()).toBe(0)
  })

  it('rejects old history after an account switch and return', async () => {
    let resolveHistory
    cadApi.getCadTasks.mockReturnValueOnce(new Promise(resolve => { resolveHistory = resolve }))
    const wrapper = mountWorkspace()
    useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'second-user' }))}.signature`
    useAuthStore().token = ''
    resolveHistory({ tasks: [completedTask()] })
    await flushPromises()
    expect(wrapper.findAll('.cad-task-row')).toHaveLength(0)
    expect(cadApi.fetchCadArtifact).not.toHaveBeenCalled()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('does not start background polling when initial history finishes after navigation', async () => {
    let resolveHistory
    cadApi.getCadTasks.mockReturnValueOnce(new Promise(resolve => { resolveHistory = resolve }))
    const wrapper = mountWorkspace()
    await flushPromises()
    wrapper.unmount()
    resolveHistory({ tasks: [{ task_id: 'pending-model', status: 'running', result: {} }] })
    await flushPromises()
    await vi.advanceTimersByTimeAsync(4000)
    expect(cadApi.getCadTask).not.toHaveBeenCalled()
    expect(cadApi.fetchCadArtifact).not.toHaveBeenCalled()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('does not allocate an orphaned preview URL after navigation', async () => {
    let resolvePreview
    cadApi.getCadTasks.mockResolvedValue({ tasks: [completedTask()] })
    cadApi.fetchCadArtifact.mockImplementation(async (_id, type) => (
      type === 'model_source'
        ? { text: async () => 'model source' }
        : new Promise(resolve => { resolvePreview = resolve })
    ))
    const wrapper = mountWorkspace()
    await flushPromises()
    wrapper.unmount()
    resolvePreview(new Blob(['preview']))
    await flushPromises()
    expect(URL.createObjectURL).not.toHaveBeenCalled()
    expect(vi.getTimerCount()).toBe(0)
  })

  it('does not fetch artifacts for an in-flight poll after navigation', async () => {
    let resolvePoll
    cadApi.getCadTasks.mockResolvedValue({ tasks: [{ task_id: 'pending-model', status: 'running', result: {} }] })
    cadApi.getCadTask.mockReturnValueOnce(new Promise(resolve => { resolvePoll = resolve }))
    const wrapper = mountWorkspace()
    await flushPromises()
    await vi.advanceTimersByTimeAsync(2000)
    wrapper.unmount()
    resolvePoll(completedTask('pending-model'))
    await flushPromises()
    expect(cadApi.fetchCadArtifact).not.toHaveBeenCalled()
  })

  it('automatically shows the final image after one generation request', async () => {
    cadApi.createCadTask.mockResolvedValue({
      task_id: 'new-model',
      status: 'running',
      workflow_state: { current_stage: 'fetch', nodes: [{ node_name: 'init_project_context', status: 'in_progress' }] },
    })
    cadApi.getCadTask.mockResolvedValueOnce({
      task_id: 'new-model',
      status: 'running',
      result: {
        workflow_state: { current_stage: 'build', nodes: [{ node_name: 'build_and_snapshot', status: 'in_progress' }] },
      },
    }).mockResolvedValueOnce(completedTask('new-model'))
    const wrapper = mountWorkspace()
    await flushPromises()
    await wrapper.find('textarea').setValue('Create a box')
    await wrapper.findAll('button').find((button) => button.text() === 'Generate final review').trigger('click')
    await flushPromises()

    expect(cadApi.createCadTask).toHaveBeenCalledTimes(1)
    expect(cadApi.createCadTask).toHaveBeenCalledWith({
      prompt: 'Create a box', output_format: 'step', auto_build: true,
    })
    await vi.advanceTimersByTimeAsync(2000)
    await flushPromises()
    expect(wrapper.find('.pipe-node.active').text()).toContain('Build and Review')
    await vi.advanceTimersByTimeAsync(2000)
    await flushPromises()

    expect(wrapper.find('.cad-preview img').attributes('src')).toBe('blob:cad-preview')
    expect(wrapper.findAll('.artifact-row')).toHaveLength(2)
    expect(wrapper.find('.script-review').attributes('open')).toBeUndefined()
    expect(wrapper.text()).not.toContain('Build and create preview')
    expect(cadApi.startCadBuild).not.toHaveBeenCalled()
  })

  it('does not show a previous task source or preview after switching tasks', async () => {
    let resolveSource
    cadApi.getCadTasks.mockResolvedValue({ tasks: [
      completedTask(),
      { task_id: 'pending-model', status: 'running', result: {}, input: { prompt: 'New plate' } },
    ] })
    cadApi.fetchCadArtifact.mockImplementation(() => new Promise((resolve) => { resolveSource = resolve }))
    const wrapper = mountWorkspace()
    await flushPromises()
    await wrapper.findAll('.cad-task-row')[1].trigger('click')
    resolveSource({ text: async () => 'previous model source' })
    await flushPromises()

    expect(wrapper.find('.cad-preview img').exists()).toBe(false)
    expect(wrapper.find('.script-review').exists()).toBe(false)
    expect(cadApi.fetchCadArtifact).toHaveBeenCalledTimes(1)
  })

  it('shows repair only for a failed build and keeps earlier node history unknown', async () => {
    const task = completedTask()
    task.status = 'failed'
    task.result.phase = 'build_failed'
    cadApi.getCadTasks.mockResolvedValue({ tasks: [task] })
    cadApi.repairCadModelScript.mockResolvedValue({ status: 'running', message: 'Repairing CAD model' })
    const wrapper = mountWorkspace()
    await flushPromises()

    expect(wrapper.findAll('.pipe-node')).toHaveLength(0)
    expect(wrapper.text()).toContain('Workflow node history is unavailable')
    const repairButtons = wrapper.findAll('button').filter((button) => button.text().includes('Repair and regenerate review'))
    expect(repairButtons).toHaveLength(1)
    await repairButtons[0].trigger('click')
    await flushPromises()

    expect(cadApi.repairCadModelScript).toHaveBeenCalledTimes(1)
    expect(cadApi.repairCadModelScript).toHaveBeenCalledWith(task.task_id)
    expect(wrapper.text()).toContain('Cancel')
    expect(wrapper.text()).not.toContain('Repair and regenerate review')
  })

  it('allows repairing a failed coverage review when the source was saved', async () => {
    const task = completedTask('review-rejected')
    task.status = 'failed'
    task.result = {
      ...task.result,
      phase: 'generation_failed',
      coverage_review: { status: 'revise', missing_requirements: ['Apply a perimeter fillet'] },
    }
    cadApi.getCadTasks.mockResolvedValue({ tasks: [task] })
    cadApi.repairCadModelScript.mockResolvedValue({ status: 'running', message: 'Repairing CAD model' })
    const wrapper = mountWorkspace()
    await flushPromises()

    const repairButton = wrapper.findAll('button').find((button) => button.text().includes('Repair and regenerate review'))
    expect(repairButton).toBeTruthy()
    await repairButton.trigger('click')
    await flushPromises()

    expect(cadApi.repairCadModelScript).toHaveBeenCalledWith('review-rejected')
  })
})
