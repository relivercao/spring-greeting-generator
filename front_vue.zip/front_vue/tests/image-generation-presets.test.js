import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import ImageGenerationWorkspace from '../src/components/ImageGenerationWorkspace.vue'
import {
  getImagePresetUpdates,
  imagePromptPresets,
} from '../src/constants/imagePromptPresets.js'

const { imageStore } = vi.hoisted(() => ({
  imageStore: {
    taskHistory: [],
    loading: false,
    loadHistory: vi.fn().mockResolvedValue(),
    refreshTask: vi.fn(),
    upsertTask: vi.fn(),
    removeTask: vi.fn(),
  },
}))

vi.mock('../src/stores/imageGeneration.js', () => ({
  useImageGenerationStore: () => imageStore,
}))
vi.mock('../src/api/knowledgeBase.js', () => ({
  listKnowledgeDocuments: vi.fn().mockResolvedValue({ documents: [] }),
}))
vi.mock('../src/api/imageGeneration.js', () => ({
  cancelImageGenerationTask: vi.fn(),
  createImageGenerationTask: vi.fn(),
  getImageGenerationSettings: vi.fn(),
}))

const wrappers = []

function mountWorkspace() {
  const wrapper = shallowMount(ImageGenerationWorkspace, {
    global: { config: { warnHandler: () => {} } },
  })
  wrappers.push(wrapper)
  return wrapper
}

beforeEach(() => {
  imageStore.taskHistory = []
  vi.clearAllMocks()
})

afterEach(() => {
  wrappers.splice(0).forEach((wrapper) => wrapper.unmount())
})

describe('image-generation prompt templates', () => {
  it('keeps creative examples at their exact supported aspect ratios', () => {
    const creativePresets = imagePromptPresets.filter((preset) => preset.category === 'creative')

    expect(creativePresets.map(({ aspectRatio }) => aspectRatio)).toEqual([
      '9:16', '4:3', '9:16', '16:9',
    ])
    for (const preset of creativePresets) {
      const [width, height] = preset.size.split('x').map(Number)
      const [ratioWidth, ratioHeight] = preset.aspectRatio.split(':').map(Number)
      expect(width * ratioHeight).toBe(height * ratioWidth)
      expect(width % 16).toBe(0)
      expect(height % 16).toBe(0)
      expect(width * height).toBeGreaterThanOrEqual(655_360)
    }
  })

  it('maps a selected template to prompt and generation settings', () => {
    const preset = imagePromptPresets.find((item) => item.id === 'porcelain-catalog')

    expect(getImagePresetUpdates(preset)).toEqual({
      prompt: preset.prompt,
      selectedPresetId: 'porcelain-catalog',
      params: {
        size: '1024x768',
        quality: 'high',
        outputFormat: 'png',
        transparentOutput: false,
      },
    })
    expect(getImagePresetUpdates(null)).toBeNull()
  })

  it('shows creative cards first and preserves the technical template set', async () => {
    const wrapper = mountWorkspace()
    await flushPromises()

    expect(wrapper.findAll('.preset-card')).toHaveLength(4)
    expect(wrapper.text()).toContain('Cosmic anime poster')
    expect(wrapper.findAll('.preset-cover img')).toHaveLength(4)

    await wrapper.find('[role="tab"][aria-selected="false"]').trigger('click')

    expect(wrapper.findAll('.preset-card')).toHaveLength(4)
    expect(wrapper.text()).toContain('Structure diagram')
    expect(wrapper.text()).toContain('Knowledge-base configuration')
  })

  it('applies a visual template and marks its card selected', async () => {
    const wrapper = mountWorkspace()
    await flushPromises()
    await wrapper.find('.preset-card').trigger('click')

    expect(wrapper.find('.prompt-input').element.value).toContain('cinematic vertical anime key visual')
    expect(wrapper.find('.preset-card').attributes('aria-pressed')).toBe('true')
  })
})
