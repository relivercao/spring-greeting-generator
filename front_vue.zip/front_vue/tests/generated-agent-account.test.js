import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { useAuthStore } from '../src/stores/auth.js'
import { useWorkspaceStore } from '../src/stores/workspace.js'
import GeneratedAgentWorkspace from '../src/components/GeneratedAgentWorkspace.vue'
import * as api from '../src/api/agentGenerator.js'

vi.mock('../src/api/agentGenerator.js', () => ({
  approveGeneratedAgentTask: vi.fn(), chatWithGeneratedAgent: vi.fn(),
  deleteGeneratedAgent: vi.fn(), getGeneratedAgentTask: vi.fn(),
}))
const agent = {
  id: 'generated-fixture', name: 'Fixture', knowledge_document_ids: [],
  knowledge_documents: [], capabilities: [], flow_nodes: [], input_definitions: [],
}
const token = (sub, version = 1) => `header.${btoa(JSON.stringify({ sub, version }))}.signature`
let wrapper
let auth

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  auth = useAuthStore()
  auth.token = token('first-user')
  vi.clearAllMocks()
})
afterEach(() => wrapper?.unmount())

function mount() {
  wrapper = shallowMount(GeneratedAgentWorkspace, {
    props: { agent }, global: { config: { warnHandler: () => {} } },
  })
}
async function send(message) {
  await wrapper.find('.composer textarea').setValue(message)
  await wrapper.find('.composer button').trigger('click')
  await flushPromises()
}

it('clears account conversations and restores only the owner after switching back', async () => {
  api.chatWithGeneratedAgent.mockResolvedValue({ task_id: 'first-task' })
  api.getGeneratedAgentTask.mockResolvedValue({ status: 'completed', response: 'Private first result' })
  mount()
  await send('Private first request')
  expect(wrapper.text()).toContain('Private first result')
  auth.token = token('second-user')
  await flushPromises()
  expect(wrapper.text()).not.toContain('Private first')
  auth.token = token('first-user', 2)
  await flushPromises()
  expect(wrapper.text()).toContain('Private first result')
  auth.logout()
  await flushPromises()
  expect(wrapper.text()).not.toContain('Private first')
})

it('ignores delayed poll results after an account switch', async () => {
  let finish
  api.chatWithGeneratedAgent.mockResolvedValue({ task_id: 'first-task' })
  api.getGeneratedAgentTask.mockReturnValue(new Promise(resolve => { finish = resolve }))
  mount()
  await send('Old account request')
  auth.token = token('second-user')
  await flushPromises()
  finish({ status: 'awaiting_approval', response: 'Private old result', approval: { status: 'pending', token: 'private-token', draft_response: 'Private old draft' } })
  await flushPromises()
  expect(wrapper.text()).not.toContain('Old account request')
  expect(wrapper.text()).not.toContain('Private old')
  expect(wrapper.find('.approval-card').exists()).toBe(false)
})

it('keeps pending task creation in its original account and preserves token refresh continuity', async () => {
  let accept
  api.chatWithGeneratedAgent.mockReturnValue(new Promise(resolve => { accept = resolve }))
  mount()
  await send('Pending first request')
  auth.token = token('first-user', 2)
  auth.user = { id: 'first-user', name: 'Profile loaded' }
  await flushPromises()
  expect(wrapper.text()).toContain('Pending first request')
  auth.token = token('second-user')
  await flushPromises()
  accept({ task_id: 'late-first-task' })
  await flushPromises()
  expect(wrapper.text()).not.toContain('Pending first request')
  expect(api.getGeneratedAgentTask).not.toHaveBeenCalled()
  const saved = useWorkspaceStore().getState('generated:user:first-user:generated-fixture')
  expect(saved.taskId).toBe('late-first-task')
  expect(useWorkspaceStore().getState('generated:user:second-user:generated-fixture')?.taskId).not.toBe('late-first-task')
})
