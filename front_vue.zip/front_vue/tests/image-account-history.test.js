import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../src/stores/auth.js'
import { useImageGenerationStore } from '../src/stores/imageGeneration.js'
import * as imageApi from '../src/api/imageGeneration.js'

vi.mock('../src/api/imageGeneration.js', () => ({
  getImageGenerationTasks: vi.fn(),
  getImageGenerationTask: vi.fn(),
  deleteImageGenerationTask: vi.fn(),
}))

const token = (subject) => `header.${btoa(JSON.stringify({ sub: subject }))}.signature`
const task = (id) => ({ task_id: id, status: 'completed', input: { prompt: id } })
function deferred() {
  let resolve
  const promise = new Promise((done) => { resolve = done })
  return { promise, resolve }
}

beforeEach(() => {
  vi.clearAllMocks()
  localStorage.clear()
  setActivePinia(createPinia())
})

describe('Image history account boundaries', () => {
  it('clears cached images synchronously on logout', () => {
    const auth = useAuthStore()
    auth.token = token('owner')
    const images = useImageGenerationStore()
    images.upsertTask(task('private-image'))
    auth.logout()
    expect(images.taskHistory).toEqual([])
  })

  it('keeps the same account history during token refresh', () => {
    const auth = useAuthStore()
    auth.token = token('owner')
    const images = useImageGenerationStore()
    images.upsertTask(task('owner-image'))
    auth.token = `header.${btoa(JSON.stringify({ sub: 'owner', exp: 2 }))}.signature`
    expect(images.taskHistory.map(item => item.id)).toEqual(['owner-image'])
  })

  it('discards an old account history response without changing the new load state', async () => {
    const auth = useAuthStore()
    auth.token = token('first')
    const images = useImageGenerationStore()
    const first = deferred()
    const second = deferred()
    imageApi.getImageGenerationTasks.mockReturnValueOnce(first.promise).mockReturnValueOnce(second.promise)
    const oldLoad = images.loadHistory()
    auth.token = token('second')
    const newLoad = images.loadHistory()
    first.resolve({ tasks: [task('private-first')] })
    await oldLoad
    expect(images.taskHistory).toEqual([])
    expect(images.loading).toBe(true)
    second.resolve({ tasks: [task('private-second')] })
    await newLoad
    expect(images.taskHistory.map(item => item.id)).toEqual(['private-second'])
    expect(images.loading).toBe(false)
  })

  it('rejects stale refresh and creation results even after signing back into the same account', async () => {
    const auth = useAuthStore()
    auth.token = token('first')
    const images = useImageGenerationStore()
    const revision = images.accountRevision
    const pending = deferred()
    imageApi.getImageGenerationTask.mockReturnValue(pending.promise)
    const refresh = images.refreshTask('old-task')
    auth.logout()
    auth.token = token('first')
    pending.resolve(task('old-task'))
    expect(await refresh).toBeNull()
    expect(images.upsertTask(task('old-create'), revision)).toBeNull()
    expect(images.taskHistory).toEqual([])
  })
})
