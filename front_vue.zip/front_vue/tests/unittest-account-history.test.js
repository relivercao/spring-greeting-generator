import { beforeEach, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { nextTick } from 'vue'
import { useAuthStore } from '../src/stores/auth.js'
import { useUnittestStore } from '../src/stores/unittest.js'
import { useBatchTestStore } from '../src/stores/batchTest.js'

const token = sub => `header.${btoa(JSON.stringify({ sub }))}.signature`
beforeEach(() => { localStorage.clear(); setActivePinia(createPinia()) })

it('isolates single and batch results and dismissed cards across accounts', async () => {
  const auth = useAuthStore()
  auth.token = token('first-user')
  const single = useUnittestStore()
  const batch = useBatchTestStore()
  single.addTask({ id: 'single-a', title: 'Private source', result: { code: 'Private output' } })
  batch.addTask({ id: 'batch-a', batchTaskId: 'server-a' })
  batch.deleteTask('batch-a')
  batch.addTask({ id: 'batch-b', batchTaskId: 'server-b' })
  auth.token = token('second-user')
  expect(single.taskHistory).toEqual([])
  expect(batch.taskHistory).toEqual([])
  expect(batch.isDismissed('server-a')).toBe(false)
  await nextTick()
  auth.token = token('first-user')
  expect(single.getTask('single-a').result.code).toBe('Private output')
  expect(batch.getTask('batch-b').batchTaskId).toBe('server-b')
  expect(batch.isDismissed('server-a')).toBe(true)
  auth.logout()
  expect(single.taskHistory).toEqual([])
  expect(batch.taskHistory).toEqual([])
})

it('preserves unknown legacy task history without assigning it to a signed-in user', () => {
  const legacy = JSON.stringify([{ id: 'private-legacy' }])
  localStorage.setItem('agent_unittest_history', legacy)
  localStorage.setItem('agent_batch_test_history', legacy)
  useAuthStore().token = token('first-user')
  expect(useUnittestStore().taskHistory).toEqual([])
  expect(useBatchTestStore().taskHistory).toEqual([])
  expect(localStorage.getItem('agent_unittest_history')).toBe(legacy)
  expect(localStorage.getItem('agent_batch_test_history')).toBe(legacy)
})
