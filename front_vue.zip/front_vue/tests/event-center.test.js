import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { reactive } from 'vue'
import EventCenterView from '../src/views/EventCenterView.vue'
import EventRoutingRules from '../src/components/EventRoutingRules.vue'
import EventWebhookSources from '../src/components/EventWebhookSources.vue'
import * as api from '../src/api/events.js'

const state = vi.hoisted(() => ({ auth: null }))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('../src/api/events.js', () => ({
  getEventCatalog: vi.fn(),
  getEventRouting: vi.fn(),
  saveEventRouting: vi.fn(),
  previewEvent: vi.fn(),
  listEvents: vi.fn(),
  getEvent: vi.fn(),
  listEventSources: vi.fn(),
  createEventSource: vi.fn(),
  setEventSourceEnabled: vi.fn(),
  rotateEventSource: vi.fn(),
  deleteEventSource: vi.fn(),
}))
vi.mock('element-plus', () => ({ ElMessageBox: { confirm: vi.fn().mockResolvedValue(true) } }))
const saved = { enabled: false, fallback_agent: null, revision: 0, rules: [] }
const agents = [
  { id: 'chat', name: 'Chat Agent', event_execution: 'direct', requirements: 'Text supported.' },
  {
    id: 'build',
    name: 'Build Agent',
    event_execution: 'workspace',
    requirements: 'Provide project and toolchain.',
  },
]
let wrapper
function mountPage() {
  wrapper = mount(EventCenterView, {
    global: { stubs: { RouterLink: { template: '<a><slot /></a>' } } },
  })
  return wrapper
}
const button = text => wrapper.findAll('button').find(item => item.text() === text)

beforeEach(() => {
  vi.clearAllMocks()
  state.auth = reactive({ user: { id: 'user-a' } })
  api.getEventRouting.mockResolvedValue(structuredClone(saved))
  api.getEventCatalog.mockResolvedValue({ agents })
  api.listEvents.mockResolvedValue({ items: [] })
  api.listEventSources.mockResolvedValue({ items: [] })
  api.saveEventRouting.mockImplementation(async policy => ({ ...policy, revision: 1 }))
  api.previewEvent.mockResolvedValue({
    agent: 'build',
    reason: 'Matched first rule.',
    rule_name: 'CI',
    rule_id: 'ci',
    requirements: ['Provide project and toolchain.'],
  })
})
afterEach(() => {
  wrapper?.unmount()
  wrapper = null
  vi.useRealTimers()
  vi.unstubAllGlobals()
})

it('adds rules on HTTP deployments without the secure-context randomUUID API', async () => {
  vi.stubGlobal('crypto', {
    getRandomValues: bytes => {
      bytes.fill(7)
      return bytes
    },
  })
  wrapper = mount(EventRoutingRules, { props: { modelValue: structuredClone(saved), agents } })
  await button('Add rule').trigger('click')
  expect(wrapper.emitted('update:modelValue')[0][0].rules[0].id).toMatch(/^rule_[0-9a-f]{32}$/)
})

it('loads disabled defaults and previews editor changes without executing', async () => {
  mountPage()
  await flushPromises()
  expect(wrapper.find('[data-testid="save-routing"]').attributes('disabled')).toBeDefined()
  await button('Add rule').trigger('click')
  await wrapper.find('[aria-label="Rule Agent"]').setValue('build')
  await wrapper.find('[aria-label="Preview event text"]').setValue('Analyze CI failure')
  await button('Preview route').trigger('submit')
  await flushPromises()
  expect(api.previewEvent).toHaveBeenCalledTimes(1)
  expect(api.previewEvent.mock.calls[0][0].policy.rules[0].agent).toBe('build')
  expect(wrapper.text()).toContain('Provide project and toolchain.')
  expect(api.saveEventRouting).not.toHaveBeenCalled()
})

it('saves explicit routing changes and displays revision conflicts without losing edits', async () => {
  mountPage()
  await flushPromises()
  await wrapper.find('input[type="checkbox"]').setValue(true)
  await wrapper.find('form').trigger('submit')
  await flushPromises()
  expect(api.saveEventRouting.mock.calls[0][0].enabled).toBe(true)
  expect(wrapper.text()).toContain('Saved policy revision 1')
  await button('Add rule').trigger('click')
  api.saveEventRouting.mockRejectedValue(
    new Error('Routing policy changed. Refresh before saving.')
  )
  await wrapper.find('form').trigger('submit')
  await flushPromises()
  expect(wrapper.text()).toContain('Refresh before saving.')
  expect(wrapper.findAll('[data-testid="routing-rule"]')).toHaveLength(1)
})

it('preserves explicit rule order and shows workspace requirements', async () => {
  wrapper = mount(EventRoutingRules, { props: { modelValue: structuredClone(saved), agents } })
  await button('Add rule').trigger('click')
  const first = wrapper.emitted('update:modelValue')[0][0]
  await wrapper.setProps({ modelValue: first })
  await button('Add rule').trigger('click')
  const second = wrapper.emitted('update:modelValue')[1][0]
  await wrapper.setProps({ modelValue: second })
  await wrapper.findAll('[aria-label="Move rule down"]')[0].trigger('click')
  expect(wrapper.emitted('update:modelValue')[2][0].rules[0].id).toBe(second.rules[1].id)
  await wrapper.find('[aria-label="Rule Agent"]').setValue('build')
  expect(wrapper.text()).toContain('Provide project and toolchain.')
})

it('shows detailed results as text and refreshes only while mounted', async () => {
  vi.useFakeTimers()
  api.listEvents.mockResolvedValue({
    items: [
      {
        id: 'e1',
        source: 'api',
        event_type: 'ci.failed',
        created_at: '2026-11-08T12:00:00',
        selected_agent: 'chat',
        status: 'completed',
      },
    ],
  })
  api.getEvent.mockResolvedValue({
    id: 'e1',
    status: 'completed',
    route: { reason: 'Fallback' },
    input: { text: '<script>private()</script>' },
    result: { response: '<img src=x onerror=alert(1)>' },
  })
  mountPage()
  await flushPromises()
  await button('Details').trigger('click')
  await flushPromises()
  expect(wrapper.find('.event-detail').text()).toContain('<img src=x onerror=alert(1)>')
  expect(wrapper.find('.event-detail img').exists()).toBe(false)
  expect(wrapper.find('.event-detail script').exists()).toBe(false)
  wrapper.unmount()
  wrapper = null
  const calls = api.listEvents.mock.calls.length
  await vi.advanceTimersByTimeAsync(10000)
  expect(api.listEvents).toHaveBeenCalledTimes(calls)
})

it('discards results from a previous account and clears private details', async () => {
  let resolveOld
  api.getEventRouting.mockReturnValueOnce(
    new Promise(resolve => {
      resolveOld = resolve
    })
  )
  mountPage()
  await flushPromises()
  state.auth.user.id = 'user-b'
  await flushPromises()
  resolveOld({ ...saved, enabled: true, revision: 99 })
  await flushPromises()
  expect(wrapper.text()).toContain('Saved policy revision 0')
  expect(wrapper.text()).not.toContain('revision 99')
})

it('displays webhook secrets once without writing browser storage', async () => {
  api.createEventSource.mockResolvedValue({ id: 'ci', webhook_secret: 'one-time-private-secret' })
  wrapper = mount(EventWebhookSources, { props: { accountId: 'user-a' } })
  await flushPromises()
  await wrapper.find('[aria-label="Webhook source name"]').setValue('CI')
  await wrapper.find('form').trigger('submit')
  await flushPromises()
  expect(api.createEventSource).toHaveBeenCalledWith('CI')
  expect(wrapper.text()).toContain('one-time-private-secret')
  expect(JSON.stringify(localStorage)).not.toContain('one-time-private-secret')
  await button('Dismiss secret').trigger('click')
  expect(wrapper.text()).not.toContain('one-time-private-secret')
})

it('ignores a one-time secret returned after switching accounts', async () => {
  let finish
  api.createEventSource.mockReturnValueOnce(
    new Promise(resolve => {
      finish = resolve
    })
  )
  wrapper = mount(EventWebhookSources, { props: { accountId: 'user-a' } })
  await flushPromises()
  await wrapper.find('[aria-label="Webhook source name"]').setValue('CI')
  await wrapper.find('form').trigger('submit')
  await wrapper.setProps({ accountId: 'user-b' })
  await flushPromises()
  finish({ webhook_secret: 'old-account-secret' })
  await flushPromises()
  expect(wrapper.text()).not.toContain('old-account-secret')
})
