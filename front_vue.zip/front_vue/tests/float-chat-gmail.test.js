import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { reactive } from 'vue'
import FloatChat from '../src/components/FloatChat.vue'
import ChatGeneratedFiles from '../src/components/ChatGeneratedFiles.vue'
import { apiSendMessage } from '../src/api/auth.js'
import { composeGmailRequest } from '../src/utils/assistantEvents.js'

const state = vi.hoisted(() => ({ auth: null }))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('../src/api/auth.js', () => ({ apiSendMessage: vi.fn() }))
const inputStub = {
  props: ['modelValue'],
  emits: ['update:modelValue'],
  template:
    '<textarea :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />',
}
const buttonStub = {
  props: ['disabled'],
  template: '<button :disabled="disabled"><slot /></button>',
}
let wrapper

function mountChat() {
  wrapper = shallowMount(FloatChat, {
    global: {
      config: { warnHandler: () => {} },
      stubs: { ElInput: inputStub, ElButton: buttonStub, ChatGeneratedFiles },
    },
  })
  return wrapper
}

async function send(message) {
  if (!wrapper.find('textarea').exists()) await wrapper.find('.float-button').trigger('click')
  await wrapper.find('textarea').setValue(message)
  await wrapper.find('[aria-label="Send message"]').trigger('click')
  await flushPromises()
}

beforeEach(() => {
  state.auth = reactive({ isLoggedIn: true, user: { id: 'user-a' } })
  vi.clearAllMocks()
  vi.useFakeTimers()
})
afterEach(() => {
  wrapper?.unmount()
  vi.useRealTimers()
  vi.unstubAllGlobals()
})

it('mounts when randomUUID is unavailable on an insecure HTTP origin', () => {
  const cryptoStub = {
    getRandomValues: vi.fn(bytes => {
      bytes.fill(7)
      return bytes
    }),
  }
  vi.stubGlobal('crypto', cryptoStub)

  expect(() => mountChat()).not.toThrow()
  expect(cryptoStub.getRandomValues).toHaveBeenCalledOnce()
})

it('opens a Gmail request from any page and waits for the user to submit it', async () => {
  mountChat()
  composeGmailRequest()
  await flushPromises()
  expect(wrapper.find('textarea').element.value).toContain('Gmail')
  expect(apiSendMessage).not.toHaveBeenCalled()
})

it('keeps the assistant input and launcher inside a small viewport', async () => {
  const originalWidth = window.innerWidth
  const originalHeight = window.innerHeight
  try {
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: 360 })
    Object.defineProperty(window, 'innerHeight', { configurable: true, value: 500 })
    mountChat()
    await wrapper.find('.float-button').trigger('click')
    const position = wrapper.find('.float-chat-container').element.style
    expect(parseFloat(position.left)).toBeLessThanOrEqual(360 - 56 - 8)
    expect(parseFloat(position.top)).toBeLessThanOrEqual(500 - 56 - 8)
  } finally {
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: originalWidth })
    Object.defineProperty(window, 'innerHeight', { configurable: true, value: originalHeight })
  }
})

it('preserves an unfinished user message when opening Gmail', async () => {
  mountChat()
  await wrapper.find('.float-button').trigger('click')
  await wrapper.find('textarea').setValue('Existing draft')
  composeGmailRequest()
  await flushPromises()
  expect(wrapper.find('textarea').element.value).toBe('Existing draft')
})

it('clears private messages on account changes and ignores a late response', async () => {
  let resolvePrevious
  apiSendMessage.mockReturnValueOnce(
    new Promise(resolve => {
      resolvePrevious = resolve
    })
  )
  mountChat()
  await send('Read my Gmail inbox')
  const previousSession = apiSendMessage.mock.calls[0][2]
  state.auth.user = { id: 'user-b' }
  await flushPromises()
  expect(wrapper.text()).not.toContain('Read my Gmail inbox')
  resolvePrevious({ response: 'Private mail belonging to User A' })
  await flushPromises()
  await vi.advanceTimersByTimeAsync(2000)
  expect(wrapper.text()).not.toContain('Private mail')
  apiSendMessage.mockResolvedValueOnce({ response: 'User B inbox' })
  await send('Read my Gmail inbox')
  expect(apiSendMessage.mock.calls[1][2]).not.toBe(previousSession)
  await vi.advanceTimersByTimeAsync(2000)
  expect(wrapper.text()).toContain('User B inbox')
})

it('cancels rendering of a private response when the user signs out', async () => {
  apiSendMessage.mockResolvedValue({
    response: 'Private mailbox content should never cross accounts',
  })
  mountChat()
  await send('Read Gmail')
  await vi.advanceTimersByTimeAsync(60)
  state.auth.isLoggedIn = false
  await flushPromises()
  await vi.advanceTimersByTimeAsync(3000)
  expect(wrapper.text()).not.toContain('Private mailbox')
  expect(wrapper.text()).not.toContain('Read Gmail')
})

it('displays generated file links immediately and clears them when accounts change', async () => {
  const url = '/api/v1/chat/artifacts/u/s/id/plan.html?expires=123&signature=test'
  apiSendMessage.mockResolvedValueOnce({
    response: `Your document is ready.\n\nGenerated document: [D:/outputs/plan.html](${url})`,
    metadata: { data: { artifacts: [{ filename: 'plan.html', url, size_bytes: 1024 }] } },
  })
  mountChat()
  await send('Create a plan.html')
  expect(wrapper.find('.file-name').text()).toBe('plan.html')
  expect(wrapper.find('.file-actions a').attributes('href')).toBe(url)
  expect(wrapper.text()).toContain('Your document is ready.')
  expect(wrapper.find('.typing').exists()).toBe(false)
  expect(wrapper.text()).not.toContain('Generated document:')
  state.auth.user = { id: 'user-b' }
  await flushPromises()
  expect(wrapper.find('.generated-files').exists()).toBe(false)
})

it('shows verified Gmail operation status and handles ordinary login errors without AWS login', async () => {
  apiSendMessage.mockResolvedValueOnce({
    response: 'Done',
    metadata: {
      data: { app_operations: [{ app: 'gmail', tool: 'GMAIL_SEND_EMAIL', success: true }] },
    },
  })
  mountChat()
  await send('Send the requested email')
  await vi.advanceTimersByTimeAsync(500)
  expect(wrapper.find('.app-operation').text()).toContain('Completed')
  apiSendMessage.mockRejectedValueOnce({ status: 401, message: 'Please sign in again.' })
  await send('Read Gmail')
  expect(wrapper.text()).toContain('Please sign in again.')
  expect(wrapper.findComponent({ name: 'AWSSSOLoginModal' }).props('visible')).toBe(false)
})
