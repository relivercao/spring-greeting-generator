import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { useAuthStore } from '../src/stores/auth.js'
import { useWorkspaceStore } from '../src/stores/workspace.js'
import UnittestWorkspace from '../src/components/UnittestWorkspace.vue'
import BatchTestWorkspace from '../src/components/BatchTestWorkspace.vue'
import BatchRunProgress from '../src/components/BatchRunProgress.vue'
import { isLocalFileSelectorHost, routeSourceFilePicker } from '../src/utils/localFileSelector.js'
import * as api from '../src/api/unittest.js'

vi.mock('vue-router', () => ({ useRouter: () => ({ push: vi.fn() }) }))
vi.mock('../src/api/unittest.js', () => ({
  apiGenerateTests: vi.fn(), apiPollTask: vi.fn(), apiCancelTask: vi.fn(), apiGetTask: vi.fn(),
  apiCancelBatchTask: vi.fn(), apiCreateBatchTask: vi.fn(), apiPollBatchTask: vi.fn(),
  apiResumeBatchTask: vi.fn(),
}))

const token = sub => `header.${btoa(JSON.stringify({ sub }))}.signature`
const source = { id: 'source-a', name: 'private.c', path: '/fixture/private.c', relativePath: 'private.c' }
const wrappers = []
let auth

function deferred() {
  let resolve
  let reject
  const promise = new Promise((done, fail) => { resolve = done; reject = fail })
  return { promise, resolve, reject }
}

function mount(component, activeTask, listeners = {}) {
  const wrapper = shallowMount(component, {
    props: { activeTask, ...listeners }, global: {
      config: { warnHandler: () => {} }, stubs: { BatchRunProgress: false },
    },
  })
  wrappers.push(wrapper)
  return wrapper
}

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  auth = useAuthStore()
  auth.token = token('first-user')
  vi.resetAllMocks()
  api.apiGetTask.mockReturnValue(new Promise(() => {}))
  api.apiPollTask.mockReturnValue(vi.fn())
  api.apiPollBatchTask.mockReturnValue(vi.fn())
})

afterEach(() => {
  wrappers.splice(0).forEach(wrapper => wrapper.unmount())
  vi.unstubAllGlobals()
})

it('restores only the current owner workspace and ignores a late recovery result', async () => {
  const recovery = deferred()
  api.apiGetTask.mockReturnValue(recovery.promise)
  const workspace = useWorkspaceStore()
  workspace.saveState('unittest:user:first-user:2', {
    taskId: 'old-task', phase: 'running', selectedFileSnapshot: source,
  })
  const old = mount(UnittestWorkspace)
  await flushPromises()
  expect(old.text()).toContain('private.c')
  auth.token = token('second-user')
  old.unmount()
  const current = mount(UnittestWorkspace)
  recovery.resolve({ status: 'running', progress: 35, message: 'Private old progress' })
  await flushPromises()
  expect(current.text()).not.toContain('private.c')
  expect(current.text()).not.toContain('Private old progress')
  expect(api.apiPollTask).not.toHaveBeenCalled()
  expect(workspace.getState('unittest:user:second-user:2')).toBeNull()
  expect(workspace.getState('unittest:user:first-user:2').taskId).toBe('old-task')
})

it('does not revive an old unit poll after leaving and returning to the same account', async () => {
  const wrapper = mount(UnittestWorkspace, { id: 'old-task', status: 'running' })
  const poll = api.apiPollTask.mock.calls[0][1]
  auth.logout()
  auth.token = token('first-user')
  poll({ status: 'running', progress: 40, message: 'Obsolete progress' })
  await flushPromises()
  expect(wrapper.text()).not.toContain('Obsolete progress')
  expect(wrapper.emitted('task-updated')).toBeUndefined()
})

it('keeps the last known progress while a temporary status request is retried', async () => {
  const wrapper = mount(UnittestWorkspace, { id: 'active-task', status: 'running' })
  const poll = api.apiPollTask.mock.calls[0][1]
  poll({ status: 'running', progress: 80, message: 'Writing generated files' })
  await flushPromises()
  poll({ status: 'connection_retrying', message: 'Unable to read task progress. Retrying.' })
  await flushPromises()
  expect(wrapper.vm.$.setupState.phase).toBe('running')
  expect(wrapper.vm.$.setupState.progress).toBe(80)
  expect(wrapper.text()).toContain('Unable to read task progress. Retrying.')
  expect(wrapper.text()).not.toContain('Generation Failed')
})

it('recovers a locally failed task when the server returns its completed result', async () => {
  api.apiGetTask.mockResolvedValue({
    task_id: 'completed-task', status: 'completed', progress: 100,
    result: { test_files: [{ filename: 'tc-module.cpp', content: '// Generated fixture' }] },
    message: 'Generated 1 test files',
  })
  const wrapper = mount(UnittestWorkspace, {
    id: 'completed-task', status: 'failed', error: 'Internal server error',
  })
  await flushPromises()
  expect(wrapper.vm.$.setupState.phase).toBe('done')
  expect(wrapper.vm.$.setupState.taskError).toBeNull()
  expect(wrapper.vm.$.setupState.result.test_files[0].filename).toBe('tc-module.cpp')
  expect(wrapper.text()).not.toContain('Generation Failed')
  expect(api.apiGenerateTests).not.toHaveBeenCalled()
})

it('rejects old batch callbacks and resume requests after an account switch', async () => {
  const wrapper = mount(BatchTestWorkspace, {
    id: 'old-batch', batchTaskId: 'server-a', status: 'running', resumeRequired: true,
    selectedFiles: [source],
  })
  await flushPromises()
  const count = wrapper.emitted('task-updated')?.length || 0
  const poll = api.apiPollBatchTask.mock.calls[0][1]
  auth.logout()
  auth.token = token('first-user')
  poll({ batch_task_id: 'server-a', status: 'done', progress: 100, items: [], counts: { pass: 1 } })
  await wrapper.vm.resumeBlockedBatch()
  await flushPromises()
  expect(wrapper.emitted('task-updated')?.length || 0).toBe(count)
  expect(api.apiResumeBatchTask).not.toHaveBeenCalled()
})

it('does not start a batch for another account when local file preparation finishes late', async () => {
  const read = deferred()
  vi.stubGlobal('fetch', vi.fn(() => read.promise))
  const wrapper = mount(BatchTestWorkspace, { id: 'draft', status: 'idle', selectedFiles: [source] })
  await flushPromises()
  await wrapper.find('.run-button').trigger('click')
  expect(fetch).toHaveBeenCalledTimes(1)
  auth.token = token('second-user')
  read.resolve({ ok: true, json: async () => ({ success: true, content: 'int fixture = 1;' }) })
  await flushPromises()
  expect(api.apiCreateBatchTask).not.toHaveBeenCalled()
})

it('ignores accepted batch creation after its workspace is unmounted', async () => {
  const creation = deferred()
  const onTaskUpdated = vi.fn()
  api.apiCreateBatchTask.mockReturnValue(creation.promise)
  const wrapper = mount(BatchTestWorkspace, {
    id: 'draft', status: 'idle', selectedFiles: [{ ...source, file: new File(['int fixture = 1;'], 'private.c') }],
  }, { onTaskUpdated })
  await flushPromises()
  await wrapper.find('.run-button').trigger('click')
  await flushPromises()
  expect(api.apiCreateBatchTask).toHaveBeenCalledTimes(1)
  const count = onTaskUpdated.mock.calls.length
  wrapper.unmount()
  creation.resolve({ batch_task_id: 'late-batch', status: 'queued', items: [] })
  await flushPromises()
  expect(onTaskUpdated).toHaveBeenCalledTimes(count)
  expect(api.apiPollBatchTask).not.toHaveBeenCalled()
})

it('continues a batch on same-account token refresh and updates the visible task', async () => {
  const wrapper = mount(BatchTestWorkspace, {
    id: 'batch-a', batchTaskId: 'server-a', status: 'running', selectedFiles: [source],
  })
  const poll = api.apiPollBatchTask.mock.calls[0][1]
  auth.token = `header.${btoa(JSON.stringify({ sub: 'first-user', version: 2 }))}.signature`
  poll({ batch_task_id: 'server-a', status: 'done', progress: 100, items: [], counts: { pass: 1 } })
  await flushPromises()
  expect(wrapper.emitted('task-updated').some(([event]) => event.status === 'completed')).toBe(true)
})

it('uses the local path selector only for a local application host', () => {
  expect(isLocalFileSelectorHost('localhost')).toBe(true)
  expect(isLocalFileSelectorHost('127.0.0.1')).toBe(true)
  expect(isLocalFileSelectorHost('[::1]')).toBe(true)
  expect(isLocalFileSelectorHost('111.230.91.68')).toBe(false)
  expect(isLocalFileSelectorHost('app.example.com')).toBe(false)
})

it('opens the browser source picker synchronously on a public host', async () => {
  const events = []
  const result = routeSourceFilePicker(
    'app.example.com',
    () => { events.push('local') },
    () => { events.push('browser') },
  )

  expect(events).toEqual(['browser'])
  expect(result).toBeUndefined()
})

it('keeps the upload fallback available when the local path service is unavailable', async () => {
  const click = vi.spyOn(HTMLInputElement.prototype, 'click').mockImplementation(() => {})
  const fetchMock = vi.fn().mockRejectedValue(new Error('selector unavailable'))
  vi.stubGlobal('fetch', fetchMock)
  const wrapper = mount(UnittestWorkspace)

  await wrapper.find('.file-select-actions .folder-select-btn').trigger('click')
  await flushPromises()

  expect(fetchMock).toHaveBeenCalledWith('http://127.0.0.1:9999/select-file', { method: 'POST' })
  expect(click).not.toHaveBeenCalled()
  expect(wrapper.find('.file-select-actions .secondary').exists()).toBe(true)
  click.mockRestore()
})

it('enables generation for an uploaded file when no project path is saved', async () => {
  api.apiGenerateTests.mockResolvedValue({ task_id: 'uploaded-source-task' })
  const wrapper = mount(UnittestWorkspace)
  const input = wrapper.find('input[type="file"]')
  const file = new File(['int fixture(void) { return 0; }'], 'fixture.c', { type: 'text/plain' })
  Object.defineProperty(input.element, 'files', { configurable: true, value: [file] })
  await input.trigger('change')

  const generateButton = wrapper.find('.run-btn')
  expect(generateButton.element.disabled).toBe(false)
  await generateButton.trigger('click')
  await flushPromises()

  expect(api.apiGenerateTests).toHaveBeenCalledWith(file, expect.objectContaining({ output_dir: '' }))
})

it('submits browser batch uploads without requiring absolute project paths', async () => {
  api.apiCreateBatchTask.mockResolvedValue({ batch_task_id: 'uploaded-batch', status: 'queued', items: [] })
  const fetchMock = vi.fn()
  vi.stubGlobal('fetch', fetchMock)
  const wrapper = mount(BatchTestWorkspace, { id: 'upload-draft', status: 'idle', selectedFiles: [] })
  const input = wrapper.find('input[type="file"][accept]')
  const files = [new File(['int first(void) { return 1; }'], 'first.c'), new File(['int second() { return 2; }'], 'second.cpp')]
  Object.defineProperty(input.element, 'files', { configurable: true, value: files })
  await input.trigger('change')
  await wrapper.find('.run-button').trigger('click')
  await flushPromises()

  expect(api.apiCreateBatchTask).toHaveBeenCalledWith(
    [{ file: files[0], name: 'first.c' }, { file: files[1], name: 'second.cpp' }],
    { source_paths: ['first.c', 'second.cpp'], source_mode: 'upload' },
  )
  expect(fetchMock).not.toHaveBeenCalled()
  expect(api.apiPollBatchTask).toHaveBeenCalledWith('uploaded-batch', expect.any(Function))
})

it('keeps an unaccepted batch upload editable after a request failure', async () => {
  api.apiCreateBatchTask.mockRejectedValue(new Error('Upload temporarily unavailable'))
  const wrapper = mount(BatchTestWorkspace, {
    id: 'upload-draft', status: 'idle', selectedFiles: [{ ...source, file: new File(['int fixture;'], 'private.c') }],
  })
  await flushPromises()
  await wrapper.find('.run-button').trigger('click')
  await flushPromises()
  expect(api.apiCreateBatchTask).toHaveBeenCalledTimes(1)
  expect(wrapper.emitted('task-updated').some(([event]) => event.status === 'idle' && event.error === 'Upload temporarily unavailable')).toBe(true)
  expect(wrapper.find('[role="alert"]').text()).toContain('Upload temporarily unavailable')
})

it('excludes empty browser sources while submitting the remaining files in order', async () => {
  api.apiCreateBatchTask.mockResolvedValue({ batch_task_id: 'nonempty-batch', status: 'queued', items: [] })
  const wrapper = mount(BatchTestWorkspace, { id: 'mixed-draft', status: 'idle', selectedFiles: [] })
  const input = wrapper.find('input[type="file"][accept]')
  const first = new File(['int first;'], 'first.c')
  const empty = new File([], 'placeholder.c')
  const last = new File(['int last;'], 'last.cpp')
  Object.defineProperty(input.element, 'files', { configurable: true, value: [first, empty, last] })
  await input.trigger('change')
  await flushPromises()

  const emptyRow = wrapper.findAll('.batch-file-row')[1]
  expect(emptyRow.text()).toContain('Empty file')
  expect(emptyRow.find('.selection-mark').element.disabled).toBe(true)
  expect(wrapper.find('.empty-files-hint').text()).toContain('placeholder.c')
  await wrapper.find('.select-toggle-button').trigger('click')
  await wrapper.find('.select-toggle-button').trigger('click')
  await wrapper.find('.run-button').trigger('click')
  await flushPromises()

  expect(api.apiCreateBatchTask).toHaveBeenCalledWith(
    [{ file: first, name: 'first.c' }, { file: last, name: 'last.cpp' }],
    { source_paths: ['first.c', 'last.cpp'], source_mode: 'upload' },
  )
})

it('keeps an all-empty batch disabled with a persistent explanation', async () => {
  const wrapper = mount(BatchTestWorkspace, { id: 'empty-draft', status: 'idle', selectedFiles: [] })
  const input = wrapper.find('input[type="file"][accept]')
  Object.defineProperty(input.element, 'files', { configurable: true, value: [new File([], 'empty.c')] })
  await input.trigger('change')
  await flushPromises()

  expect(wrapper.find('.run-button').element.disabled).toBe(true)
  expect(wrapper.find('.empty-files-hint').text()).toContain('empty.c')
  expect(api.apiCreateBatchTask).not.toHaveBeenCalled()
})

it('does not reselect an empty file when restoring a rejected batch draft', async () => {
  api.apiCreateBatchTask.mockResolvedValue({ batch_task_id: 'restored-batch', status: 'queued', items: [] })
  const valid = new File(['int value;'], 'private.c')
  const wrapper = mount(BatchTestWorkspace, {
    id: 'restored-draft', status: 'idle', selectedFiles: [
      { ...source, path: 'private.c', file: valid },
      { id: 'empty.c', name: 'empty.c', relativePath: 'empty.c', file: new File([], 'empty.c') },
    ],
  })
  await flushPromises()
  await wrapper.find('.run-button').trigger('click')
  await flushPromises()

  expect(api.apiCreateBatchTask).toHaveBeenCalledWith(
    [{ file: valid, name: 'private.c' }],
    { source_paths: ['private.c'], source_mode: 'upload' },
  )
})

it('updates the right panel with each batch progress response while running', async () => {
  const wrapper = mount(BatchTestWorkspace, {
    id: 'live-batch', batchTaskId: 'live-server', status: 'running', selectedFiles: [source],
  })
  const poll = api.apiPollBatchTask.mock.calls[0][1]
  const item = {
    item_id: 'live-item', sequence: 0, filename: 'private.c', relative_path: 'private.c',
    status: 'running', progress: 33, current_stage: 'generate', message: 'Writing the test fixture',
  }
  poll({ batch_task_id: 'live-server', status: 'running', progress: 33, items: [item] })
  await flushPromises()

  const panel = wrapper.find('.report-column')
  expect(panel.text()).not.toContain('Ready for execution')
  expect(panel.find('.live-run-card').text()).toContain('private.c')
  expect(panel.find('.live-run-card').text()).toContain('Writing the test fixture')
  expect(panel.find('.live-run-card').text()).toContain('Generating tests')
  expect(panel.find('.batch-progress').attributes('aria-valuenow')).toBe('33')

  poll({ batch_task_id: 'live-server', status: 'running', progress: 60,
    items: [{ ...item, progress: 60, current_stage: 'compile', message: 'Compiling generated tests' }],
  })
  await flushPromises()
  expect(panel.find('.live-run-card').text()).toContain('Compiling generated tests')
  expect(panel.find('.live-run-card').text()).not.toContain('Writing the test fixture')
  expect(panel.find('.batch-progress').attributes('aria-valuenow')).toBe('60')
  expect(panel.find('.file-progress').attributes('aria-valuenow')).toBe('60')
})

it('shows the current running file even when a completed file report is selected', async () => {
  api.apiGetTask.mockResolvedValue({ status: 'completed', result: { compile_success: true } })
  const wrapper = mount(BatchTestWorkspace, {
    id: 'two-file-batch', batchTaskId: 'two-file-server', status: 'running', selectedFiles: [
      source, { id: 'next.c', name: 'next.c', relativePath: 'next.c' },
    ],
  })
  const poll = api.apiPollBatchTask.mock.calls[0][1]
  poll({ batch_task_id: 'two-file-server', status: 'running', progress: 66, items: [
    { item_id: 'first', sequence: 0, filename: 'private.c', relative_path: 'private.c', status: 'pass', unittest_task_id: 'first-child' },
    { item_id: 'next', sequence: 1, filename: 'next.c', relative_path: 'next.c', status: 'running', progress: 33,
      current_stage: 'generate', message: 'Reading next.c' },
  ] })
  await flushPromises()

  const panel = wrapper.find('.report-column')
  expect(panel.find('.live-run-card').text()).toContain('next.c')
  expect(panel.find('.live-run-card').text()).toContain('Reading next.c')
  expect(panel.find('.task-report-card h3').text()).toBe('private.c')
  expect(panel.find('.task-report-card').text()).toContain('Generated Files')
})

it('shows queue status before a child starts without claiming generation has begun', async () => {
  const wrapper = mount(BatchTestWorkspace, {
    id: 'queued-batch', batchTaskId: 'queued-server', status: 'queued', selectedFiles: [source],
  })
  const panel = wrapper.find('.report-column')
  expect(panel.find('.live-run-card').text()).toContain('Waiting for an available worker')
  expect(panel.find('.batch-progress').attributes('aria-valuenow')).toBe('0')
  expect(panel.text()).not.toContain('Ready for execution')
})
