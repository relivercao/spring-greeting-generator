import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { reactive } from 'vue'
import AdminModelsView from '../src/views/admin/AdminModelsView.vue'
import UsageView from '../src/views/UsageView.vue'
import { useModelCatalog } from '../src/composables/useModelCatalog.js'
import { usageCsv } from '../src/utils/usageExport.js'
import * as api from '../src/api/modelManagement.js'

const state = vi.hoisted(() => ({ auth: null, route: null }))
vi.mock('../src/api/modelManagement.js', () => ({
  listModels: vi.fn(), getDefaultPricing: vi.fn(), createModel: vi.fn(), updateModel: vi.fn(),
  deleteModel: vi.fn(), importModels: vi.fn(), discoverModels: vi.fn(), updateDefaultPricing: vi.fn(),
  getModelCatalog: vi.fn(), getUsage: vi.fn(), getUsageDetail: vi.fn(),
}))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('vue-router', () => ({ useRoute: () => state.route, useRouter: () => ({ push: vi.fn() }) }))
vi.mock('element-plus', () => ({ ElMessage: { success: vi.fn() }, ElMessageBox: { confirm: vi.fn().mockResolvedValue(true) } }))

const slotStub = { template: '<div><slot name="header" /><slot /></div>' }
const stubs = {
  ElCard: slotStub, ElCollapse: slotStub, ElCollapseItem: slotStub,
  ElForm: { template: '<form @submit.prevent="$emit(\'submit\', $event)"><slot /></form>' },
  ElFormItem: { props: ['label'], template: '<label>{{ label }}<slot /></label>' },
  ElButton: { props: ['disabled', 'loading', 'nativeType'], template: '<button :type="nativeType || \'button\'" :disabled="disabled || loading"><slot /></button>' },
  ElAlert: { props: ['title'], template: '<p role="alert">{{ title }}</p>' },
  ElInput: { props: ['modelValue', 'type'], emits: ['update:modelValue'], template: '<input :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />' },
  ElInputNumber: { props: ['modelValue'], emits: ['update:modelValue'], template: '<input type="number" :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value === \'\' ? null : Number($event.target.value))" />' },
  ElSelect: { props: ['modelValue'], emits: ['update:modelValue'], template: '<select :value="modelValue" @change="$emit(\'update:modelValue\', $event.target.value)"><slot /></select>' },
  ElOption: { props: ['value', 'label'], template: '<option :value="value">{{ label }}</option>' },
  ElSwitch: true, ElCheckbox: true, ElTag: slotStub, ElDatePicker: true,
  ElDialog: { props: ['modelValue'], template: '<section v-if="modelValue" class="dialog"><slot /><slot name="footer" /></section>' },
  ElTable: { props: ['data'], template: '<pre class="table">{{ JSON.stringify(data) }}</pre>' },
  ElTableColumn: true, ElPagination: true,
}
let wrapper
function render(component) {
  wrapper = mount(component, { global: { stubs, directives: { loading: () => {} }, config: { warnHandler: () => {} } } })
  return wrapper
}
function button(text) { return wrapper.findAll('button').find(item => item.text() === text) }
function field(label) {
  const scope = wrapper.find('.dialog').exists() ? wrapper.find('.dialog') : wrapper
  return scope.findAll('label').find(item => item.text() === label).find('input')
}
const report = (model = 'current') => ({ summary: { requests: 1, total_tokens: 12, cost_usd: 0.5, charged_cny: 0 },
  items: [{ model, created_at: '2026-01-01T00:00:00Z' }], groups: [], total: 1 })

beforeEach(() => {
  vi.clearAllMocks()
  state.auth = reactive({ isLoggedIn: true, user: { id: 'alice', name: 'Alice' } })
  state.route = reactive({ meta: { requiresAdmin: false } })
  api.listModels.mockResolvedValue({ items: [] })
  api.getDefaultPricing.mockResolvedValue({ default: { input_usd_per_mtok: 3, output_usd_per_mtok: 15 }, models: {} })
  api.createModel.mockResolvedValue({ id: 'new-model' })
  api.getUsage.mockResolvedValue(report())
})
afterEach(() => { wrapper?.unmount(); wrapper = null })

it('creates an explicit free model and defaults its display name to the model ID', async () => {
  render(AdminModelsView)
  await flushPromises()
  await button('Add Model').trigger('click')
  await field('Model ID').setValue('new-free-model')
  await field('Input USD / 1M').setValue(0)
  await field('Output USD / 1M').setValue(0)
  await button('Save Model').trigger('click')
  await flushPromises()
  expect(api.createModel).toHaveBeenCalledWith(expect.objectContaining({
    provider: 'macode', model: 'new-free-model', display_name: 'new-free-model',
    input_usd_per_mtok: 0, output_usd_per_mtok: 0,
  }))
})

it('keeps the model editor open and exposes validation errors when saving fails', async () => {
  api.createModel.mockRejectedValue(new Error('Set both input and output prices'))
  render(AdminModelsView)
  await flushPromises()
  await button('Add Model').trigger('click')
  await field('Model ID').setValue('model')
  await button('Save Model').trigger('click')
  await flushPromises()
  expect(wrapper.find('.dialog').exists()).toBe(true)
  expect(wrapper.text()).toContain('Set both input and output prices')
})

it('shows personal usage and never sends an admin flag or another user filter', async () => {
  render(UsageView)
  await flushPromises()
  expect(api.getUsage).toHaveBeenCalledWith(expect.objectContaining({ group_by: 'model', page: 1 }), false)
  expect(api.getUsage.mock.calls[0][0]).not.toHaveProperty('user_id')
  expect(wrapper.text()).toContain('My Usage & Costs')
  expect(wrapper.text()).toContain('current')
})

it('filters admin usage by model and user before fetching summaries', async () => {
  state.route.meta.requiresAdmin = true
  render(UsageView)
  await flushPromises()
  await field('Model').setValue('priced-model')
  await field('User ID').setValue('bob')
  await wrapper.find('form').trigger('submit')
  await flushPromises()
  expect(api.getUsage).toHaveBeenLastCalledWith(expect.objectContaining({ model: 'priced-model', user_id: 'bob' }), true)
})

it('discards a previous account response after switching accounts', async () => {
  let completeOld
  api.getUsage.mockImplementationOnce(() => new Promise(resolve => { completeOld = resolve }))
  render(UsageView)
  await flushPromises()
  state.auth.user = { id: 'bob', name: 'Bob' }
  await flushPromises()
  completeOld(report('private-alice-model'))
  await flushPromises()
  expect(wrapper.text()).not.toContain('private-alice-model')
  expect(wrapper.text()).toContain('current')
})

it('clears saved reports immediately on logout', async () => {
  render(UsageView)
  await flushPromises()
  expect(wrapper.text()).toContain('current')
  state.auth.isLoggedIn = false
  await flushPromises()
  expect(wrapper.text()).not.toContain('current')
})

it('shows loading failures and allows refresh to recover', async () => {
  api.getUsage.mockRejectedValueOnce(new Error('Usage service unavailable'))
  render(UsageView)
  await flushPromises()
  expect(wrapper.text()).toContain('Usage service unavailable')
  await button('Refresh').trigger('click')
  await flushPromises()
  expect(wrapper.text()).toContain('current')
  expect(wrapper.text()).not.toContain('Usage service unavailable')
})

it('preserves configured values while adding enabled catalog options for the matching provider', async () => {
  api.getModelCatalog.mockResolvedValue({ items: [
    { provider: 'macode', model: 'new-model', display_name: 'New Model' },
    { provider: 'bedrock', model: 'aws-model', display_name: 'AWS Model' },
  ] })
  const catalog = useModelCatalog()
  await catalog.loadCatalog()
  expect(catalog.options('macode', 'previous-model')).toEqual([
    { value: 'new-model', label: 'New Model' }, { value: 'previous-model', label: 'previous-model' },
  ])
})

it('escapes spreadsheet formula prefixes and quoted model names in CSV', () => {
  const csv = usageCsv([{ model: '=HYPERLINK("untrusted")', provider: 'safe', cost_usd: 0 }])
  expect(csv).toContain('"\'=HYPERLINK(""untrusted"")"')
  expect(csv).toContain('"safe"')
})
