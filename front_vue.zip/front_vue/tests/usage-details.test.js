import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { computed, inject, provide, reactive } from 'vue'
import UsageView from '../src/views/UsageView.vue'
import UsageDetailDrawer from '../src/components/UsageDetailDrawer.vue'
import TransactionListView from '../src/views/TransactionListView.vue'
import * as api from '../src/api/modelManagement.js'
import { apiGetTransactions } from '../src/api/payment.js'

const state = vi.hoisted(() => ({ auth: null, route: null, push: vi.fn() }))
vi.mock('../src/api/modelManagement.js', () => ({ getUsage: vi.fn(), getUsageDetail: vi.fn() }))
vi.mock('../src/api/payment.js', () => ({ apiGetTransactions: vi.fn() }))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('vue-router', () => ({ useRoute: () => state.route, useRouter: () => ({ push: state.push }) }))

const slot = { template: '<div><slot name="header" /><slot /></div>' }
const stubs = {
  ElCard: slot, ElForm: { template: '<form @submit.prevent="$emit(\'submit\')"><slot /></form>' },
  ElFormItem: { props: ['label'], template: '<label>{{ label }}<slot /></label>' },
  ElButton: { props: ['disabled', 'nativeType'], template: '<button :type="nativeType || \'button\'" :disabled="disabled"><slot /></button>' },
  ElInput: { props: ['modelValue'], emits: ['update:modelValue'], template: '<input :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />' },
  ElSelect: { props: ['modelValue'], template: '<select><slot /></select>' },
  ElOption: { props: ['value', 'label'], template: '<option :value="value">{{ label }}</option>' },
  ElAlert: { props: ['title'], template: '<p role="alert">{{ title }}</p>' },
  ElDrawer: { props: ['modelValue', 'title'], emits: ['update:modelValue'], template: '<section v-if="modelValue" class="drawer"><h2>{{ title }}</h2><button @click="$emit(\'update:modelValue\', false)">Close Details</button><slot /></section>' },
  ElTable: { props: ['data'], setup(props) { provide('tableRows', computed(() => props.data)); }, template: '<div><slot /></div>' },
  ElTableColumn: { props: ['prop'], setup() { return { rows: inject('tableRows') }; }, template: '<div><div v-for="(row, index) in rows" :key="index"><slot :row="row">{{ row[prop] }}</slot></div></div>' },
  ElDatePicker: true, ElPagination: true, ElIcon: slot, ArrowLeft: true,
}
const detail = (id = 'usage-a') => ({
  id, user_id: 'alice', model: 'historical-model', agent_name: 'chat', provider: 'macode',
  created_at: '2026-11-07T14:00:00Z', status: 'completed', latency_ms: 1250,
  usage_source: 'reported', pricing_source: 'catalog', workflow_id: 'flow-a', session_id: 'session-a',
  prompt_tokens: 1100, completion_tokens: 300, cache_read_tokens: 200, cache_write_tokens: 100, total_tokens: 1400,
  cost_usd: 0.00489, charged_cny: 0.03,
  token_breakdown: { uncached_input_tokens: 800 },
  cost_breakdown: { available: true, matches_recorded_cost: true, items: [
    { kind: 'uncached_input', tokens: 800, usd_per_mtok: 2, cost_usd: 0.0016 },
    { kind: 'cache_read', tokens: 200, usd_per_mtok: 0.2, cost_usd: 0.00004 },
  ] },
  billing: { status: 'charged', usd_to_cny_rate: 7, discount_percent: 10, charge_before_discount_cny: 0.0342 },
  transactions: [{ id: 'ledger-a', amount: -0.03, balance_after: 99.97 }],
})
let wrapper
function render(component = UsageView, props = {}) {
  wrapper = mount(component, { props, global: { stubs, directives: { loading: () => {} }, config: { warnHandler: () => {} } } })
  return wrapper
}
function button(text) { return wrapper.findAll('button').find(node => node.text() === text) }
beforeEach(() => {
  vi.clearAllMocks()
  state.auth = reactive({ isLoggedIn: true, user: { id: 'alice' } })
  state.route = reactive({ meta: { requiresAdmin: false }, query: {} })
  api.getUsage.mockResolvedValue({ summary: {}, items: [detail()], groups: [], total: 1 })
  api.getUsageDetail.mockResolvedValue(detail())
})
afterEach(() => { wrapper?.unmount(); wrapper = null })

it('opens a request and displays saved token costs, discount and linked ledger details', async () => {
  render()
  await flushPromises()
  await button('Details').trigger('click')
  await flushPromises()
  expect(api.getUsageDetail).toHaveBeenCalledWith('usage-a', false)
  const drawer = wrapper.find('.drawer').text()
  expect(drawer).toContain('historical-model')
  expect(drawer).toContain('Uncached input')
  expect(drawer).toContain('Cache read')
  expect(drawer).toContain('10% off')
  expect(drawer).toContain('ledger-a')
  expect(drawer).toContain('99.9700')
})

it('follows a workflow to all related requests without the old time restriction', async () => {
  render()
  await flushPromises()
  await button('Details').trigger('click')
  await flushPromises()
  await button('View Workflow Requests').trigger('click')
  await flushPromises()
  expect(api.getUsage).toHaveBeenLastCalledWith(expect.objectContaining({ workflow_id: 'flow-a', date_from: undefined, date_to: undefined }), false)
  expect(wrapper.find('.drawer').exists()).toBe(false)
})

it('opens an older record directly from a balance transaction link in admin context', async () => {
  state.route.meta.requiresAdmin = true
  state.route.query.usage_id = 'usage-old'
  render()
  await flushPromises()
  expect(api.getUsageDetail).toHaveBeenCalledWith('usage-old', true)
  expect(wrapper.find('.drawer').text()).toContain('Usage Details')
})

it('offers retry after detail failure and shows unavailable history without fabricating a price', async () => {
  api.getUsageDetail.mockRejectedValueOnce(new Error('Usage record not found'))
  const legacy = { ...detail(), usage_source: 'legacy', pricing_source: 'legacy',
    cost_breakdown: { available: false, items: [] }, billing: { status: 'unknown', discount_percent: null }, transactions: [] }
  api.getUsageDetail.mockResolvedValueOnce(legacy)
  render(UsageDetailDrawer, { modelValue: true, usageId: 'usage-a' })
  await flushPromises()
  expect(wrapper.text()).toContain('Usage record not found')
  await button('Retry').trigger('click')
  await flushPromises()
  expect(wrapper.text()).toContain('Cost breakdown not recorded')
  expect(wrapper.text()).toContain('Not recorded')
  expect(wrapper.text()).not.toContain('10% off')
})

it('ignores an old request when a different record is selected', async () => {
  let resolveOld
  api.getUsageDetail.mockImplementationOnce(() => new Promise(resolve => { resolveOld = resolve }))
  render(UsageDetailDrawer, { modelValue: true, usageId: 'usage-a' })
  await flushPromises()
  await wrapper.setProps({ usageId: 'usage-b' })
  await flushPromises()
  resolveOld({ ...detail(), model: 'private-old-response' })
  await flushPromises()
  expect(wrapper.text()).not.toContain('private-old-response')
  expect(wrapper.text()).toContain('historical-model')
})

it.each(['account', 'logout'])('clears details and discards late responses on %s change', async change => {
  let resolveOld
  api.getUsageDetail.mockImplementationOnce(() => new Promise(resolve => { resolveOld = resolve }))
  render(UsageDetailDrawer, { modelValue: true, usageId: 'usage-a' })
  await flushPromises()
  if (change === 'account') state.auth.user = { id: 'bob' }
  else state.auth.isLoggedIn = false
  await flushPromises()
  resolveOld({ ...detail(), model: 'private-alice-result' })
  await flushPromises()
  expect(wrapper.text()).not.toContain('private-alice-result')
  expect(wrapper.emitted('update:modelValue')).toContainEqual([false])
  expect(api.getUsageDetail).toHaveBeenCalledTimes(1)
})

it('links a usage debit from balance history to the usage details route', async () => {
  apiGetTransactions.mockResolvedValue({ items: [{ type: 'usage', reference_id: 'usage-a', amount: -0.1 }], total: 1 })
  render(TransactionListView)
  await flushPromises()
  await button('View Details').trigger('click')
  expect(state.push).toHaveBeenCalledWith({ path: '/usage', query: { usage_id: 'usage-a' } })
})

it('clears the date restriction when selecting All Time', async () => {
  render()
  await flushPromises()
  await button('All Time').trigger('click')
  await flushPromises()
  expect(api.getUsage).toHaveBeenLastCalledWith(expect.objectContaining({ date_from: undefined, date_to: undefined }), false)
})
