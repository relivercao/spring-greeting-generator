import { expect, it } from 'vitest'
import { BUILT_IN_AGENTS } from '../src/config/agentCatalog.js'
import { agentMascotFor } from '../src/config/agentMascots.js'

it('maps a distinct reference portrait to every backend-registered Agent', () => {
  const portraits = Array.from({ length: 11 }, (_, index) => agentMascotFor({ id: index + 1 }))

  expect(portraits.every(Boolean)).toBe(true)
  expect(new Set(portraits).size).toBe(11)
  expect(BUILT_IN_AGENTS.every(agent => agentMascotFor(agent))).toBe(true)
})
