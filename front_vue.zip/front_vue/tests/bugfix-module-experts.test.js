import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import BugFixExpertReviews from '../src/components/bugfix-workspace/BugFixExpertReviews.vue'
import BugFixResultReport from '../src/components/bugfix-workspace/BugFixResultReport.vue'

vi.mock('element-plus', () => ({ ElMessage: { success: vi.fn(), error: vi.fn() } }))

let wrapper
let blobs
let downloads
const candidateDiff = '--- a/src/battery.c\n+++ b/src/battery.c\n@@ -1 +1 @@\n-return -1;\n+return 0;\n'
const finalDiff = candidateDiff.replace('return 0;', 'return 1;')
const finding = {
  file: 'src/battery.c', line: 12, problem: 'Invalid measurement reaches the caller',
  evidence: 'return -1;', evidence_verified: true, fix_logic: 'Preserve the error contract',
  risk: 'Boundary readings need regression checks',
}
const reviews = () => [{
  skill: 'battery-expert', module: 'battery', status: 'completed', summary: 'Measurement review',
  selection_reasons: ['Module battery matches source src/battery.c'], fix_logic: 'Validate the reading first',
  findings: [{ ...finding }], code_diffs: { 'src/battery.c': candidateDiff },
  verification: ['Exercise invalid readings'], warnings: [],
}, {
  skill: 'storage-expert', module: 'datamanage', status: 'needs_review', summary: 'Storage review',
  findings: [{ ...finding, evidence: 'unverified_write();', evidence_verified: false }],
  code_diffs: { 'src/battery.c': finalDiff }, warnings: ['Source evidence could not be verified'],
}]
const conflicts = [{ file: 'src/battery.c', skills: ['battery-expert', 'storage-expert'], message: 'Final reconciliation required' }]
const result = () => ({
  root_cause: 'Read failure', fix_approach: 'Handle invalid readings', files_analyzed: 1,
  expert_reviews: reviews(), expert_conflicts: conflicts, code_diffs: { 'src/battery.c': finalDiff },
  patches: { 'src/battery.c': 'int level(void) { return 1; }\n' },
})
const mountReport = data => mount(BugFixResultReport, {
  props: { result: data }, global: { stubs: { 'el-icon': true } },
})

beforeEach(() => {
  blobs = []
  downloads = []
  vi.stubGlobal('Blob', class {
    constructor(parts, options) { this.content = parts.join(''); this.type = options.type }
  })
  vi.stubGlobal('URL', {
    createObjectURL: vi.fn(blob => { blobs.push(blob); return `blob:download-${blobs.length}` }),
    revokeObjectURL: vi.fn(),
  })
  vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(function () {
    downloads.push({ name: this.download, href: this.href })
  })
})
afterEach(() => { wrapper?.unmount(); vi.unstubAllGlobals(); vi.restoreAllMocks() })

it('shows each independent expert, source evidence, fix logic and conflicting candidate diff', () => {
  wrapper = mount(BugFixExpertReviews, { props: { reviews: reviews(), conflicts } })
  const cards = wrapper.findAll('.expert-card')
  expect(cards).toHaveLength(2)
  expect(cards[0].text()).toContain('battery-expert')
  expect(cards[0].text()).toContain('src/battery.c:12')
  expect(cards[0].text()).toContain('Source quote verified')
  expect(cards[0].text()).toContain('Validate the reading first')
  expect(cards[0].text()).toContain('Preserve the error contract')
  expect(cards[0].text()).toContain('Boundary readings need regression checks')
  expect(cards[0].text()).toContain('Proposed verification (not executed)')
  expect(cards[0].find('.diff-item pre').text()).toBe(candidateDiff.trim())
  expect(cards[1].text()).toContain('Evidence needs review')
  expect(cards[1].text()).toContain('Source evidence could not be verified')
  expect(wrapper.find('[role="status"]').text()).toContain('battery-expert, storage-expert: Final reconciliation required')
})

it('keeps failed, unavailable and unmatched reviews explicit without claiming success', () => {
  wrapper = mount(BugFixExpertReviews, { props: { reviews: [
    { skill: 'battery-expert', module: 'battery', status: 'failed', summary: 'Expert response was invalid' },
    { skill: 'storage-expert', module: 'datamanage', status: 'unavailable', summary: 'A dependency is unavailable' },
  ] } })
  expect(wrapper.text()).toContain('Expert response was invalid')
  expect(wrapper.text()).toContain('A dependency is unavailable')
  expect(wrapper.text()).not.toContain('No supported problem points were identified')
  wrapper.unmount()
  wrapper = mount(BugFixExpertReviews)
  expect(wrapper.text()).toContain('No applicable module expert review is available')
})

it('downloads the selected expert diff with a safe filename and escapes source HTML', async () => {
  const data = reviews()
  data[0].skill = 'expert/one'
  data[0].findings[0].evidence = '<img src=x onerror=alert(1)>'
  wrapper = mount(BugFixExpertReviews, { props: { reviews: data } })
  expect(wrapper.find('img').exists()).toBe(false)
  expect(wrapper.text()).toContain('<img src=x onerror=alert(1)>')
  await wrapper.find('.diff-item button').trigger('click')
  expect(blobs[0].content).toBe(candidateDiff)
  expect(blobs[0].type).toBe('text/x-diff')
  expect(downloads[0].name).toBe('expert_one-src_battery.c.diff')
  expect(URL.revokeObjectURL).toHaveBeenCalledWith(downloads[0].href)
})

it('keeps expert candidate diffs and final diffs distinct in the shared single and batch report', async () => {
  wrapper = mountReport(result())
  expect(wrapper.findComponent(BugFixExpertReviews).props('reviews')).toHaveLength(2)
  const section = wrapper.findAll('section.result-section').find(item => item.find('h3').text() === 'Final code diffs')
  expect(section.find('pre').text()).toBe(finalDiff.trim())
  await section.find('button').trigger('click')
  expect(blobs[0].content).toBe(finalDiff)
  expect(downloads[0].name).toBe('src_battery.c.diff')
})

it('downloads the authoritative server report and retains expert details in the fallback export', async () => {
  wrapper = mountReport({ ...result(), report_markdown: '# Saved expert report\nExact server content' })
  await wrapper.find('[aria-label="Download analysis report"]').trigger('click')
  expect(blobs[0].content).toBe('# Saved expert report\nExact server content')
  await wrapper.setProps({ result: result() })
  await wrapper.find('[aria-label="Download analysis report"]').trigger('click')
  expect(downloads[1].name).toBe('bugfix-report.md')
  expect(blobs[1].content).toContain('## Module expert: battery-expert (battery)')
  expect(blobs[1].content).toContain('Source quote verified: true')
  expect(blobs[1].content).toContain('Fix logic: Preserve the error contract')
  expect(blobs[1].content).toContain('Expert candidate diff: src/battery.c')
  expect(blobs[1].content).toContain('Proposed verification (not executed): Exercise invalid readings')
  expect(blobs[1].content).toContain('Proposal conflict: src/battery.c')
  expect(blobs[1].content).toContain('Final code diff: src/battery.c')
})
