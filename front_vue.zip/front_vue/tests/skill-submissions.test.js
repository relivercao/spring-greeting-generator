import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { reactive } from 'vue'
import SkillSubmissionPanel from '../src/components/SkillSubmissionPanel.vue'
import * as api from '../src/api/skillMarket.js'

const state=vi.hoisted(()=>({ auth:null }))
vi.mock('../src/stores/auth.js',()=>({useAuthStore:()=>state.auth}))
vi.mock('../src/api/skillMarket.js',()=>({submissionTargets:vi.fn(), submitUserSkill:vi.fn(), listSkillSubmissions:vi.fn(),
  getSkillSubmission:vi.fn(), publishSkillSubmission:vi.fn(), rejectSkillSubmission:vi.fn(),
  skillPackageDownloadUrl:id=>`/api/v1/skill-market/packages/${id}/download`}))
const slots={template:'<div><slot /></div>'}
const stubs={
  ElDrawer:{props:['modelValue'],template:'<div v-if="modelValue"><slot /></div>'},
  ElDialog:{props:['modelValue'],template:'<section v-if="modelValue" class="preview"><slot /><slot name="footer" /></section>'},
  ElButton:{props:['disabled','loading'],template:'<button :disabled="disabled || loading"><slot /></button>'},
  ElAlert:{props:['title'],template:'<p role="alert">{{title}}</p>'},ElTag:slots,
  ElSelect:{props:['modelValue'],emits:['update:modelValue','change'],template:'<select :value="modelValue" @change="$emit(\'update:modelValue\',$event.target.value);$emit(\'change\',$event.target.value)"><slot /></select>'},
  ElOption:{props:['value','label'],template:'<option :value="value">{{label}}</option>'},
  ElInput:{props:['modelValue'],emits:['update:modelValue'],template:'<textarea :value="modelValue" @input="$emit(\'update:modelValue\',$event.target.value)" />'},
  ElPagination:true,
}
const submission=()=>({id:'submission-1',name:'user-guide',description:'User submitted guide.',status:'pending',content_sha256:'saved-hash',
  files:{'SKILL.md':'---\nname: user-guide\ndescription: User guide.\n---\n<script>untrusted text</script>\n'}})
let wrapper
function button(text){return wrapper.findAll('button').find(item=>item.text()===text)}
function render(){wrapper=mount(SkillSubmissionPanel,{props:{modelValue:true},global:{stubs,config:{warnHandler:()=>{}}}});return wrapper}
async function chooseFile(size=10){
  const file=new File(['x'.repeat(size)],'SKILL.md',{type:'text/markdown'})
  const input=wrapper.find('input[type=file]')
  Object.defineProperty(input.element,'files',{value:[file],configurable:true})
  await input.trigger('change');return file
}
beforeEach(()=>{
  vi.clearAllMocks()
  state.auth=reactive({isLoggedIn:true,isAdmin:false,user:{id:'alice',name:'Alice'}})
  api.submissionTargets.mockResolvedValue({items:[{agent:'chat',stages:['respond']}]})
  api.listSkillSubmissions.mockResolvedValue({items:[submission()],total:1})
  api.submitUserSkill.mockResolvedValue(submission())
  api.getSkillSubmission.mockResolvedValue(submission())
  api.publishSkillSubmission.mockResolvedValue({...submission(),status:'published',integration:{status:'mapped',message:'Ready for chat/respond.'}})
  api.rejectSkillSubmission.mockResolvedValue({...submission(),status:'rejected'})
})
afterEach(()=>{wrapper?.unmount();wrapper=null})

it('submits the selected file with an optional Agent mapping and never deploys it as a user',async()=>{
  render();await flushPromises()
  const file=await chooseFile()
  await wrapper.find('select').setValue('chat')
  await wrapper.findAll('select')[1].setValue('respond')
  await button('Submit for Review').trigger('click');await flushPromises()
  expect(api.submitUserSkill).toHaveBeenCalledWith(file,'chat','respond')
  expect(wrapper.text()).toContain('It has not been deployed yet')
  expect(button('Review Queue')).toBeUndefined()
  expect(api.publishSkillSubmission).not.toHaveBeenCalled()
})

it('renders the package as text and lets an administrator publish and deploy the reviewed content',async()=>{
  state.auth.isAdmin=true
  render();await flushPromises()
  await button('Review Queue').trigger('click');await flushPromises()
  expect(api.listSkillSubmissions).toHaveBeenLastCalledWith(true,1)
  await button('Review Package').trigger('click');await flushPromises()
  expect(wrapper.find('pre').text()).toContain('<script>untrusted text</script>')
  expect(wrapper.find('.preview script').exists()).toBe(false)
  await button('Publish & Deploy').trigger('click');await flushPromises()
  expect(api.publishSkillSubmission).toHaveBeenCalledWith('submission-1')
  expect(wrapper.text()).toContain('Ready for chat/respond')
  expect(wrapper.emitted('published')).toHaveLength(1)
})

it('keeps the review open on a conflict without reporting publication success',async()=>{
  state.auth.isAdmin=true
  api.publishSkillSubmission.mockRejectedValue(new Error('A skill with this name is already installed'))
  render();await flushPromises()
  await button('View Submission').trigger('click');await flushPromises()
  await button('Publish & Deploy').trigger('click');await flushPromises()
  expect(wrapper.find('.preview').exists()).toBe(true)
  expect(wrapper.text()).toContain('already installed')
  expect(wrapper.emitted('published')).toBeUndefined()
})

it('requires a rejection note and sends the review decision',async()=>{
  state.auth.isAdmin=true
  render();await flushPromises()
  await button('View Submission').trigger('click');await flushPromises()
  expect(button('Reject').attributes('disabled')).toBeDefined()
  await wrapper.find('textarea').setValue('Please include a reference.')
  await button('Reject').trigger('click');await flushPromises()
  expect(api.rejectSkillSubmission).toHaveBeenCalledWith('submission-1','Please include a reference.')
})

it('rejects oversized uploads before sending them to the server',async()=>{
  render();await flushPromises()
  await chooseFile(1024*1024+1)
  expect(wrapper.text()).toContain('exceeds the 1 MiB limit')
  expect(button('Submit for Review').attributes('disabled')).toBeDefined()
  expect(api.submitUserSkill).not.toHaveBeenCalled()
})

it('clears private submissions and ignores late preview responses after switching accounts',async()=>{
  let resolvePreview
  api.getSkillSubmission.mockImplementationOnce(()=>new Promise(resolve=>{resolvePreview=resolve}))
  render();await flushPromises()
  await button('View Submission').trigger('click');await flushPromises()
  state.auth.user={id:'bob',name:'Bob'};await flushPromises()
  resolvePreview({...submission(),name:'private-alice-package'});await flushPromises()
  expect(wrapper.text()).not.toContain('private-alice-package')
  expect(wrapper.text()).not.toContain('user-guide')
  expect(wrapper.emitted('update:modelValue')).toContainEqual([false])
})

it('provides a portable ZIP download for a published skill',async()=>{
  api.listSkillSubmissions.mockResolvedValue({items:[{...submission(),status:'published',installed_id:'user-guide-hash'}],total:1})
  render();await flushPromises()
  expect(button('Export ZIP').attributes('href')).toBe('/api/v1/skill-market/packages/user-guide-hash/download')
})

it('reports the existing rejection when the same package is submitted again',async()=>{
  api.submitUserSkill.mockResolvedValue({...submission(),status:'rejected',review_note:'Add supporting references.'})
  render();await flushPromises()
  await chooseFile()
  await button('Submit for Review').trigger('click');await flushPromises()
  expect(wrapper.text()).toContain('already rejected')
  expect(wrapper.text()).toContain('Add supporting references.')
  expect(wrapper.text()).not.toContain('Skill submitted for administrator review')
})
