import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { reactive } from 'vue'
import FeishuBotSettings from '../src/components/FeishuBotSettings.vue'
import ConnectedAppsPanel from '../src/components/ConnectedAppsPanel.vue'
import * as api from '../src/api/feishu.js'
import { getConnectedApps } from '../src/api/connectedApps.js'

const state = vi.hoisted(() => ({ auth: null }))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('vue-router', () => ({ useRouter: () => ({ push: vi.fn() }) }))
vi.mock('../src/api/feishu.js', () => ({
  getFeishuConfiguration: vi.fn(),
  saveFeishuConfiguration: vi.fn(),
  checkFeishuConnection: vi.fn(),
  startFeishuListener: vi.fn(),
  stopFeishuListener: vi.fn(),
  disconnectFeishu: vi.fn(),
}))
vi.mock('../src/api/connectedApps.js', () => ({
  getConnectedApps: vi.fn(),
  createConnectedAppLink: vi.fn(),
  disconnectConnectedApp: vi.fn(),
}))

const saved = {
  configured: true,
  app_id: 'cli_saved',
  app_secret_configured: true,
  brand: 'feishu',
  allowed_sender_ids: ['ou_owner'],
  verified_at: '2026-11-08T10:00:00',
  enabled: false,
  runtime: { status: 'stopped', cli_available: true, error: null },
}
const input = {
  props: ['modelValue', 'type', 'placeholder'],
  emits: ['update:modelValue'],
  template:
    '<textarea v-if="type === \'textarea\'" :value="modelValue" :placeholder="placeholder" @input="$emit(\'update:modelValue\', $event.target.value)" /><input v-else :type="type === \'password\' ? \'password\' : \'text\'" :value="modelValue" :placeholder="placeholder" @input="$emit(\'update:modelValue\', $event.target.value)" />',
}
const button = {
  props: ['disabled', 'loading', 'nativeType'],
  template:
    '<button :type="nativeType || \'button\'" :disabled="disabled || loading"><slot /></button>',
}
const form = {
  props: ['disabled'],
  template: '<form><fieldset :disabled="disabled"><slot /></fieldset></form>',
}
const alert = { props: ['title'], template: '<div role="alert">{{ title }}</div>' }
const stubs = {
  ElButton: button,
  ElInput: input,
  ElForm: form,
  ElFormItem: { template: '<label><slot /></label>' },
  ElAlert: alert,
}
let wrapper
function mountSettings() {
  wrapper = shallowMount(FeishuBotSettings, {
    global: { config: { warnHandler: () => {} }, stubs },
  })
  return wrapper
}
const findButton = label => wrapper.findAll('button').find(item => item.text() === label)

beforeEach(() => {
  vi.clearAllMocks()
  state.auth = reactive({ isLoggedIn: true, user: { id: 'user-a' } })
  api.getFeishuConfiguration.mockResolvedValue(structuredClone(saved))
  api.saveFeishuConfiguration.mockResolvedValue(saved)
  api.checkFeishuConnection.mockResolvedValue({
    message: 'Bot verified. No test message was sent.',
  })
  api.startFeishuListener.mockResolvedValue(saved)
  api.stopFeishuListener.mockResolvedValue(saved)
  api.disconnectFeishu.mockResolvedValue({ deleted_count: 1 })
})
afterEach(() => {
  wrapper?.unmount()
  wrapper = null
  vi.useRealTimers()
})

it('keeps saved secrets out of the form and checks without sending messages', async () => {
  mountSettings()
  await flushPromises()
  expect(wrapper.find('[aria-label="App Secret"]').element.value).toBe('')
  expect(wrapper.find('[aria-label="App Secret"]').attributes('placeholder')).toContain(
    'keep the saved secret'
  )
  await findButton('Check connection').trigger('click')
  await flushPromises()
  expect(api.checkFeishuConnection).toHaveBeenCalledTimes(1)
  expect(api.startFeishuListener).not.toHaveBeenCalled()
  expect(wrapper.text()).toContain('No test message was sent.')
})

it('saves optional secret and normalized allowlist without starting a listener', async () => {
  mountSettings()
  await flushPromises()
  await wrapper
    .find('[aria-label="Authorized sender open_ids"]')
    .setValue('ou_owner, ou_second\nou_owner')
  expect(findButton('Start listening').attributes('disabled')).toBeDefined()
  await wrapper.find('form').trigger('submit')
  await flushPromises()
  expect(api.saveFeishuConfiguration).toHaveBeenCalledWith({
    app_id: 'cli_saved',
    brand: 'feishu',
    allowed_sender_ids: ['ou_owner', 'ou_second'],
  })
  expect(api.startFeishuListener).not.toHaveBeenCalled()
  expect(wrapper.emitted('changed')).toHaveLength(1)
})

it('clears entered secrets after saving and does not persist them in browser storage', async () => {
  mountSettings()
  await flushPromises()
  await wrapper.find('[aria-label="App Secret"]').setValue('private-secret')
  await wrapper.find('form').trigger('submit')
  await flushPromises()
  expect(api.saveFeishuConfiguration.mock.calls[0][0].app_secret).toBe('private-secret')
  expect(wrapper.find('[aria-label="App Secret"]').element.value).toBe('')
  expect(JSON.stringify(localStorage)).not.toContain('private-secret')
})

it('disables configuration while listening and stops through the explicit action', async () => {
  api.getFeishuConfiguration.mockResolvedValue({
    ...saved,
    enabled: true,
    runtime: { status: 'listening', cli_available: true },
  })
  mountSettings()
  await flushPromises()
  expect(wrapper.find('fieldset').attributes('disabled')).toBeDefined()
  expect(findButton('Disconnect').attributes('disabled')).toBeDefined()
  await findButton('Stop listening').trigger('click')
  await flushPromises()
  expect(api.stopFeishuListener).toHaveBeenCalledTimes(1)
})

it('shows command failures and recent safe receipt outcomes', async () => {
  api.checkFeishuConnection.mockRejectedValue(new Error('Bot authentication failed.'))
  api.getFeishuConfiguration.mockResolvedValue({
    ...saved,
    recent_messages: [
      { id: 'one', status: 'failed', created_at: '2026-11-08', error: 'Delivery uncertain.' },
    ],
  })
  mountSettings()
  await flushPromises()
  await findButton('Check connection').trigger('click')
  await flushPromises()
  expect(wrapper.text()).toContain('Bot authentication failed.')
  expect(wrapper.text()).toContain('Delivery uncertain.')
})

it('ignores an old account response and cancels polling when closed', async () => {
  vi.useFakeTimers()
  let resolve
  api.getFeishuConfiguration.mockReturnValue(
    new Promise(done => {
      resolve = done
    })
  )
  mountSettings()
  state.auth.user = { id: 'user-b' }
  resolve({ ...saved, enabled: true, app_id: 'cli_private' })
  await flushPromises()
  expect(wrapper.html()).not.toContain('cli_private')
  wrapper.unmount()
  wrapper = null
  await vi.advanceTimersByTimeAsync(15000)
  expect(api.getFeishuConfiguration).toHaveBeenCalledTimes(1)
})

it('polls active status without overwriting unsaved fields', async () => {
  vi.useFakeTimers()
  api.getFeishuConfiguration.mockResolvedValue({
    ...saved,
    enabled: true,
    runtime: { status: 'listening', cli_available: true },
  })
  mountSettings()
  await flushPromises()
  await vi.advanceTimersByTimeAsync(4000)
  expect(api.getFeishuConfiguration).toHaveBeenCalledTimes(2)
  wrapper.unmount()
  wrapper = null
  await vi.advanceTimersByTimeAsync(10000)
  expect(api.getFeishuConfiguration).toHaveBeenCalledTimes(2)
})

it('offers CLI bot configuration even when the OAuth provider is not configured', async () => {
  getConnectedApps.mockResolvedValue({
    provider: { configured: false },
    apps: [
      {
        slug: 'feishu',
        name: 'Feishu / Lark',
        description: 'Bot chat',
        connection_method: 'feishu_cli',
        configured: true,
        connected: false,
        connection_status: 'NOT_CONNECTED',
      },
    ],
  })
  wrapper = shallowMount(ConnectedAppsPanel, {
    global: { config: { warnHandler: () => {} }, stubs },
  })
  await flushPromises()
  await findButton('Configure Bot').trigger('click')
  expect(wrapper.findComponent(FeishuBotSettings).exists()).toBe(true)
  state.auth.user = { id: 'user-b' }
  await flushPromises()
  expect(wrapper.findComponent(FeishuBotSettings).exists()).toBe(false)
})
