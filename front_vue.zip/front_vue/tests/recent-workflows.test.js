import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { reactive } from 'vue'
import GeneratedAgentWorkspace from '../src/components/GeneratedAgentWorkspace.vue'
import ChatGeneratedFiles from '../src/components/ChatGeneratedFiles.vue'
import BugFixJiraSource from '../src/components/bugfix-workspace/BugFixJiraSource.vue'
import BugFixResultReport from '../src/components/bugfix-workspace/BugFixResultReport.vue'
import AgentWorkspace from '../src/components/AgentWorkspace.vue'
import { useWorkspaceStore } from '../src/stores/workspace.js'
import { useAuthStore } from '../src/stores/auth.js'
import { chatWithGeneratedAgent, getGeneratedAgentTask } from '../src/api/agentGenerator.js'
import { apiGetJiraBug, apiGetJiraBugs } from '../src/api/bugfix.js'
import { http } from '../src/api/http.js'

const { route } = vi.hoisted(() => ({ route: { query: {} } }))
vi.mock('vue-router', () => ({ useRoute: () => route }))
vi.mock('../src/api/agentGenerator.js', () => ({
  chatWithGeneratedAgent: vi.fn(), getGeneratedAgentTask: vi.fn(),
  approveGeneratedAgentTask: vi.fn(), deleteGeneratedAgent: vi.fn(),
}))
vi.mock('../src/api/bugfix.js', () => ({ apiGetJiraBug: vi.fn(), apiGetJiraBugs: vi.fn() }))
vi.mock('../src/api/http.js', () => ({ http: { get: vi.fn().mockResolvedValue({}), post: vi.fn() } }))

const agent = {
  id: 'test-agent', name: 'Test Agent', description: 'Test workflow',
  knowledge_document_ids: [], knowledge_documents: [], input_definitions: [],
  flow_nodes: [{ id: 'execute', label: 'Execute', kind: 'task' }],
}
const wrappers = []
function mount(component, props) {
  const wrapper = shallowMount(component, {
    props, global: { plugins: [testPinia], config: { warnHandler: () => {} }, stubs: { ChatGeneratedFiles } },
  })
  wrappers.push(wrapper)
  return wrapper
}
function deferred() {
  let resolve
  const promise = new Promise(done => { resolve = done })
  return { promise, resolve }
}
async function startTask(wrapper) {
  await wrapper.find('textarea[placeholder="Send a task to this generated Agent..."]').setValue('Run this task')
  await wrapper.find('.send-button').trigger('click')
  await flushPromises()
}

let testPinia
beforeEach(() => {
  localStorage.clear()
  testPinia = createPinia()
  setActivePinia(testPinia)
  route.query = reactive({})
  vi.clearAllMocks()
  http.get.mockResolvedValue({})
  apiGetJiraBugs.mockResolvedValue({ issues: [] })
})
afterEach(() => {
  wrappers.splice(0).forEach(wrapper => wrapper.unmount())
  vi.useRealTimers()
})

describe('generated Agent task lifecycle', () => {
  beforeEach(() => useAuthStore().enterGuest())

  it('renders completed task outputs as openable file cards without a duplicate path bubble', async () => {
    const url = '/api/v1/chat/artifacts/u/s/id/report.md?expires=123&signature=test'
    chatWithGeneratedAgent.mockResolvedValue({ task_id: 'task-document' })
    getGeneratedAgentTask.mockResolvedValue({
      status: 'completed', progress: 100,
      response: `Generated document: [D:/outputs/report.md](${url})`,
      output_files: [{ name: 'report.md', download_url: url, size: 1024 }],
    })
    const wrapper = mount(GeneratedAgentWorkspace, { agent })
    await startTask(wrapper)
    expect(wrapper.findAll('.generated-file')).toHaveLength(1)
    expect(wrapper.find('.file-name').attributes('href')).toBe(url)
    expect(wrapper.find('.message-row.assistant .message-content').exists()).toBe(false)
  })

  it('sends bounded previous history without duplicating the new user turn', async () => {
    chatWithGeneratedAgent.mockResolvedValue({ task_id: 'task-history' })
    getGeneratedAgentTask.mockResolvedValue({ status: 'completed', progress: 100, response: 'Done' })
    const wrapper = mount(GeneratedAgentWorkspace, { agent })
    await startTask(wrapper)
    expect(chatWithGeneratedAgent.mock.calls[0][1].history).toEqual([])
    await startTask(wrapper)
    expect(chatWithGeneratedAgent.mock.calls[1][1].history).toEqual([
      { role: 'user', content: 'Run this task' }, { role: 'assistant', content: 'Done' },
    ])
  })

  it('preserves completed progress when the manifest refreshes', async () => {
    chatWithGeneratedAgent.mockResolvedValue({ task_id: 'task-refresh' })
    getGeneratedAgentTask.mockResolvedValue({
      status: 'completed', progress: 100, response: 'Done', workflow_nodes: [{ ...agent.flow_nodes[0], status: 'done' }],
    })
    const wrapper = mount(GeneratedAgentWorkspace, { agent })
    await startTask(wrapper)
    await wrapper.setProps({ agent: structuredClone(agent) })
    expect(wrapper.find('.workflow-progress').text()).toBe('100%')
  })

  it('restores the task handle after leaving and returning to the workspace', async () => {
    chatWithGeneratedAgent.mockResolvedValue({ task_id: 'task-resume' })
    const pending = deferred()
    getGeneratedAgentTask.mockReturnValueOnce(pending.promise)
    const wrapper = mount(GeneratedAgentWorkspace, { agent })
    await startTask(wrapper)
    wrapper.unmount()
    getGeneratedAgentTask.mockResolvedValue({ status: 'completed', progress: 100, response: 'Recovered result' })
    const restored = mount(GeneratedAgentWorkspace, { agent })
    pending.resolve({ status: 'running', progress: 25 })
    await flushPromises()
    expect(restored.text()).toContain('Recovered result')
    expect(chatWithGeneratedAgent).toHaveBeenCalledTimes(1)
    expect(getGeneratedAgentTask).toHaveBeenCalledTimes(2)
  })

  it('hides expired approval controls on terminal task snapshots', async () => {
    chatWithGeneratedAgent.mockResolvedValue({ task_id: 'task-cancelled' })
    getGeneratedAgentTask.mockResolvedValue({ status: 'cancelled', message: 'Stopped', approval: { status: 'pending', token: 'expired' } })
    const wrapper = mount(GeneratedAgentWorkspace, { agent })
    await startTask(wrapper)
    expect(wrapper.find('.approval-card').exists()).toBe(false)
    expect(wrapper.text()).toContain('Stopped')
  })
})

describe('Jira notification navigation', () => {
  it('loads the latest requested issue when the previous issue is still loading', async () => {
    route.query.issue = 'FW-1'
    const first = deferred()
    apiGetJiraBug.mockReturnValueOnce(first.promise).mockResolvedValueOnce({ key: 'FW-2', summary: 'Second bug' })
    const wrapper = mount(BugFixJiraSource, { integration: { available: true }, disabled: false })
    route.query.issue = 'FW-2'
    await flushPromises()
    first.resolve({ key: 'FW-1', summary: 'First bug' })
    await flushPromises()
    expect(apiGetJiraBug).toHaveBeenCalledWith('FW-2')
    expect(wrapper.emitted('selected').filter(([ticket]) => ticket).at(-1)[0].key).toBe('FW-2')
  })

  it('defers a notification while a task is active and loads it when enabled', async () => {
    route.query.issue = 'FW-3'
    apiGetJiraBug.mockResolvedValue({ key: 'FW-3', summary: 'Deferred bug' })
    const wrapper = mount(BugFixJiraSource, { integration: { available: true }, disabled: true })
    expect(apiGetJiraBug).not.toHaveBeenCalled()
    await wrapper.setProps({ disabled: false })
    await flushPromises()
    expect(apiGetJiraBug).toHaveBeenCalledWith('FW-3')
  })
})

describe('BugFix result report', () => {
  it('shows validation summary and expands only the first patch', () => {
    const wrapper = mount(BugFixResultReport, {
      result: {
        files_analyzed: 3,
        patches: { 'src/driver.c': 'fix one', 'include/driver.h': 'fix two' },
        validation_warnings: ['Static checks only'],
        patch_attempt_history: [{ attempt: 1, validation: 'passed', patch_paths: ['src/driver.c'] }],
        root_cause: 'Null pointer',
        fix_approach: 'Guard the dereference',
      },
    })

    expect(wrapper.find('.result-stats').text()).toContain('3Files analyzed')
    expect(wrapper.find('.result-stats').text()).toContain('2Patches')
    expect(wrapper.find('.result-stats').text()).toContain('1Attempts')
    expect(wrapper.find('.validation-banner').text()).toContain('Review notes available')
    const patches = wrapper.findAll('details')
    expect(patches).toHaveLength(2)
    expect(patches[0].element.open).toBe(true)
    expect(patches[1].element.open).toBe(false)
  })
})

describe('Code Review defaults and notification navigation', () => {
  beforeEach(() => useAuthStore().enterGuest())
  it('leaves email unchecked by default and follows same-page PR updates', async () => {
    const wrapper = mount(AgentWorkspace, { agent: { id: 4, name: 'Code Review', color: '#2563eb' } })
    await flushPromises()
    expect(wrapper.find('input[value="email"]').element.checked).toBe(false)
    route.query.repo = 'FW/firmware'
    route.query.pr_id = '42'
    await flushPromises()
    expect(wrapper.find('input[placeholder*="Repository"]').exists() || wrapper.text().includes('Pull Request')).toBe(true)
    expect(useWorkspaceStore().getState('workspace:guest:4')).toMatchObject({ bitbucketRepo: 'FW/firmware', bitbucketPrId: '42' })
    route.query.repo = 'FW/driver'
    route.query.pr_id = '43'
    await flushPromises()
    expect(useWorkspaceStore().getState('workspace:guest:4')).toMatchObject({ bitbucketRepo: 'FW/driver', bitbucketPrId: '43' })
  })
})
