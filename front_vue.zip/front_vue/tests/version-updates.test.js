import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { checkForVersionUpdate } from '../src/api/version.js'
import VersionUpdateBanner from '../src/components/VersionUpdateBanner.vue'

vi.mock('../src/api/version.js', () => ({
  checkForVersionUpdate: vi.fn(),
}))

vi.mock('element-plus', () => ({
  ElMessage: { error: vi.fn() },
  ElMessageBox: { confirm: vi.fn() },
}))

const ElementButtonStub = {
  emits: ['click'],
  template: '<button @click="$emit(\'click\')"><slot /></button>',
}

describe('version update reminder', () => {
  beforeEach(() => {
    localStorage.clear()
    checkForVersionUpdate.mockReset()
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('shows the latest version and remembers a dismissed optional reminder', async () => {
    checkForVersionUpdate.mockResolvedValue({
      current_version: '3.2.0',
      latest_version: '3.2.1',
      update_available: true,
      release: {
        version: '3.2.1',
        title: 'Improved release workflow',
        release_notes: 'Installer stability fixes',
        download_url: 'https://downloads.example.com/Macode-Setup-3.2.1.exe',
        mandatory: false,
      },
    })

    const wrapper = mount(VersionUpdateBanner, {
      global: { stubs: { ElButton: ElementButtonStub, ElIcon: true } },
    })
    await flushPromises()

    expect(wrapper.text()).toContain('Version 3.2.1 is available')
    expect(wrapper.text()).toContain('Installer stability fixes')
    await wrapper.findAll('button').at(-1).trigger('click')
    expect(localStorage.getItem('macode.dismissed-update:3.2.1')).toBe('1')
    expect(wrapper.find('.version-update-banner').exists()).toBe(false)
    wrapper.unmount()
  })
})
