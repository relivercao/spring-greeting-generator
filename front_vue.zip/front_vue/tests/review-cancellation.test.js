import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { flushPromises, shallowMount } from '@vue/test-utils'
import AgentWorkspace from '../src/components/AgentWorkspace.vue'
import * as api from '../src/api/review.js'
import { useAuthStore } from '../src/stores/auth.js'

vi.mock('vue-router', () => ({ useRoute: () => ({ query: {} }) }))
vi.mock('../src/api/review.js', () => ({
  apiApproveReviewTask: vi.fn(), apiCreateReviewTask: vi.fn(),
  apiPollReviewTask: vi.fn(), apiCancelReviewTask: vi.fn(), getReviewIntegrations: vi.fn(),
}))

let wrapper
let poll
let stop
beforeEach(async () => {
  localStorage.clear()
  setActivePinia(createPinia())
  useAuthStore().enterGuest()
  vi.resetAllMocks()
  stop = vi.fn()
  api.getReviewIntegrations.mockResolvedValue({})
  api.apiCreateReviewTask.mockResolvedValue({ task_id: 'review-first' })
  api.apiPollReviewTask.mockImplementation((_id, callback) => { poll = callback; return stop })
  wrapper = shallowMount(AgentWorkspace, {
    props: { agent: { id: 4, name: 'Code Review', color: '#2563eb' } },
    global: { config: { warnHandler: () => {} } },
  })
  wrapper.vm.handleReview()
  await flushPromises()
})
afterEach(() => wrapper.unmount())

it('retains progress and cancellation controls after a failed cancel request', async () => {
  api.apiCancelReviewTask.mockRejectedValue(new Error('Network unavailable'))
  await wrapper.find('.cancel-btn').trigger('click')
  await flushPromises()
  expect(wrapper.find('.cancel-btn').exists()).toBe(true)
  expect(wrapper.vm.currentTaskId).toBe('review-first')
  expect(stop).not.toHaveBeenCalled()
  expect(wrapper.vm.loadingMsg).toContain('Network unavailable')
  poll({ status: 'completed', result: { score: 97, findings: [] } })
  await flushPromises()
  expect(wrapper.vm.agentResult.score).toBe(97)
})

it('shows a result already completed before the cancel request reached the server', async () => {
  api.apiCancelReviewTask.mockResolvedValue({ status: 'completed', result: { score: 98, findings: [] } })
  await wrapper.find('.cancel-btn').trigger('click')
  await flushPromises()
  expect(wrapper.vm.agentResult.score).toBe(98)
  expect(wrapper.vm.agentResult.error).toBeUndefined()
})

it('continues polling a cancellation that is still running', async () => {
  api.apiCancelReviewTask.mockResolvedValue({ status: 'running', progress: 65 })
  await wrapper.find('.cancel-btn').trigger('click')
  await flushPromises()
  expect(wrapper.vm.isLoading).toBe(true)
  expect(wrapper.find('.cancel-btn').attributes('disabled')).toBeUndefined()
  expect(stop).not.toHaveBeenCalled()
  poll({ status: 'cancelled', message: 'Cancelled by user' })
  await flushPromises()
  expect(wrapper.vm.agentResult.error).toBe('Cancelled by user')
})

it('ignores a cancellation error received after completion', async () => {
  let reject
  api.apiCancelReviewTask.mockReturnValue(new Promise((_resolve, fail) => { reject = fail }))
  await wrapper.find('.cancel-btn').trigger('click')
  poll({ status: 'completed', result: { score: 99, findings: [] } })
  await flushPromises()
  reject(new Error('Late failure'))
  await flushPromises()
  expect(wrapper.vm.agentResult.score).toBe(99)
  expect(wrapper.vm.agentResult.error).toBeUndefined()
})

it('does not release a new task cancellation when an old response arrives', async () => {
  let resolveFirst
  api.apiCancelReviewTask.mockReturnValueOnce(new Promise(done => { resolveFirst = done }))
  await wrapper.find('.cancel-btn').trigger('click')
  poll({ status: 'completed', result: { findings: [] } })
  await flushPromises()
  api.apiCreateReviewTask.mockResolvedValue({ task_id: 'review-second' })
  wrapper.vm.handleReview()
  await flushPromises()
  expect(wrapper.find('.cancel-btn').attributes('disabled')).toBeUndefined()
  api.apiCancelReviewTask.mockReturnValueOnce(new Promise(() => {}))
  await wrapper.find('.cancel-btn').trigger('click')
  resolveFirst({ status: 'cancelled' })
  await flushPromises()
  expect(wrapper.vm.currentTaskId).toBe('review-second')
  expect(wrapper.vm.isLoading).toBe(true)
  expect(wrapper.find('.cancel-btn').attributes('disabled')).toBeDefined()
})

it('does not resume polling after navigation during task creation', async () => {
  poll({ status: 'completed', result: {} })
  await flushPromises()
  let resolve
  api.apiCreateReviewTask.mockReturnValue(new Promise(done => { resolve = done }))
  const pending = wrapper.vm.handleReview()
  wrapper.unmount()
  resolve({ task_id: 'late-review' })
  await pending
  expect(api.apiPollReviewTask).toHaveBeenCalledTimes(1)
})

it('stops observation immediately and ignores private results after an account change', async () => {
  useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'second-user' }))}.signature`
  expect(stop).toHaveBeenCalledTimes(1)
  poll({ status: 'completed', result: { score: 42, findings: [] } })
  await flushPromises()
  expect(wrapper.vm.agentResult).toBeNull()
})

it('does not restore another account review context', async () => {
  wrapper.vm.userPrompt = 'Private review context'
  await flushPromises()
  wrapper.unmount()
  useAuthStore().token = `header.${btoa(JSON.stringify({ sub: 'second-user' }))}.signature`
  wrapper = shallowMount(AgentWorkspace, {
    props: { agent: { id: 4, name: 'Code Review', color: '#2563eb' } },
    global: { config: { warnHandler: () => {} } },
  })
  await flushPromises()
  expect(wrapper.vm.userPrompt).toBe('')
})

it('restores review inputs when the same account returns', async () => {
  wrapper.vm.userPrompt = 'Review interrupt safety'
  wrapper.vm.bitbucketRepo = 'firmware/core'
  wrapper.vm.bitbucketPrId = '24'
  await flushPromises()
  wrapper.unmount()
  wrapper = shallowMount(AgentWorkspace, {
    props: { agent: { id: 4, name: 'Code Review', color: '#2563eb' } },
    global: { config: { warnHandler: () => {} } },
  })
  await flushPromises()
  expect(wrapper.vm.userPrompt).toBe('Review interrupt safety')
  expect(wrapper.vm.bitbucketRepo).toBe('firmware/core')
  expect(wrapper.vm.bitbucketPrId).toBe('24')
})
