import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import ConnectedAppsPanel from '../src/components/ConnectedAppsPanel.vue'
import ConnectedAppProviderSettings from '../src/components/ConnectedAppProviderSettings.vue'
import { reactive } from 'vue'
import {
  getConnectedApps,
  getAppConnectionProvider,
  saveAppConnectionProvider,
} from '../src/api/connectedApps.js'

const state = vi.hoisted(() => ({
  auth: { isLoggedIn: false },
  push: vi.fn(),
}))

vi.mock('vue-router', () => ({ useRouter: () => ({ push: state.push }) }))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('../src/api/connectedApps.js', () => ({
  createConnectedAppLink: vi.fn(),
  disconnectConnectedApp: vi.fn(),
  getConnectedApps: vi.fn(),
  getAppConnectionProvider: vi.fn(),
  saveAppConnectionProvider: vi.fn(),
}))

let wrapper
const buttonStub = {
  props: ['disabled', 'loading'],
  template: '<button :disabled="disabled || loading"><slot /></button>',
}
const inputStub = {
  props: ['modelValue'],
  emits: ['update:modelValue'],
  template:
    '<input :value="modelValue" @input="$emit(\'update:modelValue\', $event.target.value)" />',
}
function mountPanel() {
  wrapper = shallowMount(ConnectedAppsPanel, {
    global: {
      config: { warnHandler: () => {} },
      stubs: { ElButton: buttonStub, ElInput: inputStub },
    },
  })
  return wrapper
}
beforeEach(() => {
  state.auth = reactive({ isLoggedIn: false, isAdmin: false, user: null })
  vi.clearAllMocks()
  getConnectedApps.mockResolvedValue({ provider: { configured: true }, apps: [] })
})

afterEach(() => {
  wrapper?.unmount()
  wrapper = null
  vi.clearAllMocks()
})

it('asks guests to sign in without requesting protected connection data', async () => {
  mountPanel()
  await flushPromises()

  expect(wrapper.text()).toContain('Sign in to connect apps to your workspace.')
  expect(getConnectedApps).not.toHaveBeenCalled()
})

const catalog = [
  {
    slug: 'gmail',
    name: 'Gmail',
    description: 'Email messages',
    configured: true,
    connected: true,
    has_account: true,
    connection_status: 'ACTIVE',
  },
  {
    slug: 'github',
    name: 'GitHub',
    description: 'Repositories',
    configured: false,
    connected: false,
    has_account: false,
    connection_status: 'NOT_CONNECTED',
  },
]

it('shows account status and filters connected apps in settings', async () => {
  state.auth.isLoggedIn = true
  state.auth.user = { id: 'user-a' }
  getConnectedApps.mockResolvedValue({ provider: { configured: true }, apps: catalog })
  mountPanel()
  await flushPromises()
  expect(wrapper.findAll('.app-card')).toHaveLength(2)
  expect(wrapper.find('.app-card').text()).toContain('Connected')
  await wrapper.findAll('.filter-button')[1].trigger('click')
  expect(wrapper.findAll('.app-card')).toHaveLength(1)
  expect(wrapper.find('.app-card').text()).toContain('Gmail')
  expect(wrapper.text()).toContain('Connected accounts are available to Chat Agent')
})

it('offers Gmail in the global assistant without automatically reading or sending mail', async () => {
  state.auth.isLoggedIn = true
  state.auth.user = { id: 'user-a' }
  getConnectedApps.mockResolvedValue({ provider: { configured: true }, apps: catalog })
  mountPanel()
  await flushPromises()
  await wrapper.findAll('button').find(button => button.text() === 'Use Gmail').trigger('click')
  expect(wrapper.emitted('use-app')).toEqual([['gmail']])
  expect(wrapper.text()).toContain('AI Assistant on every page')
  expect(getConnectedApps).toHaveBeenCalledTimes(1)
})

it('does not show account connections from an earlier signed-in user', async () => {
  state.auth.isLoggedIn = true
  state.auth.user = { id: 'user-a' }
  let resolveFirst
  getConnectedApps
    .mockReturnValueOnce(
      new Promise(resolve => {
        resolveFirst = resolve
      })
    )
    .mockResolvedValueOnce({ provider: { configured: true }, apps: [] })
  mountPanel()
  state.auth.user = { id: 'user-b' }
  await flushPromises()
  resolveFirst({ provider: { configured: true }, apps: catalog })
  await flushPromises()
  expect(wrapper.findAll('.app-card')).toHaveLength(0)
  expect(wrapper.text()).not.toContain('Gmail')
})

it('refreshes authorization on focus and exposes provider setup only to admins', async () => {
  state.auth.isLoggedIn = true
  state.auth.user = { id: 'user-a' }
  mountPanel()
  await flushPromises()
  expect(wrapper.find('.provider-settings-toggle').exists()).toBe(false)
  state.auth.isAdmin = true
  await flushPromises()
  expect(wrapper.find('.provider-settings-toggle').exists()).toBe(true)
  globalThis.dispatchEvent(new Event('focus'))
  await flushPromises()
  expect(getConnectedApps).toHaveBeenCalledTimes(2)
})

it('saves provider settings without overwriting a previously configured secret', async () => {
  getAppConnectionProvider.mockResolvedValue({
    api_key_configured: true,
    api_base_url: 'https://composio.test/api/v3.1',
    frontend_base_url: 'http://127.0.0.1:5173',
    auth_configs: {},
    apps: [{ slug: 'notion', name: 'Notion' }],
  })
  saveAppConnectionProvider.mockResolvedValue({ api_key_configured: true })
  wrapper = shallowMount(ConnectedAppProviderSettings, {
    global: {
      config: { warnHandler: () => {} },
      stubs: { ElButton: buttonStub, ElInput: inputStub },
    },
  })
  await flushPromises()
  await wrapper.find('#auth-config-notion').setValue('ac_notion')
  await wrapper.find('button').trigger('click')
  await flushPromises()
  expect(saveAppConnectionProvider).toHaveBeenCalledWith({
    api_key: null,
    api_base_url: 'https://composio.test/api/v3.1',
    app_frontend_base_url: window.location.origin,
    auth_configs: { notion: 'ac_notion' },
  })
  expect(wrapper.emitted('saved')).toHaveLength(1)
})

it('uses the current browser address when the dedicated app return URL is unset', async () => {
  getAppConnectionProvider.mockResolvedValue({
    api_key_configured: false,
    api_base_url: 'https://composio.test/api/v3.1',
    app_frontend_base_url: '',
    frontend_base_url: 'https://payments.example.test',
    auth_configs: {},
    apps: [],
  })
  wrapper = shallowMount(ConnectedAppProviderSettings, {
    global: { stubs: { ElButton: buttonStub, ElInput: inputStub } },
  })
  await flushPromises()

  expect(wrapper.find('#app-callback-url').element.value).toBe(window.location.origin)
})

it('replaces a legacy loopback callback URL with the hosted browser address', async () => {
  getAppConnectionProvider.mockResolvedValue({
    api_key_configured: false,
    api_base_url: 'https://composio.test/api/v3.1',
    frontend_base_url: 'http://127.0.0.1:5173',
    auth_configs: {},
    apps: [],
  })
  wrapper = shallowMount(ConnectedAppProviderSettings, {
    global: { stubs: { ElButton: buttonStub, ElInput: inputStub } },
  })
  await flushPromises()

  expect(wrapper.find('#app-callback-url').element.value).toBe(window.location.origin)
})
