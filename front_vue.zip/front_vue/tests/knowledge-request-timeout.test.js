import { afterEach, expect, it, vi } from 'vitest'
import { askKnowledgeBase } from '../src/api/knowledgeBase.js'

afterEach(() => {
  vi.useRealTimers()
  vi.unstubAllGlobals()
  localStorage.clear()
})

it('allows the semantic lookup deadline before aborting a stalled knowledge request', async () => {
  vi.useFakeTimers()
  let requestSignal
  vi.stubGlobal('fetch', vi.fn((_url, options) => new Promise((_resolve, reject) => {
    requestSignal = options.signal
    options.signal.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')))
  })))
  const result = askKnowledgeBase({ question: 'What is the delay?' }).catch(error => error)
  await vi.advanceTimersByTimeAsync(300000)
  expect(requestSignal.aborted).toBe(false)
  await vi.advanceTimersByTimeAsync(30000)
  expect(requestSignal.aborted).toBe(true)
  expect((await result).message).toContain('timed out after 330 seconds')
  expect(vi.getTimerCount()).toBe(0)
})

it('cleans up its timeout after a successful response', async () => {
  vi.useFakeTimers()
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
    status: 200, ok: true, json: async () => ({ answer: '12 milliseconds' }),
  }))
  expect(await askKnowledgeBase({ question: 'What is the delay?' })).toEqual({ answer: '12 milliseconds' })
  expect(vi.getTimerCount()).toBe(0)
})

it('sends recent knowledge conversation history with follow-up questions', async () => {
  const history = [
    { role: 'user', content: 'Explain CTRL.ENABLE.' },
    { role: 'assistant', content: 'It enables the controller output.' },
  ]
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
    status: 200, ok: true, json: async () => ({ answer: 'It resets to zero.' }),
  }))

  await askKnowledgeBase({ question: 'What about its reset value?', history })

  const requestBody = JSON.parse(fetch.mock.calls[0][1].body)
  expect(requestBody.question).toBe('What about its reset value?')
  expect(requestBody.history).toEqual(history)
})
