import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { reactive } from 'vue'
import Header from '../src/components/Header.vue'
import ChatWindow from '../src/components/ChatWindow.vue'
import ChatGeneratedFiles from '../src/components/ChatGeneratedFiles.vue'
import { getIntegrationNotifications } from '../src/api/notifications.js'
import { ASSISTANT_COMPOSE_EVENT } from '../src/utils/assistantEvents.js'

const state = vi.hoisted(() => ({
  auth: null,
  push: vi.fn(),
  route: { path: '/cad', fullPath: '/cad', query: {} },
}))
vi.mock('vue-router', () => ({
  useRouter: () => ({ push: state.push, replace: vi.fn() }),
  useRoute: () => state.route,
}))
vi.mock('../src/stores/auth.js', () => ({ useAuthStore: () => state.auth }))
vi.mock('../src/api/notifications.js', () => ({ getIntegrationNotifications: vi.fn() }))

const wrappers = []
function header() {
  const wrapper = shallowMount(Header, {
    props: { user: { name: 'Test User' } },
    global: {
      config: { warnHandler: () => {} },
      stubs: { ElPopover: { template: '<div><slot name="reference" /><slot /></div>' } },
    },
  })
  wrappers.push(wrapper)
  return wrapper
}
const updates = [1, 2].map(id => ({
  id: `jira:FW-${id}`, source: 'jira', title: `FW-${id}`, message: 'Updated bug',
  route: '/bugfix', query: { issue: `FW-${id}` },
}))

beforeEach(() => {
  localStorage.clear()
  state.auth = reactive({ isLoggedIn: true, user: { id: 'user-a', name: 'User A' } })
  vi.clearAllMocks()
  getIntegrationNotifications.mockResolvedValue({ notifications: updates })
})
afterEach(() => {
  wrappers.splice(0).forEach(wrapper => wrapper.unmount())
  vi.useRealTimers()
})

it('reports source failures without claiming there are no updates', async () => {
  getIntegrationNotifications.mockResolvedValue({ notifications: [], sources: {
    jira: { available: true, error: 'Jira updates could not be read.' }, bitbucket: { available: false },
  } })
  const wrapper = header()
  await flushPromises()
  expect(wrapper.find('.notification-error').text()).toContain('Jira updates could not be read.')
  expect(wrapper.text()).not.toContain('No recent updates assigned to you.')
})

it('opens the global assistant for Gmail without leaving the current workspace', async () => {
  const onCompose = vi.fn()
  window.addEventListener(ASSISTANT_COMPOSE_EVENT, onCompose, { once: true })
  const wrapper = header()
  await flushPromises()
  wrapper.findComponent({ name: 'ConnectedAppsDialog' }).vm.$emit('use-app', 'gmail')
  await flushPromises()
  expect(onCompose).toHaveBeenCalledTimes(1)
  expect(onCompose.mock.calls[0][0].detail.app).toBe('gmail')
  expect(state.push).not.toHaveBeenCalled()
  expect(wrapper.findComponent({ name: 'ConnectedAppsDialog' }).props('modelValue')).toBe(false)
})

it('marks only the selected update as read and isolates accounts', async () => {
  const wrapper = header()
  await flushPromises()
  expect(wrapper.find('.notification-count').text()).toBe('2')
  await wrapper.findAll('.notification-item')[0].trigger('click')
  expect(wrapper.find('.notification-count').text()).toBe('1')
  expect(state.push).toHaveBeenCalledWith({ path: '/bugfix', query: { issue: 'FW-1' } })
  state.auth.user = { id: 'user-b', name: 'User B' }
  await flushPromises()
  expect(wrapper.find('.notification-count').text()).toBe('2')
  state.auth.user = { id: 'user-a', name: 'User A' }
  await flushPromises()
  expect(wrapper.find('.notification-count').text()).toBe('1')
})

it('discards updates from a request belonging to the previous account', async () => {
  let resolveFirst
  getIntegrationNotifications.mockReturnValueOnce(new Promise(resolve => { resolveFirst = resolve }))
    .mockResolvedValueOnce({ notifications: [updates[1]] })
  const wrapper = header()
  state.auth.user = { id: 'user-b', name: 'User B' }
  await flushPromises()
  resolveFirst({ notifications: [updates[0]] })
  await flushPromises()
  expect(wrapper.findAll('.notification-item')).toHaveLength(1)
  expect(wrapper.find('.notification-item').text()).toContain('FW-2')
})

it('renders quoted code as text and copies the exact content without executable attributes', async () => {
  const code = 'const html = "<img src=x onerror=alert(1)>";\nconst text = \'single & double "\';'
  const writeText = vi.fn().mockResolvedValue(undefined)
  Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } })
  const wrapper = shallowMount(ChatWindow, {
    props: { session: { messages: [{ id: 1, role: 'assistant', content: '```js\n' + code + '\n```' }] } },
    global: { config: { warnHandler: () => {} } },
  })
  wrappers.push(wrapper)
  expect(wrapper.find('.copy-code-btn').attributes('onclick')).toBeUndefined()
  expect(wrapper.find('.msg-content img').exists()).toBe(false)
  expect(wrapper.find('pre code').text()).toBe(code)
  await wrapper.find('.copy-code-btn').trigger('click')
  await flushPromises()
  expect(writeText).toHaveBeenCalledWith(code)
})

it('renders generated document paths as openable links in ChatWindow', () => {
  const wrapper = shallowMount(ChatWindow, {
    props: {
      session: { messages: [{ id: 2, role: 'assistant', content: 'Generated: [guide.docx](/api/v1/chat/artifacts/u/s/id/guide.docx?expires=1&signature=test)' }] },
    },
    global: { config: { warnHandler: () => {} }, stubs: { ChatGeneratedFiles } },
  })
  wrappers.push(wrapper)

  const link = wrapper.find('.file-name')
  expect(link.exists()).toBe(true)
  expect(link.attributes('href')).toContain('/api/v1/chat/artifacts/u/s/id/guide.docx')
  expect(link.attributes('target')).toBe('_blank')
  expect(wrapper.find('.msg-content').exists()).toBe(false)
})
