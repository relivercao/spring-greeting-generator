import { afterEach, describe, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import ChatGeneratedFiles from '../src/components/ChatGeneratedFiles.vue'
import {
  generatedFiles,
  generatedFileDownloadUrl,
  generatedFileUrl,
  withoutGeneratedFileLines,
} from '../src/utils/generatedFiles.js'

const url = '/api/v1/chat/artifacts/user/session/document/guide.docx?expires=123&signature=a%2Bb'
const artifact = { filename: 'guide.docx', url, path: 'D:\\outputs\\guide.docx', size_bytes: 2048 }
const wrappers = []

it('requests legacy signed Chat artifacts as attachments while preserving their signature', () => {
  const downloadUrl = generatedFileDownloadUrl(url)
  const parsed = new URL(downloadUrl, 'https://local.test')
  expect(parsed.searchParams.get('signature')).toBe('a+b')
  expect(parsed.searchParams.get('download')).toBe('true')
  expect(generatedFileDownloadUrl('/api/v1/agent-generator/agents/writer/outputs/output-1'))
    .toBe('/api/v1/agent-generator/agents/writer/outputs/output-1')
})

it('adds download disposition to a durable Chat artifact URL', () => {
  const downloadUrl = generatedFileDownloadUrl('/api/v1/chat/artifacts/user/session/document/guide.docx')
  expect(downloadUrl).toBe('/api/v1/chat/artifacts/user/session/document/guide.docx?download=true')
})

function card(props) {
  const wrapper = mount(ChatGeneratedFiles, { props })
  wrappers.push(wrapper)
  return wrapper
}

afterEach(() => wrappers.splice(0).forEach(wrapper => wrapper.unmount()))

describe('generated file cards', () => {
  it('shows a downloadable PowerPoint card after restoring a signed history link', () => {
    const pptUrl = url.replace('guide.docx', 'slides.pptx')
    const wrapper = card({ content: `Generated document: [slides.pptx](${pptUrl})` })
    expect(wrapper.find('.file-name').text()).toBe('slides.pptx')
    expect(wrapper.find('.file-meta').text()).toContain('PPTX')
    expect(wrapper.find('a[download]').attributes()).toMatchObject({
      href: `${pptUrl}&download=true`,
      download: 'slides.pptx',
    })
    expect(wrapper.find('[aria-label="Open slides.pptx"]').attributes('href')).toBe(pptUrl)
  })
  it('shows one file with a native open link, type, size and local path', () => {
    const wrapper = card({
      files: [artifact],
      content: `Generated document: [${artifact.path}](${url})`,
    })
    expect(wrapper.findAll('.generated-file')).toHaveLength(1)
    expect(wrapper.find('.file-name').text()).toBe('guide.docx')
    expect(wrapper.find('.file-meta').text()).toContain('DOCX · 2.0 KB')
    expect(wrapper.find('.file-path').attributes('title')).toBe(artifact.path)
    const open = wrapper.find('.file-actions a')
    expect(open.text()).toContain('Open file')
    expect(open.attributes()).toMatchObject({
      href: url,
      target: '_blank',
      rel: 'noopener noreferrer',
    })
  })

  it('restores old message links using the filename instead of the long path label', () => {
    const wrapper = card({ content: `Generated document: [D:/outputs/guide.docx](${url})` })
    expect(wrapper.find('.file-name').text()).toBe('guide.docx')
    expect(wrapper.find('.file-name').attributes('href')).toBe(url)
    expect(withoutGeneratedFileLines(`Ready.\n\nGenerated document: [guide](${url})`)).toBe(
      'Ready.'
    )
  })

  it('normalizes generated Agent outputs without discarding their download URL', () => {
    const download = '/api/v1/agent-generator/agents/writer/outputs/output-1'
    const wrapper = card({ files: [{ name: 'result.xlsx', download_url: download, size: 4096 }] })
    expect(wrapper.find('.file-name').attributes('href')).toBe(download)
    expect(wrapper.find('a[download]').attributes('href')).toBe(download)
    expect(wrapper.find('.file-meta').text()).toContain('XLSX · 4.0 KB')
  })

  it('keeps signatures intact when copying an absolute open link', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined)
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } })
    const wrapper = card({ files: [artifact] })
    await wrapper.find('button').trigger('click')
    await flushPromises()
    expect(writeText).toHaveBeenCalledWith(new URL(url, window.location.origin).href)
    expect(wrapper.find('button').text()).toBe('Copied')
    expect(wrapper.find('[role="status"]').text()).toBe('File link copied.')
  })

  it('keeps the native link usable when clipboard access is denied', async () => {
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: { writeText: vi.fn().mockRejectedValue(new Error('Permission denied')) },
    })
    const wrapper = card({ files: [artifact] })
    await wrapper.find('button').trigger('click')
    await flushPromises()
    expect(wrapper.find('[role="alert"]').text()).toContain('Right-click the file link')
    expect(wrapper.find('.file-name').attributes('href')).toBe(url)
    expect(wrapper.find('button').text()).toBe('Copy link')
  })

  it('escapes filenames and rejects executable, protocol-relative and unrelated file targets', () => {
    const unsafe = [
      `javascript:${url}`,
      `data:text/html,${url}`,
      `//evil.example${url}`,
      `/api/v1/chat/artifacts/../../../../other.docx`,
      '/other/report.docx',
      `https://user:password@example.com${url}`,
    ]
    expect(unsafe.map(generatedFileUrl)).toEqual(unsafe.map(() => ''))
    const wrapper = card({
      files: [
        ...unsafe.map(target => ({ url: target, filename: 'unsafe.docx' })),
        { ...artifact, filename: '<img src=x onerror=alert(1)>.docx' },
      ],
    })
    expect(wrapper.findAll('.generated-file')).toHaveLength(1)
    expect(wrapper.find('img').exists()).toBe(false)
    expect(wrapper.find('.file-name').text()).toContain('<img src=x onerror=alert(1)>')
  })

  it('keeps complete and unfinished code examples out of the generated file list', () => {
    const line = `Generated document: [guide.docx](${url})`
    for (const content of [
      `\`\`\`txt\n${line}\n\`\`\``,
      `~~~txt\n${line}\n~~~`,
      `\`\`\`txt\n${line}`,
      `\`${line}\``,
    ]) {
      expect(generatedFiles([], content)).toEqual([])
      expect(withoutGeneratedFileLines(content)).toBe(content)
    }
  })
})
