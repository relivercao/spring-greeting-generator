import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { useAuthStore } from '../src/stores/auth.js'
import AgentGeneratorWorkspace from '../src/components/AgentGeneratorWorkspace.vue'
import * as api from '../src/api/agentGenerator.js'

vi.mock('../src/api/agentGenerator.js', () => ({
  generateAgent: vi.fn(), generateAgentSkillDraft: vi.fn(), getCodeParserStatus: vi.fn(),
  listAgentGeneratorTools: vi.fn(), listGeneratorKnowledgeDocuments: vi.fn(),
  uploadAgentInputFile: vi.fn(), uploadAgentLogo: vi.fn(), uploadAgentSkillFile: vi.fn(),
}))
vi.mock('../src/api/settings.js', () => ({ getProviderSettings: vi.fn().mockResolvedValue({}) }))
vi.mock('../src/api/skillMarket.js', () => ({ listInstalledMarketSkills: vi.fn().mockResolvedValue({ items: [] }) }))

const token = (sub, version = 1) => `header.${btoa(JSON.stringify({ sub, version }))}.signature`
let auth
let wrapper
function deferred() {
  let resolve
  const promise = new Promise(done => { resolve = done })
  return { promise, resolve }
}
function mount() {
  wrapper = shallowMount(AgentGeneratorWorkspace, { global: { config: { warnHandler: () => {} } } })
  return wrapper
}
const result = { agent: {
  id: 'private-agent', name: 'Private agent', system_prompt: 'Private prompt',
  knowledge_document_ids: [], warnings: [],
} }
beforeEach(() => {
  vi.useFakeTimers()
  vi.clearAllMocks()
  localStorage.clear()
  setActivePinia(createPinia())
  auth = useAuthStore()
  auth.token = token('first-user')
  api.listGeneratorKnowledgeDocuments.mockResolvedValue({ documents: [] })
  api.listAgentGeneratorTools.mockResolvedValue({ tools: [] })
})
afterEach(() => { wrapper?.unmount(); vi.useRealTimers() })

it('does not publish generation results after changing accounts and returning', async () => {
  const pending = deferred()
  api.generateAgent.mockReturnValue(pending.promise)
  mount()
  await flushPromises()
  wrapper.vm.form.prompt = 'Create a private agent'
  const generating = wrapper.vm.handleGenerate()
  auth.token = token('second-user')
  auth.token = token('first-user', 2)
  pending.resolve(result)
  await generating
  expect(wrapper.emitted('agent-created')).toBeUndefined()
  expect(wrapper.vm.lastAgent).toBeNull()
  await vi.advanceTimersByTimeAsync(24000)
  expect(api.listGeneratorKnowledgeDocuments).toHaveBeenCalledTimes(1)
})

it('does not attach an upload completed under a different account', async () => {
  const pending = deferred()
  api.uploadAgentInputFile.mockReturnValue(pending.promise)
  mount()
  await flushPromises()
  const uploading = wrapper.vm.handleFileUpload({ target: { files: [new File(['secret'], 'input.txt')], value: 'input.txt' } })
  auth.token = token('second-user')
  pending.resolve({ id: 'private-file', name: 'input.txt' })
  await uploading
  expect(wrapper.vm.form.inputFiles).toEqual([])
})

it('ignores a skill draft completed after leaving the workspace', async () => {
  const pending = deferred()
  api.generateAgentSkillDraft.mockReturnValue(pending.promise)
  mount()
  await flushPromises()
  wrapper.vm.skillDraft.name = 'private-skill'
  wrapper.vm.skillDraft.goal = 'Inspect private code'
  const generating = wrapper.vm.handleGenerateSkill()
  const draft = wrapper.vm.skillDraft
  wrapper.unmount()
  pending.resolve({ content: 'Private generated skill', warnings: [] })
  await generating
  expect(draft.content).toBe('')
})

it('preserves generation across token refresh for the same account', async () => {
  const pending = deferred()
  api.generateAgent.mockReturnValue(pending.promise)
  mount()
  await flushPromises()
  wrapper.vm.form.prompt = 'Create an agent'
  const generating = wrapper.vm.handleGenerate()
  auth.token = token('first-user', 2)
  pending.resolve(result)
  await generating
  expect(wrapper.emitted('agent-created')[0][0].id).toBe('private-agent')
})
