import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { useAuthStore } from '../src/stores/auth.js'
import router from '../src/router/index.js'
import { apiLogin } from '../src/api/auth.js'

vi.mock('../src/api/auth.js', () => ({
  apiGetProfile: vi.fn(),
  apiLogin: vi.fn(),
  apiRegister: vi.fn(),
}))

beforeEach(async () => {
  localStorage.clear()
  setActivePinia(createPinia())
  await router.push('/')
  vi.clearAllMocks()
})

afterEach(() => {
  localStorage.clear()
})

it('stores a refresh token after login without persisting the password', async () => {
  apiLogin.mockResolvedValue({
    access_token: 'access-token',
    refresh_token: 'refresh-token',
    username: 'alice',
    user: { username: 'alice', email: 'alice@example.com' },
  })

  const auth = useAuthStore()
  await auth.login('alice', 'private-password')

  expect(auth.isLoggedIn).toBe(true)
  expect(auth.refreshToken).toBe('refresh-token')
  expect(localStorage.getItem('refresh_token')).toBe('refresh-token')
  expect(localStorage.getItem('password')).toBeNull()
})

it('restores a saved guest session to the main interface after reopening the login route', async () => {
  const auth = useAuthStore()
  auth.enterGuest()

  await router.push('/login')

  expect(router.currentRoute.value.path).toBe('/')
  expect(auth.isGuest).toBe(true)
  expect(auth.hasAccess).toBe(true)
})

it('restores a saved account session to the main interface after reopening the login route', async () => {
  localStorage.setItem('token', 'persisted-access-token')
  localStorage.setItem('refresh_token', 'persisted-refresh-token')
  localStorage.setItem('user', JSON.stringify({ name: 'Alice' }))

  await router.push('/login')

  expect(router.currentRoute.value.path).toBe('/')
  expect(useAuthStore().isLoggedIn).toBe(true)
})

it('allows a guest to explicitly open account login from the main interface', async () => {
  useAuthStore().enterGuest()

  await router.push('/login?switch=1')

  expect(router.currentRoute.value.path).toBe('/login')
  expect(router.currentRoute.value.query.switch).toBe('1')
})

it('keeps anonymous visitors on the login route', async () => {
  await router.push('/login')

  expect(router.currentRoute.value.path).toBe('/login')
})
