import { afterEach, expect, it, vi } from 'vitest'
import { flushPromises } from '@vue/test-utils'
import { pollAgentTask } from '../src/api/agentTaskPoller.js'

afterEach(() => vi.useRealTimers())

it.each(['resolve', 'reject'])('discards a pending poll after cleanup on %s', async outcome => {
  vi.useFakeTimers()
  let resolve
  let reject
  const fetchTask = vi.fn(() => new Promise((done, fail) => { resolve = done; reject = fail }))
  const onData = vi.fn()
  const stop = pollAgentTask(fetchTask, onData)
  stop()
  if (outcome === 'resolve') resolve({ status: 'running', progress: 50 })
  else reject(new Error('Connection interrupted'))
  await flushPromises()
  expect(onData).not.toHaveBeenCalled()
  expect(vi.getTimerCount()).toBe(0)
  await vi.advanceTimersByTimeAsync(15000)
  expect(fetchTask).toHaveBeenCalledTimes(1)
})

it('does not schedule another poll when its callback stops observation', async () => {
  vi.useFakeTimers()
  const fetchTask = vi.fn().mockResolvedValue({ status: 'running' })
  const stop = pollAgentTask(fetchTask, () => stop())
  await flushPromises()
  expect(vi.getTimerCount()).toBe(0)
  await vi.advanceTimersByTimeAsync(15000)
  expect(fetchTask).toHaveBeenCalledTimes(1)
})
