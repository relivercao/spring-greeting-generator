import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { http } from '../src/api/http.js'

function jsonResponse(status, data) {
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: { get: () => 'application/json' },
    json: vi.fn().mockResolvedValue(data),
  }
}

beforeEach(() => {
  localStorage.clear()
  vi.stubGlobal('fetch', vi.fn())
})

afterEach(() => {
  vi.unstubAllGlobals()
  localStorage.clear()
})

it('refreshes an expired access token and retries the original request once', async () => {
  localStorage.setItem('token', 'expired-access-token')
  localStorage.setItem('refresh_token', 'valid-refresh-token')
  fetch
    .mockResolvedValueOnce(jsonResponse(401, { detail: 'Could not validate credentials' }))
    .mockResolvedValueOnce(jsonResponse(200, { access_token: 'renewed-access-token' }))
    .mockResolvedValueOnce(jsonResponse(200, { result: 'ok' }))

  const result = await http.get('/v1/private-data')

  expect(result).toEqual({ result: 'ok' })
  expect(fetch).toHaveBeenCalledTimes(3)
  expect(fetch.mock.calls[0][1].headers.Authorization).toBe('Bearer expired-access-token')
  expect(fetch.mock.calls[1][0]).toBe('/api/v1/auth/refresh')
  expect(JSON.parse(fetch.mock.calls[1][1].body)).toEqual({ refresh_token: 'valid-refresh-token' })
  expect(fetch.mock.calls[2][1].headers.Authorization).toBe('Bearer renewed-access-token')
  expect(localStorage.getItem('token')).toBe('renewed-access-token')
  expect(localStorage.getItem('refresh_token')).toBe('valid-refresh-token')
})

it('keeps the guest session when a guest-only request returns unauthorized', async () => {
  localStorage.setItem('guest', '1')
  localStorage.setItem('user', JSON.stringify({ name: 'Guest', isGuest: true }))
  const onLogout = vi.fn()
  window.addEventListener('auth:logout', onLogout)
  fetch.mockResolvedValueOnce(jsonResponse(401, { detail: 'This action requires an account' }))

  await expect(http.get('/v1/private-data')).rejects.toMatchObject({ status: 401 })

  expect(localStorage.getItem('guest')).toBe('1')
  expect(JSON.parse(localStorage.getItem('user'))).toMatchObject({ name: 'Guest', isGuest: true })
  expect(onLogout).not.toHaveBeenCalled()
  window.removeEventListener('auth:logout', onLogout)
})

it('can make public requests without attaching a stale access token', async () => {
  localStorage.setItem('token', 'expired-access-token')
  fetch.mockResolvedValueOnce(jsonResponse(200, { update_available: false }))

  const result = await http.get('/v1/version', { skipAuth: true })

  expect(result).toEqual({ update_available: false })
  expect(fetch).toHaveBeenCalledTimes(1)
  expect(fetch.mock.calls[0][1].headers.Authorization).toBeUndefined()
})

it('explains non-JSON proxy server errors instead of showing a generic request failure', async () => {
  fetch.mockResolvedValueOnce({
    ok: false,
    status: 500,
    headers: { get: () => 'text/plain' },
    json: vi.fn().mockRejectedValue(new SyntaxError('Unexpected token')),
  })

  await expect(http.get('/v1/agent-generator/agents')).rejects.toMatchObject({
    status: 500,
    message: 'The API proxy returned a non-JSON server error (HTTP 500). Check backend and proxy availability.',
  })
})

it('explains proxy upload size rejection and preserves the session', async () => {
  localStorage.setItem('token', 'valid-access-token')
  fetch.mockResolvedValueOnce({
    ok: false,
    status: 413,
    headers: { get: () => 'text/html' },
    json: vi.fn().mockRejectedValue(new SyntaxError('Unexpected token')),
  })

  await expect(http.upload('/v1/unittest/batch-tasks', new FormData())).rejects.toMatchObject({
    status: 413,
    message: 'The upload exceeds the server request size limit (HTTP 413). Upload fewer or smaller files and try again.',
  })
  expect(localStorage.getItem('token')).toBe('valid-access-token')
})

it('preserves the backend upload validation detail when it returns HTTP 413', async () => {
  fetch.mockResolvedValueOnce(jsonResponse(413, {
    detail: 'BATCH_TOTAL_SIZE_EXCEEDED: The batch exceeds the configured total size limit',
  }))

  await expect(http.upload('/v1/unittest/batch-tasks', new FormData())).rejects.toMatchObject({
    status: 413,
    message: 'BATCH_TOTAL_SIZE_EXCEEDED: The batch exceeds the configured total size limit',
  })
})

it('clears the session only when access and refresh credentials both fail', async () => {
  localStorage.setItem('token', 'expired-access-token')
  localStorage.setItem('refresh_token', 'revoked-refresh-token')
  const onLogout = vi.fn()
  window.addEventListener('auth:logout', onLogout)
  fetch
    .mockResolvedValueOnce(jsonResponse(401, { detail: 'Could not validate credentials' }))
    .mockResolvedValueOnce(jsonResponse(401, { detail: 'Token has been revoked' }))

  await expect(http.get('/v1/private-data')).rejects.toMatchObject({ status: 401 })

  expect(localStorage.getItem('token')).toBeNull()
  expect(localStorage.getItem('refresh_token')).toBeNull()
  expect(localStorage.getItem('guest')).toBeNull()
  expect(onLogout).toHaveBeenCalledTimes(1)
  window.removeEventListener('auth:logout', onLogout)
})

it('does not clear a newer login when an older request returns unauthorized', async () => {
  let rejectRequest
  localStorage.setItem('token', 'old-access-token')
  localStorage.setItem('refresh_token', 'old-refresh-token')
  const onLogout = vi.fn()
  window.addEventListener('auth:logout', onLogout)
  fetch.mockReturnValueOnce(new Promise((resolve) => {
    rejectRequest = resolve
  }))

  const request = http.get('/v1/private-data')
  localStorage.setItem('token', 'new-access-token')
  localStorage.setItem('refresh_token', 'new-refresh-token')
  localStorage.setItem('user', JSON.stringify({ name: 'New account' }))
  rejectRequest(jsonResponse(401, { detail: 'Could not validate credentials' }))

  await expect(request).rejects.toMatchObject({ status: 401 })

  expect(localStorage.getItem('token')).toBe('new-access-token')
  expect(localStorage.getItem('refresh_token')).toBe('new-refresh-token')
  expect(onLogout).not.toHaveBeenCalled()
  window.removeEventListener('auth:logout', onLogout)
})
