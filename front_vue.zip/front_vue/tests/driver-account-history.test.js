import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { nextTick } from 'vue'
import { useAuthStore } from '../src/stores/auth.js'
import { useDriverStore } from '../src/stores/driver.js'

function token(subject, version = 1) {
  return `header.${btoa(JSON.stringify({ sub: subject, version }))}.signature`
}

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
})

describe('Driver account history', () => {
  it('isolates users and restores only their own tasks after account changes', async () => {
    const auth = useAuthStore()
    auth.token = token('first-user')
    const driver = useDriverStore()
    driver.addTask({ id: 'first-task', title: 'Private driver' })
    // Switching before the persistence watcher flushes must still save to the old owner.
    auth.token = token('second-user')
    expect(driver.taskHistory).toEqual([])
    driver.addTask({ id: 'second-task' })
    await nextTick()
    auth.token = token('first-user', 2)
    expect(driver.taskHistory.map(task => task.id)).toEqual(['first-task'])
    auth.token = token('second-user', 2)
    expect(driver.taskHistory.map(task => task.id)).toEqual(['second-task'])
  })

  it('hides history after logout without erasing the owner history', async () => {
    const auth = useAuthStore()
    auth.token = token('owner')
    const driver = useDriverStore()
    driver.addTask({ id: 'owner-task' })
    auth.logout()
    expect(driver.taskHistory).toEqual([])
    await nextTick()
    auth.token = token('owner')
    expect(driver.taskHistory.map(task => task.id)).toEqual(['owner-task'])
  })

  it('preserves unowned legacy data without assigning it to the current account', () => {
    const legacy = JSON.stringify([{ id: 'unknown-owner', title: 'Private result' }])
    localStorage.setItem('agent_driver_history', legacy)
    const auth = useAuthStore()
    auth.token = token('new-user')
    expect(useDriverStore().taskHistory).toEqual([])
    expect(localStorage.getItem('agent_driver_history')).toBe(legacy)
  })

  it('separates guest work and does not persist tokens when credentials are malformed', async () => {
    const auth = useAuthStore()
    auth.enterGuest()
    const driver = useDriverStore()
    driver.addTask({ id: 'guest-task' })
    auth.token = token('member')
    expect(driver.taskHistory).toEqual([])
    auth.token = 'invalid-private-token'
    driver.addTask({ id: 'untrusted-task' })
    await nextTick()
    expect(JSON.stringify(localStorage)).not.toContain('invalid-private-token')
    auth.token = ''
    expect(driver.taskHistory.map(task => task.id)).toEqual(['guest-task'])
  })
})
