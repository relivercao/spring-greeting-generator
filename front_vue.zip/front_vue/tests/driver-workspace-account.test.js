import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { flushPromises, shallowMount } from '@vue/test-utils'
import { useAuthStore } from '../src/stores/auth.js'
import DriverWorkspace from '../src/components/DriverWorkspace.vue'
import * as api from '../src/api/driver.js'

vi.mock('../src/api/driver.js', () => ({
  apiUploadDriverSources: vi.fn(), apiGenerateDriver: vi.fn(), apiPollDriverTask: vi.fn(),
  apiGetDriverArtifacts: vi.fn(), apiGetDriverTask: vi.fn(), apiCancelDriverTask: vi.fn(),
  isTransientDriverError: vi.fn(() => false),
}))

const token = sub => `header.${btoa(JSON.stringify({ sub }))}.signature`
const wrappers = []
let auth

function deferred() {
  let resolve
  let reject
  const promise = new Promise((done, fail) => { resolve = done; reject = fail })
  return { promise, resolve, reject }
}

function mount(status = 'running', listener = vi.fn()) {
  const wrapper = shallowMount(DriverWorkspace, {
    props: {
      activeTask: { id: 'private-card', status, driverState: { driverTaskId: 'server-task' } },
      onTaskUpdated: listener,
    },
    global: { config: { warnHandler: () => {} } },
  })
  wrappers.push(wrapper)
  return { wrapper, listener }
}

beforeEach(() => {
  localStorage.clear()
  setActivePinia(createPinia())
  auth = useAuthStore()
  auth.token = token('first-user')
  vi.resetAllMocks()
  api.apiPollDriverTask.mockReturnValue(vi.fn())
  vi.spyOn(console, 'log').mockImplementation(() => {})
})

afterEach(() => {
  wrappers.splice(0).forEach(wrapper => wrapper.unmount())
  vi.useRealTimers()
})

it('discards old poll callbacks after leaving and returning to the same account', async () => {
  const { listener } = mount()
  await flushPromises()
  listener.mockClear()
  const poll = api.apiPollDriverTask.mock.calls[0][1]
  const stop = api.apiPollDriverTask.mock.results[0].value
  auth.logout()
  auth.token = token('first-user')
  await poll({ status: 'running', state_data: { progress: 40 } })
  expect(stop).toHaveBeenCalled()
  expect(listener).not.toHaveBeenCalled()
})

it('does not attach a late upload to another account', async () => {
  const upload = deferred()
  api.apiUploadDriverSources.mockReturnValue(upload.promise)
  const { wrapper, listener } = mount('idle')
  await flushPromises()
  listener.mockClear()
  const pending = wrapper.vm.addKnowledgeBaseFiles([new File(['private'], 'private.txt')])
  auth.token = token('second-user')
  upload.resolve({ sources: [{ source_id: 'source-a', name: 'private.txt', size: 7 }] })
  await pending
  expect(listener).not.toHaveBeenCalled()
})

it('discards an artifact response after the workspace is unmounted', async () => {
  const artifacts = deferred()
  api.apiGetDriverArtifacts.mockReturnValue(artifacts.promise)
  const { wrapper, listener } = mount('completed')
  await flushPromises()
  expect(api.apiGetDriverArtifacts).toHaveBeenCalledTimes(1)
  listener.mockClear()
  wrapper.unmount()
  artifacts.resolve({ artifacts: [{ name: 'private.c', content: 'private' }] })
  await flushPromises()
  expect(listener).not.toHaveBeenCalled()
})

it('does not persist a late cancel result into a new account', async () => {
  const cancellation = deferred()
  api.apiCancelDriverTask.mockReturnValue(cancellation.promise)
  const { wrapper, listener } = mount()
  await flushPromises()
  listener.mockClear()
  const pending = wrapper.vm.cancelTask()
  auth.token = token('second-user')
  cancellation.resolve({ status: 'cancelled', cancelled: true })
  await pending
  expect(listener).not.toHaveBeenCalled()
})

it('stops artifact retries before another account can issue the next request', async () => {
  vi.useFakeTimers()
  api.apiGetDriverArtifacts.mockRejectedValue(new Error('Artifacts are not ready'))
  mount('completed')
  await flushPromises()
  expect(api.apiGetDriverArtifacts).toHaveBeenCalledTimes(1)
  auth.token = token('second-user')
  await vi.advanceTimersByTimeAsync(1000)
  expect(api.apiGetDriverArtifacts).toHaveBeenCalledTimes(1)
})

it('ignores a generation accepted after its owner leaves the workspace', async () => {
  const generation = deferred()
  api.apiGenerateDriver.mockReturnValue(generation.promise)
  const { wrapper, listener } = mount('idle')
  await flushPromises()
  const pending = wrapper.vm.startGeneration('Generate an I2C driver')
  const taskId = api.apiGenerateDriver.mock.calls[0][0].task_id
  listener.mockClear()
  auth.token = token('second-user')
  generation.resolve({ task_id: taskId, session_id: 'owner-session' })
  await pending
  expect(listener).not.toHaveBeenCalled()
  expect(api.apiGetDriverTask).not.toHaveBeenCalled()
})

it('keeps monitoring across token refresh for the same account', async () => {
  const { listener } = mount()
  await flushPromises()
  listener.mockClear()
  auth.token = `header.${btoa(JSON.stringify({ sub: 'first-user', version: 2 }))}.signature`
  const poll = api.apiPollDriverTask.mock.calls[0][1]
  await poll({ status: 'running', state_data: { progress: 40 } })
  expect(listener).toHaveBeenCalledWith(expect.objectContaining({ progress: 40 }))
})

it('keeps monitoring when the server protects a finalizing task from cancellation', async () => {
  api.apiCancelDriverTask.mockResolvedValue({ status: 'running', cancelled: false, reason: 'Finalizing artifacts' })
  const { wrapper, listener } = mount()
  await flushPromises()
  listener.mockClear()
  const stop = api.apiPollDriverTask.mock.results[0].value
  await wrapper.vm.cancelTask()
  expect(stop).not.toHaveBeenCalled()
  expect(wrapper.vm.phase).toBe('running')
  expect(wrapper.vm.isCancellingTask).toBe(false)
  expect(wrapper.vm.pollingNotice).toContain('Finalizing artifacts')
  expect(listener.mock.calls.every(([update]) => update.status !== 'cancelled')).toBe(true)
})

it('retains current progress and observation after a cancellation error', async () => {
  api.apiCancelDriverTask.mockRejectedValue(new Error('Network unavailable'))
  const { wrapper } = mount()
  await flushPromises()
  const stop = api.apiPollDriverTask.mock.results[0].value
  await wrapper.vm.cancelTask()
  expect(stop).not.toHaveBeenCalled()
  expect(wrapper.vm.phase).toBe('running')
  await api.apiPollDriverTask.mock.calls[0][1]({ status: 'running', state_data: { progress: 75 } })
  expect(wrapper.vm.currentProgress).toBe(75)
})

it.each(['reject', 'resolve'])('preserves completion when a late cancellation settles by %s', async outcome => {
  const cancellation = deferred()
  api.apiCancelDriverTask.mockReturnValue(cancellation.promise)
  api.apiGetDriverArtifacts.mockResolvedValue({ artifacts: [{ name: 'driver.c', content: 'generated' }] })
  const { wrapper } = mount()
  await flushPromises()
  const pending = wrapper.vm.cancelTask()
  await api.apiPollDriverTask.mock.calls[0][1]({ status: 'completed' })
  if (outcome === 'reject') cancellation.reject(new Error('Late failure'))
  else cancellation.resolve({ status: 'cancelled', cancelled: true })
  await pending
  expect(wrapper.vm.phase).toBe('done')
  expect(wrapper.vm.currentProgress).toBe(100)
  expect(wrapper.vm.generatedCodeTabs[0].content).toBe('generated')
})

it('does not let an old cancellation release the next task cancellation control', async () => {
  const cancellation = deferred()
  api.apiCancelDriverTask.mockReturnValueOnce(cancellation.promise)
  const { wrapper } = mount()
  await flushPromises()
  const oldRequest = wrapper.vm.cancelTask()
  await wrapper.setProps({ activeTask: {
    id: 'next-card', status: 'running', driverState: { driverTaskId: 'next-server-task' },
  } })
  expect(wrapper.vm.isCancellingTask).toBe(false)
  api.apiCancelDriverTask.mockReturnValueOnce(new Promise(() => {}))
  wrapper.vm.cancelTask()
  cancellation.resolve({ status: 'cancelled', cancelled: true })
  await oldRequest
  expect(wrapper.vm.currentDriverTaskId).toBe('next-server-task')
  expect(wrapper.vm.phase).toBe('running')
  expect(wrapper.vm.isCancellingTask).toBe(true)
})
