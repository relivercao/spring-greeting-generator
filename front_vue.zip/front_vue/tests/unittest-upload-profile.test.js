import { expect, it, vi } from 'vitest'
import { apiCreateBatchTask, apiGenerateTests } from '../src/api/unittest.js'
import { http } from '../src/api/http.js'

vi.mock('../src/api/http.js', () => ({ http: { upload: vi.fn() } }))

it.each([undefined, 'custom-toolchain'])('uses server profile selection while preserving explicit profile %s', async profile => {
  http.upload.mockResolvedValue({ task_id: 'fixture-task' })
  await apiGenerateTests(new File(['int value(void) { return 1; }'], 'module.c'), { build_profile: profile })
  const [, form] = http.upload.mock.calls.at(-1)
  expect(form.get('build_profile')).toBe(profile || 'auto')
  expect(form.get('compile_verify')).toBe('true')
})

it('sends the explicit browser upload mode with ordered batch paths', async () => {
  const files = [new File(['int value;'], 'module.c')]
  await apiCreateBatchTask(files, { source_paths: ['project/src/module.c'], source_mode: 'upload' })
  const [path, form] = http.upload.mock.calls.at(-1)
  expect(path).toBe('/v1/unittest/batch-tasks')
  expect(form.get('source_mode')).toBe('upload')
  expect(JSON.parse(form.get('source_paths_json'))).toEqual(['project/src/module.c'])
})
