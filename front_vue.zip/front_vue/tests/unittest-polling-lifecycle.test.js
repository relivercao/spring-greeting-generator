import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { apiPollTask } from '../src/api/unittest.js'
import { http } from '../src/api/http.js'

vi.mock('../src/api/http.js', () => ({ http: { get: vi.fn() } }))

let settle

beforeEach(() => {
  vi.useFakeTimers()
  http.get.mockReset()
  vi.spyOn(console, 'error').mockImplementation(() => {})
})

afterEach(() => {
  vi.useRealTimers()
  vi.restoreAllMocks()
})

it.each(['resolve', 'reject'])('does not resume or publish after stopping an in-flight %s', async outcome => {
  http.get.mockReturnValue(new Promise((resolve, reject) => { settle = { resolve, reject } }))
  const onData = vi.fn()
  const stop = apiPollTask('task-a', onData)
  stop()
  if (outcome === 'resolve') settle.resolve({ status: 'running', progress: 30 })
  else settle.reject(new Error('Fixture request ended'))
  await vi.advanceTimersByTimeAsync(20000)
  expect(onData).not.toHaveBeenCalled()
  expect(http.get).toHaveBeenCalledTimes(1)
  expect(vi.getTimerCount()).toBe(0)
})

it('stops when the callback closes the workspace', async () => {
  http.get.mockResolvedValue({ status: 'running', progress: 30 })
  let stop
  const onData = vi.fn(() => stop())
  stop = apiPollTask('task-a', onData)
  await vi.advanceTimersByTimeAsync(20000)
  expect(onData).toHaveBeenCalledTimes(1)
  expect(http.get).toHaveBeenCalledTimes(1)
  expect(vi.getTimerCount()).toBe(0)
})

it('continues observation until the real task becomes terminal', async () => {
  http.get.mockResolvedValueOnce({ status: 'running', progress: 30 })
    .mockResolvedValueOnce({ status: 'completed', progress: 100 })
  const onData = vi.fn()
  apiPollTask('task-a', onData)
  await vi.advanceTimersByTimeAsync(20000)
  expect(onData.mock.calls.map(([data]) => data.status)).toEqual(['running', 'completed'])
  expect(http.get).toHaveBeenCalledTimes(2)
  expect(vi.getTimerCount()).toBe(0)
})

it.each([500, 502, 503, 504, 408, 429, undefined])(
  'recovers from a temporary polling error (%s) without marking generation failed', async status => {
    const error = Object.assign(new Error('Temporary progress request failure'), { status })
    const completed = { status: 'completed', progress: 100, result: { test_files: [{ filename: 'tc-module.cpp' }] } }
    http.get.mockRejectedValueOnce(error).mockResolvedValueOnce(completed)
    const onData = vi.fn()
    apiPollTask('task-a', onData)

    await vi.advanceTimersByTimeAsync(0)
    expect(onData.mock.calls.map(([data]) => data.status)).not.toContain('failed')
    expect(vi.getTimerCount()).toBe(1)

    await vi.advanceTimersByTimeAsync(20000)
    expect(onData).toHaveBeenLastCalledWith(completed)
    expect(http.get).toHaveBeenCalledTimes(2)
    expect(vi.getTimerCount()).toBe(0)
  },
)

it.each([403, 404])('stops polling when access cannot be recovered (%s)', async status => {
  http.get.mockRejectedValue(Object.assign(new Error('Task is unavailable'), { status }))
  const onData = vi.fn()
  apiPollTask('task-a', onData)
  await vi.advanceTimersByTimeAsync(20000)
  expect(http.get).toHaveBeenCalledTimes(1)
  expect(onData).toHaveBeenCalledWith({ status: 'failed', error: 'Task is unavailable' })
  expect(vi.getTimerCount()).toBe(0)
})

it('preserves a real generation failure received after temporary progress errors', async () => {
  const failure = { status: 'failed', error: 'The compiler rejected the generated source' }
  http.get.mockRejectedValueOnce(Object.assign(new Error('Server unavailable'), { status: 503 }))
    .mockRejectedValueOnce(new TypeError('Failed to fetch'))
    .mockResolvedValueOnce(failure)
  const onData = vi.fn()
  apiPollTask('task-a', onData)
  await vi.advanceTimersByTimeAsync(20000)
  expect(onData.mock.calls.map(([data]) => data.status)).toEqual([
    'connection_retrying', 'connection_retrying', 'failed',
  ])
  expect(onData).toHaveBeenLastCalledWith(failure)
  expect(vi.getTimerCount()).toBe(0)
})

it('stops automatic retries when the workspace is closed', async () => {
  http.get.mockRejectedValue(Object.assign(new Error('Server unavailable'), { status: 500 }))
  const onData = vi.fn()
  const stop = apiPollTask('task-a', onData)
  await vi.advanceTimersByTimeAsync(0)
  stop()
  await vi.advanceTimersByTimeAsync(20000)
  expect(http.get).toHaveBeenCalledTimes(1)
  expect(onData).toHaveBeenCalledTimes(1)
  expect(vi.getTimerCount()).toBe(0)
})
