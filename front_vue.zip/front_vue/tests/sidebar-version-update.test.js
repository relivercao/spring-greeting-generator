import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import Sidebar from '../src/components/Sidebar.vue'

const stubs = {
  ElTooltip: { template: '<div><slot /></div>' },
  ElIcon: { template: '<i><slot /></i>' },
  Cpu: true,
  CollectionTag: true,
}

function mountSidebar(versionUpdateAvailable) {
  return mount(Sidebar, {
    props: {
      agents: [],
      history: [],
      versionUpdateAvailable,
    },
    global: { stubs },
  })
}

describe('home version update indicator', () => {
  it('shows a blue dot on Home when an update is available', () => {
    const wrapper = mountSidebar(true)

    expect(wrapper.find('.home-update-dot').exists()).toBe(true)
    expect(wrapper.find('.home-update-dot').attributes('aria-label')).toBe('Version update available')
    wrapper.unmount()
  })

  it('does not show the dot when the running version is current', () => {
    const wrapper = mountSidebar(false)

    expect(wrapper.find('.home-update-dot').exists()).toBe(false)
    wrapper.unmount()
  })
})
