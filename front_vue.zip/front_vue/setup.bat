@echo off

:: Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: Node.js not found. Please install Node.js 16+ version.
    echo Download: https://nodejs.org/en/download/
    pause
    exit /b 1
)

echo Detected Node.js version:
node -v
echo.

echo Installing dependencies (using China mirror for acceleration)...
npm install --registry https://registry.npmmirror.com

if %errorlevel% neq 0 (
    echo Error: Failed to install dependencies.
    pause
    exit /b 1
)

echo Dependencies installed successfully!
echo.
echo Starting development server...
npm run dev
