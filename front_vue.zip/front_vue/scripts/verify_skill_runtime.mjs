// Isolated browser fixture: never modifies a user's workspace or task history.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { mkdir } from 'node:fs/promises'
import path from 'node:path'

const require = createRequire(import.meta.url)
const { chromium } = require(process.env.PLAYWRIGHT_MODULE_PATH || 'playwright')
const origin = process.env.FRONTEND_URL || 'http://127.0.0.1:5173'
const output = path.resolve(process.env.UI_VERIFY_OUTPUT || '../backend/logs/skill-ui-verification')
await mkdir(output, { recursive: true })
const browser = await chromium.launch({ headless: true, channel: process.env.BROWSER_CHANNEL || undefined })
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 820 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(`${origin}/unittest`)
    await page.waitForSelector('#app')
    await page.evaluate(async () => {
      const { createApp, h } = await import('/node_modules/.vite/deps/vue.js')
      const { default: SkillRuntimeTrace } = await import('/src/components/SkillRuntimeTrace.vue')
      const host = document.createElement('main')
      host.style.cssText = 'padding:16px;max-width:100%;box-sizing:border-box;font-family:Arial,sans-serif;background:white;color:#111827'
      document.body.replaceChildren(host)
      const traces = [{
        task_id: 'isolated-ui-fixture', stage: 'compile_repair', scope: 'project/apps/engine/src/engine.c',
        status: 'prepared', attempt: 2,
        skills: [{ name: 'unittest-build-repair', version: 1, sha256: '1'.repeat(64), references: [] }],
        actions: [{ name: 'compiler_diagnostics', status: 'completed', evidence: {
          first_diagnostic: { message: "error: unknown type name 'QueueHandle_t'" }, total: 1,
        } }],
      }]
      createApp({ render: () => h(SkillRuntimeTrace, { traces }) }).mount(host)
    })
    await page.getByText('Skill collaboration', { exact: false }).click()
    await page.getByText('compiler_diagnostics', { exact: false }).click()
    assert.match(await page.locator('pre').innerText(), /QueueHandle_t/)
    assert.match(await page.locator('.skill-stage-heading').innerText(), /prepared/)
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth), false)
    assert.deepEqual(errors, [])
    await page.screenshot({ path: path.join(output, `skill-runtime-${width}.png`), fullPage: true })
    await page.close()
    console.log(`Skill runtime panel passed at ${width}px`)
  }
} finally {
  await browser.close()
}
