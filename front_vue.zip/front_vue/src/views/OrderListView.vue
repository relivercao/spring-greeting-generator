<template>
  <div class="payment-page">
    <!-- Top bar -->
    <header class="page-header">
      <button
        type="button"
        class="back-link"
        @click="router.push('/')"
      >
        <el-icon size="14">
          <ArrowLeft />
        </el-icon>
        <span>Back to App</span>
      </button>
      <h1 class="page-title">
        My orders
      </h1>
      <div class="header-spacer" />
      <el-button
        type="primary"
        plain
        @click="router.push('/recharge')"
      >
        <el-icon
          size="14"
          style="margin-right: 4px"
        >
          <Plus />
        </el-icon>
        Recharge
      </el-button>
    </header>

    <main class="page-body">
      <div class="table-card">
        <el-table
          v-loading="loading"
          :data="orders"
          stripe
          style="width: 100%"
        >
          <el-table-column
            prop="out_trade_no"
            label="Order no."
            min-width="220"
          >
            <template #default="{ row }">
              <span class="mono">{{ row.out_trade_no || row.id }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="Amount"
            width="110"
            align="right"
          >
            <template #default="{ row }">
              {{ formatMoney(row.pay_amount ?? row.amount) }}
            </template>
          </el-table-column>
          <el-table-column
            label="Type"
            width="100"
          >
            <template #default="{ row }">
              {{ orderTypeLabel(row.order_type) }}
            </template>
          </el-table-column>
          <el-table-column
            label="Status"
            width="120"
          >
            <template #default="{ row }">
              <el-tag
                :type="statusTagType(row.status)"
                size="small"
              >
                {{ statusLabel(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column
            label="Created at"
            min-width="170"
          >
            <template #default="{ row }">
              {{ formatTime(row.created_at) }}
            </template>
          </el-table-column>
          <el-table-column
            label="Actions"
            width="190"
            fixed="right"
          >
            <template #default="{ row }">
              <template v-if="row.status === 'pending'">
                <el-button
                  link
                  type="primary"
                  @click="continuePay(row)"
                >
                  Continue pay
                </el-button>
                <el-button
                  link
                  type="danger"
                  @click="cancelOrder(row)"
                >
                  Cancel
                </el-button>
              </template>
              <span
                v-else
                class="no-action"
              >-</span>
            </template>
          </el-table-column>
          <template #empty>
            <el-empty description="No orders yet. Start a recharge to see it here." />
          </template>
        </el-table>

        <div class="pagination-row">
          <el-pagination
            v-model:current-page="page"
            v-model:page-size="pageSize"
            :total="total"
            :page-sizes="[10, 20, 50]"
            layout="total, sizes, prev, pager, next"
            background
            @current-change="fetchOrders"
            @size-change="handleSizeChange"
          />
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { apiMyOrders, apiCancelOrder } from '@/api/payment'

const router = useRouter()

const loading  = ref(false)
const orders   = ref([])
const total    = ref(0)
const page     = ref(1)
const pageSize = ref(10)

// ── Helpers ──
function formatMoney(value) {
  const num = Number(value)
  return `¥${(Number.isFinite(num) ? num : 0).toFixed(2)}`
}

function parseServerTime(value) {
  if (typeof value !== 'string') return new Date(value)
  // Server datetimes are UTC but may omit the timezone marker; add it so parsing is correct
  return new Date(/Z$|[+-]\d{2}:?\d{2}$/.test(value) ? value : `${value}Z`)
}

function formatTime(value) {
  if (!value) return '-'
  const date = parseServerTime(value)
  if (Number.isNaN(date.getTime())) return String(value)
  return date.toLocaleString()
}

function orderTypeLabel(type) {
  if (type === 'plan') return 'Plan'
  if (type === 'balance') return 'Balance'
  return type || '-'
}

function statusLabel(status) {
  const labels = {
    pending: 'Pending',
    paid: 'Paid',
    recharging: 'Crediting',
    completed: 'Completed',
    expired: 'Expired',
    cancelled: 'Cancelled',
    failed: 'Failed',
    refunded: 'Refunded',
  }
  return labels[status] || status || '-'
}

function statusTagType(status) {
  const types = {
    pending: 'warning',
    paid: 'primary',
    recharging: 'primary',
    completed: 'success',
    expired: 'info',
    cancelled: 'info',
    failed: 'danger',
    refunded: 'info',
  }
  return types[status] || 'info'
}

// ── Data loading ──
async function fetchOrders() {
  loading.value = true
  try {
    const data = await apiMyOrders({ page: page.value, page_size: pageSize.value })
    orders.value = data?.items || data?.orders || []
    total.value = Number(data?.total ?? data?.total_count) || orders.value.length
  } catch (e) {
    ElMessage.error(e.message || 'Failed to load orders.')
  } finally {
    loading.value = false
  }
}

function handleSizeChange() {
  // Changing the page size jumps back to the first page to avoid out-of-range requests
  page.value = 1
  fetchOrders()
}

// ── Actions ──
function continuePay(row) {
  router.push(`/payment/${row.id}`)
}

async function cancelOrder(row) {
  try {
    await ElMessageBox.confirm(
      `Cancel order ${row.out_trade_no || row.id}? The pending payment will be voided.`,
      'Cancel order',
      { confirmButtonText: 'Cancel order', cancelButtonText: 'Keep it', type: 'warning' }
    )
  } catch {
    // User dismissed the dialog; nothing to do
    return
  }
  try {
    await apiCancelOrder(row.id)
    ElMessage.success('Order cancelled.')
    fetchOrders()
  } catch (e) {
    ElMessage.error(e.message || 'Failed to cancel the order.')
  }
}

onMounted(fetchOrders)
</script>

<style scoped>
.payment-page {
  min-height: 100vh;
  background: #f0f4ff;
  display: flex;
  flex-direction: column;
}

/* ── Top bar ── */
.page-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 32px;
  background: #ffffff;
  border-bottom: 1px solid #e8edf3;
}

.back-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: none;
  background: transparent;
  color: #6b7280;
  font-size: 13px;
  cursor: pointer;
  padding: 6px 10px;
  border-radius: 7px;
  transition: color 0.2s, background 0.2s;
}

.back-link:hover { color: #2563eb; background: #eff6ff; }

.page-title {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
  margin: 0;
}

.header-spacer { flex: 1; }

/* ── Body ── */
.page-body {
  flex: 1;
  width: 100%;
  max-width: 1040px;
  margin: 0 auto;
  padding: 28px 24px 48px;
}

.table-card {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 18px 20px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
}

.no-action { color: #c4c9d4; }

.pagination-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}

/* ── Responsive ── */
@media (max-width: 768px) {
  .page-header { padding: 12px 16px; }
  .page-body { padding: 20px 16px 40px; }
  .table-card { padding: 12px; overflow-x: auto; }
}
</style>
