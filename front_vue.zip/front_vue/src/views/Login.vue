<template>
  <div class="auth-page">
    <canvas
      ref="canvasRef"
      class="bg-canvas"
    />
    <div class="glow glow-1" />
    <div class="glow glow-2" />

    <!-- Left brand section -->
    <div class="brand-panel">
      <!-- Decorative floating circles -->
      <div class="deco-circle deco-c1" />
      <div class="deco-circle deco-c2" />
      <div class="deco-circle deco-c3" />

      <div class="brand-logo">
        <div class="brand-logo-icon">
          <el-icon size="28">
            <Cpu />
          </el-icon>
        </div>
        <span class="brand-name">Macode</span>
      </div>

      <div class="brand-content">
        <h1 class="brand-headline">
          Let AI Understand<br>
          <span class="gradient-text">Every Line of Firmware Code</span>
        </h1>
        <p class="brand-desc">
          An AI collaboration platform built specifically for embedded engineers,
          Deeply understands MCU architecture and peripheral drivers.
        </p>

        <ul class="feature-list">
          <li
            v-for="(f, i) in features"
            :key="f.text"
            class="feature-item"
            :style="{ animationDelay: `${0.4 + i * 0.1}s` }"
          >
            <div class="feature-dot" />
            <span>{{ f.text }}</span>
          </li>
        </ul>
      </div>

      <p class="brand-footer">
        © 2026 relivercao@gmail.com · Embedded AI Agent Platform
      </p>
    </div>

    <!-- Right login section -->
    <div class="auth-panel">
      <div class="auth-card">
        <!-- Title -->
        <div class="auth-title">
          <h2>{{ mode === 'login' ? 'Welcome Back' : 'Create Account' }}</h2>
          <p>{{ mode === 'login' ? 'Sign in to continue using Macode' : 'Join the Macode Platform' }}</p>
        </div>

        <!-- Tab -->
        <div class="auth-tabs">
          <button
            class="tab-btn"
            :class="{ active: mode === 'login' }"
            @click="switchMode('login')"
          >
            Login
          </button>
          <button
            class="tab-btn"
            :class="{ active: mode === 'register' }"
            @click="switchMode('register')"
          >
            Register
          </button>
          <div
            class="tab-indicator"
            :class="{ right: mode === 'register' }"
          />
        </div>

        <!-- Error / Success -->
        <div
          v-if="errorMsg"
          class="error-banner"
        >
          <el-icon size="13">
            <Warning />
          </el-icon>{{ errorMsg }}
        </div>
        <div
          v-if="successMsg"
          class="success-banner"
        >
          <el-icon size="13">
            <CircleCheck />
          </el-icon>{{ successMsg }}
        </div>

        <!-- Login form -->
        <form
          v-if="mode === 'login'"
          class="auth-form"
          @submit.prevent="handleLogin"
        >
          <div class="form-group">
            <label class="form-label">Username</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <User />
              </el-icon>
              <input
                v-model="loginForm.username"
                type="text"
                class="form-input"
                placeholder="Enter your username"
                autocomplete="username"
                required
              >
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Lock />
              </el-icon>
              <input
                v-model="loginForm.password"
                :type="showPassword ? 'text' : 'password'"
                class="form-input"
                placeholder="Enter your password"
                autocomplete="current-password"
                required
              >
              <button
                type="button"
                class="eye-btn"
                @click="showPassword = !showPassword"
              >
                <el-icon><component :is="showPassword ? 'Hide' : 'View'" /></el-icon>
              </button>
            </div>
          </div>

          <button
            type="submit"
            class="submit-btn"
            :class="{ loading: isLoading }"
            :disabled="isLoading"
          >
            <span
              v-if="isLoading"
              class="spinner"
            />
            <span>{{ isLoading ? 'Logging in...' : 'Login' }}</span>
            <el-icon
              v-if="!isLoading"
              size="14"
            >
              <Right />
            </el-icon>
          </button>

          <p class="switch-hint">
            Don't have an account? <a
              href="#"
              @click.prevent="switchMode('register')"
            >Register now</a>
          </p>

          <div class="guest-divider">
            <span>Or</span>
          </div>
          <button
            type="button"
            class="guest-btn"
            @click="enterGuest"
          >
            <el-icon size="14">
              <User />
            </el-icon>
            Continue as Guest
          </button>
        </form>

        <!-- Registration form -->
        <form
          v-if="mode === 'register'"
          class="auth-form"
          @submit.prevent="handleRegister"
        >
          <div class="form-group">
            <label class="form-label">Username</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <User />
              </el-icon>
              <input
                v-model="registerForm.username"
                type="text"
                class="form-input"
                placeholder="Set username"
                autocomplete="username"
                required
              >
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Email</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Message />
              </el-icon>
              <input
                v-model="registerForm.email"
                type="email"
                class="form-input"
                placeholder="your@email.com"
                autocomplete="email"
                required
              >
            </div>
          </div>

          <!-- Email verification code (only when the backend requires email verification) -->
          <div
            v-if="regOptions.email_verify_enabled"
            class="form-group"
          >
            <label class="form-label">Email Code</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Key />
              </el-icon>
              <input
                v-model="registerForm.email_code"
                type="text"
                class="form-input has-code-btn"
                placeholder="Enter the code from your email"
                autocomplete="one-time-code"
                required
              >
              <button
                type="button"
                class="code-btn"
                :disabled="sendCodeCooldown > 0 || sendingCode || !registerForm.email"
                @click="handleSendCode"
              >
                {{ sendCodeCooldown > 0 ? `${sendCodeCooldown}s` : 'Send code' }}
              </button>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Lock />
              </el-icon>
              <input
                v-model="registerForm.password"
                :type="showPassword ? 'text' : 'password'"
                class="form-input"
                placeholder="At least 8 characters"
                autocomplete="new-password"
                required
                minlength="5"
              >
              <button
                type="button"
                class="eye-btn"
                @click="showPassword = !showPassword"
              >
                <el-icon><component :is="showPassword ? 'Hide' : 'View'" /></el-icon>
              </button>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Confirm Password</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Lock />
              </el-icon>
              <input
                v-model="registerForm.confirm"
                :type="showPassword ? 'text' : 'password'"
                class="form-input"
                placeholder="Enter password again"
                autocomplete="new-password"
                required
              >
            </div>
            <p
              v-if="registerForm.confirm && registerForm.password !== registerForm.confirm"
              class="field-hint error"
            >
              Passwords do not match
            </p>
          </div>

          <!-- Invite code (only when registration requires an invite) -->
          <div
            v-if="regOptions.invite_required"
            class="form-group"
          >
            <label class="form-label">Invite Code</label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Ticket />
              </el-icon>
              <input
                v-model="registerForm.invite_code"
                type="text"
                class="form-input"
                placeholder="Enter invite code"
                autocomplete="off"
                required
              >
            </div>
          </div>

          <!-- Optional promo code -->
          <div class="form-group">
            <label class="form-label">Promo Code <span class="label-optional">(optional)</span></label>
            <div class="input-wrap">
              <el-icon class="input-icon">
                <Discount />
              </el-icon>
              <input
                v-model="registerForm.promo_code"
                type="text"
                class="form-input"
                placeholder="Enter promo code if you have one"
                autocomplete="off"
              >
            </div>
          </div>

          <button
            type="submit"
            class="submit-btn"
            :class="{ loading: isLoading }"
            :disabled="isLoading || registerForm.password !== registerForm.confirm"
          >
            <span
              v-if="isLoading"
              class="spinner"
            />
            <span>{{ isLoading ? 'Creating...' : 'Create Account' }}</span>
            <el-icon
              v-if="!isLoading"
              size="14"
            >
              <Right />
            </el-icon>
          </button>

          <p class="switch-hint">
            Already have an account? <a
              href="#"
              @click.prevent="switchMode('login')"
            >Sign in</a>
          </p>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '../stores/auth.js'
import { apiSendEmailCode, apiGetRegistrationOptions } from '@/api/auth'

const emit = defineEmits(['login-success'])

const route        = useRoute()
const router       = useRouter()
const authStore    = useAuthStore()
const mode         = ref(route.meta.mode || 'login')
const isLoading    = ref(false)
const errorMsg     = ref('')
const successMsg   = ref('')
const showPassword = ref(false)

const loginForm    = reactive({ username: '', password: '' })
const registerForm = reactive({
  username:    '',
  email:       '',
  password:    '',
  confirm:     '',
  email_code:  '',
  invite_code: '',
  promo_code:  '',
})

// Registration toggles fetched from the backend; defaults keep the form minimal
const regOptions       = reactive({ email_verify_enabled: false, invite_required: false })
const sendCodeCooldown = ref(0)
const sendingCode      = ref(false)
let cooldownTimer      = null

const features = [
  { text: 'AI automatically generates peripheral drivers and HAL adaptation layers' },
  { text: 'One-click unit test generation covering interrupts and boundary conditions' },
  { text: 'MCU code review detects register configuration error risks' },
  { text: 'Private knowledge base for quick datasheet and specification lookup' },
]

// Floating particle background
const canvasRef = ref(null)
let animFrame = null
let resizeHandler = null

onMounted(() => {
  const canvas = canvasRef.value
  const ctx = canvas.getContext('2d')
  const COUNT = 40
  let particles = []

  function resize() {
    // Cover only the left area (full page width minus the 480px right login panel) to reduce computation
    canvas.width  = Math.max(window.innerWidth - 480, 300)
    canvas.height = window.innerHeight
  }

  function init() {
    particles = Array.from({ length: COUNT }, () => ({
      x:     Math.random() * canvas.width,
      y:     Math.random() * canvas.height,
      r:     Math.random() * 1.6 + 0.4,
      vx:    (Math.random() - 0.5) * 0.35,
      vy:    (Math.random() - 0.5) * 0.35,
      alpha: Math.random() * 0.45 + 0.1,
    }))
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    // Connecting lines: merge beginPath calls to reduce draw calls
    ctx.lineWidth = 0.5
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx   = particles[i].x - particles[j].x
        const dy   = particles[i].y - particles[j].y
        const dist = dx * dx + dy * dy  // Avoid sqrt by comparing squared distance
        if (dist < 100 * 100) {
          const d = Math.sqrt(dist)
          ctx.beginPath()
          ctx.strokeStyle = `rgba(37,99,235,${0.06 * (1 - d / 100)})`
          ctx.moveTo(particles[i].x, particles[i].y)
          ctx.lineTo(particles[j].x, particles[j].y)
          ctx.stroke()
        }
      }
    }
    // Particles
    for (const p of particles) {
      ctx.beginPath()
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(37,99,235,${p.alpha * 0.5})`
      ctx.fill()
      p.x += p.vx
      p.y += p.vy
      if (p.x < 0 || p.x > canvas.width)  p.vx *= -1
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1
    }
    animFrame = requestAnimationFrame(draw)
  }

  resizeHandler = () => { resize(); init() }
  resize(); init(); draw()
  window.addEventListener('resize', resizeHandler)
})

onUnmounted(() => {
  if (animFrame) cancelAnimationFrame(animFrame)
  if (resizeHandler) window.removeEventListener('resize', resizeHandler)
  if (cooldownTimer) { clearInterval(cooldownTimer); cooldownTimer = null }
})

// Fetch registration toggles so the register form adapts to backend settings
onMounted(async () => {
  try {
    const options = await apiGetRegistrationOptions()
    regOptions.email_verify_enabled = !!options?.email_verify_enabled
    regOptions.invite_required      = !!options?.invite_required
  } catch {
    // Keep defaults (no extra fields) when the endpoint is unavailable
  }
})

function switchMode(m) {
  mode.value = m; errorMsg.value = ''; successMsg.value = ''
  router.replace({ name: m })
}

// ── Email verification code ──
function startCooldown() {
  sendCodeCooldown.value = 60
  if (cooldownTimer) clearInterval(cooldownTimer)
  cooldownTimer = setInterval(() => {
    sendCodeCooldown.value -= 1
    if (sendCodeCooldown.value <= 0) {
      sendCodeCooldown.value = 0
      clearInterval(cooldownTimer)
      cooldownTimer = null
    }
  }, 1000)
}

async function handleSendCode() {
  const email = registerForm.email.trim()
  if (!email) {
    errorMsg.value = 'Enter your email address first.'
    return
  }
  if (sendCodeCooldown.value > 0 || sendingCode.value) return
  sendingCode.value = true
  errorMsg.value = ''
  try {
    await apiSendEmailCode(email)
    ElMessage.success(`Verification code sent to ${email}.`)
    startCooldown()
  } catch (e) {
    errorMsg.value = e.message || 'Failed to send the verification code.'
  } finally {
    sendingCode.value = false
  }
}

function enterGuest() {
  authStore.enterGuest()
  emit('login-success', authStore.user)
}

async function handleLogin() {
  errorMsg.value = ''; successMsg.value = ''; isLoading.value = true
  try {
    const user = await authStore.login(loginForm.username, loginForm.password)
    emit('login-success', user)
  } catch (e) {
    errorMsg.value = e.message || 'Login failed. Please check your username and password.'
  } finally { isLoading.value = false }
}

async function handleRegister() {
  if (registerForm.password !== registerForm.confirm) return
  if (registerForm.password.length < 8) {
    errorMsg.value = 'Password must be at least 8 characters.'; return
  }
  errorMsg.value = ''; successMsg.value = ''; isLoading.value = true
  try {
    await authStore.register(
      registerForm.username,
      registerForm.email,
      registerForm.password,
      {
        email_code:  registerForm.email_code.trim(),
        invite_code: registerForm.invite_code.trim(),
        promo_code:  registerForm.promo_code.trim(),
      }
    )
    successMsg.value = 'Registration successful! Please sign in.'
    loginForm.username = registerForm.username
    loginForm.password = ''
    setTimeout(() => switchMode('login'), 1200)
  } catch (e) {
    errorMsg.value = e.message || 'Registration failed. Please try again later.'
  } finally { isLoading.value = false }
}
</script>

<style scoped>
/* ── Overall layout ── */
.auth-page {
  min-height: 100vh;
  background: #f0f4ff;
  display: flex;
  align-items: stretch;
  overflow: hidden;
  position: relative;
}

/* canvas and glow stay only within the left area; no fixed positioning to avoid covering content */
.bg-canvas {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
}

.glow {
  position: absolute;
  border-radius: 50%;
  filter: blur(100px);
  pointer-events: none;
  z-index: 0;
}
.glow-1 {
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(37, 99, 235, 0.12) 0%, transparent 70%);
  top: -150px; left: -100px;
}
.glow-2 {
  width: 450px; height: 450px;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.08) 0%, transparent 70%);
  bottom: -100px; left: 30%;
}

/* ── Left brand panel ── */
.brand-panel {
  position: relative;
  z-index: 1;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 36px 48px 30px;
}

.brand-logo {
  display: flex;
  align-items: center;
  gap: 12px;
}

.brand-logo-icon {
  width: 44px; height: 44px;
  background: linear-gradient(135deg, #2563eb, #4f8ef7);
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  color: white;
  box-shadow: 0 4px 14px rgba(37, 99, 235, 0.28);
  flex-shrink: 0;
}

.brand-name {
  font-size: 17px;
  font-weight: 800;
  color: #1f2937;
  letter-spacing: -0.4px;
}

.brand-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 32px 0 24px;
}

.brand-headline {
  font-size: 32px;
  font-weight: 800;
  color: #1f2937;
  line-height: 1.2;
  letter-spacing: -1px;
  margin: 0 0 18px;
}

.gradient-text {
  background: linear-gradient(135deg, #2563eb, #6366f1);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.brand-desc {
  font-size: 15px;
  color: #6b7280;
  line-height: 1.8;
  margin: 0 0 32px;
  max-width: 360px;
}

.feature-list {
  list-style: none;
  padding: 0; margin: 0;
  display: flex;
  flex-direction: column;
  gap: 13px;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  color: #374151;
}

.feature-dot {
  width: 7px; height: 7px;
  border-radius: 50%;
  background: linear-gradient(135deg, #2563eb, #6366f1);
  flex-shrink: 0;
  box-shadow: 0 0 6px rgba(37, 99, 235, 0.35);
}

.brand-footer {
  font-size: 11px;
  color: #9ca3af;
  letter-spacing: 0.3px;
}

/* ── Right login panel ── */
.auth-panel {
  flex: 0 0 480px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 36px 44px;
  background: #ffffff;
  border-left: 1px solid #e8edf3;
  box-shadow: -4px 0 32px rgba(0, 0, 0, 0.04);
}

.auth-card {
  width: 100%;
  max-width: 340px;
}

.auth-title {
  margin-bottom: 28px;
}

.auth-title h2 {
  font-size: 20px;
  font-weight: 700;
  color: #1f2937;
  margin: 0 0 6px;
  letter-spacing: -0.3px;
}

.auth-title p {
  font-size: 13px;
  color: #9ca3af;
  margin: 0;
}

/* ── Tabs ── */
.auth-tabs {
  position: relative;
  display: flex;
  background: #f3f4f6;
  border-radius: 10px;
  padding: 3px;
  margin-bottom: 22px;
}

.tab-indicator {
  position: absolute;
  top: 3px; left: 3px;
  width: calc(50% - 3px);
  height: calc(100% - 6px);
  background: #ffffff;
  border-radius: 7px;
  transition: left 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}

.tab-indicator.right { left: calc(50%); }

.tab-btn {
  flex: 1; padding: 8px;
  border: none; border-radius: 7px;
  font-size: 13px; font-weight: 500;
  color: #6b7280;
  background: transparent; cursor: pointer;
  transition: color 0.2s;
  position: relative; z-index: 1;
}

.tab-btn.active { color: #1f2937; font-weight: 600; }

/* ── Banners ── */
.error-banner, .success-banner {
  display: flex; align-items: center; gap: 8px;
  padding: 10px 13px; border-radius: 8px;
  font-size: 13px; margin-bottom: 14px;
}

.error-banner {
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #dc2626;
}

.success-banner {
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  color: #16a34a;
}

/* ── Form ── */
.auth-form { display: flex; flex-direction: column; gap: 14px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }

.form-label {
  font-size: 12px; font-weight: 600;
  color: #374151;
  letter-spacing: 0.2px;
}

.input-wrap { position: relative; display: flex; align-items: center; }

.input-icon {
  position: absolute; left: 12px;
  color: #9ca3af;
  font-size: 14px; pointer-events: none;
}

.form-input {
  width: 100%;
  padding: 10px 38px 10px 37px;
  background: #fafafa;
  border: 1.5px solid #e5e7eb;
  border-radius: 8px;
  font-size: 14px; color: #1f2937;
  outline: none; font-family: inherit;
  transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
}

.form-input:focus {
  border-color: #2563eb;
  background: #ffffff;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.08);
}

.form-input::placeholder { color: #c4c9d4; }

.eye-btn {
  position: absolute; right: 10px;
  width: 28px; height: 28px;
  display: flex; align-items: center; justify-content: center;
  border: none; background: transparent; cursor: pointer;
  color: #9ca3af; border-radius: 5px;
  transition: color 0.15s;
}

.eye-btn:hover { color: #374151; }

/* ── Send-code button inside the email code input ── */
.form-input.has-code-btn { padding-right: 108px; }

.code-btn {
  position: absolute;
  right: 8px;
  padding: 5px 10px;
  border: none;
  border-radius: 6px;
  background: #eff6ff;
  color: #2563eb;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s, color 0.2s;
}

.code-btn:hover:not(:disabled) { background: #dbeafe; }

.code-btn:disabled {
  color: #9ca3af;
  background: #f3f4f6;
  cursor: not-allowed;
}

.label-optional {
  font-weight: 400;
  font-size: 11px;
  color: #9ca3af;
}

.field-hint { font-size: 11px; margin-top: 2px; }
.field-hint.error { color: #ef4444; }

/* ── Submit button ── */
.submit-btn {
  display: flex; align-items: center; justify-content: center; gap: 7px;
  width: 100%; padding: 11px;
  background: #2563eb;
  color: white; border: none; border-radius: 8px;
  font-size: 14px; font-weight: 600; cursor: pointer;
  transition: background 0.2s, transform 0.15s, box-shadow 0.2s;
  margin-top: 4px;
  box-shadow: 0 2px 8px rgba(37, 99, 235, 0.22);
}

.submit-btn:hover:not(:disabled) {
  background: #1d4ed8;
  transform: translateY(-1px);
  box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
}

.submit-btn:active:not(:disabled) { transform: translateY(0); }
.submit-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.submit-btn.loading { background: #93c5fd; box-shadow: none; }

.spinner {
  width: 14px; height: 14px;
  border: 2px solid rgba(255,255,255,0.35);
  border-top-color: white;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  display: inline-block;
}

@keyframes spin { to { transform: rotate(360deg); } }

.switch-hint {
  text-align: center; font-size: 13px;
  color: #9ca3af; margin-top: 2px;
}

.switch-hint a {
  color: #2563eb; text-decoration: none; font-weight: 500;
}

.switch-hint a:hover { color: #1d4ed8; text-decoration: underline; }

/* ── Guest mode ── */
.guest-divider {
  display: flex;
  align-items: center;
  gap: 10px;
  color: #d1d5db;
  font-size: 12px;
}
.guest-divider::before,
.guest-divider::after {
  content: '';
  flex: 1;
  height: 1px;
  background: #e5e7eb;
}

.guest-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  width: 100%;
  padding: 10px;
  background: transparent;
  border: 1.5px solid #e5e7eb;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  color: #6b7280;
  cursor: pointer;
  transition: border-color 0.2s, color 0.2s, background 0.2s;
}

.guest-btn:hover {
  border-color: #bfdbfe;
  color: #2563eb;
  background: #eff6ff;
}

/* ── Responsive ── */
@media (max-width: 768px) {
  .auth-page { flex-direction: column; justify-content: center; background: #ffffff; }
  .brand-panel { display: none; }
  .auth-panel { flex: none; width: 100%; padding: 32px 24px; box-shadow: none; border: none; }
}

/* ── Decorative floating circles ── */
.deco-circle {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  z-index: 0;
}
.deco-c1 {
  width: 280px; height: 280px;
  border: 1.5px solid rgba(37, 99, 235, 0.1);
  top: 10%; right: -60px;
  animation: float-slow 8s ease-in-out infinite;
}
.deco-c2 {
  width: 160px; height: 160px;
  border: 1.5px solid rgba(99, 102, 241, 0.12);
  bottom: 18%; right: 20px;
  animation: float-slow 6s ease-in-out infinite reverse;
}
.deco-c3 {
  width: 80px; height: 80px;
  background: rgba(37, 99, 235, 0.05);
  bottom: 35%; left: 12%;
  animation: float-slow 10s ease-in-out infinite;
}

@keyframes float-slow {
  0%, 100% { transform: translateY(0px); }
  50%       { transform: translateY(-16px); }
}

/* ── Entry animation ── */
.brand-logo {
  animation: fade-up 0.5s ease both;
}
.brand-headline {
  animation: fade-up 0.5s ease 0.15s both;
}
.brand-desc {
  animation: fade-up 0.5s ease 0.25s both;
}
.feature-item {
  animation: fade-up 0.5s ease both;
  opacity: 0;
}
.auth-card {
  animation: fade-up 0.5s ease 0.1s both;
}

@keyframes fade-up {
  from { opacity: 0; transform: translateY(16px); }
  to   { opacity: 1; transform: translateY(0); }
}
</style>
