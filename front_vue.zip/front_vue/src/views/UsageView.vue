<template>
  <main class="usage-page" :class="{ embedded: isAdminView }">
    <div class="heading">
      <div>
        <el-button v-if="!isAdminView" text @click="router.push('/')">Back to App</el-button>
        <h2>{{ isAdminView ? 'Usage & Costs' : 'My Usage & Costs' }}</h2>
        <p>Review saved request usage, standard USD cost, and actual CNY balance deductions.</p>
      </div>
      <el-button :loading="loading" @click="load">Refresh</el-button>
    </div>
    <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
    <el-card shadow="never">
      <div class="period-shortcuts" aria-label="Quick time filters">
        <el-button size="small" @click="setPeriod('today')">Today</el-button>
        <el-button size="small" @click="setPeriod(7)">Last 7 Days</el-button>
        <el-button size="small" @click="setPeriod(30)">Last 30 Days</el-button>
        <el-button size="small" @click="setPeriod('all')">All Time</el-button>
      </div>
      <el-form class="filters" label-position="top" @submit.prevent="applyFilters">
        <el-form-item label="Time range (local time)"
          ><el-date-picker
            v-model="dateRange"
            type="datetimerange"
            start-placeholder="Start"
            end-placeholder="End (exclusive)"
        /></el-form-item>
        <el-form-item label="Provider"
          ><el-input v-model="filters.provider" placeholder="All providers" clearable
        /></el-form-item>
        <el-form-item label="Model"
          ><el-input v-model="filters.model" placeholder="Exact model ID" clearable
        /></el-form-item>
        <el-form-item label="Agent"
          ><el-input v-model="filters.agent_name" placeholder="All agents" clearable
        /></el-form-item>
        <el-form-item v-if="isAdminView" label="User ID"
          ><el-input v-model="filters.user_id" placeholder="All users" clearable
        /></el-form-item>
        <el-form-item label="Status"
          ><el-select v-model="filters.status" clearable placeholder="All statuses"
            ><el-option label="Completed" value="completed" /><el-option
              label="Failed"
              value="failed" /></el-select
        ></el-form-item>
        <el-form-item label="Group by"
          ><el-select v-model="groupBy"
            ><el-option
              v-for="item in ['model', 'agent', 'provider', 'day']"
              :key="item"
              :label="item"
              :value="item" /></el-select
        ></el-form-item>
        <el-form-item label=" "
          ><el-button type="primary" native-type="submit">Apply Filters</el-button
          ><el-button @click="resetFilters">Reset</el-button></el-form-item
        >
        <details class="related-filters" :open="!!filters.workflow_id || !!filters.session_id">
          <summary>Workflow / Session Filters</summary>
          <div class="filters">
            <el-form-item label="Workflow ID"
              ><el-input v-model="filters.workflow_id" placeholder="All workflows" clearable
            /></el-form-item>
            <el-form-item label="Session ID"
              ><el-input v-model="filters.session_id" placeholder="All sessions" clearable
            /></el-form-item>
          </div>
        </details>
      </el-form>
    </el-card>
    <div v-loading="loading" class="stats">
      <el-card v-for="card in cards" :key="card.label" shadow="never"
        ><div class="stat-label">{{ card.label }}</div>
        <strong>{{ card.value }}</strong></el-card
      >
    </div>
    <el-alert
      v-if="incompleteCount"
      type="warning"
      :closable="false"
      :title="`${summary.estimated_requests || 0} estimated, ${summary.unknown_usage_requests || 0} unavailable/legacy usage, ${summary.unpriced_requests || 0} unpriced/legacy cost records. Totals may be incomplete. Estimates are not debited.`"
    />
    <el-alert
      title="Input includes cached tokens. Standard USD uses the prices saved at call completion; actual CNY includes the billing switch, exchange rate and membership discount. Historical records are not recalculated. Daily groups use UTC."
      type="info"
      :closable="false"
    />
    <el-card shadow="never">
      <template #header
        ><strong>Cost by {{ applied.group_by || 'model' }}</strong
        ><span class="muted"> · up to 100 groups</span></template
      >
      <el-table :data="groups" empty-text="No usage in this period" size="small">
        <el-table-column prop="name" label="Group" min-width="220" show-overflow-tooltip />
        <el-table-column prop="requests" label="Requests" width="100" />
        <el-table-column label="Tokens" width="140"
          ><template #default="{ row }">{{ number(row.total_tokens) }}</template></el-table-column
        >
        <el-table-column label="Standard USD" width="160"
          ><template #default="{ row }">{{ money(row.cost_usd, 'USD') }}</template></el-table-column
        >
        <el-table-column label="Charged CNY" width="160"
          ><template #default="{ row }">{{
            money(row.charged_cny, 'CNY')
          }}</template></el-table-column
        >
      </el-table>
    </el-card>
    <el-card shadow="never">
      <template #header
        ><div class="heading">
          <strong>Request History</strong
          ><el-button :disabled="!items.length" @click="exportPage"
            >Export This Page (CSV)</el-button
          >
        </div></template
      >
      <el-table
        v-loading="loading"
        :data="items"
        stripe
        empty-text="No saved requests match these filters"
      >
        <el-table-column label="Time" min-width="170"
          ><template #default="{ row }">{{
            new Date(row.created_at).toLocaleString()
          }}</template></el-table-column
        >
        <el-table-column prop="model" label="Model" min-width="190" show-overflow-tooltip />
        <el-table-column prop="provider" label="Provider" width="100" />
        <el-table-column prop="agent_name" label="Agent" width="120" />
        <el-table-column
          v-if="isAdminView"
          prop="user_id"
          label="User ID"
          min-width="120"
          show-overflow-tooltip
        />
        <el-table-column label="Input / Output" min-width="140"
          ><template #default="{ row }"
            >{{ number(row.prompt_tokens) }} / {{ number(row.completion_tokens) }}</template
          ></el-table-column
        >
        <el-table-column label="Cache read / write" min-width="145"
          ><template #default="{ row }"
            >{{ number(row.cache_read_tokens) }} / {{ number(row.cache_write_tokens) }}</template
          ></el-table-column
        >
        <el-table-column label="Standard USD" width="140"
          ><template #default="{ row }">{{
            row.pricing_source === 'unpriced' ? 'Unpriced' : money(row.cost_usd, 'USD')
          }}</template></el-table-column
        >
        <el-table-column label="Charged CNY" width="140"
          ><template #default="{ row }">{{
            money(row.charged_cny, 'CNY')
          }}</template></el-table-column
        >
        <el-table-column prop="usage_source" label="Usage source" width="125" />
        <el-table-column prop="pricing_source" label="Price source" width="125" />
        <el-table-column prop="status" label="Status" width="100" />
        <el-table-column label="Duration" width="110"
          ><template #default="{ row }">{{
            row.latency_ms > 0 ? `${(row.latency_ms / 1000).toFixed(2)} s` : 'Not recorded'
          }}</template></el-table-column
        >
        <el-table-column label="Details" width="100" fixed="right"
          ><template #default="{ row }"
            ><el-button link type="primary" @click="openDetail(row.id)"
              >Details</el-button
            ></template
          ></el-table-column
        >
      </el-table>
      <el-pagination
        :current-page="page"
        :page-size="pageSize"
        :total="total"
        layout="total, sizes, prev, pager, next"
        :page-sizes="[20, 50, 100]"
        @current-change="changePage"
        @size-change="changePageSize"
      />
    </el-card>
    <UsageDetailDrawer
      v-model="detailOpen"
      :usage-id="selectedId"
      :admin="isAdminView"
      @related="showRelated"
    />
  </main>
</template>

<script setup>
import { computed, onBeforeUnmount, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth.js'
import { getUsage } from '../api/modelManagement.js'
import { usageCsv } from '../utils/usageExport.js'
import UsageDetailDrawer from '../components/UsageDetailDrawer.vue'

const route = useRoute(),
  router = useRouter(),
  auth = useAuthStore()
const isAdminView = computed(() => route.meta.requiresAdmin === true)
const filters = reactive({
  provider: '',
  model: '',
  agent_name: '',
  status: '',
  user_id: '',
  workflow_id: '',
  session_id: '',
})
const detailOpen = ref(false),
  selectedId = ref('')
const initialDates = () => [new Date(Date.now() - 7 * 86400000), new Date()]
const dateRange = ref(initialDates()),
  groupBy = ref('model'),
  applied = ref({})
const loading = ref(false),
  error = ref(''),
  summary = ref({}),
  items = ref([]),
  groups = ref([])
const page = ref(1),
  pageSize = ref(20),
  total = ref(0)
let requestVersion = 0
const number = value => Number(value || 0).toLocaleString('en-US')
const money = (value, currency) =>
  Number(value || 0).toLocaleString('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 4,
    maximumFractionDigits: 6,
  })
const cards = computed(() => [
  { label: 'Requests', value: number(summary.value.requests) },
  { label: 'Total tokens', value: number(summary.value.total_tokens) },
  { label: 'Standard cost (USD)', value: money(summary.value.cost_usd, 'USD') },
  { label: 'Actual charge (CNY)', value: money(summary.value.charged_cny, 'CNY') },
  { label: 'Failed requests', value: number(summary.value.failed_requests) },
  {
    label: 'Average duration',
    value: `${((summary.value.avg_latency_ms || 0) / 1000).toFixed(2)} s`,
  },
])
const incompleteCount = computed(
  () =>
    (summary.value.estimated_requests || 0) +
    (summary.value.unknown_usage_requests || 0) +
    (summary.value.unpriced_requests || 0)
)
function clearResults() {
  summary.value = {}
  items.value = []
  groups.value = []
  total.value = 0
}
async function load() {
  const version = ++requestVersion
  loading.value = true
  error.value = ''
  clearResults()
  try {
    const result = await getUsage(
      { ...applied.value, page: page.value, page_size: pageSize.value },
      isAdminView.value
    )
    if (version !== requestVersion) return
    summary.value = result.summary
    items.value = result.items
    groups.value = result.groups
    total.value = result.total
  } catch (e) {
    if (version === requestVersion) error.value = e.message
  } finally {
    if (version === requestVersion) loading.value = false
  }
}
function applyFilters() {
  if (dateRange.value?.length === 2 && dateRange.value[0] >= dateRange.value[1]) {
    error.value = 'Start time must be before end time'
    return
  }
  applied.value = {
    provider: filters.provider.trim(),
    model: filters.model.trim(),
    agent_name: filters.agent_name.trim(),
    status: filters.status,
    workflow_id: filters.workflow_id.trim(),
    session_id: filters.session_id.trim(),
    ...(isAdminView.value ? { user_id: filters.user_id.trim() } : {}),
    group_by: groupBy.value,
    date_from: dateRange.value?.[0]?.toISOString(),
    date_to: dateRange.value?.[1]?.toISOString(),
  }
  page.value = 1
  void load()
}
function resetFilters() {
  Object.keys(filters).forEach(key => {
    filters[key] = ''
  })
  dateRange.value = initialDates()
  groupBy.value = 'model'
  applyFilters()
}
function setPeriod(period) {
  const end = new Date()
  const start =
    period === 'today'
      ? new Date(end.getFullYear(), end.getMonth(), end.getDate())
      : new Date(end.getTime() - Number(period) * 86400000)
  dateRange.value = period === 'all' ? null : [start, end]
  applyFilters()
}
function changePage(value) {
  page.value = value
  void load()
}
function changePageSize(value) {
  pageSize.value = value
  page.value = 1
  void load()
}
function exportPage() {
  const url = URL.createObjectURL(
    new Blob(['\uFEFF', usageCsv(items.value)], { type: 'text/csv;charset=utf-8' })
  )
  const link = document.createElement('a')
  link.href = url
  link.download = `usage-page-${page.value}.csv`
  link.click()
  URL.revokeObjectURL(url)
}
function openDetail(id) {
  selectedId.value = id
  detailOpen.value = true
}
function showRelated(query) {
  Object.keys(filters).forEach(key => {
    filters[key] = ''
  })
  Object.assign(filters, query)
  dateRange.value = null
  detailOpen.value = false
  applyFilters()
}
watch(
  () => [route.query?.usage_id, auth.isLoggedIn],
  ([id, signedIn]) => {
    if (signedIn && typeof id === 'string' && id) openDetail(id)
  },
  { immediate: true }
)
watch(
  () => [auth.user?.id, auth.user?.name, auth.isLoggedIn, isAdminView.value],
  (_values, previous) => {
    ++requestVersion
    clearResults()
    if (previous) {
      detailOpen.value = false
      selectedId.value = ''
    }
    if (auth.isLoggedIn) resetFilters()
  },
  { immediate: true }
)
onBeforeUnmount(() => {
  ++requestVersion
})
</script>

<style scoped>
.usage-page {
  display: grid;
  grid-auto-rows: max-content;
  align-content: start;
  gap: 18px;
  max-width: 1500px;
  margin: 0 auto;
  padding: 24px;
  background: #f5f7fa;
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  box-sizing: border-box;
}
.usage-page.embedded {
  padding: 0;
  height: auto;
  min-height: auto;
  overflow: visible;
}
.filters .el-form-item:first-child {
  width: min(440px, 100%);
}
.filters :deep(.el-form-item__content) {
  min-width: 0;
}
.filters :deep(.el-date-editor) {
  width: 100%;
  max-width: 100%;
}
.heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
}
.heading h2 {
  margin: 8px 0;
}
.heading p,
.muted {
  color: #64748b;
  font-size: 13px;
}
.filters {
  display: flex;
  gap: 0 14px;
  flex-wrap: wrap;
}
.period-shortcuts {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 18px;
}
.period-shortcuts .el-button {
  margin: 0;
}
.related-filters {
  width: 100%;
  color: #64748b;
  font-size: 13px;
}
.related-filters summary {
  cursor: pointer;
  margin-bottom: 12px;
}
.filters .el-input {
  width: 175px;
}
.filters .el-select {
  width: 140px;
}
.stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
}
.stat-label {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 10px;
}
.stats strong {
  font-size: 24px;
  color: #1e293b;
}
.el-pagination {
  margin-top: 18px;
}
@media (max-width: 800px) {
  .stats {
    grid-template-columns: repeat(2, 1fr);
  }
  .usage-page {
    padding: 12px;
  }
}
</style>
