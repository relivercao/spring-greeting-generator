<template>
  <div class="app-layout">
    <Sidebar
      :agents="agents"
      :history="sidebarHistory"
      :active-agent="activeAgent"
      :active-session="sidebarActiveSession"
      :unittest-mode="unittestMode"
      :active-view="route.name"
      :version-update-available="versionUpdateAvailable"
      @select-agent="selectAgent"
      @select-session="selectSession"
      @new-chat="newChat"
      @start-agent-chat="startAgentChat"
      @go-home="goHome"
      @delete-session="deleteSession"
      @select-unittest-mode="selectUnittestMode"
      @open-skill-market="router.push('/skill-market')"
    />
    <div class="main-area">
      <Header
        :active-agent="activeAgent"
        :user="authStore.user"
        @logout="handleLogout"
      />
      <div class="content-area">
        <SkillMarketWorkspace v-if="route.name === 'skill-market'" />
        <div
          v-else-if="route.meta?.generatedAgent && !activeAgent"
          class="generated-agent-loading"
        >
          <el-icon class="loading-icon">
            <Loading />
          </el-icon>
          <p>Loading the saved generated Agent...</p>
          <small>The Agent list is syncing with the local knowledge repository.</small>
        </div>
        <!-- No active selection: home page -->
        <WelcomePage
          v-else-if="!activeAgent"
          :user="authStore.user"
          :agents="agents"
          @select-agent="startAgentChat"
        />
        <!-- Active agent but no session, and not ChatMessage: workspace upload page -->
        <BatchTestWorkspace
          v-else-if="activeAgent.id === 2 && unittestMode === 'batch'"
          ref="batchWorkspaceRef"
          :key="'batch_unittest_workspace_' + currentAccountIdentity + '_' + (batchTestWorkspaceTask?.id || 'empty')"
          :active-task="batchTestWorkspaceTask"
          @task-updated="handleBatchTestTaskUpdated"
          @run-requested="handleBatchRunRequested"
        />
        <UnittestWorkspace
          v-else-if="activeAgent.id === 2 && unittestMode === 'single'"
          :key="'unittest_workspace_' + currentAccountIdentity"
          :active-task="activeSession"
          @new-task="handleNewTask"
          @task-updated="handleTaskUpdated"
        />
        <DriverWorkspace
          v-else-if="activeAgent.id === 3 && driverWorkspaceTask"
          :key="'driver_workspace_' + currentAccountIdentity + '_' + driverWorkspaceTask.id"
          :agent="activeAgent"
          :active-task="driverWorkspaceTask"
          @task-updated="handleDriverTaskUpdated"
        />
        <div
          v-else-if="activeAgent.id === 3"
          class="driver-workspace-empty"
        >
          <h2>Driver Development</h2>
          <p>Start a task to configure your device and generate a driver.</p>
          <el-button
            type="primary"
            @click="startAgentChat(activeAgent)"
          >
            Start Driver Task
          </el-button>
        </div>
        <BugFixWorkspace
          v-else-if="activeAgent.id === 8"
          :key="'bugfix_workspace_' + currentAccountIdentity + '_' + (workspaceInstanceKeys[8] || 0)"
          :agent="activeAgent"
        />
        <ImageGenerationWorkspace
          v-else-if="activeAgent.id === 6"
          :key="'image_generation_workspace_' + currentAccountIdentity"
          :active-task="activeSession"
          @new-task="handleImageNewTask"
          @task-updated="handleImageTaskUpdated"
        />
        <CadWorkspace
          v-else-if="activeAgent.id === 9"
          :key="'cad_workspace_' + currentAccountIdentity + '_' + (workspaceInstanceKeys[9] || 0)"
        />
        <RagWorkspace
          v-else-if="activeAgent.id === 5"
          :key="'knowledge_workspace_' + currentAccountIdentity"
          :agent="activeAgent"
        />
        <AgentGeneratorWorkspace
          v-else-if="activeAgent.id === 7"
          :key="'agent_generator_workspace_' + currentAccountIdentity"
          @agent-created="handleGeneratedAgentCreated"
        />
        <GeneratedAgentWorkspace
          v-else-if="activeAgent.generated"
          :key="'generated_' + activeAgent.id"
          :agent="activeAgent"
          @agent-deleted="handleGeneratedAgentDeleted"
        />
        <AgentWorkspace
          v-else-if="!activeSession && activeAgent.id !== 1"
          :key="`ws_${activeAgent.id}_${currentAccountIdentity}_${workspaceInstanceKeys[activeAgent.id] || 0}`"
          :agent="activeAgent"
          @start-chat="startAgentChat(activeAgent)"
        />
        <ChatWindow
          v-else
          :key="activeSession ? activeSession.id : 'empty_chat'"
          :session="activeSession || { id: null, messages: [] }"
          :agent="activeAgent"
          @send-message="sendMessage"
          @clear-chat="clearChat"
          @delete-message="deleteMessage"
        />
      </div>
    </div>

    <!-- AWS SSO Login Modal -->
    <AWSSSOLoginModal
      :visible="showAWSSSOModal"
      @close="showAWSSSOModal = false"
      @success="handleAWSLoginSuccess"
    />
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount, defineAsyncComponent } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Loading } from '@element-plus/icons-vue'
import Sidebar from '../components/Sidebar.vue'
import Header from '../components/Header.vue'
import WelcomePage from '../components/WelcomePage.vue'
import ChatWindow from '../components/ChatWindow.vue'
import AgentWorkspace from '../components/AgentWorkspace.vue'
import UnittestWorkspace from '../components/UnittestWorkspace.vue'
import DriverWorkspace from '../components/DriverWorkspace.vue'
import BugFixWorkspace from '../components/BugFixWorkspace.vue'
import BatchTestWorkspace from '../components/BatchTestWorkspace.vue'
import ImageGenerationWorkspace from '../components/ImageGenerationWorkspace.vue'
import CadWorkspace from '../components/CadWorkspace.vue'
import RagWorkspace from '../components/RagWorkspace.vue'
import AgentGeneratorWorkspace from '../components/AgentGeneratorWorkspace.vue'
import GeneratedAgentWorkspace from '../components/GeneratedAgentWorkspace.vue'
import AWSSSOLoginModal from '../components/AWSSSOLoginModal.vue'
import { useAuthStore } from '../stores/auth.js'
import { useChatStore } from '../stores/chat.js'
import { useUnittestStore } from '../stores/unittest.js'
import { useDriverStore } from '../stores/driver.js'
import { useBatchTestStore } from '../stores/batchTest.js'
import { useWorkspaceStore } from '../stores/workspace.js'
import { useImageGenerationStore } from '../stores/imageGeneration.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { apiSendMessage } from '../api/auth.js'
import { EMPTY_CHAT_RESPONSE_MESSAGE, getChatErrorMessage } from '../api/errorMessages.js'
import { listGeneratedAgents } from '../api/agentGenerator.js'
import { apiGetBatchTaskList } from '../api/unittest.js'
import { AGENT_BACKEND_MAP, AGENT_ROUTE_MAP, BUILT_IN_AGENTS } from '../config/agentCatalog.js'

const route     = useRoute()
const router    = useRouter()
const authStore = useAuthStore()
const currentAccountIdentity = computed(() => accountIdentity(authStore))
let accountRevision = 0
const chatStore = useChatStore()
const unittestStore = useUnittestStore()
const driverStore = useDriverStore()
const batchTestStore = useBatchTestStore()
const workspaceStore = useWorkspaceStore()
const imageGenerationStore = useImageGenerationStore()
const SkillMarketWorkspace = defineAsyncComponent(() => import('../components/SkillMarketWorkspace.vue'))
const GENERATED_AGENTS_CACHE_KEY = 'macode.generated-agents.v1'

defineEmits(['logout'])

// AWS SSO Login Modal
const showAWSSSOModal = ref(false)
const batchWorkspaceRef = ref(null)
const UNITTEST_AGENT_ID = 2
const UNITTEST_MODE_STORAGE_KEY = 'unittest_execution_mode'
const activeUnittestBatchSession = ref(null)
const versionUpdateAvailable = ref(false)

function handleVersionUpdateStatus(event) {
  versionUpdateAvailable.value = Boolean(event.detail?.update_available)
}

function loadUnittestMode() {
  try {
    const savedMode = localStorage.getItem(UNITTEST_MODE_STORAGE_KEY)
    return ['single', 'batch'].includes(savedMode) ? savedMode : 'single'
  } catch {
    return 'single'
  }
}

function saveUnittestMode(mode) {
  try {
    localStorage.setItem(UNITTEST_MODE_STORAGE_KEY, mode)
  } catch (error) {
    console.warn('[Home.vue] Failed to save unit-test mode:', error)
  }
}

const unittestMode = ref(loadUnittestMode())

// Listen for AWS auth required event
const handleAWSAuthRequired = (event) => {
  console.log('[Home.vue] AWS auth required event received:', event.detail)
  showAWSSSOModal.value = true
}

const handleAWSLoginSuccess = () => {
  ElMessage.success('AWS login successful! You can now use Bedrock models.')
  showAWSSSOModal.value = false
  void batchWorkspaceRef.value?.resumeBlockedBatch?.()
}

onMounted(() => {
  window.addEventListener('aws:auth-required', handleAWSAuthRequired)
  window.addEventListener('version:update-status', handleVersionUpdateStatus)
  hydrateGeneratedAgentsFromCache()
  loadGeneratedAgents()
  if (route.meta?.agentId === UNITTEST_AGENT_ID && unittestMode.value === 'batch') {
    const revision = accountRevision
    void syncBatchTaskHistoryFromBackend().then(() => {
      if (revision !== accountRevision) return
      activeUnittestBatchSession.value = batchTestStore.taskHistory[0] || createBatchTestTask()
    })
  }
  generatedAgentRefreshTimer = window.setInterval(() => loadGeneratedAgents(), 15000)
})

onBeforeUnmount(() => {
  window.removeEventListener('aws:auth-required', handleAWSAuthRequired)
  window.removeEventListener('version:update-status', handleVersionUpdateStatus)
  if (generatedAgentRefreshTimer) {
    window.clearInterval(generatedAgentRefreshTimer)
    generatedAgentRefreshTimer = null
  }
})

const agentRouteMap = AGENT_ROUTE_MAP
const agentBackendMap = AGENT_BACKEND_MAP
const agents = ref([...BUILT_IN_AGENTS])

const activeSession = ref(null)
const workspaceInstanceKeys = ref({})
const isLoadingGeneratedAgents = ref(false)
let generatedAgentRefreshTimer = null

const activeAgent = computed(() => {
  const id = route.meta?.agentId
  if (id) return agents.value.find(a => a.id === id) || null
  if (route.meta?.generatedAgent) return agents.value.find(a => a.id === route.params.agentId) || null
  return null
})

// Return the corresponding history based on Agent type
const sidebarHistory = computed(() => {
  if (activeAgent.value?.id === 2) {
    if (unittestMode.value === 'batch') return [...batchTestStore.taskHistory]
    // Unittest uses task history
    const history = [...unittestStore.taskHistory]
    // If a temporary session exists (file selected but not executed), show it at the top of the list
    if (activeSession.value?._temp && !history.find(t => t.id === activeSession.value.id)) {
      history.unshift(activeSession.value)
    }
    return history
  }
  if (activeAgent.value?.id === 3) return [...driverStore.taskHistory]
  if (activeAgent.value?.id === 6) {
    return imageGenerationStore.taskHistory
  }
  if (activeAgent.value?.generated) {
    return []
  }
  // Other Agents use chat history
  return chatStore.history
})

const batchTestWorkspaceTask = computed(() => {
  if (activeAgent.value?.id !== UNITTEST_AGENT_ID || unittestMode.value !== 'batch') return null
  return activeUnittestBatchSession.value || batchTestStore.taskHistory[0] || null
})

const driverWorkspaceTask = computed(() => (
  activeAgent.value?.id === 3 ? activeSession.value : null
))

const sidebarActiveSession = computed(() => (
  activeAgent.value?.id === UNITTEST_AGENT_ID && unittestMode.value === 'batch'
    ? activeUnittestBatchSession.value || batchTestStore.taskHistory[0] || null
    : activeSession.value
))

function createBatchTaskUpdates(task, updates = {}) {
  return {
    ...task,
    ...updates,
    agentId: UNITTEST_AGENT_ID,
    updatedAt: new Date().toISOString(),
  }
}

function batchHistoryStatus(remote) {
  if (remote?.status !== 'done') return remote?.status || 'queued'
  return String(remote?.terminal_reason || '').toUpperCase() === 'CANCELLED'
    ? 'cancelled'
    : 'completed'
}

function batchHistoryFile(item, index) {
  const relativePath = String(item?.relative_path || item?.filename || `source-${index + 1}`)
  const name = String(item?.filename || relativePath.split('/').pop() || `source-${index + 1}`)
  const extension = name.includes('.') ? name.slice(name.lastIndexOf('.')).toLowerCase() : ''
  return {
    id: item?.item_id || relativePath || `${name}-${index}`,
    name,
    path: relativePath,
    relativePath,
    extension,
  }
}

async function syncBatchTaskHistoryFromBackend() {
  const revision = accountRevision
  try {
    const response = await apiGetBatchTaskList({ limit: 100, include_items: true })
    if (revision !== accountRevision) return []
    const remoteTasks = Array.isArray(response?.tasks) ? response.tasks : []

    remoteTasks.forEach((remote) => {
      if (!remote?.batch_task_id || batchTestStore.isDismissed(remote.batch_task_id)) return
      const existing = batchTestStore.taskHistory.find(task => task.batchTaskId === remote.batch_task_id)
      const items = Array.isArray(remote.items) ? remote.items : (existing?.items || [])
      const selectedFiles = existing?.selectedFiles?.length
        ? existing.selectedFiles
        : items.map(batchHistoryFile)
      const localId = existing?.id || `batch_test_task_${remote.batch_task_id}`
      const title = selectedFiles.length > 1
        ? `Batch Test (${selectedFiles.length} files)`
        : (selectedFiles[0]?.name || 'Batch Test')
      const task = createBatchTaskUpdates(existing || {
        id: localId,
        title,
        time: remote.created_at ? new Date(remote.created_at).toLocaleString() : new Date().toLocaleString(),
      }, {
        id: localId,
        title: existing?.title || title,
        status: batchHistoryStatus(remote),
        progress: Number(remote.progress) || 0,
        totalCount: Number(remote.counts?.total) || selectedFiles.length,
        completedCount: (Number(remote.counts?.pass) || 0) + (Number(remote.counts?.fail) || 0),
        failedCount: Number(remote.counts?.fail) || 0,
        selectedFiles,
        items,
        batchTaskId: remote.batch_task_id,
        batchDetail: remote,
        terminalReason: remote.terminal_reason || null,
        blockedReason: remote.blocked_reason || null,
        resumeRequired: Boolean(remote.resume_required),
        error: remote.error_message || null,
        startedAt: remote.started_at || null,
        completedAt: remote.finished_at || null,
      })

      if (existing) batchTestStore.updateTask(existing.id, task)
      else batchTestStore.addTask(task)
    })

    batchTestStore.applyServerOrder(remoteTasks.map(remote => remote.batch_task_id).filter(Boolean))
    return remoteTasks
  } catch (error) {
    console.warn('[Home.vue] Failed to restore batch history from backend:', error)
    return []
  }
}

function createBatchTestTask() {
  const task = {
    id: 'batch_test_task_' + Date.now(),
    title: 'New Batch Test',
    status: 'idle',
    progress: 0,
    result: null,
    time: new Date().toLocaleString(),
    agentId: UNITTEST_AGENT_ID,
    testMode: 'batch',
    selectedFiles: [],
    completedCount: 0,
    failedCount: 0,
    totalCount: 0,
  }
  batchTestStore.addTask(task)
  return batchTestStore.getTask(task.id) || task
}

function selectUnittestMode(mode) {
  if (!['single', 'batch'].includes(mode) || unittestMode.value === mode) return
  unittestMode.value = mode
  saveUnittestMode(mode)

  if (mode === 'batch') {
    activeUnittestBatchSession.value = activeUnittestBatchSession.value ||
      batchTestStore.taskHistory[0] || createBatchTestTask()
    const revision = accountRevision
    void syncBatchTaskHistoryFromBackend().then(() => {
      if (revision !== accountRevision) return
      if (!activeUnittestBatchSession.value || activeUnittestBatchSession.value.status === 'idle') {
        activeUnittestBatchSession.value = batchTestStore.taskHistory[0] || createBatchTestTask()
      }
    })
  }
}

// Watch Unittest task history changes to automatically update activeSession
watch(() => unittestStore.taskHistory, (newHistory) => {
  // If currently on the Unittest page and there are tasks but no activeSession is set, set the latest task
  if (activeAgent.value?.id === 2 && newHistory.length > 0 && !activeSession.value) {
    // Do not auto-set activeSession; let UnittestWorkspace manage it
    // activeSession.value = newHistory[0]
    console.log('[DEBUG] Unittest taskHistory changed:', newHistory.length, 'tasks')
  }
}, { deep: true })

watch(() => route.meta?.agentId, (newId, oldId) => {
  if (newId !== oldId && activeSession.value?.agentId !== newId) {
    activeSession.value = null
  }
})

watch(currentAccountIdentity, () => {
  accountRevision += 1
  activeSession.value = null
  activeUnittestBatchSession.value = null
}, { flush: 'sync' })

function selectAgent(agent) {
  activeSession.value = null
  if (agent?.id !== UNITTEST_AGENT_ID) {
    unittestMode.value = 'single'
    saveUnittestMode('single')
    activeUnittestBatchSession.value = null
  }
  if (agent.id === 1) {
    activeSession.value = chatStore.getAgentSessions(1)[0] || null
  }
  router.push(agent.generated ? '/agent/' + encodeURIComponent(agent.id) : (agentRouteMap[agent.id] || '/'))
}

async function loadGeneratedAgents() {
  if (isLoadingGeneratedAgents.value) return
  isLoadingGeneratedAgents.value = true
  try {
    const response = await listGeneratedAgents()
    const generated = Array.isArray(response?.agents) ? response.agents : []
    const builtIns = agents.value.filter(agent => !agent.generated)
    const normalizedGenerated = generated.map(normalizeGeneratedAgent)
    agents.value = builtIns.concat(normalizedGenerated)
    localStorage.setItem(GENERATED_AGENTS_CACHE_KEY, JSON.stringify(normalizedGenerated))
  } catch (error) {
    console.warn('Failed to load generated Agents:', error)
  } finally {
    isLoadingGeneratedAgents.value = false
  }
}

function normalizeGeneratedAgent(agent) {
  return {
    ...agent,
    generated: true,
    category: agent.category || 'Generated',
    icon: agent.icon || 'MagicStick',
    color: agent.color || '#2563eb',
    description: agent.description || 'Generated firmware development Agent',
  }
}

function hydrateGeneratedAgentsFromCache() {
  try {
    const cached = JSON.parse(localStorage.getItem(GENERATED_AGENTS_CACHE_KEY) || '[]')
    if (!Array.isArray(cached) || !cached.length) return
    agents.value = agents.value.filter(agent => !agent.generated).concat(cached.map(normalizeGeneratedAgent))
  } catch {
    localStorage.removeItem(GENERATED_AGENTS_CACHE_KEY)
  }
}

function handleGeneratedAgentCreated(agent) {
  const normalized = normalizeGeneratedAgent(agent)
  agents.value = agents.value.filter(item => item.id !== normalized.id).concat(normalized)
  localStorage.setItem(GENERATED_AGENTS_CACHE_KEY, JSON.stringify(agents.value.filter(item => item.generated)))
  router.push('/agent/' + encodeURIComponent(normalized.id))
}

function handleGeneratedAgentDeleted(agentId) {
  agents.value = agents.value.filter(agent => agent.id !== agentId)
  localStorage.setItem(GENERATED_AGENTS_CACHE_KEY, JSON.stringify(agents.value.filter(agent => agent.generated)))
  activeSession.value = null
  router.push('/agent-generator')
}

function selectSession(session) {
  if (activeAgent.value?.id === 2) {
    const isBatchTask = Boolean(session?.batchTaskId) || String(session?.id || '').startsWith('batch_test_task_')
    if (isBatchTask) {
      unittestMode.value = 'batch'
      saveUnittestMode('batch')
      const task = batchTestStore.getTask(session.id)
      if (task) {
        activeUnittestBatchSession.value = task
        router.push(agentRouteMap[UNITTEST_AGENT_ID])
      }
      return
    }

    unittestMode.value = 'single'
    saveUnittestMode('single')
    // Skip temporary tasks (they don't exist in the backend)
    if (session.id && session.id.startsWith('__temp_')) {
      console.log('[DEBUG] Skipping temporary task selection:', session.id)
      return
    }

    // Unittest: load task status
    const task = unittestStore.getTask(session.id)
    if (task) {
      // For ALL task statuses (idle/running/completed/failed), set activeSession
      // This allows completed tasks to display their report on the right
      activeSession.value = task
      const agent = agents.value.find(a => a.id === 2)
      if (agent) router.push(agentRouteMap[agent.id])
    }
  } else if (activeAgent.value?.id === 3) {
    const task = driverStore.getTask(session.id)
    if (task) {
      activeSession.value = task
      router.push(agentRouteMap[3])
    }
  } else if (activeAgent.value?.id === 6) {
    const task = imageGenerationStore.getTask(session.id)
    if (task) {
      activeSession.value = task
      router.push(agentRouteMap[6])
    }
  } else if (activeAgent.value?.generated) {
    router.push('/agent/' + encodeURIComponent(activeAgent.value.id))
  } else {
    // Other Agents: load chat session
    const found = chatStore.findSession(session.id)
    if (found) {
      activeSession.value = found
      const agent = agents.value.find(a => a.id === found.agentId)
      if (agent) router.push(agentRouteMap[agent.id])
    }
  }
}

function newChat() {
  if (activeAgent.value?.id === 1) {
    activeSession.value = chatStore.createSession(activeAgent.value)
    router.push(agentRouteMap[activeAgent.value.id])
    return
  }
  activeSession.value = null
  activeUnittestBatchSession.value = null
  unittestMode.value = 'single'
  saveUnittestMode('single')
  router.push('/')
}

function goHome() {
  activeSession.value = null
  activeUnittestBatchSession.value = null
  unittestMode.value = 'single'
  saveUnittestMode('single')
  router.push('/')
}

function startAgentChat(agent) {
  if (agent.id === 2) {
    if (unittestMode.value === 'batch') {
      activeUnittestBatchSession.value = createBatchTestTask()
      router.push(agentRouteMap[agent.id])
      return
    }
    // Create a new empty task and add it to history
    const newTaskId = 'task_' + Date.now()
    const newTask = {
      id: newTaskId,
      title: 'New Task',
      status: 'idle',
      progress: 0,
      result: null,
      time: new Date().toLocaleString(),
      agentId: 2,
    }
    unittestStore.addTask(newTask)
    activeSession.value = newTask
    router.push(agentRouteMap[agent.id])
  } else if (agent.id === 3) {
    const newTask = {
      id: 'driver_task_' + Date.now(),
      title: 'New Driver Task',
      status: 'idle',
      progress: 0,
      result: null,
      time: new Date().toLocaleString(),
      agentId: 3,
      fileMeta: null,
      chatMessages: [],
      serialLogs: [],
      driverState: {
        phase: 'idle',
        moduleConfig: {
          moduleType: 'IMU',
          moduleName: 'IMU Sensor',
          deviceType: 'sensor',
          interface: 'i2c',
          generateTests: true,
          generateCodeReview: true,
          platform: 'stm32',
          editor_path: '',
          stm32cubeide_path: '',
          project_path: '',
        },
        repositoryConfig: { repositoryUrl: '', branch: 'main', pathInput: '', selectedPaths: [] },
      },
    }
    driverStore.addTask(newTask)
    activeSession.value = driverStore.getTask(newTask.id) || newTask
    router.push(agentRouteMap[agent.id])
  } else if (agent.id === 4) {
    workspaceStore.clearState(agent.id)
    workspaceInstanceKeys.value = {
      ...workspaceInstanceKeys.value,
      [agent.id]: (workspaceInstanceKeys.value[agent.id] || 0) + 1,
    }
    activeSession.value = null
    router.push(agentRouteMap[agent.id])
    ElMessage.success(`New ${agent.name} task ready.`)
  } else if (agent.id === 8) {
    workspaceInstanceKeys.value = {
      ...workspaceInstanceKeys.value,
      [agent.id]: (workspaceInstanceKeys.value[agent.id] || 0) + 1,
    }
    activeSession.value = null
    router.push(agentRouteMap[agent.id])
  } else if ([5, 6].includes(agent.id)) {
    activeSession.value = null
    router.push(agentRouteMap[agent.id])
  } else if (agent.id === 9) {
    workspaceInstanceKeys.value = {
      ...workspaceInstanceKeys.value,
      [agent.id]: (workspaceInstanceKeys.value[agent.id] || 0) + 1,
    }
    activeSession.value = null
    router.push(agentRouteMap[agent.id])
  } else if (agent.generated) {
    activeSession.value = null
    router.push('/agent/' + encodeURIComponent(agent.id))
  } else {
    // Other Agents: create a new chat session
    const session = chatStore.createSession(agent)
    activeSession.value = session
    router.push(agentRouteMap[agent.id])
  }
}

async function deleteSession(sessionId) {
  if (activeAgent.value?.id === 2) {
    if (unittestMode.value === 'batch') {
      batchTestStore.deleteTask(sessionId)
      if (activeUnittestBatchSession.value?.id === sessionId) {
        activeUnittestBatchSession.value = batchTestStore.taskHistory[0] || null
      }
      return
    }

    // Skip deletion for temporary tasks (they're not in the store)
    if (sessionId && sessionId.startsWith('__temp_')) {
      console.log('[DEBUG] Skipping deletion of temporary task:', sessionId)
      if (activeSession.value?.id === sessionId) {
        workspaceStore.clearState(`unittest:${currentAccountIdentity.value}:2`)
        activeSession.value = null
      }
      return
    }

    // Unittest: delete task
    unittestStore.deleteTask(sessionId)

    // If deleting the current task, clear workspace state
    if (activeSession.value?.id === sessionId) {
      workspaceStore.clearState(`unittest:${currentAccountIdentity.value}:2`)
      activeSession.value = null
    }
  } else if (activeAgent.value?.id === 3) {
    driverStore.deleteTask(sessionId)
    if (activeSession.value?.id === sessionId) activeSession.value = null
  } else if (activeAgent.value?.id === 6) {
    try {
      await imageGenerationStore.removeTask(sessionId)
      if (activeSession.value?.id === sessionId) activeSession.value = null
    } catch (error) {
      ElMessage.error(error.message || 'Failed to delete the image task')
    }
  } else {
    // Other Agents: delete chat session
    chatStore.deleteSession(sessionId)
    if (activeSession.value?.id === sessionId) {
      activeSession.value = null
    }
  }
}

function handleNewTask() {
  // Clear the current task when Unittest clicks "New Task"
  activeSession.value = null
}

function handleImageNewTask() {
  activeSession.value = null
}

function handleImageTaskUpdated(task) {
  activeSession.value = task
}

function handleDriverTaskUpdated(task) {
  if (!task?.id) return
  const updates = { ...task, agentId: 3, updatedAt: new Date().toISOString() }
  const existing = driverStore.getTask(task.id)
  if (existing) {
    driverStore.updateTask(task.id, updates)
  } else {
    driverStore.addTask({
      title: 'New Driver Task',
      status: 'idle',
      progress: 0,
      result: null,
      time: new Date().toLocaleString(),
      fileMeta: null,
      chatMessages: [],
      serialLogs: [],
      driverState: {},
      ...updates,
    })
  }

  if (activeAgent.value?.id === 3 && (!activeSession.value || activeSession.value.id === task.id)) {
    activeSession.value = driverStore.getTask(task.id)
  }
}

function handleBatchTestTaskUpdated(task) {
  if (!task?.id) return
  const existing = batchTestStore.getTask(task.id)
  const updates = createBatchTaskUpdates(existing || task, {
    ...task,
    status: task.status || existing?.status || 'idle',
  })

  if (existing) {
    batchTestStore.updateTask(task.id, updates)
  } else {
    batchTestStore.addTask({
      title: 'New Batch Test',
      status: 'idle',
      progress: 0,
      result: null,
      time: new Date().toLocaleString(),
      selectedFiles: [],
      completedCount: 0,
      failedCount: 0,
      totalCount: 0,
      ...updates,
    })
  }

  if (activeUnittestBatchSession.value?.id === task.id) {
    activeUnittestBatchSession.value = batchTestStore.getTask(task.id)
  }
}

function handleBatchRunRequested(request) {
  const taskId = request?.id || activeUnittestBatchSession.value?.id
  const task = taskId ? batchTestStore.getTask(taskId) : null
  if (!task) return

  const selectedFiles = request.selectedFiles || task.selectedFiles || []
  batchTestStore.updateTask(taskId, createBatchTaskUpdates(task, {
    title: request.title || task.title || 'New Batch Test',
    status: 'queued',
    progress: 0,
    selectedFiles,
    totalCount: request.totalCount || selectedFiles.length,
    completedCount: 0,
    failedCount: 0,
    batchTaskId: null,
    batchDetail: null,
    items: [],
    terminalReason: null,
    blockedReason: null,
    resumeRequired: false,
    error: null,
    queuedAt: new Date().toISOString(),
  }))
  activeUnittestBatchSession.value = batchTestStore.getTask(taskId)
}

function handleTaskUpdated(task) {
  console.log('[DEBUG] handleTaskUpdated called with:', task)
  console.log('[DEBUG] activeSession:', activeSession.value)

  if (!task) {
    console.log('[DEBUG] task is null')
    return
  }

  // If a real task_id is provided, prioritize finding/creating by it
  if (task.id) {
    const existing = unittestStore.getTask(task.id)
    if (existing) {
      // Already exists, update it
      unittestStore.updateTask(task.id, task)
      activeSession.value = unittestStore.getTask(task.id)
    } else {
      // Does not exist, check whether there is already an active agent2 task (re-run case)
      const prevSession = activeSession.value
      if (prevSession && prevSession.agentId === 2 && prevSession.id) {
        // If the previous session was a temporary task, delete it
        if (prevSession.id.startsWith('__temp_')) {
          console.log('[DEBUG] Removing temporary task:', prevSession.id)
          // Don't call deleteTask for temp IDs, just clear activeSession
        } else {
          // Replace the old task with the new backend task_id to avoid duplicate sidebar entries
          unittestStore.deleteTask(prevSession.id)
        }
      }
      const newTask = {
        id: task.id,
        title: task.title || prevSession?.title || 'New Task',
        status: task.status || 'idle',
        progress: task.progress || 0,
        result: task.result || null,
        fileMeta: task.fileMeta || null,
        liveNodes: Array.isArray(task.liveNodes) ? task.liveNodes : [],
        currentStage: task.currentStage || '',
        statusMessage: task.statusMessage || '',
        error: task.error || null,
        selectedFileSnapshot: task.selectedFileSnapshot || null,
        outputDir: task.outputDir || '',
        selectedFramework: task.selectedFramework,
        selectedLayer: task.selectedLayer,
        selectedPlatform: task.selectedPlatform,
        time: new Date().toLocaleString(),
        agentId: 2,
        updatedAt: task.updatedAt || new Date().toISOString(),
      }
      unittestStore.addTask(newTask)
      activeSession.value = newTask
    }
    console.log('[DEBUG] Task synced with id:', task.id)
    return
  }

  // No ID case: only update temporary display and do not write to storage
  if (!activeSession.value || activeSession.value.agentId !== 2) {
    // No active task, create a temporary session for sidebar display (not persisted)
    activeSession.value = {
      id: '__temp_' + Date.now(),
      title: task.title || 'New Task',
      status: 'idle',
      progress: 0,
      time: new Date().toLocaleString(),
      agentId: 2,
      _temp: true,  // Mark as temporary, do not write to storage
    }
    console.log('[DEBUG] Created temp session for title display:', activeSession.value)
    return
  }

  // Existing active task, update title (also sync to storage so the sidebar refreshes too)
  const updatedSession = { ...activeSession.value, title: task.title || activeSession.value.title }
  activeSession.value = updatedSession
  if (activeSession.value.id && !activeSession.value._temp) {
    unittestStore.updateTask(activeSession.value.id, { title: updatedSession.title })
  }
}

/**
 * Streaming typewriter effect - display text character by character
 * Write the full content into the store at once and control only the render range through displayIndex
 * to avoid truncating code blocks during typing
 */
async function typewriterEffect(sessionId, messageId, text, speed = 30) {
  // Store the full content first, with typing=true
  chatStore.updateMessage(sessionId, messageId, {
    content: text,
    typing: true,
    displayIndex: 0,
  })

  const totalLength = text.length
  let index = 0

  return new Promise((resolve) => {
    const tick = setInterval(() => {
      // Advance 2 characters each time (slower speed for a more streaming feel)
      index = Math.min(index + 2, totalLength)
      chatStore.updateMessage(sessionId, messageId, { displayIndex: index })

      if (index >= totalLength) {
        clearInterval(tick)
        chatStore.updateMessage(sessionId, messageId, {
          typing: false,
          displayIndex: totalLength,
        })
        resolve()
      }
    }, speed)
  })
}


function clearChat() {
  if (activeSession.value) chatStore.clearMessages(activeSession.value.id)
}

function deleteMessage(messageId) {
  if (activeSession.value) chatStore.deleteMessage(activeSession.value.id, messageId)
}

async function sendMessage(content, webSearchEnabled = true, files = []) {
  if (!activeSession.value) {
    if (!activeAgent.value) return
    startAgentChat(activeAgent.value)
  }

  const session = activeSession.value
  const agent   = agents.value.find(a => a.id === session.agentId)

  const userMsg = {
    id:   Date.now(),
    role: 'user',
    content,
    attachments: files.map(file => file.name),
    time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
  }
  chatStore.addMessage(session.id, userMsg)

  // Auto-set session title from first message
  if (session.title === 'New Chat') {
    chatStore.renameSession(session.id, content.slice(0, 20) + (content.length > 20 ? '...' : ''))
  }

  // AI placeholder message (streaming typing state)
  const aiMsgId = Date.now() + 1
  chatStore.addMessage(session.id, {
    id:     aiMsgId,
    role:   'assistant',
    content: '',
    time:   new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    typing: true,
  })

  try {
    const agentBackendId = agentBackendMap[agent?.id] || 'chat'
    const res = await apiSendMessage(agentBackendId, content, session.id, webSearchEnabled, files)

    const responseText = res?.response || EMPTY_CHAT_RESPONSE_MESSAGE
    const artifacts = res?.metadata?.data?.artifacts
    if (Array.isArray(artifacts) && artifacts.length) {
      chatStore.updateMessage(session.id, aiMsgId, { content: responseText, artifacts, typing: false })
    } else {
      await typewriterEffect(session.id, aiMsgId, responseText)
    }
  } catch (error) {
    console.error('Failed to send chat message:', error)
    chatStore.updateMessage(session.id, aiMsgId, {
      content: getChatErrorMessage(error),
      typing: false,
    })
  }
}

function handleLogout() {
  authStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.app-layout {
  display: flex;
  height: 100vh;
  background: #f5f7fa;
  overflow: hidden;
}

.main-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  min-width: 0;
}

.content-area {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.generated-agent-loading {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: #f8f9fb;
  color: #64748b;
  text-align: center;
}
.generated-agent-loading p { margin: 8px 0 0; color: #334155; font-size: 14px; font-weight: 600; }
.generated-agent-loading small { color: #94a3b8; font-size: 11px; }
.driver-workspace-empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 16px;
  padding: 32px;
  color: #334155;
  text-align: center;
}
.driver-workspace-empty p { margin: 0; color: #64748b; }
.loading-icon { color: #2563eb; font-size: 24px; animation: generated-agent-spin 1s linear infinite; }
@keyframes generated-agent-spin { to { transform: rotate(360deg); } }

.chat-notice {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #f8f9fb;
  text-align: center;
  padding: 40px;
}

.notice-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea18 0%, #764ba218 100%);
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
