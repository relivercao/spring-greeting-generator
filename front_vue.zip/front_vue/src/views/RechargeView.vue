<template>
  <div class="recharge-page">
    <!-- Top bar -->
    <header class="page-header">
      <button
        type="button"
        class="back-link"
        @click="router.push('/')"
      >
        <el-icon size="14">
          <ArrowLeft />
        </el-icon>
        <span>Back to App</span>
      </button>
      <h1 class="page-title">
        Recharge
      </h1>
      <div class="header-spacer" />
    </header>

    <main class="page-body">
      <!-- ═══ Inline paying phase ═══ -->
      <div
        v-if="phase === 'paying'"
        class="paying-wrap"
      >
        <PaymentStatusPanel
          :order-id="activeOrder.id"
          :initial-order="activeOrder"
          :payment-type="activeOrder.payment_type || paymentType"
          @success="onPaymentSuccess"
          @done="exitPayingPhase"
          @retry="exitPayingPhase"
        />
      </div>

      <!-- ═══ Select phase ═══ -->
      <template v-else>
        <!-- Account card: balance + level + progress -->
        <section class="account-card">
          <div class="account-main">
            <div class="balance-block">
              <span class="balance-label">Current balance</span>
              <span class="balance-value">{{ formatMoney(authStore.user?.balance) }}</span>
            </div>
            <div
              v-if="currentLevel"
              class="level-badge"
              :class="`tier-${currentLevel.key}`"
            >
              <svg
                viewBox="0 0 24 24"
                fill="none"
              >
                <path
                  d="M12 2.5l2.6 5.6 6.1.8-4.5 4.2 1.1 6-5.3-3-5.3 3 1.1-6L3.3 8.9l6.1-.8L12 2.5z"
                  fill="currentColor"
                />
              </svg>
              <span>{{ currentLevel.name }}</span>
              <span
                v-if="levelDiscountPercent > 0"
                class="level-discount"
              >{{ levelDiscountPercent }}% off usage</span>
            </div>
          </div>

          <!-- Level ladder progress -->
          <div
            v-if="levelProgress && levels.length > 1"
            class="level-progress"
          >
            <div class="progress-info">
              <template v-if="nextLevel">
                <span>
                  Recharged cumulatively
                  <strong>{{ formatMoney(levelProgress.total_recharged) }}</strong>
                </span>
                <span class="progress-next">
                  {{ formatMoney(levelProgress.remaining_to_next) }} more to
                  <strong>{{ nextLevel.name }}</strong>
                </span>
              </template>
              <template v-else>
                <span>
                  Recharged cumulatively
                  <strong>{{ formatMoney(levelProgress.total_recharged) }}</strong>
                </span>
                <span class="progress-next">Top tier reached</span>
              </template>
            </div>
            <div class="progress-track">
              <div
                class="progress-fill"
                :style="{ width: `${progressPercent}%` }"
              />
            </div>
            <div class="progress-marks">
              <span
                v-for="level in levels"
                :key="level.key"
                class="mark"
                :class="{ reached: reachedLevels.includes(level.key) }"
              >{{ level.name }}</span>
            </div>
          </div>
        </section>

        <!-- Loading skeleton -->
        <div
          v-if="loadingCheckout"
          class="section-card loading-card"
        >
          <el-icon
            class="loading-icon is-loading"
            :size="22"
          >
            <Loading />
          </el-icon>
          <span>Loading recharge options...</span>
        </div>

        <template v-else>
          <!-- Tab pill switcher -->
          <div
            v-if="plans.length"
            class="tab-pills"
          >
            <button
              type="button"
              class="pill"
              :class="{ active: activeTab === 'plans' }"
              @click="activeTab = 'plans'"
            >
              Preset plans
            </button>
            <button
              type="button"
              class="pill"
              :class="{ active: activeTab === 'custom' }"
              @click="activeTab = 'custom'"
            >
              Custom amount
            </button>
          </div>

          <!-- Preset plans tab -->
          <section
            v-if="activeTab === 'plans' && plans.length"
            class="section-card"
          >
            <div class="plan-grid">
              <PlanCard
                v-for="(plan, index) in plans"
                :key="plan.id"
                :plan="plan"
                :selected="selectedPlanId === plan.id"
                :accent-index="index"
                @select="selectPlan(plan)"
              />
            </div>
          </section>

          <!-- Custom amount tab -->
          <section
            v-else
            class="section-card"
          >
            <AmountInput
              v-model="customAmount"
              :amounts="quickAmounts"
              :min="numericLimit('min_recharge_amount', 1)"
              :max="effectiveMax"
            />
            <p
              v-if="customAmountError"
              class="limit-hint error"
            >
              {{ customAmountError }}
            </p>
            <p
              v-else
              class="limit-hint"
            >
              Daily remaining quota {{ formatMoney(limits.daily_remaining) }}
            </p>
          </section>

          <!-- Payment method -->
          <section class="section-card">
            <PaymentMethodSelector
              :methods="paymentMethods"
              :selected="paymentType"
              :fee-rate="feeRate"
              @select="paymentType = $event"
            />
            <p
              v-if="!paymentMethods.length"
              class="limit-hint error"
            >
              No payment method is currently available. Please contact the administrator.
            </p>
          </section>

          <!-- Order summary -->
          <section class="section-card summary-card">
            <div class="summary-row">
              <span>Recharge amount</span>
              <span>{{ formatMoney(selectedAmount) }}</span>
            </div>
            <div
              v-if="bonusAmount > 0"
              class="summary-row"
            >
              <span>Extra bonus</span>
              <span class="bonus">+{{ formatMoney(bonusAmount) }}</span>
            </div>
            <div class="summary-row total">
              <span>You pay</span>
              <span class="pay">{{ formatMoney(selectedAmount) }}</span>
            </div>
            <div class="summary-row credited">
              <span>Credited to balance</span>
              <span class="credited-value">{{ formatMoney(creditedAmount) }}</span>
            </div>
          </section>

          <!-- CTA -->
          <el-button
            type="primary"
            size="large"
            class="submit-btn"
            :loading="submitting"
            :disabled="!canSubmit"
            @click="submitOrder"
          >
            {{ submitting ? 'Creating order...' : `Pay ${formatMoney(selectedAmount)}` }}
          </el-button>
        </template>
      </template>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { apiGetPlans, apiCreateOrder } from '@/api/payment'
import { useAuthStore } from '@/stores/auth'
import AmountInput from '@/components/payment/AmountInput.vue'
import PaymentMethodSelector from '@/components/payment/PaymentMethodSelector.vue'
import PlanCard from '@/components/payment/PlanCard.vue'
import PaymentStatusPanel from '@/components/payment/PaymentStatusPanel.vue'

const router = useRouter()
const authStore = useAuthStore()

// Fallback labels for payment methods returned as raw keys by the backend
const PAYMENT_METHOD_LABELS = {
  alipay: 'Alipay',
  wxpay: 'WeChat Pay',
  wechat: 'WeChat Pay',
}

const loadingCheckout = ref(true)
const submitting = ref(false)
const plans = ref([])
const limits = ref({})
const levels = ref([])
const levelProgress = ref(null)
const rawMethods = ref([])
const paymentType = ref('alipay')
const customAmount = ref(null)
const selectedPlan = ref(null)
const activeTab = ref('plans')

// Inline paying phase state
const phase = ref('select')
const activeOrder = ref(null)

const quickAmounts = [10, 20, 50, 100, 200, 500, 1000]

// ── Derived state ──
const selectedPlanId = computed(() => selectedPlan.value?.id ?? null)

const paymentMethods = computed(() => normalizeMethods(rawMethods.value))

const feeRate = computed(() => Number(limits.value.fee_rate) || 0)

const currentLevel = computed(() => levelProgress.value?.current_level || null)

const nextLevel = computed(() => levelProgress.value?.next_level || null)

const levelDiscountPercent = computed(
  () => Math.round(Number(currentLevel.value?.discount_percent) || 0),
)

const reachedLevels = computed(() => {
  const total = Number(levelProgress.value?.total_recharged) || 0
  return levels.value.filter((l) => total >= Number(l.threshold)).map((l) => l.key)
})

const progressPercent = computed(() => {
  const progress = levelProgress.value
  if (!progress || !nextLevel.value) return 100
  const total = Number(progress.total_recharged) || 0
  const base = Number(currentLevel.value?.threshold) || 0
  const target = Number(nextLevel.value.threshold) || 1
  const span = Math.max(target - base, 1)
  return Math.min(100, Math.max(0, ((total - base) / span) * 100))
})

const effectiveMax = computed(() => {
  const max = numericLimit('max_recharge_amount', 1000)
  const daily = Number(limits.value.daily_remaining)
  if (Number.isFinite(daily) && daily > 0) return Math.min(max, daily)
  return max
})

const selectedAmount = computed(() => {
  if (selectedPlan.value) return Number(selectedPlan.value.price) || 0
  return Number(customAmount.value) || 0
})

const multiplier = computed(() => Number(limits.value.recharge_multiplier) || 1)

const creditedAmount = computed(() => {
  if (selectedPlan.value) return Number(selectedPlan.value.credited_amount) || 0
  return Math.round(selectedAmount.value * multiplier.value * 100) / 100
})

const bonusAmount = computed(() => {
  if (selectedPlan.value) {
    return Math.max(
      0,
      (Number(selectedPlan.value.credited_amount) || 0) - (Number(selectedPlan.value.price) || 0),
    )
  }
  return Math.max(0, creditedAmount.value - selectedAmount.value)
})

const customAmountError = computed(() => {
  if (activeTab.value === 'plans') return ''
  const amount = Number(customAmount.value)
  if (!customAmount.value || !Number.isFinite(amount) || amount <= 0) return ''
  const min = numericLimit('min_recharge_amount', 1)
  if (amount < min) return `Minimum recharge amount is ${formatMoney(min)}.`
  if (amount > effectiveMax.value) {
    if (Number.isFinite(Number(limits.value.daily_remaining))
      && Number(limits.value.daily_remaining) > 0
      && amount > Number(limits.value.daily_remaining)) {
      return `Daily remaining recharge quota is ${formatMoney(limits.value.daily_remaining)}.`
    }
    return `Maximum recharge amount is ${formatMoney(limits.value.max_recharge_amount)}.`
  }
  return ''
})

const canSubmit = computed(() => {
  if (!paymentMethods.value.length || customAmountError.value) return false
  if (activeTab.value === 'plans') return selectedPlanId.value !== null
  const amount = Number(customAmount.value)
  return Number.isFinite(amount) && amount > 0
})

// ── Helpers ──
function formatMoney(value) {
  const num = Number(value)
  return `¥${(Number.isFinite(num) ? num : 0).toFixed(2)}`
}

function numericLimit(key, fallback) {
  const num = Number(limits.value?.[key])
  return Number.isFinite(num) && num > 0 ? num : fallback
}

function normalizeMethods(list) {
  if (!Array.isArray(list)) return []
  return list
    .map((item) => {
      if (typeof item === 'string') {
        return { value: item, label: PAYMENT_METHOD_LABELS[item] || item }
      }
      if (item && typeof item === 'object') {
        const value = item.method || item.value || item.key || item.type || item.code
        const label = item.label || item.name || PAYMENT_METHOD_LABELS[value] || value
        return value ? { value, label } : null
      }
      return null
    })
    .filter(Boolean)
}

function selectPlan(plan) {
  selectedPlan.value = selectedPlanId.value === plan.id ? null : plan
}

// ── Data loading ──
async function loadCheckout() {
  try {
    const data = await apiGetPlans()
    plans.value = Array.isArray(data?.plans) ? data.plans : []
    limits.value = data?.limits || {}
    levels.value = Array.isArray(data?.levels) ? data.levels : []
    levelProgress.value = data?.level_progress || null
    rawMethods.value = data?.payment_methods || []
    if (paymentMethods.value.length
      && !paymentMethods.value.some((m) => m.value === paymentType.value)) {
      paymentType.value = paymentMethods.value[0].value
    }
    // Default to the plans tab when presets exist, else custom amount
    if (!plans.value.length) activeTab.value = 'custom'
  } catch (e) {
    ElMessage.error(e.message || 'Failed to load recharge options.')
  } finally {
    loadingCheckout.value = false
  }
}

onMounted(async () => {
  await loadCheckout()
  // Refresh the balance chip data if the profile is available
  if (authStore.isLoggedIn && typeof authStore.fetchProfile === 'function') {
    authStore.fetchProfile().catch(() => {})
  }
})

// ── Order creation and paying phase ──
async function submitOrder() {
  if (submitting.value || !canSubmit.value) return
  submitting.value = true
  try {
    const payload = activeTab.value === 'plans' && selectedPlan.value
      ? { plan_id: selectedPlan.value.id, payment_type: paymentType.value }
      : { amount: Number(customAmount.value), payment_type: paymentType.value }
    const order = await apiCreateOrder(payload)
    if (!order?.id) throw new Error('Order response did not contain an id.')
    activeOrder.value = order
    phase.value = 'paying'
    // Popup mode: open the gateway window alongside the inline panel
    if (order.pay_mode === 'popup' && order.pay_url) {
      window.open(order.pay_url, '_blank', 'noopener')
    }
  } catch (e) {
    // The http wrapper already normalizes backend detail messages
    ElMessage.error(e.message || 'Failed to create the order.')
  } finally {
    submitting.value = false
  }
}

function onPaymentSuccess() {
  // Balance and level progress may both have moved
  if (authStore.isLoggedIn && typeof authStore.fetchProfile === 'function') {
    authStore.fetchProfile().catch(() => {})
  }
}

async function exitPayingPhase() {
  phase.value = 'select'
  activeOrder.value = null
  selectedPlan.value = null
  customAmount.value = null
  await loadCheckout()
}
</script>

<style scoped>
.recharge-page {
  min-height: 100vh;
  background: #f0f4ff;
  display: flex;
  flex-direction: column;
}

/* ── Top bar ── */
.page-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 32px;
  background: #ffffff;
  border-bottom: 1px solid #e8edf3;
}

.back-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: none;
  background: transparent;
  color: #6b7280;
  font-size: 13px;
  cursor: pointer;
  padding: 6px 10px;
  border-radius: 7px;
  transition: color 0.2s, background 0.2s;
}

.back-link:hover { color: #2563eb; background: #eff6ff; }

.page-title {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
  margin: 0;
}

.header-spacer { flex: 1; }

/* Inline paying phase keeps the narrow payment column */
.paying-wrap {
  width: 100%;
  max-width: 460px;
  margin: 0 auto;
}

/* ── Body ── */
.page-body {
  flex: 1;
  width: 100%;
  max-width: 960px;
  margin: 0 auto;
  padding: 28px 24px 48px;
}

/* ── Account card ── */
.account-card {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 22px 24px;
  margin-bottom: 18px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}

.account-main {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
}

.balance-block { display: flex; flex-direction: column; gap: 2px; }

.balance-label { font-size: 12px; color: #6b7280; }

.balance-value {
  font-size: 28px;
  font-weight: 800;
  color: #1f2937;
  letter-spacing: -0.5px;
}

.level-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border-radius: 999px;
  padding: 6px 14px;
  font-size: 13px;
  font-weight: 700;
  background: #eff6ff;
  color: #1d4ed8;
  border: 1px solid #bfdbfe;
}

.level-badge svg { width: 15px; height: 15px; }

.level-badge.tier-silver { background: #f1f5f9; color: #475569; border-color: #cbd5e1; }
.level-badge.tier-gold { background: #fef3c7; color: #b45309; border-color: #fde68a; }
.level-badge.tier-platinum {
  background: linear-gradient(135deg, #eff6ff, #f5f3ff);
  color: #6d28d9;
  border-color: #c7d2fe;
}

.level-discount {
  font-size: 11px;
  font-weight: 600;
  opacity: 0.85;
  padding-left: 6px;
  border-left: 1px solid currentColor;
}

/* Level ladder progress */
.level-progress { margin-top: 18px; }

.progress-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  font-size: 12px;
  color: #6b7280;
  margin-bottom: 8px;
  flex-wrap: wrap;
}

.progress-info strong { color: #111827; font-weight: 700; }

.progress-next { color: #2563eb; }

.progress-track {
  height: 8px;
  border-radius: 999px;
  background: #e8edf3;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: 999px;
  background: linear-gradient(90deg, #2563eb, #60a5fa);
  transition: width 0.4s ease;
}

.progress-marks {
  display: flex;
  justify-content: space-between;
  margin-top: 6px;
}

.progress-marks .mark {
  font-size: 11px;
  color: #9ca3af;
  font-weight: 600;
}

.progress-marks .mark.reached { color: #2563eb; }

/* ── Tabs ── */
.tab-pills {
  display: inline-flex;
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 999px;
  padding: 4px;
  gap: 4px;
  margin-bottom: 18px;
}

.pill {
  border: none;
  background: transparent;
  border-radius: 999px;
  padding: 8px 20px;
  font-size: 13px;
  font-weight: 600;
  color: #6b7280;
  cursor: pointer;
  transition: background 0.15s, color 0.15s, box-shadow 0.15s;
}

.pill:hover { color: #2563eb; }

.pill.active {
  background: #2563eb;
  color: #ffffff;
  box-shadow: 0 2px 8px rgba(37, 99, 235, 0.28);
}

/* ── Sections ── */
.section-card {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 22px 24px;
  margin-bottom: 18px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}

.loading-card {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #6b7280;
  font-size: 14px;
  padding: 48px 24px;
}

.loading-icon.is-loading { animation: rc-spin 0.9s linear infinite; }

@keyframes rc-spin { to { transform: rotate(360deg); } }

.plan-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
  gap: 14px;
}

.limit-hint { font-size: 12px; color: #9ca3af; margin: 14px 0 0; }

.limit-hint.error { color: #ef4444; }

/* ── Summary card ── */
.summary-card { display: flex; flex-direction: column; }

.summary-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  color: #6b7280;
  padding: 9px 0;
}

.summary-row + .summary-row { border-top: 1px dashed #eef2f7; }

.summary-row .bonus { color: #d97706; font-weight: 600; }

.summary-row.total .pay {
  font-size: 20px;
  font-weight: 800;
  color: #111827;
}

.summary-row.credited .credited-value {
  font-size: 15px;
  font-weight: 800;
  color: #16a34a;
}

/* ── CTA ── */
.submit-btn {
  width: 100%;
  height: 50px;
  font-size: 16px;
  font-weight: 700;
  border-radius: 12px;
}

/* ── Responsive ── */
@media (max-width: 768px) {
  .page-header { padding: 12px 16px; }
  .page-body { padding: 20px 16px 40px; }
  .plan-grid { grid-template-columns: 1fr 1fr; }
  .account-main { flex-direction: column; align-items: flex-start; }
}
</style>
