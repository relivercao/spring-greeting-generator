<template>
  <div class="payment-page">
    <!-- Top bar -->
    <header class="page-header">
      <button
        type="button"
        class="back-link"
        @click="router.push('/orders')"
      >
        <el-icon size="14">
          <ArrowLeft />
        </el-icon>
        <span>Back to orders</span>
      </button>
      <h1 class="page-title">
        Order payment
      </h1>
      <div class="header-spacer" />
    </header>

    <main class="page-body">
      <!-- Initial loading -->
      <div
        v-if="loading"
        class="status-card loading-card"
      >
        <el-icon
          class="loading-icon is-loading"
          :size="22"
        >
          <Loading />
        </el-icon>
        <span>Loading order details...</span>
      </div>

      <!-- Load failure -->
      <div
        v-else-if="loadError"
        class="status-card"
      >
        <el-icon
          :size="40"
          class="state-icon error"
        >
          <CircleCloseFilled />
        </el-icon>
        <h2 class="state-title">
          Unable to load the order
        </h2>
        <p class="state-desc">
          {{ loadError }}
        </p>
        <el-button @click="router.push('/orders')">
          Back to orders
        </el-button>
      </div>

      <!-- Payment lifecycle panel (QR / countdown / states / polling) -->
      <PaymentStatusPanel
        v-else-if="order"
        :order-id="order.id"
        :initial-order="order"
        :payment-type="order.payment_type || ''"
        @success="onSuccess"
        @done="goOrders"
        @retry="goRecharge"
      />
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { apiOrderDetail } from '@/api/payment'
import { useAuthStore } from '@/stores/auth'
import PaymentStatusPanel from '@/components/payment/PaymentStatusPanel.vue'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

const loading = ref(true)
const loadError = ref('')
const order = ref(null)

onMounted(async () => {
  const orderId = route?.params?.orderId || null
  if (!orderId) {
    loadError.value = 'Missing order id.'
    loading.value = false
    return
  }
  try {
    order.value = await apiOrderDetail(orderId)
  } catch (e) {
    loadError.value = e.message || 'The order could not be loaded.'
  } finally {
    loading.value = false
  }
})

function onSuccess() {
  // Balance may have moved; refresh the header chip
  if (authStore.isLoggedIn && typeof authStore.fetchProfile === 'function') {
    authStore.fetchProfile().catch(() => {})
  }
}

function goOrders() {
  router.push('/orders')
}

function goRecharge() {
  router.push('/recharge')
}
</script>

<style scoped>
.payment-page {
  min-height: 100vh;
  background: #f0f4ff;
  display: flex;
  flex-direction: column;
}

.page-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 32px;
  background: #ffffff;
  border-bottom: 1px solid #e8edf3;
}

.back-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: none;
  background: transparent;
  color: #6b7280;
  font-size: 13px;
  cursor: pointer;
  padding: 6px 10px;
  border-radius: 7px;
  transition: color 0.2s, background 0.2s;
}

.back-link:hover { color: #2563eb; background: #eff6ff; }

.page-title {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
  margin: 0;
}

.header-spacer { flex: 1; }

.page-body {
  flex: 1;
  width: 100%;
  max-width: 460px;
  margin: 0 auto;
  padding: 28px 24px 48px;
}

.status-card {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 32px 24px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  text-align: center;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}

.loading-card {
  flex-direction: row;
  color: #6b7280;
  font-size: 14px;
}

.loading-icon.is-loading { animation: pv-spin 0.9s linear infinite; }

@keyframes pv-spin { to { transform: rotate(360deg); } }

.state-icon.error { color: #ef4444; }

.state-title {
  font-size: 17px;
  font-weight: 800;
  color: #1f2937;
  margin: 0;
}

.state-desc { font-size: 13px; color: #6b7280; margin: 0; }
</style>
