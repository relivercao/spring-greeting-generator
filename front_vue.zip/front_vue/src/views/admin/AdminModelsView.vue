<template>
  <div class="model-page">
    <div class="heading">
      <div>
        <h2>Models &amp; Pricing</h2>
        <p>Manage the catalog and token prices for each provider.</p>
      </div>
      <el-button type="primary" @click="openEditor()">Add Model</el-button>
    </div>
    <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
    <el-alert
      title="All prices are USD per 1M tokens. Catalog prices take priority over existing model overrides and fallback prices. Price changes affect future calls only."
      type="info"
      :closable="false"
    />
    <el-card shadow="never">
      <div class="toolbar">
        <el-input
          v-model="keyword"
          placeholder="Search model or provider"
          clearable
          @input="page = 1"
        />
        <el-button :loading="loading" @click="load">Refresh</el-button>
        <el-button :loading="discovering" @click="discover">Add Configured Models</el-button>
      </div>
      <el-table
        v-loading="loading"
        :data="visibleModels"
        stripe
        empty-text="No models yet. Add configured models or import a pricing file."
      >
        <el-table-column prop="display_name" label="Model" min-width="210">
          <template #default="{ row }"
            ><strong>{{ row.display_name }}</strong>
            <div class="muted">{{ row.model }}</div></template
          >
        </el-table-column>
        <el-table-column prop="provider" label="Provider" width="120" />
        <el-table-column label="Input / Output" min-width="150"
          ><template #default="{ row }"
            >{{ price(row.input_usd_per_mtok) }} / {{ price(row.output_usd_per_mtok) }}</template
          ></el-table-column
        >
        <el-table-column label="Cache read / write" min-width="155"
          ><template #default="{ row }"
            >{{ price(row.cache_read_usd_per_mtok) }} /
            {{ price(row.cache_write_usd_per_mtok) }}</template
          ></el-table-column
        >
        <el-table-column label="Context" width="110"
          ><template #default="{ row }">{{
            row.context_window?.toLocaleString() || 'Unset'
          }}</template></el-table-column
        >
        <el-table-column label="Picker" width="90"
          ><template #default="{ row }"
            ><el-tag :type="row.enabled ? 'success' : 'info'">{{
              row.enabled ? 'Visible' : 'Hidden'
            }}</el-tag></template
          ></el-table-column
        >
        <el-table-column label="Actions" width="140" fixed="right"
          ><template #default="{ row }"
            ><el-button link type="primary" @click="openEditor(row)">Edit</el-button
            ><el-button link type="danger" @click="remove(row)">Delete</el-button></template
          ></el-table-column
        >
      </el-table>
      <el-pagination
        v-model:current-page="page"
        :page-size="20"
        :total="filteredModels.length"
        layout="total, prev, pager, next"
      />
    </el-card>
    <el-collapse>
      <el-collapse-item title="Fallback pricing & existing model overrides" name="defaults">
        <p class="muted">
          Used when a model has no catalog price. Unset cache prices use the input rate. Hiding a
          model only removes it from pickers.
        </p>
        <el-form inline>
          <el-form-item label="Input USD / 1M"
            ><el-input-number
              v-model="defaults.input_usd_per_mtok"
              :min="0"
              :max="1000000"
              :precision="6"
          /></el-form-item>
          <el-form-item label="Output USD / 1M"
            ><el-input-number
              v-model="defaults.output_usd_per_mtok"
              :min="0"
              :max="1000000"
              :precision="6"
          /></el-form-item>
          <el-form-item
            ><el-button :loading="savingDefaults" @click="saveDefaults"
              >Save Fallback</el-button
            ></el-form-item
          >
        </el-form>
        <el-table :data="legacyPrices" size="small" empty-text="No existing per-model overrides">
          <el-table-column prop="model" label="Existing model override (all providers)" />
          <el-table-column prop="input_usd_per_mtok" label="Input USD / 1M" />
          <el-table-column prop="output_usd_per_mtok" label="Output USD / 1M" />
        </el-table>
      </el-collapse-item>
      <el-collapse-item title="Import / export catalog" name="import">
        <p class="muted">
          Import a catalog JSON array or LiteLLM chat pricing JSON. LiteLLM per-token prices are
          converted to USD / 1M. Review the source date and prices before importing. Existing models
          are skipped unless overwrite is selected.
        </p>
        <div class="toolbar">
          <el-select v-model="importFormat" aria-label="Import format"
            ><el-option label="Catalog JSON" value="catalog" /><el-option
              label="LiteLLM JSON"
              value="litellm"
          /></el-select>
          <el-input
            v-if="importFormat === 'litellm'"
            v-model="importProvider"
            placeholder="Target provider, e.g. macode"
          />
          <input
            aria-label="Pricing JSON file"
            type="file"
            accept=".json,application/json"
            @change="readFile"
          />
          <el-checkbox v-model="overwrite">Overwrite matching models</el-checkbox>
          <el-button @click="exportCatalog">Export Catalog</el-button>
        </div>
        <el-input
          v-model="importText"
          type="textarea"
          :rows="5"
          placeholder="Paste pricing JSON or select a file"
        />
        <el-button
          type="primary"
          :loading="importing"
          :disabled="!importText.trim()"
          @click="runImport"
          >Import Prices</el-button
        >
        <p v-if="importResult" role="status">{{ importResult }}</p>
      </el-collapse-item>
    </el-collapse>
    <el-dialog
      v-model="editorVisible"
      :title="editingId ? 'Edit Model' : 'Add Model'"
      width="min(640px, calc(100vw - 32px))"
      class="model-editor"
    >
      <el-alert v-if="editorError" :title="editorError" type="error" :closable="false" />
      <el-form label-position="top" class="edit-grid">
        <el-form-item label="Provider"
          ><el-select v-model="form.provider" filterable allow-create
            ><el-option
              v-for="provider in ['macode', 'bedrock', 'claude_cli']"
              :key="provider"
              :label="provider"
              :value="provider" /></el-select
        ></el-form-item>
        <el-form-item label="Model ID"
          ><el-input v-model="form.model" maxlength="200"
        /></el-form-item>
        <el-form-item label="Display name"
          ><el-input v-model="form.display_name" maxlength="200" placeholder="Defaults to model ID"
        /></el-form-item>
        <el-form-item label="Show in model pickers"
          ><el-switch v-model="form.enabled"
        /></el-form-item>
        <el-form-item label="Context window"
          ><el-input-number v-model="form.context_window" :min="1" :max="100000000" :precision="0"
        /></el-form-item>
        <el-form-item label="Max output tokens"
          ><el-input-number
            v-model="form.max_output_tokens"
            :min="1"
            :max="100000000"
            :precision="0"
        /></el-form-item>
        <el-form-item v-for="field in rateFields" :key="field.key" :label="field.label"
          ><el-input-number
            v-model="form[field.key]"
            :min="0"
            :max="1000000"
            :precision="6"
            placeholder="Use fallback"
        /></el-form-item>
      </el-form>
      <p class="muted">
        Set both input/output prices or leave both blank for fallback. Zero is an explicit free
        price. Catalog changes do not change provider credentials or the active model.
      </p>
      <template #footer
        ><el-button @click="editorVisible = false">Cancel</el-button
        ><el-button type="primary" :loading="saving" @click="save">Save Model</el-button></template
      >
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import * as api from '../../api/modelManagement.js'

const models = ref([]),
  keyword = ref(''),
  page = ref(1),
  error = ref(''),
  loading = ref(false)
const editorVisible = ref(false),
  editorError = ref(''),
  editingId = ref(''),
  saving = ref(false)
const defaults = reactive({ input_usd_per_mtok: 3, output_usd_per_mtok: 15 })
const legacyPrices = ref([]),
  savingDefaults = ref(false),
  discovering = ref(false)
const importFormat = ref('catalog'),
  importProvider = ref('macode'),
  overwrite = ref(false)
const importText = ref(''),
  importing = ref(false),
  importResult = ref('')
const rateFields = [
  { key: 'input_usd_per_mtok', label: 'Input USD / 1M' },
  { key: 'output_usd_per_mtok', label: 'Output USD / 1M' },
  { key: 'cache_read_usd_per_mtok', label: 'Cache read USD / 1M' },
  { key: 'cache_write_usd_per_mtok', label: 'Cache write USD / 1M' },
]
const emptyForm = () => ({
  provider: 'macode',
  model: '',
  display_name: '',
  enabled: true,
  context_window: null,
  max_output_tokens: null,
  input_usd_per_mtok: null,
  output_usd_per_mtok: null,
  cache_read_usd_per_mtok: null,
  cache_write_usd_per_mtok: null,
  source: 'manual',
})
const form = reactive(emptyForm())
const filteredModels = computed(() =>
  models.value.filter(row =>
    `${row.model} ${row.display_name} ${row.provider}`
      .toLowerCase()
      .includes(keyword.value.toLowerCase())
  )
)
const visibleModels = computed(() =>
  filteredModels.value.slice((page.value - 1) * 20, page.value * 20)
)
const price = value =>
  value === null || value === undefined
    ? 'Fallback'
    : `$${value.toLocaleString('en-US', { maximumFractionDigits: 6 })}`

async function load() {
  loading.value = true
  try {
    const [catalog, pricing] = await Promise.all([api.listModels(), api.getDefaultPricing()])
    models.value = catalog.items
    Object.assign(defaults, pricing.default)
    legacyPrices.value = Object.entries(pricing.models || {}).map(([model, rates]) => ({
      model,
      ...rates,
    }))
    error.value = ''
  } catch (e) {
    error.value = e.message
  } finally {
    loading.value = false
  }
}
function openEditor(row) {
  editingId.value = row?.id || ''
  const blank = emptyForm()
  Object.assign(
    form,
    Object.fromEntries(Object.keys(blank).map(key => [key, row?.[key] ?? blank[key]]))
  )
  editorError.value = ''
  editorVisible.value = true
}
async function save() {
  saving.value = true
  try {
    const payload = {
      ...form,
      model: form.model.trim(),
      display_name: form.display_name.trim() || form.model.trim(),
    }
    for (const key of [
      'context_window',
      'max_output_tokens',
      ...rateFields.map(field => field.key),
    ])
      payload[key] ??= null
    if (editingId.value) await api.updateModel(editingId.value, payload)
    else await api.createModel(payload)
    editorVisible.value = false
    ElMessage.success('Model saved')
    await load()
  } catch (e) {
    editorError.value = e.message
  } finally {
    saving.value = false
  }
}
async function remove(row) {
  try {
    await ElMessageBox.confirm(
      `Delete ${row.model}? Future calls will use fallback pricing. Historical costs are preserved.`,
      'Delete Model',
      { type: 'warning' }
    )
    await api.deleteModel(row.id)
    await load()
  } catch (e) {
    if (e !== 'cancel' && e !== 'close') error.value = e.message || 'Delete failed'
  }
}
async function saveDefaults() {
  savingDefaults.value = true
  try {
    await api.updateDefaultPricing({ ...defaults })
    ElMessage.success('Fallback pricing saved')
  } catch (e) {
    error.value = e.message
  } finally {
    savingDefaults.value = false
  }
}
async function discover() {
  discovering.value = true
  try {
    await api.discoverModels()
    await load()
  } catch (e) {
    error.value = e.message
  } finally {
    discovering.value = false
  }
}
async function readFile(event) {
  const file = event.target.files?.[0]
  if (!file) return
  if (file.size > 5 * 1024 * 1024) {
    error.value = 'Pricing files must be at most 5 MB'
    return
  }
  try {
    importText.value = await file.text()
  } catch {
    error.value = 'Could not read pricing file'
  }
}
async function runImport() {
  importing.value = true
  importResult.value = ''
  try {
    const entries = JSON.parse(importText.value)
    const result = await api.importModels({
      format: importFormat.value,
      provider: importProvider.value,
      overwrite: overwrite.value,
      entries,
    })
    importResult.value = `Created ${result.created}, updated ${result.updated}, skipped ${result.skipped}.`
    await load()
  } catch (e) {
    error.value = e instanceof SyntaxError ? 'Invalid JSON. Check the pricing file.' : e.message
  } finally {
    importing.value = false
  }
}
function exportCatalog() {
  const keys = Object.keys(emptyForm())
  const payload = models.value.map(row => Object.fromEntries(keys.map(key => [key, row[key]])))
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
  )
  const link = document.createElement('a')
  link.href = url
  link.download = 'model-catalog.json'
  link.click()
  URL.revokeObjectURL(url)
}
onMounted(load)
</script>

<style scoped>
.model-page {
  display: grid;
  gap: 18px;
  max-width: 1500px;
  margin: auto;
}
:global(.model-editor .el-dialog__body) {
  max-height: calc(80vh - 140px);
  overflow-y: auto;
}
.heading,
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.heading h2 {
  margin: 0 0 8px;
}
.heading p,
.muted {
  color: #64748b;
  font-size: 13px;
}
.toolbar {
  margin-bottom: 16px;
  justify-content: flex-start;
}
.toolbar .el-input {
  max-width: 300px;
}
.toolbar .el-select {
  width: 180px;
}
.el-pagination {
  margin-top: 18px;
}
.edit-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0 20px;
  margin-top: 12px;
}
.edit-grid .el-input-number,
.edit-grid .el-select {
  width: 100%;
}
.el-alert {
  margin-bottom: 0;
}
@media (max-width: 700px) {
  .edit-grid {
    grid-template-columns: 1fr;
  }
}
</style>
