<template>
  <div class="admin-page">
    <div class="page-header">
      <h2>Payment Providers</h2>
      <p>Configure EasyPay provider instances used for recharge orders.</p>
    </div>

    <div class="toolbar-card">
      <el-button
        type="primary"
        @click="openCreate"
      >
        <el-icon class="btn-icon">
          <Plus />
        </el-icon>Add Provider
      </el-button>
      <el-button @click="loadProviders">
        <el-icon class="btn-icon">
          <Refresh />
        </el-icon>Refresh
      </el-button>
    </div>

    <el-card
      shadow="never"
      class="table-card"
    >
      <el-table
        v-loading="loading"
        :data="providers"
        stripe
      >
        <el-table-column
          prop="name"
          label="Name"
          min-width="140"
        />
        <el-table-column
          prop="provider_key"
          label="Provider"
          width="110"
        >
          <template #default="{ row }">
            {{ row.provider_key || 'easypay' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Enabled"
          width="90"
          align="center"
        >
          <template #default="{ row }">
            <el-tag
              size="small"
              :type="row.is_enabled ? 'success' : 'info'"
            >
              {{ row.is_enabled ? 'Enabled' : 'Disabled' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          prop="remark"
          label="Remark"
          min-width="180"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            {{ row.remark || '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Actions"
          width="240"
          fixed="right"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              @click="openEdit(row)"
            >
              Edit
            </el-button>
            <el-button
              link
              type="success"
              :loading="testingId === row.id"
              @click="handleTest(row)"
            >
              Check Reachability
            </el-button>
            <el-button
              link
              type="danger"
              @click="handleDelete(row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Create / edit dialog -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEditing ? 'Edit Provider' : 'Add Provider'"
      width="560px"
    >
      <el-form
        ref="formRef"
        :model="form"
        :rules="formRules"
        label-width="130px"
        label-position="right"
      >
        <el-form-item
          label="Name"
          prop="name"
        >
          <el-input
            v-model="form.name"
            placeholder="Display name, e.g. EasyPay Primary"
          />
        </el-form-item>
        <el-form-item label="Enabled">
          <el-switch v-model="form.is_enabled" />
        </el-form-item>
        <el-form-item
          label="API Base"
          prop="apiBase"
        >
          <el-input
            v-model="form.apiBase"
            autocomplete="url"
            placeholder="https://pay.example.com"
          />
          <div class="field-hint">
            Enter the gateway root URL; endpoint paths are normalized automatically.
          </div>
        </el-form-item>
        <el-form-item
          label="PID"
          prop="pid"
        >
          <el-input
            v-model="form.pid"
            placeholder="Merchant ID"
          />
        </el-form-item>
        <el-form-item
          label="Merchant Key"
          prop="pkey"
        >
          <el-input
            v-model="form.pkey"
            type="password"
            show-password
            :placeholder="isEditing ? 'Leave as shown (masked) to keep the current key' : 'Merchant secret key'"
          />
          <div
            v-if="isEditing"
            class="field-hint"
          >
            The masked value keeps the stored key; type a new value to replace it
          </div>
        </el-form-item>
        <el-form-item label="Notify URL">
          <el-input
            v-model="form.notifyUrl"
            placeholder="https://your-backend/api/v1/payment/webhook/easypay/{instance_id}"
          />
        </el-form-item>
        <el-form-item label="Return URL">
          <el-input
            v-model="form.returnUrl"
            placeholder="https://your-frontend/payment/result"
          />
        </el-form-item>
        <el-form-item
          label="Payment Mode"
          prop="paymentMode"
        >
          <el-select
            v-model="form.paymentMode"
            class="mode-select"
          >
            <el-option
              value="popup"
              label="Popup (redirect URL)"
            />
            <el-option
              value="qrcode"
              label="QR code"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="CID">
          <el-input
            v-model="form.cid"
            placeholder="Default channel ID"
          />
        </el-form-item>
        <el-form-item label="CID (Alipay)">
          <el-input
            v-model="form.cidAlipay"
            placeholder="Alipay channel ID"
          />
        </el-form-item>
        <el-form-item label="CID (WeChat)">
          <el-input
            v-model="form.cidWxpay"
            placeholder="WeChat Pay channel ID"
          />
        </el-form-item>
        <el-form-item label="Remark">
          <el-input
            v-model="form.remark"
            placeholder="Optional remark"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :loading="saving"
          @click="handleSave"
        >
          Save
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh } from '@element-plus/icons-vue'
import {
  apiAdminListProviders,
  apiAdminCreateProvider,
  apiAdminUpdateProvider,
  apiAdminDeleteProvider,
  apiAdminTestProvider,
} from '@/api/admin'

const loading = ref(false)
const saving = ref(false)
const testingId = ref(null)
const providers = ref([])
const dialogVisible = ref(false)
const editingId = ref(null)
const formRef = ref(null)

const isEditing = computed(() => editingId.value !== null && editingId.value !== undefined)

const form = reactive({
  name: '',
  is_enabled: true,
  apiBase: '',
  pid: '',
  pkey: '',
  notifyUrl: '',
  returnUrl: '',
  paymentMode: 'popup',
  cid: '',
  cidAlipay: '',
  cidWxpay: '',
  remark: '',
})

const formRules = {
  name: [{ required: true, whitespace: true, message: 'Provider name is required', trigger: 'blur' }],
  apiBase: [
    {
      validator: (_rule, value, callback) => {
        if (!form.is_enabled) {
          callback()
          return
        }
        try {
          const url = new globalThis.URL(String(value || '').trim())
          if (!['http:', 'https:'].includes(url.protocol) || !url.hostname || url.username || url.password || url.search || url.hash) {
            callback(new Error('Enter a valid HTTP(S) gateway root URL'))
            return
          }
          callback()
        } catch {
          callback(new Error('Enter a valid HTTP(S) gateway root URL'))
        }
      },
      trigger: 'blur',
    },
  ],
  pid: [{ validator: (_rule, value, callback) => {
    if (form.is_enabled && !String(value || '').trim()) {
      callback(new Error('Merchant ID is required'))
      return
    }
    callback()
  }, trigger: 'blur' }],
  pkey: [{ validator: (_rule, value, callback) => {
    if (form.is_enabled && !isEditing.value && !String(value || '').trim()) {
      callback(new Error('Merchant key is required'))
      return
    }
    callback()
  }, trigger: 'blur' }],
}

// Accept the common list response shapes (items / providers) from the admin API.
function extractRows(res) {
  if (Array.isArray(res)) return res
  if (Array.isArray(res?.items)) return res.items
  if (Array.isArray(res?.providers)) return res.providers
  return []
}

// Provider config may come back nested in `config` or flattened on the row.
function rowConfig(row) {
  const cfg = row?.config && typeof row.config === 'object' ? row.config : {}
  return { ...row, ...cfg }
}

function maskedPkey(cfg) {
  return cfg.pkey_masked ?? cfg.masked_pkey ?? cfg.pkey ?? ''
}

async function loadProviders() {
  loading.value = true
  try {
    const res = await apiAdminListProviders()
    providers.value = extractRows(res)
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load providers')
  } finally {
    loading.value = false
  }
}

function resetForm() {
  form.name = ''
  form.is_enabled = true
  form.apiBase = ''
  form.pid = ''
  form.pkey = ''
  form.notifyUrl = ''
  form.returnUrl = ''
  form.paymentMode = 'popup'
  form.cid = ''
  form.cidAlipay = ''
  form.cidWxpay = ''
  form.remark = ''
}

function openCreate() {
  editingId.value = null
  resetForm()
  dialogVisible.value = true
}

function openEdit(row) {
  const cfg = rowConfig(row)
  editingId.value = row.id
  form.name = row.name || ''
  form.is_enabled = row.is_enabled !== false
  form.apiBase = cfg.apiBase || ''
  form.pid = String(cfg.pid ?? '')
  // Show the masked key; submitting it unchanged tells the backend to keep it.
  form.pkey = maskedPkey(cfg)
  form.notifyUrl = cfg.notifyUrl || cfg.notify_url || ''
  form.returnUrl = cfg.returnUrl || cfg.return_url || ''
  form.paymentMode = cfg.paymentMode || cfg.payment_mode || 'popup'
  form.cid = String(cfg.cid ?? '')
  form.cidAlipay = cfg.cidAlipay ?? cfg.cid_alipay ?? ''
  form.cidWxpay = cfg.cidWxpay ?? cfg.cid_wxpay ?? ''
  form.remark = row.remark || ''
  dialogVisible.value = true
}

async function handleSave() {
  try {
    await formRef.value?.validate()
  } catch {
    return
  }
  saving.value = true
  try {
    const config = {
      apiBase: form.apiBase.trim(),
      pid: form.pid.trim(),
      pkey: form.pkey,
      notifyUrl: form.notifyUrl.trim(),
      returnUrl: form.returnUrl.trim(),
      paymentMode: form.paymentMode,
      cid: form.cid.trim(),
      cidAlipay: form.cidAlipay.trim(),
      cidWxpay: form.cidWxpay.trim(),
    }
    // Send the config both nested (mirrors the DB model) and flattened so the
    // admin schema can accept whichever shape it declares.
    const payload = {
      name: form.name.trim(),
      provider_key: 'easypay',
      is_enabled: form.is_enabled,
      remark: form.remark,
      config,
      ...config,
    }
    if (isEditing.value) {
      await apiAdminUpdateProvider(editingId.value, payload)
      ElMessage.success('Provider updated')
    } else {
      await apiAdminCreateProvider(payload)
      ElMessage.success('Provider created')
    }
    dialogVisible.value = false
    loadProviders()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to save the provider')
  } finally {
    saving.value = false
  }
}

async function handleTest(row) {
  testingId.value = row.id
  try {
    const res = await apiAdminTestProvider(row.id)
    const ok = res?.success ?? res?.ok ?? true
    const message = res?.message || res?.detail || 'Connection test completed'
    if (ok) {
      ElMessage.success({
        message: message.replace('merchant credentials were not verified', 'merchant credentials were not checked'),
        duration: 5000,
      })
    } else {
      ElMessage.error({ message, duration: 5000 })
    }
  } catch (error) {
    ElMessage.error(error?.message || 'Connection test failed')
  } finally {
    testingId.value = null
  }
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(
      `Delete provider "${row.name}"? Existing orders keep their snapshot.`,
      'Delete Provider',
      { type: 'warning', confirmButtonText: 'Delete', cancelButtonText: 'Cancel' }
    )
  } catch {
    return
  }
  try {
    await apiAdminDeleteProvider(row.id)
    ElMessage.success('Provider deleted')
    loadProviders()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to delete the provider')
  }
}

onMounted(loadProviders)
</script>

<style scoped>
.admin-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.page-header h2 {
  margin: 0 0 4px;
  font-size: 18px;
  color: #1f2937;
}

.page-header p {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
}

.toolbar-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 16px;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.btn-icon {
  margin-right: 4px;
}

.table-card {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.mode-select {
  width: 220px;
}

.field-hint {
  width: 100%;
  margin-top: 4px;
  font-size: 11px;
  color: #9ca3af;
}
</style>
