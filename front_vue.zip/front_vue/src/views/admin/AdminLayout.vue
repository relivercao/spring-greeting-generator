<template>
  <el-container class="admin-layout">
    <el-aside
      width="220px"
      class="admin-aside"
    >
      <div
        class="admin-brand"
        @click="router.push('/')"
      >
        <el-icon size="18">
          <Monitor />
        </el-icon>
        <span>Admin Console</span>
      </div>

      <el-menu
        :default-active="activeMenu"
        router
        class="admin-menu"
      >
        <el-menu-item index="/admin/models">
          <el-icon><Connection /></el-icon>
          <span>Models &amp; Pricing</span>
        </el-menu-item>
        <el-menu-item index="/admin/usage">
          <el-icon><List /></el-icon>
          <span>Usage &amp; Costs</span>
        </el-menu-item>
        <el-menu-item index="/admin/orders">
          <el-icon><List /></el-icon>
          <span>Orders</span>
        </el-menu-item>
        <el-menu-item index="/admin/plans">
          <el-icon><Goods /></el-icon>
          <span>Plans</span>
        </el-menu-item>
        <el-menu-item index="/admin/providers">
          <el-icon><Connection /></el-icon>
          <span>Providers</span>
        </el-menu-item>
        <el-menu-item index="/admin/users">
          <el-icon><User /></el-icon>
          <span>Users</span>
        </el-menu-item>
        <el-menu-item index="/admin/versions">
          <el-icon><Upload /></el-icon>
          <span>Versions</span>
        </el-menu-item>
      </el-menu>

      <div class="admin-aside-footer">
        <el-button
          text
          size="small"
          @click="router.push('/')"
        >
          <el-icon class="back-icon">
            <ArrowLeft />
          </el-icon>
          Back to App
        </el-button>
      </div>
    </el-aside>

    <el-main class="admin-main">
      <router-view />
    </el-main>
  </el-container>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  Monitor, List, Goods, Connection, User, Upload, ArrowLeft
} from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()

// Keep the sidebar highlight in sync with the current child route.
const activeMenu = computed(() => route.path)
</script>

<style scoped>
.admin-layout {
  height: 100vh;
  background: #f5f7fa;
}

.admin-aside {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border-right: 1px solid #e5e7eb;
}

.admin-brand {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 50px;
  padding: 0 16px;
  font-size: 14px;
  font-weight: 700;
  color: #1f2937;
  border-bottom: 1px solid #e5e7eb;
  cursor: pointer;
  flex-shrink: 0;
}

.admin-brand:hover {
  color: #2563eb;
}

.admin-menu {
  flex: 1;
  border-right: none;
  padding-top: 8px;
}

.admin-aside-footer {
  padding: 10px 12px;
  border-top: 1px solid #e5e7eb;
  flex-shrink: 0;
}

.back-icon {
  margin-right: 4px;
}

.admin-main {
  padding: 20px;
  overflow-y: auto;
}
@media (max-width: 800px) {
  .admin-aside { width: 180px !important; }
  .admin-brand { padding: 0 12px; font-size: 13px; }
  .admin-menu :deep(.el-menu-item) { padding-left: 14px !important; font-size: 13px; }
  .admin-main { padding: 12px; }
}
</style>
