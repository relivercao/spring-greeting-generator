<template>
  <div class="admin-page">
    <div class="page-header">
      <h2>Users</h2>
      <p>Manage user balances, roles, transactions, and redeem codes.</p>
    </div>

    <el-card
      shadow="never"
      class="table-card"
    >
      <div class="toolbar-row">
        <el-input
          v-model="userKeyword"
          clearable
          placeholder="Search by username or email"
          class="filter-keyword"
          @keyup.enter="handleUserSearch"
          @clear="handleUserSearch"
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
        <el-button
          type="primary"
          @click="handleUserSearch"
        >
          <el-icon class="btn-icon">
            <Search />
          </el-icon>Search
        </el-button>
        <el-button @click="loadUsers">
          <el-icon class="btn-icon">
            <Refresh />
          </el-icon>Refresh
        </el-button>
      </div>

      <!-- Status filter chips (server-side filter) -->
      <div class="filter-chips">
        <button
          v-for="option in STATUS_FILTERS"
          :key="option.value"
          type="button"
          class="filter-chip"
          :class="{ active: statusFilter === option.value }"
          @click="setStatusFilter(option.value)"
        >
          {{ option.label }}
        </button>
      </div>

      <el-table
        v-loading="usersLoading"
        :data="users"
        stripe
      >
        <el-table-column
          prop="username"
          label="Username"
          min-width="120"
        />
        <el-table-column
          prop="email"
          label="Email"
          min-width="180"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            {{ row.email || '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Balance"
          width="100"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.balance) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Total Recharged"
          width="130"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.total_recharged) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Level"
          width="130"
          align="center"
        >
          <template #default="{ row }">
            <div class="level-cell">
              <span
                class="level-pill"
                :class="`tier-${row.level || 'default'}`"
              >
                {{ levelName(row.level) }}
                <span
                  v-if="Number(levelDiscount(row.level)) > 0"
                  class="level-pill-off"
                >-{{ levelDiscount(row.level) }}%</span>
              </span>
              <span
                v-if="row.level_manual"
                class="level-pin"
                title="Manually pinned (auto-upgrade skipped)"
              >pinned</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          label="Active"
          width="80"
          align="center"
        >
          <template #default="{ row }">
            <el-switch
              :model-value="row.is_active !== false"
              @change="value => handleToggleStatus(row, value)"
            />
          </template>
        </el-table-column>
        <el-table-column
          label="Admin"
          width="80"
          align="center"
        >
          <template #default="{ row }">
            <el-switch
              :model-value="!!row.is_admin"
              @change="value => handleToggleAdmin(row, value)"
            />
          </template>
        </el-table-column>
        <el-table-column
          label="Created At"
          min-width="160"
        >
          <template #default="{ row }">
            {{ formatTime(row.created_at) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Actions"
          width="290"
          fixed="right"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              @click="openAdjust(row)"
            >
              Adjust Balance
            </el-button>
            <el-button
              link
              type="primary"
              @click="openSetLevel(row)"
            >
              Set Level
            </el-button>
            <el-button
              link
              type="primary"
              @click="openTransactions(row)"
            >
              Transactions
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-row">
        <el-pagination
          v-model:current-page="userPage"
          v-model:page-size="userPageSize"
          :total="userTotal"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @current-change="loadUsers"
          @size-change="handleUserSearch"
        />
      </div>
    </el-card>

    <!-- Redeem codes section -->
    <el-card
      shadow="never"
      class="table-card"
    >
      <div class="toolbar-row">
        <div class="section-title">
          <h3>Redeem Codes</h3>
          <p>Invitation and promo codes that credit a bonus on use.</p>
        </div>
        <div class="toolbar-actions">
          <el-button @click="loadRedeemCodes">
            <el-icon class="btn-icon">
              <Refresh />
            </el-icon>Refresh
          </el-button>
          <el-button
            type="primary"
            @click="openCreateCodes"
          >
            <el-icon class="btn-icon">
              <Plus />
            </el-icon>Create Codes
          </el-button>
        </div>
      </div>

      <el-table
        v-loading="codesLoading"
        :data="redeemCodes"
        stripe
        size="small"
      >
        <el-table-column
          label="Code"
          min-width="200"
        >
          <template #default="{ row }">
            <span class="code-text">{{ row.code }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="Type"
          width="110"
        >
          <template #default="{ row }">
            <el-tag
              size="small"
              :type="row.code_type === 'promo' ? 'warning' : 'primary'"
            >
              {{ row.code_type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          label="Bonus"
          width="100"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.bonus_amount) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Uses"
          width="90"
          align="center"
        >
          <template #default="{ row }">
            {{ row.used_count ?? 0 }} / {{ row.max_uses ?? '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Expires At"
          min-width="150"
        >
          <template #default="{ row }">
            {{ formatTime(row.expires_at) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Active"
          width="80"
          align="center"
        >
          <template #default="{ row }">
            <el-tag
              size="small"
              :type="row.is_active !== false ? 'success' : 'info'"
            >
              {{ row.is_active !== false ? 'Active' : 'Inactive' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          label="Created At"
          min-width="150"
        >
          <template #default="{ row }">
            {{ formatTime(row.created_at) }}
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-row">
        <el-pagination
          v-model:current-page="codePage"
          v-model:page-size="codePageSize"
          :total="codeTotal"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @current-change="loadRedeemCodes"
          @size-change="handleCodeSearch"
        />
      </div>
    </el-card>

    <!-- Balance adjust dialog -->
    <el-dialog
      v-model="adjustVisible"
      :title="`Adjust Balance - ${adjustTarget?.username || ''}`"
      width="440px"
    >
      <div class="adjust-hint">
        Current balance: <strong>¥{{ formatAmount(adjustTarget?.balance) }}</strong>.
        Use a signed amount, e.g. 10 to add or -5 to deduct.
      </div>
      <el-form label-width="100px">
        <el-form-item label="Amount">
          <el-input-number
            v-model="adjustAmount"
            :precision="2"
            :step="1"
            controls-position="right"
            class="adjust-input"
          />
        </el-form-item>
        <el-form-item label="Reason">
          <el-input
            v-model="adjustReason"
            placeholder="Reason recorded in the transaction log"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="adjustVisible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :loading="adjusting"
          @click="handleAdjust"
        >
          Apply
        </el-button>
      </template>
    </el-dialog>

    <!-- Set level dialog -->
    <el-dialog
      v-model="levelVisible"
      :title="`Set Level - ${levelTarget?.username || ''}`"
      width="440px"
    >
      <div class="adjust-hint">
        Cumulative recharge:
        <strong>¥{{ formatAmount(levelTarget?.total_recharged) }}</strong>.
        Pinning a level keeps it until changed; resetting returns the user
        to automatic tiering by cumulative recharge.
      </div>
      <el-form label-width="110px">
        <el-form-item label="Level">
          <el-select
            v-model="levelForm.level"
            class="level-select"
            placeholder="Choose a level"
          >
            <el-option
              v-for="level in levelOptions"
              :key="level.key"
              :value="level.key"
              :label="`${level.name}${levelDiscount(level.key) > 0 ? ` (-${levelDiscount(level.key)}% usage)` : ''}`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Mode">
          <el-switch
            v-model="levelForm.manual"
            active-text="Pinned"
            inactive-text="Auto"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button
          :loading="settingLevel"
          @click="handleResetLevel"
        >
          Reset to Auto
        </el-button>
        <el-button @click="levelVisible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :loading="settingLevel"
          :disabled="!levelForm.level"
          @click="handleSetLevel"
        >
          Apply
        </el-button>
      </template>
    </el-dialog>

    <!-- Transactions drawer -->
    <el-drawer
      v-model="transactionsVisible"
      :title="`Transactions - ${transactionsUser?.username || ''}`"
      size="min(720px, 100vw)"
    >
      <el-table
        v-loading="transactionsLoading"
        :data="transactions"
        stripe
        size="small"
      >
        <el-table-column
          label="Time"
          min-width="150"
        >
          <template #default="{ row }">
            {{ formatTime(row.created_at) }}
          </template>
        </el-table-column>
        <el-table-column
          prop="type"
          label="Type"
          width="120"
        />
        <el-table-column
          label="Amount"
          width="100"
          align="right"
        >
          <template #default="{ row }">
            <span :class="Number(row.amount) >= 0 ? 'amount-positive' : 'amount-negative'">
              {{ Number(row.amount) >= 0 ? '+' : '' }}{{ formatAmount(row.amount) }}
            </span>
          </template>
        </el-table-column>
        <el-table-column
          label="Balance After"
          width="110"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.balance_after) }}
          </template>
        </el-table-column>
        <el-table-column
          prop="description"
          label="Description"
          min-width="160"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            {{ row.description || '-' }}
          </template>
        </el-table-column>
        <el-table-column
          prop="model"
          label="Model"
          min-width="140"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            {{ row.model || '-' }}
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-row">
        <el-pagination
          v-model:current-page="txPage"
          v-model:page-size="txPageSize"
          :total="txTotal"
          :page-sizes="[10, 20, 50]"
          layout="total, prev, pager, next"
          @current-change="loadTransactions"
        />
      </div>
    </el-drawer>

    <!-- Batch create redeem codes dialog -->
    <el-dialog
      v-model="codesDialogVisible"
      title="Create Redeem Codes"
      width="480px"
    >
      <el-form label-width="120px">
        <el-form-item label="Type">
          <el-select
            v-model="codesForm.code_type"
            class="codes-type-select"
          >
            <el-option
              value="invitation"
              label="Invitation"
            />
            <el-option
              value="promo"
              label="Promo"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="Bonus Amount">
          <el-input-number
            v-model="codesForm.bonus_amount"
            :min="0"
            :precision="2"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
        <el-form-item label="Max Uses">
          <el-input-number
            v-model="codesForm.max_uses"
            :min="1"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
        <el-form-item label="Count">
          <el-input-number
            v-model="codesForm.count"
            :min="1"
            :max="100"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
        <el-form-item label="Expires In">
          <el-input-number
            v-model="codesForm.expires_days"
            :min="0"
            :step="1"
            controls-position="right"
          />
          <div class="field-hint">
            Validity in days from now; 0 means no expiry
          </div>
        </el-form-item>
      </el-form>

      <!-- Copyable list of the codes created in this dialog -->
      <div
        v-if="createdCodes.length"
        class="created-codes"
      >
        <div class="created-codes-header">
          <span>Created codes</span>
          <el-button
            size="small"
            type="primary"
            @click="copyCreatedCodes"
          >
            <el-icon class="btn-icon">
              <CopyDocument />
            </el-icon>Copy All
          </el-button>
        </div>
        <el-input
          :model-value="createdCodesText"
          type="textarea"
          :rows="6"
          readonly
          class="codes-textarea"
        />
      </div>

      <template #footer>
        <el-button @click="codesDialogVisible = false">
          Close
        </el-button>
        <el-button
          type="primary"
          :loading="creatingCodes"
          @click="handleCreateCodes"
        >
          Create
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Refresh, Plus, CopyDocument } from '@element-plus/icons-vue'
import {
  apiAdminUsers,
  apiAdminAdjustBalance,
  apiAdminSetUserStatus,
  apiAdminSetAdmin,
  apiAdminSetUserLevel,
  apiAdminUserTransactions,
  apiAdminListRedeemCodes,
  apiAdminCreateRedeemCodes,
  apiAdminGetConfig,
} from '@/api/admin'

function formatAmount(value) {
  return Number(value ?? 0).toFixed(2)
}

function formatTime(value) {
  return value ? new Date(value).toLocaleString() : '-'
}

// Accept the common list response shapes from the admin API.
function extractRows(res, ...keys) {
  if (Array.isArray(res)) return res
  for (const key of ['items', ...keys]) {
    if (Array.isArray(res?.[key])) return res[key]
  }
  return []
}

// ── Users table ──
const usersLoading = ref(false)
const users = ref([])
const userTotal = ref(0)
const userPage = ref(1)
const userPageSize = ref(20)
const userKeyword = ref('')
const statusFilter = ref('')

const STATUS_FILTERS = [
  { value: '', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'disabled', label: 'Disabled' },
  { value: 'admin', label: 'Admins' },
]

function setStatusFilter(value) {
  if (statusFilter.value === value) return
  statusFilter.value = value
  handleUserSearch()
}

async function loadUsers() {
  usersLoading.value = true
  try {
    const res = await apiAdminUsers({
      page: userPage.value,
      page_size: userPageSize.value,
      keyword: userKeyword.value.trim() || undefined,
      status: statusFilter.value || undefined,
    })
    users.value = extractRows(res, 'users')
    userTotal.value = Number(res?.total ?? users.value.length)
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load users')
  } finally {
    usersLoading.value = false
  }
}

function handleUserSearch() {
  userPage.value = 1
  loadUsers()
}

async function handleToggleStatus(row, value) {
  try {
    await apiAdminSetUserStatus(row.id, { is_active: !!value })
    row.is_active = !!value
    ElMessage.success(value ? 'User enabled' : 'User disabled')
  } catch (error) {
    // el-switch uses :model-value, so the row keeps the old value on failure.
    ElMessage.error(error?.message || 'Failed to update the user status')
  }
}

async function handleToggleAdmin(row, value) {
  const action = value ? 'grant admin rights to' : 'revoke admin rights from'
  try {
    await ElMessageBox.confirm(
      `Do you want to ${action} "${row.username}"?`,
      'Change Admin Role',
      { type: 'warning', confirmButtonText: 'Confirm', cancelButtonText: 'Cancel' }
    )
  } catch {
    return
  }
  try {
    await apiAdminSetAdmin(row.id, { is_admin: !!value })
    row.is_admin = !!value
    ElMessage.success('Admin role updated')
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to update the admin role')
  }
}

// ── Balance adjust dialog ──
const adjustVisible = ref(false)
const adjusting = ref(false)
const adjustTarget = ref(null)
const adjustAmount = ref(0)
const adjustReason = ref('')

function openAdjust(row) {
  adjustTarget.value = row
  adjustAmount.value = 0
  adjustReason.value = ''
  adjustVisible.value = true
}

async function handleAdjust() {
  if (!adjustTarget.value) return
  if (!adjustAmount.value) {
    ElMessage.warning('Enter a non-zero amount')
    return
  }
  adjusting.value = true
  try {
    await apiAdminAdjustBalance(adjustTarget.value.id, {
      amount: Number(adjustAmount.value),
      reason: adjustReason.value.trim(),
    })
    ElMessage.success('Balance adjusted')
    adjustVisible.value = false
    loadUsers()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to adjust the balance')
  } finally {
    adjusting.value = false
  }
}

// ── Membership levels ──
const levelsConfig = ref([])

const levelOptions = computed(() => levelsConfig.value)

async function loadLevels() {
  try {
    const config = await apiAdminGetConfig()
    levelsConfig.value = Array.isArray(config?.levels?.levels)
      ? config.levels.levels
      : []
  } catch {
    // The level dialog falls back to raw keys when config is unavailable
    levelsConfig.value = []
  }
}

function levelName(key) {
  const match = levelsConfig.value.find((level) => level.key === key)
  return match?.name || key || 'Standard'
}

function levelDiscount(key) {
  const match = levelsConfig.value.find((level) => level.key === key)
  return Math.round(Number(match?.discount_percent) || 0)
}

// ── Set level dialog ──
const levelVisible = ref(false)
const settingLevel = ref(false)
const levelTarget = ref(null)
const levelForm = reactive({ level: '', manual: true })

function openSetLevel(row) {
  levelTarget.value = row
  levelForm.level = row.level || 'default'
  levelForm.manual = row.level_manual !== false
  levelVisible.value = true
}

async function handleSetLevel() {
  if (!levelTarget.value || !levelForm.level) return
  settingLevel.value = true
  try {
    const updated = await apiAdminSetUserLevel(levelTarget.value.id, {
      level: levelForm.level,
      manual: levelForm.manual,
    })
    Object.assign(levelTarget.value, {
      level: updated?.level ?? levelForm.level,
      level_manual: updated?.level_manual ?? levelForm.manual,
    })
    ElMessage.success('Level updated')
    levelVisible.value = false
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to update the level')
  } finally {
    settingLevel.value = false
  }
}

async function handleResetLevel() {
  if (!levelTarget.value) return
  settingLevel.value = true
  try {
    const updated = await apiAdminSetUserLevel(levelTarget.value.id, {
      level: '',
      manual: false,
    })
    Object.assign(levelTarget.value, {
      level: updated?.level ?? 'default',
      level_manual: updated?.level_manual ?? false,
    })
    ElMessage.success('Level reset to automatic tiering')
    levelVisible.value = false
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to reset the level')
  } finally {
    settingLevel.value = false
  }
}

// ── Transactions drawer ──
const transactionsVisible = ref(false)
const transactionsLoading = ref(false)
const transactionsUser = ref(null)
const transactions = ref([])
const txTotal = ref(0)
const txPage = ref(1)
const txPageSize = ref(20)

function openTransactions(row) {
  transactionsUser.value = row
  transactions.value = []
  txTotal.value = 0
  txPage.value = 1
  transactionsVisible.value = true
  loadTransactions()
}

async function loadTransactions() {
  if (!transactionsUser.value) return
  transactionsLoading.value = true
  try {
    const res = await apiAdminUserTransactions(transactionsUser.value.id, {
      page: txPage.value,
      page_size: txPageSize.value,
    })
    transactions.value = extractRows(res, 'transactions')
    txTotal.value = Number(res?.total ?? transactions.value.length)
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load transactions')
  } finally {
    transactionsLoading.value = false
  }
}

// ── Redeem codes ──
const codesLoading = ref(false)
const redeemCodes = ref([])
const codeTotal = ref(0)
const codePage = ref(1)
const codePageSize = ref(20)

const codesDialogVisible = ref(false)
const creatingCodes = ref(false)
const createdCodes = ref([])

const codesForm = reactive({
  code_type: 'invitation',
  bonus_amount: 5,
  max_uses: 1,
  count: 1,
  expires_days: 0,
})

const createdCodesText = computed(() => createdCodes.value.join('\n'))

async function loadRedeemCodes() {
  codesLoading.value = true
  try {
    const res = await apiAdminListRedeemCodes({
      page: codePage.value,
      page_size: codePageSize.value,
    })
    redeemCodes.value = extractRows(res, 'codes', 'redeem_codes')
    codeTotal.value = Number(res?.total ?? redeemCodes.value.length)
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load redeem codes')
  } finally {
    codesLoading.value = false
  }
}

function handleCodeSearch() {
  codePage.value = 1
  loadRedeemCodes()
}

function openCreateCodes() {
  createdCodes.value = []
  codesDialogVisible.value = true
}

async function handleCreateCodes() {
  creatingCodes.value = true
  try {
    const res = await apiAdminCreateRedeemCodes({ ...codesForm })
    // The response carries the generated codes; accept strings or objects.
    const raw = extractRows(res, 'codes', 'redeem_codes')
    createdCodes.value = raw
      .map(item => (typeof item === 'string' ? item : item?.code))
      .filter(Boolean)
    if (!createdCodes.value.length) {
      ElMessage.success('Redeem codes created')
      codesDialogVisible.value = false
    }
    loadRedeemCodes()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to create redeem codes')
  } finally {
    creatingCodes.value = false
  }
}

async function copyCreatedCodes() {
  try {
    await navigator.clipboard.writeText(createdCodesText.value)
    ElMessage.success('Codes copied to clipboard')
  } catch {
    ElMessage.error('Copy failed - select the text manually')
  }
}

onMounted(() => {
  loadUsers()
  loadRedeemCodes()
  loadLevels()
})
</script>

<style scoped>
.admin-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.page-header h2 {
  margin: 0 0 4px;
  font-size: 18px;
  color: #1f2937;
}

.page-header p {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
}

.table-card {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.toolbar-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 14px;
  flex-wrap: wrap;
}

.toolbar-actions {
  display: flex;
  gap: 10px;
}

.section-title h3 {
  margin: 0;
  font-size: 15px;
  color: #1f2937;
}

.section-title p {
  margin: 2px 0 0;
  font-size: 12px;
  color: #6b7280;
}

.filter-keyword {
  width: 280px;
}

.btn-icon {
  margin-right: 4px;
}

.pagination-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}

.code-text {
  font-family: 'SF Mono', Monaco, Menlo, monospace;
  font-size: 12px;
}

.amount-positive {
  color: #059669;
  font-weight: 600;
}

.amount-negative {
  color: #dc2626;
  font-weight: 600;
}

/* ── Status filter chips ── */
.filter-chips {
  display: flex;
  gap: 8px;
  margin: 12px 0 4px;
  flex-wrap: wrap;
}

.filter-chip {
  border: 1px solid #e5e7eb;
  background: #ffffff;
  color: #6b7280;
  font-size: 12px;
  font-weight: 600;
  border-radius: 999px;
  padding: 6px 16px;
  cursor: pointer;
  transition: all 0.15s;
}

.filter-chip:hover { color: #2563eb; border-color: #93c5fd; }

.filter-chip.active {
  background: #2563eb;
  border-color: #2563eb;
  color: #ffffff;
  box-shadow: 0 2px 8px rgba(37, 99, 235, 0.25);
}

/* ── Level cell ── */
.level-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
}

.level-pill {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  border-radius: 999px;
  padding: 3px 10px;
  font-size: 11px;
  font-weight: 700;
  background: #eff6ff;
  color: #1d4ed8;
  border: 1px solid #bfdbfe;
}

.level-pill.tier-silver { background: #f1f5f9; color: #475569; border-color: #cbd5e1; }
.level-pill.tier-gold { background: #fef3c7; color: #b45309; border-color: #fde68a; }
.level-pill.tier-platinum {
  background: linear-gradient(135deg, #eff6ff, #f5f3ff);
  color: #6d28d9;
  border-color: #c7d2fe;
}

.level-pill-off { font-size: 10px; font-weight: 600; opacity: 0.85; }

.level-pin {
  font-size: 10px;
  color: #9ca3af;
  font-weight: 600;
  letter-spacing: 0.02em;
}

.level-select { width: 100%; }

.adjust-hint {  margin-bottom: 12px;
  padding: 10px 12px;
  background: #eff6ff;
  border: 1px solid #dbeafe;
  border-radius: 8px;
  font-size: 13px;
  color: #1e40af;
}

.adjust-input {
  width: 200px;
}

.codes-type-select {
  width: 200px;
}

.field-hint {
  width: 100%;
  margin-top: 4px;
  font-size: 11px;
  color: #9ca3af;
}

.created-codes {
  margin-top: 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.created-codes-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  font-weight: 600;
  color: #374151;
}

.codes-textarea :deep(textarea) {
  font-family: 'SF Mono', Monaco, Menlo, monospace;
  font-size: 12px;
}
</style>
