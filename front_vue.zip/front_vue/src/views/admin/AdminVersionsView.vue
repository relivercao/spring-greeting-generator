<template>
  <div class="admin-page">
    <div class="page-header">
      <div>
        <h2>Version Releases</h2>
        <p>Manage published installers and release notes for users.</p>
      </div>
      <el-button type="primary" @click="openCreate">
        <el-icon><Plus /></el-icon>
        New release
      </el-button>
    </div>

    <div class="current-version-row">
      <span>Running version</span>
      <strong>v{{ currentVersion || '...' }}</strong>
      <el-button
        text
        :loading="loading"
        aria-label="Refresh version releases"
        title="Refresh version releases"
        @click="loadReleases"
      >
        <el-icon><Refresh /></el-icon>
      </el-button>
    </div>

    <el-table v-loading="loading" :data="releases" stripe>
      <el-table-column label="Version" width="130">
        <template #default="{ row }">
          <strong>v{{ row.version }}</strong>
          <el-tag v-if="row.mandatory" type="danger" size="small" class="persistent-tag">
            Persistent
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="title" label="Release" min-width="160" show-overflow-tooltip />
      <el-table-column label="Published" width="180">
        <template #default="{ row }">{{ formatDate(row.published_at) }}</template>
      </el-table-column>
      <el-table-column label="Installer" min-width="220" show-overflow-tooltip>
        <template #default="{ row }">
          <a :href="row.download_url" target="_blank" rel="noopener noreferrer">{{ row.download_url }}</a>
        </template>
      </el-table-column>
      <el-table-column label="SHA-256" min-width="220" show-overflow-tooltip>
        <template #default="{ row }"><code>{{ row.sha256 }}</code></template>
      </el-table-column>
      <el-table-column label="Actions" width="145" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row)">Edit</el-button>
          <el-button link type="danger" @click="removeRelease(row)">Delete</el-button>
        </template>
      </el-table-column>
      <template #empty>
        <el-empty description="No version releases have been published." />
      </template>
    </el-table>

    <el-dialog
      v-model="dialogVisible"
      :title="editingVersion ? `Edit version ${editingVersion}` : 'Publish a version'"
      width="min(620px, calc(100vw - 24px))"
      destroy-on-close
    >
      <el-form ref="formRef" :model="form" :rules="rules" label-position="top">
        <div class="form-grid">
          <el-form-item label="Version" prop="version">
            <el-input v-model="form.version" :disabled="Boolean(editingVersion)" placeholder="3.2.1" />
          </el-form-item>
          <el-form-item label="Release title" prop="title">
            <el-input v-model="form.title" maxlength="200" placeholder="Improved firmware workflow" />
          </el-form-item>
        </div>
        <el-form-item label="Release notes" prop="release_notes">
          <el-input
            v-model="form.release_notes"
            type="textarea"
            :rows="5"
            maxlength="20000"
            show-word-limit
            placeholder="Describe the changes in this release."
          />
        </el-form-item>
        <el-form-item label="Installer URL" prop="download_url">
          <el-input v-model="form.download_url" placeholder="https://downloads.example.com/Macode-Setup-3.2.1.exe" />
        </el-form-item>
        <el-form-item label="Installer SHA-256" prop="sha256">
          <el-input v-model="form.sha256" maxlength="64" placeholder="64 hexadecimal characters" />
        </el-form-item>
        <el-form-item label="Update policy">
          <div class="mandatory-setting">
            <el-switch v-model="form.mandatory" />
            <span>Keep the reminder visible and prevent dismissal.</span>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" :loading="saving" @click="saveRelease">
          {{ editingVersion ? 'Save changes' : 'Publish release' }}
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh } from '@element-plus/icons-vue'
import {
  adminDeleteVersionRelease,
  adminListVersionReleases,
  adminPublishVersionRelease,
} from '../../api/version.js'

const releases = ref([])
const currentVersion = ref('')
const loading = ref(false)
const saving = ref(false)
const dialogVisible = ref(false)
const editingVersion = ref('')
const formRef = ref(null)
const form = reactive({
  version: '',
  title: '',
  release_notes: '',
  download_url: '',
  sha256: '',
  mandatory: false,
})

const rules = {
  version: [
    { required: true, message: 'Enter a semantic version such as 3.2.1', trigger: 'blur' },
    { pattern: /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/, message: 'Use semantic version format X.Y.Z', trigger: 'blur' },
  ],
  title: [{ required: true, message: 'Enter a release title', trigger: 'blur' }],
  download_url: [
    { required: true, message: 'Enter an installer URL', trigger: 'blur' },
    { type: 'url', message: 'Enter a valid HTTPS URL', trigger: 'blur' },
    {
      validator: (_rule, value, callback) => {
        if (String(value || '').startsWith('https://')) callback()
        else callback(new Error('Installer URL must use HTTPS'))
      },
      trigger: 'blur',
    },
  ],
  sha256: [
    { required: true, message: 'Enter the installer SHA-256 checksum', trigger: 'blur' },
    { pattern: /^[0-9a-fA-F]{64}$/, message: 'SHA-256 must contain 64 hexadecimal characters', trigger: 'blur' },
  ],
}

async function loadReleases() {
  loading.value = true
  try {
    const response = await adminListVersionReleases()
    releases.value = Array.isArray(response?.releases) ? response.releases : []
    currentVersion.value = response?.current_version || ''
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load version releases')
  } finally {
    loading.value = false
  }
}

function resetForm() {
  Object.assign(form, {
    version: '', title: '', release_notes: '', download_url: '', sha256: '', mandatory: false,
  })
  editingVersion.value = ''
}

function openCreate() {
  resetForm()
  dialogVisible.value = true
}

function openEdit(release) {
  resetForm()
  editingVersion.value = release.version
  Object.assign(form, {
    version: release.version,
    title: release.title || '',
    release_notes: release.release_notes || '',
    download_url: release.download_url || '',
    sha256: release.sha256 || '',
    mandatory: Boolean(release.mandatory),
  })
  dialogVisible.value = true
}

async function saveRelease() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    await adminPublishVersionRelease({ ...form })
    ElMessage.success(editingVersion.value ? 'Version release updated' : 'Version release published')
    dialogVisible.value = false
    await loadReleases()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to save version release')
  } finally {
    saving.value = false
  }
}

async function removeRelease(release) {
  try {
    await ElMessageBox.confirm(
      `Delete version ${release.version}? Users will no longer see this release as an available update.`,
      'Delete version release',
      { confirmButtonText: 'Delete', cancelButtonText: 'Cancel', type: 'warning' },
    )
    await adminDeleteVersionRelease(release.version)
    ElMessage.success('Version release deleted')
    await loadReleases()
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') {
      ElMessage.error(error?.message || 'Failed to delete version release')
    }
  }
}

function formatDate(value) {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '-'
  return new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(date)
}

onMounted(loadReleases)
</script>

<style scoped>
.admin-page { display: flex; flex-direction: column; gap: 16px; }
.page-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; }
.page-header h2 { margin: 0; color: #172b4d; font-size: 20px; }
.page-header p { margin: 5px 0 0; color: #6b778c; font-size: 12px; }
.current-version-row { display: flex; align-items: center; gap: 8px; min-height: 40px; padding: 0 12px; border-top: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; color: #526174; font-size: 12px; }
.current-version-row strong { color: #172b4d; font-size: 13px; }
.required-tag { margin-left: 5px; vertical-align: 1px; }
.form-grid { display: grid; grid-template-columns: minmax(120px, 0.7fr) minmax(0, 1.3fr); gap: 14px; }
.mandatory-setting { display: flex; align-items: center; gap: 10px; color: #526174; font-size: 12px; }
a { display: inline-block; max-width: 100%; overflow: hidden; color: #175cd3; text-overflow: ellipsis; vertical-align: bottom; }
code { color: #526174; font-size: 11px; }
@media (max-width: 620px) {
  .page-header { align-items: stretch; flex-direction: column; }
  .page-header > .el-button { align-self: flex-start; }
  .form-grid { grid-template-columns: 1fr; gap: 0; }
}
</style>
