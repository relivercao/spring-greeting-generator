<template>
  <div class="admin-page">
    <div class="page-header">
      <h2>Orders</h2>
      <p>Monitor payment orders, cancel pending ones, refund completed ones.</p>
    </div>

    <div class="toolbar-card">
      <el-select
        v-model="filters.status"
        clearable
        placeholder="Status"
        class="filter-status"
        @change="handleSearch"
      >
        <el-option
          v-for="item in statusOptions"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>
      <el-input
        v-model="filters.keyword"
        clearable
        placeholder="Search by trade no or username"
        class="filter-keyword"
        @keyup.enter="handleSearch"
        @clear="handleSearch"
      >
        <template #prefix>
          <el-icon><Search /></el-icon>
        </template>
      </el-input>
      <el-button
        type="primary"
        @click="handleSearch"
      >
        <el-icon class="btn-icon">
          <Search />
        </el-icon>Search
      </el-button>
      <el-button @click="loadOrders">
        <el-icon class="btn-icon">
          <Refresh />
        </el-icon>Refresh
      </el-button>
    </div>

    <el-card
      shadow="never"
      class="table-card"
    >
      <el-table
        v-loading="loading"
        :data="orders"
        stripe
      >
        <el-table-column
          prop="out_trade_no"
          label="Trade No"
          min-width="200"
          show-overflow-tooltip
        />
        <el-table-column
          label="User"
          min-width="110"
        >
          <template #default="{ row }">
            {{ row.username || row.user_id || '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Amount"
          width="100"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.amount) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Pay Amount"
          width="110"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.pay_amount) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Status"
          width="110"
        >
          <template #default="{ row }">
            <el-tag
              size="small"
              :type="statusTagType(row.status)"
            >
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          prop="payment_type"
          label="Payment"
          width="100"
        />
        <el-table-column
          label="Created At"
          min-width="160"
        >
          <template #default="{ row }">
            {{ formatTime(row.created_at) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Actions"
          width="250"
          fixed="right"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              @click="openDetail(row)"
            >
              Detail
            </el-button>
            <el-button
              v-if="row.status === 'pending'"
              link
              type="warning"
              @click="handleCancel(row)"
            >
              Cancel
            </el-button>
            <el-button
              v-if="row.status === 'completed'"
              link
              type="danger"
              @click="openRefund(row)"
            >
              Refund
            </el-button>
            <el-button
              v-if="row.status === 'failed'"
              link
              type="success"
              @click="handleRetry(row)"
            >
              Retry
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-row">
        <el-pagination
          v-model:current-page="page"
          v-model:page-size="pageSize"
          :total="total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          @current-change="loadOrders"
          @size-change="handleSearch"
        />
      </div>
    </el-card>

    <!-- Order detail drawer -->
    <el-drawer
      v-model="detailVisible"
      title="Order Detail"
      size="min(560px, 100vw)"
    >
      <el-descriptions
        v-if="detail"
        :column="1"
        border
        size="small"
      >
        <el-descriptions-item label="Trade No">
          {{ detail.out_trade_no || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Provider Trade No">
          {{ detail.payment_trade_no || detail.trade_no || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Status">
          <el-tag
            size="small"
            :type="statusTagType(detail.status)"
          >
            {{ detail.status }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="Order Type">
          {{ detail.order_type || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Plan">
          {{ detail.plan_name || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="User">
          {{ detail.username || detail.user_id || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Payment Type">
          {{ detail.payment_type || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Provider">
          {{ detail.provider_key || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Amount">
          ¥{{ formatAmount(detail.amount) }}
        </el-descriptions-item>
        <el-descriptions-item label="Pay Amount">
          ¥{{ formatAmount(detail.pay_amount) }}
        </el-descriptions-item>
        <el-descriptions-item label="Credited Amount">
          ¥{{ formatAmount(detail.credited_amount) }}
        </el-descriptions-item>
        <el-descriptions-item label="Client IP">
          {{ detail.client_ip || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Pay URL">
          <el-link
            v-if="detail.pay_url"
            type="primary"
            :href="detail.pay_url"
            target="_blank"
            class="pay-url-link"
          >
            {{ detail.pay_url }}
          </el-link>
          <span v-else>-</span>
        </el-descriptions-item>
        <el-descriptions-item label="Expires At">
          {{ formatTime(detail.expires_at) }}
        </el-descriptions-item>
        <el-descriptions-item label="Paid At">
          {{ formatTime(detail.paid_at) }}
        </el-descriptions-item>
        <el-descriptions-item label="Completed At">
          {{ formatTime(detail.completed_at) }}
        </el-descriptions-item>
        <el-descriptions-item label="Failed At">
          {{ formatTime(detail.failed_at) }}
        </el-descriptions-item>
        <el-descriptions-item label="Failed Reason">
          {{ detail.failed_reason || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Refund Amount">
          ¥{{ formatAmount(detail.refund_amount) }}
        </el-descriptions-item>
        <el-descriptions-item label="Refund Reason">
          {{ detail.refund_reason || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Refunded At">
          {{ formatTime(detail.refunded_at) }}
        </el-descriptions-item>
        <el-descriptions-item label="Refund Status">
          {{ detail.refund_status || '-' }}
        </el-descriptions-item>
        <el-descriptions-item label="Created At">
          {{ formatTime(detail.created_at) }}
        </el-descriptions-item>
      </el-descriptions>
    </el-drawer>

    <!-- Refund dialog -->
    <el-dialog
      v-model="refundVisible"
      title="Refund Order"
      width="420px"
    >
      <div class="refund-hint">
        Refunding order <strong>{{ refundTarget?.out_trade_no }}</strong>
        (¥{{ formatAmount(refundTarget?.pay_amount) }}).
        The credited balance will be deducted from the user.
      </div>
      <el-input
        v-model="refundReason"
        type="textarea"
        :rows="3"
        placeholder="Reason for the refund"
      />
      <template #footer>
        <el-button @click="refundVisible = false">
          Cancel
        </el-button>
        <el-button
          type="danger"
          :loading="actionLoading"
          @click="handleRefund"
        >
          Confirm Refund
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search, Refresh } from '@element-plus/icons-vue'
import {
  apiAdminOrders,
  apiAdminOrderDetail,
  apiAdminCancelOrder,
  apiAdminRefundOrder,
  apiAdminRetryOrder,
} from '@/api/admin'

const statusOptions = [
  { value: 'pending', label: 'Pending' },
  { value: 'paid', label: 'Paid' },
  { value: 'recharging', label: 'Recharging' },
  { value: 'completed', label: 'Completed' },
  { value: 'expired', label: 'Expired' },
  { value: 'cancelled', label: 'Cancelled' },
  { value: 'failed', label: 'Failed' },
  { value: 'refunded', label: 'Refunded' },
]

const STATUS_TAG_TYPES = {
  pending: 'warning',
  paid: 'primary',
  recharging: 'primary',
  completed: 'success',
  expired: 'info',
  cancelled: 'info',
  failed: 'danger',
  refunded: 'warning',
}

const loading = ref(false)
const actionLoading = ref(false)
const orders = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = reactive({ status: '', keyword: '' })

const detailVisible = ref(false)
const detail = ref(null)

const refundVisible = ref(false)
const refundTarget = ref(null)
const refundReason = ref('')

function formatAmount(value) {
  return Number(value ?? 0).toFixed(2)
}

function formatTime(value) {
  return value ? new Date(value).toLocaleString() : '-'
}

function statusTagType(status) {
  return STATUS_TAG_TYPES[status] || 'info'
}

// Accept the common list response shapes (items / orders) from the admin API.
function extractRows(res, ...keys) {
  if (Array.isArray(res)) return res
  for (const key of ['items', ...keys]) {
    if (Array.isArray(res?.[key])) return res[key]
  }
  return []
}

async function loadOrders() {
  loading.value = true
  try {
    const res = await apiAdminOrders({
      page: page.value,
      page_size: pageSize.value,
      status: filters.status || undefined,
      keyword: filters.keyword?.trim() || undefined,
    })
    orders.value = extractRows(res, 'orders')
    total.value = Number(res?.total ?? orders.value.length)
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load orders')
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  page.value = 1
  loadOrders()
}

async function openDetail(row) {
  detailVisible.value = true
  detail.value = { ...row }
  try {
    const res = await apiAdminOrderDetail(row.id)
    // Response may wrap the order or return it flat; keep the richer version.
    detail.value = res?.order || res || { ...row }
  } catch (error) {
    // Keep the row snapshot already loaded from the list.
    ElMessage.warning(error?.message || 'Failed to load the latest order detail')
  }
}

async function handleCancel(row) {
  try {
    await ElMessageBox.confirm(
      `Cancel order ${row.out_trade_no}? This cannot be undone.`,
      'Cancel Order',
      { type: 'warning', confirmButtonText: 'Cancel Order', cancelButtonText: 'Keep Order' }
    )
  } catch {
    return
  }
  try {
    await apiAdminCancelOrder(row.id)
    ElMessage.success('Order cancelled')
    loadOrders()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to cancel the order')
  }
}

function openRefund(row) {
  refundTarget.value = row
  refundReason.value = ''
  refundVisible.value = true
}

async function handleRefund() {
  if (!refundTarget.value) return
  if (!refundReason.value.trim()) {
    ElMessage.warning('Please enter a refund reason')
    return
  }
  actionLoading.value = true
  try {
    await apiAdminRefundOrder(refundTarget.value.id, { reason: refundReason.value.trim() })
    ElMessage.success('Refund submitted')
    refundVisible.value = false
    loadOrders()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to refund the order')
  } finally {
    actionLoading.value = false
  }
}

async function handleRetry(row) {
  try {
    await apiAdminRetryOrder(row.id)
    ElMessage.success('Retry triggered for the failed order')
    loadOrders()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to retry the order')
  }
}

onMounted(loadOrders)
</script>

<style scoped>
.admin-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.page-header h2 {
  margin: 0 0 4px;
  font-size: 18px;
  color: #1f2937;
}

.page-header p {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
}

.toolbar-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 16px;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.filter-status {
  width: 150px;
}

.filter-keyword {
  width: 280px;
}

.btn-icon {
  margin-right: 4px;
}

.table-card {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.pagination-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}

.pay-url-link {
  word-break: break-all;
}

.refund-hint {
  margin-bottom: 12px;
  padding: 10px 12px;
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: 8px;
  font-size: 13px;
  color: #991b1b;
}
</style>
