<template>
  <div class="admin-page">
    <div class="page-header">
      <h2>Recharge Plans</h2>
      <p>Manage the preset recharge plans shown to users.</p>
    </div>

    <div class="toolbar-card">
      <el-button
        type="primary"
        @click="openCreate"
      >
        <el-icon class="btn-icon">
          <Plus />
        </el-icon>Create Plan
      </el-button>
      <el-button @click="loadPlans">
        <el-icon class="btn-icon">
          <Refresh />
        </el-icon>Refresh
      </el-button>
    </div>

    <!-- Recharge settings: general limits + membership level ladder -->
    <el-card
      shadow="never"
      class="table-card"
    >
      <div class="toolbar-row">
        <div class="section-title">
          <h3>Recharge Settings</h3>
          <p>Recharge limits, bonuses, and the membership level ladder.</p>
        </div>
        <div class="toolbar-actions">
          <el-button
            type="primary"
            :loading="savingConfig"
            @click="saveConfig"
          >
            <el-icon class="btn-icon">
              <Check />
            </el-icon>Save Settings
          </el-button>
        </div>
      </div>

      <el-form
        v-loading="configLoading"
        label-width="190px"
        class="settings-form"
      >
        <div class="settings-grid">
          <el-form-item label="Min recharge (CNY)">
            <el-input-number
              v-model="configForm.general.min_recharge_amount"
              :min="0.01"
              :precision="2"
              :step="1"
              controls-position="right"
            />
          </el-form-item>
          <el-form-item label="Max recharge (CNY)">
            <el-input-number
              v-model="configForm.general.max_recharge_amount"
              :min="1"
              :precision="2"
              :step="50"
              controls-position="right"
            />
          </el-form-item>
          <el-form-item label="Daily limit (CNY)">
            <el-input-number
              v-model="configForm.general.daily_recharge_limit"
              :min="0"
              :precision="2"
              :step="100"
              controls-position="right"
            />
          </el-form-item>
          <el-form-item label="Recharge bonus multiplier">
            <el-input-number
              v-model="configForm.general.recharge_multiplier"
              :min="1"
              :max="10"
              :precision="2"
              :step="0.1"
              controls-position="right"
            />
            <div class="field-hint">
              1.1 credits ¥110 for a ¥100 recharge
            </div>
          </el-form-item>
          <el-form-item label="Channel fee rate (%)">
            <el-input-number
              v-model="configForm.general.fee_rate"
              :min="0"
              :max="100"
              :precision="2"
              :step="0.5"
              controls-position="right"
            />
            <div class="field-hint">
              Shown on the payment method buttons
            </div>
          </el-form-item>
          <el-form-item label="Order expiry (minutes)">
            <el-input-number
              v-model="configForm.general.order_expire_minutes"
              :min="5"
              :max="240"
              :step="5"
              controls-position="right"
            />
          </el-form-item>
        </div>

        <!-- Level ladder -->
        <div class="level-ladder">
          <div class="ladder-head">
            <span>Membership levels</span>
            <el-button
              size="small"
              @click="addLevelRow"
            >
              <el-icon class="btn-icon">
                <Plus />
              </el-icon>Add Level
            </el-button>
          </div>
          <p class="ladder-hint">
            Users are placed on the highest level whose cumulative recharge
            threshold they meet (on every successful payment, unless an admin
            pinned their level). The discount applies to per-call usage billing.
          </p>
          <div
            v-for="(level, index) in configLevels"
            :key="index"
            class="ladder-row"
          >
            <el-input
              v-model="level.key"
              placeholder="key"
              class="ladder-key"
              :disabled="index === 0"
            />
            <el-input
              v-model="level.name"
              placeholder="Display name"
              class="ladder-name"
            />
            <el-input-number
              v-model="level.threshold"
              :min="0"
              :precision="2"
              :step="50"
              controls-position="right"
              class="ladder-threshold"
            />
            <span class="ladder-unit">CNY cumulative</span>
            <el-input-number
              v-model="level.discount_percent"
              :min="0"
              :max="100"
              :precision="1"
              :step="5"
              controls-position="right"
              class="ladder-discount"
            />
            <span class="ladder-unit">% off usage</span>
            <el-button
              link
              type="danger"
              :disabled="index === 0"
              @click="removeLevelRow(index)"
            >
              Remove
            </el-button>
          </div>
        </div>
      </el-form>
    </el-card>

    <el-card
      shadow="never"
      class="table-card"
    >
      <el-table
        v-loading="loading"
        :data="plans"
        stripe
      >
        <el-table-column
          prop="sort_order"
          label="Sort"
          width="70"
          align="center"
        />
        <el-table-column
          prop="name"
          label="Name"
          min-width="140"
        />
        <el-table-column
          prop="description"
          label="Description"
          min-width="200"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            {{ row.description || '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Price"
          width="100"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.price) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Original Price"
          width="120"
          align="right"
        >
          <template #default="{ row }">
            {{ row.original_price !== undefined && row.original_price !== null ? '¥' + formatAmount(row.original_price) : '-' }}
          </template>
        </el-table-column>
        <el-table-column
          label="Credited"
          width="110"
          align="right"
        >
          <template #default="{ row }">
            ¥{{ formatAmount(row.credited_amount) }}
          </template>
        </el-table-column>
        <el-table-column
          label="Validity"
          width="100"
          align="center"
        >
          <template #default="{ row }">
            {{ row.validity_days ? row.validity_days + ' days' : 'Balance' }}
          </template>
        </el-table-column>
        <el-table-column
          label="On Sale"
          width="90"
          align="center"
        >
          <template #default="{ row }">
            <el-tag
              size="small"
              :type="row.for_sale ? 'success' : 'info'"
            >
              {{ row.for_sale ? 'On Sale' : 'Hidden' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          label="Actions"
          width="150"
          fixed="right"
        >
          <template #default="{ row }">
            <el-button
              link
              type="primary"
              @click="openEdit(row)"
            >
              Edit
            </el-button>
            <el-button
              link
              type="danger"
              @click="handleDelete(row)"
            >
              Delete
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Create / edit dialog -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEditing ? 'Edit Plan' : 'Create Plan'"
      width="520px"
    >
      <el-form
        :model="form"
        label-width="130px"
        label-position="right"
      >
        <el-form-item label="Name">
          <el-input
            v-model="form.name"
            placeholder="Plan name"
          />
        </el-form-item>
        <el-form-item label="Description">
          <el-input
            v-model="form.description"
            type="textarea"
            :rows="2"
            placeholder="Short description shown on the plan card"
          />
        </el-form-item>
        <el-form-item label="Price (CNY)">
          <el-input-number
            v-model="form.price"
            :min="0.01"
            :precision="2"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
        <el-form-item label="Original Price">
          <el-input-number
            v-model="form.original_price"
            :min="0"
            :precision="2"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
        <el-form-item label="Credited Amount">
          <el-input-number
            v-model="form.credited_amount"
            :min="0"
            :precision="2"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
        <el-form-item label="Validity Days">
          <el-input-number
            v-model="form.validity_days"
            :min="0"
            :step="1"
            controls-position="right"
          />
          <div class="field-hint">
            0 means a pure balance top-up with no validity period
          </div>
        </el-form-item>
        <el-form-item label="For Sale">
          <el-switch v-model="form.for_sale" />
        </el-form-item>
        <el-form-item label="Sort Order">
          <el-input-number
            v-model="form.sort_order"
            :min="0"
            :step="1"
            controls-position="right"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :loading="saving"
          @click="handleSave"
        >
          Save
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, Refresh, Check } from '@element-plus/icons-vue'
import {
  apiAdminListPlans,
  apiAdminCreatePlan,
  apiAdminUpdatePlan,
  apiAdminDeletePlan,
  apiAdminGetConfig,
  apiAdminUpdateConfig,
} from '@/api/admin'

// ── Recharge settings (general limits + level ladder) ──
const configLoading = ref(false)
const savingConfig = ref(false)
const configForm = reactive({
  general: {
    min_recharge_amount: 1,
    max_recharge_amount: 1000,
    daily_recharge_limit: 5000,
    recharge_multiplier: 1,
    fee_rate: 0,
    order_expire_minutes: 30,
  },
  pricing: null,
})
const configLevels = ref([])

async function loadConfig() {
  configLoading.value = true
  try {
    const config = await apiAdminGetConfig()
    if (config?.general) Object.assign(configForm.general, config.general)
    configForm.pricing = config?.pricing || null
    configLevels.value = (config?.levels?.levels || []).map((level) => ({
      key: level.key,
      name: level.name,
      threshold: Number(level.threshold) || 0,
      discount_percent: Number(level.discount_percent) || 0,
    }))
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load recharge settings')
  } finally {
    configLoading.value = false
  }
}

function addLevelRow() {
  configLevels.value.push({
    key: '',
    name: '',
    threshold: 0,
    discount_percent: 0,
  })
}

function removeLevelRow(index) {
  configLevels.value.splice(index, 1)
}

async function saveConfig() {
  savingConfig.value = true
  try {
    const payload = {
      general: { ...configForm.general },
      levels: {
        levels: configLevels.value
          .filter((level) => level.key.trim() && level.name.trim())
          .map((level) => ({
            key: level.key.trim(),
            name: level.name.trim(),
            threshold: Number(level.threshold) || 0,
            discount_percent: Number(level.discount_percent) || 0,
          })),
      },
    }
    const saved = await apiAdminUpdateConfig(payload)
    configLevels.value = (saved?.levels?.levels || []).map((level) => ({
      key: level.key,
      name: level.name,
      threshold: Number(level.threshold) || 0,
      discount_percent: Number(level.discount_percent) || 0,
    }))
    ElMessage.success('Recharge settings saved')
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to save recharge settings')
  } finally {
    savingConfig.value = false
  }
}

const loading = ref(false)
const saving = ref(false)
const plans = ref([])
const dialogVisible = ref(false)
const editingId = ref(null)

const isEditing = computed(() => editingId.value !== null && editingId.value !== undefined)

const form = reactive({
  name: '',
  description: '',
  price: 10,
  original_price: 0,
  credited_amount: 10,
  validity_days: 0,
  for_sale: true,
  sort_order: 0,
})

function formatAmount(value) {
  return Number(value ?? 0).toFixed(2)
}

// Accept the common list response shapes (items / plans) from the admin API.
function extractRows(res) {
  if (Array.isArray(res)) return res
  if (Array.isArray(res?.items)) return res.items
  if (Array.isArray(res?.plans)) return res.plans
  return []
}

async function loadPlans() {
  loading.value = true
  try {
    const res = await apiAdminListPlans()
    plans.value = extractRows(res)
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to load plans')
  } finally {
    loading.value = false
  }
}

function resetForm() {
  form.name = ''
  form.description = ''
  form.price = 10
  form.original_price = 0
  form.credited_amount = 10
  form.validity_days = 0
  form.for_sale = true
  form.sort_order = 0
}

function openCreate() {
  editingId.value = null
  resetForm()
  dialogVisible.value = true
}

function openEdit(row) {
  editingId.value = row.id
  form.name = row.name || ''
  form.description = row.description || ''
  form.price = Number(row.price ?? 10)
  form.original_price = Number(row.original_price ?? 0)
  form.credited_amount = Number(row.credited_amount ?? 0)
  form.validity_days = Number(row.validity_days ?? 0)
  form.for_sale = row.for_sale !== false
  form.sort_order = Number(row.sort_order ?? 0)
  dialogVisible.value = true
}

async function handleSave() {
  if (!form.name.trim()) {
    ElMessage.warning('Plan name is required')
    return
  }
  saving.value = true
  try {
    const payload = { ...form, name: form.name.trim() }
    if (isEditing.value) {
      await apiAdminUpdatePlan(editingId.value, payload)
      ElMessage.success('Plan updated')
    } else {
      await apiAdminCreatePlan(payload)
      ElMessage.success('Plan created')
    }
    dialogVisible.value = false
    loadPlans()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to save the plan')
  } finally {
    saving.value = false
  }
}

async function handleDelete(row) {
  try {
    await ElMessageBox.confirm(
      `Delete plan "${row.name}"? This cannot be undone.`,
      'Delete Plan',
      { type: 'warning', confirmButtonText: 'Delete', cancelButtonText: 'Cancel' }
    )
  } catch {
    return
  }
  try {
    await apiAdminDeletePlan(row.id)
    ElMessage.success('Plan deleted')
    loadPlans()
  } catch (error) {
    ElMessage.error(error?.message || 'Failed to delete the plan')
  }
}

onMounted(() => {
  loadPlans()
  loadConfig()
})
</script>

<style scoped>
.admin-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.page-header h2 {
  margin: 0 0 4px;
  font-size: 18px;
  color: #1f2937;
}

.page-header p {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
}

.toolbar-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 16px;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.btn-icon {
  margin-right: 4px;
}

.table-card {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
}

.field-hint {
  width: 100%;
  margin-top: 4px;
  font-size: 11px;
  color: #9ca3af;
}

/* ── Recharge settings ── */
.toolbar-row {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 14px;
  flex-wrap: wrap;
}

.section-title h3 { margin: 0; font-size: 15px; color: #1f2937; }
.section-title p { margin: 4px 0 0; font-size: 12px; color: #9ca3af; }

.settings-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 0 24px;
}

.level-ladder {
  border-top: 1px dashed #e5e7eb;
  margin-top: 8px;
  padding-top: 14px;
}

.ladder-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 4px;
}

.ladder-hint {
  font-size: 12px;
  color: #9ca3af;
  margin: 0 0 12px;
  line-height: 1.5;
}

.ladder-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
  flex-wrap: wrap;
}

.ladder-key { width: 130px; }
.ladder-name { width: 160px; }
.ladder-threshold { width: 150px; }
.ladder-discount { width: 140px; }

.ladder-unit { font-size: 12px; color: #9ca3af; white-space: nowrap; }

@media (max-width: 768px) {
  .settings-grid { grid-template-columns: 1fr; }
}
</style>
