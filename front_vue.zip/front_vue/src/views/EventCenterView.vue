<template>
  <main class="event-page">
    <header>
      <div>
        <router-link to="/">← Back to App</router-link>
        <h1>Event Center</h1>
        <p>Route Feishu messages and system events to the right specialist Agent.</p>
      </div>
      <button :disabled="loading || saving" @click="load">Reload saved settings</button>
    </header>
    <p v-if="error" class="error" role="alert">{{ error }}</p>
    <p v-if="notice" class="notice" role="status">{{ notice }}</p>
    <p v-if="loading" role="status">Loading event settings...</p>
    <template v-if="loaded">
      <form class="panel" @submit.prevent="save">
        <EventRoutingRules v-model="policy" :agents="agents" :disabled="saving" />
        <div class="save-bar">
          <span>{{
            dirty
              ? 'Unsaved changes. Preview uses these changes.'
              : `Saved policy revision ${policy.revision}`
          }}</span
          ><button class="primary" :disabled="saving || !dirty" data-testid="save-routing">
            {{ saving ? 'Saving...' : 'Save routing' }}
          </button>
        </div>
      </form>
      <section class="panel">
        <h2>Routing preview</h2>
        <p>
          Try the current editor settings without saving, billing, or executing an Agent. Matching
          is case insensitive; keywords are literal text.
        </p>
        <form @submit.prevent="preview">
          <div class="preview-grid">
            <label
              >Source<select
                v-model="sample.source"
                aria-label="Preview source"
                @change="clearApiSource"
              >
                <option value="api">Authenticated API</option>
                <option value="feishu">Feishu</option>
                <option value="webhook">Webhook</option>
              </select></label
            >
            <label
              >Source ID<input
                v-model="sample.source_id"
                :disabled="sample.source === 'api'"
                placeholder="Optional bot / webhook ID"
            /></label>
            <label
              >Event type<input v-model="sample.event_type" required placeholder="issue.created"
            /></label>
          </div>
          <label
            >Event text<textarea
              v-model="sample.text"
              required
              maxlength="16000"
              rows="3"
              aria-label="Preview event text"
              placeholder="/debug Analyze this crash log"
            />
          </label>
          <button :disabled="previewing" type="submit">
            {{ previewing ? 'Checking...' : 'Preview route' }}
          </button>
        </form>
        <div v-if="decision" class="decision" role="status">
          <strong>{{ decision.agent ? agentName(decision.agent) : 'No Agent selected' }}</strong>
          <p>{{ decision.reason }}</p>
          <p v-if="decision.rule_id">Rule: {{ decision.rule_name }}</p>
          <p v-for="requirement in decision.requirements" :key="requirement">{{ requirement }}</p>
        </div>
      </section>
      <section class="panel"><EventWebhookSources :account-id="accountId" /></section>
      <section class="panel">
        <div class="section-heading">
          <div>
            <h2>Recent events</h2>
            <p>
              Queued → Running → Completed / Needs input / Failed. Interrupted work is never
              replayed automatically.
            </p>
          </div>
          <button :disabled="refreshing" @click="refreshHistory">Refresh events</button>
        </div>
        <p v-if="historyError" class="error" role="alert">{{ historyError }}</p>
        <p v-if="runtimeStatus && runtimeStatus !== 'running'" class="error" role="alert">
          Event worker: {{ runtimeStatus }}. Queued work will wait for service recovery.
        </p>
        <div class="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Received</th>
                <th>Source / Type</th>
                <th>Agent</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              <tr v-for="event in events" :key="event.id">
                <td>{{ formatDate(event.created_at) }}</td>
                <td>
                  {{ event.source }}<small>{{ event.event_type }}</small>
                </td>
                <td>{{ agentName(event.selected_agent) }}</td>
                <td>
                  <span class="status" :class="event.status">{{
                    event.status.replaceAll('_', ' ')
                  }}</span>
                </td>
                <td><button @click="openEvent(event.id)">Details</button></td>
              </tr>
              <tr v-if="!events.length">
                <td colspan="5">No events on this page.</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="pagination">
          <button :disabled="offset === 0 || refreshing" @click="changePage(-25)">Previous</button
          ><span>Page {{ offset / 25 + 1 }}</span
          ><button :disabled="events.length < 25 || refreshing" @click="changePage(25)">
            Next
          </button>
        </div>
      </section>
      <section v-if="detail" class="panel event-detail">
        <div class="section-heading">
          <h2>Event details</h2>
          <button @click="closeDetail">Close details</button>
        </div>
        <p>
          <strong>{{ detail.status }}</strong> · {{ detail.id }}
        </p>
        <p>{{ detail.route.reason }}</p>
        <p v-if="detail.error" class="error">{{ detail.error }}</p>
        <p v-if="detail.task_id">Task: {{ detail.task_id }}</p>
        <router-link v-if="detail.result?.workspace" :to="detail.result.workspace"
          >Open Agent workspace</router-link
        >
        <h3>Input</h3>
        <pre>{{ detail.input?.text }}</pre>
        <h3>Result</h3>
        <pre>{{ detail.result?.response || 'No result available.' }}</pre>
        <details>
          <summary>Structured result</summary>
          <pre>{{ JSON.stringify(detail.result, null, 2) }}</pre>
        </details>
      </section>
    </template>
  </main>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import EventRoutingRules from '../components/EventRoutingRules.vue'
import EventWebhookSources from '../components/EventWebhookSources.vue'
import {
  getEvent,
  getEventCatalog,
  getEventRouting,
  listEvents,
  previewEvent,
  saveEventRouting,
} from '../api/events.js'

const auth = useAuthStore()
const accountId = computed(() => String(auth.user?.id || ''))
const policy = ref({ enabled: false, fallback_agent: null, rules: [], revision: 0 })
const agents = ref([]),
  events = ref([]),
  detail = ref(null),
  selectedId = ref(''),
  offset = ref(0)
const error = ref(''),
  historyError = ref(''),
  notice = ref(''),
  baseline = ref('')
const loading = ref(false),
  loaded = ref(false),
  saving = ref(false),
  refreshing = ref(false),
  previewing = ref(false)
const sample = ref({ source: 'api', source_id: '', event_type: 'issue.created', text: '' }),
  decision = ref(null)
const runtimeStatus = ref('')
const dirty = computed(() => JSON.stringify(policy.value) !== baseline.value)
let revision = 0,
  previewRevision = 0,
  historyRevision = 0,
  timer
const agentName = id => agents.value.find(agent => agent.id === id)?.name || id || '—'
const formatDate = value =>
  new Date(
    value.endsWith('Z') || /[+-]\d\d:\d\d$/.test(value) ? value : `${value}Z`
  ).toLocaleString()

async function load() {
  const current = ++revision
  previewRevision++
  historyRevision++
  clearTimeout(timer)
  loading.value = true
  loaded.value = false
  error.value = ''
  notice.value = ''
  detail.value = null
  selectedId.value = ''
  decision.value = null
  offset.value = 0
  events.value = []
  try {
    const [saved, catalog] = await Promise.all([getEventRouting(), getEventCatalog()])
    if (current !== revision) return
    policy.value = saved
    baseline.value = JSON.stringify(saved)
    agents.value = catalog.agents
    loaded.value = true
    await refreshHistory()
  } catch (failure) {
    if (current === revision) error.value = failure.message || 'Could not load event settings.'
  } finally {
    if (current === revision) loading.value = false
  }
}
async function save() {
  const current = revision
  saving.value = true
  error.value = ''
  notice.value = ''
  try {
    const saved = await saveEventRouting(JSON.parse(JSON.stringify(policy.value)))
    if (current !== revision) return
    policy.value = saved
    baseline.value = JSON.stringify(saved)
    notice.value =
      'Routing saved. New events use this policy; queued events retain their recorded route.'
  } catch (failure) {
    if (current === revision) error.value = failure.message || 'Could not save routing.'
  } finally {
    if (current === revision) saving.value = false
  }
}
async function preview() {
  const current = revision,
    request = ++previewRevision
  previewing.value = true
  error.value = ''
  decision.value = null
  try {
    const result = await previewEvent({
      source: sample.value.source,
      source_id: sample.value.source_id,
      policy: JSON.parse(JSON.stringify(policy.value)),
      event: { event_id: 'preview', event_type: sample.value.event_type, text: sample.value.text },
    })
    if (current === revision && request === previewRevision) decision.value = result
  } catch (failure) {
    if (current === revision && request === previewRevision)
      error.value = failure.message || 'Preview failed.'
  } finally {
    if (current === revision && request === previewRevision) previewing.value = false
  }
}
async function refreshHistory() {
  const current = revision,
    request = ++historyRevision
  clearTimeout(timer)
  refreshing.value = true
  try {
    const result = await listEvents(offset.value)
    if (current !== revision || request !== historyRevision) return
    events.value = result.items
    runtimeStatus.value = result.runtime?.status || ''
    historyError.value = ''
    if (selectedId.value) await openEvent(selectedId.value)
  } catch (failure) {
    if (current === revision && request === historyRevision)
      historyError.value = failure.message || 'Could not refresh events.'
  } finally {
    if (current === revision && request === historyRevision) {
      refreshing.value = false
      timer = setTimeout(refreshHistory, 5000)
    }
  }
}
async function openEvent(id) {
  selectedId.value = id
  const current = revision
  try {
    const result = await getEvent(id)
    if (current === revision && selectedId.value === id) detail.value = result
  } catch (failure) {
    if (current === revision)
      historyError.value = failure.message || 'Could not load event details.'
  }
}
function changePage(delta) {
  offset.value = Math.max(0, offset.value + delta)
  void refreshHistory()
}
function closeDetail() {
  detail.value = null
  selectedId.value = ''
}
function clearApiSource() {
  if (sample.value.source === 'api') sample.value.source_id = ''
}
watch(
  accountId,
  () => {
    saving.value = false
    refreshing.value = false
    previewing.value = false
    sample.value.text = ''
    void load()
  },
  { immediate: true }
)
watch(
  [sample, policy],
  () => {
    previewRevision++
    decision.value = null
    previewing.value = false
  },
  { deep: true }
)
onBeforeUnmount(() => {
  revision++
  clearTimeout(timer)
})
</script>

<style scoped>
.event-page {
  height: 100%;
  overflow-y: auto;
  max-width: 1180px;
  margin: auto;
  padding: 30px 24px 70px;
  color: #0f172a;
}
header,
.section-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
}
h1 {
  font-size: 28px;
  margin: 18px 0 8px;
}
h2 {
  font-size: 18px;
  margin: 0;
}
h3 {
  font-size: 14px;
}
p {
  font-size: 13px;
  line-height: 1.7;
  color: #64748b;
}
a {
  font-size: 13px;
  color: #2563eb;
}
.panel {
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 24px;
  margin-top: 24px;
}
.save-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  border-top: 1px solid #e2e8f0;
  padding-top: 18px;
  margin-top: 24px;
  font-size: 12px;
  color: #64748b;
}
button {
  background: white;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 8px 12px;
  cursor: pointer;
  color: #334155;
}
button:disabled {
  opacity: 0.5;
  cursor: default;
}
.primary {
  background: #2563eb;
  border-color: #2563eb;
  color: white;
}
.preview-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
}
label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 12px;
  color: #475569;
  margin-bottom: 14px;
}
input,
select,
textarea {
  padding: 9px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  min-width: 0;
  color: #0f172a;
  background: white;
}
textarea {
  resize: vertical;
  line-height: 1.5;
}
.decision {
  padding: 16px;
  background: #eff6ff;
  border-radius: 8px;
  margin-top: 16px;
}
.error {
  color: #b91c1c;
  background: #fef2f2;
  padding: 12px;
  border-radius: 8px;
}
.notice {
  color: #166534;
  background: #f0fdf4;
  padding: 12px;
  border-radius: 8px;
}
.table-scroll {
  overflow: auto;
}
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
  text-align: left;
}
th,
td {
  padding: 12px 10px;
  border-bottom: 1px solid #e2e8f0;
  white-space: nowrap;
}
th {
  color: #64748b;
  font-weight: 500;
}
small {
  display: block;
  color: #64748b;
  margin-top: 5px;
}
.status {
  padding: 4px 8px;
  border-radius: 5px;
  background: #f1f5f9;
  color: #475569;
  font-size: 12px;
}
.status.completed {
  color: #15803d;
  background: #f0fdf4;
}
.status.failed,
.status.interrupted {
  color: #b91c1c;
  background: #fef2f2;
}
.status.needs_input {
  color: #a16207;
  background: #fefce8;
}
.status.running,
.status.queued {
  color: #1d4ed8;
  background: #eff6ff;
}
.pagination {
  display: flex;
  gap: 16px;
  justify-content: flex-end;
  align-items: center;
  font-size: 12px;
  margin-top: 18px;
}
pre {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  background: #f8fafc;
  padding: 16px;
  border-radius: 8px;
  max-height: 500px;
  overflow: auto;
  font-size: 12px;
  line-height: 1.6;
}
summary {
  cursor: pointer;
  font-size: 13px;
}
@media (max-width: 700px) {
  .event-page {
    padding: 20px 12px;
  }
  .panel {
    padding: 16px;
  }
  header {
    align-items: flex-start;
  }
  .preview-grid {
    grid-template-columns: 1fr;
  }
}
</style>
