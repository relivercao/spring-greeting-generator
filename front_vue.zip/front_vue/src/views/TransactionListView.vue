<template>
  <div class="payment-page">
    <!-- Top bar -->
    <header class="page-header">
      <button
        type="button"
        class="back-link"
        @click="router.push('/')"
      >
        <el-icon size="14">
          <ArrowLeft />
        </el-icon>
        <span>Back to App</span>
      </button>
      <h1 class="page-title">
        Balance transactions
      </h1>
      <div class="header-spacer" />
    </header>

    <main class="page-body">
      <div class="table-card">
        <el-table
          v-loading="loading"
          :data="transactions"
          stripe
          style="width: 100%"
        >
          <el-table-column
            label="Type"
            width="150"
          >
            <template #default="{ row }">
              <el-tag
                :type="typeTagType(row.type)"
                size="small"
                effect="plain"
              >
                {{ typeLabel(row.type) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column
            label="Amount"
            width="130"
            align="right"
          >
            <template #default="{ row }">
              <span :class="amountClass(row.amount)">{{ formatSignedAmount(row.amount) }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="Balance after"
            width="130"
            align="right"
          >
            <template #default="{ row }">
              {{ formatMoney(row.balance_after) }}
            </template>
          </el-table-column>
          <el-table-column
            label="Model"
            min-width="170"
          >
            <template #default="{ row }">
              <span class="mono">{{ row.model || '-' }}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="Created at"
            min-width="170"
          >
            <template #default="{ row }">
              {{ formatTime(row.created_at) }}
            </template>
          </el-table-column>
          <el-table-column label="Usage Details" width="130">
            <template #default="{ row }">
              <el-button
                v-if="row.type === 'usage' && row.reference_id"
                link
                type="primary"
                @click="router.push({ path: '/usage', query: { usage_id: row.reference_id } })"
              >View Details</el-button>
              <span v-else>-</span>
            </template>
          </el-table-column>
          <template #empty>
            <el-empty description="No transactions yet." />
          </template>
        </el-table>

        <div class="pagination-row">
          <el-pagination
            v-model:current-page="page"
            v-model:page-size="pageSize"
            :total="total"
            :page-sizes="[10, 20, 50]"
            layout="total, sizes, prev, pager, next"
            background
            @current-change="fetchTransactions"
            @size-change="handleSizeChange"
          />
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { apiGetTransactions } from '@/api/payment'

const router = useRouter()

const loading      = ref(false)
const transactions = ref([])
const total        = ref(0)
const page         = ref(1)
const pageSize     = ref(10)

// ── Helpers ──
function formatMoney(value) {
  const num = Number(value)
  return `¥${(Number.isFinite(num) ? num : 0).toFixed(2)}`
}

function formatSignedAmount(value) {
  const num = Number(value)
  if (!Number.isFinite(num)) return formatMoney(value)
  const sign = num > 0 ? '+' : ''
  return `${sign}¥${num.toFixed(2)}`
}

function amountClass(value) {
  return Number(value) >= 0 ? 'amount-in' : 'amount-out'
}

function parseServerTime(value) {
  if (typeof value !== 'string') return new Date(value)
  // Server datetimes are UTC but may omit the timezone marker; add it so parsing is correct
  return new Date(/Z$|[+-]\d{2}:?\d{2}$/.test(value) ? value : `${value}Z`)
}

function formatTime(value) {
  if (!value) return '-'
  const date = parseServerTime(value)
  if (Number.isNaN(date.getTime())) return String(value)
  return date.toLocaleString()
}

function typeLabel(type) {
  const labels = {
    recharge: 'Recharge',
    usage: 'Usage',
    admin_adjust: 'Admin adjust',
    signup_bonus: 'Signup bonus',
    promo_bonus: 'Promo bonus',
    refund: 'Refund',
  }
  return labels[type] || type || '-'
}

function typeTagType(type) {
  const types = {
    recharge: 'success',
    usage: 'warning',
    admin_adjust: 'info',
    signup_bonus: 'primary',
    promo_bonus: 'primary',
    refund: 'info',
  }
  return types[type] || 'info'
}

// ── Data loading ──
async function fetchTransactions() {
  loading.value = true
  try {
    const data = await apiGetTransactions({ page: page.value, page_size: pageSize.value })
    transactions.value = data?.items || data?.transactions || []
    total.value = Number(data?.total ?? data?.total_count) || transactions.value.length
  } catch (e) {
    ElMessage.error(e.message || 'Failed to load transactions.')
  } finally {
    loading.value = false
  }
}

function handleSizeChange() {
  // Changing the page size jumps back to the first page to avoid out-of-range requests
  page.value = 1
  fetchTransactions()
}

onMounted(fetchTransactions)
</script>

<style scoped>
.payment-page {
  min-height: 100vh;
  background: #f0f4ff;
  display: flex;
  flex-direction: column;
}

/* ── Top bar ── */
.page-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px 32px;
  background: #ffffff;
  border-bottom: 1px solid #e8edf3;
}

.back-link {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: none;
  background: transparent;
  color: #6b7280;
  font-size: 13px;
  cursor: pointer;
  padding: 6px 10px;
  border-radius: 7px;
  transition: color 0.2s, background 0.2s;
}

.back-link:hover { color: #2563eb; background: #eff6ff; }

.page-title {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
  margin: 0;
}

.header-spacer { flex: 1; }

/* ── Body ── */
.page-body {
  flex: 1;
  width: 100%;
  max-width: 960px;
  margin: 0 auto;
  padding: 28px 24px 48px;
}

.table-card {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 18px 20px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}

.amount-in { color: #16a34a; font-weight: 600; }

.amount-out { color: #dc2626; font-weight: 600; }

.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
}

.pagination-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}

/* ── Responsive ── */
@media (max-width: 768px) {
  .page-header { padding: 12px 16px; }
  .page-body { padding: 20px 16px 40px; }
  .table-card { padding: 12px; overflow-x: auto; }
}
</style>
