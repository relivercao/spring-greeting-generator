import { http } from './http.js'

const base = '/v1/connected-apps/feishu'
export const getFeishuConfiguration = () => http.get(`${base}/config`)
export const saveFeishuConfiguration = configuration => http.put(`${base}/config`, configuration)
export const checkFeishuConnection = () => http.post(`${base}/check`)
export const startFeishuListener = () => http.post(`${base}/start`)
export const stopFeishuListener = () => http.post(`${base}/stop`)
export const disconnectFeishu = () => http.delete(`${base}/config`)
