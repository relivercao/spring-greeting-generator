/**
 * LLM Settings API
 */
import { http } from './http.js'

export function getLLMSettings() {
  return http.get('/v1/settings/llm')
}

/**
 * ENV JSON Configuration Editor API
 */
export function getEnvJson() {
  return http.get('/v1/settings/env-json')
}

export function saveEnvJson(data) {
  return http.post('/v1/settings/env-json', { data })
}

export function getGlobalEmailSettings() {
  return http.get('/v1/settings/email')
}

export function saveGlobalEmailSettings(configuration) {
  return http.put('/v1/settings/email', configuration)
}

export function checkGlobalEmailConnection() {
  return http.post('/v1/settings/email/check', {})
}

/**
 * Multi-Provider Settings API
 */
export function getProviderSettings() {
  return getEnvJson()
}

export function saveProviderSettings(data) {
  return http.post('/v1/settings/providers', data)
}
