import { http } from './http.js'

export function searchMarketSkills(query, page = 1, limit = 20) {
  const params = `q=${encodeURIComponent(query)}&page=${page}&limit=${limit}`
  return http.get('/v1/skill-market/search?' + params)
}

export function listInstalledMarketSkills() {
  return http.get('/v1/skill-market/installed')
}

export function previewMarketSkill(githubUrl) {
  return http.get('/v1/skill-market/preview?github_url=' + encodeURIComponent(githubUrl))
}

export function installMarketSkill(githubUrl) {
  return http.post('/v1/skill-market/install', { github_url: githubUrl })
}

export const submissionTargets = () => http.get('/v1/skill-market/submission-targets')
export const submitUserSkill = (file, agent = '', stage = '') => {
  const data = new FormData()
  data.append('file', file)
  if (agent) {
    data.append('agent', agent)
    data.append('stage', stage)
  }
  return http.upload('/v1/skill-market/submissions', data)
}
export const listSkillSubmissions = (review = false, page = 1) =>
  http.get(`/v1/skill-market/submissions?review_queue=${review}&page=${page}`)
export const getSkillSubmission = id =>
  http.get(`/v1/skill-market/submissions/${encodeURIComponent(id)}`)
export const publishSkillSubmission = id =>
  http.post(`/v1/skill-market/submissions/${encodeURIComponent(id)}/publish`, {})
export const rejectSkillSubmission = (id, note) =>
  http.post(`/v1/skill-market/submissions/${encodeURIComponent(id)}/reject`, { note })
export const installedSkillPackage = id =>
  http.get(`/v1/skill-market/packages/${encodeURIComponent(id)}`)
export const skillPackageDownloadUrl = id =>
  `${import.meta.env.VITE_API_URL || '/api'}/v1/skill-market/packages/${encodeURIComponent(id)}/download`
