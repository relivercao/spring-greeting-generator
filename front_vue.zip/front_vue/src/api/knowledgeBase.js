import { http } from './http.js'

const KNOWLEDGE_REQUEST_TIMEOUT_MS = 330000

export function listKnowledgeDocuments() {
  return http.get('/v1/knowledge/documents')
}

export function searchKnowledgeRegisters({ limit = 100 } = {}) {
  const params = new URLSearchParams({ limit: String(limit) })
  return http.get(`/v1/knowledge/registers/search?${params}`)
}

export function uploadKnowledgeDocument(file, metadata) {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('chip', metadata.chip || 'GENERAL')
  formData.append('title', metadata.title || file.name)
  formData.append('revision', metadata.revision || '')
  formData.append('peripheral_hint', metadata.peripheralHint || '')
  formData.append('doc_type', metadata.docType || 'reference')
  const tags = Array.isArray(metadata.tags)
    ? metadata.tags
    : String(metadata.tags || '').split(',').map(tag => tag.trim()).filter(Boolean)
  for (const tag of tags) formData.append('tags', tag)
  formData.append('llm_ocr', String(metadata.llmOcr !== false))
  return http.upload('/v1/knowledge/documents', formData)
}

export async function askKnowledgeBase(payload) {
  const { retrievalMode, ...request } = payload
  const controller = new AbortController()
  let timedOut = false
  const timer = globalThis.setTimeout(() => {
    timedOut = true
    controller.abort()
  }, KNOWLEDGE_REQUEST_TIMEOUT_MS)
  try {
    return await http.post('/v1/knowledge/ask', {
      ...request,
      retrieval_mode: retrievalMode || 'hybrid',
    }, { signal: controller.signal })
  } catch (error) {
    if (timedOut) throw new Error('The knowledge request timed out after 330 seconds. Please try again.', { cause: error })
    throw error
  } finally {
    globalThis.clearTimeout(timer)
  }
}

export function previewKnowledgeChunks(text, maxChars = 2200) {
  return http.post('/v1/knowledge/chunks/preview', {
    text,
    max_chars: maxChars,
  })
}

export function deleteKnowledgeDocument(documentId) {
  return http.delete(`/v1/knowledge/documents/${encodeURIComponent(documentId)}`)
}

export function getKnowledgeRepositoryStatus() {
  return http.get('/v1/knowledge/repository/status')
}

export function syncKnowledgeRepository(payload = {}) {
  return http.post('/v1/knowledge/repository/sync', {
    pull: payload.pull ?? true,
    push: payload.push ?? false,
    rebuild_index: payload.rebuildIndex ?? true,
  })
}

export function importGithubReference(payload) {
  return http.post('/v1/knowledge/references/github', {
    repository: payload.repository,
    ref: payload.ref || '',
    chip: payload.chip || 'GENERAL',
    revision: payload.revision || '',
    doc_type: payload.docType || 'reference-project',
    tags: payload.tags || [],
    max_documents: payload.maxDocuments || 100,
  })
}

export function importObsidianVault(payload) {
  return http.post('/v1/knowledge/obsidian/import', {
    path: payload.path || '',
    chip: payload.chip || '',
    revision: payload.revision || '',
    doc_type: payload.docType || 'obsidian-note',
    tags: payload.tags || [],
    include_globs: payload.includeGlobs || [],
    exclude_globs: payload.excludeGlobs || [],
    max_documents: payload.maxDocuments || 500,
    rebuild_index: payload.rebuildIndex ?? true,
  })
}

export function buildKnowledgeMkdocs(payload = {}) {
  return http.post('/v1/knowledge/publish/mkdocs', {
    strict: payload.strict ?? false,
    clean: payload.clean ?? true,
  })
}
