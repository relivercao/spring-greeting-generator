import { http } from './http.js'

function notifyTaskData(onData, data) {
  if (!onData) return
  try {
    onData(data)
  } catch (err) {
    console.error('[apiPollTask] onData callback failed:', err)
    throw err // Re-throw to propagate error to caller
  }
}

/**
 * Upload source file and create unit test generation task (interfaces with generate-tests endpoint)
 *
 * @param {File|File[]} files  - Single file or array of files
 * @param {object} opts
 *   - framework:      'gtest' | 'unity'   (default: 'gtest')
 *   - layer:          'auto' | 'hal' | 'driver' | 'controller' | 'app'  (default: 'auto')
 *   - coverage:       number   (default: 90)
 *   - iterations:     number   (default: 3)
 *   - output_dir:     string   (optional, custom output directory)
 *   - enable_mock:    boolean  (default: true, enable mock generation)
 *   - compile_verify: boolean (default: true, enable QBS compilation verification)
 *   - build_profile:  string   (default: server-selected profile)
 *   - platform:       string   (default: 'stm32u3')
 *   - auto_update_qbs: boolean (default: true)
 * @returns {Promise<{task_id, status, message, files_received}>}
 */
export async function apiGenerateTests(files, opts = {}) {
  const form = new FormData()

  const rawFileList = Array.isArray(files) ? files : [files]
  const fileList = rawFileList.filter(f => f instanceof Blob)

  if (fileList.length === 0) {
    throw new Error('No valid files to upload')
  }

  for (const f of fileList) {
    const filename = typeof f.name === 'string' && f.name ? f.name : 'source_file.c'
    form.append('file', f, filename)
  }

  // Basic parameters
  form.append('framework',  opts.framework  || 'gtest')
  form.append('layer',      opts.layer      || 'auto')
  form.append('target_coverage',   String(opts.coverage ?? 90))
  form.append('max_iterations', String(opts.iterations ?? 3))

  if (opts.output_dir) {
    form.append('output_dir', opts.output_dir)
  }

  // Task metadata (title, source file path)
  if (opts.task_title) {
    form.append('task_title', opts.task_title)
  }
  if (opts.source_filename) {
    form.append('source_filename', opts.source_filename)
  }
  if (opts.source_full_path) {
    form.append('source_full_path', opts.source_full_path)
  }

  // Real source file paths (in the same order as the uploaded file list), used for backend layer detection and project root inference
  if (opts.source_paths) {
    const paths = Array.isArray(opts.source_paths) ? opts.source_paths : [opts.source_paths]
    form.append('source_paths_json', JSON.stringify(paths))
  }

  // Full parameters aligned with test_real_pipeline.py
  form.append('enable_mock', String(opts.enable_mock ?? true))
  form.append('compile_verify', String(opts.compile_verify ?? true))
  form.append('build_profile',   opts.build_profile   || 'auto')
  form.append('platform',        opts.platform        || 'stm32u3')
  form.append('auto_update_qbs', String(opts.auto_update_qbs ?? true))

  return http.upload('/v1/generate-tests', form)
}

/**
 * Poll task progress in real-time
 * Call GET /v1/unittest/tasks/:id every intervalMs to get node status
 *
 * @param {string}   taskId
 * @param {function} onData  - Callback (data) => void
 * @param {number}   intervalMs - Polling interval, default 1500ms
 * @returns {function} Cleanup function to stop polling
 */
export function apiPollTask(taskId, onData) {
  let timer = null
  let polling = false
  let pollCount = 0
  let stopped = false
  let pollingFailures = 0

  const getInterval = () => pollingFailures
    ? Math.min(2000 * pollingFailures, 10000)
    : pollCount < 5 ? 2000 : 10000

  const poll = async () => {
    if (stopped || polling) return
    polling = true
    let requestSucceeded = false
    try {
      const data = await http.get(`/v1/unittest/tasks/${taskId}`)
      if (stopped) return
      requestSucceeded = true
      pollingFailures = 0
      notifyTaskData(onData, data)
      if (data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled') {
        clearTimeout(timer)
        timer = null
        return
      }
    } catch (err) {
      if (stopped) return
      console.error('Poll error:', err)

      // Check if this is an AWS authentication error
      // The http.js layer already triggers SSO login, but we need to notify the UI
      if (err.message && err.message.includes('AWS_AUTH_REQUIRED')) {
        console.warn('[apiPollTask] AWS authentication error detected, SSO login should have been triggered')
        // Don't stop polling - let it continue after user completes SSO login
        // Just notify the UI about the auth requirement
        notifyTaskData(onData, {
          status: 'auth_required',
          error: 'AWS authentication required. Please complete login in browser.',
          aws_auth_required: true
        })
      } else if (!requestSucceeded && (
        !err.status || err.status >= 500 || err.status === 408 || err.status === 429
      )) {
        pollingFailures++
        notifyTaskData(onData, {
          status: 'connection_retrying',
          message: `Unable to read task progress. Retrying in ${getInterval() / 1000} seconds; the last known task state is preserved.`,
        })
      } else {
        // For other errors, stop polling and mark as failed
        clearTimeout(timer)
        timer = null
        notifyTaskData(onData, { status: 'failed', error: err.message })
        return
      }
    } finally {
      polling = false
      pollCount++
    }
    if (!stopped) timer = setTimeout(poll, getInterval())
  }

  poll()
  return () => {
    stopped = true
    if (timer) { clearTimeout(timer); timer = null }
  }
}


/**
 * Listen to task progress via WebSocket (legacy, kept for compatibility)
 *
 * @deprecated Use apiPollTask instead
 */
export function apiWaitForTask(taskId, onData) {
  return new Promise((resolve, reject) => {
    const wsUrl = `ws://localhost:8000/api/v1/ws/stream/${taskId}`
    const ws = new WebSocket(wsUrl)

    ws.onopen = () => {
      console.warn('WebSocket connected for task stream')
    }

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)

        notifyTaskData(onData, data)

        if (data.type === 'complete' || data.type === 'error') {
          ws.close()
          resolve(data)
        }
      } catch (error) {
        console.error('WebSocket message error:', error)
      }
    }

    ws.onerror = (error) => {
      console.error('WebSocket error:', error)
      ws.close()
      reject(new Error('WebSocket connection error'))
    }

    ws.onclose = () => {
      console.warn('WebSocket disconnected')
    }
  })
}

/**
 * Get unittest task list (summary only, without full result data)
 *
 * @param {number} limit - Maximum number of tasks to return (default: 100)
 * @returns {Promise<{tasks: Array, total: number}>}
 */
export async function apiGetTaskList(limit = 100) {
  return http.get('/v1/unittest/tasks', { params: { limit } })
}

/**
 * Query task result in one request (suitable for polling or when task is already completed)
 *
 * @param {string} taskId
 * @returns {Promise<object>}
 */
export async function apiGetTask(taskId) {
  return http.get(`/v1/unittest/tasks/${taskId}`)
}

/**
 * Cancel a running unit test task
 *
 * @param {string} taskId
 * @returns {Promise<{task_id, status, message}>}
 */
export async function apiCancelTask(taskId) {
  return http.post(`/v1/unittest/tasks/${taskId}/cancel`)
}

/** Create an ordered FIFO batch unit-test task. */
export async function apiCreateBatchTask(files, options = {}) {
  const rawFiles = Array.isArray(files) ? files : [files]
  const sourcePaths = options.source_paths ?? []
  const form = new FormData()

  const fileList = rawFiles.map((entry, index) => {
    const blob = entry instanceof Blob ? entry : entry?.file
    if (!(blob instanceof Blob)) return null

    const suppliedName = entry && typeof entry === 'object' ? entry.name : ''
    const sourceName = typeof sourcePaths[index] === 'string'
      ? sourcePaths[index].replace(/\\/g, '/').split('/').pop()
      : ''
    const filename = suppliedName || blob.name || sourceName || `source-${index + 1}.c`
    form.append('file', blob, filename)
    return blob
  }).filter(Boolean)

  if (fileList.length === 0) throw new Error('No valid files to upload')
  if (fileList.length !== sourcePaths.length) {
    throw new Error('Batch source paths must match the uploaded file count')
  }

  form.append('source_paths_json', JSON.stringify(sourcePaths))
  if (options.source_mode) form.append('source_mode', options.source_mode)
  return http.upload('/v1/unittest/batch-tasks', form)
}

function batchTaskPath(taskId) {
  if (!taskId || typeof taskId !== 'string') {
    throw new Error('Batch task ID is required')
  }
  return `/v1/unittest/batch-tasks/${encodeURIComponent(taskId)}`
}

export function apiGetBatchTask(taskId) {
  return http.get(batchTaskPath(taskId))
}

export function apiGetBatchTaskList(options = {}) {
  const params = new URLSearchParams()
  if (options.status) params.set('status', String(options.status))
  if (options.limit !== undefined && options.limit !== null) {
    params.set('limit', String(options.limit))
  }
  if (options.offset !== undefined && options.offset !== null) {
    params.set('offset', String(options.offset))
  }
  const includeItems = options.include_items ?? options.includeItems
  if (includeItems !== undefined && includeItems !== null) {
    params.set('include_items', String(Boolean(includeItems)))
  }
  const query = params.toString()
  return http.get(`/v1/unittest/batch-tasks${query ? `?${query}` : ''}`)
}

function createBatchTaskPoller({ fetchTask, onData }) {
  let timer = null
  let polling = false
  let stopped = false
  let networkFailures = 0
  const maxNetworkFailures = 5

  const stop = () => {
    stopped = true
    if (timer) {
      clearTimeout(timer)
      timer = null
    }
  }

  const poll = async () => {
    if (stopped || polling) return
    polling = true
    let nextDelay = 2000
    try {
      const data = await fetchTask()
      if (stopped) return
      networkFailures = 0
      notifyTaskData(onData, data)
      if (data?.status === 'done') {
        stop()
        return
      }
      const serverDelay = Number(data?.poll_after_ms)
      if (Number.isFinite(serverDelay) && serverDelay > 0) nextDelay = serverDelay
    } catch (err) {
      console.error('Batch poll error:', err)
      if (err?.message?.includes('AWS_AUTH_REQUIRED')) {
        notifyTaskData(onData, {
          status: 'auth_required',
          error: 'AWS authentication required. Please complete login in browser.',
          aws_auth_required: true,
        })
      } else {
        networkFailures += 1
        if (networkFailures >= maxNetworkFailures) {
          stop()
          notifyTaskData(onData, {
            status: 'client_error',
            error: `Lost connection to the backend after ${networkFailures} poll attempts (${err?.message || 'poll failed'}); the displayed state is the last known one — refresh the page once the backend is back`,
          })
          return
        }
        nextDelay = Math.min(2000 * networkFailures, 10000)
      }
    } finally {
      polling = false
    }
    if (!stopped) timer = setTimeout(poll, nextDelay)
  }

  void poll()
  return stop
}

export function apiPollBatchTask(taskId, onData) {
  return createBatchTaskPoller({
    fetchTask: () => apiGetBatchTask(taskId),
    onData,
  })
}

export function apiCancelBatchTask(taskId) {
  return http.post(`${batchTaskPath(taskId)}/cancel`)
}

export function apiResumeBatchTask(taskId) {
  return http.post(`${batchTaskPath(taskId)}/resume`)
}
