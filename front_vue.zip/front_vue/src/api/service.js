/**
 * Portable Package Service Management API
 *
 * Provides the following endpoints:
 * - Check service status
 * - Remotely shutdown services from frontend UI
 */
import { http } from './http.js'

/**
 * Get current service status (backend/frontend)
 * @returns {Promise<Object>} Service status information
 */
export async function apiGetServiceStatus() {
  return http.get('/v1/service/status')
}

/**
 * Shutdown all services (backend + frontend)
 *
 * Warning: This will make the API unavailable in about 1 second
 * @returns {Promise<Object>} Shutdown confirmation
 */
export async function apiShutdownServices() {
  return http.post('/v1/service/shutdown')
}

/**
 * Load balancer quick health check
 * @returns {Promise<Object>} Health status
 */
export async function apiHealthCheck() {
  return http.get('/v1/service/health')
}