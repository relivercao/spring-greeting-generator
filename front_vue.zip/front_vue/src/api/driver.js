/**
 * @file driver.js
 * @author zhangjian
 * @brief Driver Agent API client for upload, generation, polling, artifacts,
 *        chat, and build configuration endpoints.
 * @version 1.1.0-fix-404-polling
 * @date 2026-07-21
 * @copyright Copyright (c) 2026 relivercao@gmail.com
 * All rights reserved.
 *
 * This module is the transport boundary for Driver Agent frontend features. It
 * only wraps backend endpoints; it does not own UI state, task persistence, or
 * routing. Keeping Driver requests here prevents components from hardcoding
 * endpoint paths.
 */
import { http } from './http.js'

const DRIVER_TASK_POLL_INTERVAL_MS = 2000
const DRIVER_TASK_MAX_MISSING_POLLS = 12
const DRIVER_TASK_MAX_RETRY_DELAY_MS = 15000
const DRIVER_TASK_POLL_TIMEOUT_MS = 15000

export function isTransientDriverError(error) {
  const status = Number(error?.status)
  if (Number.isFinite(status) && status > 0) {
    return [408, 429].includes(status) || (status >= 500 && status <= 599)
  }
  return error?.name === 'AbortError' || !error?.status
}

function getPollRetryDelay(errorCount) {
  return Math.min(
    DRIVER_TASK_POLL_INTERVAL_MS * (2 ** Math.max(0, errorCount - 1)),
    DRIVER_TASK_MAX_RETRY_DELAY_MS,
  )
}

// ==================== File Sources ====================

/**
 * Upload one or more files to the driver knowledge base or reference set.
 * @param {File[]} files - Raw File objects
 * @param {'knowledge_base'|'reference'} sourceType
 * @returns {Promise<{sources: Array}>}
 */
export async function apiUploadDriverSources(files, sourceType) {
  const formData = new FormData()
  for (const file of files) {
    formData.append('files', file)
  }
  formData.append('source_type', sourceType)
  return http.upload('/v1/driver/sources/upload', formData)
}

/**
 * Get an uploaded driver source file status.
 * @param {string} sourceId
 * @returns {Promise<object>}
 */
export async function apiGetDriverSource(sourceId) {
  return http.get(`/v1/driver/sources/${encodeURIComponent(sourceId)}`)
}

/**
 * Delete an uploaded driver source file.
 * @param {string} sourceId
 * @returns {Promise<{source_id: string, deleted: boolean}>}
 */
export async function apiDeleteDriverSource(sourceId) {
  return http.delete(`/v1/driver/sources/${encodeURIComponent(sourceId)}`)
}

// ==================== Generation ====================

/**
 * Start full driver generation pipeline.
 * @param {{
 *   prompt: string,
 *   module_config: { module_type: string, module_name: string, device_name?: string,
 *                    device_type?: string, interface?: string, mcu_family?: string, platform?: string },
 *   source_ids?: string[],
 *   output_options?: object,
 * }} payload
 * @param {RequestInit} [options]
 * @returns {Promise<{task_id: string, session_id: string, status: string, message: string}>}
 */
export async function apiGenerateDriver(payload, options = {}) {
  return http.post('/v1/driver/generate', payload, options)
}

/**
 * Compatibility adapter for the generic AgentWorkspace driver action.
 * New Driver work should use DriverWorkspace so sources and configuration stay editable.
 * @param {File} file
 * @param {{deviceName?: string, interface?: string, mcuFamily?: string, platform?: string, requirements?: string}} options
 */
export async function apiCreateDriverTask(file, options = {}) {
  if (!file) throw new Error('A driver specification file is required')
  const upload = await apiUploadDriverSources([file], 'reference')
  const sourceId = upload?.sources?.[0]?.source_id
  if (!sourceId) throw new Error('The uploaded driver specification did not return a source ID')

  const deviceName = options.deviceName || file.name.replace(/\.[^.]+$/, '')
  return apiGenerateDriver({
    prompt: options.requirements || `Generate a portable driver for ${deviceName}.`,
    module_config: {
      module_type: 'driver',
      module_name: deviceName,
      device_name: deviceName,
      interface: options.interface || 'i2c',
      mcu_family: options.mcuFamily || null,
      platform: options.platform || 'stm32',
    },
    source_ids: [sourceId],
    output_options: { include_tests: false, include_config: true },
  })
}

// ==================== Task Polling ====================

/**
 * Get current state of a driver task (for progress polling).
 * @param {string} taskId
 * @returns {Promise<{id: string, status: string, current_step: string|null,
 *                    last_error: string|null, state_data: object|null, ...}>}
 */
export async function apiGetDriverTask(taskId) {
  return http.get(`/v1/driver/tasks/${encodeURIComponent(taskId)}`)
}

/**
 * Poll task progress in real-time (follows unittest.js pattern).
 * Call GET /v1/driver/tasks/:id every intervalMs to get node status
 *
 * @param {string}   taskId
 * @param {function} onData  - Callback (data) => void
 * @returns {function} Cleanup function to stop polling
 */
export function apiPollDriverTask(taskId, onData) {
  let timer = null
  let deadline = null
  let stopped = false
  let controller = null
  let consecutiveMissingTaskPolls = 0
  let consecutiveTransientErrors = 0

  const emitData = async (data) => {
    if (stopped || !onData) return
    try {
      await onData(data)
    } catch (cbErr) {
      console.error('onData callback error:', cbErr)
    }
  }

  const unavailable = async (error, status = 'polling_unavailable') => {
    await emitData({ status, error, retrying: false })
    stopped = true
  }

  const poll = async () => {
    if (stopped) return
    timer = null
    controller = new AbortController()
    const requestController = controller
    deadline = setTimeout(() => requestController.abort(), DRIVER_TASK_POLL_TIMEOUT_MS)
    let nextPollDelay = DRIVER_TASK_POLL_INTERVAL_MS
    try {
      const data = await http.get(`/v1/driver/tasks/${encodeURIComponent(taskId)}`, {
        signal: requestController.signal,
      })
      clearTimeout(deadline)
      if (stopped) return
      consecutiveTransientErrors = 0
      if (data?.state_data?.task_registration_pending) {
        consecutiveMissingTaskPolls++
        if (consecutiveMissingTaskPolls >= DRIVER_TASK_MAX_MISSING_POLLS) {
          nextPollDelay = DRIVER_TASK_MAX_RETRY_DELAY_MS
          await emitData({
            status: 'polling_retry', retrying: true,
            error: 'Task registration is still pending. Monitoring will continue.',
          })
        }
      } else {
        consecutiveMissingTaskPolls = 0
        await emitData(data)
        if (['completed', 'failed', 'cancelled'].includes(data.status)) stopped = true
      }
    } catch (err) {
      clearTimeout(deadline)
      if (stopped) return
      if ([401, 403].includes(err.status) || err.message?.includes('AWS_AUTH_REQUIRED')) {
        await unavailable('Authentication or access is required to monitor this task.', 'auth_required')
      } else if (err.status === 404) {
        consecutiveTransientErrors = 0
        consecutiveMissingTaskPolls++
        if (consecutiveMissingTaskPolls >= DRIVER_TASK_MAX_MISSING_POLLS) {
          await unavailable(
            'This task is not accessible in the current browser session. ' +
            'The backend may still be running or already completed. Restore the ' +
            'original guest session or login, then reconnect monitoring.'
          )
        } else {
          await emitData({
            status: 'polling_retry',
            retrying: true,
            retry_count: consecutiveMissingTaskPolls,
            error: 'Task status is temporarily unavailable (404). Retrying lookup; this is not a generation failure.',
          })
        }
      } else if (isTransientDriverError(err)) {
        consecutiveMissingTaskPolls = 0
        consecutiveTransientErrors++
        nextPollDelay = getPollRetryDelay(consecutiveTransientErrors)
        await emitData({
          status: 'polling_retry', retrying: true,
          retry_count: consecutiveTransientErrors, retry_delay_ms: nextPollDelay,
          error: `Connection interrupted. The task may still be running. Retrying in ${nextPollDelay / 1000}s.`,
        })
      } else {
        await unavailable('Task monitoring stopped after a request error. Reconnect to check the backend state.')
      }
    } finally {
      clearTimeout(deadline)
      controller = null
    }
    if (!stopped) timer = setTimeout(poll, nextPollDelay)
  }

  poll()
  return () => {
    stopped = true
    clearTimeout(timer)
    clearTimeout(deadline)
    timer = null
    controller?.abort()
  }
}

/**
 * Cancel a running driver task.
 * @param {string} taskId
 */
export async function apiCancelDriverTask(taskId) {
  return http.post(`/v1/driver/tasks/${encodeURIComponent(taskId)}/cancel`, {})
}

// ==================== Artifacts ====================

/**
 * Get generated code artifacts for a completed driver task.
 * @param {string} taskId
 * @returns {Promise<{task_id: string, artifacts: Array<{artifact_id, name, artifact_type, content, language, size}>}>}
 */
export async function apiGetDriverArtifacts(taskId) {
  return http.get(`/v1/driver/tasks/${encodeURIComponent(taskId)}/artifacts`)
}

// ==================== Chat ====================

/**
 * Send a conversational message to the driver agent (multi-turn).
 * @param {{session_id?: string|null, task_id?: string|null, message: string,
 *          target_file?: string, project_root?: string}} payload
 * @returns {Promise<{session_id: string, task_id: string, reply: string, task_state: object}>}
 */
export async function apiDriverChat(payload) {
  return http.post('/v1/driver/chat', payload)
}

/**
 * Get messages for a driver agent session.
 * @param {string} sessionId
 */
export async function apiGetDriverSessionMessages(sessionId) {
  return http.get(`/v1/driver/sessions/${encodeURIComponent(sessionId)}/messages`)
}

// ==================== Build Config ====================

/**
 * Get saved driver build configuration.
 * @returns {Promise<{
 *   platform: string,
 *   selected_platform: string,
 *   stm32cubeide_path: string,
 *   project_path: string,
 *   platform_configs: Record<string, object>,
 *   updated_at: string|null
 * }>}
 */
export async function apiGetDriverBuildConfig() {
  return http.get('/v1/driver/build-config')
}

/**
 * Save driver build configuration.
 * @param {{platform: string, editor_path: string, stm32cubeide_path: string, project_path: string}} config
 * @returns {Promise<{platform: string, editor_path: string, stm32cubeide_path: string, project_path: string, updated_at: string}>}
 */
export async function apiSaveDriverBuildConfig(config) {
  // The backend build-config endpoint currently accepts multipart Form fields.
  const formData = new FormData()
  const platform = config.platform || 'stm32'
  const isStm32 = platform === 'stm32'
  formData.append('platform', platform)
  formData.append('editor_path', config.editor_path || config.stm32cubeide_path || '')
  formData.append('stm32cubeide_path', isStm32 ? config.stm32cubeide_path || config.editor_path || '' : '')
  formData.append('project_path', config.project_path || '')
  return http.upload('/v1/driver/build-config', formData)
}
