import { http } from './http.js'

const base = '/v1/event-center'
export const getEventCatalog = () => http.get(`${base}/catalog`)
export const getEventRouting = () => http.get(`${base}/routing`)
export const saveEventRouting = policy => http.put(`${base}/routing`, policy)
export const previewEvent = body => http.post(`${base}/preview`, body)
export const submitEvent = body => http.post(`${base}/events`, body)
export const listEvents = (offset = 0) => http.get(`${base}/events?limit=25&offset=${offset}`)
export const getEvent = id => http.get(`${base}/events/${encodeURIComponent(id)}`)
export const listEventSources = () => http.get(`${base}/sources`)
export const createEventSource = name => http.post(`${base}/sources`, { name })
export const setEventSourceEnabled = (id, enabled) =>
  http.put(`${base}/sources/${encodeURIComponent(id)}`, { enabled })
export const rotateEventSource = id => http.post(`${base}/sources/${encodeURIComponent(id)}/rotate`)
export const deleteEventSource = id => http.delete(`${base}/sources/${encodeURIComponent(id)}`)
