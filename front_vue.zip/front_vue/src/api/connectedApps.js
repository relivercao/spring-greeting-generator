import { http } from './http.js'

export function getConnectedApps() {
  return http.get('/v1/connected-apps')
}

export function createConnectedAppLink(appSlug, returnPath) {
  return http.post(`/v1/connected-apps/${encodeURIComponent(appSlug)}/connect`, {
    return_path: returnPath,
  })
}

export function disconnectConnectedApp(appSlug) {
  return http.delete(`/v1/connected-apps/${encodeURIComponent(appSlug)}`)
}

export function getAppConnectionProvider() {
  return http.get('/v1/connected-apps/provider')
}

export function saveAppConnectionProvider(configuration) {
  return http.put('/v1/connected-apps/provider', configuration)
}
