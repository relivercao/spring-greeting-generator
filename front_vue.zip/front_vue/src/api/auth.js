import { http } from './http.js'
import { loadWebSearchPreference } from '../utils/chatPreferences.js'

/** Decode username from JWT payload without verifying signature */
function decodeToken(token) {
  try {
    return JSON.parse(atob(token.split('.')[1]))
  } catch {
    return {}
  }
}

export async function apiLogin(username, password) {
  const data = await http.post('/v1/auth/login', { username, password })
  const payload = decodeToken(data.access_token)
  // Backend JWT payload stores username in the sub field
  return { ...data, username: payload.sub || username }
}

/**
 * Register a new account.
 * `options` may carry the optional registration extras (both snake_case and
 * camelCase keys are accepted): email_code, invite_code, promo_code.
 */
export function apiRegister(username, email, password, options = {}) {
  const emailCode  = options.email_code ?? options.emailCode
  const inviteCode = options.invite_code ?? options.inviteCode
  const promoCode  = options.promo_code ?? options.promoCode

  const payload = { username, email, password }
  if (emailCode)  payload.email_code  = emailCode
  if (inviteCode) payload.invite_code = inviteCode
  if (promoCode)  payload.promo_code  = promoCode
  return http.post('/v1/auth/register', payload)
}

/** Request a verification code email for registration */
export function apiSendEmailCode(email) {
  return http.post('/v1/auth/email/send-code', { email })
}

/** Get registration toggles: registration_enabled / email_verify_enabled / invite_required */
export function apiGetRegistrationOptions() {
  return http.get('/v1/auth/registration-options')
}

/** Get the full profile of the logged-in user (incl. balance) */
export function apiGetProfile() {
  return http.get('/v1/auth/me')
}

export function apiSendMessage(agentId, message, sessionId, webSearchEnabled = loadWebSearchPreference(), files = []) {
  if (files.length) {
    const formData = new FormData()
    formData.append('agent', agentId)
    formData.append('message', message)
    formData.append('session_id', sessionId || '')
    files.forEach(file => formData.append('files', file, file.name))
    return http.upload('/v1/chat/with-files', formData)
  }
  return http.post('/v1/chat', {
    agent: agentId,
    message,
    session_id: sessionId,
    web_search_enabled: Boolean(webSearchEnabled),
  })
}
