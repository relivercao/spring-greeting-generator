import { http } from './http.js'
import { pollAgentTask } from './agentTaskPoller.js'

export function getBugFixIntegrations() {
  return http.get('/v1/bugfix/integrations')
}

export function apiGetJiraBugs(project) {
  return http.get(`/v1/bugfix/jira/bugs?project=${encodeURIComponent(project)}`)
}

export function apiGetJiraBug(issueKey) {
  return http.get(`/v1/bugfix/jira/issues/${encodeURIComponent(issueKey)}`)
}

export function apiCreateBugFixTask(payload) {
  return http.post('/v1/bugfix', payload)
}

export function apiPollBugFixTask(taskId, onData) {
  return pollAgentTask(() => http.get(`/v1/bugfix/tasks/${taskId}`), onData)
}

export function apiCancelBugFixTask(taskId) {
  return http.post(`/v1/bugfix/tasks/${taskId}/cancel`, {})
}

export function apiGetBugFixTask(taskId) {
  return http.get(`/v1/bugfix/tasks/${encodeURIComponent(taskId)}`)
}

export function apiCreateBugFixBatch(items) {
  return http.post('/v1/bugfix/batch-tasks', { items })
}

export function apiListBugFixBatches() {
  return http.get('/v1/bugfix/batch-tasks')
}

export function apiGetBugFixBatch(taskId) {
  return http.get(`/v1/bugfix/batch-tasks/${encodeURIComponent(taskId)}`)
}

export function apiPollBugFixBatch(taskId, onData) {
  return pollAgentTask(() => apiGetBugFixBatch(taskId), onData)
}

export function apiCancelBugFixBatch(taskId) {
  return http.post(`/v1/bugfix/batch-tasks/${encodeURIComponent(taskId)}/cancel`, {})
}
