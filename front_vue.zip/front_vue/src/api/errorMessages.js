const RATE_LIMIT_PATTERN = /(?:\b429\b|rate[ -]?limit|too many requests|cooling down|all .* accounts .* cool)/i
const SERVICE_UNAVAILABLE_PATTERN = /(?:service unavailable|upstream|provider unavailable|temporarily unavailable|connection (?:failed|reset)|timeout|cli.*not available)/i

const DEFAULT_CHAT_ERROR = 'The AI assistant could not complete your request. Please try again later.'
const RATE_LIMIT_CHAT_ERROR = 'The configured LLM provider is temporarily rate-limited because all upstream accounts are cooling down. Please retry later or select another configured provider.'
const SERVICE_CHAT_ERROR = 'The configured LLM service is temporarily unavailable. Please retry later or select another configured provider.'
const PROCESSING_CHAT_ERROR = 'The AI service failed to process your request. Please retry later or select another configured provider.'
export const EMPTY_CHAT_RESPONSE_MESSAGE = 'The configured LLM returned an empty response. Please retry or select another configured provider.'

/**
 * Convert an HTTP/LLM failure into a useful, safe message for the chat UI.
 * Provider internals are intentionally not rendered when they are unavailable.
 */
export function getChatErrorMessage(error) {
  const status = Number(error?.status)
  const rawMessage = typeof error?.message === 'string' ? error.message.trim() : ''
  const message = rawMessage.toLowerCase()

  if (status === 429 || RATE_LIMIT_PATTERN.test(rawMessage)) {
    return RATE_LIMIT_CHAT_ERROR
  }

  if (
    [502, 503, 504].includes(status)
    || SERVICE_UNAVAILABLE_PATTERN.test(rawMessage)
  ) {
    return SERVICE_CHAT_ERROR
  }

  if (status >= 500 || message.includes('task execution failed')) {
    return PROCESSING_CHAT_ERROR
  }

  if (rawMessage && /^[\x20-\x7E]+$/.test(rawMessage) && !/^request failed \(\d+\)$/i.test(rawMessage)) {
    return rawMessage
  }

  return DEFAULT_CHAT_ERROR
}
