/**
 * Admin API (requires an admin account)
 * - Payment config, orders (cancel / refund / retry), plans, providers
 * - User management and redeem codes
 */

import { http } from './http.js'

/** Append defined params as a query string to a path */
function withQuery(path, params = {}) {
  const query = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join('&')
  return query ? `${path}?${query}` : path
}

// ── Payment config ──────────────────────────────────────────────────────────

export function apiAdminGetConfig() {
  return http.get('/v1/admin/payment/config')
}

export function apiAdminUpdateConfig(data) {
  return http.put('/v1/admin/payment/config', data)
}

// ── Orders ──────────────────────────────────────────────────────────────────

/** List all orders (paged; optional filters) */
export function apiAdminOrders(params = {}) {
  return http.get(withQuery('/v1/admin/payment/orders', params))
}

export function apiAdminOrderDetail(id) {
  return http.get(`/v1/admin/payment/orders/${encodeURIComponent(id)}`)
}

export function apiAdminCancelOrder(id) {
  return http.post(`/v1/admin/payment/orders/${encodeURIComponent(id)}/cancel`)
}

export function apiAdminRefundOrder(id, { reason } = {}) {
  return http.post(`/v1/admin/payment/orders/${encodeURIComponent(id)}/refund`, { reason })
}

export function apiAdminRetryOrder(id) {
  return http.post(`/v1/admin/payment/orders/${encodeURIComponent(id)}/retry`)
}

// ── Recharge plans ──────────────────────────────────────────────────────────

export function apiAdminListPlans() {
  return http.get('/v1/admin/payment/plans')
}

export function apiAdminCreatePlan(data) {
  return http.post('/v1/admin/payment/plans', data)
}

export function apiAdminUpdatePlan(id, data) {
  return http.put(`/v1/admin/payment/plans/${encodeURIComponent(id)}`, data)
}

export function apiAdminDeletePlan(id) {
  return http.delete(`/v1/admin/payment/plans/${encodeURIComponent(id)}`)
}

// ── Payment provider instances (EasyPay) ────────────────────────────────────

export function apiAdminListProviders() {
  return http.get('/v1/admin/payment/providers')
}

export function apiAdminCreateProvider(data) {
  return http.post('/v1/admin/payment/providers', data)
}

export function apiAdminUpdateProvider(id, data) {
  return http.put(`/v1/admin/payment/providers/${encodeURIComponent(id)}`, data)
}

export function apiAdminDeleteProvider(id) {
  return http.delete(`/v1/admin/payment/providers/${encodeURIComponent(id)}`)
}

/** Run a connectivity test against the provider endpoint */
export function apiAdminTestProvider(id) {
  return http.post(`/v1/admin/payment/providers/${encodeURIComponent(id)}/test`)
}

// ── Users ───────────────────────────────────────────────────────────────────

/** List users (paged; optional filters) */
export function apiAdminUsers(params = {}) {
  return http.get(withQuery('/v1/admin/users', params))
}

/** Adjust a user's balance (signed amount + reason) */
export function apiAdminAdjustBalance(id, { amount, reason } = {}) {
  return http.post(`/v1/admin/users/${encodeURIComponent(id)}/balance`, { amount, reason })
}

export function apiAdminSetUserStatus(id, { is_active } = {}) {
  return http.post(`/v1/admin/users/${encodeURIComponent(id)}/status`, { is_active })
}

export function apiAdminSetAdmin(id, { is_admin } = {}) {
  return http.post(`/v1/admin/users/${encodeURIComponent(id)}/admin`, { is_admin })
}

/**
 * Set a user's membership level.
 * Pass { level: 'gold', manual: true } to pin, or { level: '' } to reset
 * the tier to automatic (recomputed from cumulative recharge).
 */
export function apiAdminSetUserLevel(id, { level = '', manual = true } = {}) {
  return http.post(`/v1/admin/users/${encodeURIComponent(id)}/level`, { level, manual })
}

export function apiAdminUserTransactions(id, params = {}) {
  return http.get(withQuery(`/v1/admin/users/${encodeURIComponent(id)}/transactions`, params))
}

// ── Redeem codes (invitation / promo) ───────────────────────────────────────

export function apiAdminListRedeemCodes(params = {}) {
  return http.get(withQuery('/v1/admin/redeem-codes', params))
}

export function apiAdminCreateRedeemCodes(payload) {
  return http.post('/v1/admin/redeem-codes', payload)
}
