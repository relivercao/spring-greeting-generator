import { http } from './http.js'

const BASE_URL = import.meta.env.VITE_API_URL || '/api'

export function getCadStatus() {
  return http.get('/v1/cad/status')
}

export function getCadTasks() {
  return http.get('/v1/cad/tasks?limit=50&offset=0')
}

export function getCadTask(taskId) {
  return http.get(`/v1/cad/tasks/${encodeURIComponent(taskId)}`)
}

export function createCadTask(payload) {
  return http.post('/v1/cad/tasks', payload)
}

export function startCadBuild(taskId) {
  return http.post(`/v1/cad/tasks/${encodeURIComponent(taskId)}/build`, {})
}

export function repairCadModelScript(taskId) {
  return http.post(`/v1/cad/tasks/${encodeURIComponent(taskId)}/repair`, {})
}

export function cancelCadTask(taskId) {
  return http.post(`/v1/cad/tasks/${encodeURIComponent(taskId)}/cancel`, {})
}

export async function fetchCadArtifact(taskId, artifactType) {
  const token = localStorage.getItem('token')
  const response = await fetch(
    `${BASE_URL}/v1/cad/tasks/${encodeURIComponent(taskId)}/artifacts/${encodeURIComponent(artifactType)}`,
    { headers: token ? { Authorization: `Bearer ${token}` } : {} },
  )
  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error(body.detail || `Artifact request failed (${response.status})`)
  }
  return response.blob()
}
