import { http } from './http.js'
import { pollAgentTask } from './agentTaskPoller.js'

export function getReviewIntegrations() {
  return http.get('/v1/review/integrations')
}

export async function apiCreateReviewTask(files, options = {}) {
  const form = new globalThis.FormData()
  for (const file of files) form.append('files', file, file.name || 'source.c')
  form.append('review_type', options.reviewType || 'full')
  form.append('standards_json', JSON.stringify(options.standards || ['MISRA-C:2012']))
  if (options.focus) form.append('focus', options.focus)
  form.append('require_approval', options.requireApproval ? 'true' : 'false')
  form.append('approval_channels_json', JSON.stringify(options.approvalChannels || []))
  form.append('approval_recipients_json', JSON.stringify(options.approvalRecipients || []))
  if (options.gitRepositoryPath) form.append('git_repository_path', options.gitRepositoryPath)
  form.append('git_base_ref', options.gitBaseRef || 'HEAD~1')
  form.append('git_target_ref', options.gitTargetRef || 'WORKTREE')
  form.append('git_include_untracked', options.gitIncludeUntracked === false ? 'false' : 'true')
  if (options.bitbucketRepo) form.append('repo', options.bitbucketRepo)
  if (options.bitbucketPrId) form.append('pr_id', String(options.bitbucketPrId))
  if (options.jiraProject) form.append('jira_project', options.jiraProject)
  if (options.jiraJql) form.append('jira_jql', options.jiraJql)
  form.append('jira_issue_keys_json', JSON.stringify(options.jiraIssueKeys || []))
  if (options.jiraStatus) form.append('jira_status', options.jiraStatus)
  form.append('jira_max_results', String(options.jiraMaxResults || 20))
  return http.upload('/v1/review/tasks', form)
}

export function apiPollReviewTask(taskId, onData) {
  return pollAgentTask(() => http.get(`/v1/review/tasks/${taskId}`), onData)
}

export async function apiCancelReviewTask(taskId) {
  return http.post(`/v1/review/tasks/${taskId}/cancel`, {})
}

export async function apiApproveReviewTask(taskId, decision, token, comment = '') {
  return http.post('/v1/review/tasks/' + taskId + '/approval', { decision, token, comment })
}
