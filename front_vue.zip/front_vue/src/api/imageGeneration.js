import { http } from './http.js'

export function createImageGenerationTask(payload) {
  const form = new FormData()
  form.append('prompt', payload.prompt)
  form.append('size', payload.size)
  form.append('quality', payload.quality)
  form.append('output_format', payload.outputFormat)
  form.append('moderation', payload.moderation)
  form.append('image_count', String(payload.imageCount))
  form.append('transparent_output', String(payload.transparentOutput))
  form.append('enhance_prompt', String(payload.enhancePrompt))
  for (const documentId of payload.knowledgeDocumentIds || []) {
    if (documentId) form.append('knowledge_document_ids', String(documentId))
  }
  if (payload.outputCompression !== null && payload.outputCompression !== undefined && payload.outputFormat !== 'png') {
    form.append('output_compression', String(payload.outputCompression))
  }
  for (const image of payload.referenceImages || []) {
    form.append('reference_images', image.file, image.file.name)
  }
  if (payload.maskFile) {
    form.append('mask', payload.maskFile, 'mask.png')
  }
  return http.upload('/v1/image-generation/tasks', form)
}

export function getImageGenerationTasks(params = {}) {
  const query = new URLSearchParams()
  if (params.status) query.set('status', params.status)
  query.set('limit', String(params.limit || 50))
  query.set('offset', String(params.offset || 0))
  return http.get(`/v1/image-generation/tasks?${query.toString()}`)
}

export function getImageGenerationTask(taskId) {
  return http.get(`/v1/image-generation/tasks/${taskId}`)
}

export function cancelImageGenerationTask(taskId) {
  return http.post(`/v1/image-generation/tasks/${taskId}/cancel`)
}

export function deleteImageGenerationTask(taskId) {
  return http.delete(`/v1/image-generation/tasks/${taskId}`)
}

export function getImageGenerationSettings() {
  return http.get('/v1/settings/image-generation')
}

export function updateImageGenerationSettings(settings) {
  return http.put('/v1/settings/image-generation', settings)
}
