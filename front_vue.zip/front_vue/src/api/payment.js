/**
 * Payment API (user side)
 * - Recharge plans and order lifecycle
 * - Paged lists use the envelope { items, total, page, page_size }
 */

import { http } from './http.js'

/** Append defined params as a query string to a path */
function withQuery(path, params = {}) {
  const query = Object.entries(params)
    .filter(([, value]) => value !== undefined && value !== null && value !== '')
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join('&')
  return query ? `${path}?${query}` : path
}

/** List recharge plans plus recharge limits and available payment methods */
export function apiGetPlans() {
  return http.get('/v1/payment/plans')
}

/**
 * Create a payment order.
 * `payload` carries either { plan_id, payment_type } or { amount, payment_type }.
 * Returns the created order incl. id / out_trade_no / pay_url / qr_code /
 * pay_mode / expires_at / amount / status.
 */
export function apiCreateOrder(payload) {
  return http.post('/v1/payment/orders', payload)
}

/** List the current user's orders (paged; optional status filter) */
export function apiMyOrders(params = {}) {
  return http.get(withQuery('/v1/payment/orders', params))
}

/** Get one order by id (also used to poll payment status) */
export function apiOrderDetail(orderId) {
  return http.get(`/v1/payment/orders/${encodeURIComponent(orderId)}`)
}

/** Cancel a pending order */
export function apiCancelOrder(orderId) {
  return http.post(`/v1/payment/orders/${encodeURIComponent(orderId)}/cancel`)
}

/** List the current user's balance transactions (paged) */
export function apiGetTransactions(params = {}) {
  return http.get(withQuery('/v1/payment/transactions', params))
}
