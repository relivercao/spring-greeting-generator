import { http } from './http.js'

function query(path, params = {}) {
  const values = Object.entries(params).filter(
    ([, value]) => value !== '' && value !== null && value !== undefined
  )
  const encoded = new URLSearchParams(values).toString()
  return encoded ? `${path}?${encoded}` : path
}

export const getModelCatalog = () => http.get('/v1/models')
export const listModels = (keyword = '') => http.get(query('/v1/admin/models', { keyword }))
export const createModel = data => http.post('/v1/admin/models', data)
export const updateModel = (id, data) =>
  http.put(`/v1/admin/models/${encodeURIComponent(id)}`, data)
export const deleteModel = id => http.delete(`/v1/admin/models/${encodeURIComponent(id)}`)
export const importModels = data => http.post('/v1/admin/models/import', data)
export const discoverModels = () => http.post('/v1/admin/models/discover', {})
export const getDefaultPricing = () => http.get('/v1/admin/models/defaults')
export const updateDefaultPricing = data => http.put('/v1/admin/models/defaults', data)
export const getUsage = (params, admin = false) =>
  http.get(query(admin ? '/v1/admin/usage' : '/v1/usage', params))
export const getUsageDetail = (id, admin = false) =>
  http.get(`${admin ? '/v1/admin/usage' : '/v1/usage'}/${encodeURIComponent(id)}`)
