export function pollAgentTask(fetchTask, onData) {
  let timer = null
  let stopped = false
  let polling = false
  let consecutiveErrors = 0

  const poll = async () => {
    if (stopped || polling) return
    timer = null
    polling = true
    try {
      const data = await fetchTask()
      if (stopped) return
      consecutiveErrors = 0
      onData?.(data)
      if (['completed', 'failed', 'cancelled'].includes(data.status)) {
        stopped = true
        return
      }
    } catch (error) {
      if (stopped) return
      consecutiveErrors += 1
      const status = Number(error?.status || 0)
      const permanent = status === 400 || status === 401 || status === 403 || status === 404
      if (permanent) {
        stopped = true
        onData?.({ status: 'failed', progress: 0, error: error.message || 'Task polling failed' })
        return
      }
      onData?.({
        status: 'running',
        progress: undefined,
        message: 'Connection interrupted; retrying (attempt ' + consecutiveErrors + ')',
        error: error.message || 'Task polling temporarily unavailable',
      })
    } finally {
      polling = false
    }
    const delay = Math.min(10000, 1500 * (2 ** Math.min(consecutiveErrors, 3)))
    if (!stopped) timer = globalThis.setTimeout(poll, consecutiveErrors ? delay : 1500)
  }

  poll()
  return () => {
    stopped = true
    if (timer) globalThis.clearTimeout(timer)
  }
}
