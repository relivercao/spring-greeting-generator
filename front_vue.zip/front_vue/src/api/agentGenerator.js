import { http } from './http.js'

export function listGeneratedAgents() {
  return http.get('/v1/agent-generator/agents')
}

export function listGeneratorKnowledgeDocuments() {
  return http.get('/v1/agent-generator/knowledge-documents')
}

export function listAgentGeneratorTools() {
  return http.get('/v1/agent-generator/tools')
}

export function getCodeParserStatus() {
  return http.get('/v1/agent-generator/code-parser/status')
}

export function generateAgent(payload) {
  return http.post('/v1/agent-generator/generate', {
    name: payload.name || '',
    goal: payload.goal || '',
    prompt: payload.prompt,
    icon: payload.icon || 'MagicStick',
    color: payload.color || '#2563eb',
    logo_url: payload.logoUrl || '',
    knowledge_document_ids: payload.knowledgeDocumentIds || [],
    input_files: payload.inputFiles || [],
    input_definitions: (payload.inputDefinitions || []).map((input) => ({
      id: String(input.id || '').trim(),
      label: String(input.label || input.id || '').trim(),
      type: input.type || 'text',
      required: input.required === true,
      placeholder: String(input.placeholder || ''),
      default: input.default === '' ? null : (input.default ?? null),
      options: String(input.optionsText || '').split(',').map((item) => item.trim()).filter(Boolean),
    })),
    skill_files: payload.skillFiles || [],
    market_skill_names: payload.marketSkillNames || [],
    selected_tools: payload.selectedTools || [],
    flow_nodes: (payload.flowNodes || []).map((node) => ({
      id: node.id,
      label: node.label,
      description: node.description || '',
      kind: node.kind || 'task',
      approval_channels: node.approvalChannels || node.approval_channels || [],
      approval_recipients: Array.isArray(node.approvalRecipients)
        ? node.approvalRecipients
        : String(node.approvalRecipients || '').split(',').map((item) => item.trim()).filter(Boolean),
      approval_required: node.approvalRequired ?? node.approval_required,
    })),
    llm_provider: payload.llmProvider || 'macode',
    llm_model: payload.llmModel || '',
    output_mode: payload.outputMode || 'text',
    output_format: payload.outputFormat || 'markdown',
    output_filename: payload.outputFilename || '',
  })
}

export function generateAgentSkillDraft(payload) {
  return http.post('/v1/agent-generator/skill-drafts', {
    name: payload.name,
    goal: payload.goal,
    agent_name: payload.agentName || '',
    agent_goal: payload.agentGoal || '',
    agent_prompt: payload.agentPrompt || '',
    llm_provider: payload.llmProvider || 'macode',
    llm_model: payload.llmModel || '',
  })
}

export function uploadAgentInputFile(file) {
  const form = new globalThis.FormData()
  form.append('file', file)
  return http.upload('/v1/agent-generator/input-files', form)
}

export function uploadAgentSkillFile(file) {
  const form = new globalThis.FormData()
  form.append('file', file)
  return http.upload('/v1/agent-generator/skill-files', form)
}

export function uploadAgentLogo(file) {
  const form = new globalThis.FormData()
  form.append('file', file)
  return http.upload('/v1/agent-generator/logos', form)
}

export function chatWithGeneratedAgent(agentId, payload) {
  return http.post('/v1/agent-generator/agents/' + encodeURIComponent(agentId) + '/chat', {
    message: payload.message,
    history: payload.history || [],
    inputs: payload.inputs || {},
  })
}

export function getGeneratedAgentTask(taskId) {
  return http.get('/v1/agent-generator/tasks/' + encodeURIComponent(taskId))
}

export function approveGeneratedAgentTask(taskId, decision, token, comment = '') {
  return http.post('/v1/agent-generator/tasks/' + encodeURIComponent(taskId) + '/approval', {
    decision,
    token,
    comment,
  })
}

export function deleteGeneratedAgent(agentId) {
  return http.delete('/v1/agent-generator/agents/' + encodeURIComponent(agentId))
}
