import { http } from './http.js'

export function getIntegrationNotifications(maxResults = 20) {
  return http.get(`/v1/notifications/integration-updates?max_results=${encodeURIComponent(maxResults)}`)
}
