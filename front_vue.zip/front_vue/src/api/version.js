import { http } from './http.js'

export function checkForVersionUpdate() {
  return http.get('/v1/version', { skipAuth: true })
}

export function adminListVersionReleases() {
  return http.get('/v1/admin/version')
}

export function adminPublishVersionRelease(payload) {
  return http.post('/v1/admin/version/releases', payload)
}

export function adminDeleteVersionRelease(version) {
  return http.delete(`/v1/admin/version/releases/${encodeURIComponent(version)}`)
}
