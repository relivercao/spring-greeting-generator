/**
 * Unified HTTP request layer
 * - Automatically attaches the Authorization token
 * - Normalizes error format
 * - Automatically clears auth state on 401 and redirects to login
 */

const BASE_URL = import.meta.env.VITE_API_URL || '/api'
let refreshRequest = null

class HttpError extends Error {
  constructor(message, status, details = null) {
    super(message)
    this.name = 'HttpError'
    this.status = status
    this.details = details
  }
}

function formatErrorDetail(detail) {
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) {
    return detail
      .map((item) => {
        if (typeof item === 'string') return item
        if (item && typeof item.msg === 'string') return item.msg
        return ''
      })
      .filter(Boolean)
      .join('; ')
  }
  if (detail && typeof detail === 'object') {
    if (typeof detail.message === 'string') return detail.message
    if (typeof detail.error === 'string') return detail.error
  }
  return ''
}

function clearAuthentication() {
  const hadSession = localStorage.getItem('token') || localStorage.getItem('refresh_token') || localStorage.getItem('guest')
  if (!hadSession) return
  localStorage.removeItem('token')
  localStorage.removeItem('refresh_token')
  localStorage.removeItem('user')
  localStorage.removeItem('guest')
  window.dispatchEvent(new CustomEvent('auth:logout'))
}

async function refreshAccessToken() {
  const refreshToken = localStorage.getItem('refresh_token')
  if (!refreshToken) return null

  if (!refreshRequest) {
    refreshRequest = fetch(`${BASE_URL}/v1/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken }),
    })
      .then(async (response) => {
        if (!response.ok) return null
        const data = await response.json().catch(() => ({}))
        if (typeof data.access_token !== 'string' || !data.access_token) return null
        if (localStorage.getItem('refresh_token') !== refreshToken) return null
        localStorage.setItem('token', data.access_token)
        return data.access_token
      })
      .catch(() => null)
      .finally(() => {
        refreshRequest = null
      })
  }

  return refreshRequest
}

async function request(path, options = {}, canRefresh = true) {
  const skipAuth = options.skipAuth === true
  const fetchOptions = { ...options }
  delete fetchOptions.skipAuth
  const token = skipAuth ? '' : localStorage.getItem('token')

  // FormData uploads do not need Content-Type; let the browser handle the boundary automatically
  const isFormData = fetchOptions.body instanceof FormData
  const headers = {
    ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...fetchOptions.headers,
  }

  const res = await fetch(BASE_URL + path, {
    ...fetchOptions,
    headers,
  })

  // 204 No Content — no body
  if (res.status === 204) return null

  const data = await res.json().catch(() => ({}))

  if (!res.ok) {
    const contentType = res.headers?.get?.('content-type') || ''
    const structuredError = formatErrorDetail(data.detail)
      || formatErrorDetail(data.message)
    const uploadSizeError = res.status === 413
      ? 'The upload exceeds the server request size limit (HTTP 413). Upload fewer or smaller files and try again.'
      : ''
    const errorMessage = structuredError || uploadSizeError
      || (res.status >= 500 && !contentType.toLowerCase().includes('json')
        ? `The API proxy returned a non-JSON server error (HTTP ${res.status}). Check backend and proxy availability.`
        : `Request failed (${res.status})`)

    // Check if this is an AWS authentication error
    // Just throw the error and let the component show modal - don't auto-trigger SSO here
    if (res.status === 401 && errorMessage.includes('AWS_AUTH_REQUIRED')) {
      console.log('[http.js] AWS authentication error detected:', errorMessage)
      throw new HttpError(errorMessage, res.status, data)
    }

    const isAuthEndpoint = path === '/v1/auth/login' || path === '/v1/auth/refresh'
    if (res.status === 401 && !isAuthEndpoint && !skipAuth) {
      const currentToken = localStorage.getItem('token')
      const refreshToken = localStorage.getItem('refresh_token')
      const isGuest = localStorage.getItem('guest') === '1'

      if (token && currentToken === token && refreshToken && canRefresh) {
        const accessToken = await refreshAccessToken()
        if (accessToken) {
          return request(path, {
            ...options,
            headers: { ...options.headers, Authorization: `Bearer ${accessToken}` },
          }, false)
        }
        if (localStorage.getItem('token') === token && localStorage.getItem('refresh_token') === refreshToken) {
          clearAuthentication()
        }
      } else if (token && currentToken === token && !refreshToken) {
        clearAuthentication()
      } else if (!token && !currentToken && !isGuest) {
        clearAuthentication()
      }
    }

    throw new HttpError(errorMessage, res.status, data)
  }

  return data
}

export const http = {
  get: (path, options) => request(path, { method: 'GET', ...options }),
  post: (path, body, options) =>
    request(path, { method: 'POST', body: JSON.stringify(body), ...options }),
  put: (path, body, options) =>
    request(path, { method: 'PUT', body: JSON.stringify(body), ...options }),
  delete: (path, options) => request(path, { method: 'DELETE', ...options }),
  // multipart/form-data upload: do not set Content-Type so the browser can add the boundary automatically
  upload: (path, formData, options) =>
    request(path, {
      method: 'POST',
      body: formData,
      headers: { ...(options?.headers) }, // Do not pass Content-Type
      ...options,
    }),
}
