export function usageCsv(rows) {
  const columns = [
    'id',
    'created_at',
    'model',
    'provider',
    'agent_name',
    'workflow_id',
    'session_id',
    'prompt_tokens',
    'completion_tokens',
    'cache_read_tokens',
    'cache_write_tokens',
    'total_tokens',
    'latency_ms',
    'cost_usd',
    'charged_cny',
    'usage_source',
    'pricing_source',
    'status',
  ]
  const escape = value => {
    let text = String(value ?? '')
    if (/^[\s]*[=+\-@\t\r]/.test(text)) text = `'${text}`
    return `"${text.replaceAll('"', '""')}"`
  }
  return [
    columns.join(','),
    ...rows.map(row => columns.map(key => escape(row[key])).join(',')),
  ].join('\r\n')
}
