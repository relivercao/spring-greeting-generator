// This identity namespaces browser state only. The server validates authorization.
export function accountIdentity(auth) {
  if (!auth.token) return auth.isGuest ? 'guest' : ''
  try {
    const payload = auth.token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')
    const { sub } = JSON.parse(atob(payload))
    return typeof sub === 'string' && sub ? `user:${encodeURIComponent(sub)}` : ''
  } catch {
    return ''
  }
}
