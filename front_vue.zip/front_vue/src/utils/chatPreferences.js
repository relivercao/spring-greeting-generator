const WEB_SEARCH_PREFERENCE_KEY = 'macode.chat.web-search-enabled.v1'

export function loadWebSearchPreference() {
  try {
    return localStorage.getItem(WEB_SEARCH_PREFERENCE_KEY) !== 'false'
  } catch {
    return true
  }
}

export function saveWebSearchPreference(enabled) {
  try {
    localStorage.setItem(WEB_SEARCH_PREFERENCE_KEY, String(Boolean(enabled)))
  } catch (error) {
    console.warn('Could not save the web search preference:', error)
  }
}
