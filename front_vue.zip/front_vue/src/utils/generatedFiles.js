const ARTIFACT_PATH =
  /^\/api\/v\d+\/(?:chat\/artifacts\/[^/]+\/[^/]+\/[^/]+\/[^/]+|agent-generator\/agents\/[^/]+\/outputs\/[^/]+)$/
const MARKDOWN_LINK = /\[([^\]\r\n]+)\]\(([^\s)]+)\)/g

export function generatedFileUrl(value) {
  if (typeof value !== 'string' || /[\s\\<>"']/.test(value)) return ''
  const relative = value.startsWith('/') && !value.startsWith('//')
  try {
    const url = relative ? new URL(value, 'https://generated-files.invalid') : new URL(value)
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return ''
    if (!ARTIFACT_PATH.test(url.pathname)) return ''
    return relative ? `${url.pathname}${url.search}${url.hash}` : url.href
  } catch {
    return ''
  }
}

export function generatedFileDownloadUrl(value) {
  const safeUrl = generatedFileUrl(value)
  if (!safeUrl) return ''

  const relative = safeUrl.startsWith('/')
  const parsed = new URL(safeUrl, 'https://generated-files.invalid')
  if (/^\/api\/v\d+\/chat\/artifacts\//.test(parsed.pathname)) {
    parsed.searchParams.set('download', 'true')
  }
  return relative ? `${parsed.pathname}${parsed.search}${parsed.hash}` : parsed.href
}

function filenameFromUrl(url) {
  const path = url.split(/[?#]/)[0]
  const name = path.split('/').pop() || 'Generated file'
  try {
    return decodeURIComponent(name)
  } catch {
    return name
  }
}

export function generatedFiles(files = [], content = '') {
  const normalized = new Map()
  const add = file => {
    if (!file || typeof file !== 'object') return
    const url = generatedFileUrl(file.url || file.download_url)
    if (!url || normalized.has(url)) return
    const name = String(file.filename || file.name || filenameFromUrl(url))
    const size = file.size_bytes ?? file.size
    normalized.set(url, {
      url,
      downloadUrl: generatedFileDownloadUrl(url),
      name,
      path: String(file.path || file.repository_path || ''),
      extension: name.match(/\.([a-z0-9]{1,10})$/i)?.[1].toUpperCase() || 'FILE',
      size: typeof size === 'number' && Number.isFinite(size) && size >= 0 ? size : null,
    })
  }
  if (Array.isArray(files)) files.forEach(add)
  // Old messages may retain the signed link without structured file metadata.
  const prose = String(content).replace(/```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$)|`[^`\n]*`/g, '')
  for (const match of prose.matchAll(MARKDOWN_LINK)) {
    add({ url: match[2] })
  }
  return [...normalized.values()]
}

export function withoutGeneratedFileLines(content) {
  return String(content || '')
    .split(/(```[\s\S]*?(?:```|$)|~~~[\s\S]*?(?:~~~|$))/g)
    .map(part => {
      if (part.startsWith('```') || part.startsWith('~~~')) return part
      return part
        .split('\n')
        .filter(line => {
          const match = line
            .trim()
            .match(/^(?:Generated document:|Generated:)\s*\[([^\]]+)\]\(([^\s)]+)\)$/)
          return !match || !generatedFileUrl(match[2])
        })
        .join('\n')
    })
    .join('')
    .trim()
}

export function fileSizeLabel(size) {
  if (size === null) return ''
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}
