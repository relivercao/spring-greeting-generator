const LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '::1', '[::1]'])

export function isLocalFileSelectorHost(hostname) {
  return LOCAL_HOSTS.has(String(hostname || '').toLowerCase())
}

export function routeSourceFilePicker(hostname, localPicker, browserPicker) {
  return isLocalFileSelectorHost(hostname) ? localPicker() : browserPicker()
}
