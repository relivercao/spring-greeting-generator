export const ASSISTANT_COMPOSE_EVENT = 'assistant:compose'

export function composeGmailRequest() {
  window.dispatchEvent(
    new CustomEvent(ASSISTANT_COMPOSE_EVENT, {
      detail: { app: 'gmail', message: 'Read my unread Gmail messages and summarize them.' },
    })
  )
}
