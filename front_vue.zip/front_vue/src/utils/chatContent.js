import { generatedFileUrl } from './generatedFiles.js'

const DOCUMENT_EXTENSIONS = [
  'txt', 'md', 'markdown', 'doc', 'docx', 'html', 'htm',
  'xls', 'xlsx', 'csv', 'json', 'yaml', 'yml', 'pdf', 'ppt', 'pptx',
]

const DOCUMENT_PATH_PATTERN = new RegExp(
  String.raw`(?:[A-Za-z]:[\\/][^\s<>"']+|/(?:[^\s<>"']+/)+[^\s<>"']+\.(?:${DOCUMENT_EXTENSIONS.join('|')}))`,
  'gi',
)

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function trimPathPunctuation(value) {
  return value.replace(/[.,;:!?\])}]+$/g, '')
}

function documentPathHref(path) {
  const normalized = trimPathPunctuation(path).replace(/\\/g, '/')
  if (/^[A-Za-z]:\//.test(normalized)) {
    const drive = normalized.slice(0, 3)
    const segments = normalized.slice(3).split('/').map(encodeURIComponent)
    return `file:///${drive}${segments.join('/')}`
  }
  if (normalized.startsWith('/')) {
    return `file://${normalized.split('/').map(encodeURIComponent).join('/')}`
  }
  return normalized
}

function fileLink(label, path) {
  const cleanPath = trimPathPunctuation(path)
  const href = documentPathHref(cleanPath)
  return `<a class="chat-file-link" href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer" title="Open ${escapeHtml(cleanPath)}">${escapeHtml(label || cleanPath)}</a>`
}

function externalLink(label, href) {
  const safeHref = /^(?:https?:|mailto:)/i.test(href) || generatedFileUrl(href)
    ? href
    : '#'
  return `<a class="chat-link" href="${escapeHtml(safeHref)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label || href)}</a>`
}

function renderInline(text) {
  const linkTokens = []
  const token = (html) => {
    const index = linkTokens.length
    linkTokens.push(html)
    return `\uE001CHAT_LINK_${index}\uE001`
  }

  let value = String(text)
  value = value.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (match, label, target) => {
    if (/^(?:https?:|mailto:)/i.test(target) || generatedFileUrl(target)) {
      return token(externalLink(label, target))
    }
    const isDocumentPath = new RegExp(
      String.raw`^(?:[A-Za-z]:[\\/]|/(?!/))[^<>"\r\n]*\.(?:${DOCUMENT_EXTENSIONS.join('|')})$`, 'i',
    ).test(target)
    if (isDocumentPath) return token(fileLink(label, target))
    if (/^[A-Za-z][\w+.-]*:/.test(target) || target.startsWith('//')) return token(escapeHtml(match))
    return match
  })

  value = value.replace(/\bhttps?:\/\/[^\s<]+/gi, (match) => {
    const cleanUrl = trimPathPunctuation(match)
    const trailing = match.slice(cleanUrl.length)
    return token(externalLink(cleanUrl, cleanUrl)) + trailing
  })

  value = value.replace(/\/api\/v\d+\/(?:chat\/artifacts\/|agent-generator\/agents\/[^/\s]+\/outputs\/)[^\s<>"']+/g, (match) => {
    const cleanUrl = trimPathPunctuation(match)
    return token(externalLink(cleanUrl, cleanUrl)) + match.slice(cleanUrl.length)
  })

  DOCUMENT_PATH_PATTERN.lastIndex = 0
  value = value.replace(DOCUMENT_PATH_PATTERN, (match) => {
    const cleanPath = trimPathPunctuation(match)
    const trailing = match.slice(cleanPath.length)
    return token(fileLink(cleanPath, cleanPath)) + trailing
  })
  DOCUMENT_PATH_PATTERN.lastIndex = 0

  value = escapeHtml(value)
  value = value.replace(/`([^`]+?)`/g, '<code class="inline-code">$1</code>')
  value = value.replace(/^#{1,3} (.+)$/gm, '<div class="heading">$1</div>')
  value = value.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  value = value.replace(/^(\d+)\. (.+)$/gm, '<div class="list-item numbered"><span class="num">$1.</span>$2</div>')
  value = value.replace(/^[-*] (.+)$/gm, '<div class="list-item bullet">$1</div>')
  value = value.replace(/\uE001CHAT_LINK_(\d+)\uE001/g, (_, index) => linkTokens[Number(index)] || '')
  return value
}

/** Render assistant text as escaped HTML with document paths as context-menu links. */
export function renderChatContent(text, { includeCopyButton = false } = {}) {
  if (!text) return ''

  const codeBlocks = []
  const processed = String(text).replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
    const index = codeBlocks.length
    codeBlocks.push({ lang: lang || '', code: code.trim() })
    return `\uE000CODE_BLOCK_${index}\uE000`
  })

  let html = processed
    .split(/(\uE000CODE_BLOCK_\d+\uE000)/g)
    .map((part) => /^\uE000CODE_BLOCK_\d+\uE000$/.test(part) ? part : renderInline(part))
    .join('')

  html = html.replace(/\n/g, '<br>')

  return html.replace(/\uE000CODE_BLOCK_(\d+)\uE000/g, (match, indexText) => {
    const block = codeBlocks[Number(indexText)]
    if (!block) return match
    const langLabel = block.lang ? `<span class="code-lang">${escapeHtml(block.lang)}</span>` : ''
    const copyButton = includeCopyButton
      ? `<button class="copy-code-btn" type="button" title="Copy code"><span aria-hidden="true">&#x2398;</span></button>`
      : ''
    return `<div class="code-block">${langLabel}${copyButton}<pre><code>${escapeHtml(block.code)}</code></pre></div>`
  })
}

export { documentPathHref, trimPathPunctuation }
