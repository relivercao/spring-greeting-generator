<template>
  <RouterView v-slot="{ Component }">
    <component
      :is="Component"
      @login-success="onLoginSuccess"
      @logout="onLogout"
    />
  </RouterView>

  <VersionUpdateBanner />

  <!-- Global floating customer support widget -->
  <FloatChat />
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from './stores/auth.js'
import FloatChat from './components/FloatChat.vue'
import VersionUpdateBanner from './components/VersionUpdateBanner.vue'

const router    = useRouter()
const authStore = useAuthStore()

function onLoginSuccess() {
  router.push('/')
}

function onLogout() {
  authStore.logout()
  router.push('/login')
}
</script>

<style>
:root {
  font-family: Inter, "Segoe UI", Arial, sans-serif;
  font-size: 14px;
  --el-font-size-extra-large: 17px;
  --el-font-size-large: 15px;
  --el-font-size-medium: 14px;
  --el-font-size-base: 13px;
  --el-font-size-small: 12px;
  --el-component-size-large: 36px;
  --el-component-size: 30px;
  --el-component-size-small: 26px;
}

*,
*::before,
*::after {
  box-sizing: border-box;
}

html, body {
  height: 100%;
  margin: 0;
}

body,
button,
input,
textarea,
select {
  font-family: inherit;
  font-size: 13px;
  letter-spacing: 0;
}

#app {
  height: 100%;
  overflow: hidden;
  font-size: 13px;
}
</style>
