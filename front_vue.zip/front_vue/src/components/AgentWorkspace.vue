<template>
  <div class="workspace">
    <!-- Top bar -->
    <div class="workspace-topbar">
      <div class="topbar-left">
        <div
          class="topbar-agent-icon"
          :style="{ background: agent.color + '18', color: agent.color }"
        >
          <AgentMascot :agent="agent" size="header">
            <el-icon size="15">
              <component :is="agent.icon" />
            </el-icon>
          </AgentMascot>
        </div>
        <span class="topbar-title">{{ agent.name }}</span>
        <span class="topbar-desc">{{ config.tagline }}</span>
      </div>
      <div class="topbar-right">
        <button
          v-if="isLoading && currentTaskId"
          class="cancel-btn"
          :disabled="isCancelling"
          @click="handleCancel"
        >
          <el-icon size="13">
            <CircleClose />
          </el-icon> {{ isCancelling ? 'Cancelling...' : 'Cancel' }}
        </button>
        <button
          v-if="hasResult && !isLoading"
          class="reset-btn"
          @click="resetState"
        >
          <el-icon size="13">
            <RefreshLeft />
          </el-icon> New Task
        </button>
      </div>
    </div>

    <div class="workspace-body">
      <!-- LEFT: Input Panel -->
      <div class="input-panel">
        <div class="panel-section">
          <div class="section-label">
            <el-icon size="13">
              <component :is="config.fileIcon" />
            </el-icon>
            {{ config.uploadLabel }}
          </div>

          <!-- File Drop Zone -->
          <div
            class="drop-zone"
            :class="{ 'drag-over': isDragging, 'has-file': uploadedFiles.length > 0 }"
            @dragover.prevent="isDragging = true"
            @dragleave="isDragging = false"
            @drop.prevent="handleDrop"
            @click="triggerFileInput"
          >
            <input
              ref="fileInputRef"
              type="file"
              :accept="config.accept"
              :multiple="config.multiple"
              style="display:none"
              @change="handleFileChange"
            >
            <template v-if="uploadedFiles.length === 0 && !uploadedFileName">
              <el-icon
                size="28"
                class="drop-icon"
              >
                <Upload />
              </el-icon>
              <p class="drop-text">
                Drag and drop files or <span class="drop-link">browse</span>
              </p>
              <p class="drop-hint">
                {{ config.acceptHint }}
              </p>
            </template>
            <template v-else>
              <el-icon
                size="24"
                class="file-ok-icon"
              >
                <Document />
              </el-icon>
              <p class="file-name">
                {{ uploadedDisplayName }}
              </p>
              <p class="file-size">
                {{ formatSize(uploadedTotalSize || uploadedFileSize) }}
              </p>
              <button
                class="remove-file"
                @click.stop="clearUploadedFiles"
              >
                <el-icon size="12">
                  <Close />
                </el-icon>
              </button>
            </template>
          </div>
        </div>

        <div
          v-if="props.agent.id === 4"
          class="panel-section git-review-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <Connection />
            </el-icon>
            Git Repository
          </div>
          <div class="git-path-row">
            <input
              v-model="gitRepositoryPath"
              class="compact-input"
              placeholder="Local repository path, e.g. D:/repo/firmware"
            >
            <button
              type="button"
              class="folder-picker-btn"
              :disabled="isLoading"
              @click="selectGitRepository"
            >
              Browse
            </button>
          </div>
          <div class="field-grid git-ref-grid">
            <input
              v-model="gitBaseRef"
              class="compact-input"
              placeholder="Base ref (HEAD~1)"
            >
            <input
              v-model="gitTargetRef"
              class="compact-input"
              placeholder="Target ref (WORKTREE)"
            >
          </div>
          <label class="approval-toggle git-untracked-toggle">
            <input
              v-model="gitIncludeUntracked"
              type="checkbox"
            >
            Include untracked files in working-tree review
          </label>
          <small class="git-help">Use Git alone or combine it with uploaded source files. WORKTREE reviews uncommitted changes.</small>
        </div>

        <div
          v-if="props.agent.id === 4"
          class="panel-section git-review-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <Connection />
            </el-icon>
            Bitbucket Pull Request Diff
          </div>
          <div
            class="integration-status"
            :class="{ unavailable: !reviewIntegrations.bitbucket?.available }"
          >
            <span class="integration-status-dot" />
            {{ reviewIntegrations.bitbucket?.available ? 'Bitbucket MCP configured' : 'Bitbucket MCP not configured on backend' }}
          </div>
          <div class="field-grid git-ref-grid">
            <input
              v-model="bitbucketRepo"
              class="compact-input"
              placeholder="Repository slug (e.g. firmware)"
            >
            <input
              v-model.number="bitbucketPrId"
              class="compact-input"
              type="number"
              min="1"
              placeholder="Pull request ID"
            >
          </div>
          <small
            v-if="hasPartialBitbucketPr"
            class="field-error"
          >Enter both a repository slug and a valid pull request ID.</small>
          <small class="git-help">When provided, Review analyzes the Bitbucket PR diff and anchors findings to added target lines.</small>
        </div>

        <div
          v-if="props.agent.id === 4"
          class="panel-section review-context-section jira-review-section"
        >
          <div class="review-context-heading">
            <span class="review-context-title">Review Context</span>
            <small>Optional Git and Jira evidence for this review</small>
          </div>
          <div class="section-label">
            <el-icon size="13">
              <Tickets />
            </el-icon>
            Jira Bug Context
          </div>
          <div
            class="integration-status"
            :class="{ unavailable: !reviewIntegrations.jira.available }"
          >
            <span class="integration-status-dot" />
            {{ reviewIntegrations.jira.available ? 'Jira MCP configured' : 'Jira MCP not configured on backend' }}
          </div>
          <div class="field-grid">
            <input
              v-model="jiraProject"
              class="compact-input"
              placeholder="Project key (e.g. FW)"
            >
            <input
              v-model="jiraStatus"
              class="compact-input"
              placeholder="Status (optional)"
            >
            <input
              v-model="jiraIssueKeys"
              class="compact-input field-span"
              placeholder="Issue keys, comma-separated (e.g. FW-123, FW-124)"
            >
            <input
              v-model.number="jiraMaxResults"
              class="compact-input"
              type="number"
              min="1"
              max="100"
              placeholder="Max bugs"
            >
          </div>
          <textarea
            v-model="jiraJql"
            class="prompt-input jira-jql-input"
            rows="2"
            placeholder="Optional JQL, e.g. project = FW AND issuetype = Bug AND status != Done"
          />
          <small class="git-help">Uses the configured Jira API token on the backend. Jira text is treated as untrusted issue context.</small>
        </div>

        <!-- Extra input (optional per agent) -->
        <div
          v-if="config.hasPrompt"
          class="panel-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <EditPen />
            </el-icon>
            {{ config.promptLabel }}
          </div>
          <textarea
            v-model="userPrompt"
            class="prompt-input"
            :placeholder="config.promptPlaceholder"
            rows="4"
          />
        </div>

        <div
          v-if="props.agent.id === 3"
          class="panel-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <Setting />
            </el-icon>
            Driver Target
          </div>
          <div class="field-grid">
            <input
              v-model="driverDeviceName"
              class="compact-input"
              placeholder="Device name (auto from filename)"
            >
            <select
              v-model="driverInterface"
              class="compact-input"
            >
              <option value="auto">
                Auto-detect interface
              </option>
              <option value="i2c">
                I2C
              </option>
              <option value="spi">
                SPI
              </option>
              <option value="uart">
                UART
              </option>
              <option value="gpio">
                GPIO
              </option>
              <option value="can">
                CAN
              </option>
              <option value="usb">
                USB
              </option>
            </select>
            <input
              v-model="driverMcuFamily"
              class="compact-input field-span"
              placeholder="MCU family or platform"
            >
          </div>
        </div>

        <div
          v-if="props.agent.id === 4"
          class="panel-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <Setting />
            </el-icon>
            Review Mode
          </div>
          <select
            v-model="reviewType"
            class="compact-input"
          >
            <option value="full">
              Full review
            </option>
            <option value="quick">
              Quick defect scan
            </option>
            <option value="misra">
              MISRA compliance
            </option>
            <option value="security">
              Security review
            </option>
          </select>
          <label class="approval-toggle">
            <input
              v-model="reviewRequireApproval"
              type="checkbox"
            >
            Require human approval before final report
          </label>
          <div
            v-if="reviewRequireApproval"
            class="review-approval-fields"
          >
            <label><input
              v-model="reviewApprovalChannels"
              type="checkbox"
              value="email"
            > Email</label>
            <label><input
              v-model="reviewApprovalChannels"
              type="checkbox"
              value="feishu"
            > Feishu</label>
            <input
              v-model="reviewApprovalRecipients"
              class="compact-input"
              placeholder="Reviewer emails, comma-separated (optional)"
            >
          </div>
        </div>

        <button
          class="run-btn"
          :class="{ loading: isLoading }"
          :disabled="!canRun"
          @click="handleRun"
        >
          <el-icon
            v-if="!isLoading"
            size="15"
          >
            <component :is="config.runIcon" />
          </el-icon>
          <span
            v-if="isLoading"
            class="spinner"
          />
          {{ isLoading ? 'Processing...' : config.runLabel }}
        </button>
      </div>

      <!-- RIGHT: Result Panel -->
      <div class="result-panel">
        <div
          v-if="props.agent.id === 3 && (isLoading || agentResult)"
          class="token-usage-strip"
        >
          <div class="token-usage-heading">
            LLM Usage
          </div>
          <div class="token-usage-item">
            <span>Input</span>
            <strong>{{ tokenUsage.input_tokens.toLocaleString() }}</strong>
          </div>
          <div class="token-usage-item">
            <span>Output</span>
            <strong>{{ tokenUsage.output_tokens.toLocaleString() }}</strong>
          </div>
          <div class="token-usage-item">
            <span>Cache Write</span>
            <strong>{{ tokenUsage.cache_creation_input_tokens.toLocaleString() }}</strong>
          </div>
          <div class="token-usage-item">
            <span>Cache Read</span>
            <strong>{{ tokenUsage.cache_read_input_tokens.toLocaleString() }}</strong>
          </div>
          <div class="token-usage-item token-usage-total">
            <span>Total</span>
            <strong>{{ tokenUsage.total_tokens.toLocaleString() }}</strong>
          </div>
        </div>

        <!-- Loading: wait for task completion -->
        <div
          v-if="isLoading"
          class="result-loading"
        >
          <!-- Title row -->
          <div class="loading-title-row">
            <div class="loading-spinner-wrap">
              <svg
                class="loading-ring"
                viewBox="0 0 36 36"
              >
                <circle
                  class="ring-bg"
                  cx="18"
                  cy="18"
                  r="15"
                />
                <circle
                  class="ring-progress"
                  cx="18"
                  cy="18"
                  r="15"
                  :style="{ strokeDashoffset: 94.2 - (taskProgress / 100) * 94.2 }"
                />
              </svg>
              <span class="loading-pct">{{ taskProgress > 0 ? taskProgress + '%' : '--' }}</span>
            </div>
            <div class="loading-msg-col">
              <div class="loading-msg-title">
                Processing...
              </div>
              <div class="loading-msg-sub">
                {{ loadingMsg }}
              </div>
            </div>
          </div>

          <!-- Horizontal pipeline flow -->
          <div class="pipeline-flow">
            <template
              v-for="(step, i) in taskSteps"
              :key="i"
            >
              <!-- Step node -->
              <div
                class="pipeline-node"
                :class="step.state"
              >
                <div class="pipeline-icon-wrap">
                  <el-icon
                    v-if="step.state === 'done'"
                    class="pipe-check"
                    size="18"
                  >
                    <CircleCheck />
                  </el-icon>
                  <span
                    v-else-if="step.state === 'active'"
                    class="pipe-spinner"
                  />
                  <span
                    v-else-if="step.state === 'fail'"
                    class="pipe-fail"
                  >×</span>
                  <span
                    v-else
                    class="pipe-empty"
                  />
                </div>
                <span class="pipeline-label">{{ step.label }}</span>
              </div>
              <!-- Connector arrow (hidden for the last step) -->
              <div
                v-if="i < taskSteps.length - 1"
                class="pipeline-arrow"
                :class="{ lit: step.state === 'done' }"
              >
                <svg
                  width="28"
                  height="12"
                  viewBox="0 0 28 12"
                >
                  <line
                    x1="0"
                    y1="6"
                    x2="20"
                    y2="6"
                    stroke-width="2"
                  />
                  <polyline
                    points="16,2 22,6 16,10"
                    stroke-width="2"
                    fill="none"
                    stroke-linejoin="round"
                  />
                </svg>
              </div>
            </template>
          </div>
        </div>

        <div
          v-if="props.agent.id === 3 && agentResult && !isLoading"
          class="agent-result"
        >
          <div class="stats-row">
            <div class="stat-card stat-ok">
              <el-icon size="18">
                <CircleCheck />
              </el-icon>
              <span class="stat-label">Validation</span>
              <span class="stat-value">{{ agentResult.validation?.passed ? 'PASS' : 'CHECK' }}</span>
            </div>
            <div class="stat-card">
              <el-icon
                size="18"
                style="color:#2563eb"
              >
                <Document />
              </el-icon>
              <span class="stat-label">Files</span>
              <span class="stat-value">{{ agentResult.files?.length || 0 }}</span>
            </div>
          </div>

          <div class="file-list-section">
            <div class="section-title">
              <el-icon size="13">
                <FolderOpened />
              </el-icon>
              Generated Driver Files
            </div>
            <div
              v-for="file in agentResult.files || []"
              :key="file.filename"
              class="file-item-wrap"
            >
              <div class="file-item">
                <el-icon
                  size="13"
                  style="color:#2563eb"
                >
                  <Document />
                </el-icon>
                <span class="file-item-name">{{ file.filename }}</span>
                <button
                  class="view-btn"
                  @click="toggleGeneratedFile(file)"
                >
                  <el-icon size="11">
                    <component :is="expandedFiles.has(file.filename) ? 'ArrowUp' : 'ArrowDown'" />
                  </el-icon>
                  {{ expandedFiles.has(file.filename) ? 'Collapse' : 'Preview' }}
                </button>
                <button
                  class="dl-btn"
                  @click="downloadGeneratedFile(file)"
                >
                  <el-icon size="12">
                    <Download />
                  </el-icon>
                  Download
                </button>
              </div>
              <div
                v-if="expandedFiles.has(file.filename)"
                class="inline-code-wrap"
              >
                <div class="inline-code-header">
                  <span>{{ file.filename }}</span>
                  <button
                    class="copy-small-btn"
                    @click="copyGeneratedFile(file)"
                  >
                    <el-icon size="11">
                      <CopyDocument />
                    </el-icon>
                    {{ copiedFiles.has(file.filename) ? 'Copied' : 'Copy' }}
                  </button>
                </div>
                <pre class="inline-code">{{ file.content }}</pre>
              </div>
            </div>
          </div>

          <div
            v-if="agentResult.validation?.warnings?.length"
            class="warning-list"
          >
            <div class="section-title">
              <el-icon size="13">
                <Warning />
              </el-icon>
              Validation Notes
            </div>
            <div
              v-for="warning in agentResult.validation.warnings"
              :key="warning"
              class="warning-row"
            >
              {{ warning }}
            </div>
          </div>
          <div
            v-if="agentResult.error"
            class="error-box"
          >
            <el-icon size="14">
              <Warning />
            </el-icon>
            {{ agentResult.error }}
          </div>
        </div>

        <div
          v-if="props.agent.id === 4 && reviewApprovalState.status === 'pending'"
          class="review-approval-card"
        >
          <div class="review-approval-heading">
            <strong>Human approval required</strong>
            <span>Review findings and code diff before finalizing</span>
          </div>
          <pre
            v-if="reviewApprovalState.code_diff"
            class="review-diff-preview"
          >{{ reviewApprovalState.code_diff }}</pre>
          <textarea
            v-model="reviewApprovalComment"
            class="approval-comment"
            rows="3"
            placeholder="Optional reviewer comment"
          />
          <div class="review-approval-actions">
            <button
              class="approval-reject-btn"
              type="button"
              :disabled="isReviewApprovalSubmitting"
              @click="submitReviewApproval('reject')"
            >
              Reject review
            </button>
            <button
              class="approval-approve-btn"
              type="button"
              :disabled="isReviewApprovalSubmitting"
              @click="submitReviewApproval('approve')"
            >
              Approve report
            </button>
          </div>
          <small
            v-if="reviewApprovalState.delivery?.warnings?.length"
            class="review-approval-warning"
          >{{ reviewApprovalState.delivery.warnings.join(' ') }}</small>
          <small
            v-else
            class="review-approval-channel"
          >Notifications: {{ (reviewApprovalState.channels || []).join(', ') || 'workspace only' }}</small>
        </div>

        <div
          v-if="props.agent.id === 4 && agentResult && !isLoading"
          class="agent-result"
        >
          <div class="stats-row review-stats">
            <div class="stat-card">
              <span class="stat-label">Score</span>
              <span class="stat-value score-value">{{ agentResult.score ?? 0 }}</span>
            </div>
            <div class="stat-card severity-critical">
              <span class="stat-label">Critical</span>
              <span class="stat-value">{{ agentResult.counts?.critical || 0 }}</span>
            </div>
            <div class="stat-card severity-major">
              <span class="stat-label">Major</span>
              <span class="stat-value">{{ agentResult.counts?.major || 0 }}</span>
            </div>
            <div class="stat-card severity-minor">
              <span class="stat-label">Minor</span>
              <span class="stat-value">{{ agentResult.counts?.minor || 0 }}</span>
            </div>
          </div>

          <div class="review-summary">
            {{ agentResult.summary }}
          </div>
          <div
            v-if="agentResult.jira_issues?.length"
            class="jira-context-section"
          >
            <div class="section-title">
              Jira Bug Context
            </div>
            <div
              v-for="issue in agentResult.jira_issues"
              :key="issue.key || issue.issue_key"
              class="jira-context-item"
            >
              <strong>{{ issue.key || issue.issue_key }}</strong>
              <span>{{ issue.summary }}</span>
              <small v-if="issue.status">{{ issue.status }}</small>
            </div>
          </div>
          <div
            v-if="agentResult.code_diff"
            class="review-diff-section"
          >
            <div class="section-title">
              Code Diff
            </div>
            <pre class="review-diff-preview final-diff">{{ agentResult.code_diff }}</pre>
          </div>
          <div class="findings-list">
            <div
              v-for="(finding, index) in agentResult.findings || []"
              :key="`${finding.file}-${finding.line}-${index}`"
              class="finding-item"
              :class="`finding-${finding.severity}`"
            >
              <div class="finding-head">
                <span class="severity-badge">{{ finding.severity }}</span>
                <strong>{{ finding.title }}</strong>
                <span class="finding-location">{{ finding.file }}{{ finding.line ? ':' + finding.line : '' }}</span>
              </div>
              <p>{{ finding.description }}</p>
              <div
                v-if="finding.rule"
                class="finding-rule"
              >
                {{ finding.rule }}
              </div>
              <div
                v-if="finding.suggestion"
                class="finding-suggestion"
              >
                <strong>Suggested fix:</strong> {{ finding.suggestion }}
              </div>
            </div>
            <div
              v-if="!(agentResult.findings || []).length && !agentResult.error"
              class="empty-findings"
            >
              No actionable findings were reported.
            </div>
          </div>
          <div
            v-if="agentResult.report_markdown"
            class="report-actions"
          >
            <button
              class="dl-btn"
              @click="downloadReviewReport"
            >
              <el-icon size="12">
                <Download />
              </el-icon>
              Download Report
            </button>
          </div>
          <div
            v-if="agentResult.error"
            class="error-box"
          >
            <el-icon size="14">
              <Warning />
            </el-icon>
            {{ agentResult.error }}
          </div>
        </div>

        <!-- Unittest-specific result panel -->
        <div
          v-if="props.agent.id === 2 && unittestResult && !isLoading"
          class="unittest-result"
        >
          <!-- Stats card row -->
          <div class="stats-row">
            <div
              class="stat-card"
              :class="unittestResult.compile_success ? 'stat-ok' : 'stat-fail'"
            >
              <el-icon size="18">
                <component :is="unittestResult.compile_success ? 'CircleCheck' : 'CircleClose'" />
              </el-icon>
              <span class="stat-label">Build</span>
              <span class="stat-value">{{ unittestResult.compile_success ? 'PASS' : 'FAIL' }}</span>
            </div>
            <div class="stat-card">
              <el-icon
                size="18"
                style="color:#2563eb"
              >
                <Document />
              </el-icon>
              <span class="stat-label">Files</span>
              <span class="stat-value">{{ unittestResult.files_processed }}</span>
            </div>
            <div class="stat-card">
              <el-icon
                size="18"
                style="color:#16a34a"
              >
                <Finished />
              </el-icon>
              <span class="stat-label">Test Files</span>
              <span class="stat-value">{{ unittestResult.tests_generated }}</span>
            </div>
          </div>

          <!-- Generated file list -->
          <div
            v-if="unittestResult.written_files?.length"
            class="file-list-section"
          >
            <div class="section-title">
              <el-icon size="13">
                <FolderOpened />
              </el-icon>
              Generated Files
            </div>
            <div
              v-for="f in unittestResult.written_files"
              :key="f"
              class="file-item-wrap"
            >
              <div class="file-item">
                <el-icon
                  size="13"
                  style="color:#2563eb"
                >
                  <Document />
                </el-icon>
                <span class="file-item-name">{{ shortPath(f) }}</span>
                <button
                  class="view-btn"
                  @click="toggleInlineFile(f)"
                >
                  <el-icon size="11">
                    <component :is="expandedFiles.has(f) ? 'ArrowUp' : 'ArrowDown'" />
                  </el-icon>
                  {{ expandedFiles.has(f) ? 'Collapse' : 'Preview' }}
                </button>
                <button
                  class="dl-btn"
                  @click="downloadFile(f)"
                >
                  <el-icon size="12">
                    <Download />
                  </el-icon>
                  Download
                </button>
              </div>
              <!-- Inline code preview -->
              <div
                v-if="expandedFiles.has(f)"
                class="inline-code-wrap"
              >
                <div class="inline-code-header">
                  <span>{{ shortPath(f) }}</span>
                  <button
                    class="copy-small-btn"
                    @click="copyInlineFile(f)"
                  >
                    <el-icon size="11">
                      <CopyDocument />
                    </el-icon>
                    {{ copiedFiles.has(f) ? 'Copied' : 'Copy' }}
                  </button>
                </div>
                <pre class="inline-code">{{ inlineFileContents[f] || 'Loading...' }}</pre>
              </div>
            </div>
          </div>

          <!-- Build output -->
          <div class="compile-section">
            <div
              class="section-title"
              style="cursor:pointer"
              @click="showCompile = !showCompile"
            >
              <el-icon size="13">
                <component :is="unittestResult.compile_success ? 'CircleCheck' : 'Warning'" />
              </el-icon>
              Build Output
              <el-icon
                size="11"
                style="margin-left:auto"
              >
                <component :is="showCompile ? 'ArrowUp' : 'ArrowDown'" />
              </el-icon>
            </div>
            <pre
              v-if="showCompile"
              class="compile-output"
              :class="{ 'compile-ok': unittestResult.compile_success, 'compile-error': !unittestResult.compile_success }"
            >{{ unittestResult.compile_output || '(no output)' }}</pre>
          </div>

          <!-- Error message -->
          <div
            v-if="unittestResult.error"
            class="error-box"
          >
            <el-icon size="14">
              <Warning />
            </el-icon>
            {{ unittestResult.error }}
          </div>
        </div>

        <!-- Code viewer dialog -->
        <el-dialog
          v-model="codeDialogVisible"
          :title="codeDialogTitle"
          width="72%"
          top="5vh"
          destroy-on-close
        >
          <pre class="dialog-code">{{ codeDialogContent }}</pre>
          <template #footer>
            <el-button @click="codeDialogVisible = false">
              Close
            </el-button>
            <el-button
              type="primary"
              @click="downloadCurrentFile"
            >
              Download File
            </el-button>
          </template>
        </el-dialog>

        <!-- Existing result panel for other agents -->
        <div
          v-if="![2, 3, 4].includes(props.agent.id) && resultContent && !isLoading"
          class="result-content"
        >
          <div class="result-header">
            <div class="result-header-left">
              <el-icon
                size="14"
                style="color: #16a34a"
              >
                <CircleCheck />
              </el-icon>
              <span>{{ config.resultTitle }}</span>
            </div>
            <button
              class="copy-btn"
              @click="copyResult"
            >
              <el-icon size="13">
                <CopyDocument />
              </el-icon>
              {{ copied ? 'Copied!' : 'Copy' }}
            </button>
          </div>
          <pre class="result-code">{{ resultContent }}</pre>
        </div>
      </div>
    </div>

    <!-- AWS SSO Login Modal -->
    <AWSSSOLoginModal
      :visible="showAWSSSOModal"
      @success="handleAWSSSOSuccess"
      @close="handleAWSSSOClose"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount, watch } from 'vue'
import { useRoute } from 'vue-router'
import { apiGenerateTests, apiPollTask } from '../api/unittest.js'
import { apiCreateDriverTask, apiPollDriverTask, apiCancelDriverTask } from '../api/driver.js'
import { apiApproveReviewTask, apiCreateReviewTask, apiPollReviewTask, apiCancelReviewTask, getReviewIntegrations } from '../api/review.js'
import { useWorkspaceStore } from '../stores/workspace.js'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import AWSSSOLoginModal from './AWSSSOLoginModal.vue'
import AgentMascot from './AgentMascot.vue'

const props = defineProps({
  agent: Object
})
const route = useRoute()

const workspaceStore = useWorkspaceStore()
const authStore = useAuthStore()
const mountedAccount = accountIdentity(authStore)
const workspaceStateKey = computed(() => mountedAccount ? `workspace:${mountedAccount}:${props.agent?.id}` : null)
let disposed = false

function isCurrentAccount() {
  return !disposed && mountedAccount === accountIdentity(authStore)
}

function invalidateWorkspace() {
  disposed = true
  activeStopPolling?.()
  activeStopPolling = null
  activeTaskResolver?.(null)
  activeTaskResolver = null
}

watch(() => accountIdentity(authStore), invalidateWorkspace, { flush: 'sync' })

// Per-agent configuration
const configs = {
  2: {
    tagline: 'Auto-generate unit test cases from source code',
    uploadLabel: 'Upload source code file',
    fileIcon: 'Document',
    accept: '.c,.cpp,.h',
    acceptHint: 'Supports .c / .cpp / .h',
    multiple: false,
    hasPrompt: false,
    promptLabel: '',
    promptPlaceholder: '',
    runIcon: 'Finished',
    runLabel: 'Generate Tests',
    emptyTitle: 'Ready to generate unit tests',
    emptySub: 'Upload your source file and click Generate Tests.',
    steps: ['Upload source code file', 'Click Generate Tests', 'Review and copy results'],
    resultTitle: 'Generated Unit Tests',
  },
  3: {
    tagline: 'Generate peripheral driver code for embedded systems',
    uploadLabel: 'Upload datasheet or specification file',
    fileIcon: 'Document',
    accept: '.pdf,.docx,.txt,.md,.c,.h,.cpp,.hpp',
    acceptHint: 'Supports PDF, Docx, text, Markdown, and C/C++ specifications',
    multiple: false,
    hasPrompt: true,
    promptLabel: 'Additional Requirements',
    promptPlaceholder: 'Optional API, timing, interrupt, portability, or platform requirements...',
    runIcon: 'Connection',
    runLabel: 'Generate Driver',
    emptyTitle: 'Ready to generate driver code',
    emptySub: 'Upload datasheet or describe peripheral requirements.',
    steps: ['Upload datasheet / spec', 'Click Generate Driver', 'Review and copy results'],
    resultTitle: 'Generated Driver Code',
  },
  4: {
    tagline: 'Automated MCU code security and compliance review',
    uploadLabel: 'Upload source code',
    fileIcon: 'Document',
    accept: '.c,.cc,.cpp,.h,.hh,.hpp,.s,.asm',
    acceptHint: 'Select up to 20 C, C++, header, or assembly files',
    multiple: true,
    hasPrompt: true,
    promptLabel: 'Review Focus',
    promptPlaceholder: 'Optional subsystem, defect class, safety, or compliance focus...',
    runIcon: 'Cpu',
    runLabel: 'Start Review',
    emptyTitle: 'Ready to review MCU code',
    emptySub: 'Upload MCU source files to detect risks and compliance issues.',
    steps: ['Upload MCU source code', 'Click Start Review', 'View detailed report', 'Fix flagged issues'],
    resultTitle: 'Code Review Report',
  },
  5: {
    tagline: 'RAG-based Q&A with knowledge base retrieval',
    uploadLabel: 'Upload knowledge base documents',
    fileIcon: 'Collection',
    accept: '.pdf,.txt,.docx,.md',
    acceptHint: 'Supports .pdf / .txt / .docx / .md',
    multiple: false,
    hasPrompt: true,
    promptLabel: 'Your Question',
    promptPlaceholder: 'Enter your question about the uploaded document...',
    runIcon: 'Search',
    runLabel: 'Search and Answer',
    emptyTitle: 'Knowledge base Q&A ready',
    emptySub: 'Upload documents and enter your question.',
    steps: ['Upload knowledge base documents', 'Enter question', 'Click Search and Answer', 'View results'],
    resultTitle: 'RAG Answer',
  },
}

const config = computed(() => configs[props.agent.id] || configs[2])

// Workspace state
const uploadedFiles     = ref([])
const userPrompt        = ref('')
const isLoading         = ref(false)
const resultContent     = ref('')
const agentResult       = ref(null)
const isDragging        = ref(false)
const copied            = ref(false)
const fileInputRef      = ref(null)
const currentTaskId     = ref('')
const isCancelling = ref(false)
const tokenUsage        = ref(createEmptyTokenUsage())
const driverDeviceName  = ref('')
const driverInterface   = ref('auto')
const driverMcuFamily   = ref('generic')
const reviewType        = ref('full')
const reviewRequireApproval = ref(true)
const reviewApprovalChannels = ref([])
const reviewApprovalRecipients = ref('')
const reviewApprovalState = ref({})
const reviewApprovalComment = ref('')
const isReviewApprovalSubmitting = ref(false)
const gitRepositoryPath = ref('')
const gitBaseRef = ref('HEAD~1')
const gitTargetRef = ref('WORKTREE')
const gitIncludeUntracked = ref(true)
const jiraProject = ref('')
const jiraJql = ref('')
const jiraIssueKeys = ref('')
const jiraStatus = ref('')
const jiraMaxResults = ref(20)
const bitbucketRepo = ref('')
const bitbucketPrId = ref('')
const reviewIntegrations = ref({ jira: { available: false }, git: { available: false }, bitbucket: { available: false } })
let activeStopPolling = null
let activeTaskResolver = null

// Unittest-specific state
const unittestResult    = ref(null)
const taskProgress      = ref(0)
const loadingMsg        = ref('Processing...')
const reviewWorkflowNodes = ref([])
const showCompile       = ref(false)
const codeDialogVisible = ref(false)
const codeDialogTitle   = ref('')
const codeDialogContent = ref('')
const codeDialogFilePath = ref('')

// Inline file preview state
const expandedFiles     = ref(new Set())
const inlineFileContents = ref({})
const copiedFiles       = ref(new Set())

// Used to show the uploaded filename even when the File object is unavailable
const uploadedFileName  = ref('')
const uploadedFileSize  = ref(0)

// AWS SSO login modal state
const showAWSSSOModal   = ref(false)
const pendingRetryFn    = ref(null)

// Handle global AWS auth required event
const handleAWSAuthRequired = () => {
  showAWSSSOModal.value = true
  pendingRetryFn.value = null // Clear any pending retry since we don't know which operation failed
}

onMounted(() => {
  const saved = workspaceStateKey.value ? workspaceStore.getState(workspaceStateKey.value) : null
  if (saved) {
    resultContent.value  = saved.resultContent  || ''
    unittestResult.value = saved.unittestResult || null
    showCompile.value    = saved.showCompile    || false
    uploadedFileName.value = saved.uploadedFileName || ''
    uploadedFileSize.value = saved.uploadedFileSize || 0
    userPrompt.value = saved.userPrompt || ''
    driverDeviceName.value = saved.driverDeviceName || ''
    driverInterface.value = saved.driverInterface || 'auto'
    driverMcuFamily.value = saved.driverMcuFamily || 'generic'
    reviewType.value = saved.reviewType || 'full'
    reviewRequireApproval.value = Boolean(saved.reviewRequireApproval)
    reviewApprovalChannels.value = saved.reviewApprovalChannels || []
    reviewApprovalRecipients.value = saved.reviewApprovalRecipients || ''
    gitRepositoryPath.value = saved.gitRepositoryPath || ''
    gitBaseRef.value = saved.gitBaseRef || 'HEAD~1'
    gitTargetRef.value = saved.gitTargetRef || 'WORKTREE'
    gitIncludeUntracked.value = saved.gitIncludeUntracked !== false
    bitbucketRepo.value = saved.bitbucketRepo || ''
    bitbucketPrId.value = saved.bitbucketPrId || ''
    jiraProject.value = saved.jiraProject || ''
    jiraJql.value = saved.jiraJql || ''
    jiraIssueKeys.value = saved.jiraIssueKeys || ''
    jiraStatus.value = saved.jiraStatus || ''
    jiraMaxResults.value = saved.jiraMaxResults || 20
    tokenUsage.value = normalizeTokenUsage(saved.tokenUsage)
  }

  applyReviewNotification()

  // Listen for global AWS auth required events
  globalThis.addEventListener('aws:auth-required', handleAWSAuthRequired)
  if (props.agent?.id === 4) {
    getReviewIntegrations().then((data) => {
      if (!isCurrentAccount()) return
      reviewIntegrations.value = {
        jira: { available: false, ...(data?.jira || {}) },
        git: { available: false, ...(data?.git || {}) },
        bitbucket: { available: false, ...(data?.bitbucket || {}) },
      }
      if (!gitRepositoryPath.value && data?.git?.repository_path) {
        gitRepositoryPath.value = data.git.repository_path
      }
      if (!bitbucketRepo.value && data?.bitbucket?.workspace) {
        bitbucketRepo.value = data.bitbucket.workspace
      }
      if (!jiraProject.value && data?.jira?.project) {
        jiraProject.value = data.jira.project
      }
    }).catch(error => {
      if (isCurrentAccount()) console.warn('Review integration status is unavailable:', error)
    })
  }
})

function applyReviewNotification() {
  if (!isCurrentAccount() || props.agent?.id !== 4 || isLoading.value) return
  const repo = String(route.query.repo || '').trim()
  const prId = String(route.query.pr_id || '').trim()
  if (!repo || !/^[1-9][0-9]*$/.test(prId)) return
  bitbucketRepo.value = repo
  bitbucketPrId.value = prId
}

watch(() => [route.query.repo, route.query.pr_id, isLoading.value], applyReviewNotification)

onBeforeUnmount(() => {
  globalThis.removeEventListener('aws:auth-required', handleAWSAuthRequired)
  invalidateWorkspace()
})

watch([
  resultContent,
  unittestResult,
  showCompile,
  userPrompt,
  driverDeviceName,
  driverInterface,
  driverMcuFamily,
  reviewType,
  reviewRequireApproval,
  reviewApprovalChannels,
  reviewApprovalRecipients,
  gitRepositoryPath,
  gitBaseRef,
  gitTargetRef,
  gitIncludeUntracked,
  bitbucketRepo,
  bitbucketPrId,
  jiraProject,
  jiraJql,
  jiraIssueKeys,
  jiraStatus,
  jiraMaxResults,
  tokenUsage,
], () => {
  if (!isCurrentAccount() || !workspaceStateKey.value) return
  workspaceStore.saveState(workspaceStateKey.value, {
    resultContent:  resultContent.value,
    unittestResult: unittestResult.value,
    showCompile:    showCompile.value,
    uploadedFileName: uploadedFileName.value,
    uploadedFileSize: uploadedFileSize.value,
    userPrompt: userPrompt.value,
    driverDeviceName: driverDeviceName.value,
    driverInterface: driverInterface.value,
    driverMcuFamily: driverMcuFamily.value,
    reviewType: reviewType.value,
    reviewRequireApproval: reviewRequireApproval.value,
    reviewApprovalChannels: reviewApprovalChannels.value,
    reviewApprovalRecipients: reviewApprovalRecipients.value,
    gitRepositoryPath: gitRepositoryPath.value,
    gitBaseRef: gitBaseRef.value,
    gitTargetRef: gitTargetRef.value,
    gitIncludeUntracked: gitIncludeUntracked.value,
    bitbucketRepo: bitbucketRepo.value,
    bitbucketPrId: bitbucketPrId.value,
    jiraProject: jiraProject.value,
    jiraJql: jiraJql.value,
    jiraIssueKeys: jiraIssueKeys.value,
    jiraStatus: jiraStatus.value,
    jiraMaxResults: jiraMaxResults.value,
    tokenUsage: tokenUsage.value,
  })
})

// Progress stages aligned with backend Agent updates
const TASK_STEPS_BY_AGENT = {
  2: [
    { label: 'Upload file', doneAbove: 10 },
    { label: 'Generate tests', doneAbove: 54 },
    { label: 'Write files', doneAbove: 64 },
    { label: 'Update project', doneAbove: 74 },
    { label: 'Build', doneAbove: 94 },
    { label: 'Done', doneAbove: 100 },
  ],
  3: [
    { label: 'Extract spec', doneAbove: 18 },
    { label: 'Analyze', doneAbove: 34 },
    { label: 'Generate files', doneAbove: 74 },
    { label: 'Validate', doneAbove: 90 },
    { label: 'Save', doneAbove: 99 },
    { label: 'Done', doneAbove: 100 },
  ],
  4: [
    { label: 'Upload files', doneAbove: 12 },
    { label: 'Collect code', doneAbove: 24 },
    { label: 'Review', doneAbove: 80 },
    { label: 'Aggregate', doneAbove: 90 },
    { label: 'Save report', doneAbove: 99 },
    { label: 'Done', doneAbove: 100 },
  ],
}

const taskSteps = computed(() => {
  if ((props.agent.id === 3 || props.agent.id === 4) && reviewWorkflowNodes.value.length) {
    return reviewWorkflowNodes.value.map(node => ({
      label: node.label,
      state: node.status === 'fail' ? 'fail' : (node.status || 'pending'),
    }))
  }
  const pct = taskProgress.value
  const steps = TASK_STEPS_BY_AGENT[props.agent.id] || TASK_STEPS_BY_AGENT[2]
  const activeIdx = steps.findIndex(s => pct <= s.doneAbove)
  return steps.map((s, i) => {
    if (i < activeIdx) return { ...s, state: 'done' }
    if (i === activeIdx) return { ...s, state: pct === 0 && i === 0 ? 'active' : 'active' }
    return { ...s, state: 'pending' }
  })
})

// Computed state
const uploadedFile = computed(() => uploadedFiles.value[0] || null)
const uploadedTotalSize = computed(() => uploadedFiles.value.reduce((sum, file) => sum + file.size, 0))
const uploadedDisplayName = computed(() => {
  if (uploadedFiles.value.length > 1) {
    return `${uploadedFiles.value[0].name} +${uploadedFiles.value.length - 1} more`
  }
  return uploadedFile.value?.name || uploadedFileName.value
})
const hasResult = computed(() => Boolean(resultContent.value || unittestResult.value || agentResult.value))
const hasValidBitbucketPr = computed(() => (
  Boolean(bitbucketRepo.value.trim()) &&
  Number.isInteger(Number(bitbucketPrId.value)) &&
  Number(bitbucketPrId.value) > 0
))
const hasPartialBitbucketPr = computed(() => (
  Boolean(bitbucketRepo.value.trim()) !== (Number(bitbucketPrId.value) > 0)
))
const canRun = computed(() => {
  if (isLoading.value) return false
  if (props.agent.id === 4) {
    if (hasPartialBitbucketPr.value) return false
    return uploadedFiles.value.length > 0 || Boolean(gitRepositoryPath.value.trim()) || hasValidBitbucketPr.value
  }
  if (uploadedFiles.value.length === 0) return false
  if (config.value.hasPrompt && props.agent.id === 5 && !userPrompt.value.trim()) return false
  return true
})

// File selection
function triggerFileInput() { fileInputRef.value?.click() }

function handleFileChange(e) {
  applySelectedFiles(Array.from(e.target.files || []))
}

function handleDrop(e) {
  isDragging.value = false
  applySelectedFiles(Array.from(e.dataTransfer.files || []))
}

function applySelectedFiles(files) {
  uploadedFiles.value = config.value.multiple ? files.slice(0, 20) : files.slice(0, 1)
  uploadedFileName.value = uploadedDisplayName.value
  uploadedFileSize.value = uploadedTotalSize.value
  if (props.agent.id === 3 && uploadedFile.value && !driverDeviceName.value) {
    driverDeviceName.value = uploadedFile.value.name.replace(/\.[^.]+$/, '')
  }
}

function clearUploadedFiles() {
  uploadedFiles.value = []
  uploadedFileName.value = ''
  uploadedFileSize.value = 0
  if (fileInputRef.value) fileInputRef.value.value = ''
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

function resetState() {
  clearUploadedFiles()
  userPrompt.value     = ''
  resultContent.value  = ''
  agentResult.value    = null
  unittestResult.value = null
  taskProgress.value   = 0
  reviewWorkflowNodes.value = []
  reviewApprovalState.value = {}
  reviewApprovalComment.value = ''
  gitRepositoryPath.value = ''
  gitBaseRef.value = 'HEAD~1'
  gitTargetRef.value = 'WORKTREE'
  gitIncludeUntracked.value = true
  bitbucketRepo.value = ''
  bitbucketPrId.value = ''
  jiraProject.value = ''
  jiraJql.value = ''
  jiraIssueKeys.value = ''
  jiraStatus.value = ''
  jiraMaxResults.value = 20
  showCompile.value    = false
  expandedFiles.value  = new Set()
  inlineFileContents.value = {}
  copiedFiles.value    = new Set()
  currentTaskId.value  = ''
  tokenUsage.value     = createEmptyTokenUsage()
  activeStopPolling?.()
  activeStopPolling = null
  if (isCurrentAccount() && workspaceStateKey.value) workspaceStore.clearState(workspaceStateKey.value)
}

function shortPath(fullPath) {
  // Show only the last two path segments
  return fullPath.replace(/\\/g, '/').split('/').slice(-2).join('/')
}

async function selectGitRepository() {
  try {
    const response = await globalThis.fetch('http://127.0.0.1:9999/select-folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Select Git repository' }),
    })
    const data = await response.json()
    if (response.ok && data.path) {
      gitRepositoryPath.value = data.path
      return
    }
    if (data.error) throw new Error(data.error)
  } catch (error) {
    agentResult.value = {
      findings: [],
      counts: { critical: 0, major: 0, minor: 0, info: 0 },
      score: 0,
      error: error.message || 'Git repository folder selection failed',
    }
  }
}

// Toggle inline file preview
async function toggleInlineFile(filePath) {
  const set = new Set(expandedFiles.value)
  if (set.has(filePath)) {
    set.delete(filePath)
  } else {
    set.add(filePath)
    if (!inlineFileContents.value[filePath]) {
      inlineFileContents.value = { ...inlineFileContents.value, [filePath]: 'Loading...' }
      try {
        const res = await globalThis.fetch(`/api/v1/files/content?path=${encodeURIComponent(filePath)}`)
        let text = res.ok ? await res.text() : '(File content unavailable)'
        // If the content is JSON (fallback when LLM output is truncated), try to extract the matching field
        text = extractCodeFromJson(text, filePath)
        inlineFileContents.value = { ...inlineFileContents.value, [filePath]: text }
      } catch {
        inlineFileContents.value = { ...inlineFileContents.value, [filePath]: '(Load failed)' }
      }
    }
  }
  expandedFiles.value = set
}

/**
 * If the text is JSON (fallback when LLM output is truncated), try to extract the matching field.
 * Use `header_file` for .h files and `source_file` for .cpp files.
 */
function extractCodeFromJson(text, filePath) {
  const trimmed = text.trimStart()
  if (!trimmed.startsWith('{')) return text  // Not JSON, return as-is
  try {
    const parsed = JSON.parse(text)
    const ext = filePath.split('.').pop()
    if (ext === 'h' && parsed.header_file) return parsed.header_file
    if (ext === 'cpp' && parsed.source_file) return parsed.source_file
    return text
  } catch {
    // JSON is truncated, extract with regex
    const isHeader = filePath.endsWith('.h')
    const key = isHeader ? 'header_file' : 'source_file'
    const m = text.match(new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)`))
    if (m) {
      try { return JSON.parse('"' + m[1] + '"') } catch { return m[1].replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\"/g, '"') }
    }
    return text
  }
}

async function copyInlineFile(filePath) {
  const content = inlineFileContents.value[filePath] || ''
  await globalThis.navigator.clipboard.writeText(content)
  const set = new Set(copiedFiles.value)
  set.add(filePath)
  copiedFiles.value = set
  globalThis.setTimeout(() => {
    const s = new Set(copiedFiles.value)
    s.delete(filePath)
    copiedFiles.value = s
  }, 2000)
}


function downloadCurrentFile() {
  downloadFile(codeDialogFilePath.value)
}

function downloadFile(filePath) {
  const url = `/api/v1/files/download?path=${encodeURIComponent(filePath)}`
  const a   = globalThis.document.createElement('a')
  a.href    = url
  a.download = shortPath(filePath).split('/').pop()
  a.click()
}

function toggleGeneratedFile(file) {
  const set = new Set(expandedFiles.value)
  if (set.has(file.filename)) set.delete(file.filename)
  else set.add(file.filename)
  expandedFiles.value = set
}

async function copyGeneratedFile(file) {
  await globalThis.navigator.clipboard.writeText(file.content || '')
  const set = new Set(copiedFiles.value)
  set.add(file.filename)
  copiedFiles.value = set
  globalThis.setTimeout(() => {
    const next = new Set(copiedFiles.value)
    next.delete(file.filename)
    copiedFiles.value = next
  }, 2000)
}

function downloadText(filename, content, mediaType = 'text/plain') {
  const blob = new globalThis.Blob([content || ''], { type: `${mediaType};charset=utf-8` })
  const url = globalThis.URL.createObjectURL(blob)
  const anchor = globalThis.document.createElement('a')
  anchor.href = url
  anchor.download = filename
  anchor.click()
  globalThis.URL.revokeObjectURL(url)
}

function downloadGeneratedFile(file) {
  downloadText(file.filename, file.content, file.media_type || 'text/plain')
}

function downloadReviewReport() {
  downloadText('review-report.md', agentResult.value?.report_markdown || '', 'text/markdown')
}

function waitForAgentTask(startPolling) {
  return new Promise(resolve => {
    if (!isCurrentAccount()) { resolve(null); return }
    activeTaskResolver = resolve
    activeStopPolling = startPolling(data => {
      if (!isCurrentAccount()) return
      taskProgress.value = data.progress ?? 0
      loadingMsg.value = data.message || 'Processing...'
      if ((props.agent.id === 3 || props.agent.id === 4) && Array.isArray(data.workflow_nodes)) {
        reviewWorkflowNodes.value = data.workflow_nodes.map(node => ({ ...node }))
      }
      if (props.agent.id === 4 && data.approval) {
        reviewApprovalState.value = { ...data.approval }
      }
      if (data.token_usage) tokenUsage.value = normalizeTokenUsage(data.token_usage)
      if (['completed', 'failed', 'cancelled'].includes(data.status)) {
        activeStopPolling?.()
        activeStopPolling = null
        activeTaskResolver = null
        resolve(data)
      }
    })
  })
}

function isAWSAuthError(error) {
  return Boolean(error?.message?.includes('AWS_AUTH_REQUIRED'))
}

async function handleDriver() {
  if (!isCurrentAccount() || isLoading.value) return
  isCancelling.value = false
  isLoading.value = true
  agentResult.value = null
  resultContent.value = ''
  taskProgress.value = 0
  reviewWorkflowNodes.value = []
  tokenUsage.value = createEmptyTokenUsage()
  loadingMsg.value = 'Uploading the specification...'

  try {
    const created = await apiCreateDriverTask(uploadedFile.value, {
      deviceName: driverDeviceName.value,
      interface: driverInterface.value,
      mcuFamily: driverMcuFamily.value,
      platform: driverMcuFamily.value,
      requirements: userPrompt.value,
    })
    if (!isCurrentAccount()) return
    currentTaskId.value = created.task_id
    taskProgress.value = 4
    const final = await waitForAgentTask(callback => apiPollDriverTask(created.task_id, callback))
    if (!isCurrentAccount()) return
    tokenUsage.value = normalizeTokenUsage(final.result?.token_usage || final.token_usage)
    if (final.status === 'completed') {
      agentResult.value = final.result || {}
    } else {
      agentResult.value = {
        files: [],
        validation: { passed: false, warnings: [] },
        error: final.error || final.message || 'Driver generation failed',
      }
    }
  } catch (error) {
    if (!isCurrentAccount()) return
    if (isAWSAuthError(error)) {
      showAWSSSOModal.value = true
      pendingRetryFn.value = handleDriver
      return
    }
    agentResult.value = {
      files: [],
      validation: { passed: false, warnings: [] },
      error: error.message || 'Driver generation failed',
    }
  } finally {
    if (isCurrentAccount()) {
      isLoading.value = false
      currentTaskId.value = ''
      taskProgress.value = 0
    }
  }
}

function createEmptyTokenUsage() {
  return {
    input_tokens: 0,
    output_tokens: 0,
    total_tokens: 0,
    cache_creation_input_tokens: 0,
    cache_read_input_tokens: 0,
  }
}

function normalizeTokenUsage(usage) {
  const normalized = createEmptyTokenUsage()
  if (!usage || typeof usage !== 'object') return normalized
  for (const key of Object.keys(normalized)) {
    const value = Number(usage[key])
    normalized[key] = Number.isFinite(value) && value > 0 ? Math.floor(value) : 0
  }
  return normalized
}

async function handleReview() {
  if (!isCurrentAccount() || isLoading.value) return
  isCancelling.value = false
  isLoading.value = true
  agentResult.value = null
  resultContent.value = ''
  taskProgress.value = 0
  reviewWorkflowNodes.value = []
  const hasGitSource = Boolean(gitRepositoryPath.value.trim())
  const hasPullRequest = Boolean(bitbucketRepo.value.trim() && Number(bitbucketPrId.value) > 0)
  loadingMsg.value = hasGitSource && hasPullRequest
    ? 'Reading Git and Bitbucket pull request changes...'
    : (hasPullRequest ? 'Reading Bitbucket pull request diff...' : (hasGitSource ? 'Reading Git repository changes...' : 'Uploading source files...'))

  try {
    const created = await apiCreateReviewTask(uploadedFiles.value, {
      reviewType: reviewType.value,
      standards: ['MISRA-C:2012'],
      focus: userPrompt.value,
      requireApproval: reviewRequireApproval.value,
      approvalChannels: reviewApprovalChannels.value,
      approvalRecipients: reviewApprovalRecipients.value.split(',').map(item => item.trim()).filter(Boolean),
      gitRepositoryPath: gitRepositoryPath.value.trim(),
      gitBaseRef: gitBaseRef.value.trim() || 'HEAD~1',
      gitTargetRef: gitTargetRef.value.trim() || 'WORKTREE',
      gitIncludeUntracked: gitIncludeUntracked.value,
      bitbucketRepo: bitbucketRepo.value.trim(),
      bitbucketPrId: Number(bitbucketPrId.value) || '',
      jiraProject: jiraProject.value.trim(),
      jiraJql: jiraJql.value.trim(),
      jiraIssueKeys: jiraIssueKeys.value.split(',').map(item => item.trim().toUpperCase()).filter(Boolean),
      jiraStatus: jiraStatus.value.trim(),
      jiraMaxResults: Math.max(1, Math.min(Number(jiraMaxResults.value) || 20, 100)),
    })
    if (!isCurrentAccount()) return
    currentTaskId.value = created.task_id
    taskProgress.value = 4
    const final = await waitForAgentTask(callback => apiPollReviewTask(created.task_id, callback))
    if (!isCurrentAccount()) return
    if (final.status === 'completed') {
      agentResult.value = final.result || {}
    } else {
      agentResult.value = {
        findings: [],
        counts: { critical: 0, major: 0, minor: 0, info: 0 },
        score: 0,
        error: final.error || final.message || 'Code review failed',
      }
    }
  } catch (error) {
    if (!isCurrentAccount()) return
    if (isAWSAuthError(error)) {
      showAWSSSOModal.value = true
      pendingRetryFn.value = handleReview
      return
    }
    agentResult.value = {
      findings: [],
      counts: { critical: 0, major: 0, minor: 0, info: 0 },
      score: 0,
      error: error.message || 'Code review failed',
    }
  } finally {
    if (isCurrentAccount()) {
      isLoading.value = false
      currentTaskId.value = ''
      taskProgress.value = 0
    }
  }
}

async function submitReviewApproval(decision) {
  if (!isCurrentAccount() || isReviewApprovalSubmitting.value || !currentTaskId.value || !reviewApprovalState.value.token) return
  const taskId = currentTaskId.value
  isReviewApprovalSubmitting.value = true
  try {
    await apiApproveReviewTask(
      taskId,
      decision,
      reviewApprovalState.value.token,
      reviewApprovalComment.value,
    )
    if (!isCurrentAccount() || currentTaskId.value !== taskId) return
    reviewApprovalState.value = {
      ...reviewApprovalState.value,
      status: decision,
      decision,
      comment: reviewApprovalComment.value,
    }
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== taskId) return
    agentResult.value = {
      findings: [],
      counts: { critical: 0, major: 0, minor: 0, info: 0 },
      score: 0,
      error: error.message || 'Review approval submission failed',
    }
  } finally {
    if (isCurrentAccount() && currentTaskId.value === taskId) isReviewApprovalSubmitting.value = false
  }
}

async function handleCancel() {
  if (!isCurrentAccount() || !currentTaskId.value || isCancelling.value) return
  const taskId = currentTaskId.value
  isCancelling.value = true
  try {
    const response = props.agent.id === 3
      ? await apiCancelDriverTask(taskId)
      : await apiCancelReviewTask(taskId)
    if (!isCurrentAccount() || currentTaskId.value !== taskId || !isLoading.value) return
    if (['completed', 'failed', 'cancelled'].includes(response.status)) {
      activeStopPolling?.()
      activeStopPolling = null
      activeTaskResolver?.(response)
      activeTaskResolver = null
    } else {
      loadingMsg.value = 'Cancellation is still processing. Continuing to monitor the task.'
    }
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== taskId || !isLoading.value) return
    loadingMsg.value = `${error.message || 'Task cancellation failed.'} Continuing to monitor the task. You can retry cancellation.`
  } finally {
    if (isCurrentAccount() && (!currentTaskId.value || currentTaskId.value === taskId)) isCancelling.value = false
  }
}

// Unit test flow
async function handleUnittest() {
  isLoading.value      = true
  unittestResult.value = null
  taskProgress.value   = 0
  showCompile.value    = false
  loadingMsg.value     = 'Uploading file, creating task...'

  try {
    // 1. Upload the file and get task_id (step 0 is active during upload)
    taskProgress.value = 0
    const created = await apiGenerateTests(uploadedFile.value, { layer: 'auto', framework: 'gtest' })
    // Upload complete, move into the "Generate test code" stage
    taskProgress.value = 11
    loadingMsg.value = `Task created (${created.task_id.slice(0, 8)}...), generating...`

    // 2. Poll for task status
    let final = null
    const stopPolling = apiPollTask(created.task_id, (data) => {
      taskProgress.value = data.progress ?? 0
      loadingMsg.value   = data.message || 'Processing...'
      if (data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled') {
        final = data
      }
    })

    // Wait for task completion
    while (!final) {
      await new Promise(resolve => globalThis.setTimeout(resolve, 500))
    }
    stopPolling()

    // 3. Show results
    unittestResult.value = {
      compile_success: final.result?.compile_success ?? false,
      files_processed: final.result?.files_processed ?? 0,
      tests_generated: final.result?.tests_generated ?? 0,
      written_files:   final.result?.written_files   ?? [],
      compile_output:  final.result?.compile_output  ?? '',
      error:           final.error ?? null,
    }
    showCompile.value = !unittestResult.value.compile_success

  } catch (e) {
    // Check if this is an AWS authentication error
    if (e.message && e.message.includes('AWS_AUTH_REQUIRED')) {
      // Show AWS SSO login modal
      showAWSSSOModal.value = true
      pendingRetryFn.value = handleUnittest
      isLoading.value = false
      return
    }

    unittestResult.value = {
      compile_success: false,
      files_processed: 0,
      tests_generated: 0,
      written_files:   [],
      compile_output:  '',
      error: e.message || 'Request failed',
    }
  } finally {
    isLoading.value    = false
    taskProgress.value = 0
  }
}

// Unified entry point
async function handleRun() {
  if (props.agent.id === 2) {
    return handleUnittest()
  }
  if (props.agent.id === 3) return handleDriver()
  if (props.agent.id === 4) return handleReview()
}

async function copyResult() {
  await globalThis.navigator.clipboard.writeText(resultContent.value)
  copied.value = true
  globalThis.setTimeout(() => copied.value = false, 2000)
}

// AWS SSO login handlers
function handleAWSSSOSuccess() {
  showAWSSSOModal.value = false
  // Retry the pending operation
  if (pendingRetryFn.value) {
    const retryFn = pendingRetryFn.value
    pendingRetryFn.value = null
    retryFn()
  }
}

function handleAWSSSOClose() {
  showAWSSSOModal.value = false
  pendingRetryFn.value = null
}
</script>

<style scoped>
.workspace {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: #f8f9fb;
}

/* Topbar */
.workspace-topbar {
  height: 44px;
  background: white;
  border-bottom: 1px solid #eef0f3;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  flex-shrink: 0;
}

.topbar-left { display: flex; align-items: center; gap: 10px; }

.topbar-agent-icon {
  width: 34px; height: 34px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}

.topbar-title { font-size: 13px; font-weight: 600; color: #1f2937; }

.topbar-desc {
  font-size: 12px; color: #9ca3af;
  padding-left: 10px;
  border-left: 1px solid #e5e7eb;
}

.topbar-right { display: flex; align-items: center; gap: 8px; }

.reset-btn, .cancel-btn {
  display: flex; align-items: center; gap: 5px;
  padding: 5px 12px;
  border: 1px solid #e5e7eb;
  border-radius: 7px;
  background: white;
  font-size: 12px; color: #6b7280;
  cursor: pointer;
  transition: all 0.15s;
}
.reset-btn:hover { background: #f3f4f6; color: #374151; }
.cancel-btn { color: #b91c1c; border-color: #fecaca; background: #fff7f7; }
.cancel-btn:hover { background: #fee2e2; }

/* Body */
.workspace-body {
  flex: 1;
  display: flex;
  gap: 0;
  overflow: hidden;
}

/* Input Panel */
.input-panel {
  width: 320px;
  min-width: 320px;
  background: white;
  border-right: 1px solid #eef0f3;
  display: flex;
  flex-direction: column;
  gap: 0;
  overflow-y: auto;
  padding: 20px 16px 24px;
  scrollbar-width: thin;
  scrollbar-color: #e5e7eb transparent;
}

.panel-section { margin-bottom: 20px; }

.section-label {
  display: flex; align-items: center; gap: 5px;
  font-size: 11px; font-weight: 600;
  color: #6b7280; text-transform: uppercase;
  letter-spacing: 0.5px; margin-bottom: 8px;
}

/* Drop Zone */
.drop-zone {
  border: 1.5px dashed #d1d5db;
  border-radius: 10px;
  padding: 24px 16px;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
  background: #fafafa;
  position: relative;
}
.drop-zone:hover, .drop-zone.drag-over {
  border-color: #2563eb;
  background: #eff6ff;
}
.drop-zone.has-file {
  border-style: solid;
  border-color: #16a34a;
  background: #f0fdf4;
}

.drop-icon { color: #d1d5db; margin-bottom: 8px; }
.drop-text { font-size: 13px; color: #6b7280; margin-bottom: 4px; }
.drop-link { color: #2563eb; text-decoration: underline; }
.drop-hint { font-size: 11px; color: #9ca3af; }

.file-ok-icon { color: #16a34a; margin-bottom: 6px; }
.file-name { font-size: 13px; font-weight: 500; color: #1f2937; margin-bottom: 2px; word-break: break-all; }
.file-size { font-size: 11px; color: #9ca3af; }

.remove-file {
  position: absolute; top: 8px; right: 8px;
  width: 20px; height: 20px;
  display: flex; align-items: center; justify-content: center;
  border: none; background: #fee2e2; border-radius: 50%;
  color: #ef4444; cursor: pointer;
}

/* Prompt input */
.prompt-input {
  width: 100%;
  border: 1.5px solid #e5e7eb;
  border-radius: 8px;
  padding: 9px 11px;
  font-size: 13px;
  color: #374151;
  resize: vertical;
  outline: none;
  font-family: inherit;
  line-height: 1.5;
  transition: border-color 0.15s;
  background: #fafafa;
}
.prompt-input:focus { border-color: #2563eb; background: white; }
.prompt-input::placeholder { color: #c4c9d4; }

.field-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 8px;
}

.compact-input {
  width: 100%; min-width: 0; height: 34px;
  border: 1px solid #dfe3e8; border-radius: 6px;
  background: #fff; color: #374151;
  padding: 0 9px; font: inherit; font-size: 12px;
  outline: none;
}
.compact-input:focus { border-color: #2563eb; }
.field-span { grid-column: 1 / -1; }

/* Options */
.options-list { display: flex; flex-direction: column; gap: 8px; }
.option-item {
  display: flex; align-items: center; gap: 8px;
  font-size: 13px; color: #374151; cursor: pointer;
}
.option-item input[type=checkbox] { accent-color: #2563eb; width: 14px; height: 14px; }

/* Platform select */
.select-group { display: flex; flex-wrap: wrap; gap: 6px; }
.select-btn {
  padding: 4px 12px;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  font-size: 12px; color: #6b7280;
  background: white; cursor: pointer;
  transition: all 0.15s;
}
.select-btn.active {
  border-color: #2563eb; background: #eff6ff; color: #2563eb; font-weight: 500;
}

/* Run button */
.run-btn {
  width: 100%;
  display: flex; align-items: center; justify-content: center; gap: 7px;
  padding: 11px;
  background: #1e3a5f;
  color: white;
  border: none; border-radius: 10px;
  font-size: 14px; font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
  margin-top: auto;
}
.run-btn:hover:not(:disabled) { background: #2563eb; }
.run-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.run-btn.loading { background: #6b7280; }

.spinner {
  width: 14px; height: 14px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: white;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  display: inline-block;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* Result Panel */
.result-panel {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  scrollbar-width: thin;
  scrollbar-color: #e5e7eb transparent;
}

.token-usage-strip {
  display: grid;
  grid-template-columns: auto repeat(5, minmax(78px, 1fr));
  align-items: stretch;
  gap: 1px;
  margin-bottom: 16px;
  border: 1px solid #dfe3e8;
  border-radius: 8px;
  overflow: hidden;
  background: #dfe3e8;
}

.token-usage-heading,
.token-usage-item {
  min-width: 0;
  background: #fff;
  padding: 9px 12px;
}

.token-usage-heading {
  display: flex;
  align-items: center;
  color: #374151;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
}

.token-usage-item {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.token-usage-item span {
  color: #9ca3af;
  font-size: 10px;
}

.token-usage-item strong {
  overflow: hidden;
  color: #1f2937;
  font-size: 13px;
  text-overflow: ellipsis;
}

.token-usage-total strong { color: #1d4ed8; }

@media (max-width: 1050px) {
  .token-usage-strip {
    grid-template-columns: repeat(3, minmax(90px, 1fr));
  }

  .token-usage-heading { grid-column: 1 / -1; }
}

.result-empty {
  display: flex; flex-direction: column; align-items: center;
  padding: 60px 20px;
  text-align: center;
}

.result-empty-icon {
  width: 64px; height: 64px;
  border-radius: 18px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 16px;
}

.result-empty-title { font-size: 15px; font-weight: 600; color: #1f2937; margin-bottom: 6px; }
.result-empty-sub { font-size: 13px; color: #9ca3af; margin-bottom: 28px; }

.result-steps {
  display: flex; flex-direction: column; gap: 10px;
  text-align: left; width: 100%; max-width: 320px;
}

.result-step {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 14px;
  background: white; border: 1px solid #e5e7eb; border-radius: 8px;
}

.step-num {
  width: 20px; height: 20px;
  background: #1e3a5f; color: white;
  border-radius: 50%; font-size: 11px; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}

.step-text { font-size: 13px; color: #374151; }

/* Loading */
.result-loading { padding: 24px; }

/* Updated loading */
.loading-title-row {
  display: flex; align-items: center; gap: 16px;
  margin-bottom: 16px;
}

.loading-spinner-wrap {
  position: relative; width: 48px; height: 48px; flex-shrink: 0;
}

.loading-ring {
  width: 48px; height: 48px;
  transform: rotate(-90deg);
}

.ring-bg {
  fill: none; stroke: #e5e7eb; stroke-width: 3;
}

.ring-progress {
  fill: none; stroke: #2563eb; stroke-width: 3;
  stroke-dasharray: 94.2;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.5s ease;
}

.loading-pct {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  font-size: 10px; font-weight: 700; color: #2563eb;
}

.loading-msg-col { display: flex; flex-direction: column; gap: 4px; }
.loading-msg-title { font-size: 14px; font-weight: 600; color: #1f2937; }
.loading-msg-sub { font-size: 12px; color: #6b7280; word-break: break-word; }

/* Horizontal pipeline flow */
.pipeline-flow {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: nowrap;
  gap: 0;
  margin-top: 20px;
  padding: 8px 4px;
  overflow-x: auto;
}

.pipeline-node {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 72px;
  flex-shrink: 0;
  transition: all 0.3s;
}

.pipeline-icon-wrap {
  width: 40px; height: 40px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  border: 2px solid #e5e7eb;
  background: #f9fafb;
  transition: all 0.3s;
  flex-shrink: 0;
}

/* done state */
.pipeline-node.done .pipeline-icon-wrap {
  border-color: #16a34a;
  background: #f0fdf4;
}
.pipeline-node.done .pipeline-label {
  color: #166534;
  font-weight: 500;
}
.pipe-check { color: #16a34a; }
.pipe-fail { color: #dc2626; font-size: 20px; font-weight: 700; line-height: 1; }

/* active state */
.pipeline-node.active .pipeline-icon-wrap {
  border-color: #2563eb;
  background: #eff6ff;
  box-shadow: 0 0 0 3px rgba(37,99,235,0.15);
}
.pipeline-node.active .pipeline-label {
  color: #1d4ed8;
  font-weight: 600;
}

/* failed state */
.pipeline-node.fail .pipeline-icon-wrap {
  border-color: #fca5a5;
  background: #fef2f2;
}
.pipeline-node.fail .pipeline-label {
  color: #b91c1c;
  font-weight: 600;
}

/* pending state */
.pipeline-node.pending .pipeline-icon-wrap {
  border-color: #e5e7eb;
  background: #f9fafb;
}
.pipeline-node.pending .pipeline-label {
  color: #9ca3af;
}

.pipeline-label {
  font-size: 11px;
  text-align: center;
  line-height: 1.3;
  color: #6b7280;
  white-space: nowrap;
}

/* Spinning animation circle */
.pipe-spinner {
  width: 18px; height: 18px;
  border: 2px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  display: inline-block;
  animation: spin 0.8s linear infinite;
}

.pipe-empty {
  width: 10px; height: 10px;
  border-radius: 50%;
  background: #d1d5db;
  display: inline-block;
}

/* Connector arrow */
.pipeline-arrow {
  display: flex; align-items: center;
  flex-shrink: 0;
  margin: 0 2px;
  margin-bottom: 22px; /* Align to the icon center (40px icon + ~22px label) */
}
.pipeline-arrow svg line,
.pipeline-arrow svg polyline {
  stroke: #d1d5db;
  transition: stroke 0.3s;
}
.pipeline-arrow.lit svg line,
.pipeline-arrow.lit svg polyline {
  stroke: #16a34a;
}

@keyframes spin { to { transform: rotate(360deg); } }

@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
@keyframes shimmer { from { opacity: 0.5; } to { opacity: 1; } }

/* Result content */
.result-content {
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  overflow: hidden;
}

.field-error {
  display: block;
  margin: 5px 0 0;
  color: #b91c1c;
  font-size: 11px;
  line-height: 1.4;
}

.result-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid #e5e7eb;
  background: #fafafa;
}

.result-header-left { display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 600; color: #1f2937; }

.copy-btn {
  display: flex; align-items: center; gap: 5px;
  padding: 4px 12px;
  border: 1px solid #e5e7eb; border-radius: 6px;
  background: white; font-size: 12px; color: #6b7280;
  cursor: pointer; transition: all 0.15s;
}
.copy-btn:hover { background: #f3f4f6; color: #374151; }

.result-code {
  padding: 20px;
  font-size: 12.5px;
  font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  line-height: 1.7;
  color: #1f2937;
  white-space: pre-wrap;
  word-break: break-word;
  margin: 0;
  overflow-x: auto;
}

/* Structured Agent result styles */
.unittest-result, .agent-result {
  display: flex; flex-direction: column; gap: 16px;
}

.stats-row {
  display: flex; gap: 12px;
}
.stat-card {
  flex: 1; display: flex; flex-direction: column; align-items: center;
  gap: 4px; padding: 14px 10px;
  background: white; border: 1px solid #e5e7eb; border-radius: 10px;
}
.stat-card.stat-ok { border-color: #16a34a; background: #f0fdf4; }
.stat-card.stat-ok .el-icon { color: #16a34a; }
.stat-card.stat-fail { border-color: #ef4444; background: #fef2f2; }
.stat-card.stat-fail .el-icon { color: #ef4444; }
.stat-label { font-size: 11px; color: #9ca3af; }
.stat-value { font-size: 15px; font-weight: 700; color: #1f2937; }
.score-value { font-size: 20px; }
.review-stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); }
.severity-critical { border-color: #fecaca; background: #fff7f7; }
.severity-major { border-color: #fed7aa; background: #fffaf5; }
.severity-minor { border-color: #fde68a; background: #fffdf2; }

.section-title {
  display: flex; align-items: center; gap: 6px;
  font-size: 12px; font-weight: 600; color: #374151;
  text-transform: uppercase; letter-spacing: 0.4px;
  margin-bottom: 8px; user-select: none;
}

.file-list-section, .compile-section {
  background: white; border: 1px solid #e5e7eb;
  border-radius: 10px; padding: 14px 16px;
}

.file-item {
  display: flex; align-items: center; gap: 8px;
  padding: 7px 0;
  border-bottom: 1px solid #f3f4f6;
  font-size: 13px;
}
.file-item:last-child { border-bottom: none; }
.file-item-name { flex: 1; color: #374151; word-break: break-all; }

.dl-btn, .view-btn {
  flex-shrink: 0; display: flex; align-items: center; gap: 4px;
  padding: 3px 10px; border-radius: 5px;
  font-size: 11px; cursor: pointer; transition: all 0.15s;
}
.dl-btn {
  background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe;
}
.dl-btn:hover { background: #dbeafe; }
.view-btn {
  background: #f9fafb; color: #6b7280; border: 1px solid #e5e7eb;
}
.view-btn:hover { background: #f3f4f6; color: #374151; }

/* Inline file preview */
.file-item-wrap { border-bottom: 1px solid #f3f4f6; }
.file-item-wrap:last-child { border-bottom: none; }

.inline-code-wrap {
  border-top: 1px solid #e5e7eb;
  background: #0f172a;
  border-radius: 0 0 8px 8px;
  overflow: hidden;
}

.inline-code-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 6px 14px;
  background: #1e293b;
  font-size: 11px; color: #94a3b8;
}

.copy-small-btn {
  display: flex; align-items: center; gap: 4px;
  padding: 2px 8px;
  border: 1px solid #334155; border-radius: 4px;
  background: transparent; color: #94a3b8;
  font-size: 11px; cursor: pointer;
  transition: all 0.15s;
}
.copy-small-btn:hover { background: #334155; color: #e2e8f0; }

.inline-code {
  padding: 14px 16px;
  font-size: 11.5px;
  font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  line-height: 1.6;
  color: #e2e8f0;
  white-space: pre !important;
  word-break: normal;
  word-wrap: normal;
  overflow-wrap: normal;
  margin: 0;
  max-height: 400px;
  overflow: auto;
  scrollbar-width: thin;
  scrollbar-color: #334155 transparent;
  display: block;
  tab-size: 4;
}


.compile-output {
  font-size: 11.5px; font-family: 'Consolas', monospace;
  white-space: pre !important;
  word-break: normal; word-wrap: normal; overflow-wrap: normal;
  padding: 12px; border-radius: 6px; margin-top: 8px;
  max-height: 300px; overflow: auto;
  line-height: 1.6;
  display: block;
  tab-size: 4;
}
.compile-ok  { background: #f0fdf4; color: #166534; }
.compile-error { background: #fef2f2; color: #991b1b; }

.error-box {
  display: flex; align-items: flex-start; gap: 8px;
  padding: 12px 14px;
  background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px;
  color: #991b1b; font-size: 13px;
}

.warning-list {
  padding: 14px 16px;
  background: #fffdf2;
  border: 1px solid #fde68a;
  border-radius: 8px;
}
.warning-row { font-size: 12px; color: #854d0e; padding: 4px 0; }

.review-summary {
  padding: 12px 14px;
  background: #fff;
  border-left: 3px solid #2563eb;
  color: #374151;
  font-size: 13px;
  line-height: 1.6;
}

.review-approval-card { margin-top: 14px; padding: 13px; border: 1px solid #fcd34d; border-radius: 8px; background: #fffbeb; }
.review-approval-heading { display: flex; flex-direction: column; gap: 3px; color: #92400e; font-size: 12px; }
.review-approval-heading span { color: #a16207; font-size: 10px; }
.review-diff-section { margin: 12px 0; }
.review-diff-preview { max-height: 280px; margin: 9px 0; padding: 10px; overflow: auto; border: 1px solid #fde68a; border-radius: 6px; color: #334155; background: #fff; font: 11px/1.45 Consolas, monospace; white-space: pre; }
.review-diff-section .review-diff-preview { max-height: 420px; border-color: #dbe3ed; background: #0f172a; color: #dbeafe; }
.approval-comment { width: 100%; box-sizing: border-box; padding: 8px; border: 1px solid #fcd34d; border-radius: 6px; color: #451a03; background: #fff; font: inherit; font-size: 11px; resize: vertical; }
.review-approval-actions { display: flex; justify-content: flex-end; gap: 7px; margin-top: 8px; }
.review-approval-actions button { padding: 7px 10px; border-radius: 6px; cursor: pointer; font: inherit; font-size: 11px; font-weight: 600; }
.approval-reject-btn { border: 1px solid #fecaca; color: #b91c1c; background: #fff; }
.approval-approve-btn { border: 1px solid #16a34a; color: #fff; background: #16a34a; }
.review-approval-actions button:disabled { opacity: .55; cursor: wait; }
.review-approval-warning, .review-approval-channel { display: block; margin-top: 7px; color: #92400e; font-size: 10px; line-height: 1.4; }
.review-approval-channel { color: #a16207; }
.approval-toggle { display: flex; align-items: center; gap: 6px; margin-top: 8px; color: #475569; font-size: 11px; }
.approval-toggle input, .review-approval-fields input[type='checkbox'] { accent-color: #2563eb; }
.review-approval-fields { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: 7px; color: #64748b; font-size: 10px; }
.review-approval-fields label { display: inline-flex; align-items: center; gap: 3px; }
.review-approval-fields .compact-input { min-width: 220px; flex: 1; }
.git-review-section { border-top: 1px solid #eef2f7; }
.git-path-row { display: flex; align-items: center; gap: 6px; }
.git-path-row .compact-input { min-width: 0; flex: 1; }
.folder-picker-btn { flex: 0 0 auto; padding: 7px 10px; border: 1px solid #bfdbfe; border-radius: 6px; color: #1d4ed8; background: #eff6ff; font: inherit; font-size: 11px; cursor: pointer; }
.folder-picker-btn:hover { background: #dbeafe; }
.folder-picker-btn:disabled { opacity: .55; cursor: wait; }
.git-ref-grid { margin-top: 7px; }
.git-untracked-toggle { margin-top: 7px; }
.git-help { display: block; margin-top: 6px; color: #94a3b8; font-size: 10px; line-height: 1.4; }
.review-context-section { margin-top: 2px; padding-top: 12px; border-top: 1px solid #e2e8f0; }
.review-context-heading { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; margin-bottom: 8px; }
.review-context-title { color: #334155; font-size: 11px; font-weight: 700; letter-spacing: .45px; text-transform: uppercase; }
.review-context-heading small { color: #94a3b8; font-size: 10px; }
.integration-status { display: flex; align-items: center; gap: 5px; margin: -2px 0 8px; color: #15803d; font-size: 10px; }
.integration-status.unavailable { color: #b45309; }
.integration-status-dot { width: 6px; height: 6px; border-radius: 50%; background: #22c55e; }
.integration-status.unavailable .integration-status-dot { background: #f59e0b; }
.jira-review-section { border-top: 1px solid #eef2f7; }
.jira-jql-input { min-height: 44px; margin-top: 7px; }
.jira-context-section { margin: 12px 0; padding: 10px; border: 1px solid #dbeafe; border-radius: 7px; background: #f8fbff; }
.jira-context-item { display: flex; align-items: baseline; gap: 7px; padding: 5px 0; border-bottom: 1px solid #e5eefb; color: #475569; font-size: 11px; }
.jira-context-item:last-child { border-bottom: 0; }
.jira-context-item strong { color: #1d4ed8; font-family: Consolas, monospace; }
.jira-context-item span { min-width: 0; flex: 1; }
.jira-context-item small { color: #64748b; }

.findings-list { display: flex; flex-direction: column; gap: 10px; }
.finding-item {
  padding: 13px 14px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-left-width: 3px;
  border-radius: 6px;
}
.finding-critical { border-left-color: #dc2626; }
.finding-major { border-left-color: #ea580c; }
.finding-minor { border-left-color: #ca8a04; }
.finding-info { border-left-color: #2563eb; }
.finding-head { display: flex; align-items: center; gap: 8px; min-width: 0; }
.finding-head strong { font-size: 13px; color: #1f2937; }
.severity-badge {
  flex-shrink: 0;
  font-size: 10px; font-weight: 700; text-transform: uppercase;
  color: #4b5563; background: #f3f4f6;
  padding: 2px 6px; border-radius: 4px;
}
.finding-location {
  margin-left: auto; min-width: 0;
  font: 11px 'Consolas', monospace; color: #6b7280;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.finding-item p { margin: 9px 0; font-size: 12px; line-height: 1.6; color: #4b5563; }
.finding-rule { display: inline-block; font-size: 11px; color: #1d4ed8; margin-bottom: 7px; }
.finding-suggestion { font-size: 12px; line-height: 1.5; color: #374151; }
.empty-findings {
  padding: 24px; text-align: center; color: #166534;
  background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px;
}
.report-actions { display: flex; justify-content: flex-end; }

.dialog-code {
  font-size: 12px; font-family: 'Consolas', monospace;
  white-space: pre !important;
  word-break: normal; word-wrap: normal; overflow-wrap: normal;
  line-height: 1.6; max-height: 65vh; overflow: auto;
  background: #f8f9fb; padding: 16px; border-radius: 6px;
  margin: 0; display: block; tab-size: 4;
}
</style>
