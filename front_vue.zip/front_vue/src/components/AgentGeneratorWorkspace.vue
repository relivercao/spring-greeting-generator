<template>
  <div class="generator-page">
    <div class="generator-header">
      <div>
        <div class="eyebrow">
          AGENT BUILDER
        </div>
        <h1>Generate a reusable Agent</h1>
        <p>Describe the workflow, preview the generated system prompt, and bind it to canonical knowledge.</p>
        <p
          v-if="parserStatus"
          class="parser-status"
          :class="{ unavailable: !parserStatus.available }"
        >
          Code parser: {{ parserStatus.available ? 'ready' : 'fallback mode' }} - Tree-sitter 0.21.1, Acorn 8.18.0, JSONC 3.3.1
        </p>
      </div>
      <button
        class="refresh-button"
        type="button"
        :disabled="isRefreshing"
        @click="refreshKnowledgeDocuments(true)"
      >
        <el-icon><Refresh /></el-icon>
        {{ isRefreshing ? 'Refreshing...' : 'Refresh knowledge' }}
      </button>
    </div>

    <div class="generator-grid">
      <section class="builder-card">
        <div class="card-title">
          Agent requirements
        </div>
        <label
          class="field-label"
          for="agent-name"
        >Agent name</label>
        <input
          id="agent-name"
          v-model="form.name"
          class="text-input"
          maxlength="120"
          placeholder="For example: Register Triage Agent"
        >

        <label
          class="field-label"
          for="agent-goal"
        >Primary goal</label>
        <textarea
          id="agent-goal"
          v-model="form.goal"
          class="text-area compact"
          maxlength="2000"
          rows="3"
          placeholder="What outcome should this Agent deliver?"
        />

        <label
          class="field-label"
          for="agent-prompt"
        >Prompt and operating rules</label>
        <textarea
          id="agent-prompt"
          v-model="form.prompt"
          class="text-area"
          maxlength="20000"
          rows="9"
          placeholder="Describe inputs, steps, constraints, expected output, and verification requirements."
        />

        <div class="field-row llm-settings">
          <div class="field-grow">
            <label
              class="field-label"
              for="agent-llm-provider"
            >Runtime provider</label>
            <select
              id="agent-llm-provider"
              v-model="form.llmProvider"
              class="select-input"
              @change="handleLlmProviderChange"
            >
              <option value="macode">
                Macode
              </option>
              <option value="bedrock">
                AWS Bedrock
              </option>
            </select>
          </div>
          <div class="field-grow">
            <label
              class="field-label"
              for="agent-llm-model"
            >Runtime model</label>
            <input
              id="agent-llm-model"
              v-model="form.llmModel"
              class="text-input"
              list="agent-llm-model-options"
              maxlength="200"
              placeholder="Select or enter a model"
            >
            <datalist id="agent-llm-model-options">
              <option
                v-for="model in modelOptions"
                :key="model"
                :value="model"
              >
                {{ model }}
              </option>
            </datalist>
          </div>
        </div>
        <small class="field-hint">This model is persisted with the generated Agent and used for future runs.</small>

        <div class="field-row output-settings">
          <div class="field-grow">
            <label
              class="field-label"
              for="agent-output-mode"
            >Output mode</label>
            <select
              id="agent-output-mode"
              v-model="form.outputMode"
              class="select-input"
            >
              <option value="text">
                Chat response
              </option>
              <option value="file">
                Downloadable file
              </option>
              <option value="both">
                Chat response and file
              </option>
            </select>
          </div>
          <div
            v-if="form.outputMode !== 'text'"
            class="field-grow"
          >
            <label
              class="field-label"
              for="agent-output-format"
            >File format</label>
            <select
              id="agent-output-format"
              v-model="form.outputFormat"
              class="select-input"
            >
              <option value="markdown">
                Markdown
              </option>
              <option value="text">
                Plain text
              </option>
              <option value="json">
                JSON
              </option>
              <option value="yaml">
                YAML
              </option>
              <option value="csv">
                CSV
              </option>
              <option value="c_source">
                C source
              </option>
              <option value="c_header">
                C header
              </option>
              <option value="python">
                Python
              </option>
            </select>
          </div>
        </div>
        <div v-if="form.outputMode !== 'text'">
          <label
            class="field-label"
            for="agent-output-filename"
          >File name</label>
          <input
            id="agent-output-filename"
            v-model="form.outputFilename"
            class="text-input"
            maxlength="120"
            placeholder="agent-output"
          >
        </div>

        <div class="field-row">
          <div class="field-grow">
            <label
              class="field-label"
              for="agent-icon"
            >Icon</label>
            <select
              id="agent-icon"
              v-model="form.icon"
              class="select-input"
            >
              <option value="MagicStick">
                Magic stick
              </option>
              <option value="Cpu">
                CPU
              </option>
              <option value="Connection">
                Connection
              </option>
              <option value="Finished">
                Checklist
              </option>
              <option value="Collection">
                Collection
              </option>
            </select>
          </div>
          <div class="field-grow">
            <label
              class="field-label"
              for="agent-color"
            >Color</label>
            <input
              id="agent-color"
              v-model="form.color"
              class="color-input"
              type="color"
            >
          </div>
        </div>

        <label class="field-label">Agent logo</label>
        <div class="logo-picker">
          <div
            class="logo-preview"
            :style="{ background: form.color + '18', color: form.color }"
          >
            <img
              v-if="form.logoUrl"
              :src="form.logoUrl"
              alt="Agent logo preview"
            >
            <el-icon v-else>
              <component :is="form.icon || 'MagicStick'" />
            </el-icon>
          </div>
          <div class="logo-picker-copy">
            <strong>{{ form.logoUrl ? 'Custom logo selected' : 'Default icon will be used' }}</strong>
            <small>PNG, JPEG, WebP, or SVG up to 5 MB</small>
          </div>
          <label class="secondary-button">
            <input
              type="file"
              accept=".png,.jpg,.jpeg,.webp,.svg"
              @change="handleLogoUpload"
            >
            {{ isUploadingLogo ? 'Uploading...' : 'Choose logo' }}
          </label>
          <button
            v-if="form.logoUrl"
            class="clear-button"
            type="button"
            @click="form.logoUrl = ''"
          >
            Clear
          </button>
        </div>

        <label
          class="field-label"
          for="agent-files"
        >Input files</label>
        <label
          class="file-drop"
          :class="{ uploading: isUploadingFile }"
        >
          <input
            id="agent-files"
            type="file"
            multiple
            accept=".c,.h,.cc,.cpp,.cxx,.hpp,.hxx,.py,.js,.jsx,.mjs,.cjs,.ts,.tsx,.md,.markdown,.txt,.json,.jsonc,.yaml,.yml,.xml,.csv,.pdf"
            @change="handleFileUpload"
          >
          <el-icon><Upload /></el-icon>
          <span>{{ isUploadingFile ? 'Uploading files...' : 'Add source, specification, or configuration files' }}</span>
          <small>Files are stored with the Agent and included as generation context.</small>
        </label>
        <div
          v-if="form.inputFiles.length"
          class="file-list"
        >
          <div
            v-for="file in form.inputFiles"
            :key="file.id"
            class="file-item"
          >
            <div class="file-item-copy">
              <strong>{{ file.name }}</strong><small>{{ formatSize(file.size) }} - {{ analysisLabel(file.code_analysis) }}</small>
            </div>
            <button
              class="icon-clear"
              type="button"
              title="Remove file"
              @click="removeInputFile(file.id)"
            >
              ×
            </button>
          </div>
        </div>

        <div class="input-heading">
          <div>
            <div class="card-title">
              Runtime inputs
            </div>
            <small>Define values the Agent must collect for each run.</small>
          </div>
          <button
            class="secondary-button"
            type="button"
            @click="addRuntimeInput"
          >
            <el-icon><Plus /></el-icon> Add input
          </button>
        </div>
        <div
          v-if="form.inputDefinitions.length"
          class="runtime-input-editor"
        >
          <div
            v-for="input in form.inputDefinitions"
            :key="input.id"
            class="runtime-input-row"
          >
            <div class="runtime-input-fields">
              <input
                v-model="input.id"
                class="text-input"
                maxlength="80"
                placeholder="Input id (for example target)"
                aria-label="Runtime input id"
              >
              <input
                v-model="input.label"
                class="text-input"
                maxlength="120"
                placeholder="Label"
                aria-label="Runtime input label"
              >
              <select
                v-model="input.type"
                class="select-input"
                aria-label="Runtime input type"
              >
                <option value="text">
                  Text
                </option>
                <option value="textarea">
                  Long text
                </option>
                <option value="number">
                  Number
                </option>
                <option value="boolean">
                  Yes or no
                </option>
                <option value="select">
                  Select
                </option>
                <option value="file">
                  Attached file
                </option>
              </select>
              <label class="runtime-required"><input
                v-model="input.required"
                type="checkbox"
              > Required</label>
              <input
                v-model="input.placeholder"
                class="text-input"
                maxlength="300"
                placeholder="Placeholder (optional)"
                aria-label="Runtime input placeholder"
              >
              <input
                v-if="input.type !== 'boolean' && input.type !== 'file'"
                v-model="input.default"
                class="text-input"
                maxlength="20000"
                placeholder="Default value (optional)"
                aria-label="Runtime input default"
              >
              <input
                v-if="input.type === 'select'"
                v-model="input.optionsText"
                class="text-input runtime-options"
                maxlength="2000"
                placeholder="Options, comma-separated"
                aria-label="Runtime input options"
              >
              <small
                v-if="input.type === 'file'"
                class="runtime-input-hint"
              >Uses a file already attached above.</small>
            </div>
            <button
              class="icon-clear"
              type="button"
              title="Remove runtime input"
              @click="removeRuntimeInput(input.id)"
            >
              ×
            </button>
          </div>
        </div>
        <div
          v-else
          class="empty-runtime-inputs"
        >
          No runtime inputs configured. The Agent will use the task message only.
        </div>

        <div class="skill-heading">
          <label
            class="field-label"
            for="agent-skills"
          >Skill attachments</label>
          <button
            class="secondary-button"
            type="button"
            @click="openSkillGenerator"
          >
            <el-icon><MagicStick /></el-icon> Generate a Skill
          </button>
        </div>
        <div class="market-skill-heading">
          <span class="field-label">Imported Skill Market skills</span>
          <button
            class="secondary-button"
            type="button"
            :disabled="isRefreshingMarketSkills"
            @click="refreshMarketSkills(true)"
          >
            {{ isRefreshingMarketSkills ? 'Refreshing...' : 'Refresh' }}
          </button>
        </div>
        <div
          v-if="marketSkills.length"
          class="market-skill-list"
        >
          <label
            v-for="skill in marketSkills"
            :key="skill.name"
            class="market-skill-item"
          >
            <input
              v-model="form.marketSkillNames"
              type="checkbox"
              :value="skill.name"
            >
            <span class="market-skill-copy">
              <strong>{{ skill.name }}</strong>
              <small>{{ skill.description || 'Installed Skill Market instructions' }}</small>
            </span>
          </label>
        </div>
        <div
          v-else
          class="market-skill-empty"
        >
          No Skill Market imports found. Install a skill in Skill Market, then refresh this list.
        </div>
        <small class="field-hint">Selected market skills are included when this Agent runs.</small>
        <label
          class="file-drop skill-drop"
          :class="{ uploading: isUploadingSkill || isAddingSkill }"
        >
          <input
            id="agent-skills"
            type="file"
            multiple
            accept=".md,.markdown,.txt,.json,.yaml,.yml,.xml,.zip"
            :disabled="isUploadingSkill || isAddingSkill"
            @change="handleSkillUpload"
          >
          <el-icon><Collection /></el-icon>
          <span>{{ isUploadingSkill || isAddingSkill ? 'Uploading skills...' : 'Attach skill instruction files' }}</span>
          <small>Markdown, text, YAML, JSON, XML, or a ZIP containing SKILL.md.</small>
        </label>
        <div
          v-if="form.skillFiles.length"
          class="file-list"
        >
          <div
            v-for="file in form.skillFiles"
            :key="file.id"
            class="file-item skill-file-item"
          >
            <div class="file-item-copy">
              <strong>{{ file.name }}</strong><small>{{ formatSize(file.size) }} · Skill</small>
            </div>
            <button
              class="icon-clear"
              type="button"
              title="Remove skill"
              @click="removeSkillFile(file.id)"
            >
              ×
            </button>
          </div>
        </div>
        <section
          v-if="showSkillGenerator"
          class="skill-generator-panel"
        >
          <div class="card-title">
            Generate Skill
          </div>
          <label
            class="field-label"
            for="generated-skill-name"
          >Skill name</label>
          <input
            id="generated-skill-name"
            v-model="skillDraft.name"
            class="text-input"
            maxlength="64"
            pattern="[a-z0-9]+(-[a-z0-9]+)*"
            placeholder="firmware-bug-triage"
            :disabled="isGeneratingSkill || isAddingSkill"
          >
          <label
            class="field-label"
            for="generated-skill-goal"
          >Skill goal</label>
          <textarea
            id="generated-skill-goal"
            v-model="skillDraft.goal"
            class="text-area compact"
            maxlength="5000"
            rows="4"
            placeholder="Describe the reusable expertise, workflow, and expected result."
            :disabled="isGeneratingSkill || isAddingSkill"
          />
          <small class="field-hint">Uses the selected Agent Generator model: {{ form.llmProvider }} / {{ form.llmModel || providerDefaults[form.llmProvider] }}.</small>
          <div class="skill-draft-actions">
            <button
              class="secondary-button"
              type="button"
              :disabled="!canGenerateSkill"
              @click="handleGenerateSkill"
            >
              <span
                v-if="isGeneratingSkill"
                class="button-spinner skill-spinner"
              />
              <el-icon v-else>
                <MagicStick />
              </el-icon>
              {{ isGeneratingSkill ? 'Generating...' : skillDraft.content ? 'Regenerate' : 'Generate draft' }}
            </button>
            <button
              class="secondary-button skill-attach-button"
              type="button"
              :disabled="!skillDraft.content || isAddingSkill"
              @click="handleAttachGeneratedSkill"
            >
              {{ isAddingSkill ? 'Adding...' : 'Add to Agent' }}
            </button>
          </div>
          <p
            v-if="skillGenerationError"
            class="error-message"
          >
            {{ skillGenerationError }}
          </p>
          <div
            v-if="skillDraft.content"
            class="skill-draft-preview"
          >
            <strong>{{ skillDraft.name }} · {{ skillDraft.description }}</strong>
            <pre>{{ skillDraft.content }}</pre>
            <small v-if="skillDraft.warnings.length">{{ skillDraft.warnings.join(' ') }}</small>
          </div>
        </section>

        <div class="tool-heading">
          <div>
            <div class="card-title">
              External plugin tools
            </div>
            <small>Attach read-only MCP tools from the existing Claude Code tool layer.</small>
          </div>
          <button
            class="secondary-button"
            type="button"
            :disabled="isRefreshingTools"
            @click="refreshAgentTools(true)"
          >
            {{ isRefreshingTools ? 'Refreshing...' : 'Refresh tools' }}
          </button>
        </div>
        <div
          v-if="availableTools.length"
          class="tool-list"
        >
          <label
            v-for="tool in availableTools"
            :key="tool.name"
            class="tool-item"
          >
            <input
              v-model="form.selectedTools"
              type="checkbox"
              :value="tool.name"
            >
            <span class="tool-item-copy">
              <strong>{{ tool.name }}</strong>
              <small>{{ tool.server || 'mcp' }} · {{ tool.description }}</small>
              <small class="tool-runtime-hint">{{ tool.runtime_mode === 'automatic' ? 'Automatic preflight' : 'Runs when explicit parameters are supplied' }} · {{ tool.runtime_hint }}</small>
            </span>
          </label>
        </div>
        <div
          v-else
          class="empty-tools"
        >
          No MCP tools are available. Start the backend with the configured Claude Code integration and refresh.
        </div>

        <div class="flow-heading">
          <div>
            <div class="card-title">
              Agent flow
            </div>
            <small>Choose the ordered nodes this Agent must follow.</small>
          </div>
          <div class="flow-actions">
            <button
              class="secondary-button"
              type="button"
              @click="addFlowNode"
            >
              <el-icon><Plus /></el-icon> Add node
            </button>
            <button
              class="secondary-button approval-add-button"
              type="button"
              @click="addApprovalNode"
            >
              Add approval
            </button>
          </div>
        </div>
        <div class="flow-editor">
          <template
            v-for="(node, index) in form.flowNodes"
            :key="node.id"
          >
            <div class="flow-node">
              <span class="flow-index">{{ index + 1 }}</span>
              <div class="flow-node-fields">
                <input
                  v-model="node.label"
                  class="text-input"
                  maxlength="100"
                  placeholder="Node name"
                >
                <input
                  v-model="node.description"
                  class="text-input"
                  maxlength="300"
                  placeholder="What happens in this step?"
                >
                <select
                  v-model="node.kind"
                  class="select-input flow-kind-select"
                >
                  <option value="input">
                    Input
                  </option>
                  <option value="task">
                    Task
                  </option>
                  <option value="verify">
                    Verify
                  </option>
                  <option value="approval">
                    Human approval
                  </option>
                </select>
                <div
                  v-if="node.kind === 'approval'"
                  class="approval-config"
                >
                  <label><input
                    v-model="node.approvalChannels"
                    type="checkbox"
                    value="email"
                  > Email</label>
                  <label><input
                    v-model="node.approvalChannels"
                    type="checkbox"
                    value="feishu"
                  > Feishu</label>
                  <input
                    v-model="node.approvalRecipients"
                    class="text-input"
                    maxlength="500"
                    placeholder="Reviewer emails, comma-separated (optional)"
                  >
                </div>
              </div>
              <button
                class="icon-clear"
                type="button"
                title="Remove node"
                :disabled="form.flowNodes.length <= 1"
                @click="removeFlowNode(node.id)"
              >
                ×
              </button>
            </div>
            <div
              v-if="index < form.flowNodes.length - 1"
              class="flow-connector"
            >
              ↓
            </div>
          </template>
        </div>

        <div class="card-title knowledge-title">
          <span>Knowledge references</span>
          <span class="count-badge">{{ selectedDocumentIds.length }} selected</span>
        </div>
        <div class="knowledge-search-row">
          <input
            v-model="knowledgeSearch"
            class="text-input"
            placeholder="Filter documents..."
          >
          <span class="live-label"><span class="live-dot" /> Live</span>
        </div>
        <div
          v-if="filteredDocuments.length"
          class="knowledge-list"
        >
          <label
            v-for="document in filteredDocuments"
            :key="document.id"
            class="knowledge-item"
          >
            <input
              v-model="selectedDocumentIds"
              type="checkbox"
              :value="document.id"
            >
            <span class="knowledge-item-copy">
              <strong>{{ document.title }}</strong>
              <small>{{ document.chip }} <span v-if="document.revision">· {{ document.revision }}</span></small>
              <small class="repository-path">{{ document.repository_path }}</small>
            </span>
          </label>
        </div>
        <div
          v-else
          class="empty-knowledge"
        >
          No canonical knowledge documents found yet. Import one from Knowledge Base and refresh.
        </div>

        <button
          class="generate-button"
          type="button"
          :disabled="!canGenerate"
          @click="handleGenerate"
        >
          <span
            v-if="isGenerating"
            class="button-spinner"
          />
          <el-icon v-else>
            <MagicStick />
          </el-icon>
          {{ isGenerating ? 'Generating Agent...' : 'Generate Agent' }}
        </button>
        <p
          v-if="errorMessage"
          class="error-message"
        >
          {{ errorMessage }}
        </p>
      </section>

      <section class="preview-card">
        <div class="preview-heading">
          <div>
            <div class="card-title">
              Prompt output
            </div>
            <p class="muted">
              The final system prompt is stored with the Agent manifest.
            </p>
          </div>
          <span
            v-if="lastAgent"
            class="saved-badge"
          >Saved to Git</span>
        </div>
        <pre class="prompt-preview">{{ promptPreview || placeholderPreview }}</pre>
        <div
          v-if="lastAgent"
          class="generated-summary"
        >
          <div class="summary-title">
            {{ lastAgent.name }}
          </div>
          <div class="summary-description">
            {{ lastAgent.description }}
          </div>
          <div class="summary-meta">
            <span>{{ lastAgent.generated_by_llm ? 'LLM designed' : 'Scaffolded safely' }}</span>
            <span>{{ lastAgent.knowledge_document_ids.length }} knowledge references</span>
            <span>{{ (lastAgent.selected_tools || []).length }} plugin tools</span>
            <span>{{ (lastAgent.market_skill_names || []).length }} market skills</span>
            <span>Runtime: {{ lastAgent.llm_provider }} / {{ lastAgent.llm_model }}</span>
            <span>Output: {{ lastAgent.output_mode === 'text' ? 'chat' : lastAgent.output_mode + ' / ' + lastAgent.output_format }}</span>
          </div>
          <div
            v-if="lastAgent.warnings.length"
            class="warning-box"
          >
            {{ lastAgent.warnings.join(' ') }}
          </div>
        </div>
        <div
          v-else
          class="preview-hint"
        >
          Your generated system prompt will appear here before the new Agent is added to the sidebar.
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { generateAgent, generateAgentSkillDraft, getCodeParserStatus, listAgentGeneratorTools, listGeneratorKnowledgeDocuments, uploadAgentInputFile, uploadAgentLogo, uploadAgentSkillFile } from '../api/agentGenerator.js'
import { getProviderSettings } from '../api/settings.js'
import { useModelCatalog } from '../composables/useModelCatalog.js'
import { listInstalledMarketSkills } from '../api/skillMarket.js'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'

const emit = defineEmits(['agent-created'])
const authStore = useAuthStore()
const mountedIdentity = accountIdentity(authStore)
let invalidated = false

function isCurrentWorkspace() {
  return !invalidated && !!mountedIdentity && mountedIdentity === accountIdentity(authStore)
}

const form = ref({
  name: '',
  goal: '',
  prompt: '',
  icon: 'MagicStick',
  color: '#2563eb',
  logoUrl: '',
  inputFiles: [],
  inputDefinitions: [],
  skillFiles: [],
  marketSkillNames: [],
  selectedTools: [],
  flowNodes: [
    { id: 'analyze', label: 'Analyze input', description: 'Understand the request and uploaded context.', kind: 'input', approvalChannels: [], approvalRecipients: '' },
    { id: 'execute', label: 'Execute workflow', description: 'Apply the Agent instructions and selected knowledge.', kind: 'task', approvalChannels: [], approvalRecipients: '' },
    { id: 'verify', label: 'Verify output', description: 'Check correctness, safety, and acceptance criteria.', kind: 'verify', approvalChannels: [], approvalRecipients: '' },
  ],
  llmProvider: 'macode',
  llmModel: 'claude-sonnet-4-6',
  outputMode: 'text',
  outputFormat: 'markdown',
  outputFilename: '',
})
const knowledgeDocuments = ref([])
const availableTools = ref([])
const marketSkills = ref([])
const parserStatus = ref(null)
const selectedDocumentIds = ref([])
const knowledgeSearch = ref('')
const isRefreshing = ref(false)
const isRefreshingTools = ref(false)
const isRefreshingMarketSkills = ref(false)
const isGenerating = ref(false)
const errorMessage = ref('')
const promptPreview = ref('')
const lastAgent = ref(null)
const isUploadingFile = ref(false)
const isUploadingSkill = ref(false)
const isUploadingLogo = ref(false)
const showSkillGenerator = ref(false)
const isGeneratingSkill = ref(false)
const isAddingSkill = ref(false)
const skillGenerationError = ref('')
const skillDraft = ref({ name: '', goal: '', description: '', content: '', warnings: [] })
const providerDefaults = ref({
  macode: 'claude-sonnet-4-6',
  bedrock: 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
})
let refreshTimer = null

function invalidateWorkspace() {
  invalidated = true
  if (refreshTimer) globalThis.clearInterval(refreshTimer)
  globalThis.removeEventListener('knowledge:updated', handleKnowledgeUpdated)
}

watch(() => accountIdentity(authStore), invalidateWorkspace, { flush: 'sync' })

const { loadCatalog, options: catalogOptions } = useModelCatalog()
const modelOptions = computed(() => {
  const defaults = providerDefaults.value
  const values = form.value.llmProvider === 'bedrock'
    ? [defaults.bedrock, 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0']
    : [defaults.macode, 'claude-sonnet-4-6', 'claude-sonnet-4-5']
  return catalogOptions(form.value.llmProvider, form.value.llmModel, values).map(option => option.value)
})

const filteredDocuments = computed(() => {
  const query = knowledgeSearch.value.trim().toLowerCase()
  if (!query) return knowledgeDocuments.value
  return knowledgeDocuments.value.filter((document) => {
    return [document.title, document.chip, document.repository_path].some((value) => String(value || '').toLowerCase().includes(query))
  })
})

const selectedToolDetails = computed(() => {
  const selected = new Set(form.value.selectedTools)
  return availableTools.value.filter(tool => selected.has(tool.name))
})

const canGenerate = computed(() => form.value.prompt.trim().length > 0 && !isGenerating.value)
const canGenerateSkill = computed(() => {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(skillDraft.value.name.trim())
    && skillDraft.value.goal.trim().length > 0
    && !isGeneratingSkill.value
    && !isAddingSkill.value
})

const placeholderPreview = computed(() => {
  const goal = form.value.goal.trim() || 'the requested firmware workflow'
  return 'The generated Agent prompt for ' + goal + ' will appear here.'
})

watch(form, updatePromptPreview, { deep: true })
watch(
  () => [
    skillDraft.value.name,
    skillDraft.value.goal,
    form.value.name,
    form.value.goal,
    form.value.prompt,
    form.value.llmProvider,
    form.value.llmModel,
  ],
  () => {
    skillDraft.value.content = ''
    skillDraft.value.description = ''
    skillDraft.value.warnings = []
    skillGenerationError.value = ''
  },
)

async function refreshKnowledgeDocuments(showMessage = false) {
  if (!isCurrentWorkspace()) return
  isRefreshing.value = true
  try {
    const response = await listGeneratorKnowledgeDocuments()
    if (!isCurrentWorkspace()) return
    const nextDocuments = Array.isArray(response?.documents) ? response.documents : []
    const availableIds = new Set(nextDocuments.map(document => document.id))
    knowledgeDocuments.value = nextDocuments
    selectedDocumentIds.value = selectedDocumentIds.value.filter(id => availableIds.has(id))
    if (showMessage) ElMessage.success('Knowledge references refreshed.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    if (showMessage) ElMessage.error(error.message || 'Failed to refresh knowledge references.')
  } finally {
    isRefreshing.value = false
  }
}

async function refreshAgentTools(showMessage = false) {
  if (!isCurrentWorkspace()) return
  isRefreshingTools.value = true
  try {
    const response = await listAgentGeneratorTools()
    if (!isCurrentWorkspace()) return
    const nextTools = Array.isArray(response?.tools) ? response.tools : []
    const availableNames = new Set(nextTools.map(tool => tool.name))
    availableTools.value = nextTools
    form.value.selectedTools = form.value.selectedTools.filter(name => availableNames.has(name))
    if (showMessage) ElMessage.success('External tools refreshed.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    if (showMessage) ElMessage.error(error.message || 'Failed to refresh external tools.')
  } finally {
    isRefreshingTools.value = false
  }
}

async function refreshMarketSkills(showMessage = false) {
  if (!isCurrentWorkspace()) return
  isRefreshingMarketSkills.value = true
  try {
    const response = await listInstalledMarketSkills()
    if (!isCurrentWorkspace()) return
    const nextSkills = Array.isArray(response?.items) ? response.items : []
    const availableNames = new Set(nextSkills.map(skill => skill.name).filter(Boolean))
    marketSkills.value = nextSkills
    form.value.marketSkillNames = form.value.marketSkillNames.filter(name => availableNames.has(name))
    if (showMessage) ElMessage.success('Installed Skill Market skills refreshed.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    if (showMessage) ElMessage.error(error.message || 'Failed to refresh Skill Market skills.')
  } finally {
    isRefreshingMarketSkills.value = false
  }
}

function updatePromptPreview() {
  const selected = knowledgeDocuments.value.filter(document => selectedDocumentIds.value.includes(document.id))
  const references = selected.map(document => '- ' + document.title + ' (' + document.repository_path + ')').join('\n') || '- None selected'
  promptPreview.value = [
    'You are ' + (form.value.name.trim() || 'a generated firmware development Agent') + '.',
    '',
    'Mission: ' + (form.value.goal.trim() || form.value.prompt.trim() || 'Define the requested workflow.'),
    '',
    'Operating requirements:',
    form.value.prompt.trim() || 'Describe the inputs, workflow, constraints, and output format.',
    '',
    'Canonical knowledge references:',
    references,
    '',
    'Uploaded input files:',
    form.value.inputFiles.map(file => '- ' + file.name + ' (' + file.repository_path + ') - ' + analysisLabel(file.code_analysis)).join('\n') || '- None uploaded',
    '',
    'Runtime inputs:',
    form.value.inputDefinitions.map(input => '- ' + input.id + ': ' + input.label + ' [' + input.type + ']' + (input.required ? ' (required)' : '')).join('\n') || '- None configured',
    '',
    'Attached skill files:',
    form.value.skillFiles.map(file => '- ' + file.name + ' (' + file.repository_path + ')').join('\n') || '- None attached',
    '',
    'Imported Skill Market skills:',
    marketSkills.value.filter(skill => form.value.marketSkillNames.includes(skill.name)).map(skill => '- ' + skill.name).join('\n') || '- None selected',
    '',
    'Selected external tools:',
    selectedToolDetails.value.map(tool => '- ' + tool.name + ' (' + (tool.server || 'mcp') + '): ' + tool.description).join('\n') || '- None selected',
    '',
    'Runtime LLM:',
    '- Provider: ' + form.value.llmProvider,
    '- Model: ' + (form.value.llmModel.trim() || providerDefaults.value[form.value.llmProvider]),
    '',
    'Output settings:',
    '- Mode: ' + form.value.outputMode,
    '- Format: ' + form.value.outputFormat,
    '- Filename: ' + (form.value.outputFilename.trim() || 'agent-output'),
    '',
    'Flow nodes:',
    form.value.flowNodes.map((node, index) => (index + 1) + '. ' + node.label + ' [' + node.kind + ']: ' + node.description + (node.kind === 'approval' ? ' (channels: ' + (node.approvalChannels?.join(', ') || 'workspace') + ')' : '')).join('\n') || '- Default workflow',
  ].join('\n')
}

function handleLlmProviderChange() {
  form.value.llmModel = providerDefaults.value[form.value.llmProvider] || ''
}

async function loadLlmDefaults() {
  if (!isCurrentWorkspace()) return
  void loadCatalog()
  try {
    const response = await getProviderSettings()
    if (!isCurrentWorkspace()) return
    const env = response?.data || {}
    providerDefaults.value = {
      macode: env.TURING_DEFAULT_MODEL || 'claude-sonnet-4-6',
      bedrock: env.BEDROCK_DEFAULT_MODEL || env.ANTHROPIC_DEFAULT_SONNET_MODEL || 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
    }
    let configured = {}
    try {
      configured = env.AGENT_LLM_CONFIG ? JSON.parse(env.AGENT_LLM_CONFIG) : {}
    } catch {
      configured = {}
    }
    const selection = configured.agent_generator || {}
    const provider = ['macode', 'bedrock'].includes(selection.provider)
      ? selection.provider
      : (['macode', 'bedrock'].includes(env.DEFAULT_PROVIDER) ? env.DEFAULT_PROVIDER : 'macode')
    form.value.llmProvider = provider
    form.value.llmModel = selection.model || providerDefaults.value[provider]
    updatePromptPreview()
  } catch {
    // Keep the safe Macode defaults when settings are unavailable.
  }
}

async function handleGenerate() {
  if (!isCurrentWorkspace() || !canGenerate.value) return
  isGenerating.value = true
  errorMessage.value = ''
  try {
    const response = await generateAgent({
      ...form.value,
      knowledgeDocumentIds: selectedDocumentIds.value,
      logoUrl: form.value.logoUrl,
      inputFiles: form.value.inputFiles,
      inputDefinitions: form.value.inputDefinitions,
      skillFiles: form.value.skillFiles,
      selectedTools: form.value.selectedTools,
      flowNodes: form.value.flowNodes.filter(node => node.label.trim()),
    })
    if (!isCurrentWorkspace()) return
    lastAgent.value = response.agent
    promptPreview.value = response.agent.prompt_preview || response.agent.system_prompt
    emit('agent-created', response.agent)
    ElMessage.success('Agent generated and saved to the Git knowledge tree.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    errorMessage.value = error.message || 'Agent generation failed.'
  } finally {
    isGenerating.value = false
  }
}

async function handleFileUpload(event) {
  if (!isCurrentWorkspace()) return
  const files = Array.from(event.target.files || [])
  event.target.value = ''
  if (!files.length) return
  isUploadingFile.value = true
  try {
    const uploaded = await Promise.all(files.map(file => uploadAgentInputFile(file)))
    if (!isCurrentWorkspace()) return
    const existing = new Set(form.value.inputFiles.map(file => file.id))
    form.value.inputFiles.push(...uploaded.filter(file => !existing.has(file.id)))
    ElMessage.success(`${uploaded.length} input file${uploaded.length > 1 ? 's' : ''} added.`)
  } catch (error) {
    if (!isCurrentWorkspace()) return
    ElMessage.error(error.message || 'Failed to upload Agent input file.')
  } finally {
    isUploadingFile.value = false
  }
}

async function handleSkillUpload(event) {
  if (!isCurrentWorkspace()) return
  const files = Array.from(event.target.files || [])
  event.target.value = ''
  if (!files.length) return
  isUploadingSkill.value = true
  try {
    const uploaded = await Promise.all(files.map(file => uploadAgentSkillFile(file)))
    if (!isCurrentWorkspace()) return
    const existing = new Set(form.value.skillFiles.map(file => file.id))
    form.value.skillFiles.push(...uploaded.filter(file => !existing.has(file.id)))
    ElMessage.success(String(uploaded.length) + ' skill file' + (uploaded.length > 1 ? 's' : '') + ' added.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    ElMessage.error(error.message || 'Failed to upload Agent skill file.')
  } finally {
    isUploadingSkill.value = false
  }
}

function openSkillGenerator() {
  const agentSlug = form.value.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48)
  skillDraft.value.name = (agentSlug || 'generated-agent') + '-skill'
  skillDraft.value.goal = form.value.goal.trim() || form.value.prompt.trim()
  skillDraft.value.content = ''
  skillDraft.value.description = ''
  skillDraft.value.warnings = []
  skillGenerationError.value = ''
  showSkillGenerator.value = true
}

async function handleGenerateSkill() {
  if (!isCurrentWorkspace() || !canGenerateSkill.value) return
  const generationContext = JSON.stringify([
    skillDraft.value.name,
    skillDraft.value.goal,
    form.value.name,
    form.value.goal,
    form.value.prompt,
    form.value.llmProvider,
    form.value.llmModel,
  ])
  isGeneratingSkill.value = true
  skillGenerationError.value = ''
  try {
    const response = await generateAgentSkillDraft({
      name: skillDraft.value.name.trim(),
      goal: skillDraft.value.goal.trim(),
      agentName: form.value.name,
      agentGoal: form.value.goal,
      agentPrompt: form.value.prompt,
      llmProvider: form.value.llmProvider,
      llmModel: form.value.llmModel,
    })
    if (!isCurrentWorkspace()) return
    const currentContext = JSON.stringify([
      skillDraft.value.name,
      skillDraft.value.goal,
      form.value.name,
      form.value.goal,
      form.value.prompt,
      form.value.llmProvider,
      form.value.llmModel,
    ])
    if (currentContext !== generationContext) {
      skillGenerationError.value = 'Agent settings changed during generation. Generate a fresh Skill draft.'
      return
    }
    skillDraft.value.content = response.content || ''
    skillDraft.value.description = response.description || ''
    skillDraft.value.warnings = response.warnings || []
    if (skillDraft.value.content) ElMessage.success('Skill draft is ready to review.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    skillGenerationError.value = error.message || 'Skill generation failed.'
  } finally {
    isGeneratingSkill.value = false
  }
}

async function handleAttachGeneratedSkill() {
  if (!isCurrentWorkspace() || !skillDraft.value.content || isAddingSkill.value) return
  isAddingSkill.value = true
  skillGenerationError.value = ''
  try {
    const file = new globalThis.File(
      [skillDraft.value.content],
      skillDraft.value.name.trim() + '.md',
      { type: 'text/markdown' },
    )
    const uploaded = await uploadAgentSkillFile(file)
    if (!isCurrentWorkspace()) return
    form.value.skillFiles.push(uploaded)
    showSkillGenerator.value = false
    ElMessage.success('Generated Skill added to this Agent.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    skillGenerationError.value = error.message || 'Could not add the generated Skill.'
  } finally {
    isAddingSkill.value = false
  }
}

async function handleLogoUpload(event) {
  if (!isCurrentWorkspace()) return
  const file = event.target.files?.[0]
  event.target.value = ''
  if (!file) return
  isUploadingLogo.value = true
  try {
    const uploaded = await uploadAgentLogo(file)
    if (!isCurrentWorkspace()) return
    form.value.logoUrl = uploaded.logo_url
    ElMessage.success('Agent logo uploaded.')
  } catch (error) {
    if (!isCurrentWorkspace()) return
    ElMessage.error(error.message || 'Failed to upload Agent logo.')
  } finally {
    isUploadingLogo.value = false
  }
}

function addFlowNode() {
  form.value.flowNodes.push({
    id: 'node_' + Date.now(),
    label: 'New step',
    description: 'Describe this step.',
    kind: 'task',
    approvalChannels: [],
    approvalRecipients: '',
  })
}

function addRuntimeInput() {
  const index = form.value.inputDefinitions.length + 1
  form.value.inputDefinitions.push({
    id: 'input_' + index,
    label: 'Input ' + index,
    type: 'text',
    required: false,
    placeholder: '',
    default: '',
    optionsText: '',
  })
}

function removeRuntimeInput(inputId) {
  form.value.inputDefinitions = form.value.inputDefinitions.filter(input => input.id !== inputId)
}

function addApprovalNode() {
  form.value.flowNodes.push({
    id: 'approval_' + Date.now(),
    label: 'Human approval',
    description: 'Pause and request reviewer approval before continuing.',
    kind: 'approval',
    approvalChannels: [],
    approvalRecipients: '',
  })
}

function removeFlowNode(nodeId) {
  if (form.value.flowNodes.length <= 1) return
  form.value.flowNodes = form.value.flowNodes.filter(node => node.id !== nodeId)
}

function removeInputFile(fileId) {
  form.value.inputFiles = form.value.inputFiles.filter(file => file.id !== fileId)
}

function removeSkillFile(fileId) {
  form.value.skillFiles = form.value.skillFiles.filter(file => file.id !== fileId)
}

function formatSize(size) {
  if (!size) return '0 B'
  if (size < 1024) return size + ' B'
  if (size < 1024 * 1024) return (size / 1024).toFixed(1) + ' KB'
  return (size / (1024 * 1024)).toFixed(1) + ' MB'
}

function analysisLabel(analysis) {
  if (!analysis || !analysis.language) return 'not parsed'
  const symbols = Number(analysis.symbols || 0)
  const errors = Number(analysis.syntax_errors || 0)
  return String(analysis.language) + ' - ' + String(analysis.parser || 'fallback') + ' - ' + symbols + ' symbols' + (errors ? ' - ' + errors + ' syntax issue' + (errors > 1 ? 's' : '') : '')
}

async function loadCodeParserStatus() {
  if (!isCurrentWorkspace()) return
  try {
    const status = await getCodeParserStatus()
    if (isCurrentWorkspace()) parserStatus.value = status
  } catch {
    if (isCurrentWorkspace()) parserStatus.value = null
  }
}

function handleKnowledgeUpdated() {
  refreshKnowledgeDocuments(false)
}

onMounted(() => {
  if (!isCurrentWorkspace()) return
  refreshKnowledgeDocuments(false)
  refreshAgentTools(false)
  refreshMarketSkills(false)
  loadCodeParserStatus()
  loadLlmDefaults()
  updatePromptPreview()
  refreshTimer = globalThis.setInterval(() => refreshKnowledgeDocuments(false), 12000)
  globalThis.addEventListener('knowledge:updated', handleKnowledgeUpdated)
})

onBeforeUnmount(invalidateWorkspace)
</script>

<style scoped>
.generator-page { flex: 1; overflow: auto; padding: 28px 32px 40px; background: #f8f9fb; }
.generator-header { max-width: 1180px; margin: 0 auto 22px; display: flex; justify-content: space-between; gap: 24px; align-items: flex-start; }
.eyebrow { color: #2563eb; font-size: 11px; font-weight: 700; letter-spacing: 1.8px; }
h1 { margin: 7px 0 6px; color: #0f172a; font-size: 25px; }
.generator-header p { margin: 0; color: #64748b; font-size: 13px; }
.refresh-button, .generate-button { display: inline-flex; align-items: center; justify-content: center; gap: 7px; border: 0; border-radius: 8px; cursor: pointer; font-weight: 600; }
.refresh-button { padding: 9px 14px; color: #1d4ed8; background: #eff6ff; border: 1px solid #bfdbfe; }
.refresh-button:disabled { opacity: .6; cursor: wait; }
.generator-grid { max-width: 1180px; margin: 0 auto; display: grid; grid-template-columns: minmax(0, 1.04fr) minmax(0, .96fr); gap: 18px; }
.builder-card, .preview-card { min-width: 0; background: #fff; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; box-shadow: 0 5px 18px rgba(15, 23, 42, .04); }
.card-title { color: #1f2937; font-size: 14px; font-weight: 700; }
.field-label { display: block; margin: 16px 0 7px; color: #475569; font-size: 12px; font-weight: 600; }
.text-input, .text-area, .select-input, .color-input { width: 100%; box-sizing: border-box; border: 1px solid #dbe3ed; border-radius: 7px; background: #fbfdff; color: #0f172a; font: inherit; font-size: 13px; }
.text-input, .select-input { height: 36px; padding: 0 10px; }
.text-area { min-height: 160px; padding: 10px; line-height: 1.55; resize: vertical; }
.text-area.compact { min-height: 78px; }
.text-input:focus, .text-area:focus, .select-input:focus { outline: 2px solid #bfdbfe; border-color: #60a5fa; }
.field-row { display: flex; gap: 12px; }
.field-grow { flex: 1; }
.llm-settings { margin-top: 2px; }
.field-hint { display: block; margin-top: 6px; color: #94a3b8; font-size: 10px; }
.output-settings { margin-top: 2px; }
.color-input { padding: 3px; height: 36px; cursor: pointer; }
.logo-picker { display: flex; align-items: center; gap: 9px; min-width: 0; padding: 9px; border: 1px solid #edf1f5; border-radius: 8px; background: #fbfdff; }
.logo-preview { width: 38px; height: 38px; display: grid; place-items: center; flex-shrink: 0; border-radius: 9px; font-size: 20px; overflow: hidden; }
.logo-preview img { width: 100%; height: 100%; object-fit: cover; }
.logo-picker-copy { display: flex; flex: 1; min-width: 0; flex-direction: column; gap: 2px; }
.logo-picker-copy strong { color: #334155; font-size: 11px; }
.logo-picker-copy small, .flow-heading small { color: #94a3b8; font-size: 10px; }
.secondary-button { display: inline-flex; align-items: center; justify-content: center; gap: 5px; padding: 7px 9px; border: 1px solid #bfdbfe; border-radius: 7px; color: #1d4ed8; background: #eff6ff; cursor: pointer; font-size: 11px; font-weight: 600; white-space: nowrap; }
.secondary-button input, .file-drop input { display: none; }
.clear-button, .icon-clear { border: 0; color: #64748b; background: transparent; cursor: pointer; font-size: 11px; }
.file-drop { display: flex; align-items: center; gap: 8px; min-height: 52px; padding: 9px 11px; border: 1px dashed #bfdbfe; border-radius: 8px; color: #2563eb; background: #f8fbff; cursor: pointer; }
.file-drop.uploading { opacity: .65; cursor: wait; }
.file-drop span { color: #334155; font-size: 11px; font-weight: 600; }
.file-drop small { margin-left: auto; color: #94a3b8; font-size: 10px; }
.file-list { display: flex; flex-direction: column; gap: 5px; margin-top: 7px; }
.file-item { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border: 1px solid #edf1f5; border-radius: 6px; }
.file-item-copy { display: flex; flex: 1; min-width: 0; flex-direction: column; gap: 1px; }
.file-item-copy strong { overflow: hidden; color: #334155; font-size: 11px; text-overflow: ellipsis; white-space: nowrap; }
.file-item-copy small { color: #94a3b8; font-size: 10px; }
.skill-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 4px; }
.skill-heading .field-label { margin-top: 16px; }
.market-skill-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 8px; }
.market-skill-heading .field-label { margin: 8px 0 0; }
.market-skill-list { max-height: 180px; margin-top: 8px; overflow: auto; border: 1px solid #edf1f5; border-radius: 8px; }
.market-skill-item { display: flex; align-items: flex-start; gap: 8px; padding: 8px 10px; border-bottom: 1px solid #f1f5f9; cursor: pointer; }
.market-skill-item:last-child { border-bottom: 0; }
.market-skill-item:hover { background: #f8fbff; }
.market-skill-item input { margin-top: 3px; accent-color: #2563eb; }
.market-skill-copy { display: flex; min-width: 0; flex-direction: column; gap: 2px; }
.market-skill-copy strong { color: #334155; font: 600 11px Consolas, monospace; overflow-wrap: anywhere; }
.market-skill-copy small, .market-skill-empty { color: #64748b; font-size: 10px; line-height: 1.4; }
.market-skill-empty { margin-top: 8px; padding: 10px; border-radius: 6px; background: #f8fafc; }
.skill-generator-panel { margin-top: 10px; padding: 12px; border: 1px solid #dbeafe; border-radius: 8px; background: #f8fbff; }
.skill-generator-panel .field-label { margin-top: 12px; }
.skill-draft-actions { display: flex; gap: 7px; margin-top: 10px; }
.skill-attach-button { color: #047857; border-color: #a7f3d0; background: #ecfdf5; }
.skill-spinner { border-color: rgba(37,99,235,.25); border-top-color: #2563eb; }
.skill-draft-preview { margin-top: 12px; padding: 10px; border: 1px solid #dbe3ed; border-radius: 7px; background: #fff; }
.skill-draft-preview strong { display: block; color: #334155; font-size: 11px; line-height: 1.45; overflow-wrap: anywhere; }
.skill-draft-preview pre { max-height: 360px; margin: 8px 0 0; padding: 10px; overflow: auto; border-radius: 6px; background: #0f172a; color: #dbeafe; font: 11px/1.55 Consolas, 'SFMono-Regular', monospace; white-space: pre-wrap; overflow-wrap: anywhere; }
.skill-draft-preview small { display: block; margin-top: 7px; color: #92400e; font-size: 10px; line-height: 1.4; }
.flow-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 22px; }
.input-heading { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; margin-top: 22px; }
.input-heading small { display: block; margin-top: 3px; color: #94a3b8; font-size: 10px; }
.runtime-input-editor { display: flex; flex-direction: column; gap: 7px; margin-top: 9px; }
.runtime-input-row { display: flex; align-items: flex-start; gap: 7px; padding: 8px; border: 1px solid #edf1f5; border-radius: 8px; background: #fbfdff; }
.runtime-input-fields { display: grid; flex: 1; grid-template-columns: .85fr 1fr .7fr auto; gap: 6px; min-width: 0; }
.runtime-input-fields .text-input, .runtime-input-fields .select-input { min-width: 0; height: 31px; font-size: 11px; }
.runtime-required { display: inline-flex; align-items: center; gap: 4px; min-height: 31px; color: #475569; font-size: 10px; white-space: nowrap; }
.runtime-required input { accent-color: #2563eb; }
.runtime-options { grid-column: 2 / -1; }
.runtime-input-hint, .empty-runtime-inputs { color: #94a3b8; font-size: 10px; line-height: 1.4; }
.runtime-input-hint { grid-column: 2 / -1; align-self: center; }
.flow-actions { display: flex; gap: 6px; }
.approval-add-button { color: #92400e; border-color: #fcd34d; background: #fffbeb; }
.tool-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 22px; }
.tool-heading > div { min-width: 0; }
.tool-list { max-height: 220px; margin-top: 9px; overflow: auto; border: 1px solid #edf1f5; border-radius: 8px; }
.tool-item { display: flex; align-items: flex-start; gap: 8px; padding: 9px 10px; border-bottom: 1px solid #f1f5f9; cursor: pointer; }
.tool-item:last-child { border-bottom: 0; }
.tool-item:hover { background: #f8fbff; }
.tool-item input { margin-top: 3px; accent-color: #2563eb; }
.tool-item-copy { display: flex; min-width: 0; flex-direction: column; gap: 2px; }
.tool-item-copy strong { color: #334155; font: 600 11px Consolas, monospace; }
.tool-item-copy small { color: #64748b; font-size: 10px; line-height: 1.35; }
.tool-item-copy .tool-runtime-hint { color: #2563eb; }
.empty-tools { margin-top: 9px; padding: 12px; border-radius: 8px; color: #64748b; background: #f8fafc; font-size: 11px; line-height: 1.5; }
.flow-editor { margin-top: 9px; padding: 8px; border: 1px solid #edf1f5; border-radius: 8px; background: #fbfdff; }
.flow-node { display: flex; align-items: center; gap: 7px; }
.flow-index { width: 20px; height: 20px; display: grid; place-items: center; flex-shrink: 0; border-radius: 50%; color: #1d4ed8; background: #dbeafe; font-size: 10px; font-weight: 700; }
.flow-node-fields { display: grid; flex: 1; grid-template-columns: .75fr 1.15fr .55fr; gap: 6px; min-width: 0; }
.flow-node-fields .text-input { height: 31px; font-size: 11px; }
.flow-kind-select { height: 31px; font-size: 11px; }
.approval-config { display: flex; grid-column: 1 / -1; align-items: center; gap: 9px; flex-wrap: wrap; color: #475569; font-size: 10px; }
.approval-config label { display: inline-flex; align-items: center; gap: 3px; white-space: nowrap; }
.approval-config input[type='checkbox'] { accent-color: #2563eb; }
.approval-config .text-input { flex: 1; min-width: 180px; }
.flow-connector { height: 15px; margin-left: 7px; color: #93c5fd; font-size: 14px; line-height: 15px; }
.knowledge-title { display: flex; align-items: center; justify-content: space-between; margin-top: 22px; }
.count-badge, .saved-badge { padding: 3px 8px; border-radius: 999px; font-size: 10px; font-weight: 600; color: #1d4ed8; background: #eff6ff; }
.knowledge-search-row { display: flex; align-items: center; gap: 8px; margin-top: 10px; }
.live-label { flex-shrink: 0; color: #16a34a; font-size: 11px; font-weight: 600; }
.live-dot { width: 6px; height: 6px; display: inline-block; margin-right: 4px; border-radius: 50%; background: #22c55e; }
.knowledge-list { max-height: 245px; margin-top: 9px; overflow: auto; border: 1px solid #edf1f5; border-radius: 8px; }
.knowledge-item { display: flex; gap: 9px; align-items: flex-start; padding: 10px; border-bottom: 1px solid #f1f5f9; cursor: pointer; }
.knowledge-item:last-child { border-bottom: 0; }
.knowledge-item:hover { background: #f8fbff; }
.knowledge-item input { margin-top: 3px; accent-color: #2563eb; }
.knowledge-item-copy { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.knowledge-item-copy strong { color: #334155; font-size: 12px; }
.knowledge-item-copy small { color: #64748b; font-size: 10px; }
.repository-path { overflow: hidden; color: #94a3b8 !important; text-overflow: ellipsis; white-space: nowrap; }
.empty-knowledge { margin-top: 9px; padding: 14px; border-radius: 8px; color: #64748b; background: #f8fafc; font-size: 12px; line-height: 1.5; }
.generate-button { width: 100%; margin-top: 20px; padding: 11px 15px; color: #fff; background: #2563eb; }
.generate-button:hover:not(:disabled) { background: #1d4ed8; }
.generate-button:disabled { opacity: .55; cursor: not-allowed; }
.button-spinner { width: 14px; height: 14px; border: 2px solid rgba(255,255,255,.45); border-top-color: #fff; border-radius: 50%; animation: spin 0.8s linear infinite; }
.error-message { margin: 10px 0 0; color: #b91c1c; font-size: 12px; }
.preview-heading { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
.muted { margin: 5px 0 0; color: #94a3b8; font-size: 11px; }
.parser-status { margin: 6px 0 0; color: #15803d; font-size: 10px; }
.parser-status.unavailable { color: #b45309; }
.prompt-preview { min-height: 420px; max-height: 580px; margin: 17px 0 0; padding: 15px; overflow: auto; border: 1px solid #e2e8f0; border-radius: 9px; background: #0f172a; color: #dbeafe; font: 12px/1.65 Consolas, 'SFMono-Regular', monospace; white-space: pre-wrap; }
.generated-summary { margin-top: 15px; padding: 12px 13px; border: 1px solid #dbeafe; border-radius: 8px; background: #eff6ff; }
.summary-title { color: #1e3a8a; font-size: 13px; font-weight: 700; }
.summary-description { margin-top: 5px; color: #475569; font-size: 12px; line-height: 1.5; }
.summary-meta { display: flex; gap: 12px; margin-top: 8px; color: #2563eb; font-size: 10px; }
.warning-box { margin-top: 9px; color: #92400e; font-size: 11px; line-height: 1.5; }
.preview-hint { margin-top: 17px; padding: 15px; color: #64748b; background: #f8fafc; border-radius: 9px; font-size: 12px; line-height: 1.55; }
@keyframes spin { to { transform: rotate(360deg); } }
@media (max-width: 900px) { .generator-grid { grid-template-columns: 1fr; } .generator-header { flex-direction: column; } }
@media (max-width: 640px) { .logo-picker { flex-wrap: wrap; } .logo-picker-copy { min-width: 150px; } .file-drop { flex-wrap: wrap; } .file-drop small { width: 100%; margin-left: 0; } .flow-node-fields, .runtime-input-fields { grid-template-columns: 1fr; } .runtime-options, .runtime-input-hint { grid-column: auto; } .flow-actions, .skill-draft-actions { flex-wrap: wrap; } .skill-heading { align-items: flex-end; } .skill-heading .secondary-button { white-space: normal; } }
</style>
