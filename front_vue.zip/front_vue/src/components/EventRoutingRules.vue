<template>
  <section class="routing-rules">
    <div class="section-heading">
      <div>
        <h2>Agent routing</h2>
        <p>
          Higher priority wins. Equal priorities use the displayed rule order. All conditions in a
          rule must match.
        </p>
      </div>
      <button type="button" :disabled="disabled || modelValue.rules.length >= 50" @click="addRule">
        Add rule
      </button>
    </div>
    <label class="toggle"
      ><input
        type="checkbox"
        :checked="modelValue.enabled"
        :disabled="disabled"
        @change="update('enabled', $event.target.checked)"
      />
      Enable event routing</label
    >
    <label class="fallback"
      >Fallback Agent
      <select
        :value="modelValue.fallback_agent || ''"
        :disabled="disabled"
        @change="update('fallback_agent', $event.target.value || null)"
      >
        <option value="">Ignore unmatched events</option>
        <option v-for="agent in agents" :key="agent.id" :value="agent.id">{{ agent.name }}</option>
      </select>
    </label>
    <p class="hint">
      With routing disabled, Feishu keeps its existing Chat behavior; API and webhook events are
      recorded as ignored.
    </p>
    <p class="hint">
      Feishu messages use im.message.receive_v1. Use a bot App ID or webhook source ID to restrict a
      rule to one connection. Event types such as issue.* match a prefix.
    </p>
    <p v-if="!modelValue.rules.length" class="empty">
      No rules yet. Add a rule or choose a fallback Agent.
    </p>
    <fieldset
      v-for="(rule, index) in modelValue.rules"
      :key="rule.id"
      :disabled="disabled"
      class="rule"
      data-testid="routing-rule"
    >
      <legend>Rule {{ index + 1 }}</legend>
      <div class="rule-top">
        <label class="toggle"><input v-model="rule.enabled" type="checkbox" /> Enabled</label>
        <div>
          <button
            type="button"
            :disabled="index === 0"
            aria-label="Move rule up"
            @click="move(index, -1)"
          >
            ↑
          </button>
          <button
            type="button"
            :disabled="index === modelValue.rules.length - 1"
            aria-label="Move rule down"
            @click="move(index, 1)"
          >
            ↓
          </button>
          <button type="button" @click="remove(index)">Remove</button>
        </div>
      </div>
      <div class="rule-grid">
        <label
          >Rule name<input v-model="rule.name" required maxlength="80" aria-label="Rule name"
        /></label>
        <label
          >Priority<input
            v-model.number="rule.priority"
            type="number"
            min="0"
            max="1000"
            aria-label="Rule priority"
        /></label>
        <label
          >Source<select
            v-model="rule.source"
            aria-label="Rule source"
            @change="clearApiSource(rule)"
          >
            <option value="*">Any source</option>
            <option value="feishu">Feishu</option>
            <option value="api">Authenticated API</option>
            <option value="webhook">Signed webhook</option>
          </select></label
        >
        <label
          >Source ID (optional)<input
            v-model="rule.source_id"
            :disabled="rule.source === 'api'"
            maxlength="128"
            placeholder="Bot App ID or webhook source ID"
        /></label>
        <label
          >Event type<input
            v-model="rule.event_type"
            required
            maxlength="100"
            placeholder="* or issue.*"
        /></label>
        <label
          >Match<select v-model="rule.match" aria-label="Rule match">
            <option value="any">Any text</option>
            <option value="command">Exact leading command</option>
            <option value="contains">Contains keyword</option>
          </select></label
        >
        <label v-if="rule.match !== 'any'"
          >{{ rule.match === 'command' ? 'Command' : 'Keyword'
          }}<input
            v-model="rule.value"
            required
            maxlength="120"
            :placeholder="rule.match === 'command' ? '/debug' : 'crash'"
            aria-label="Match value"
        /></label>
        <label
          >Agent<select v-model="rule.agent" aria-label="Rule Agent">
            <option v-for="agent in agents" :key="agent.id" :value="agent.id">
              {{ agent.name
              }}{{ agent.event_execution === 'workspace' ? ' (workspace inputs)' : '' }}
            </option>
          </select></label
        >
      </div>
      <p class="hint">{{ agents.find(agent => agent.id === rule.agent)?.requirements }}</p>
    </fieldset>
  </section>
</template>

<script setup>
const props = defineProps({
  modelValue: { type: Object, required: true },
  agents: { type: Array, default: () => [] },
  disabled: Boolean,
})
const emit = defineEmits(['update:modelValue'])
function update(key, value) {
  emit('update:modelValue', { ...props.modelValue, [key]: value })
}
function clearApiSource(rule) {
  if (rule.source === 'api') rule.source_id = ''
}
function addRule() {
  update('rules', [
    ...props.modelValue.rules,
    {
      id: ruleId(),
      name: 'New routing rule',
      enabled: true,
      priority: 100,
      source: '*',
      source_id: '',
      event_type: '*',
      match: 'any',
      value: '',
      agent: 'chat',
    },
  ])
}
function ruleId() {
  if (globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID()
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16))
  return 'rule_' + Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('')
}
function remove(index) {
  update(
    'rules',
    props.modelValue.rules.filter((_, position) => position !== index)
  )
}
function move(index, delta) {
  const rules = [...props.modelValue.rules]
  ;[rules[index], rules[index + delta]] = [rules[index + delta], rules[index]]
  update('rules', rules)
}
</script>

<style scoped>
.section-heading,
.rule-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}
h2 {
  margin: 0;
  font-size: 18px;
}
p {
  color: #64748b;
  font-size: 13px;
  line-height: 1.6;
}
.toggle {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}
.fallback {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  margin-left: 24px;
  font-size: 14px;
}
.rule {
  border: 1px solid #dbe3ee;
  border-radius: 10px;
  margin: 18px 0 0;
  padding: 16px;
  min-width: 0;
}
.rule legend {
  color: #475569;
  font-size: 13px;
  padding: 0 6px;
}
.rule-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  gap: 14px;
  margin-top: 14px;
}
.rule-grid label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  color: #475569;
  font-size: 12px;
}
input:not([type='checkbox']),
select {
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 8px;
  min-width: 0;
  background: #fff;
  color: #0f172a;
}
button {
  border: 1px solid #cbd5e1;
  background: #fff;
  padding: 7px 11px;
  border-radius: 6px;
  color: #334155;
  cursor: pointer;
  margin-left: 5px;
}
button:disabled {
  opacity: 0.5;
  cursor: default;
}
.empty {
  padding: 20px;
  background: #f8fafc;
  border-radius: 8px;
}
.hint {
  margin-bottom: 0;
}
@media (max-width: 650px) {
  .fallback {
    display: flex;
    margin: 16px 0 0;
  }
  .section-heading {
    align-items: flex-start;
  }
}
</style>
