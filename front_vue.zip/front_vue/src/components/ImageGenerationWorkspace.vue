<template>
  <div class="image-workspace">
    <header class="workspace-toolbar">
      <div class="toolbar-title">
        <span class="agent-mark"><el-icon><PictureRounded /></el-icon></span>
        <div>
          <strong>Image Generation</strong>
          <span>{{ imageStore.taskHistory.length }} task{{ imageStore.taskHistory.length === 1 ? '' : 's' }}</span>
        </div>
      </div>
      <div class="toolbar-controls">
        <el-input
          v-model="searchText"
          class="search-control"
          placeholder="Search prompts"
          clearable
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
        <el-select
          v-model="statusFilter"
          class="status-control"
          aria-label="Task status"
        >
          <el-option
            label="All status"
            value="all"
          />
          <el-option
            label="Running"
            value="running"
          />
          <el-option
            label="Completed"
            value="completed"
          />
          <el-option
            label="Failed"
            value="failed"
          />
          <el-option
            label="Cancelled"
            value="cancelled"
          />
        </el-select>
        <el-tooltip
          content="Image provider settings"
          placement="bottom"
        >
          <button
            class="toolbar-icon"
            type="button"
            @click="settingsDialog.open()"
          >
            <el-icon><Setting /></el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          content="New image task"
          placement="bottom"
        >
          <button
            class="toolbar-icon primary"
            type="button"
            @click="resetComposer"
          >
            <el-icon><Plus /></el-icon>
          </button>
        </el-tooltip>
      </div>
    </header>

    <main
      ref="galleryRef"
      class="gallery-scroll"
    >
      <div
        v-if="imageStore.loading && !imageStore.taskHistory.length"
        class="gallery-state"
      >
        <el-icon
          class="state-spinner"
          size="28"
        >
          <Loading />
        </el-icon>
        <span>Loading image tasks</span>
      </div>
      <div
        v-else-if="!filteredTasks.length"
        class="gallery-state"
      >
        <el-icon size="32">
          <Picture />
        </el-icon>
        <strong>No image tasks match this view</strong>
      </div>
      <div
        v-else
        class="task-grid"
      >
        <ImageTaskCard
          v-for="task in filteredTasks"
          :id="`image-task-${task.id}`"
          :key="task.id"
          :task="task"
          :selected="selectedTaskId === task.id"
          @preview="openPreview"
          @reuse="reuseTask"
          @edit-output="editOutput"
          @cancel="cancelTask"
          @delete="deleteTask"
        />
      </div>
    </main>

    <section
      class="composer-band"
      :class="{ dragging: isDragging }"
      @dragenter.prevent="isDragging = true"
      @dragover.prevent="isDragging = true"
      @dragleave.self="isDragging = false"
      @drop.prevent="handleDrop"
    >
      <div
        v-if="referenceImages.length || maskPreviewUrl"
        class="reference-strip"
      >
        <div
          v-for="(image, index) in referenceImages"
          :key="image.url"
          class="reference-item"
        >
          <img
            :src="image.url"
            :alt="image.name"
          >
          <span v-if="index === 0">Primary</span>
          <button
            type="button"
            title="Remove reference"
            @click="removeReference(index)"
          >
            <el-icon><Close /></el-icon>
          </button>
        </div>
        <div
          v-if="maskPreviewUrl"
          class="reference-item mask-item"
        >
          <img
            :src="maskPreviewUrl"
            alt="Edit mask"
          >
          <span>Mask</span>
          <button
            type="button"
            title="Remove mask"
            @click="clearMask"
          >
            <el-icon><Close /></el-icon>
          </button>
        </div>
      </div>

      <div class="prompt-row">
        <textarea
          v-model="prompt"
          class="prompt-input"
          rows="2"
          maxlength="32000"
          placeholder="Describe the image to generate or the changes to apply"
          @keydown.ctrl.enter.prevent="generate"
          @keydown.meta.enter.prevent="generate"
          @paste="handlePaste"
        />
        <input
          ref="fileInput"
          type="file"
          accept="image/png,image/jpeg,image/webp"
          multiple
          hidden
          @change="handleFileSelection"
        >
        <el-tooltip
          content="Add reference images"
          placement="top"
        >
          <button
            class="composer-icon"
            type="button"
            @click="fileInput.click()"
          >
            <el-icon><Paperclip /></el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          content="Edit mask"
          placement="top"
        >
          <button
            class="composer-icon"
            type="button"
            :disabled="!referenceImages.length"
            @click="maskEditorVisible = true"
          >
            <el-icon><Brush /></el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          :content="configurationExpanded ? 'Collapse image settings' : 'Expand image settings'"
          placement="top"
        >
          <button
            class="composer-icon configuration-toggle"
            type="button"
            :aria-label="configurationExpanded ? 'Collapse image settings' : 'Expand image settings'"
            :aria-expanded="configurationExpanded"
            @click="configurationExpanded = !configurationExpanded"
          >
            <el-icon>
              <CaretTop v-if="configurationExpanded" />
              <CaretBottom v-else />
            </el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          content="Generate"
          placement="top"
        >
          <button
            class="generate-button"
            type="button"
            :disabled="submitting || !prompt.trim()"
            @click="generate"
          >
            <el-icon v-if="!submitting">
              <Right />
            </el-icon>
            <el-icon
              v-else
              class="spin"
            >
              <Loading />
            </el-icon>
          </button>
        </el-tooltip>
      </div>

      <div
        v-show="configurationExpanded"
        class="configuration-options"
      >
        <section
          class="preset-panel"
          :class="{ collapsed: !presetsExpanded }"
          aria-labelledby="image-preset-heading"
        >
          <div class="preset-heading">
            <div class="preset-heading-copy">
              <span class="preset-heading-icon">
                <el-icon><MagicStick /></el-icon>
              </span>
              <div>
                <strong id="image-preset-heading">Image templates</strong>
                <span>Ready-to-use styles for creative and technical images</span>
              </div>
            </div>
            <div
              class="preset-category-switch"
              role="tablist"
              aria-label="Image template category"
            >
              <button
                v-for="category in imagePromptPresetCategories"
                :key="category.id"
                type="button"
                role="tab"
                :aria-selected="selectedPresetCategory === category.id"
                :class="{ active: selectedPresetCategory === category.id }"
                @click="selectedPresetCategory = category.id"
              >
                {{ category.label }}
              </button>
            </div>
            <el-tooltip
              :content="presetsExpanded ? 'Collapse prompt presets' : 'Expand prompt presets'"
              placement="top"
            >
              <button
                class="preset-toggle"
                type="button"
                :aria-label="presetsExpanded ? 'Collapse prompt presets' : 'Expand prompt presets'"
                :aria-expanded="presetsExpanded"
                @click="presetsExpanded = !presetsExpanded"
              >
                <el-icon>
                  <CaretTop v-if="presetsExpanded" />
                  <CaretBottom v-else />
                </el-icon>
              </button>
            </el-tooltip>
          </div>

          <div
            v-show="presetsExpanded"
            class="preset-grid"
          >
            <button
              v-for="preset in visiblePromptPresets"
              :key="preset.id"
              class="preset-card"
              :class="[`preset-${preset.id}`, { selected: selectedPresetId === preset.id }]"
              type="button"
              :aria-pressed="selectedPresetId === preset.id"
              @click="applyPreset(preset)"
            >
              <span
                v-if="preset.thumbnail"
                class="preset-cover"
              >
                <img
                  :src="preset.thumbnail"
                  :alt="preset.label"
                  loading="lazy"
                >
                <span class="preset-ratio">{{ preset.aspectRatio }}</span>
              </span>
              <span
                v-else
                class="preset-cover preset-cover-icon"
              >
                <el-icon size="25"><component :is="preset.icon" /></el-icon>
                <span class="preset-ratio">{{ preset.aspectRatio }}</span>
              </span>
              <span class="preset-card-body">
                <span class="preset-card-copy">
                  <strong>{{ preset.label }}</strong>
                  <span>{{ preset.description }}</span>
                </span>
                <span
                  v-if="preset.tags.length"
                  class="preset-tags"
                >
                  <span
                    v-for="tag in preset.tags"
                    :key="tag"
                  >
                    {{ tag }}
                  </span>
                </span>
              </span>
              <span class="preset-card-footer">
                <span>{{ preset.sizeLabel }}</span>
                <span class="preset-use">Use preset</span>
              </span>
            </button>
          </div>
        </section>

        <div
          v-if="selectedPresetId === 'knowledge-base' || selectedKnowledgeDocumentIds.length"
          class="knowledge-context-row"
        >
          <div class="knowledge-context-label">
            <el-icon><CollectionTag /></el-icon>
            <span>
              <strong>Knowledge sources</strong>
              <small>Ground the visual in selected canonical documents</small>
            </span>
          </div>
          <el-select
            v-model="selectedKnowledgeDocumentIds"
            class="knowledge-context-select"
            multiple
            collapse-tags
            collapse-tags-tooltip
            clearable
            :loading="knowledgeLoading"
            placeholder="Select knowledge documents"
            aria-label="Knowledge sources"
          >
            <el-option
              v-for="document in knowledgeDocuments"
              :key="document.id"
              :label="document.title || document.id"
              :value="document.id"
            >
              <span class="knowledge-option">
                <strong>{{ document.title || document.id }}</strong>
                <small>{{ document.chip || 'GENERAL' }} - {{ document.repository_path || 'canonical document' }}</small>
              </span>
            </el-option>
          </el-select>
          <el-tooltip
            content="Refresh knowledge documents"
            placement="top"
          >
            <button
              class="knowledge-refresh"
              type="button"
              :disabled="knowledgeLoading"
              aria-label="Refresh knowledge documents"
              @click="loadKnowledgeDocuments"
            >
              <el-icon :class="{ spin: knowledgeLoading }">
                <Refresh />
              </el-icon>
            </button>
          </el-tooltip>
        </div>

        <div class="parameter-row">
          <label class="parameter-control size-control">
            <span>Size</span>
            <el-select v-model="params.size">
              <el-option
                label="Auto"
                value="auto"
              />
              <el-option-group label="1K">
                <el-option
                  label="Square 1024"
                  value="1024x1024"
                />
                <el-option
                  label="Landscape 1536 x 1024"
                  value="1536x1024"
                />
                <el-option
                  label="Portrait 1024 x 1536"
                  value="1024x1536"
                />
                <el-option
                  label="Wide 1280 x 720"
                  value="1280x720"
                />
                <el-option
                  label="Portrait 9:16 864 x 1536"
                  value="864x1536"
                />
                <el-option
                  label="Landscape 4:3 1024 x 768"
                  value="1024x768"
                />
                <el-option
                  label="Wide 16:9 1536 x 864"
                  value="1536x864"
                />
              </el-option-group>
              <el-option-group label="2K">
                <el-option
                  label="Square 2048"
                  value="2048x2048"
                />
                <el-option
                  label="Landscape 2160 x 1440"
                  value="2160x1440"
                />
                <el-option
                  label="Portrait 1440 x 2160"
                  value="1440x2160"
                />
                <el-option
                  label="Wide 2560 x 1440"
                  value="2560x1440"
                />
                <el-option
                  label="Portrait 9:16 1152 x 2048"
                  value="1152x2048"
                />
                <el-option
                  label="Landscape 4:3 2048 x 1536"
                  value="2048x1536"
                />
                <el-option
                  label="Wide 16:9 2048 x 1152"
                  value="2048x1152"
                />
              </el-option-group>
              <el-option-group label="4K">
                <el-option
                  label="Square 2880"
                  value="2880x2880"
                />
                <el-option
                  label="Landscape 3456 x 2304"
                  value="3456x2304"
                />
                <el-option
                  label="Portrait 2304 x 3456"
                  value="2304x3456"
                />
                <el-option
                  label="Wide 3840 x 2160"
                  value="3840x2160"
                />
              </el-option-group>
            </el-select>
          </label>
          <label class="parameter-control">
            <span>Quality</span>
            <el-select v-model="params.quality">
              <el-option
                label="Auto"
                value="auto"
              />
              <el-option
                label="Low"
                value="low"
              />
              <el-option
                label="Medium"
                value="medium"
              />
              <el-option
                label="High"
                value="high"
              />
            </el-select>
          </label>
          <label class="parameter-control format-control">
            <span>Format</span>
            <el-segmented
              v-model="params.outputFormat"
              :options="formatOptions"
            />
          </label>
          <label class="parameter-control count-control">
            <span>Count</span>
            <el-input-number
              v-model="params.imageCount"
              :min="1"
              :max="10"
              controls-position="right"
            />
          </label>
          <label class="parameter-control">
            <span>Moderation</span>
            <el-select v-model="params.moderation">
              <el-option
                label="Auto"
                value="auto"
              />
              <el-option
                label="Low"
                value="low"
              />
            </el-select>
          </label>
          <label
            v-if="params.outputFormat !== 'png'"
            class="parameter-control compression-control"
          >
            <span>Compression {{ params.outputCompression }}</span>
            <el-slider
              v-model="params.outputCompression"
              :min="0"
              :max="100"
            />
          </label>
          <label class="toggle-control">
            <span>Transparent</span>
            <el-switch v-model="params.transparentOutput" />
          </label>
          <label class="toggle-control">
            <span>Enhance prompt</span>
            <el-switch v-model="params.enhancePrompt" />
          </label>
        </div>
      </div>
    </section>

    <ImageGenerationSettingsDialog ref="settingsDialog" />
    <ImageMaskEditor
      v-model="maskEditorVisible"
      :image="referenceImages[0]"
      @save="applyMask"
    />

    <el-dialog
      v-model="previewVisible"
      width="min(1120px, 96vw)"
      class="image-preview-dialog"
      destroy-on-close
    >
      <template #header>
        <div class="preview-heading">
          <strong>{{ previewItem?.task?.input?.prompt || 'Generated image' }}</strong>
          <span v-if="previewItem?.image">
            {{ previewItem.image.width }} x {{ previewItem.image.height }}
          </span>
        </div>
      </template>
      <div class="preview-stage">
        <img
          v-if="previewItem?.image"
          :src="previewItem.image.url"
          :alt="previewItem.task.input?.prompt || 'Generated image'"
        >
      </div>
      <template #footer>
        <div class="preview-actions">
          <el-button @click="previewVisible = false">
            Close
          </el-button>
          <el-button
            v-if="previewItem?.image"
            tag="a"
            :href="previewItem.image.download_url"
            :download="previewItem.image.filename"
            type="primary"
          >
            <el-icon><Download /></el-icon>
            Download
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  CaretBottom,
  CaretTop,
  Brush,
  Close,
  CollectionTag,
  Download,
  Loading,
  MagicStick,
  Paperclip,
  Picture,
  PictureRounded,
  Plus,
  Refresh,
  Right,
  Search,
  Setting,
} from '@element-plus/icons-vue'
import ImageGenerationSettingsDialog from './ImageGenerationSettingsDialog.vue'
import ImageMaskEditor from './ImageMaskEditor.vue'
import ImageTaskCard from './ImageTaskCard.vue'
import {
  getImagePresetUpdates,
  imagePromptPresetCategories,
  imagePromptPresets,
} from '../constants/imagePromptPresets.js'
import {
  cancelImageGenerationTask,
  createImageGenerationTask,
  getImageGenerationSettings,
} from '../api/imageGeneration.js'
import { listKnowledgeDocuments } from '../api/knowledgeBase.js'
import { useImageGenerationStore } from '../stores/imageGeneration.js'

const props = defineProps({
  activeTask: Object,
})
const emit = defineEmits(['new-task', 'task-updated'])
const imageStore = useImageGenerationStore()
const galleryRef = ref(null)
const fileInput = ref(null)
const settingsDialog = ref(null)
const searchText = ref('')
const statusFilter = ref('all')
const prompt = ref('')
const presetsExpanded = ref(true)
const configurationExpanded = ref(true)
const selectedPresetId = ref(null)
const selectedPresetCategory = ref('creative')
const knowledgeDocuments = ref([])
const selectedKnowledgeDocumentIds = ref([])
const knowledgeLoading = ref(false)
const referenceImages = ref([])
const maskFile = ref(null)
const maskPreviewUrl = ref('')
const maskEditorVisible = ref(false)
const submitting = ref(false)
const isDragging = ref(false)
const selectedTaskId = ref(null)
const previewVisible = ref(false)
const previewItem = ref(null)
const formatOptions = [
  { label: 'PNG', value: 'png' },
  { label: 'JPEG', value: 'jpeg' },
  { label: 'WebP', value: 'webp' },
]
const params = reactive({
  size: 'auto',
  quality: 'auto',
  outputFormat: 'png',
  outputCompression: 90,
  moderation: 'auto',
  imageCount: 1,
  transparentOutput: false,
  enhancePrompt: true,
})
let pollTimer = null
let polling = false
let disposed = false

function isCurrentRequest(revision) {
  return !disposed && revision === imageStore.accountRevision
}

function invalidateWorkspace() {
  disposed = true
  if (pollTimer) window.clearInterval(pollTimer)
  pollTimer = null
  referenceImages.value.forEach((image) => URL.revokeObjectURL(image.url))
  referenceImages.value = []
  clearMask()
  maskEditorVisible.value = false
  prompt.value = ''
  knowledgeDocuments.value = []
  selectedKnowledgeDocumentIds.value = []
  selectedTaskId.value = null
  previewVisible.value = false
  previewItem.value = null
}

watch(() => imageStore.accountRevision, invalidateWorkspace, { flush: 'sync' })

const filteredTasks = computed(() => {
  const query = searchText.value.trim().toLowerCase()
  return imageStore.taskHistory.filter((task) => {
    if (statusFilter.value !== 'all' && task.status !== statusFilter.value) return false
    if (!query) return true
    const haystack = [
      task.input?.prompt,
      task.result?.model,
      task.status,
    ].filter(Boolean).join(' ').toLowerCase()
    return haystack.includes(query)
  })
})

const visiblePromptPresets = computed(() => imagePromptPresets.filter(
  (preset) => preset.category === selectedPresetCategory.value,
))

watch(() => props.activeTask?.id, async (taskId) => {
  if (!taskId) return
  selectedTaskId.value = taskId
  await nextTick()
  document.getElementById(`image-task-${taskId}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })
})

watch(() => params.transparentOutput, (enabled) => {
  if (enabled) params.outputFormat = 'png'
})

onMounted(async () => {
  const revision = imageStore.accountRevision
  try {
    await imageStore.loadHistory()
  } catch (error) {
    if (isCurrentRequest(revision)) ElMessage.error(error.message || 'Failed to load image task history')
  }
  if (!isCurrentRequest(revision)) return
  await loadKnowledgeDocuments()
  if (!isCurrentRequest(revision)) return
  pollTimer = window.setInterval(refreshRunningTasks, 2000)
})

onBeforeUnmount(() => {
  disposed = true
  if (pollTimer) window.clearInterval(pollTimer)
  referenceImages.value.forEach((image) => URL.revokeObjectURL(image.url))
  if (maskPreviewUrl.value) URL.revokeObjectURL(maskPreviewUrl.value)
})

async function refreshRunningTasks() {
  if (disposed || polling) return
  const revision = imageStore.accountRevision
  const runningTasks = imageStore.taskHistory.filter((task) => task.status === 'running')
  if (!runningTasks.length) return
  polling = true
  try {
    const results = await Promise.allSettled(
      runningTasks.map((task) => imageStore.refreshTask(task.id)),
    )
    if (!isCurrentRequest(revision)) return
    for (const result of results) {
      if (result.status === 'fulfilled' && result.value) emit('task-updated', result.value)
    }
  } finally {
    polling = false
  }
}

async function loadKnowledgeDocuments() {
  if (disposed || knowledgeLoading.value) return
  const revision = imageStore.accountRevision
  knowledgeLoading.value = true
  try {
    const response = await listKnowledgeDocuments()
    if (!isCurrentRequest(revision)) return
    const documents = Array.isArray(response?.documents) ? response.documents : []
    knowledgeDocuments.value = documents
    const availableIds = new Set(documents.map((document) => String(document.id)))
    selectedKnowledgeDocumentIds.value = selectedKnowledgeDocumentIds.value
      .filter((documentId) => availableIds.has(String(documentId)))
  } catch (error) {
    if (!isCurrentRequest(revision)) return
    ElMessage.error(error.message || 'Failed to load knowledge documents')
  } finally {
    knowledgeLoading.value = false
  }
}

function applyPreset(value) {
  const preset = typeof value === 'string'
    ? imagePromptPresets.find((item) => item.prompt === value)
    : value
  const updates = getImagePresetUpdates(preset)
  if (!updates) return
  prompt.value = updates.prompt
  selectedPresetId.value = updates.selectedPresetId
  Object.assign(params, updates.params)
}

function resetComposer() {
  prompt.value = ''
  selectedPresetId.value = null
  configurationExpanded.value = true
  presetsExpanded.value = true
  selectedKnowledgeDocumentIds.value = []
  params.size = 'auto'
  params.quality = 'auto'
  params.outputFormat = 'png'
  params.outputCompression = 90
  params.moderation = 'auto'
  params.imageCount = 1
  params.transparentOutput = false
  params.enhancePrompt = true
  referenceImages.value.forEach((image) => URL.revokeObjectURL(image.url))
  referenceImages.value = []
  clearMask()
  selectedTaskId.value = null
  emit('new-task')
}

function handleFileSelection(event) {
  addReferenceFiles(Array.from(event.target.files || []))
  event.target.value = ''
}

function handleDrop(event) {
  isDragging.value = false
  addReferenceFiles(Array.from(event.dataTransfer?.files || []))
}

function handlePaste(event) {
  const files = Array.from(event.clipboardData?.items || [])
    .filter((item) => item.kind === 'file' && item.type.startsWith('image/'))
    .map((item) => item.getAsFile())
    .filter(Boolean)
  if (!files.length) return
  event.preventDefault()
  addReferenceFiles(files)
}

function addReferenceFiles(files) {
  const accepted = files.filter((file) => ['image/png', 'image/jpeg', 'image/webp'].includes(file.type))
  const remaining = 16 - referenceImages.value.length
  if (remaining <= 0) {
    ElMessage.warning('A maximum of 16 reference images is allowed')
    return
  }
  if (accepted.length !== files.length) {
    ElMessage.warning('Only PNG, JPEG, and WebP reference images are supported')
  }
  for (const file of accepted.slice(0, remaining)) {
    referenceImages.value.push({
      file,
      name: file.name,
      url: URL.createObjectURL(file),
    })
  }
}

function removeReference(index) {
  URL.revokeObjectURL(referenceImages.value[index].url)
  referenceImages.value.splice(index, 1)
  if (index === 0) clearMask()
}

function applyMask(blob) {
  clearMask()
  maskFile.value = new File([blob], 'mask.png', { type: 'image/png' })
  maskPreviewUrl.value = URL.createObjectURL(blob)
}

function clearMask() {
  maskFile.value = null
  if (maskPreviewUrl.value) URL.revokeObjectURL(maskPreviewUrl.value)
  maskPreviewUrl.value = ''
}

async function generate() {
  if (disposed || !prompt.value.trim() || submitting.value) return
  const accountRevision = imageStore.accountRevision
  submitting.value = true
  try {
    const settings = await getImageGenerationSettings()
    if (!isCurrentRequest(accountRevision)) return
    if (!settings.configured) {
      settingsDialog.value.open()
      ElMessage.warning('Configure an image provider before generating')
      return
    }
    const response = await createImageGenerationTask({
      prompt: prompt.value.trim(),
      size: params.size,
      quality: params.quality,
      outputFormat: params.outputFormat,
      outputCompression: params.outputCompression,
      moderation: params.moderation,
      imageCount: params.imageCount,
      transparentOutput: params.transparentOutput,
      enhancePrompt: params.enhancePrompt,
      knowledgeDocumentIds: selectedKnowledgeDocumentIds.value,
      referenceImages: referenceImages.value,
      maskFile: maskFile.value,
    })
    const task = imageStore.upsertTask({
      task_id: response.task_id,
      status: 'running',
      progress: 5,
      message: response.message,
      input: {
        prompt: prompt.value.trim(),
        params: {
          size: params.size,
          quality: params.quality,
          output_format: params.outputFormat,
          output_compression: params.outputCompression,
          moderation: params.moderation,
          image_count: params.imageCount,
          transparent_output: params.transparentOutput,
          enhance_prompt: params.enhancePrompt,
        },
        reference_images: referenceImages.value.map((image) => ({ filename: image.name })),
        has_mask: Boolean(maskFile.value),
        knowledge_document_ids: [...selectedKnowledgeDocumentIds.value],
      },
      result: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }, accountRevision)
    if (!task || !isCurrentRequest(accountRevision)) return
    selectedTaskId.value = task.id
    emit('task-updated', task)
    ElMessage.success('Image generation started')
  } catch (error) {
    if (!isCurrentRequest(accountRevision)) return
    ElMessage.error(error.message || 'Failed to start image generation')
  } finally {
    submitting.value = false
  }
}

function reuseTask(task) {
  prompt.value = task.input?.prompt || ''
  selectedPresetId.value = null
  selectedKnowledgeDocumentIds.value = task.input?.knowledge_document_ids || []
  const taskParams = task.input?.params || {}
  params.size = taskParams.size || 'auto'
  params.quality = taskParams.quality || 'auto'
  params.outputFormat = taskParams.output_format || 'png'
  params.outputCompression = taskParams.output_compression ?? 90
  params.moderation = taskParams.moderation || 'auto'
  params.imageCount = taskParams.image_count || 1
  params.transparentOutput = Boolean(taskParams.transparent_output)
  params.enhancePrompt = taskParams.enhance_prompt !== false
  selectedTaskId.value = task.id
}

async function editOutput(task) {
  if (disposed) return
  const revision = imageStore.accountRevision
  const image = task.result?.images?.[0]
  if (!image) return
  try {
    const response = await fetch(image.url)
    if (!response.ok) throw new Error('Failed to load generated image')
    const blob = await response.blob()
    if (!isCurrentRequest(revision)) return
    const extension = blob.type === 'image/jpeg' ? 'jpg' : blob.type.split('/')[1] || 'png'
    const file = new File([blob], `generated-reference.${extension}`, { type: blob.type })
    resetComposer()
    prompt.value = task.input?.prompt || ''
    addReferenceFiles([file])
  } catch (error) {
    if (!isCurrentRequest(revision)) return
    ElMessage.error(error.message || 'Failed to reuse the generated image')
  }
}

function openPreview(item) {
  previewItem.value = item
  previewVisible.value = true
}

async function cancelTask(task) {
  if (disposed) return
  const accountRevision = imageStore.accountRevision
  try {
    const updated = await cancelImageGenerationTask(task.id)
    const normalized = imageStore.upsertTask(updated, accountRevision)
    if (!normalized || !isCurrentRequest(accountRevision)) return
    emit('task-updated', normalized)
    ElMessage.success('Image generation cancelled')
  } catch (error) {
    if (!isCurrentRequest(accountRevision)) return
    ElMessage.error(error.message || 'Failed to cancel the task')
  }
}

async function deleteTask(task) {
  if (disposed) return
  const revision = imageStore.accountRevision
  try {
    await ElMessageBox.confirm(
      'Delete this task and all generated images?',
      'Delete image task',
      { confirmButtonText: 'Delete', cancelButtonText: 'Cancel', type: 'warning' },
    )
    if (!isCurrentRequest(revision)) return
    await imageStore.removeTask(task.id)
    if (!isCurrentRequest(revision)) return
    if (selectedTaskId.value === task.id) {
      selectedTaskId.value = null
      emit('task-updated', null)
    }
    ElMessage.success('Image task deleted')
  } catch (error) {
    if (!isCurrentRequest(revision)) return
    if (error !== 'cancel' && error !== 'close') {
      ElMessage.error(error.message || 'Failed to delete the task')
    }
  }
}
</script>

<style scoped>
.image-workspace {
  min-height: 0;
  display: grid;
  flex: 1;
  grid-template-rows: 58px minmax(0, 1fr) auto;
  color: #1f2937;
  background: #f8fafc;
}

.workspace-toolbar {
  min-width: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 9px 18px;
  border-bottom: 1px solid #e5e7eb;
  background: #ffffff;
}

.toolbar-title {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 10px;
}

.agent-mark {
  width: 34px;
  height: 34px;
  display: grid;
  flex: 0 0 34px;
  place-items: center;
  border-radius: 7px;
  color: #2563eb;
  background: #eff6ff;
}

.toolbar-title div {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.toolbar-title strong {
  overflow: hidden;
  color: #111827;
  font-size: 14px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.toolbar-title span:last-child {
  color: #94a3b8;
  font-size: 11px;
}

.toolbar-controls {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 7px;
}

.search-control {
  width: min(260px, 24vw);
}

.status-control {
  width: 126px;
}

.toolbar-icon,
.composer-icon,
.generate-button {
  width: 34px;
  height: 34px;
  display: grid;
  flex: 0 0 34px;
  place-items: center;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  color: #475569;
  background: #ffffff;
  cursor: pointer;
}

.toolbar-icon:hover,
.composer-icon:hover:not(:disabled) {
  color: #2563eb;
  border-color: #93c5fd;
  background: #eff6ff;
}

.toolbar-icon.primary,
.generate-button {
  color: #ffffff;
  border-color: #2563eb;
  background: #2563eb;
}

.toolbar-icon.primary:hover,
.generate-button:hover:not(:disabled) {
  border-color: #1d4ed8;
  background: #1d4ed8;
}

.composer-icon:disabled,
.generate-button:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.gallery-scroll {
  min-height: 0;
  overflow-y: auto;
  padding: 18px;
  scrollbar-color: #cbd5e1 transparent;
  scrollbar-width: thin;
}

.task-grid {
  max-width: 1480px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
  margin: 0 auto;
  padding-bottom: 4px;
}

.gallery-state {
  min-height: 260px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 10px;
  color: #94a3b8;
  font-size: 12px;
}

.gallery-state strong {
  color: #64748b;
  font-size: 13px;
}

.state-spinner,
.spin {
  animation: spin 1s linear infinite;
}

.composer-band {
  position: relative;
  z-index: 2;
  min-height: 0;
  max-height: min(70vh, 560px);
  overflow-y: auto;
  padding: 12px 18px 14px;
  border-top: 1px solid #dbe2ea;
  background: #ffffff;
  box-shadow: 0 -8px 22px rgb(15 23 42 / 5%);
}

.configuration-options {
  margin-top: 10px;
}

.configuration-toggle {
  color: #2563eb;
  border-color: #bfdbfe;
  background: #eff6ff;
}

.preset-panel {
  max-width: 1480px;
  margin: 0 auto 9px;
  padding: 9px 10px 10px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: #f8fafc;
}

.preset-panel.collapsed {
  padding-bottom: 9px;
}

.preset-heading {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 12px;
}

.preset-heading-copy {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 9px;
}

.preset-heading-icon {
  width: 27px;
  height: 27px;
  display: grid;
  flex: 0 0 27px;
  place-items: center;
  border-radius: 6px;
  color: #2563eb;
  background: #dbeafe;
}

.preset-heading-copy > div {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.preset-category-switch {
  display: flex;
  flex: 0 0 auto;
  gap: 2px;
  margin-left: auto;
  padding: 2px;
  border: 1px solid #dbe2ea;
  border-radius: 6px;
  background: #ffffff;
}

.preset-category-switch button {
  min-height: 25px;
  padding: 0 9px;
  border: 0;
  border-radius: 4px;
  color: #64748b;
  background: transparent;
  font-size: 10px;
  font-weight: 600;
  cursor: pointer;
}

.preset-category-switch button.active {
  color: #1d4ed8;
  background: #eff6ff;
}

.preset-heading-copy strong {
  color: #334155;
  font-size: 12px;
  font-weight: 700;
}

.preset-heading-copy span:last-child {
  overflow: hidden;
  color: #94a3b8;
  font-size: 10px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.preset-toggle {
  width: 28px;
  height: 28px;
  display: grid;
  flex: 0 0 28px;
  place-items: center;
  padding: 0;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  color: #64748b;
  background: #ffffff;
  cursor: pointer;
}

.preset-toggle:hover {
  border-color: #93c5fd;
  color: #2563eb;
  background: #eff6ff;
}

.preset-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
  margin-top: 9px;
}

.preset-card {
  min-width: 0;
  min-height: 190px;
  display: flex;
  flex-direction: column;
  padding: 0;
  overflow: hidden;
  border: 1px solid #e2e8f0;
  border-radius: 7px;
  color: #334155;
  background: #ffffff;
  text-align: left;
  cursor: pointer;
  transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease;
}

.preset-card:hover {
  border-color: #93c5fd;
  box-shadow: 0 5px 14px rgb(15 23 42 / 8%);
  transform: translateY(-1px);
}

.preset-card.selected {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgb(37 99 235 / 12%);
}

.preset-card:focus-visible,
.preset-category-switch button:focus-visible {
  outline: 2px solid #2563eb;
  outline-offset: 2px;
}

.preset-cover {
  position: relative;
  height: 94px;
  display: grid;
  place-items: center;
  overflow: hidden;
  background: #e2e8f0;
}

.preset-cover img {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
}

.preset-cover-icon {
  color: #2563eb;
  background: #eff6ff;
}

.preset-packaging .preset-cover-icon {
  color: #c2410c;
  background: #fff7ed;
}

.preset-article-summary .preset-cover-icon {
  color: #047857;
  background: #ecfdf5;
}

.preset-knowledge-base .preset-cover-icon {
  color: #7c3aed;
  background: #f5f3ff;
}

.preset-ratio {
  position: absolute;
  top: 6px;
  right: 6px;
  padding: 3px 5px;
  border-radius: 3px;
  color: #ffffff;
  background: rgb(15 23 42 / 82%);
  font-size: 10px;
  font-weight: 700;
  line-height: 1;
}

.preset-card-body {
  min-width: 0;
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 5px;
  padding: 8px 9px 0;
}

.preset-card-copy {
  min-width: 0;
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
}

.preset-card-copy strong {
  display: -webkit-box;
  overflow: hidden;
  color: #1e293b;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.3;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.preset-card-copy > span {
  display: -webkit-box;
  overflow: hidden;
  color: #64748b;
  font-size: 10px;
  line-height: 1.4;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.preset-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.preset-tags span {
  max-width: 100%;
  overflow: hidden;
  padding: 2px 5px;
  border: 1px solid #dbeafe;
  border-radius: 3px;
  color: #2563eb;
  background: #eff6ff;
  font-size: 9px;
  line-height: 1.25;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.preset-card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-top: auto;
  padding: 7px 9px 9px;
  color: #94a3b8;
  font-size: 9px;
}

.preset-use {
  color: #2563eb;
  font-weight: 700;
}

.knowledge-context-row {
  max-width: 1480px;
  display: flex;
  align-items: center;
  gap: 9px;
  margin: 0 auto 9px;
  padding: 8px 10px;
  border: 1px solid #ddd6fe;
  border-radius: 7px;
  background: #faf5ff;
}

.knowledge-context-label {
  min-width: 185px;
  display: flex;
  align-items: center;
  gap: 7px;
  color: #7c3aed;
}

.knowledge-context-label > span {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.knowledge-context-label strong {
  color: #5b21b6;
  font-size: 11px;
}

.knowledge-context-label small {
  overflow: hidden;
  color: #8b5cf6;
  font-size: 9px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.knowledge-context-select {
  min-width: 0;
  flex: 1;
}

.knowledge-option {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.knowledge-option strong,
.knowledge-option small {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.knowledge-option strong {
  color: #334155;
  font-size: 11px;
}

.knowledge-option small {
  color: #94a3b8;
  font-size: 9px;
}

.knowledge-refresh {
  width: 30px;
  height: 30px;
  display: grid;
  flex: 0 0 30px;
  place-items: center;
  padding: 0;
  border: 1px solid #ddd6fe;
  border-radius: 6px;
  color: #7c3aed;
  background: #ffffff;
  cursor: pointer;
}

.knowledge-refresh:hover:not(:disabled) {
  border-color: #a78bfa;
  background: #f5f3ff;
}

.knowledge-refresh:disabled {
  cursor: wait;
  opacity: 0.55;
}

.composer-band.dragging {
  background: #eff6ff;
  box-shadow: inset 0 0 0 2px #60a5fa;
}

.reference-strip {
  max-width: 1480px;
  display: flex;
  gap: 8px;
  overflow-x: auto;
  margin: 0 auto 9px;
  padding-bottom: 2px;
}

.reference-item {
  width: 58px;
  height: 58px;
  position: relative;
  flex: 0 0 58px;
  overflow: hidden;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  background: #e2e8f0;
}

.reference-item img {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
}

.reference-item span {
  position: absolute;
  right: 3px;
  bottom: 3px;
  left: 3px;
  overflow: hidden;
  padding: 2px 3px;
  border-radius: 3px;
  color: #ffffff;
  background: rgb(15 23 42 / 74%);
  font-size: 8px;
  text-align: center;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.reference-item button {
  width: 19px;
  height: 19px;
  position: absolute;
  top: 3px;
  right: 3px;
  display: grid;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: 50%;
  color: #ffffff;
  background: rgb(15 23 42 / 80%);
  cursor: pointer;
}

.mask-item {
  border-color: #60a5fa;
  background-color: #e2e8f0;
  background-image:
    linear-gradient(45deg, #ffffff 25%, transparent 25%),
    linear-gradient(-45deg, #ffffff 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #ffffff 75%),
    linear-gradient(-45deg, transparent 75%, #ffffff 75%);
  background-position: 0 0, 0 5px, 5px -5px, -5px 0;
  background-size: 10px 10px;
}

.prompt-row {
  max-width: 1480px;
  display: flex;
  align-items: flex-end;
  gap: 7px;
  margin: 0 auto;
}

.prompt-input {
  min-width: 0;
  min-height: 52px;
  max-height: 118px;
  flex: 1;
  resize: vertical;
  box-sizing: border-box;
  padding: 10px 12px;
  border: 1px solid #cbd5e1;
  border-radius: 7px;
  outline: none;
  color: #1f2937;
  background: #ffffff;
  font: inherit;
  font-size: 13px;
  line-height: 1.5;
}

.prompt-input:focus {
  border-color: #60a5fa;
  box-shadow: 0 0 0 3px rgb(96 165 250 / 14%);
}

.prompt-input::placeholder {
  color: #94a3b8;
}

.generate-button {
  width: 42px;
  height: 42px;
  flex-basis: 42px;
}

.parameter-row {
  max-width: 1480px;
  display: grid;
  grid-template-columns: minmax(145px, 1.25fr) minmax(100px, .8fr) minmax(210px, 1.25fr) 110px minmax(100px, .7fr) auto;
  align-items: end;
  gap: 9px;
  margin: 10px auto 0;
}

.parameter-control,
.toggle-control {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 5px;
  color: #64748b;
  font-size: 10px;
  font-weight: 600;
}

.parameter-control :deep(.el-select),
.parameter-control :deep(.el-input-number) {
  width: 100%;
}

.compression-control {
  min-width: 150px;
}

.toggle-control {
  align-items: center;
  align-self: stretch;
  justify-content: flex-end;
  padding-bottom: 4px;
}

.preview-heading {
  min-width: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.preview-heading strong {
  overflow: hidden;
  color: #111827;
  font-size: 14px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.preview-heading span {
  flex: 0 0 auto;
  color: #64748b;
  font-size: 11px;
}

.preview-stage {
  min-height: 360px;
  max-height: 72vh;
  display: grid;
  place-items: center;
  overflow: auto;
  background: #111827;
}

.preview-stage img {
  max-width: 100%;
  max-height: 72vh;
  display: block;
  object-fit: contain;
}

.preview-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

@media (max-width: 1180px) {
  .task-grid {
    grid-template-columns: 1fr;
  }

  .parameter-row {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }

  .toggle-control {
    flex-direction: row;
    justify-content: space-between;
    padding: 7px 4px;
  }
}

@media (max-width: 760px) {
  .image-workspace {
    grid-template-rows: auto minmax(0, 1fr) auto;
  }

  .preset-heading {
    flex-wrap: wrap;
    row-gap: 7px;
  }

  .preset-heading-copy {
    flex: 1 1 calc(100% - 42px);
  }

  .preset-category-switch {
    order: 2;
    margin-left: 36px;
  }

  .preset-toggle {
    order: 1;
    margin-left: auto;
  }

  .workspace-toolbar {
    align-items: stretch;
    flex-direction: column;
    gap: 8px;
    padding: 10px 12px;
  }

  .toolbar-controls {
    width: 100%;
  }

  .search-control {
    width: auto;
    flex: 1;
  }

  .status-control {
    width: 112px;
  }

  .gallery-scroll {
    padding: 12px;
  }

  .composer-band {
    padding: 10px 12px 12px;
  }

  .prompt-row {
    align-items: center;
    flex-wrap: wrap;
  }

  .preset-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .knowledge-context-row {
    align-items: stretch;
    flex-wrap: wrap;
  }

  .knowledge-context-label {
    min-width: 100%;
  }

  .knowledge-context-select {
    min-width: calc(100% - 39px);
  }

  .prompt-input {
    min-width: calc(100% - 42px);
    order: -1;
  }

  .parameter-row {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .format-control,
  .compression-control {
    grid-column: 1 / -1;
  }
}

@media (max-width: 480px) {
  .status-control {
    display: none;
  }

  .parameter-row {
    grid-template-columns: 1fr;
  }

  .preset-grid {
    grid-template-columns: 1fr;
  }

  .preset-ratio {
    right: auto;
    left: 6px;
  }

  .format-control,
  .compression-control {
    grid-column: auto;
  }
}
</style>
