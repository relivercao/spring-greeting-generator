<template>
  <div class="knowledge-workspace">
    <div class="knowledge-topbar">
      <div class="topbar-left">
        <div
          class="agent-icon"
          :style="{ background: agent.color + '18', color: agent.color }"
        >
          <el-icon size="15">
            <Collection />
          </el-icon>
        </div>
        <span class="topbar-title">{{ agent.name }}</span>
        <span
          class="topbar-status"
          :class="{ ready: documents.length > 0 }"
        >
          {{ documents.length }} document{{ documents.length === 1 ? '' : 's' }}
        </span>
      </div>
      <el-button
        :icon="Refresh"
        circle
        title="Refresh documents"
        @click="refreshWorkspace"
      />
    </div>

    <div class="knowledge-body">
      <aside class="document-panel">
        <section class="panel-section upload-section">
          <div class="section-label">Add to knowledge base</div>
          <el-input
            v-model="form.title"
            clearable
            :disabled="uploading"
            placeholder="Name (optional, uses filename)"
            aria-label="Document name (optional)"
            @input="isAutoTitle = false"
          />
          <div
            class="drop-zone"
            :class="{ dragging: isDragging, selected: selectedFile, uploading }"
            role="button"
            tabindex="0"
            :aria-disabled="uploading"
            :aria-busy="uploading"
            @keydown.enter.prevent="!uploading && fileInput?.click()"
            @keydown.space.prevent="!uploading && fileInput?.click()"
            @click="!uploading && fileInput?.click()"
            @dragover.prevent="isDragging = true"
            @dragleave="isDragging = false"
            @drop.prevent="handleDrop"
          >
            <input
              ref="fileInput"
              type="file"
              accept=".md,.markdown,.txt,.pdf,.docx,.pptx,.xlsx,.html,.csv,.png,.jpg,.jpeg,.tiff,.bmp"
              hidden
              :disabled="uploading"
              @change="handleFileChange"
            >
            <el-icon
              v-if="uploading"
              class="upload-spinner"
              size="24"
            >
              <Refresh />
            </el-icon>
            <el-icon v-else size="24">
              <DocumentAdd />
            </el-icon>
            <span class="file-name">{{ uploading ? (selectedFileIsPdf ? 'Converting PDF to Markdown and indexing' : 'Converting and indexing') : selectedFile?.name || 'Choose a file or drop it here' }}</span>
            <span class="file-meta">{{ selectedFile ? formatSize(selectedFile.size) : 'PDF, Office, image, Markdown, or text' }}</span>
          </div>
        </section>

        <section class="panel-section document-list-section">
          <div class="section-label">
            Knowledge Documents
          </div>
          <div
            v-if="loadingDocuments"
            class="loading-state"
          >
            Loading...
          </div>
          <div
            v-else-if="documents.length === 0"
            class="empty-state"
          >
            No documents imported
          </div>
          <div
            v-else
            class="document-list"
          >
            <button
              type="button"
              class="document-row"
              :class="{ active: activeDocumentId === '' }"
              @click="activeDocumentId = ''"
            >
              <el-icon class="document-icon">
                <Collection />
              </el-icon>
              <span class="document-copy">
                <strong>All documents</strong>
                <small>Rank matches across the full knowledge base</small>
              </span>
            </button>
            <button
              v-for="document in documents"
              :key="document.id"
              type="button"
              class="document-row"
              :class="{ active: activeDocumentId === document.id }"
              @click="activeDocumentId = document.id"
            >
              <el-icon class="document-icon">
                <Files />
              </el-icon>
              <span class="document-copy">
                <strong>{{ document.title }}</strong>
                <small>{{ document.chip }} | {{ document.chunk_count ?? 0 }} search chunks | {{ document.source_lines ?? 0 }} source lines</small>
                <small :class="document.index_status === 'ready' ? 'document-index-ready' : 'document-index-pending'">
                  {{ document.index_status === 'ready' ? 'Indexed' : 'Index pending' }} | {{ document.register_count }} registers | {{ document.bitfield_count }} fields
                </small>
                <small
                  v-if="document.quality?.warnings?.length"
                  class="document-quality-warning"
                  :title="document.quality.warnings.join(' ')"
                >
                  Source review required
                </small>
              </span>
              <el-button
                :icon="Delete"
                text
                circle
                title="Delete document"
                @click.stop="removeDocument(document.id)"
              />
            </button>
          </div>
        </section>

        <details class="panel-section advanced-imports">
          <summary>Special imports and options</summary>
          <div class="advanced-content">
            <div class="section-label">Document details</div>
            <div class="metadata-grid">
              <el-input v-model="form.chip" placeholder="Chip, e.g. STM32F407" />
              <el-input v-model="form.revision" placeholder="Revision" />
              <el-input v-model="form.peripheralHint" placeholder="Peripheral hint" />
              <el-input v-model="form.docType" placeholder="Document type" />
              <el-input v-model="form.tags" placeholder="Tags, comma separated" />
            </div>
            <div v-if="selectedFileIsPdf" class="ocr-option">
              <span>Enhanced PDF OCR</span>
              <el-switch v-model="form.llmOcr" title="Use the configured Knowledge Base Agent model for visual OCR" />
            </div>
            <div class="advanced-tools">
              <el-button
                :icon="Search"
                size="small"
                :loading="previewingChunks"
                :disabled="!previewableSelectedFile || uploading"
                title="Preview structure-aware chunks without indexing"
                @click="previewSelectedFile"
              >
                Preview chunks
              </el-button>
            </div>

            <div class="section-heading advanced-heading">
              <div class="section-label">Source repository</div>
              <el-tag
                v-if="repositoryStatus"
                size="small"
                :type="repositoryStatus.git?.dirty ? 'warning' : 'success'"
              >
                {{ repositoryStatus.git?.dirty ? 'Dirty' : 'Ready' }}
              </el-tag>
            </div>
            <div class="repository-meta">
              <span>{{ repositoryStatus?.document_count ?? 0 }} canonical documents</span>
              <span v-if="repositoryStatus?.git?.commit">{{ repositoryStatus.git.branch }} @ {{ repositoryStatus.git.commit }}</span>
              <span v-else>Git repository is initializing</span>
            </div>
            <div class="repository-actions">
              <el-button
                :icon="RefreshRight"
                size="small"
                :loading="repositoryBusy"
                title="Pull and rebuild the knowledge index"
                @click="syncRepository"
              >
                {{ repositoryStatus?.git?.remote ? 'Sync' : 'Reindex' }}
              </el-button>
              <el-button
                :icon="DocumentChecked"
                size="small"
                :loading="publishing"
                title="Build the MkDocs human-readable site"
                @click="buildMkdocs"
              >
                Build site
              </el-button>
            </div>
            <div class="repository-links">
              <el-button
                v-if="repositoryStatus?.publisher?.built"
                :icon="Reading"
                text
                size="small"
                @click="openLink(repositoryStatus.publisher.local_url || repositoryStatus.local_preview_url)"
              >
                MkDocs
              </el-button>
              <el-button
                :icon="Link"
                text
                size="small"
                @click="openLink(repositoryStatus?.wikijs_url || repositoryStatus?.publisher?.wikijs_url)"
              >
                Wiki.js
              </el-button>
            </div>
            <div class="github-import">
              <el-input v-model="githubForm.repository" size="small" placeholder="GitHub owner/repository" />
              <div class="github-row">
                <el-input v-model="githubForm.ref" size="small" placeholder="Ref (optional)" />
                <el-button
                  :icon="Download"
                  size="small"
                  :loading="importingReference"
                  :disabled="!githubForm.repository.trim()"
                  title="Clone and import Markdown from GitHub"
                  @click="importGithub"
                >
                  GitHub
                </el-button>
              </div>
            </div>
            <div class="obsidian-import">
              <el-input v-model="obsidianForm.path" size="small" placeholder="Obsidian vault path" />
              <div class="obsidian-row">
                <el-input v-model="obsidianForm.chip" size="small" placeholder="Default chip (optional)" />
                <el-button
                  :icon="Files"
                  size="small"
                  :loading="importingObsidian"
                  :disabled="!obsidianForm.path.trim()"
                  title="Import Markdown notes from an Obsidian vault"
                  @click="importObsidian"
                >
                  Vault
                </el-button>
              </div>
            </div>
          </div>
        </details>
      </aside>

      <main class="answer-panel">
        <div
          ref="messagesEl"
          class="messages"
        >
          <div
            v-if="messages.length === 0"
            class="answer-empty"
          >
            <div class="answer-empty-icon">
              <Search />
            </div>
            <div class="answer-empty-title">
              Register-first knowledge search
            </div>
            <div v-if="visibleRegisterExamples.length" class="example-queries">
              <button
                v-for="example in visibleRegisterExamples"
                :key="example.id"
                type="button"
                @click="useExample(example)"
              >
                {{ example.question }}
              </button>
            </div>
          </div>

          <div
            v-for="message in messages"
            :key="message.id"
            class="message"
            :class="message.role"
          >
            <div class="message-bubble">
              <template v-if="message.role === 'user'">
                {{ message.content }}
              </template>
              <template v-else>
                <div class="answer-heading">
                  <span
                    class="confidence"
                    :class="message.result.confidence"
                  >
                    Retrieval confidence: {{ message.result.confidence }}
                    ({{ Math.round((message.result.confidence_score ?? 0) * 100) }}%)
                  </span>
                  <span>{{ formatAnswerMode(message.result.mode) }}</span>
                </div>
                <div class="retrieval-telemetry">
                  <span>
                    <strong>Search mode</strong>
                    {{ formatTelemetryValue(message.result.retrieval_mode || 'hybrid') }}
                  </span>
                  <span>
                    <strong>Answer source</strong>
                    {{ message.result.semantic_lookup_used ? 'Claude Code CLI' : 'Knowledge base' }}
                  </span>
                  <span v-if="message.result.semantic_lookup_mode">
                    <strong>Semantic lookup</strong>
                    {{ formatSemanticLookup(message.result) }}
                  </span>
                  <span v-if="message.result.semantic_lookup_path">
                    <strong>Markdown scope</strong>
                    {{ message.result.semantic_lookup_path }}
                  </span>
                </div>
                <p class="answer-text">
                  {{ message.result.answer }}
                </p>

                <div
                  v-if="message.result.parsed_query"
                  class="query-entities"
                >
                  <template
                    v-for="(value, key) in message.result.parsed_query"
                    :key="key"
                  >
                    <span v-if="value !== null && value !== ''">
                      {{ formatQueryKey(key) }}: {{ value }}
                    </span>
                  </template>
                </div>

                <div
                  v-if="message.result.exact_hits.length"
                  class="fact-table-wrap"
                >
                  <table class="fact-table">
                    <thead>
                      <tr><th>Register</th><th>Field</th><th>Bits</th><th>Access</th><th>Reset</th><th>Score</th></tr>
                    </thead>
                    <tbody>
                      <tr
                        v-for="hit in message.result.exact_hits"
                        :key="`${hit.register_id}-${hit.field_name}-${hit.bit_range}`"
                      >
                        <td>{{ hit.peripheral }}.{{ hit.register_name }}</td>
                        <td>{{ hit.field_name || '-' }}</td>
                        <td>{{ hit.bit_range || '-' }}</td>
                        <td>{{ hit.bitfield_access || hit.register_access || '-' }}</td>
                        <td>{{ hit.bitfield_reset || hit.register_reset || '-' }}</td>
                        <td>{{ hit.match_score ?? '-' }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div
                  v-if="message.result.evidence.length"
                  class="evidence-list"
                >
                  <details
                    v-for="evidence in message.result.evidence"
                    :key="evidence.id"
                  >
                    <summary>
                      {{ evidence.heading || evidence.title }} | {{ evidence.source_ref }}
                      | relevance {{ evidence.match_score ?? 0 }}
                    </summary>
                    <pre>{{ evidence.chunk_text }}</pre>
                  </details>
                </div>

                <div
                  v-for="warning in message.result.warnings"
                  :key="warning"
                  class="warning-row"
                >
                  <el-icon><Warning /></el-icon>{{ warning }}
                </div>
              </template>
            </div>
          </div>

          <div
            v-if="asking"
            class="message assistant"
          >
            <div class="message-bubble loading-answer">
              <span class="spinner" />Searching the knowledge base...
            </div>
          </div>
        </div>

        <div class="query-area">
          <p v-if="queryError" class="query-error" role="alert">{{ queryError }}</p>
          <div class="query-box">
            <el-input
              v-model="question"
              type="textarea"
              :autosize="{ minRows: 1, maxRows: 5 }"
              placeholder="Ask about a register, bitfield, address, or chip manual"
              @keydown.enter.exact.prevent="submitQuestion"
            />
            <el-button
              type="primary"
              :icon="Promotion"
              circle
              :loading="asking"
              :disabled="!question.trim() || documents.length === 0"
              title="Ask knowledge base"
              @click="submitQuestion"
            />
          </div>
          <div class="query-options">
            <el-input
              v-model="queryChip"
              placeholder="Optional chip filter"
              clearable
            />
            <el-select
              v-model="queryRetrievalMode"
              aria-label="Retrieval mode"
              title="Choose how evidence is retrieved"
            >
              <el-option
                label="Hybrid search"
                value="hybrid"
              />
              <el-option
                label="Keyword search"
                value="keyword"
              />
            </el-select>
            <span>{{ activeDocument ? `Using ${activeDocument.title}` : 'Searching all documents' }}</span>
          </div>
        </div>
      </main>
    </div>
    <el-dialog
      v-model="chunkPreviewVisible"
      title="Chunk preview"
      width="min(760px, calc(100vw - 32px))"
      destroy-on-close
    >
      <div
        v-if="chunkPreview"
        class="chunk-preview"
      >
        <div class="chunk-preview-summary">
          <span><strong>{{ chunkPreview.strategy }}</strong> strategy</span>
          <span>{{ chunkPreview.chunk_count }} chunks</span>
          <span>{{ chunkPreview.source_lines }} source lines</span>
          <span>{{ chunkPreview.table_count }} tables</span>
        </div>
        <div class="chunk-preview-list">
          <details
            v-for="chunk in chunkPreview.chunks"
            :key="chunk.index"
            :open="chunk.index === 1"
          >
            <summary>
              <span>Chunk {{ chunk.index }} · {{ chunk.heading }}</span>
              <span>{{ chunk.char_count }} chars · line {{ chunk.source_line }}</span>
            </summary>
            <pre>{{ chunk.content }}</pre>
          </details>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Collection,
  Delete,
  DocumentChecked,
  DocumentAdd,
  Download,
  Files,
  Link,
  Promotion,
  Reading,
  Refresh,
  RefreshRight,
  Search,
  Warning,
} from '@element-plus/icons-vue'
import {
  askKnowledgeBase,
  buildKnowledgeMkdocs,
  deleteKnowledgeDocument,
  getKnowledgeRepositoryStatus,
  importGithubReference,
  importObsidianVault,
  listKnowledgeDocuments,
  previewKnowledgeChunks,
  searchKnowledgeRegisters,
  syncKnowledgeRepository,
  uploadKnowledgeDocument,
} from '../api/knowledgeBase.js'

const props = defineProps({ agent: { type: Object, required: true } })

const documents = ref([])
const registerExamples = ref([])
const activeDocumentId = ref('')
const selectedFile = ref(null)
const fileInput = ref(null)
const isDragging = ref(false)
const isAutoTitle = ref(false)
const uploading = ref(false)
const loadingDocuments = ref(false)
const asking = ref(false)
const question = ref('')
const queryError = ref('')
const queryChip = ref('')
const queryRetrievalMode = ref('hybrid')
const messages = ref([])
const messagesEl = ref(null)
const repositoryStatus = ref(null)
const repositoryBusy = ref(false)
const importingReference = ref(false)
const importingObsidian = ref(false)
const publishing = ref(false)
const previewingChunks = ref(false)
const chunkPreviewVisible = ref(false)
const chunkPreview = ref(null)
const form = reactive({ chip: 'GENERAL', title: '', revision: '', peripheralHint: '', docType: 'reference', tags: '', llmOcr: true })
const githubForm = reactive({ repository: '', ref: '' })
const obsidianForm = reactive({ path: '', chip: '', revision: '' })
const authStore = useAuthStore()
let disposed = false
let chunkPreviewRequestId = 0

function invalidateWorkspace() {
  disposed = true
  chunkPreviewRequestId += 1
  documents.value = []
  registerExamples.value = []
  messages.value = []
  activeDocumentId.value = ''
  selectedFile.value = null
  question.value = ''
  queryError.value = ''
  queryChip.value = ''
  chunkPreview.value = null
  chunkPreviewVisible.value = false
  repositoryStatus.value = null
  Object.assign(form, { chip: 'GENERAL', title: '', revision: '', peripheralHint: '', docType: 'reference', tags: '', llmOcr: true })
  Object.assign(githubForm, { repository: '', ref: '' })
  Object.assign(obsidianForm, { path: '', chip: '', revision: '' })
}

watch(() => accountIdentity(authStore), invalidateWorkspace, { flush: 'sync' })
onBeforeUnmount(invalidateWorkspace)

const activeDocument = computed(() => documents.value.find(item => item.id === activeDocumentId.value))
const visibleRegisterExamples = computed(() => registerExamples.value
  .filter(example => !activeDocumentId.value || example.documentId === activeDocumentId.value)
  .slice(0, 3))
const selectedFileIsPdf = computed(() => selectedFile.value?.name?.toLowerCase().endsWith('.pdf'))
const previewableSelectedFile = computed(() => {
  const suffix = selectedFile.value?.name?.toLowerCase().split('.').pop()
  return Boolean(selectedFile.value && ['md', 'markdown', 'txt'].includes(suffix))
})

onMounted(refreshWorkspace)

async function refreshWorkspace() {
  if (disposed) return
  await Promise.all([loadDocuments(), loadRepositoryStatus(), loadRegisterExamples()])
}

async function loadDocuments() {
  if (disposed) return
  loadingDocuments.value = true
  try {
    const result = await listKnowledgeDocuments()
    if (disposed) return
    documents.value = result.documents || []
    if (!documents.value.some(item => item.id === activeDocumentId.value)) {
      activeDocumentId.value = ''
    }
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to load knowledge documents')
  } finally {
    loadingDocuments.value = false
  }
}

async function loadRepositoryStatus() {
  if (disposed) return
  try {
    const result = await getKnowledgeRepositoryStatus()
    if (disposed) return
    repositoryStatus.value = result
    if (!obsidianForm.path && result.obsidian_default_path) {
      obsidianForm.path = result.obsidian_default_path
    }
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to load repository status')
  }
}

async function loadRegisterExamples() {
  if (disposed) return
  try {
    const result = await searchKnowledgeRegisters()
    if (disposed) return
    const seen = new Set()
    registerExamples.value = (result.results || []).flatMap(register => {
      const queryParts = [register.register_name]
      if (register.field_name) queryParts.push(register.field_name)
      if (register.field_name && register.bit_range) {
        queryParts.push('bits', register.bit_range)
      }
      const question = queryParts.filter(Boolean).join(' ')
      const id = `${register.document_id}:${question}`
      if (!question || seen.has(id)) return []
      seen.add(id)
      return [{
        id,
        question,
        chip: register.chip || '',
        documentId: register.document_id,
      }]
    })
  } catch (error) {
    if (disposed) return
    ElMessage.warning(error.message || 'Could not load register examples')
  }
}

async function syncRepository() {
  if (disposed || repositoryBusy.value) return
  repositoryBusy.value = true
  try {
    const result = await syncKnowledgeRepository({
      pull: Boolean(repositoryStatus.value?.git?.remote),
      rebuildIndex: true,
    })
    if (disposed) return
    ElMessage.success(`Repository synchronized; ${result.rebuild?.documents ?? 0} documents indexed`)
    await refreshWorkspace()
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Repository synchronization failed')
  } finally {
    repositoryBusy.value = false
  }
}

async function importGithub() {
  if (disposed || importingReference.value) return
  importingReference.value = true
  try {
    const result = await importGithubReference(githubForm)
    if (disposed) return
    ElMessage.success(`Imported ${result.documents_imported} GitHub documents`)
    githubForm.repository = ''
    githubForm.ref = ''
    await refreshWorkspace()
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'GitHub reference import failed')
  } finally {
    importingReference.value = false
  }
}

async function importObsidian() {
  if (disposed || importingObsidian.value) return
  importingObsidian.value = true
  try {
    const result = await importObsidianVault(obsidianForm)
    if (disposed) return
    const indexed = result.rebuild?.documents ?? result.documents_imported
    const publishSuffix = result.publication?.ok ? ' and published MkDocs' : ''
    ElMessage.success(
      'Imported '
        + result.documents_imported
        + ' Obsidian notes; '
        + indexed
        + ' documents indexed'
        + publishSuffix,
    )
    await refreshWorkspace()
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Obsidian vault import failed')
  } finally {
    importingObsidian.value = false
  }
}

async function buildMkdocs() {
  if (disposed || publishing.value) return
  publishing.value = true
  try {
    const result = await buildKnowledgeMkdocs()
    if (disposed) return
    repositoryStatus.value = { ...repositoryStatus.value, publisher: result.status }
    ElMessage.success('MkDocs site built')
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'MkDocs build failed')
  } finally {
    publishing.value = false
  }
}

function openLink(url) {
  if (!url) {
    ElMessage.warning('The interface URL is not configured')
    return
  }
  window.open(url, '_blank', 'noopener,noreferrer')
}

async function handleFileChange(event) {
  const file = event.target.files?.[0]
  event.target.value = ''
  if (!setSelectedFile(file)) return
  await importDocument()
}

async function handleDrop(event) {
  isDragging.value = false
  if (uploading.value) return
  if (!setSelectedFile(event.dataTransfer.files?.[0])) return
  await importDocument()
}

function setSelectedFile(file) {
  if (disposed || uploading.value || !file) return false
  chunkPreviewRequestId += 1
  previewingChunks.value = false
  selectedFile.value = file
  chunkPreview.value = null
  chunkPreviewVisible.value = false
  if (!form.title || isAutoTitle.value) {
    form.title = file.name.replace(/\.[^.]+$/, '')
    isAutoTitle.value = true
  }
  return true
}

async function previewSelectedFile() {
  if (disposed || !previewableSelectedFile.value || previewingChunks.value) return
  const file = selectedFile.value
  const requestId = ++chunkPreviewRequestId
  const isCurrentPreview = () => !disposed && requestId === chunkPreviewRequestId && file === selectedFile.value
  previewingChunks.value = true
  try {
    const text = await file.text()
    if (!isCurrentPreview()) return
    const result = await previewKnowledgeChunks(text)
    if (!isCurrentPreview()) return
    chunkPreview.value = result
    chunkPreviewVisible.value = true
  } catch (error) {
    if (!isCurrentPreview()) return
    ElMessage.error(error.message || 'Chunk preview failed')
  } finally {
    if (isCurrentPreview()) previewingChunks.value = false
  }
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

async function importDocument() {
  if (disposed || !selectedFile.value || uploading.value) return
  const file = selectedFile.value
  const metadata = { ...form }
  uploading.value = true
  try {
    const result = await uploadKnowledgeDocument(file, metadata)
    if (disposed) return
    const pdfSummary = result.conversion
      ? `${result.conversion.pages} pages and ${result.conversion.tables} tables; `
      : ''
    const ocrSummary = result.conversion?.llm_ocr_pages
      ? `${result.conversion.llm_ocr_pages} pages via ${result.conversion.llm_ocr_model}; `
      : ''
    const sourceLines = result.conversion?.source_lines
      ?? result.stats?.source_lines
      ?? result.stats?.lines
      ?? 0
    const losslessVerified = result.conversion?.lossless_verified
      ?? result.stats?.lossless_verified
    const losslessSummary = sourceLines > 0
      ? `; ${sourceLines} source lines preserved${losslessVerified ? ' (source checksum verified)' : ''}`
      : ''
    const conversionSummary = file.name.toLowerCase().endsWith('.pdf')
      ? 'Converted PDF to Markdown; '
      : ''
    const importSummary = `${conversionSummary}Imported ${pdfSummary}${ocrSummary}${result.stats?.chunks ?? 0} search chunks, ${result.stats?.registers ?? 0} registers, and ${result.stats?.bitfields ?? 0} bitfields${losslessSummary}`
    const qualityWarnings = [
      ...(result.conversion?.warnings || []),
      ...(result.stats?.quality?.warnings || []),
    ]
    if (result.publication?.attempted && !result.publication.ok) {
      ElMessage.warning(`${importSummary}; MkDocs publication failed: ${result.publication.error}`)
    } else if (qualityWarnings.length) {
      ElMessage.warning(`${importSummary}; ${[...new Set(qualityWarnings)].join(' ')}`)
    } else {
      const publishSummary = result.publication?.ok ? ' and published MkDocs' : ''
      ElMessage.success(`${importSummary}${publishSummary}`)
    }
    selectedFile.value = null
    form.title = ''
    isAutoTitle.value = false
    await refreshWorkspace()
    if (disposed) return
    activeDocumentId.value = result.document_id
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Knowledge document import failed')
  } finally {
    uploading.value = false
  }
}

async function removeDocument(documentId) {
  if (disposed) return
  try {
    await ElMessageBox.confirm('Delete this knowledge document and its register data?', 'Delete Document', {
      type: 'warning',
      confirmButtonText: 'Delete',
    })
    if (disposed) return
    await deleteKnowledgeDocument(documentId)
    if (disposed) return
    await loadDocuments()
  } catch (error) {
    if (disposed) return
    if (error !== 'cancel' && error !== 'close') {
      ElMessage.error(error.message || 'Failed to delete knowledge document')
    }
  }
}

function useExample(example) {
  activeDocumentId.value = example.documentId
  queryChip.value = example.chip
  question.value = example.question
}

function formatQueryKey(key) {
  return String(key).replaceAll('_', ' ')
}

function formatTelemetryValue(value) {
  const normalized = String(value || 'unknown').replaceAll('_', ' ')
  return normalized.charAt(0).toUpperCase() + normalized.slice(1)
}

function formatAnswerMode(mode) {
  const labels = {
    register_first: 'Register and document retrieval',
    document_evidence: 'Document evidence',
    semantic_cli: 'Claude Code semantic answer',
  }
  return labels[mode] || formatTelemetryValue(mode)
}

function formatSemanticLookup(result) {
  if (result.semantic_lookup_used) return 'Answered by Claude Code CLI'
  if (result.semantic_lookup_mode === 'not_needed') return 'Not needed for this confidence level'
  if (result.semantic_lookup_mode === 'failed') return 'Failed; retrieved answer shown'
  if (result.semantic_lookup_mode === 'skipped') return 'Skipped'
  if (result.semantic_lookup_mode === 'disabled') return 'Disabled'
  return formatTelemetryValue(result.semantic_lookup_mode)
}

async function submitQuestion() {
  const content = question.value.trim()
  if (disposed || !content || asking.value || documents.value.length === 0) return
  const history = messages.value.slice(-12).flatMap(message => {
    const previousContent = message.role === 'user'
      ? message.content
      : message.result?.answer
    return previousContent
      ? [{ role: message.role, content: String(previousContent).slice(0, 2000) }]
      : []
  })
  queryError.value = ''
  messages.value.push({ id: `user-${Date.now()}`, role: 'user', content })
  question.value = ''
  asking.value = true
  await scrollToBottom()
  if (disposed) return
  try {
    const result = await askKnowledgeBase({
      question: content,
      chip: queryChip.value.trim() || null,
      document_id: activeDocumentId.value || null,
      limit: 5,
      retrievalMode: queryRetrievalMode.value,
      history,
    })
    if (disposed) return
    messages.value.push({ id: `assistant-${Date.now()}`, role: 'assistant', result })
  } catch (error) {
    if (disposed) return
    queryError.value = error.message || 'Knowledge base query failed. Please try again.'
    if (!question.value.trim()) question.value = content
  } finally {
    asking.value = false
    await scrollToBottom()
  }
}

async function scrollToBottom() {
  await nextTick()
  if (!disposed && messagesEl.value) messagesEl.value.scrollTop = messagesEl.value.scrollHeight
}
</script>

<style scoped>
.knowledge-workspace { flex: 1; display: flex; flex-direction: column; min-width: 0; overflow: hidden; background: #f6f8fa; }
.query-error { color: #b91c1c; font-size: 12px; margin: 0 0 8px; overflow-wrap: anywhere; }
.knowledge-topbar { height: 44px; padding: 0 16px; display: flex; align-items: center; justify-content: space-between; background: white; border-bottom: 1px solid #e5e7eb; }
.topbar-left { display: flex; align-items: center; gap: 9px; min-width: 0; }
.agent-icon { width: 26px; height: 26px; border-radius: 6px; display: grid; place-items: center; }
.topbar-title { font-size: 13px; font-weight: 650; color: #1f2937; }
.topbar-status { font-size: 11px; color: #9ca3af; border-left: 1px solid #e5e7eb; padding-left: 9px; }
.topbar-status.ready { color: #047857; }
.knowledge-body { flex: 1; min-height: 0; display: flex; }
.document-panel { width: 310px; flex-shrink: 0; padding: 16px; overflow-y: auto; background: white; border-right: 1px solid #e5e7eb; }
.panel-section + .panel-section { margin-top: 20px; }
.section-label { margin-bottom: 9px; font-size: 11px; font-weight: 700; color: #6b7280; text-transform: uppercase; }
.section-heading { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.section-heading .section-label { margin-bottom: 0; }
.repository-meta { margin-top: 7px; display: flex; flex-direction: column; gap: 2px; color: #64748b; font-size: 10px; line-height: 1.4; overflow-wrap: anywhere; }
.repository-actions { margin-top: 9px; display: grid; grid-template-columns: 1fr 1fr; gap: 7px; }
.repository-actions :deep(.el-button) { width: 100%; margin: 0; }
.repository-links { min-height: 28px; display: flex; align-items: center; gap: 2px; }
.repository-links :deep(.el-button) { margin: 0; padding-inline: 6px; }
.github-import, .obsidian-import { display: grid; gap: 6px; }
.obsidian-import { margin-top: 8px; }
.github-row, .obsidian-row { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 6px; }
.metadata-grid { display: grid; gap: 8px; }
.advanced-imports { margin-top: 16px; padding-top: 11px; border-top: 1px solid #e5e7eb; }
.advanced-imports summary { display: flex; align-items: center; justify-content: space-between; gap: 10px; color: #64748b; cursor: pointer; font-size: 11px; font-weight: 650; list-style: none; }
.advanced-imports summary::-webkit-details-marker { display: none; }
.advanced-imports summary::after { content: '+'; color: #0891b2; font-size: 16px; font-weight: 400; }
.advanced-imports[open] summary::after { content: '-'; }
.advanced-content { padding-top: 13px; }
.drop-zone { margin-top: 10px; min-height: 108px; padding: 14px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 5px; color: #94a3b8; border: 1px dashed #cbd5e1; border-radius: 7px; cursor: pointer; background: #f8fafc; transition: border-color .15s ease, background .15s ease, color .15s ease; }
.drop-zone:hover, .drop-zone.dragging { border-color: #0891b2; background: #ecfeff; color: #0891b2; }
.drop-zone.selected { border-style: solid; border-color: #86efac; color: #047857; background: #f0fdf4; }
.drop-zone:focus-visible { outline: 2px solid #0891b2; outline-offset: 2px; }
.drop-zone[aria-disabled="true"] { cursor: progress; opacity: .78; }
.upload-spinner { animation: spin .8s linear infinite; }
.file-name { max-width: 100%; font-size: 12px; font-weight: 600; color: #334155; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-meta { font-size: 10px; }
.ocr-option { min-height: 34px; margin-top: 7px; padding: 0 2px; display: flex; align-items: center; justify-content: space-between; color: #475569; font-size: 11px; font-weight: 650; }
.document-list-section { min-height: 0; }
.document-list { display: flex; flex-direction: column; gap: 5px; }
.document-row { width: 100%; min-width: 0; display: flex; align-items: center; gap: 8px; padding: 8px; text-align: left; border: 1px solid transparent; border-radius: 6px; background: transparent; cursor: pointer; }
.document-row:hover { background: #f8fafc; border-color: #e2e8f0; }
.document-row.active { background: #ecfeff; border-color: #a5f3fc; }
.document-icon { flex-shrink: 0; color: #0891b2; }
.document-copy { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.document-copy strong { font-size: 12px; color: #334155; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.document-copy small { font-size: 10px; color: #94a3b8; line-height: 1.35; }
.document-copy .document-index-ready { color: #047857; }
.document-copy .document-index-pending { color: #a16207; }
.document-copy .document-quality-warning { color: #a16207; overflow-wrap: anywhere; }
.loading-state, .empty-state { padding: 24px 8px; color: #94a3b8; font-size: 12px; text-align: center; }
.answer-panel { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.messages { flex: 1; overflow-y: auto; padding: 22px max(20px, calc((100% - 820px) / 2)); }
.answer-empty { min-height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #64748b; }
.answer-empty-icon { width: 48px; height: 48px; display: grid; place-items: center; border-radius: 8px; color: #0891b2; background: #cffafe; font-size: 22px; }
.answer-empty-title { margin-top: 12px; font-size: 14px; font-weight: 650; color: #334155; }
.example-queries { margin-top: 14px; display: flex; flex-wrap: wrap; justify-content: center; gap: 7px; }
.example-queries button { padding: 6px 9px; border: 1px solid #dbe3ea; border-radius: 6px; color: #64748b; background: white; cursor: pointer; font-size: 11px; }
.message { display: flex; margin-bottom: 16px; }
.message.user { justify-content: flex-end; }
.message-bubble { max-width: 88%; padding: 11px 13px; border-radius: 7px; font-size: 13px; line-height: 1.55; }
.message.user .message-bubble { color: white; background: #0f766e; }
.message.assistant .message-bubble { width: 100%; color: #334155; background: white; border: 1px solid #e2e8f0; }
.answer-heading { display: flex; align-items: center; gap: 8px; font-size: 10px; color: #94a3b8; text-transform: uppercase; }
.confidence { padding: 2px 6px; border-radius: 4px; font-weight: 700; }
.llm-badge { padding: 2px 6px; border: 1px solid #bae6fd; border-radius: 4px; color: #0369a1; background: #f0f9ff; font-weight: 600; text-transform: none; }
.confidence.high { color: #047857; background: #d1fae5; }
.confidence.medium { color: #a16207; background: #fef3c7; }
.confidence.low { color: #b91c1c; background: #fee2e2; }
.retrieval-telemetry { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 5px; }
.retrieval-telemetry span { padding: 4px 7px; display: inline-flex; align-items: center; gap: 4px; border: 1px solid #e2e8f0; border-radius: 5px; color: #475569; background: #f8fafc; font-size: 10px; }
.retrieval-telemetry strong { color: #64748b; font-weight: 650; }
.retrieval-telemetry .llm-mode-synthesis { color: #047857; border-color: #a7f3d0; background: #ecfdf5; }
.retrieval-telemetry .llm-mode-fallback { color: #a16207; border-color: #fde68a; background: #fffbeb; }
.retrieval-telemetry .llm-mode-unavailable { color: #b91c1c; border-color: #fecaca; background: #fef2f2; }
.retrieval-telemetry .llm-mode-disabled { color: #64748b; }
.retrieval-telemetry .llm-mode-semantic_cli { color: #0369a1; border-color: #bae6fd; background: #f0f9ff; }
.retrieval-telemetry .llm-mode-semantic_cli small { max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.answer-text { margin: 9px 0 0; }
.query-entities { margin-top: 8px; display: flex; flex-wrap: wrap; gap: 5px; }
.query-entities span { padding: 2px 6px; border: 1px solid #dbeafe; border-radius: 4px; color: #1d4ed8; background: #eff6ff; font-size: 10px; text-transform: capitalize; }
.fact-table-wrap { margin-top: 11px; overflow-x: auto; }
.fact-table { width: 100%; border-collapse: collapse; font-size: 11px; }
.fact-table th, .fact-table td { padding: 6px 7px; border: 1px solid #e5e7eb; text-align: left; white-space: nowrap; }
.fact-table th { color: #64748b; background: #f8fafc; font-weight: 650; }
.evidence-list { margin-top: 10px; display: grid; gap: 6px; }
.evidence-list details { border: 1px solid #e5e7eb; border-radius: 5px; background: #f8fafc; }
.evidence-list summary { padding: 7px 9px; cursor: pointer; color: #475569; font-size: 11px; }
.evidence-list pre { margin: 0; padding: 9px; max-height: 240px; overflow: auto; white-space: pre-wrap; font: 11px/1.55 Consolas, monospace; border-top: 1px solid #e5e7eb; }
.warning-row { margin-top: 8px; display: flex; align-items: center; gap: 5px; color: #a16207; font-size: 11px; }
.loading-answer { display: flex; align-items: center; gap: 8px; color: #64748b; }
.spinner { width: 13px; height: 13px; border: 2px solid #bae6fd; border-top-color: #0891b2; border-radius: 50%; animation: spin .7s linear infinite; }
.query-area { padding: 12px max(20px, calc((100% - 820px) / 2)) 15px; border-top: 1px solid #e5e7eb; background: white; }
.query-box { display: flex; align-items: flex-end; gap: 8px; }
.query-options { margin-top: 7px; display: flex; align-items: center; gap: 10px; color: #94a3b8; font-size: 10px; }
.query-options :deep(.el-input) { width: 180px; }
.query-options :deep(.el-select) { width: 140px; }
.chunk-preview-summary { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; color: #64748b; font-size: 11px; }
.chunk-preview-summary span { padding: 5px 7px; border: 1px solid #e2e8f0; border-radius: 5px; background: #f8fafc; }
.chunk-preview-summary strong { color: #1d4ed8; }
.chunk-preview-list { display: grid; gap: 7px; max-height: 52vh; overflow-y: auto; }
.chunk-preview-list details { overflow: hidden; border: 1px solid #e2e8f0; border-radius: 6px; background: #fff; }
.chunk-preview-list summary { display: flex; justify-content: space-between; gap: 10px; padding: 8px 10px; cursor: pointer; color: #334155; font-size: 11px; }
.chunk-preview-list summary span:last-child { flex: 0 0 auto; color: #94a3b8; font-size: 10px; }
.chunk-preview-list pre { margin: 0; padding: 10px; overflow: auto; border-top: 1px solid #e2e8f0; background: #f8fafc; color: #334155; font: 11px/1.55 Consolas, monospace; white-space: pre-wrap; }
@keyframes spin { to { transform: rotate(360deg); } }
@media (max-width: 760px) {
  .knowledge-body { flex-direction: column; overflow-y: auto; }
  .document-panel { width: 100%; overflow: visible; border-right: none; border-bottom: 1px solid #e5e7eb; }
  .answer-panel { min-height: 520px; }
  .messages, .query-area { padding-left: 14px; padding-right: 14px; }
  .query-options { align-items: stretch; flex-wrap: wrap; }
  .query-options :deep(.el-input), .query-options :deep(.el-select) { width: 100%; }
  .chunk-preview-list summary { flex-direction: column; gap: 3px; }
}
</style>
