<template>
  <el-dialog
    v-model="visible"
    width="480px"
    :close-on-click-modal="false"
    :show-close="false"
    class="shutdown-dialog"
  >
    <div class="dialog-content">
      <div class="icon-wrapper">
        <el-icon
          size="48"
          class="warning-icon"
        >
          <WarningFilled />
        </el-icon>
      </div>

      <h3 class="dialog-title">
        Shutdown Services
      </h3>

      <div class="dialog-actions">
        <el-button
          size="large"
          @click="handleCancel"
        >
          Cancel
        </el-button>
        <el-button
          type="danger"
          size="large"
          :loading="loading"
          @click="handleConfirm"
        >
          <el-icon><SwitchButton /></el-icon>
          <span>Shutdown Services</span>
        </el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { apiShutdownServices } from '../api/service.js'

const visible = ref(false)
const loading = ref(false)

const emit = defineEmits(['shutdown'])

function open() {
  visible.value = true
}

async function handleConfirm() {
  loading.value = true
  visible.value = false

  // Show shutdown in progress message
  ElMessage({
    type: 'info',
    message: 'Shutting down services...',
    duration: 1500
  })

  // Start the shutdown process immediately after request
  // When backend shuts down, the connection will close, so we can't rely on the response
  const shutdownComplete = false
  setTimeout(() => {
    // Add fade-out animation to entire page
    document.body.style.transition = 'opacity 1s ease-out'
    document.body.style.opacity = '0'
  }, 800)

  // Show shutdown page after fade-out
  // Even if the request fails due to connection close, we still show the page
  setTimeout(() => {
    // Try to close window (will fail for direct navigation due to browser security)
    try {
      window.close()
    } catch (e) {
      // Ignore, show shutdown page
    }

    // Always show shutdown page since window.close() doesn't work for direct navigation
    document.body.innerHTML = `
      <div style="
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        margin: 0;
        padding: 20px;
        box-sizing: border-box;
        background: linear-gradient(135deg, #1a237e 0%, #14202e 100%);
        color: white;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        animation: fadeIn 0.8s ease-in;
      ">
        <style>
          @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95) translateY(15px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
          }
          @keyframes checkmark {
            0% { transform: scale(0) rotate(0deg); opacity: 0; }
            50% { transform: scale(1.2) rotate(180deg); opacity: 1; }
            100% { transform: scale(1) rotate(360deg); opacity: 1; }
          }
          @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
          }
        </style>
        <div style="
          font-size: 80px;
          margin-bottom: 36px;
          animation: checkmark 1s ease-out;
          line-height: 1;
        ">✓</div>
        <h1 style="font-size: 36px; margin: 0 0 16px 0; font-weight: 600;">Services Shutdown Complete</h1>
        <p style="font-size: 16px; color: #9ca3af; margin: 0 0 32px 0; text-align: center; line-height: 1.5;">
          All backend services have been stopped successfully
        </p>
        <div style="
          font-size: 15px;
          padding: 18px 28px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          animation: pulse 2s ease-in-out infinite;
          text-align: center;
        ">
          You can now safely close this browser tab
        </div>
      </div>
    `
    document.body.style.opacity = '1'
  }, 1800)

  // Send the shutdown request in background
  try {
    await apiShutdownServices()
  } catch (error) {
    // Expected: when server shuts down, connection will be closed before response is complete
    // This is not an actual error, just the normal shutdown process
    console.log('Shutdown request complete (connection closed as expected):', error)
  } finally {
    loading.value = false
  }
}

function handleCancel() {
  visible.value = false
}

defineExpose({ open })
</script>

<style scoped>
.shutdown-dialog :deep(.el-dialog) {
  border-radius: 12px;
  overflow: hidden;
}

.shutdown-dialog :deep(.el-dialog__header) {
  display: none;
}

.shutdown-dialog :deep(.el-dialog__body) {
  padding: 0;
}

.dialog-content {
  padding: 32px;
  text-align: center;
}

.icon-wrapper {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
  margin-bottom: 20px;
}

.warning-icon {
  color: #dc2626;
}

.dialog-title {
  font-size: 24px;
  font-weight: 600;
  color: #111827;
  margin: 0 0 12px 0;
}

.dialog-message {
  font-size: 14px;
  line-height: 1.6;
  color: #6b7280;
  margin: 0 0 20px 0;
}

.dialog-message code {
  background: #f3f4f6;
  padding: 2px 8px;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  color: #374151;
  font-size: 13px;
}

.warning-box {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px 16px;
  background: #fffbeb;
  border: 1px solid #fde68a;
  border-radius: 8px;
  margin-bottom: 24px;
  text-align: left;
}

.info-icon {
  color: #f59e0b;
  flex-shrink: 0;
  margin-top: 2px;
}

.warning-box span {
  font-size: 13px;
  color: #92400e;
  line-height: 1.5;
}

.dialog-actions {
  display: flex;
  gap: 12px;
  justify-content: center;
}

.dialog-actions .el-button {
  flex: 1;
  max-width: 180px;
  height: 40px;
  font-size: 14px;
  font-weight: 500;
}

.dialog-actions .el-button--danger {
  background: #dc2626;
  border-color: #dc2626;
}

.dialog-actions .el-button--danger:hover {
  background: #b91c1c;
  border-color: #b91c1c;
}
</style>