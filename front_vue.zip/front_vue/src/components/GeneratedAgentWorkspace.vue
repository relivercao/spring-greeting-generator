<template>
  <div
    class="generated-page"
    :style="{ '--agent-color': agent.color || '#2563eb' }"
  >
    <div class="generated-header">
      <div class="agent-heading">
        <div class="agent-icon">
          <img
            v-if="agent.logo_url"
            :src="agent.logo_url"
            :alt="agent.name + ' logo'"
          >
          <el-icon v-else>
            <component :is="agent.icon || 'MagicStick'" />
          </el-icon>
        </div>
        <div>
          <div class="eyebrow">
            GENERATED AGENT
          </div>
          <h1>{{ agent.name }}</h1>
          <p>{{ agent.description }}</p>
        </div>
      </div>
      <div class="agent-meta">
        <span>{{ agent.llm_provider }} · {{ agent.llm_model }}</span>
        <span>{{ agent.knowledge_document_ids.length }} knowledge references</span>
        <button
          class="delete-agent-button"
          type="button"
          :disabled="isDeleting"
          @click="deleteAgent"
        >
          <span
            v-if="isDeleting"
            class="button-spinner"
          />
          <el-icon v-else>
            <Delete />
          </el-icon>
          {{ isDeleting ? 'Deleting...' : 'Delete Agent' }}
        </button>
      </div>
    </div>

    <div class="generated-grid">
      <section class="chat-card">
        <div class="card-title">
          Agent conversation
        </div>
        <div class="workflow-card">
          <div class="workflow-heading">
            <div>
              <strong>Workflow</strong>
              <small>{{ workflowStatusLabel }}</small>
            </div>
            <span class="workflow-progress">{{ taskProgress }}%</span>
          </div>
          <div class="workflow-flow">
            <template
              v-for="(node, index) in workflowNodes"
              :key="node.id"
            >
              <div
                class="workflow-node"
                :class="node.status"
              >
                <div class="workflow-icon">
                  <span v-if="node.status === 'done'">✓</span>
                  <span v-else-if="node.status === 'fail'">×</span>
                  <span
                    v-else-if="node.status === 'active'"
                    class="workflow-spinner"
                  >…</span>
                  <span v-else>{{ index + 1 }}</span>
                </div>
                <span class="workflow-label">{{ node.label }}</span>
              </div>
              <div
                v-if="index < workflowNodes.length - 1"
                class="workflow-connector"
                :class="{ lit: node.status === 'done' }"
              >
                →
              </div>
            </template>
          </div>
        </div>
        <div
          v-if="taskStatus === 'awaiting_approval' && approvalState.status === 'pending'"
          class="approval-card"
        >
          <div class="approval-card-heading">
            <strong>Human approval required</strong>
            <span>{{ approvalState.node_label || 'Review' }}</span>
          </div>
          <p>Review the generated response before the workflow continues.</p>
          <pre
            v-if="approvalState.draft_response"
            class="approval-draft"
          >{{ approvalState.draft_response }}</pre>
          <textarea
            v-model="approvalComment"
            rows="2"
            placeholder="Optional review comment"
          />
          <div class="approval-actions">
            <button
              type="button"
              class="approval-reject"
              :disabled="isDecidingApproval"
              @click="decideApproval('reject')"
            >
              Reject
            </button>
            <button
              type="button"
              class="approval-approve"
              :disabled="isDecidingApproval"
              @click="decideApproval('approve')"
            >
              Approve and continue
            </button>
          </div>
          <small
            v-if="approvalState.delivery?.warnings?.length"
            class="approval-warning"
          >{{ approvalState.delivery.warnings.join(' ') }}</small>
          <small
            v-else
            class="approval-delivery"
          >Notifications: {{ (approvalState.channels || []).join(', ') || 'workspace only' }}</small>
        </div>
        <div
          v-if="runtimeInputDefinitions.length"
          class="runtime-input-card"
        >
          <div class="runtime-input-card-heading">
            <strong>Run inputs</strong>
            <span>Values apply to this task only.</span>
          </div>
          <div
            v-for="input in runtimeInputDefinitions"
            :key="input.id"
            class="runtime-input-control"
          >
            <label :for="'runtime-' + input.id">{{ input.label }}<span v-if="input.required"> *</span></label>
            <textarea
              v-if="input.type === 'textarea'"
              :id="'runtime-' + input.id"
              v-model="inputValues[input.id]"
              rows="3"
              :placeholder="input.placeholder || ''"
            />
            <input
              v-else-if="input.type === 'text'"
              :id="'runtime-' + input.id"
              v-model="inputValues[input.id]"
              type="text"
              :placeholder="input.placeholder || ''"
              maxlength="20000"
            >
            <input
              v-else-if="input.type === 'number'"
              :id="'runtime-' + input.id"
              v-model.number="inputValues[input.id]"
              type="number"
              :placeholder="input.placeholder || ''"
            >
            <label
              v-else-if="input.type === 'boolean'"
              class="runtime-checkbox"
            ><input
              :id="'runtime-' + input.id"
              v-model="inputValues[input.id]"
              type="checkbox"
            > Enabled</label>
            <select
              v-else-if="input.type === 'select'"
              :id="'runtime-' + input.id"
              v-model="inputValues[input.id]"
            >
              <option value="">
                Select an option
              </option>
              <option
                v-for="option in input.options || []"
                :key="option"
                :value="option"
              >
                {{ option }}
              </option>
            </select>
            <select
              v-else
              :id="'runtime-' + input.id"
              v-model="inputValues[input.id]"
            >
              <option value="">
                Select an attached file
              </option>
              <option
                v-for="file in agent.input_files || []"
                :key="file.id"
                :value="file.id"
              >
                {{ file.name }}
              </option>
            </select>
          </div>
          <p
            v-if="runtimeValidationMessage"
            class="runtime-input-error"
          >
            {{ runtimeValidationMessage }}
          </p>
        </div>
        <div
          ref="messageList"
          class="message-list"
        >
          <div
            v-if="messages.length === 0"
            class="empty-chat"
          >
            Ask this Agent to use its generated workflow and selected knowledge.
          </div>
          <div
            v-for="message in messages"
            :key="message.id"
            class="message-row"
            :class="message.role"
          >
            <div class="message-role">
              {{ message.role === 'user' ? 'You' : agent.name }}
            </div>
            <div
              v-if="message.role === 'assistant' && withoutGeneratedFileLines(message.content)"
              class="message-content"
              v-html="renderChatContent(withoutGeneratedFileLines(message.content))"
            />
            <div
              v-else-if="message.role !== 'assistant'"
              class="message-content"
            >
              {{ message.content }}
            </div>
            <div
              v-if="message.quality?.validation"
              class="quality-status"
            >
              Code review {{ message.quality.reviewed ? 'improvement accepted' : 'draft retained' }}
              · Syntax {{ message.quality.validation }}
              · Repairs {{ message.quality.repair_attempts || 0 }}
            </div>
            <ChatGeneratedFiles v-if="message.role === 'assistant'" :files="message.outputFiles || []" :content="message.content" />
          </div>
          <div
            v-if="isSending"
            class="message-row assistant"
          >
            <div class="message-role">
              {{ agent.name }}
            </div>
            <div class="message-content typing">
              {{ taskMessage }}
            </div>
          </div>
        </div>
        <div class="composer">
          <textarea
            v-model="draft"
            rows="4"
            placeholder="Send a task to this generated Agent..."
            @keydown.ctrl.enter="sendMessage"
          />
          <button
            class="send-button"
            type="button"
            :disabled="!canSend"
            @click="sendMessage"
          >
            <span
              v-if="isSending"
              class="button-spinner"
            />
            <el-icon v-else>
              <Promotion />
            </el-icon>
            {{ isSending ? 'Running...' : 'Run Agent' }}
          </button>
        </div>
        <p
          v-if="taskId"
          class="task-status"
        >
          Task {{ taskId }} · {{ taskElapsed }}
        </p>
        <p
          v-if="errorMessage"
          class="error-message"
        >
          {{ errorMessage }}
        </p>
      </section>

      <aside class="details-card">
        <div class="card-title">
          Agent definition
        </div>
        <div class="detail-label">
          Goal
        </div>
        <div class="detail-value">
          {{ agent.goal || 'No explicit goal provided.' }}
        </div>
        <div class="detail-label">
          Output
        </div>
        <div class="detail-value">
          {{ (agent.output_mode || 'text') === 'text' ? 'Chat response' : ((agent.output_mode || 'text') === 'both' ? 'Chat response and file' : 'Downloadable file') }}<span v-if="(agent.output_mode || 'text') !== 'text'"> · {{ agent.output_format }}<span v-if="agent.output_filename"> · {{ agent.output_filename }}</span></span>
        </div>
        <div class="detail-label">
          Capabilities
        </div>
        <div class="capability-list">
          <span
            v-for="capability in agent.capabilities"
            :key="capability"
            class="capability"
          >{{ capability }}</span>
        </div>
        <div
          v-if="agent.input_definitions?.length"
          class="detail-label"
        >
          Runtime inputs
        </div>
        <div
          v-if="agent.input_definitions?.length"
          class="reference-list"
        >
          <div
            v-for="input in agent.input_definitions"
            :key="input.id"
            class="reference-item"
          >
            <strong>{{ input.label }} <span v-if="input.required">*</span></strong>
            <small>{{ input.id }} · {{ input.type }}<span v-if="input.type === 'select' && input.options?.length"> · {{ input.options.join(', ') }}</span></small>
          </div>
        </div>
        <div class="detail-label">
          Configured flow
        </div>
        <div
          v-if="agent.flow_nodes?.length"
          class="flow-preview"
        >
          <template
            v-for="(node, index) in agent.flow_nodes"
            :key="node.id"
          >
            <div class="flow-preview-node">
              <span>{{ index + 1 }}</span><div><strong>{{ node.label }}</strong><small>{{ node.description }}</small></div>
            </div>
            <div
              v-if="index < agent.flow_nodes.length - 1"
              class="flow-preview-arrow"
            >
              ↓
            </div>
          </template>
        </div>
        <div
          v-else
          class="no-reference"
        >
          Default workflow
        </div>
        <div
          v-if="agent.input_files?.length"
          class="detail-label"
        >
          Input files
        </div>
        <div
          v-if="agent.input_files?.length"
          class="reference-list"
        >
          <div
            v-for="file in agent.input_files"
            :key="file.id"
            class="reference-item"
          >
            <strong>{{ file.name }}</strong><small>{{ formatSize(file.size) }} · {{ file.repository_path }}</small>
          </div>
        </div>
        <div
          v-if="agent.skill_files?.length"
          class="detail-label"
        >
          Skill attachments
        </div>
        <div
          v-if="agent.skill_files?.length"
          class="reference-list"
        >
          <div
            v-for="file in agent.skill_files"
            :key="file.id"
            class="reference-item skill-reference-item"
          >
            <strong>{{ file.name }}</strong><small>{{ formatSize(file.size) }} · {{ file.repository_path }}</small>
          </div>
        </div>
        <div
          v-if="agent.market_skill_names?.length"
          class="detail-label"
        >
          Skill Market imports
        </div>
        <div
          v-if="agent.market_skill_names?.length"
          class="reference-list"
        >
          <div
            v-for="skillName in agent.market_skill_names"
            :key="skillName"
            class="reference-item skill-reference-item"
          >
            <strong>{{ skillName }}</strong><small>Installed Skill Market instruction</small>
          </div>
        </div>
        <div
          v-if="agent.selected_tools?.length"
          class="detail-label"
        >
          External plugin tools
        </div>
        <div
          v-if="agent.selected_tools?.length"
          class="reference-list"
        >
          <div
            v-for="tool in agent.selected_tools"
            :key="tool.name"
            class="reference-item"
          >
            <strong>{{ tool.name }}</strong><small>{{ tool.server || 'mcp' }} · {{ tool.description }}</small>
          </div>
        </div>
        <div
          v-else
          class="no-reference"
        >
          No external plugin tools selected.
        </div>
        <div class="detail-label">
          System prompt
        </div>
        <pre class="system-prompt">{{ agent.system_prompt }}</pre>
        <div class="detail-label">
          Knowledge references
        </div>
        <div
          v-if="agent.knowledge_documents.length"
          class="reference-list"
        >
          <div
            v-for="document in agent.knowledge_documents"
            :key="document.id"
            class="reference-item"
          >
            <strong>{{ document.title }}</strong>
            <small>{{ document.repository_path }}</small>
          </div>
        </div>
        <div
          v-else
          class="no-reference"
        >
          No knowledge documents were selected.
        </div>
        <div class="repository-location">
          {{ agent.repository_path }}
        </div>
      </aside>
    </div>
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { approveGeneratedAgentTask, chatWithGeneratedAgent, deleteGeneratedAgent, getGeneratedAgentTask } from '../api/agentGenerator.js'
import { useWorkspaceStore } from '../stores/workspace.js'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { renderChatContent } from '../utils/chatContent.js'
import { withoutGeneratedFileLines } from '../utils/generatedFiles.js'
import ChatGeneratedFiles from './ChatGeneratedFiles.vue'

const props = defineProps({ agent: { type: Object, required: true } })
const emit = defineEmits(['agent-deleted'])
const workspaceStore = useWorkspaceStore()
const authStore = useAuthStore()
const sessionKey = computed(() => {
  const identity = accountIdentity(authStore)
  return identity ? `generated:${identity}:${props.agent.id}` : ''
})
let storageKey = sessionKey.value
const saved = workspaceStore.getState(storageKey) || {}
const draft = ref('')
const messages = ref(saved.messages || [])
const isSending = ref(Boolean(saved.isSending && saved.taskId))
const errorMessage = ref('')
const taskId = ref(saved.taskId || '')
const taskMessage = ref('')
const taskStartedAt = ref(saved.taskStartedAt || null)
const elapsedNow = ref(Date.now())
const messageList = ref(null)
const isDeleting = ref(false)
const taskProgress = ref(saved.taskProgress || 0)
const workflowNodes = ref(saved.workflowNodes || [])
const taskStatus = ref(saved.taskStatus || '')
const approvalState = ref({})
const approvalComment = ref('')
const isDecidingApproval = ref(false)
const inputValues = ref(saved.inputValues || {})
const agent = computed(() => props.agent)
const runtimeInputDefinitions = computed(() => Array.isArray(agent.value.input_definitions) ? agent.value.input_definitions : [])
const runtimeValidationMessage = computed(() => validateRuntimeInputs())
const canSend = computed(() => draft.value.trim().length > 0 && !isSending.value && !runtimeValidationMessage.value)
const workflowStatusLabel = computed(() => {
  if (taskStatus.value === 'awaiting_approval') return 'Waiting for human approval'
  if (['failed', 'cancelled', 'rejected'].includes(taskStatus.value)) return taskMessage.value || 'Workflow ' + taskStatus.value
  if (isSending.value) return taskMessage.value || 'Running workflow'
  if (taskProgress.value >= 100) return 'Workflow completed'
  return 'Ready to run'
})
const taskElapsed = computed(() => {
  if (!taskStartedAt.value) return 'starting'
  const seconds = Math.max(0, Math.floor((elapsedNow.value - taskStartedAt.value) / 1000))
  if (seconds < 60) return seconds + 's'
  return Math.floor(seconds / 60) + 'm ' + (seconds % 60) + 's'
})
let pollTimer = null
let elapsedTimer = null
let resolvePollWait = null
let disposed = false
let sessionRevision = 0

function isCurrentSession(revision) {
  return !disposed && revision === sessionRevision
}

function stopObservation() {
  if (pollTimer) window.clearTimeout(pollTimer)
  pollTimer = null
  resolvePollWait?.()
  resolvePollWait = null
  if (elapsedTimer) window.clearInterval(elapsedTimer)
  elapsedTimer = null
}

const DEFAULT_WORKFLOW_NODES = [
  { id: 'analyze', label: 'Analyze input', description: 'Understand the request and uploaded context.', kind: 'input' },
  { id: 'execute', label: 'Execute workflow', description: 'Apply the Agent instructions and selected knowledge.', kind: 'task' },
  { id: 'verify', label: 'Verify output', description: 'Check correctness, safety, and acceptance criteria.', kind: 'verify' },
]

function buildWorkflowNodes(nodes) {
  const source = Array.isArray(nodes) && nodes.length ? nodes : DEFAULT_WORKFLOW_NODES
  return source.map(node => ({ ...node, status: node.status || 'pending' }))
}

function resetWorkflow() {
  workflowNodes.value = buildWorkflowNodes(agent.value.flow_nodes)
  taskProgress.value = 0
  taskStatus.value = ''
  approvalState.value = {}
  approvalComment.value = ''
}

function syncRuntimeInputs() {
  const next = {}
  for (const input of runtimeInputDefinitions.value) {
    if (Object.prototype.hasOwnProperty.call(inputValues.value, input.id)) {
      next[input.id] = inputValues.value[input.id]
    } else if (input.default !== null && input.default !== undefined) {
      next[input.id] = input.default
    } else if (input.type === 'boolean') {
      next[input.id] = false
    } else {
      next[input.id] = ''
    }
  }
  inputValues.value = next
}

function validateRuntimeInputs() {
  for (const input of runtimeInputDefinitions.value) {
    const value = inputValues.value[input.id]
    if (input.required && (value === undefined || value === null || (typeof value === 'string' && !value.trim()))) {
      return input.label + ' is required.'
    }
    if (input.type === 'number' && value !== '' && value !== undefined && (!Number.isFinite(Number(value)) || Math.abs(Number(value)) > 1000000000000)) {
      return input.label + ' must be a valid number.'
    }
    if (input.type === 'select' && value && !(input.options || []).includes(value)) {
      return 'Choose a valid option for ' + input.label + '.'
    }
    if (input.type === 'file' && value && !(agent.value.input_files || []).some(file => file.id === value)) {
      return 'Choose an attached file for ' + input.label + '.'
    }
  }
  return ''
}

function syncWorkflowStatus(status) {
  if (Array.isArray(status.workflow_nodes) && status.workflow_nodes.length) {
    workflowNodes.value = buildWorkflowNodes(status.workflow_nodes)
  }
  if (Number.isFinite(Number(status.progress))) {
    taskProgress.value = Math.max(0, Math.min(100, Number(status.progress)))
  }
  taskStatus.value = status.status || taskStatus.value
  if (status.approval) approvalState.value = { ...status.approval }
}

watch(() => JSON.stringify(agent.value.flow_nodes), () => {
  if (!taskId.value && !isSending.value) resetWorkflow()
}, { deep: true, immediate: true })

watch(() => agent.value.input_definitions, () => {
  if (!isSending.value) syncRuntimeInputs()
}, { deep: true, immediate: true })

function persistSession() {
  if (!storageKey) return
  workspaceStore.saveState(storageKey, {
    messages: messages.value.slice(-100), isSending: isSending.value, taskId: taskId.value,
    taskStartedAt: taskStartedAt.value, taskProgress: taskProgress.value,
    workflowNodes: workflowNodes.value, taskStatus: taskStatus.value, inputValues: inputValues.value,
  })
}

watch([messages, isSending, taskId, taskProgress, taskStatus, workflowNodes, inputValues], persistSession, { deep: true })

watch(sessionKey, key => {
  persistSession()
  sessionRevision += 1
  stopObservation()
  storageKey = key
  const next = (key && workspaceStore.getState(key)) || {}
  draft.value = ''
  errorMessage.value = ''
  taskMessage.value = ''
  isDecidingApproval.value = false
  isDeleting.value = false
  resetWorkflow()
  messages.value = [...(next.messages || [])]
  taskId.value = next.taskId || ''
  isSending.value = Boolean(next.isSending && next.taskId)
  taskStartedAt.value = next.taskStartedAt || null
  taskProgress.value = next.taskProgress || 0
  taskStatus.value = next.taskStatus || ''
  workflowNodes.value = buildWorkflowNodes(next.workflowNodes || agent.value.flow_nodes)
  inputValues.value = { ...(next.inputValues || {}) }
  syncRuntimeInputs()
  if (isSending.value) void observeTask(taskId.value)
}, { flush: 'sync' })

onMounted(() => {
  if (isSending.value && taskId.value) void observeTask(taskId.value)
})

function formatSize(size) {
  if (!size) return '0 B'
  if (size < 1024) return size + ' B'
  if (size < 1024 * 1024) return (size / 1024).toFixed(1) + ' KB'
  return (size / (1024 * 1024)).toFixed(1) + ' MB'
}

async function sendMessage() {
  if (!canSend.value) return
  const revision = sessionRevision
  const ownerKey = storageKey
  const content = draft.value.trim()
  const history = messages.value.slice(-50).map(message => ({ role: message.role, content: message.content }))
  draft.value = ''
  errorMessage.value = ''
  resetWorkflow()
  taskId.value = ''
  messages.value.push({ id: Date.now(), role: 'user', content })
  isSending.value = true
  await scrollToBottom()
  if (!isCurrentSession(revision)) return
  try {
    const response = await chatWithGeneratedAgent(agent.value.id, {
      message: content,
      history,
      inputs: Object.fromEntries(Object.entries(inputValues.value).filter(([, value]) => value !== '' && value !== undefined && value !== null)),
    })
    if (!isCurrentSession(revision)) {
      if (ownerKey) workspaceStore.saveState(ownerKey, {
        taskId: response.task_id, taskStartedAt: Date.now(), isSending: true,
      })
      return
    }
    taskId.value = response.task_id
    taskStartedAt.value = Date.now()
    taskMessage.value = 'Task accepted; waiting for the configured LLM/Claude CLI'
    persistSession()
    if (!disposed) await observeTask(response.task_id)
  } catch (error) {
    if (isCurrentSession(revision)) {
      errorMessage.value = error.message || 'Generated Agent execution failed.'
      isSending.value = false
    }
  }
}

async function observeTask(id) {
  const revision = sessionRevision
  elapsedNow.value = Date.now()
  if (elapsedTimer) window.clearInterval(elapsedTimer)
  elapsedTimer = window.setInterval(() => { elapsedNow.value = Date.now() }, 1000)
  try {
    await pollTask(id, revision)
  } catch (error) {
    if (isCurrentSession(revision)) errorMessage.value = error.message || 'Generated Agent execution failed.'
  } finally {
    if (isCurrentSession(revision) && elapsedTimer) {
      window.clearInterval(elapsedTimer)
      elapsedTimer = null
    }
    if (isCurrentSession(revision)) {
      isSending.value = false
      persistSession()
      await scrollToBottom()
    }
  }
}

async function deleteAgent() {
  if (isDeleting.value) return
  const revision = sessionRevision
  try {
    await ElMessageBox.confirm(
      'This permanently removes the Agent manifest, input files, skill attachments, logo, and generated output files.',
      'Delete generated Agent?',
      { confirmButtonText: 'Delete', cancelButtonText: 'Cancel', type: 'warning' },
    )
  } catch {
    return
  }
  if (!isCurrentSession(revision)) return
  isDeleting.value = true
  try {
    await deleteGeneratedAgent(agent.value.id)
    if (!isCurrentSession(revision)) return
    workspaceStore.clearState(storageKey)
    ElMessage.success('Generated Agent deleted.')
    emit('agent-deleted', agent.value.id)
  } catch (error) {
    if (isCurrentSession(revision)) ElMessage.error(error.message || 'Failed to delete generated Agent.')
  } finally {
    if (isCurrentSession(revision)) isDeleting.value = false
  }
}

async function pollTask(id, revision) {
  let consecutiveErrors = 0
  while (isCurrentSession(revision)) {
    let status
    try {
      status = await getGeneratedAgentTask(id)
      if (!isCurrentSession(revision)) return
      consecutiveErrors = 0
    } catch (error) {
      if (!isCurrentSession(revision)) return
      consecutiveErrors += 1
      const httpStatus = Number(error?.status || 0)
      if ([400, 401, 403, 404].includes(httpStatus)) throw error
      taskMessage.value = 'Connection interrupted; retrying (attempt ' + consecutiveErrors + ')'
      await waitForPoll(Math.min(10000, 2000 * (2 ** Math.min(consecutiveErrors, 3))))
      continue
    }
    syncWorkflowStatus(status)
    taskMessage.value = status.message || 'Waiting for the configured LLM/Claude CLI'
    if (status.status === 'completed') {
      messages.value.push({ id: Date.now() + 1, role: 'assistant', content: status.response, outputFiles: status.output_files || [], quality: status.quality || null })
      return
    }
    if (status.status === 'rejected') {
      messages.value.push({ id: Date.now() + 1, role: 'assistant', content: status.message || 'Human approval rejected the task.' })
      return
    }
    if (status.status === 'failed' || status.status === 'cancelled') {
      throw new Error(status.message || 'Generated Agent task failed.')
    }
    await waitForPoll(2000)
  }
}

function waitForPoll(delay) {
  return new Promise(resolve => {
    resolvePollWait = resolve
    pollTimer = window.setTimeout(() => {
      pollTimer = null
      resolvePollWait = null
      resolve()
    }, delay)
  })
}

async function decideApproval(decision) {
  if (isDecidingApproval.value || !taskId.value || !approvalState.value.token) return
  const revision = sessionRevision
  isDecidingApproval.value = true
  try {
    const status = await approveGeneratedAgentTask(taskId.value, decision, approvalState.value.token, approvalComment.value)
    if (!isCurrentSession(revision)) return
    syncWorkflowStatus(status)
    ElMessage.success(decision === 'approve' ? 'Approval submitted.' : 'Rejection submitted.')
  } catch (error) {
    if (isCurrentSession(revision)) ElMessage.error(error.message || 'Failed to submit approval decision.')
  } finally {
    if (isCurrentSession(revision)) isDecidingApproval.value = false
  }
}

async function scrollToBottom() {
  await nextTick()
  if (messageList.value) messageList.value.scrollTop = messageList.value.scrollHeight
}

onBeforeUnmount(() => {
  disposed = true
  persistSession()
  stopObservation()
})
</script>

<style scoped>
.generated-page { flex: 1; overflow: auto; padding: 26px 32px 38px; background: #f8f9fb; }
.generated-header, .generated-grid { max-width: 1180px; margin-left: auto; margin-right: auto; }
.generated-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 20px; margin-bottom: 19px; }
.agent-heading { display: flex; align-items: center; gap: 12px; min-width: 0; }
.agent-icon { width: 42px; height: 42px; display: grid; place-items: center; flex-shrink: 0; border-radius: 11px; color: var(--agent-color); background: color-mix(in srgb, var(--agent-color) 12%, white); font-size: 21px; overflow: hidden; }
.agent-icon img { width: 100%; height: 100%; object-fit: cover; }
.eyebrow { color: var(--agent-color); font-size: 10px; font-weight: 700; letter-spacing: 1.8px; }
h1 { margin: 4px 0; color: #0f172a; font-size: 23px; }
.agent-heading p { margin: 0; color: #64748b; font-size: 12px; }
.agent-meta { display: flex; flex-direction: column; gap: 5px; align-items: flex-end; color: #64748b; font-size: 11px; white-space: nowrap; }
.delete-agent-button { display: inline-flex; align-items: center; justify-content: center; gap: 6px; min-height: 30px; padding: 6px 10px; border: 1px solid #fecaca; border-radius: 7px; color: #b91c1c; background: #fff7f7; cursor: pointer; font: inherit; font-size: 11px; font-weight: 600; }
.delete-agent-button:hover:not(:disabled) { background: #fee2e2; border-color: #fca5a5; }
.delete-agent-button:disabled { opacity: .6; cursor: wait; }
.generated-grid { display: grid; grid-template-columns: minmax(0, 1.15fr) minmax(310px, .85fr); gap: 18px; }
.chat-card, .details-card { min-width: 0; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; padding: 18px; box-shadow: 0 5px 18px rgba(15, 23, 42, .04); }
.card-title { color: #1f2937; font-size: 14px; font-weight: 700; }
.workflow-card { margin-top: 12px; padding: 11px 12px 10px; border: 1px solid #edf1f5; border-radius: 9px; background: #fbfdff; }
.workflow-heading { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.workflow-heading > div { display: flex; align-items: baseline; gap: 8px; min-width: 0; }
.workflow-heading strong { color: #334155; font-size: 11px; }
.workflow-heading small { overflow: hidden; color: #94a3b8; font-size: 10px; text-overflow: ellipsis; white-space: nowrap; }
.workflow-progress { color: #2563eb; font: 600 11px Consolas, monospace; }
.workflow-flow { display: flex; align-items: flex-start; gap: 0; margin-top: 12px; overflow-x: auto; padding: 2px 2px 4px; }
.workflow-node { display: flex; min-width: 76px; flex-direction: column; align-items: center; gap: 6px; flex-shrink: 0; }
.workflow-icon { width: 28px; height: 28px; display: grid; place-items: center; border: 2px solid #dbe3ed; border-radius: 50%; color: #94a3b8; background: #fff; font-size: 11px; font-weight: 700; }
.workflow-label { width: 88px; overflow: hidden; color: #94a3b8; font-size: 9px; line-height: 1.25; text-align: center; text-overflow: ellipsis; white-space: nowrap; }
.workflow-node.active .workflow-icon { border-color: #2563eb; color: #2563eb; background: #eff6ff; box-shadow: 0 0 0 3px rgba(37, 99, 235, .13); }
.workflow-node.active .workflow-label { color: #1d4ed8; font-weight: 600; }
.workflow-node.done .workflow-icon { border-color: #16a34a; color: #fff; background: #16a34a; }
.workflow-node.done .workflow-label { color: #166534; font-weight: 600; }
.workflow-node.fail .workflow-icon { border-color: #ef4444; color: #fff; background: #ef4444; }
.workflow-node.fail .workflow-label { color: #b91c1c; font-weight: 600; }
.workflow-spinner { animation: workflow-pulse 1s ease-in-out infinite; }
.workflow-connector { min-width: 30px; margin-top: 6px; color: #cbd5e1; font-size: 17px; line-height: 28px; text-align: center; }
.workflow-connector.lit { color: #22c55e; }
.approval-card { margin-top: 12px; padding: 12px; border: 1px solid #fcd34d; border-radius: 9px; background: #fffbeb; }
.approval-card-heading { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; color: #92400e; font-size: 11px; }
.approval-card-heading span { color: #b45309; font-size: 10px; }
.approval-card p { margin: 6px 0 8px; color: #78350f; font-size: 11px; line-height: 1.4; }
.approval-draft { max-height: 180px; margin: 0 0 8px; padding: 8px; overflow: auto; border: 1px solid #fde68a; border-radius: 6px; color: #451a03; background: #fff; font: 11px/1.45 Consolas, monospace; white-space: pre-wrap; }
.approval-card textarea { width: 100%; box-sizing: border-box; padding: 7px; border: 1px solid #fcd34d; border-radius: 6px; color: #451a03; background: #fff; font: inherit; font-size: 11px; resize: vertical; }
.approval-actions { display: flex; justify-content: flex-end; gap: 7px; margin-top: 8px; }
.approval-actions button { padding: 7px 10px; border-radius: 6px; cursor: pointer; font: inherit; font-size: 11px; font-weight: 600; }
.approval-reject { border: 1px solid #fecaca; color: #b91c1c; background: #fff; }
.approval-approve { border: 1px solid #16a34a; color: #fff; background: #16a34a; }
.approval-actions button:disabled { opacity: .55; cursor: wait; }
.approval-warning, .approval-delivery { display: block; margin-top: 7px; color: #92400e; font-size: 10px; line-height: 1.4; }
.approval-delivery { color: #a16207; }
.runtime-input-card { margin-top: 12px; padding: 12px; border: 1px solid #dbeafe; border-radius: 9px; background: #f8fbff; }
.runtime-input-card-heading { display: flex; align-items: baseline; justify-content: space-between; gap: 8px; color: #1e3a8a; font-size: 11px; }
.runtime-input-card-heading span { color: #64748b; font-size: 10px; }
.runtime-input-control { margin-top: 9px; }
.runtime-input-control > label:first-child { display: block; margin-bottom: 4px; color: #334155; font-size: 10px; font-weight: 600; }
.runtime-input-control > label:first-child span { color: #dc2626; }
.runtime-input-control input[type='text'], .runtime-input-control input[type='number'], .runtime-input-control textarea, .runtime-input-control select { width: 100%; box-sizing: border-box; padding: 7px 8px; border: 1px solid #cbd5e1; border-radius: 6px; color: #0f172a; background: #fff; font: inherit; font-size: 11px; }
.runtime-input-control textarea { resize: vertical; }
.runtime-checkbox { display: inline-flex; align-items: center; gap: 6px; color: #475569; font-size: 11px; }
.runtime-checkbox input { accent-color: #2563eb; }
.runtime-input-error { margin: 8px 0 0; color: #b91c1c; font-size: 10px; }
.message-list { height: 450px; margin-top: 14px; padding: 5px 3px; overflow: auto; border-top: 1px solid #f1f5f9; border-bottom: 1px solid #f1f5f9; }
.empty-chat { display: grid; height: 100%; place-items: center; padding: 25px; color: #94a3b8; font-size: 12px; line-height: 1.6; text-align: center; }
.message-row { max-width: 88%; margin: 12px 0; }
.message-row.user { margin-left: auto; }
.message-role { margin-bottom: 4px; color: #94a3b8; font-size: 10px; font-weight: 600; }
.message-row.user .message-role { text-align: right; }
.message-content { padding: 10px 12px; border-radius: 9px; color: #334155; background: #f1f5f9; font-size: 12px; line-height: 1.6; white-space: pre-wrap; }
.message-row.user .message-content { color: #fff; background: var(--agent-color); }
.typing { color: #64748b; font-style: italic; }
.composer { display: flex; align-items: flex-end; gap: 10px; margin-top: 13px; }
.composer textarea { flex: 1; min-height: 72px; padding: 10px; border: 1px solid #dbe3ed; border-radius: 8px; resize: vertical; color: #0f172a; font: inherit; font-size: 12px; line-height: 1.5; }
.composer textarea:focus { outline: 2px solid #bfdbfe; border-color: #60a5fa; }
.send-button { height: 38px; padding: 0 13px; display: inline-flex; align-items: center; gap: 6px; flex-shrink: 0; border: 0; border-radius: 7px; color: #fff; background: var(--agent-color); cursor: pointer; font-size: 12px; font-weight: 600; }
.send-button:disabled { opacity: .55; cursor: not-allowed; }
.button-spinner { width: 13px; height: 13px; border: 2px solid rgba(255,255,255,.4); border-top-color: #fff; border-radius: 50%; animation: spin .8s linear infinite; }
.error-message { margin: 9px 0 0; color: #b91c1c; font-size: 12px; }
.task-status { margin: 8px 0 0; color: #64748b; font: 10px Consolas, monospace; }
.quality-status { margin-top: 8px; color: #475569; font-size: 12px; }
.detail-label { margin-top: 18px; margin-bottom: 6px; color: #64748b; font-size: 10px; font-weight: 700; letter-spacing: .6px; text-transform: uppercase; }
.detail-value { color: #334155; font-size: 12px; line-height: 1.55; }
.capability-list { display: flex; flex-wrap: wrap; gap: 6px; }
.capability { padding: 4px 7px; border-radius: 5px; color: #1d4ed8; background: #eff6ff; font-size: 10px; }
.flow-preview { display: flex; flex-direction: column; gap: 4px; }
.flow-preview-node { display: flex; align-items: flex-start; gap: 7px; padding: 6px; border: 1px solid #edf1f5; border-radius: 6px; background: #fbfdff; }
.flow-preview-node > span { width: 17px; height: 17px; display: grid; place-items: center; flex-shrink: 0; border-radius: 50%; color: #1d4ed8; background: #dbeafe; font-size: 9px; font-weight: 700; }
.flow-preview-node div { display: flex; min-width: 0; flex-direction: column; gap: 2px; }
.flow-preview-node strong { color: #334155; font-size: 10px; }
.flow-preview-node small { color: #94a3b8; font-size: 9px; line-height: 1.35; }
.flow-preview-arrow { margin-left: 6px; color: #93c5fd; font-size: 12px; line-height: 10px; }
.system-prompt { max-height: 220px; margin: 0; padding: 10px; overflow: auto; border-radius: 7px; background: #0f172a; color: #dbeafe; font: 10px/1.55 Consolas, monospace; white-space: pre-wrap; }
.reference-list { display: flex; flex-direction: column; gap: 7px; }
.reference-item { display: flex; flex-direction: column; gap: 2px; padding: 8px; border: 1px solid #edf1f5; border-radius: 7px; }
.reference-item strong { overflow: hidden; color: #334155; font-size: 11px; text-overflow: ellipsis; white-space: nowrap; }
.reference-item small { overflow: hidden; color: #94a3b8; font-size: 10px; text-overflow: ellipsis; white-space: nowrap; }
.no-reference { color: #94a3b8; font-size: 11px; }
.repository-location { margin-top: 16px; color: #94a3b8; font: 10px Consolas, monospace; word-break: break-all; }
@keyframes spin { to { transform: rotate(360deg); } }
@keyframes workflow-pulse { 0%, 100% { opacity: .45; } 50% { opacity: 1; } }
@media (max-width: 900px) { .generated-header { flex-direction: column; } .agent-meta { align-items: flex-start; } .generated-grid { grid-template-columns: 1fr; } }
</style>
