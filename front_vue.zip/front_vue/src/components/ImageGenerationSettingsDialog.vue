<template>
  <el-dialog
    v-model="visible"
    width="520px"
    :close-on-click-modal="false"
    class="image-settings-dialog"
    @open="loadSettings"
  >
    <template #header>
      <div class="dialog-heading">
        <div class="heading-icon">
          <el-icon size="19">
            <Setting />
          </el-icon>
        </div>
        <div>
          <div class="heading-title">
            Image Provider
          </div>
          <div class="heading-subtitle">
            OpenAI-compatible image API
          </div>
        </div>
      </div>
    </template>

    <div
      v-loading="loading"
      class="settings-form"
    >
      <div
        v-if="form.usingTuringFallback"
        class="fallback-notice"
      >
        <el-icon><Connection /></el-icon>
        Using the current Turing connection as a fallback
      </div>

      <label class="field-group">
        <span>Provider</span>
        <el-segmented
          v-model="form.provider"
          :options="providerOptions"
        />
      </label>

      <label class="field-group">
        <span>API Base URL</span>
        <el-input
          v-model="form.apiBase"
          :placeholder="form.provider === 'macode' ? 'https://macode.cloud/v1' : 'https://api.example.com/v1'"
        />
      </label>

      <label class="field-group">
        <span>API Key</span>
        <el-input
          v-model="form.apiKey"
          type="password"
          show-password
          autocomplete="new-password"
          placeholder="Enter image API key"
        />
      </label>

      <label class="field-group">
        <span>Model</span>
        <el-input
          v-model="form.model"
          :placeholder="form.provider === 'macode' ? 'gpt-image-2' : 'image-model'"
        />
      </label>

      <div class="field-row">
        <label class="field-group">
          <span>API Mode</span>
          <el-segmented
            v-model="form.mode"
            :options="modeOptions"
          />
        </label>
        <label class="field-group timeout-field">
          <span>Timeout</span>
          <el-input-number
            v-model="form.timeoutSeconds"
            :min="30"
            :max="1800"
            :step="30"
            controls-position="right"
          />
        </label>
        <label class="field-group timeout-field">
          <span>Retries</span>
          <el-input-number
            v-model="form.retryAttempts"
            :min="0"
            :max="5"
            controls-position="right"
          />
        </label>
      </div>

      <div class="advanced-row">
        <label class="field-group">
          <span>Streaming</span>
          <el-switch v-model="form.streamImages" />
        </label>
        <label class="field-group partial-field">
          <span>Partial images</span>
          <el-input-number
            v-model="form.partialImages"
            :min="0"
            :max="3"
            controls-position="right"
          />
        </label>
        <label class="field-group prompt-field">
          <span>Allow prompt rewrite</span>
          <el-switch v-model="form.allowPromptRewrite" />
        </label>
      </div>
    </div>

    <template #footer>
      <div class="dialog-actions">
        <el-button @click="visible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :loading="saving"
          @click="saveSettings"
        >
          Save
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Connection, Setting } from '@element-plus/icons-vue'
import {
  getImageGenerationSettings,
  updateImageGenerationSettings,
} from '../api/imageGeneration.js'

const visible = ref(false)
const loading = ref(false)
const saving = ref(false)
const modeOptions = [
  { label: 'Images', value: 'images' },
  { label: 'Responses', value: 'responses' },
]
const providerOptions = [
  { label: 'Macode', value: 'macode' },
  { label: 'Custom', value: 'custom' },
]
const form = reactive({
  apiBase: '',
  apiKey: '',
  provider: 'macode',
  model: 'gpt-image-2',
  mode: 'images',
  timeoutSeconds: 600,
  retryAttempts: 2,
  streamImages: false,
  partialImages: 1,
  allowPromptRewrite: true,
  usingTuringFallback: false,
})

function open() {
  visible.value = true
}

async function loadSettings() {
  loading.value = true
  try {
    const settings = await getImageGenerationSettings()
    form.provider = settings.provider || 'macode'
    form.apiBase = settings.api_base || ''
    form.apiKey = settings.api_key || ''
    form.model = settings.model || (form.provider === 'macode' ? 'gpt-image-2' : 'image-model')
    form.mode = settings.mode || 'images'
    form.timeoutSeconds = settings.timeout_seconds || 600
    form.retryAttempts = settings.retry_attempts ?? 2
    form.streamImages = Boolean(settings.stream_images)
    form.partialImages = settings.partial_images ?? 1
    form.allowPromptRewrite = settings.allow_prompt_rewrite !== false
    form.usingTuringFallback = Boolean(settings.using_turing_fallback)
  } catch (error) {
    ElMessage.error(error.message || 'Failed to load image provider settings')
  } finally {
    loading.value = false
  }
}

async function saveSettings() {
  if (!form.model.trim()) {
    ElMessage.warning('Model is required')
    return
  }
  saving.value = true
  try {
    await updateImageGenerationSettings({
      provider: form.provider,
      api_base: form.apiBase.trim(),
      api_key: form.apiKey,
      model: form.model.trim(),
      mode: form.mode,
      timeout_seconds: form.timeoutSeconds,
      retry_attempts: form.retryAttempts,
      stream_images: form.streamImages,
      partial_images: form.partialImages,
      allow_prompt_rewrite: form.allowPromptRewrite,
    })
    ElMessage.success('Image provider settings saved')
    visible.value = false
  } catch (error) {
    ElMessage.error(error.message || 'Failed to save image provider settings')
  } finally {
    saving.value = false
  }
}

defineExpose({ open })
</script>

<style scoped>
.dialog-heading {
  display: flex;
  align-items: center;
  gap: 12px;
}

.heading-icon {
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border-radius: 8px;
  color: #2563eb;
  background: #eff6ff;
}

.heading-title {
  color: #111827;
  font-size: 16px;
  font-weight: 700;
}

.heading-subtitle {
  margin-top: 2px;
  color: #6b7280;
  font-size: 12px;
}

.settings-form {
  min-height: 280px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.fallback-notice {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 9px 11px;
  border: 1px solid #bae6fd;
  border-radius: 6px;
  color: #0369a1;
  background: #f0f9ff;
  font-size: 12px;
}

.field-group {
  min-width: 0;
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 7px;
  color: #374151;
  font-size: 12px;
  font-weight: 600;
}

.field-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 160px 120px;
  gap: 14px;
}

.advanced-row {
  display: grid;
  grid-template-columns: 1fr 150px 1fr;
  gap: 14px;
  align-items: end;
}

.partial-field :deep(.el-input-number) {
  width: 100%;
}

.timeout-field :deep(.el-input-number) {
  width: 100%;
}

.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@media (max-width: 600px) {
  .field-row,
  .advanced-row {
    grid-template-columns: 1fr;
  }
}
</style>
