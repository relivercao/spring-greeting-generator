<template>
  <main class="market-page">
    <div class="market-content">
      <header class="market-heading">
        <div>
          <div class="market-eyebrow">SKILLSMP &amp; COMMUNITY</div>
          <h1>Skill Market</h1>
          <p>Find, submit, and publish reusable skills for this deployment.</p>
        </div>
        <div class="market-source">
          <span class="source-indicator" />
          SkillsMP
        </div>
      </header>

      <div class="submission-entry">
        <el-button type="primary" :disabled="!auth.isLoggedIn" @click="submissionsVisible = true"
          >Submit / Import Skill</el-button
        >
        <el-button :disabled="!auth.isLoggedIn" @click="submissionsVisible = true">{{
          auth.isAdmin ? 'Submissions & Review' : 'My Submissions'
        }}</el-button>
        <span>{{
          auth.isLoggedIn
            ? 'Upload locally, review, then publish to this deployment.'
            : 'Sign in to submit a skill.'
        }}</span>
      </div>

      <form class="search-row" @submit.prevent="runSearch(1)">
        <el-input
          v-model="query"
          size="large"
          clearable
          maxlength="120"
          placeholder="Search skills, for example: firmware, testing, documentation"
          aria-label="Search skills"
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
        <el-button type="primary" size="large" :loading="searching" @click="runSearch(1)">
          Search
        </el-button>
      </form>

      <div class="catalog-toolbar">
        <div class="view-switch" role="tablist" aria-label="Skill list">
          <button
            type="button"
            role="tab"
            :aria-selected="viewMode === 'market'"
            :class="{ selected: viewMode === 'market' }"
            @click="viewMode = 'market'"
          >
            Market <span>{{ totalLabel }}</span>
          </button>
          <button
            type="button"
            role="tab"
            :aria-selected="viewMode === 'installed'"
            :class="{ selected: viewMode === 'installed' }"
            @click="viewMode = 'installed'"
          >
            Installed <span>{{ installedSkills.length }}</span>
          </button>
        </div>
        <button
          class="refresh-button"
          type="button"
          :disabled="searching"
          title="Refresh catalog"
          @click="refreshCurrentView"
        >
          <el-icon :class="{ spinning: searching || loadingInstalled }">
            <Refresh />
          </el-icon>
          <span>Refresh</span>
        </button>
      </div>

      <div v-if="errorMessage" class="market-alert" role="alert">
        <el-icon><Warning /></el-icon>
        <span>{{ errorMessage }}</span>
        <button type="button" aria-label="Dismiss error" @click="errorMessage = ''">Dismiss</button>
      </div>

      <section v-if="viewMode === 'market'" class="results-section" aria-live="polite">
        <div v-if="searching && !marketSkills.length" class="empty-state">
          <el-icon class="loading-icon">
            <Loading />
          </el-icon>
          <span>Loading SkillsMP results...</span>
        </div>
        <div v-else-if="!marketSkills.length" class="empty-state">
          <el-icon><CollectionTag /></el-icon>
          <span>No skills found. Try another search.</span>
        </div>
        <article
          v-for="skill in marketSkills"
          :key="skill.id || skill.github_url"
          class="skill-row"
        >
          <div class="skill-main">
            <div class="skill-title-line">
              <h2>{{ skill.name }}</h2>
              <span v-if="skill.content_language" class="language-label">{{
                skill.content_language
              }}</span>
            </div>
            <p class="skill-description">
              {{ skill.description || 'No description provided.' }}
            </p>
            <div class="skill-meta">
              <span>{{ skill.author }}</span>
              <span v-if="skill.stars" class="star-count"
                ><el-icon><Star /></el-icon>{{ formatCount(skill.stars) }}</span
              >
              <span v-if="skill.updated_at">Updated {{ formatDate(skill.updated_at) }}</span>
            </div>
          </div>
          <div class="skill-actions">
            <el-button :disabled="!skill.installable" @click="openPreview(skill)">
              <el-icon><View /></el-icon>
              Preview
            </el-button>
            <el-button v-if="isInstalled(skill)" type="success" plain disabled>
              <el-icon><CircleCheck /></el-icon>
              Installed
            </el-button>
            <el-button
              v-else
              type="primary"
              :disabled="!skill.installable || !auth.isAdmin"
              :loading="installingUrl === skill.github_url"
              @click="installSkill(skill)"
            >
              <el-icon><Download /></el-icon>
              {{ auth.isAdmin ? 'Install' : 'Admin Install' }}
            </el-button>
          </div>
        </article>
        <div v-if="marketSkills.length && (page > 1 || hasMore)" class="pagination-row">
          <el-button :disabled="page <= 1 || searching" @click="runSearch(page - 1)">
            <el-icon><ArrowLeft /></el-icon>
            Previous
          </el-button>
          <span>Page {{ page }}</span>
          <el-button :disabled="!hasMore || searching" @click="runSearch(page + 1)">
            Next
            <el-icon><ArrowRight /></el-icon>
          </el-button>
        </div>
      </section>

      <section v-else class="results-section" aria-live="polite">
        <div v-if="loadingInstalled && !installedSkills.length" class="empty-state">
          <el-icon class="loading-icon">
            <Loading />
          </el-icon>
          <span>Loading installed skills...</span>
        </div>
        <div v-else-if="!installedSkills.length" class="empty-state">
          <el-icon><CollectionTag /></el-icon>
          <span>No market skills installed yet.</span>
        </div>
        <article
          v-for="skill in installedSkills"
          :key="skill.id || skill.github_url"
          class="skill-row"
        >
          <div class="skill-main">
            <div class="skill-title-line">
              <h2>{{ skill.name }}</h2>
              <span class="installed-label"
                ><el-icon><CircleCheck /></el-icon>Installed</span
              >
            </div>
            <p class="skill-description">
              {{ skill.description || 'No description provided.' }}
            </p>
            <div
              class="runtime-integration"
              :class="`integration-${skill.integration?.status || 'unknown'}`"
              role="status"
            >
              <el-icon><component :is="integrationIcon(skill.integration?.status)" /></el-icon>
              <span>{{
                skill.integration?.message || 'Runtime integration status is unavailable.'
              }}</span>
            </div>
            <div class="skill-meta">
              <span>{{ skill.source || 'SkillsMP' }}</span>
              <span v-if="skill.installed_at">Added {{ formatDate(skill.installed_at) }}</span>
            </div>
          </div>
          <div class="skill-actions">
            <el-button @click="openPreview(skill)">
              <el-icon><View /></el-icon>
              Preview
            </el-button>
            <el-button
              v-if="skill.github_url"
              tag="a"
              :href="skill.github_url"
              target="_blank"
              rel="noopener noreferrer"
              title="Open source on GitHub"
            >
              <el-icon><Link /></el-icon>
              Source
            </el-button>
            <el-button v-if="skill.id" tag="a" :href="skillPackageDownloadUrl(skill.id)" download
              >Export ZIP</el-button
            >
          </div>
        </article>
      </section>
    </div>

    <el-dialog
      v-model="previewVisible"
      :title="previewSkill?.name || 'Skill preview'"
      width="min(860px, 94vw)"
      destroy-on-close
    >
      <div v-if="previewLoading" class="preview-loading">
        <el-icon class="loading-icon">
          <Loading />
        </el-icon>
        <span>Loading skill preview...</span>
      </div>
      <pre v-else class="skill-preview">{{ previewContent }}</pre>
      <template #footer>
        <div class="preview-footer">
          <span>Content is displayed as plain text.</span>
          <el-button @click="previewVisible = false"> Close </el-button>
        </div>
      </template>
    </el-dialog>
    <SkillSubmissionPanel v-model="submissionsVisible" @published="loadInstalled" />
  </main>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '../stores/auth.js'
import SkillSubmissionPanel from './SkillSubmissionPanel.vue'
import {
  ArrowLeft,
  ArrowRight,
  CircleCheck,
  CollectionTag,
  Download,
  Link,
  Loading,
  Refresh,
  Search,
  Star,
  View,
  Warning,
  WarningFilled,
} from '@element-plus/icons-vue'
import {
  installMarketSkill,
  listInstalledMarketSkills,
  previewMarketSkill,
  searchMarketSkills,
  installedSkillPackage,
  skillPackageDownloadUrl,
} from '../api/skillMarket.js'

const query = ref('firmware')
const auth = useAuthStore()
const submissionsVisible = ref(false)
const marketSkills = ref([])
const installedSkills = ref([])
const page = ref(1)
const hasMore = ref(false)
const total = ref(null)
const viewMode = ref('market')
const searching = ref(false)
const loadingInstalled = ref(false)
const installingUrl = ref('')
const errorMessage = ref('')
const previewVisible = ref(false)
const previewLoading = ref(false)
const previewContent = ref('')
const previewSkill = ref(null)

const totalLabel = computed(() =>
  total.value === null ? marketSkills.value.length : formatCount(total.value)
)

function formatCount(value) {
  const count = Number(value)
  return Number.isFinite(count)
    ? new Intl.NumberFormat('en', {
        notation: count >= 10000 ? 'compact' : 'standard',
        maximumFractionDigits: 1,
      }).format(count)
    : '0'
}

function formatDate(value) {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString()
}

function isInstalled(skill) {
  return installedSkills.value.some(item => item.github_url === skill.github_url)
}

function integrationIcon(status) {
  return status === 'mapped'
    ? CircleCheck
    : status === 'blocked' || status === 'not_registered'
      ? WarningFilled
      : Warning
}

async function runSearch(targetPage = 1) {
  if (query.value.trim().length < 2) {
    errorMessage.value = 'Enter at least two characters to search.'
    return
  }
  searching.value = true
  errorMessage.value = ''
  try {
    const result = await searchMarketSkills(query.value.trim(), targetPage)
    marketSkills.value = Array.isArray(result.items) ? result.items : []
    page.value = result.page || targetPage
    hasMore.value = Boolean(result.has_more)
    total.value = Number.isFinite(result.total) ? result.total : null
  } catch (error) {
    errorMessage.value = error.message || 'Could not load the skill market.'
  } finally {
    searching.value = false
  }
}

async function loadInstalled() {
  loadingInstalled.value = true
  try {
    const result = await listInstalledMarketSkills()
    installedSkills.value = Array.isArray(result.items) ? result.items : []
  } catch (error) {
    errorMessage.value = error.message || 'Could not load installed skills.'
  } finally {
    loadingInstalled.value = false
  }
}

async function refreshCurrentView() {
  if (viewMode.value === 'market') await runSearch(page.value)
  else await loadInstalled()
}

async function openPreview(skill) {
  previewSkill.value = skill
  previewVisible.value = true
  previewLoading.value = true
  previewContent.value = ''
  errorMessage.value = ''
  try {
    if (skill.id && !skill.installable) {
      const preview = await installedSkillPackage(skill.id)
      previewContent.value = Object.entries(preview.files)
        .map(([path, text]) => `# ${path}\n\n${text}`)
        .join('\n\n')
    } else {
      const preview = await previewMarketSkill(skill.github_url)
      previewContent.value = preview.content || ''
    }
  } catch (error) {
    previewContent.value = error.message || 'Could not load this skill preview.'
  } finally {
    previewLoading.value = false
  }
}

async function installSkill(skill) {
  if (!skill.installable || !skill.github_url || !auth.isAdmin) return
  installingUrl.value = skill.github_url
  errorMessage.value = ''
  try {
    const result = await installMarketSkill(skill.github_url)
    await loadInstalled()
    if (result.integration?.status === 'mapped') {
      ElMessage.success(result.integration.message)
    } else {
      ElMessage.warning(
        result.integration?.message ||
          `Installed ${result.name}, but runtime integration could not be confirmed.`
      )
    }
  } catch (error) {
    errorMessage.value = error.message || 'Could not install this skill.'
  } finally {
    installingUrl.value = ''
  }
}

onMounted(() => {
  void Promise.all([runSearch(), loadInstalled()])
})
</script>

<style scoped>
.market-page {
  flex: 1;
  min-width: 0;
  overflow: auto;
  background: #f7f8fa;
  color: #1f2937;
}

.market-content {
  width: min(1120px, 100%);
  margin: 0 auto;
  padding: 32px 36px 48px;
}
.submission-entry {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 22px;
}
.submission-entry span {
  color: #64748b;
  font-size: 12px;
}
.submission-entry .el-button {
  margin: 0;
}

.market-heading,
.catalog-toolbar,
.skill-row,
.skill-title-line,
.skill-meta,
.skill-actions,
.preview-footer {
  display: flex;
  align-items: center;
}

.market-heading,
.catalog-toolbar,
.skill-row {
  justify-content: space-between;
}

.market-eyebrow {
  color: #087f8c;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0;
}

.market-heading h1 {
  margin: 7px 0 4px;
  color: #18212f;
  font-size: 26px;
  line-height: 1.25;
}

.market-heading p {
  margin: 0;
  color: #667085;
  font-size: 14px;
}

.market-source {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  border: 1px solid #d8e5e6;
  border-radius: 6px;
  background: #fff;
  padding: 8px 11px;
  color: #354454;
  font-size: 12px;
  font-weight: 600;
}

.source-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #169b75;
}

.search-row {
  display: flex;
  gap: 10px;
  margin-top: 26px;
}

.search-row :deep(.el-input) {
  flex: 1;
  min-width: 0;
}

.catalog-toolbar {
  margin-top: 24px;
  border-bottom: 1px solid #e2e6ea;
}

.view-switch {
  display: flex;
  gap: 18px;
}

.view-switch button {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 40px;
  border: 0;
  border-bottom: 2px solid transparent;
  background: transparent;
  color: #65717d;
  font-size: 13px;
  cursor: pointer;
}

.view-switch button.selected {
  border-bottom-color: #078b86;
  color: #087b78;
  font-weight: 600;
}

.view-switch button span {
  min-width: 20px;
  border-radius: 10px;
  background: #edf1f4;
  padding: 2px 6px;
  color: #5f6b76;
  font-size: 10px;
  text-align: center;
}

.refresh-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 7px;
  border: 0;
  background: transparent;
  color: #667085;
  font-size: 12px;
  cursor: pointer;
}

.refresh-button:disabled {
  cursor: wait;
  opacity: 0.6;
}

.results-section {
  min-height: 280px;
}

.skill-row {
  gap: 20px;
  border-bottom: 1px solid #e7eaee;
  padding: 19px 2px;
}

.skill-main {
  min-width: 0;
  flex: 1;
}

.skill-title-line {
  flex-wrap: wrap;
  gap: 9px;
}

.skill-title-line h2 {
  margin: 0;
  color: #202b38;
  font-size: 15px;
  font-weight: 650;
  line-height: 1.45;
  overflow-wrap: anywhere;
}

.language-label,
.installed-label {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  border-radius: 4px;
  background: #e9f3f2;
  padding: 3px 6px;
  color: #27766e;
  font-size: 10px;
}

.installed-label {
  background: #e8f5ee;
  color: #267349;
}

.skill-description {
  display: -webkit-box;
  overflow: hidden;
  margin: 6px 0 8px;
  color: #65717d;
  font-size: 13px;
  line-height: 1.55;
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.runtime-integration {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: -2px 0 8px;
  font-size: 12px;
  line-height: 1.45;
  overflow-wrap: anywhere;
}

.runtime-integration :deep(.el-icon) {
  flex: 0 0 auto;
  margin-top: 1px;
}

.integration-mapped {
  color: #16805d;
}
.integration-not_mapped,
.integration-unknown {
  color: #926200;
}
.integration-blocked,
.integration-not_registered {
  color: #b54735;
}

.skill-meta {
  flex-wrap: wrap;
  gap: 14px;
  color: #8a949e;
  font-size: 11px;
}

.star-count {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: #9a6c19;
}

.skill-actions {
  flex-shrink: 0;
  gap: 8px;
}

.skill-actions :deep(.el-button) {
  margin-left: 0;
}

.pagination-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 14px;
  padding-top: 20px;
  color: #667085;
  font-size: 12px;
}

.empty-state,
.preview-loading {
  display: flex;
  min-height: 250px;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #77828d;
  font-size: 13px;
}

.loading-icon,
.spinning {
  animation: spin 1s linear infinite;
}

.market-alert {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
  border: 1px solid #efc6bd;
  border-radius: 6px;
  background: #fff8f6;
  padding: 10px 12px;
  color: #9a3e2d;
  font-size: 12px;
}

.market-alert span {
  flex: 1;
  overflow-wrap: anywhere;
}

.market-alert button {
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}

.skill-preview {
  max-height: min(65vh, 700px);
  overflow: auto;
  margin: 0;
  border: 1px solid #e3e7eb;
  border-radius: 4px;
  background: #fafbfc;
  padding: 16px;
  color: #263442;
  font:
    12px/1.6 Consolas,
    'Courier New',
    monospace;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.preview-footer {
  justify-content: space-between;
  gap: 12px;
  color: #7a8590;
  font-size: 11px;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@media (max-width: 720px) {
  .market-content {
    padding: 22px 16px 36px;
  }

  .market-heading {
    align-items: flex-start;
    gap: 12px;
  }

  .market-heading h1 {
    font-size: 22px;
  }

  .market-source {
    flex-shrink: 0;
    padding: 7px 8px;
  }

  .search-row {
    gap: 7px;
  }

  .skill-row {
    align-items: flex-start;
    flex-direction: column;
    gap: 12px;
  }

  .skill-actions {
    width: 100%;
  }

  .skill-actions :deep(.el-button) {
    flex: 1;
  }
}
</style>
