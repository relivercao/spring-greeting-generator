<template>
  <div
    v-if="visible"
    class="modal-overlay"
    @click.self="handleCancel"
  >
    <div class="modal-container">
      <div class="modal-header">
        <h3>AWS SSO Login Required</h3>
        <button
          class="close-btn"
          @click="handleCancel"
        >
          &times;
        </button>
      </div>

      <div class="modal-body">
        <div
          v-if="loginStatus === 'idle'"
          class="status-section"
        >
          <div class="icon-warning">
            ⚠️
          </div>
          <p class="message">
            Your AWS credentials have expired or are missing.
          </p>
          <p class="sub-message">
            Click the button below to open AWS SSO login in your browser.
          </p>
        </div>

        <div
          v-else-if="loginStatus === 'loading'"
          class="status-section"
        >
          <div class="spinner" />
          <p class="message">
            Opening AWS SSO login page...
          </p>
          <p class="sub-message">
            Please complete the login in your browser window.
          </p>
        </div>

        <div
          v-else-if="loginStatus === 'waiting'"
          class="status-section"
        >
          <div class="icon-info">
            🔐
          </div>
          <p class="message">
            Browser window opened
          </p>
          <p class="sub-message">
            Please complete the AWS SSO login in your browser, then click "Check Status" below.
          </p>
        </div>

        <div
          v-else-if="loginStatus === 'checking'"
          class="status-section"
        >
          <div class="spinner" />
          <p class="message">
            Checking login status...
          </p>
        </div>

        <div
          v-else-if="loginStatus === 'success'"
          class="status-section"
        >
          <div class="icon-success">
            ✓
          </div>
          <p class="message">
            Login successful!
          </p>
          <p class="sub-message">
            Your AWS credentials have been updated.
          </p>
        </div>

        <div
          v-else-if="loginStatus === 'error'"
          class="status-section"
        >
          <div class="icon-error">
            ✗
          </div>
          <p class="message error-text">
            Login failed
          </p>
          <p class="sub-message error-text">
            {{ errorMessage }}
          </p>
        </div>
      </div>

      <div class="modal-footer">
        <button
          v-if="loginStatus === 'idle'"
          class="btn btn-primary"
          @click="triggerLogin"
        >
          Open AWS SSO Login
        </button>

        <button
          v-if="loginStatus === 'waiting'"
          class="btn btn-primary"
          @click="checkStatus"
        >
          Check Status
        </button>

        <button
          v-if="loginStatus === 'success'"
          class="btn btn-primary"
          @click="handleSuccess"
        >
          Continue
        </button>

        <button
          v-if="loginStatus === 'error'"
          class="btn btn-secondary"
          @click="resetAndRetry"
        >
          Retry
        </button>

        <button
          v-if="loginStatus !== 'loading' && loginStatus !== 'checking'"
          class="btn btn-secondary"
          @click="handleCancel"
        >
          Cancel
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { http } from '../api/http.js'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['close', 'success'])

const loginStatus = ref('idle') // idle | loading | waiting | checking | success | error
const errorMessage = ref('')

// Trigger AWS SSO login (opens browser)
const triggerLogin = async () => {
  loginStatus.value = 'loading'
  errorMessage.value = ''

  try {
    const response = await http.post('/v1/bedrock/sso-login', {})

    if (response.status === 'success') {
      loginStatus.value = 'waiting'
    } else {
      loginStatus.value = 'error'
      errorMessage.value = response.message || 'Failed to trigger AWS SSO login'
    }
  } catch (error) {
    loginStatus.value = 'error'
    errorMessage.value = error.message || 'Failed to trigger AWS SSO login'
  }
}

// Check if login is complete
const checkStatus = async () => {
  loginStatus.value = 'checking'
  errorMessage.value = ''

  try {
    // Use fast check (verify_credentials=false) - only check SSO token expiration
    // This is much faster (~0.1s) than full verification (~1-2s)
    const response = await http.get('/v1/bedrock/sso-status?verify_credentials=false')

    if (response.valid) {
      loginStatus.value = 'success'
      setTimeout(() => {
        handleSuccess()
      }, 1500)
    } else {
      loginStatus.value = 'error'
      errorMessage.value = 'AWS credentials are still invalid. Please complete the login in your browser.'
    }
  } catch (error) {
    loginStatus.value = 'error'
    errorMessage.value = error.message || 'Failed to check login status'
  }
}

// Reset and retry
const resetAndRetry = () => {
  loginStatus.value = 'idle'
  errorMessage.value = ''
}

// Handle success
const handleSuccess = () => {
  emit('success')
  emit('close')
  resetState()
}

// Handle cancel
const handleCancel = () => {
  emit('close')
  resetState()
}

// Reset state
const resetState = () => {
  loginStatus.value = 'idle'
  errorMessage.value = ''
}

// Watch visibility to reset state and auto-trigger login when modal opens
watch(() => props.visible, async (newVal) => {
  if (newVal) {
    resetState()
    // Auto-trigger login when modal opens (don't wait for user to click button)
    await triggerLogin()
    // Auto-close modal after triggering login (browser window will open)
    setTimeout(() => {
      emit('close')
    }, 1500)
  }
})
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.modal-container {
  background: #1e1e1e;
  border-radius: 8px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
  color: #e0e0e0;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #333;
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #fff;
}

.close-btn {
  background: none;
  border: none;
  font-size: 28px;
  color: #888;
  cursor: pointer;
  padding: 0;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.2s;
}

.close-btn:hover {
  color: #fff;
}

.modal-body {
  padding: 32px 24px;
  min-height: 180px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.status-section {
  text-align: center;
  width: 100%;
}

.icon-warning,
.icon-info,
.icon-success,
.icon-error {
  font-size: 48px;
  margin-bottom: 16px;
}

.icon-success {
  color: #4caf50;
}

.icon-error {
  color: #f44336;
}

.spinner {
  width: 48px;
  height: 48px;
  border: 4px solid #333;
  border-top-color: #ff6b35;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 16px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.message {
  font-size: 16px;
  font-weight: 500;
  margin: 0 0 8px 0;
  color: #fff;
}

.sub-message {
  font-size: 14px;
  color: #aaa;
  margin: 0;
  line-height: 1.5;
}

.error-text {
  color: #f44336;
}

.modal-footer {
  padding: 16px 24px;
  border-top: 1px solid #333;
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.btn {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-primary {
  background: #ff6b35;
  color: #fff;
}

.btn-primary:hover {
  background: #ff8555;
}

.btn-secondary {
  background: #333;
  color: #e0e0e0;
}

.btn-secondary:hover {
  background: #444;
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
