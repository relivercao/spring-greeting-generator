<template>
  <img
    v-if="image"
    class="agent-mascot"
    :class="`agent-mascot--${size}`"
    :src="image"
    :alt="`${agent?.name || 'Agent'} mascot`"
    :title="`${agent?.name || 'Agent'} mascot`"
    :style="{ '--mascot-accent': agent?.color || '#2563eb' }"
  >
  <span
    v-else
    class="agent-mascot-fallback"
    :class="`agent-mascot-fallback--${size}`"
    :style="{ '--mascot-accent': agent?.color || '#2563eb' }"
  ><slot /></span>
</template>

<script setup>
import { computed } from 'vue'
import { agentMascotFor } from '../config/agentMascots.js'

const props = defineProps({
  agent: { type: Object, default: () => ({}) },
  size: { type: String, default: 'sidebar' },
})

const image = computed(() => agentMascotFor(props.agent, props.size === 'feature' ? 'scene' : 'portrait'))
</script>

<style scoped>
.agent-mascot {
  display: block;
  flex: 0 0 auto;
  aspect-ratio: 1;
  object-fit: cover;
  border: 2px solid color-mix(in srgb, var(--mascot-accent) 48%, white);
  border-radius: 50%;
  background: white;
}

.agent-mascot--card { width: 40px; height: 40px; }
.agent-mascot--feature {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  aspect-ratio: auto;
  border: 0;
  border-radius: 0;
  object-position: center;
}
.agent-mascot--sidebar { width: 38px; height: 38px; }
.agent-mascot--header { width: 34px; height: 34px; }
.agent-mascot--chat { width: 30px; height: 30px; }
.agent-mascot--hero { width: 40px; height: 40px; }
.agent-mascot--hero-art {
  position: relative;
  z-index: 1;
  width: min(270px, 76%);
  height: auto;
  border: 8px solid #ffffff;
  border-radius: 28px;
  box-shadow: 0 14px 26px rgba(30, 64, 90, 0.2);
  object-position: center 34%;
}

.agent-mascot-fallback {
  display: inline-flex;
  flex: 0 0 auto;
  align-items: center;
  justify-content: center;
  color: var(--mascot-accent);
}

.agent-mascot-fallback--card { width: 40px; height: 40px; }
.agent-mascot-fallback--feature { width: 100%; height: 100%; }
.agent-mascot-fallback--sidebar { width: 38px; height: 38px; }
.agent-mascot-fallback--header { width: 34px; height: 34px; }
.agent-mascot-fallback--chat { width: 30px; height: 30px; }
.agent-mascot-fallback--hero { width: 40px; height: 40px; }
.agent-mascot-fallback--hero-art { width: 270px; height: 270px; }
</style>
