<template>
  <article
    class="task-card"
    :class="[`status-${task.status}`, { selected }]"
  >
    <div class="card-main">
      <div
        v-if="task.status === 'running'"
        class="running-state"
      >
        <div class="progress-orbit">
          <el-progress
            type="circle"
            :percentage="task.progress || 0"
            :width="74"
            :stroke-width="5"
            color="#2563eb"
          />
        </div>
        <div class="running-copy">
          <strong>{{ task.message || 'Generating images' }}</strong>
          <span>{{ task.input?.params?.image_count || 1 }} output{{ (task.input?.params?.image_count || 1) > 1 ? 's' : '' }}</span>
        </div>
      </div>

      <div
        v-else-if="task.status === 'completed' && task.result?.images?.length"
        class="image-grid"
        :class="`count-${Math.min(task.result.images.length, 4)}`"
      >
        <button
          v-for="(image, index) in task.result.images.slice(0, 4)"
          :key="image.filename"
          class="image-tile"
          type="button"
          @click="$emit('preview', { task, image, index })"
        >
          <img
            :src="image.url"
            :alt="`${task.input?.prompt || 'Generated image'} ${index + 1}`"
          >
          <span class="image-resolution">{{ image.width }} x {{ image.height }}</span>
          <a
            class="image-download"
            :href="image.download_url"
            :download="image.filename"
            title="Download image"
            @click.stop
          >
            <el-icon><Download /></el-icon>
          </a>
          <span
            v-if="index === 3 && task.result.images.length > 4"
            class="image-more"
          >
            +{{ task.result.images.length - 4 }}
          </span>
        </button>
      </div>

      <div
        v-else
        class="error-state"
      >
        <el-icon size="26">
          <Warning />
        </el-icon>
        <strong>{{ task.status === 'cancelled' ? 'Generation cancelled' : 'Generation failed' }}</strong>
        <span>{{ task.error || task.message || 'No image was returned' }}</span>
      </div>
    </div>

    <div class="card-details">
      <div class="card-heading">
        <span
          class="status-chip"
          :class="task.status"
        >
          <i />{{ statusLabel }}
        </span>
        <time>{{ formattedTime }}</time>
      </div>
      <p class="task-prompt">
        {{ task.input?.prompt || task.result?.prompt || 'Image generation' }}
      </p>
      <section
        v-if="workflowNodes.length"
        class="workflow-inspector"
        aria-label="Image generation workflow"
      >
        <div class="workflow-rail">
          <template
            v-for="(node, index) in workflowNodes"
            :key="node.id"
          >
            <button
              class="workflow-node"
              :class="[node.status, { active: selectedWorkflowNode?.id === node.id }]"
              type="button"
              :aria-label="`${node.label}: ${node.status}`"
              :aria-pressed="selectedWorkflowNode?.id === node.id"
              @click="selectedWorkflowNodeId = node.id"
            >
              <span class="workflow-node-mark">
                <el-icon v-if="node.status === 'completed'"><CircleCheck /></el-icon>
                <el-icon v-else-if="node.status === 'in_progress'"><Loading /></el-icon>
                <el-icon v-else-if="node.status === 'failed'"><Warning /></el-icon>
                <span v-else>{{ index + 1 }}</span>
              </span>
              <span class="workflow-node-label">{{ node.label }}</span>
            </button>
            <span
              v-if="index < workflowNodes.length - 1"
              class="workflow-connector"
              :class="{ completed: node.status === 'completed' }"
              aria-hidden="true"
            />
          </template>
        </div>
        <div
          v-if="selectedWorkflowNode"
          class="workflow-node-detail"
        >
          <div>
            <strong>{{ selectedWorkflowNode.label }}</strong>
            <span :class="`node-status-${selectedWorkflowNode.status}`">{{ selectedWorkflowNode.status.replace('_', ' ') }}</span>
          </div>
          <section v-if="selectedWorkflowNode.input">
            <strong>Input</strong>
            <pre>{{ selectedWorkflowNode.input }}</pre>
          </section>
          <section v-if="selectedWorkflowNode.output">
            <strong>Output</strong>
            <pre>{{ selectedWorkflowNode.output }}</pre>
          </section>
        </div>
      </section>
      <div class="metadata-row">
        <span>{{ task.result?.model || 'Image model' }}</span>
        <span>{{ task.input?.params?.size || 'auto' }}</span>
        <span>{{ task.input?.params?.quality || 'auto' }}</span>
        <span>{{ (task.input?.params?.output_format || 'png').toUpperCase() }}</span>
        <span v-if="task.input?.reference_images?.length">
          {{ task.input.reference_images.length }} reference{{ task.input.reference_images.length > 1 ? 's' : '' }}
        </span>
        <span v-if="task.input?.has_mask">Mask</span>
      </div>
      <div class="card-actions">
        <el-tooltip
          content="Use prompt and parameters"
          placement="top"
        >
          <button
            class="action-button"
            type="button"
            @click="$emit('reuse', task)"
          >
            <el-icon><RefreshRight /></el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          v-if="task.result?.images?.length"
          content="Edit first output"
          placement="top"
        >
          <button
            class="action-button"
            type="button"
            @click="$emit('edit-output', task)"
          >
            <el-icon><EditPen /></el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          v-if="task.result?.download_all_url"
          content="Download all images"
          placement="top"
        >
          <a
            class="action-button"
            :href="task.result.download_all_url"
            download
            @click.stop
          >
            <el-icon><Download /></el-icon>
          </a>
        </el-tooltip>
        <el-tooltip
          v-if="task.status === 'running'"
          content="Cancel task"
          placement="top"
        >
          <button
            class="action-button danger"
            type="button"
            @click="$emit('cancel', task)"
          >
            <el-icon><Close /></el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          v-else
          content="Delete task"
          placement="top"
        >
          <button
            class="action-button danger"
            type="button"
            @click="$emit('delete', task)"
          >
            <el-icon><Delete /></el-icon>
          </button>
        </el-tooltip>
      </div>
    </div>
  </article>
</template>

<script setup>
import { computed } from 'vue'
import { ref, watch } from 'vue'
import {
  CircleCheck,
  Close,
  Delete,
  Download,
  EditPen,
  RefreshRight,
  Loading,
  Warning,
} from '@element-plus/icons-vue'

const props = defineProps({
  task: { type: Object, required: true },
  selected: Boolean,
})

defineEmits(['preview', 'reuse', 'edit-output', 'cancel', 'delete'])

const selectedWorkflowNodeId = ref('')
const workflowNodes = computed(() => (
  Array.isArray(props.task.result?.workflow_nodes) ? props.task.result.workflow_nodes : []
))
const selectedWorkflowNode = computed(() => (
  workflowNodes.value.find((node) => node.id === selectedWorkflowNodeId.value) || null
))

watch(() => props.task.id, () => {
  selectedWorkflowNodeId.value = ''
})

const statusLabel = computed(() => ({
  running: 'Running',
  completed: 'Completed',
  failed: 'Failed',
  cancelled: 'Cancelled',
}[props.task.status] || props.task.status))

const formattedTime = computed(() => {
  if (!props.task.created_at) return ''
  return new Date(props.task.created_at).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
})
</script>

<style scoped>
.task-card {
  min-height: 290px;
  display: grid;
  grid-template-columns: minmax(210px, 46%) minmax(0, 1fr);
  overflow: hidden;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  background: #ffffff;
  transition: border-color 0.16s, box-shadow 0.16s;
}

.task-card:hover {
  border-color: #cbd5e1;
  box-shadow: 0 6px 18px rgb(15 23 42 / 7%);
}

.task-card.selected {
  border-color: #60a5fa;
  box-shadow: 0 0 0 2px rgb(96 165 250 / 18%);
}

.card-main {
  min-width: 0;
  min-height: 220px;
  overflow: hidden;
  border-right: 1px solid #e5e7eb;
  background: #f1f5f9;
}

.image-grid {
  width: 100%;
  height: 100%;
  display: grid;
  gap: 2px;
  background: #cbd5e1;
}

.image-grid.count-1 {
  grid-template-columns: 1fr;
}

.image-grid.count-2 {
  grid-template-columns: repeat(2, 1fr);
}

.image-grid.count-3,
.image-grid.count-4 {
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(2, 1fr);
}

.image-grid.count-3 .image-tile:first-child {
  grid-row: 1 / 3;
}

.image-tile {
  min-width: 0;
  min-height: 0;
  position: relative;
  overflow: hidden;
  padding: 0;
  border: 0;
  background: #e2e8f0;
  cursor: zoom-in;
}

.image-tile img {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
  transition: transform 0.2s;
}

.image-tile:hover img {
  transform: scale(1.025);
}

.image-resolution {
  position: absolute;
  top: 7px;
  left: 7px;
  padding: 3px 6px;
  border-radius: 4px;
  color: #ffffff;
  background: rgb(15 23 42 / 78%);
  font-size: 10px;
  font-variant-numeric: tabular-nums;
}

.image-download {
  width: 30px;
  height: 30px;
  position: absolute;
  right: 7px;
  bottom: 7px;
  display: grid;
  place-items: center;
  border-radius: 6px;
  color: #ffffff;
  background: rgb(15 23 42 / 80%);
  opacity: 0;
  transition: opacity 0.16s, background 0.16s;
}

.image-tile:hover .image-download,
.image-download:focus-visible {
  opacity: 1;
}

.image-download:hover {
  background: #2563eb;
}

.image-more {
  position: absolute;
  right: 7px;
  bottom: 7px;
  padding: 3px 6px;
  border-radius: 4px;
  color: #ffffff;
  background: rgb(15 23 42 / 80%);
  font-size: 10px;
}

.running-state,
.error-state {
  width: 100%;
  height: 100%;
  min-height: 220px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  padding: 24px;
  box-sizing: border-box;
}

.running-copy,
.error-state {
  color: #64748b;
  font-size: 12px;
}

.running-copy {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.running-copy strong,
.error-state strong {
  color: #334155;
  font-size: 13px;
}

.error-state {
  flex-direction: column;
  gap: 7px;
  color: #dc2626;
  text-align: center;
}

.error-state span {
  max-width: 320px;
  color: #64748b;
  line-height: 1.5;
}

.card-details {
  min-width: 0;
  display: flex;
  flex-direction: column;
  padding: 16px;
}

.card-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.card-heading time {
  color: #94a3b8;
  font-size: 11px;
}

.status-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: #64748b;
  font-size: 11px;
  font-weight: 600;
}

.status-chip i {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #94a3b8;
}

.status-chip.running {
  color: #1d4ed8;
}

.status-chip.running i {
  background: #3b82f6;
}

.status-chip.completed {
  color: #15803d;
}

.status-chip.completed i {
  background: #22c55e;
}

.status-chip.failed,
.status-chip.cancelled {
  color: #b91c1c;
}

.status-chip.failed i,
.status-chip.cancelled i {
  background: #ef4444;
}

.task-prompt {
  margin: 15px 0 12px;
  display: -webkit-box;
  overflow: hidden;
  color: #1f2937;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.55;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 4;
}

.workflow-inspector {
  margin: 0 0 11px;
  padding: 8px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  background: #f8fafc;
}

.workflow-rail {
  display: flex;
  align-items: center;
  overflow-x: auto;
  scrollbar-width: thin;
}

.workflow-node {
  min-width: 78px;
  max-width: 110px;
  min-height: 46px;
  display: flex;
  flex: 1 0 78px;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 4px;
  border: 1px solid transparent;
  border-radius: 5px;
  color: #64748b;
  background: transparent;
  cursor: pointer;
}

.workflow-node:hover,
.workflow-node.active {
  border-color: #bfdbfe;
  background: #eff6ff;
}

.workflow-node.completed .workflow-node-mark { color: #16a34a; }
.workflow-node.in_progress .workflow-node-mark { color: #2563eb; }
.workflow-node.failed .workflow-node-mark { color: #dc2626; }
.workflow-node.warning .workflow-node-mark { color: #d97706; }

.workflow-node-mark {
  height: 16px;
  display: grid;
  place-items: center;
  color: #94a3b8;
  font-size: 11px;
  font-weight: 700;
}

.workflow-node-label {
  width: 100%;
  overflow: hidden;
  color: #475569;
  font-size: 9px;
  text-align: center;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.workflow-connector {
  width: 14px;
  height: 1px;
  flex: 0 0 14px;
  background: #cbd5e1;
}

.workflow-connector.completed { background: #22c55e; }

.workflow-node-detail {
  display: grid;
  gap: 7px;
  margin-top: 8px;
  padding: 8px;
  border-top: 1px solid #e2e8f0;
}

.workflow-node-detail > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.workflow-node-detail > div strong,
.workflow-node-detail section > strong {
  color: #334155;
  font-size: 10px;
}

.workflow-node-detail > div span {
  color: #64748b;
  font-size: 9px;
  text-transform: capitalize;
}

.workflow-node-detail .node-status-completed { color: #15803d; }
.workflow-node-detail .node-status-in_progress { color: #1d4ed8; }
.workflow-node-detail .node-status-failed { color: #b91c1c; }

.workflow-node-detail pre {
  max-height: 88px;
  overflow: auto;
  margin: 4px 0 0;
  color: #475569;
  font: inherit;
  font-size: 9px;
  line-height: 1.45;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.metadata-row {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.metadata-row span {
  padding: 3px 6px;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  color: #64748b;
  background: #f8fafc;
  font-size: 10px;
}

.card-actions {
  display: flex;
  justify-content: flex-end;
  gap: 5px;
  margin-top: auto;
  padding-top: 14px;
}

.action-button {
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  border: 1px solid transparent;
  border-radius: 6px;
  color: #64748b;
  background: transparent;
  cursor: pointer;
  text-decoration: none;
}

.action-button:hover {
  color: #2563eb;
  border-color: #bfdbfe;
  background: #eff6ff;
}

.action-button.danger:hover {
  color: #dc2626;
  border-color: #fecaca;
  background: #fef2f2;
}

@media (max-width: 720px) {
  .task-card {
    grid-template-columns: 1fr;
  }

  .card-main {
    min-height: 240px;
    border-right: 0;
    border-bottom: 1px solid #e5e7eb;
  }
}
</style>
