<template>
  <div class="batch-bugfix-workspace">
    <section class="setup-column" aria-label="Batch bug fix configuration">
      <header class="card-heading">
        <div><h2>Batch Bug Fix</h2><p>Queue defects with their complete source context.</p></div>
        <button v-if="snapshot" type="button" :disabled="busy" @click="newBatch">New batch</button>
      </header>
      <label class="input-label" for="bugfix-batch-history">Batch history</label>
      <div class="history-controls">
        <select id="bugfix-batch-history" :value="snapshot?.task_id || ''" :disabled="busy" @change="openBatch($event.target.value)">
          <option value="">Select a saved batch</option>
          <option v-for="batch in history" :key="batch.task_id" :value="batch.task_id">
            {{ batch.created_at?.slice(0, 16).replace('T', ' ') }} · {{ batch.status }} · {{ batch.task_id.slice(0, 8) }}
          </option>
        </select>
        <button type="button" :disabled="busy" @click="reloadHistory">Refresh</button>
      </div>
      <p v-if="snapshot" class="field-hint">Saved batches are read-only. Select an item to inspect its report, or create a new batch.</p>
      <template v-else>
        <BugFixJiraSource :integration="integrations.jira" :disabled="locked" multiple @batch-selected="selectedIssues = $event" />
        <section class="input-section">
          <div class="input-section-header"><div><p class="eyebrow eyebrow-emerald">Shared source context</p><h3>Configure the selected defects</h3></div></div>
          <div class="input-section-body">
            <label class="input-label" for="batch-bugfix-repo">Repository slug</label>
            <input id="batch-bugfix-repo" v-model.trim="repo" class="text-input" placeholder="firmware" :disabled="locked">
            <label class="input-label" for="batch-bugfix-branch">Branch or commit</label>
            <input id="batch-bugfix-branch" v-model.trim="branch" class="text-input" placeholder="main" :disabled="locked">
            <label class="input-label" for="batch-bugfix-paths">Source file paths</label>
            <textarea id="batch-bugfix-paths" v-model="pathsText" class="text-area" rows="3" placeholder="src/driver.c&#10;include/driver.h" :disabled="locked" />
            <p class="field-hint">One repository-relative path per line. Related files stay together in each defect's repair task.</p>
            <label class="input-label" for="batch-bugfix-context">Additional context (optional)</label>
            <textarea id="batch-bugfix-context" v-model="context" class="text-area" rows="3" placeholder="Reproduction steps, logs, or repair constraints" :disabled="locked" />
            <button class="add-to-queue" type="button" :disabled="!canAdd || locked" @click="addSelected">Add {{ selectedIssues.length || '' }} selected defects</button>
            <p class="field-hint">Each added item keeps a copy of this configuration. Later edits apply to newly added items.</p>
          </div>
        </section>
      </template>
      <p v-if="!auth.isLoggedIn" class="field-error">Sign in to run BugFix and access connected repositories.</p>
      <p v-if="inputError || error" class="field-error" role="alert">{{ inputError || error }}</p>
      <button v-if="!snapshot" class="run-batch" type="button" :disabled="busy || !selectedCount || !auth.isLoggedIn" @click="start">
        {{ creating ? 'Creating batch...' : `Run ${selectedCount} selected defects` }}
      </button>
      <button v-if="snapshot?.status === 'running'" class="cancel-batch" type="button" :disabled="cancelling" @click="cancel">
        {{ cancelling ? 'Cancelling...' : 'Cancel batch' }}
      </button>
      <button v-if="snapshot?.status === 'running' && !monitoring" type="button" @click="monitor">Reconnect progress</button>
      <p class="field-hint">The server runs one defect at a time and continues after individual failures. Closing this page keeps the submitted batch running.</p>
    </section>

    <section class="queue-column" aria-label="Bug fix queue">
      <header class="card-heading"><div><h3>Execution queue</h3><p>{{ items.length }} defects · top-to-bottom order</p></div></header>
      <label v-if="!snapshot && items.length" class="select-all">
        <input type="checkbox" aria-label="Select all queued defects" :checked="selectedCount === items.length" :indeterminate="selectedCount > 0 && selectedCount < items.length" :disabled="locked" @change="selectAll($event.target.checked)">
        Select all · {{ selectedCount }} selected
      </label>
      <div v-if="!items.length" class="empty-state"><strong>No defects queued</strong><p>Select Jira Bugs, configure their source, and add them to this queue.</p></div>
      <ol v-else class="queue-list">
        <li v-for="(item, index) in items" :key="item.task_id" :class="{ selected: selectedId === item.task_id }">
          <div class="queue-row">
            <input v-if="!snapshot" type="checkbox" :aria-label="`Include ${item.label}`" :checked="checked.has(item.task_id)" :disabled="locked" @change="toggle(item.task_id, $event.target.checked)">
            <span class="sequence">{{ index + 1 }}</span>
            <button class="item-select" type="button" :aria-pressed="selectedId === item.task_id" @click="selectedId = item.task_id">
              <strong>{{ item.label }}</strong><span v-if="item.summary">{{ item.summary }}</span>
              <small>{{ item.repo }} · {{ item.branch }} · {{ item.source_files.length }} files</small>
            </button>
            <span class="item-status" :class="item.status">{{ item.status }}</span>
          </div>
          <div v-if="!snapshot" class="row-actions">
            <button type="button" :aria-label="`Move ${item.label} up`" :disabled="locked || index === 0" @click="move(item.task_id, -1)">Up</button>
            <button type="button" :aria-label="`Move ${item.label} down`" :disabled="locked || index === items.length - 1" @click="move(item.task_id, 1)">Down</button>
            <button type="button" :aria-label="`Remove ${item.label}`" :disabled="locked" @click="remove(item.task_id)">Remove</button>
          </div>
          <div v-if="item.status === 'running'" class="progress-track"><span :style="{ width: `${item.progress}%` }" /></div>
          <p v-if="item.error" class="item-error">{{ item.error }}</p>
        </li>
      </ol>
    </section>

    <section class="report-column" aria-label="Batch bug fix results" aria-live="polite">
      <div v-if="snapshot" class="batch-summary">
        <div class="card-heading"><h3>{{ snapshot.message }}</h3><strong>{{ snapshot.progress }}%</strong></div>
        <div class="progress-track" role="progressbar" aria-label="Batch progress" :aria-valuenow="snapshot.progress" aria-valuemin="0" aria-valuemax="100"><span :style="{ width: `${snapshot.progress}%` }" /></div>
        <div class="counts"><span v-for="status in countStatuses" :key="status">{{ snapshot.counts[status] }} {{ status }}</span></div>
        <small>Batch {{ snapshot.task_id }}</small>
      </div>
      <template v-if="selectedItem">
        <div class="item-detail">
          <h3>{{ selectedItem.label }} <span class="item-status" :class="selectedItem.status">{{ selectedItem.status }}</span></h3>
          <p>{{ selectedItem.repo }} · {{ selectedItem.branch }}</p>
          <ul><li v-for="path in selectedItem.source_files" :key="path"><code>{{ path }}</code></li></ul>
          <p v-if="!snapshot">This defect will be submitted with these source files and the context saved when it was added.</p>
          <p v-else-if="selectedItem.status === 'queued'">Waiting for the previous defect to finish.</p>
          <p v-else>{{ selectedItem.error || selectedItem.message }}</p>
          <p v-if="detailLoading && !detail">Loading task details...</p>
          <p v-if="detailError" class="field-error" role="alert">{{ detailError }} <button type="button" @click="loadDetail">Retry report</button></p>
          <DriverWorkflowProgress v-if="detail?.workflow_nodes?.length" :title="selectedItem.label" :description="detail.message || ''" :progress="detail.progress || 0" :steps="workflowSteps" :show-token-usage="false" />
          <small v-if="snapshot">Task {{ selectedItem.task_id }}</small>
        </div>
        <BugFixResultReport v-if="detail?.result" :key="selectedItem.task_id" :result="detail.result" :show-reset="false" />
      </template>
      <div v-else class="empty-state"><strong>Repair details</strong><p>Select a queued defect to inspect its context, progress, root cause, patch proposal, and validation notes.</p></div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import BugFixJiraSource from './bugfix-workspace/BugFixJiraSource.vue'
import BugFixResultReport from './bugfix-workspace/BugFixResultReport.vue'
import DriverWorkflowProgress from './driver-workspace/DriverWorkflowProgress.vue'
import { useAuthStore } from '../stores/auth.js'
import { getBugFixIntegrations } from '../api/bugfix.js'
import { useBugFixBatch } from '../composables/useBugFixBatch.js'

const emit = defineEmits(['busy'])
const auth = useAuthStore()
const batch = useBugFixBatch()
const {
  checked, selectedId, snapshot, history, busy, locked, creating, cancelling, monitoring,
  error, detail, detailError, detailLoading, items, selectedItem, selectedCount,
  addItems, toggle, remove, move, start, cancel, newBatch, openBatch, monitor, loadDetail,
} = batch
const integrations = ref({ jira: null, bitbucket: null })
const selectedIssues = ref([])
const repo = ref('')
const branch = ref('main')
const pathsText = ref('')
const context = ref('')
const inputError = ref('')
const paths = computed(() => [...new Set(pathsText.value.split(/[\n,]+/).map(path => path.trim().replace(/\\/g, '/')).filter(Boolean))])
const canAdd = computed(() => auth.isLoggedIn && selectedIssues.value.length && repo.value && branch.value && paths.value.length)
const countStatuses = ['queued', 'running', 'completed', 'failed', 'cancelled']
const workflowSteps = computed(() => (detail.value?.workflow_nodes || []).map(node => ({
  title: node.label || node.node_name,
  state: { completed: 'done', in_progress: 'active', failed: 'fail', cancelled: 'cancelled', skipped: 'skipped' }[node.status] || 'pending',
})))
watch(busy, value => emit('busy', value), { immediate: true })

onMounted(async () => {
  try { integrations.value = await getBugFixIntegrations() }
  catch (failure) { inputError.value = failure.message || 'Unable to load integration status.' }
})

function addSelected() {
  if (!canAdd.value || locked.value) return
  inputError.value = ''
  if (paths.value.length > 32 || paths.value.some(path => path.startsWith('/') || /[:\0]/.test(path) || path.split('/').some(part => ['', '.', '..'].includes(part)))) {
    inputError.value = 'Use at most 32 repository-relative source paths without traversal segments.'
    return
  }
  if (repo.value.length > 128 || branch.value.length > 256 || context.value.length > 20000) {
    inputError.value = 'Repository, branch, or additional context exceeds the allowed input length.'
    return
  }
  addItems(selectedIssues.value, { repo: repo.value, branch: branch.value, source_files: paths.value, bug_description: context.value })
}

function selectAll(selected) {
  for (const item of items.value) toggle(item.task_id, selected)
}

async function reloadHistory() {
  try { await batch.refreshHistory() }
  catch (failure) { inputError.value = failure.message || 'Unable to refresh batch history.' }
}
</script>

<style scoped src="./bugfix-workspace/bugfix-input.css"></style>
<style scoped>
* { box-sizing: border-box; }
.batch-bugfix-workspace { flex: 1; min-height: 0; min-width: 0; display: grid; grid-template-columns: minmax(280px, 0.9fr) minmax(260px, 0.8fr) minmax(320px, 1.3fr); gap: 12px; padding: 12px; background: #f8fafc; overflow: hidden; color: #334155; }
.setup-column, .queue-column, .report-column { min-width: 0; min-height: 0; overflow-y: auto; scrollbar-width: thin; }
.setup-column, .report-column { display: flex; flex-direction: column; gap: 12px; }
.setup-column, .queue-column, .batch-summary, .item-detail { border: 1px solid #e2e8f0; border-radius: 12px; background: white; padding: 14px; }
.card-heading { display: flex; justify-content: space-between; align-items: center; gap: 10px; }
h2, h3, p { margin: 0; }
h2 { font-size: 17px; } h3 { font-size: 14px; }
p { font-size: 12px; line-height: 1.6; overflow-wrap: anywhere; }
.card-heading p { margin-top: 6px; color: #64748b; }
button, select { font: inherit; font-size: 12px; border: 1px solid #cbd5e1; border-radius: 7px; padding: 7px 9px; color: #334155; background: white; cursor: pointer; }
button:disabled, select:disabled { opacity: 0.5; cursor: not-allowed; }
button:hover:not(:disabled) { background: #eff6ff; }
.history-controls { display: flex; gap: 6px; } select { min-width: 0; flex: 1; }
.input-label { margin-top: 4px; }
.add-to-queue { width: 100%; margin-top: 12px; color: #1d4ed8; border-color: #93c5fd; background: #eff6ff; }
.run-batch { background: #2563eb; color: white; font-weight: 700; min-height: 42px; }
.run-batch:hover:not(:disabled) { background: #1d4ed8; }
.cancel-batch { border-color: #fca5a5; color: #b91c1c; }
.select-all { display: flex; gap: 8px; align-items: center; padding: 14px 0; font-size: 12px; }
.queue-list { list-style: none; padding: 0; margin: 12px 0 0; }
.queue-list > li { border: 1px solid #e2e8f0; padding: 10px; margin-bottom: 8px; border-radius: 10px; }
.queue-list > li.selected { border-color: #93c5fd; background: #eff6ff; }
.queue-row { display: flex; gap: 7px; align-items: flex-start; }
.sequence { color: #94a3b8; font-size: 11px; padding-top: 5px; }
.item-select { flex: 1; min-width: 0; border: 0; background: transparent; padding: 2px; text-align: left; }
.item-select strong, .item-select span, .item-select small { display: block; overflow-wrap: anywhere; line-height: 1.5; }
.item-select small { color: #64748b; margin-top: 5px; }
.row-actions { display: flex; justify-content: flex-end; gap: 6px; margin-top: 8px; }
.row-actions button { font-size: 10px; padding: 4px 6px; }
.item-status { display: inline-flex; border-radius: 999px; padding: 3px 6px; font-size: 10px; background: #ede9fe; color: #6d28d9; }
.item-status.running { background: #fef3c7; color: #b45309; }
.item-status.completed { background: #dcfce7; color: #15803d; }
.item-status.failed { background: #fee2e2; color: #b91c1c; }
.item-status.cancelled { background: #e2e8f0; color: #475569; }
.progress-track { margin-top: 12px; height: 7px; border-radius: 6px; overflow: hidden; background: #e2e8f0; }
.progress-track > span { display: block; height: 100%; background: #6366f1; transition: width 0.25s; }
.counts { display: flex; flex-wrap: wrap; gap: 10px; font-size: 11px; margin: 12px 0; }
.batch-summary small, .item-detail small { color: #64748b; font-size: 10px; overflow-wrap: anywhere; }
.item-detail { display: flex; flex-direction: column; gap: 10px; }
.item-detail ul { padding-left: 18px; margin: 0; font-size: 12px; overflow-wrap: anywhere; }
.empty-state { padding: 36px 16px; text-align: center; color: #64748b; }
.empty-state p { margin-top: 8px; }
.item-error { margin-top: 8px; color: #b91c1c; font-size: 11px; }
.report-column :deep(.result-content) { flex: 0 0 auto; overflow: visible; }
@media (max-width: 1200px) { .batch-bugfix-workspace { grid-template-columns: minmax(280px, 1fr) minmax(280px, 1fr); overflow-y: auto; } .report-column { grid-column: 1 / -1; min-height: 320px; overflow: visible; } .setup-column, .queue-column { max-height: 640px; } }
@media (max-width: 760px) { .batch-bugfix-workspace { display: flex; flex-direction: column; } .setup-column, .queue-column, .report-column { flex: 0 0 auto; max-height: none; overflow: visible; } }
</style>
