<template>
  <section>
    <h2>System event sources</h2>
    <p>
      Connect CI, issue trackers, monitoring, or other systems with signed webhooks. Feishu uses the
      bot configured in Apps.
    </p>
    <form class="create-source" @submit.prevent="create">
      <label
        >Source name<input
          v-model="name"
          required
          maxlength="80"
          pattern="[A-Za-z0-9][A-Za-z0-9 _.\-]*"
          placeholder="CI pipeline"
          aria-label="Webhook source name"
      /></label>
      <button :disabled="busy || !name.trim() || sources.length >= 20">
        Create webhook source
      </button>
    </form>
    <div v-if="secret" class="secret-notice" role="status">
      <strong>Copy this secret now. It is shown only once.</strong><code>{{ secret }}</code>
      <button type="button" @click="secret = ''">Dismiss secret</button>
    </div>
    <p v-if="error" role="alert" class="error">{{ error }}</p>
    <article v-for="source in sources" :key="source.id" class="source">
      <div>
        <strong>{{ source.name }}</strong
        ><span>{{ source.enabled ? 'Enabled' : 'Disabled' }}</span>
      </div>
      <code>{{ source.id }}</code
      ><code>{{ endpoint(source.endpoint) }}</code>
      <div class="actions">
        <button :disabled="busy" @click="toggle(source)">
          {{ source.enabled ? 'Disable' : 'Enable' }}
        </button>
        <button :disabled="busy" @click="rotate(source)">Rotate secret</button>
        <button :disabled="busy" @click="remove(source)">Delete source</button>
      </div>
    </article>
    <details>
      <summary>Webhook and API delivery format</summary>
      <p>
        POST UTF-8 JSON to the source endpoint. Sign the exact raw bytes: HMAC-SHA256(secret,
        timestamp + "." + body). Use headers X-Event-Timestamp (Unix seconds) and X-Event-Signature:
        sha256=&lt;hex&gt;. Accepted clock skew: 5 minutes.
      </p>
      <pre>{{ example }}</pre>
      <p>
        event_id must be stable across delivery retries. A reused ID with changed content returns
        409. Execution is asynchronous; view outcomes in Recent events.
      </p>
      <p>
        Authenticated systems may POST the same envelope to /api/v1/event-center/events with the
        user's Bearer token. Source is always api; the payload cannot choose the owner or Agent.
      </p>
    </details>
  </section>
</template>

<script setup>
import { onBeforeUnmount, ref, watch } from 'vue'
import { ElMessageBox } from 'element-plus'
import {
  createEventSource,
  deleteEventSource,
  listEventSources,
  rotateEventSource,
  setEventSourceEnabled,
} from '../api/events.js'

const props = defineProps({ accountId: { type: String, required: true } })
const sources = ref([]),
  name = ref(''),
  secret = ref(''),
  busy = ref(false),
  error = ref('')
let revision = 0
const example = JSON.stringify(
  {
    event_id: 'ci-build-123',
    event_type: 'build.failed',
    text: 'Analyze this compiler failure',
    data: { crash_log: 'Compiler output goes here' },
  },
  null,
  2
)
function endpoint(path) {
  return new URL(path, window.location.origin).href
}
async function load() {
  const current = ++revision
  sources.value = []
  secret.value = ''
  error.value = ''
  name.value = ''
  try {
    const result = await listEventSources()
    if (current === revision) sources.value = result.items
  } catch (failure) {
    if (current === revision) error.value = failure.message || 'Could not load webhook sources.'
  }
}
async function action(run) {
  const current = revision
  busy.value = true
  error.value = ''
  secret.value = ''
  try {
    const result = await run()
    if (current !== revision) return
    secret.value = result?.webhook_secret || ''
    const listing = await listEventSources()
    if (current === revision) sources.value = listing.items
  } catch (failure) {
    if (current === revision) error.value = failure.message || 'The webhook operation failed.'
  } finally {
    if (current === revision) busy.value = false
  }
}
async function create() {
  const current = revision
  await action(() => createEventSource(name.value.trim()))
  if (current === revision) name.value = ''
}
async function toggle(source) {
  await action(() => setEventSourceEnabled(source.id, !source.enabled))
}
async function rotate(source) {
  const current = revision
  try {
    await ElMessageBox.confirm(
      'Existing senders must use the new secret immediately.',
      'Rotate webhook secret',
      { type: 'warning' }
    )
  } catch {
    return
  }
  if (current === revision) await action(() => rotateEventSource(source.id))
}
async function remove(source) {
  const current = revision
  try {
    await ElMessageBox.confirm(
      'New deliveries will be rejected and queued events from this source will be ignored.',
      'Delete webhook source',
      { type: 'warning' }
    )
  } catch {
    return
  }
  if (current === revision) await action(() => deleteEventSource(source.id))
}
watch(
  () => props.accountId,
  () => {
    busy.value = false
    void load()
  },
  { immediate: true }
)
onBeforeUnmount(() => {
  revision++
  secret.value = ''
})
</script>

<style scoped>
h2 {
  font-size: 18px;
  margin: 0;
}
p {
  font-size: 13px;
  color: #64748b;
  line-height: 1.6;
}
.create-source {
  display: flex;
  gap: 12px;
  align-items: flex-end;
  margin: 20px 0;
}
.create-source label {
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 13px;
  color: #475569;
}
input {
  padding: 9px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
}
button {
  padding: 8px 12px;
  border: 1px solid #cbd5e1;
  background: white;
  border-radius: 6px;
  cursor: pointer;
  color: #334155;
}
button:disabled {
  opacity: 0.5;
  cursor: default;
}
.source {
  border-top: 1px solid #e2e8f0;
  padding: 18px 0;
}
.source span {
  font-size: 12px;
  margin-left: 14px;
  color: #64748b;
}
code {
  display: block;
  font-size: 12px;
  overflow-wrap: anywhere;
  margin: 8px 0;
}
.actions {
  display: flex;
  gap: 8px;
}
.secret-notice {
  padding: 16px;
  background: #fffbeb;
  color: #854d0e;
  border: 1px solid #fde68a;
  border-radius: 8px;
}
.error {
  color: #b91c1c;
}
summary {
  cursor: pointer;
  font-size: 14px;
}
pre {
  background: #f8fafc;
  padding: 12px;
  overflow: auto;
  font-size: 12px;
}
@media (max-width: 600px) {
  .create-source {
    flex-direction: column;
    align-items: stretch;
  }
}
</style>
