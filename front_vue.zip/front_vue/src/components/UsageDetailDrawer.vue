<template>
  <el-drawer
    :model-value="modelValue"
    title="Usage Details"
    size="min(760px, 100vw)"
    destroy-on-close
    @update:model-value="emit('update:modelValue', $event)"
  >
    <div v-if="loading" role="status">Loading usage details...</div>
    <div v-else-if="error" class="detail-error">
      <el-alert :title="error" type="error" :closable="false" show-icon />
      <el-button @click="load">Retry</el-button>
    </div>
    <article v-else-if="detail" class="usage-detail">
      <div class="detail-summary">
        <div>
          <span>Standard cost (USD)</span><strong>{{ standardCost }}</strong>
        </div>
        <div>
          <span>Actual charge (CNY)</span
          ><strong>{{
            detail.usage_source === 'legacy' && !detail.charged_cny && !detail.transactions.length
              ? 'Not recorded'
              : money(detail.charged_cny, 'CNY')
          }}</strong>
        </div>
      </div>
      <el-alert
        v-if="detail.usage_source !== 'reported' || !detail.cost_breakdown.available"
        title="Some usage or pricing data was not recorded. Missing details are not reconstructed from current prices. Estimated usage is never debited."
        type="warning"
        :closable="false"
        show-icon
      />
      <section>
        <h3>Request</h3>
        <dl class="detail-fields">
          <div>
            <dt>Record ID</dt>
            <dd>{{ detail.id }}</dd>
          </div>
          <div>
            <dt>Time</dt>
            <dd>{{ new Date(detail.created_at).toLocaleString() }}</dd>
          </div>
          <div>
            <dt>Model</dt>
            <dd>{{ detail.model }}</dd>
          </div>
          <div>
            <dt>Provider / Agent</dt>
            <dd>{{ detail.provider }} / {{ detail.agent_name }}</dd>
          </div>
          <div>
            <dt>Status</dt>
            <dd>{{ detail.status }}</dd>
          </div>
          <div>
            <dt>Duration</dt>
            <dd>
              {{
                detail.latency_ms > 0
                  ? `${(detail.latency_ms / 1000).toFixed(3)} s`
                  : 'Not recorded'
              }}
            </dd>
          </div>
          <div>
            <dt>Usage source</dt>
            <dd>{{ sourceLabel(detail.usage_source) }}</dd>
          </div>
          <div>
            <dt>Price source</dt>
            <dd>{{ sourceLabel(detail.pricing_source) }}</dd>
          </div>
          <div v-if="admin">
            <dt>User ID</dt>
            <dd>{{ detail.user_id || 'Not recorded' }}</dd>
          </div>
          <div>
            <dt>Workflow ID</dt>
            <dd>{{ detail.workflow_id || 'Not recorded' }}</dd>
          </div>
          <div>
            <dt>Session ID</dt>
            <dd>{{ detail.session_id || 'Not recorded' }}</dd>
          </div>
        </dl>
        <div class="detail-actions">
          <el-button
            v-if="detail.workflow_id"
            @click="emit('related', { workflow_id: detail.workflow_id })"
            >View Workflow Requests</el-button
          >
          <el-button
            v-if="detail.session_id"
            @click="emit('related', { session_id: detail.session_id })"
            >View Session Requests</el-button
          >
        </div>
      </section>
      <section>
        <h3>Token Details</h3>
        <dl class="detail-fields">
          <div>
            <dt>Total tokens</dt>
            <dd>{{ number(detail.total_tokens) }}</dd>
          </div>
          <div>
            <dt>Input (including cache)</dt>
            <dd>{{ number(detail.prompt_tokens) }}</dd>
          </div>
          <div>
            <dt>Uncached input</dt>
            <dd>{{ number(detail.token_breakdown.uncached_input_tokens) }}</dd>
          </div>
          <div>
            <dt>Output</dt>
            <dd>{{ number(detail.completion_tokens) }}</dd>
          </div>
          <div>
            <dt>Cache read</dt>
            <dd>{{ number(detail.cache_read_tokens) }}</dd>
          </div>
          <div>
            <dt>Cache write</dt>
            <dd>{{ number(detail.cache_write_tokens) }}</dd>
          </div>
        </dl>
        <p class="detail-note">
          Input includes cache reads and writes exactly once. A CLI record can aggregate several
          upstream requests.
        </p>
      </section>
      <section>
        <h3>Cost Breakdown</h3>
        <p class="detail-note">
          Rates are USD per one million tokens, saved when the call completed.
        </p>
        <el-table
          v-if="detail.cost_breakdown.available"
          :data="detail.cost_breakdown.items"
          size="small"
        >
          <el-table-column label="Category" min-width="140"
            ><template #default="{ row }">{{ sourceLabel(row.kind) }}</template></el-table-column
          >
          <el-table-column label="Tokens" min-width="100"
            ><template #default="{ row }">{{ number(row.tokens) }}</template></el-table-column
          >
          <el-table-column label="USD / 1M" min-width="120"
            ><template #default="{ row }">{{
              money(row.usd_per_mtok, 'USD')
            }}</template></el-table-column
          >
          <el-table-column label="Cost (USD)" min-width="130"
            ><template #default="{ row }">{{
              money(row.cost_usd, 'USD')
            }}</template></el-table-column
          >
        </el-table>
        <p v-else>Cost breakdown not recorded.</p>
        <el-alert
          v-if="detail.cost_breakdown.matches_recorded_cost === false"
          title="The saved token breakdown differs from the recorded cost. The original recorded cost and debit remain unchanged."
          type="warning"
          :closable="false"
        />
      </section>
      <section>
        <h3>Billing Details</h3>
        <dl class="detail-fields">
          <div>
            <dt>Billing status</dt>
            <dd>{{ sourceLabel(detail.billing.status) }}</dd>
          </div>
          <div>
            <dt>USD to CNY rate</dt>
            <dd>{{ detail.billing.usd_to_cny_rate ?? 'Not recorded' }}</dd>
          </div>
          <div>
            <dt>Membership discount</dt>
            <dd>
              {{
                detail.billing.discount_percent === null ||
                detail.billing.discount_percent === undefined
                  ? 'Not recorded'
                  : `${detail.billing.discount_percent}% off`
              }}
            </dd>
          </div>
          <div>
            <dt>Charge before discount</dt>
            <dd>{{ money(detail.billing.charge_before_discount_cny, 'CNY') }}</dd>
          </div>
        </dl>
        <p class="detail-note">
          CNY charges are rounded to four decimal places before and after any membership discount.
          Historical costs are not recalculated.
        </p>
        <div v-for="transaction in detail.transactions" :key="transaction.id" class="ledger-entry">
          <strong>Balance transaction</strong>
          <dl class="detail-fields">
            <div>
              <dt>Transaction ID</dt>
              <dd>{{ transaction.id }}</dd>
            </div>
            <div>
              <dt>Amount (CNY)</dt>
              <dd>{{ money(transaction.amount, 'CNY') }}</dd>
            </div>
            <div>
              <dt>Balance after (CNY)</dt>
              <dd>{{ money(transaction.balance_after, 'CNY') }}</dd>
            </div>
          </dl>
        </div>
        <p v-if="!detail.transactions.length" class="detail-note">
          No linked balance transaction was recorded.
        </p>
        <el-button v-if="detail.user_id === auth.user?.id" @click="router.push('/transactions')"
          >View My Balance Transactions</el-button
        >
      </section>
    </article>
  </el-drawer>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth.js'
import { getUsageDetail } from '../api/modelManagement.js'

const props = defineProps({
  modelValue: Boolean,
  usageId: { type: String, default: '' },
  admin: Boolean,
})
const emit = defineEmits(['update:modelValue', 'related'])
const auth = useAuthStore(),
  router = useRouter()
const detail = ref(null),
  loading = ref(false),
  error = ref('')
let version = 0
const number = value => Number(value || 0).toLocaleString('en-US')
const money = (value, currency) =>
  value === null || value === undefined
    ? 'Not recorded'
    : Number(value).toLocaleString('en-US', {
        style: 'currency',
        currency,
        minimumFractionDigits: 4,
        maximumFractionDigits: 8,
      })
const standardCost = computed(() =>
  detail.value?.pricing_source === 'unpriced' || detail.value?.usage_source === 'unavailable'
    ? 'Unavailable'
    : money(detail.value?.cost_usd, 'USD')
)
const labels = {
  reported: 'Provider reported',
  estimated: 'Estimated',
  unavailable: 'Unavailable',
  legacy: 'Legacy record',
  catalog: 'Model catalog',
  legacy_default: 'Default price',
  legacy_model: 'Model fallback price',
  unpriced: 'Price unavailable',
  uncached_input: 'Uncached input',
  output: 'Output',
  cache_read: 'Cache read',
  cache_write: 'Cache write',
  charged: 'Charged',
  billing_disabled: 'Billing disabled',
  estimated_usage: 'Estimated usage; no debit',
  unavailable_usage: 'Usage unavailable; no debit',
  guest: 'Guest; no debit',
  zero_cost: 'Zero standard cost',
  below_minimum_charge: 'Rounded to zero',
  account_unavailable: 'Account unavailable; no debit',
  unknown: 'Not recorded',
}
const sourceLabel = value => labels[value] || value
async function load() {
  const current = ++version
  detail.value = null
  error.value = ''
  loading.value = false
  if (!props.modelValue || !props.usageId || !auth.isLoggedIn) return
  loading.value = true
  try {
    const result = await getUsageDetail(props.usageId, props.admin)
    if (current === version) detail.value = result
  } catch (failure) {
    if (current === version) error.value = failure.message || 'Failed to load usage details'
  } finally {
    if (current === version) loading.value = false
  }
}
watch(
  () => [
    props.modelValue,
    props.usageId,
    props.admin,
    `${auth.user?.id || ''}:${auth.user?.name || ''}`,
    auth.isLoggedIn,
  ],
  (values, previous) => {
    if (previous && (values[3] !== previous[3] || !values[4])) {
      ++version
      detail.value = null
      error.value = ''
      loading.value = false
      emit('update:modelValue', false)
      return
    }
    void load()
  },
  { immediate: true }
)
onBeforeUnmount(() => {
  ++version
})
</script>

<style scoped>
.usage-detail {
  display: grid;
  gap: 20px;
  color: #1e293b;
}
.usage-detail h3 {
  margin: 0 0 14px;
  font-size: 16px;
}
.detail-summary {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
.detail-summary > div {
  padding: 16px;
  border-radius: 12px;
  background: #f1f5f9;
}
.detail-summary span {
  display: block;
  font-size: 12px;
  margin-bottom: 8px;
  color: #64748b;
}
.detail-summary strong {
  font-size: 22px;
  overflow-wrap: anywhere;
}
.detail-fields {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px 20px;
  margin: 0;
}
.detail-fields dt {
  font-size: 12px;
  color: #64748b;
  margin-bottom: 5px;
}
.detail-fields dd {
  margin: 0;
  font-size: 13px;
  overflow-wrap: anywhere;
}
.detail-note {
  color: #64748b;
  font-size: 12px;
  line-height: 1.7;
}
.detail-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 14px;
}
.detail-actions .el-button {
  margin: 0;
}
.detail-error {
  display: grid;
  gap: 12px;
}
.ledger-entry {
  background: #f8fafc;
  padding: 14px;
  border-radius: 10px;
  margin: 12px 0;
}
.ledger-entry strong {
  display: block;
  font-size: 13px;
  margin-bottom: 14px;
}
@media (max-width: 480px) {
  .detail-fields,
  .detail-summary {
    grid-template-columns: 1fr;
  }
}
</style>
