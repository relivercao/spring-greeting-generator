<template>
  <div class="welcome-page">
    <div class="welcome-content">
      <AgentWelcomeBanner
        :agent-count="agents.length"
        @explore-agents="focusAgents"
      />

      <div
        class="quick-prompts"
        aria-label="Suggested starting points"
      >
        <button
          v-for="prompt in quickPrompts"
          :key="prompt.text"
          type="button"
          class="prompt-chip"
          @click="$emit('select-agent', prompt.agent)"
        >
          <el-icon size="13">
            <component :is="prompt.icon" />
          </el-icon>
          {{ prompt.text }}
        </button>
      </div>

      <section
        ref="agentsSection"
        class="agents-section"
        aria-labelledby="agents-title"
      >
        <div class="section-header">
          <div>
            <p class="section-eyebrow">
              Your AI team
            </p>
            <h2
              id="agents-title"
              class="section-title"
            >
              Choose an Agent to begin
            </h2>
          </div>
          <span class="section-count">{{ agents.length }} available</span>
        </div>
        <div
          class="agents-grid"
          :class="{ 'single-agent': agents.length === 1 }"
        >
          <AgentCard
            v-for="(agent, index) in agents"
            :key="agent.id"
            :agent="agent"
            :index="index + 1"
            @click="$emit('select-agent', agent)"
          />
        </div>
      </section>

      <div class="homepage-note">
        <span class="homepage-note-line" />
        <span>Need a custom workflow? Agent Generator can build one from your prompt.</span>
        <span class="homepage-note-line" />
      </div>

      <div class="page-footer">
        © 2026 relivercao@gmail.com · Macode 1.0.6 · All rights reserved
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import AgentCard from './AgentCard.vue'
import AgentWelcomeBanner from './AgentWelcomeBanner.vue'

const props = defineProps({
  user: { type: Object, default: null },
  agents: { type: Array, default: () => [] },
})

defineEmits(['select-agent'])

const agentsSection = ref(null)

const quickPrompts = computed(() => [
  { agentId: 2, text: 'Generate unit tests', icon: 'Finished' },
  { agentId: 3, text: 'Create peripheral driver', icon: 'Connection' },
  { agentId: 4, text: 'Review code changes', icon: 'DocumentChecked' },
].map(prompt => ({ ...prompt, agent: props.agents.find(agent => agent.id === prompt.agentId) }))
  .filter(prompt => prompt.agent))

function focusAgents() {
  const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'
  agentsSection.value?.scrollIntoView({ behavior, block: 'start' })
}
</script>

<style scoped>
.welcome-page {
  flex: 1;
  overflow-y: auto;
  background: #f4f8fb;
  padding: 26px 32px 42px;
  scrollbar-width: thin;
  scrollbar-color: #cbd5e1 transparent;
}

.welcome-page::-webkit-scrollbar { width: 6px; }
.welcome-page::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }

.welcome-content {
  max-width: 1180px;
  margin: 0 auto;
}

.quick-prompts {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 18px 0 30px;
}

.prompt-chip {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  min-height: 32px;
  padding: 0 13px;
  border: 1px solid #d7e2eb;
  border-radius: 8px;
  background: #ffffff;
  color: #52697d;
  font-family: inherit;
  font-size: 12px;
  cursor: pointer;
  transition: border-color 0.15s, color 0.15s, background 0.15s;
}

.prompt-chip:hover {
  border-color: #93c5fd;
  background: #eff6ff;
  color: #1d4ed8;
}

.agents-section { scroll-margin-top: 16px; }

.section-header {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 16px;
}

.section-eyebrow {
  margin: 0 0 4px;
  color: #0f8a87;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 1.25px;
  text-transform: uppercase;
}

.section-title {
  margin: 0;
  color: #132f49;
  font-size: 21px;
  font-weight: 750;
  letter-spacing: -0.2px;
}

.section-count {
  padding-bottom: 2px;
  color: #7890a3;
  font-size: 12px;
}

.agents-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 16px;
}

.agents-grid.single-agent { grid-template-columns: minmax(0, 340px); }

.homepage-note {
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 30px 0 0;
  color: #8093a3;
  font-size: 11px;
  text-align: center;
}

.homepage-note-line {
  flex: 1;
  height: 1px;
  background: #d7e2eb;
}

.page-footer {
  margin-top: 18px;
  color: #a1b0bd;
  font-size: 10px;
  text-align: center;
}

@media (max-width: 900px) {
  .welcome-page { padding: 22px 22px 36px; }
  .agents-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}

@media (max-width: 640px) {
  .welcome-page { padding: 16px 14px 30px; }
  .agents-grid { grid-template-columns: 1fr; }
  .agents-grid.single-agent { grid-template-columns: 1fr; }
  .section-header { align-items: flex-start; }
  .homepage-note-line { display: none; }
  .homepage-note { justify-content: center; line-height: 1.5; }
}
</style>
