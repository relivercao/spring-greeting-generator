<template>
  <div class="app-provider-settings">
    <p>Configure Composio once, then each user authorizes their own app accounts.</p>
    <el-alert v-if="error" :title="error" type="error" :closable="false" />
    <div v-if="loading" role="status">Loading connection settings...</div>
    <template v-else-if="loaded">
      <label for="app-provider-key">Composio API key</label>
      <el-input
        id="app-provider-key"
        v-model="apiKey"
        type="password"
        show-password
        autocomplete="new-password"
        :placeholder="
          keyConfigured
            ? 'Configured; leave blank to keep the current key'
            : 'Enter the provider API key'
        "
      />
      <label for="app-provider-url">Provider API URL</label>
      <el-input
        id="app-provider-url"
        v-model="apiBaseUrl"
        placeholder="https://backend.composio.dev/api/v3.1"
      />
      <label for="app-callback-url">App authorization return URL</label>
      <el-input
        id="app-callback-url"
        v-model="frontendBaseUrl"
        placeholder="http://127.0.0.1:5173"
      />
      <p class="settings-hint">
        Used only for App Connect authorization returns. Payment return URLs are configured separately.
      </p>
      <div class="config-list">
        <div v-for="app in apps" :key="app.slug" class="config-row">
          <label :for="`auth-config-${app.slug}`">{{ app.name }}</label>
          <el-input
            :id="`auth-config-${app.slug}`"
            v-model="authConfigs[app.slug]"
            placeholder="Auth Config ID (ac_...)"
          />
        </div>
      </div>
      <p class="settings-hint">
        Create one Auth Config per app in your Composio project. Leave unused apps blank.
      </p>
      <el-button type="primary" :loading="saving" @click="save">Save connection settings</el-button>
    </template>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getAppConnectionProvider, saveAppConnectionProvider } from '../api/connectedApps.js'

const emit = defineEmits(['saved'])
const loading = ref(false)
const loaded = ref(false)
const saving = ref(false)
const error = ref('')
const apps = ref([])
const apiKey = ref('')
const apiBaseUrl = ref('')
const frontendBaseUrl = ref('')
const authConfigs = ref({})
const keyConfigured = ref(false)

onMounted(async () => {
  loading.value = true
  try {
    const configuration = await getAppConnectionProvider()
    apps.value = configuration.apps || []
    apiBaseUrl.value = configuration.api_base_url || ''
    const hasDedicatedAppUrl = Object.hasOwn(configuration, 'app_frontend_base_url')
    const configuredAppUrl = configuration.app_frontend_base_url || ''
    const legacyAppUrl = configuration.frontend_base_url || ''
    const usingLegacyLoopbackUrl = !configuredAppUrl && isLoopbackUrl(legacyAppUrl)
    frontendBaseUrl.value = hasDedicatedAppUrl
      ? configuredAppUrl || window.location.origin
      : configuredAppUrl ||
        (legacyAppUrl && !usingLegacyLoopbackUrl ? legacyAppUrl : window.location.origin)
    authConfigs.value = { ...configuration.auth_configs }
    keyConfigured.value = Boolean(configuration.api_key_configured)
    loaded.value = true
  } catch (failure) {
    error.value = failure.message || 'Could not load connection settings.'
  } finally {
    loading.value = false
  }
})

async function save() {
  error.value = ''
  saving.value = true
  try {
    const configuration = await saveAppConnectionProvider({
      api_key: apiKey.value.trim() || null,
      api_base_url: apiBaseUrl.value,
      app_frontend_base_url: frontendBaseUrl.value,
      auth_configs: { ...authConfigs.value },
    })
    apiKey.value = ''
    keyConfigured.value = Boolean(configuration.api_key_configured)
    ElMessage.success('Application connection settings saved.')
    emit('saved')
  } catch (failure) {
    error.value = failure.message || 'Could not save connection settings.'
  } finally {
    saving.value = false
  }
}

function isLoopbackUrl(value) {
  try {
    return ['localhost', '127.0.0.1', '[::1]', '::1'].includes(new URL(value).hostname)
  } catch {
    return false
  }
}
</script>

<style scoped>
.app-provider-settings {
  padding: 16px;
  border: 1px solid #dce1e8;
  border-radius: 8px;
  background: #f8fafc;
}
.app-provider-settings > label {
  display: block;
  margin: 14px 0 6px;
  color: #4b5563;
  font-size: 12px;
  font-weight: 600;
}
.app-provider-settings p {
  margin: 0 0 12px;
  color: #5f6978;
  font-size: 13px;
  line-height: 1.5;
}
.app-provider-settings .settings-hint {
  margin: 7px 0 14px;
  font-size: 11px;
}
.config-list {
  display: grid;
  gap: 9px;
  margin-top: 16px;
}
.config-row {
  display: grid;
  grid-template-columns: 110px minmax(0, 1fr);
  align-items: center;
  gap: 10px;
  font-size: 12px;
}
@media (max-width: 500px) {
  .config-row {
    grid-template-columns: 1fr;
    gap: 5px;
  }
}
</style>
