<template>
  <div
    v-if="visible"
    class="profile-error-overlay"
    @click.self="handleClose"
  >
    <div class="profile-error-dialog">
      <div class="error-icon">
        ⚠️
      </div>

      <div class="error-message">
        <template v-if="profileName">
          Profile <span class="profile-name">{{ profileName }}</span> is invalid, please check and try again
        </template>
        <template v-else>
          AWS Profile is not configured. Please configure a valid AWS_PROFILE in Provider Settings and try again
        </template>
      </div>

      <button
        class="confirm-btn"
        @click="handleClose"
      >
        OK
      </button>
    </div>
  </div>
</template>

<script setup>
import { defineProps, defineEmits } from 'vue'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  profileName: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['close'])

const handleClose = () => {
  emit('close')
}
</script>

<style scoped>
.profile-error-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.profile-error-dialog {
  background: #fff;
  border-radius: 8px;
  padding: 32px;
  width: 400px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  animation: slideUp 0.3s ease;
  text-align: center;
}

@keyframes slideUp {
  from {
    transform: translateY(20px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.error-icon {
  font-size: 48px;
  margin-bottom: 16px;
}

.error-message {
  font-size: 16px;
  color: #303133;
  margin-bottom: 24px;
  line-height: 1.6;
}

.profile-name {
  color: #f56c6c;
  font-weight: 600;
  font-family: 'Consolas', 'Monaco', monospace;
}

.confirm-btn {
  width: 50%;
  padding: 10px;
  background: #409eff;
  color: #fff;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.3s;
}

.confirm-btn:hover {
  background: #66b1ff;
}
</style>
