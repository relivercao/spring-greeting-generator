<template>
  <section class="connected-apps-panel">
    <div class="dialog-heading">
      <div>
        <h2>Connected apps</h2>
        <p>Authorize apps so Chat Agent can work with your account when you ask.</p>
      </div>
      <el-tooltip content="Refresh connections" placement="bottom">
        <button
          class="refresh-button"
          type="button"
          aria-label="Refresh connections"
          :disabled="loading"
          @click="loadApps"
        >
          <el-icon :class="{ spinning: loading }"><Refresh /></el-icon>
        </button>
      </el-tooltip>
    </div>

    <template v-if="authStore.isLoggedIn">
      <el-input
        v-model="search"
        class="app-search"
        clearable
        placeholder="Search apps"
        aria-label="Search apps"
      >
        <template #prefix
          ><el-icon><Search /></el-icon
        ></template>
      </el-input>

      <div class="app-toolbar">
        <div class="filter-group" role="group" aria-label="Filter apps">
          <button
            v-for="option in filters"
            :key="option.value"
            type="button"
            :class="['filter-button', { active: activeFilter === option.value }]"
            :aria-pressed="activeFilter === option.value"
            @click="activeFilter = option.value"
          >
            {{ option.label
            }}<span v-if="option.value === 'connected'"> ({{ connectedCount }})</span>
          </button>
        </div>
        <span class="app-count">{{ filteredApps.length }} apps</span>
      </div>

      <el-alert
        v-if="error"
        class="connection-alert"
        :title="error"
        type="error"
        :closable="false"
        show-icon
      />
      <el-alert v-if="providerWarning" class="connection-alert" :title="providerWarning" type="warning" :closable="false" show-icon />
      <el-alert
        v-if="!error && !providerWarning && !providerConfigured"
        class="connection-alert"
        title="OAuth app connections are not configured by the administrator."
        description="An administrator can configure the OAuth provider below. Feishu Bot uses its own CLI connection settings."
        type="info"
        :closable="false"
        show-icon
      />

      <div v-if="loading && !apps.length" class="dialog-state">
        <el-icon class="spinning"><Loading /></el-icon>
        <span>Loading apps...</span>
      </div>
      <div v-else-if="!filteredApps.length" class="dialog-state">
        <span>No apps match this search.</span>
      </div>
      <div v-else class="apps-grid">
        <article v-for="app in filteredApps" :key="app.slug" class="app-card">
          <div :class="['app-mark', `mark-${app.slug}`]" :aria-label="app.name">
            {{ appMark(app) }}
          </div>
          <div class="app-copy">
            <div class="app-name-row">
              <h3>{{ app.name }}</h3>
              <span :class="['connection-state', stateClass(app)]">
                <span class="state-dot" />{{ stateLabel(app) }}
              </span>
            </div>
            <p>{{ app.description }}</p>
          </div>
          <div class="app-actions">
            <el-button v-if="app.connection_method === 'feishu_cli'" size="small" type="primary" @click="configuringFeishu = !configuringFeishu">
              {{ configuringFeishu ? 'Hide settings' : 'Configure Bot' }}
            </el-button>
            <template v-else-if="app.connected">
              <el-button v-if="app.slug === 'gmail'" size="small" type="primary" @click="emit('use-app', app.slug)">
                Use Gmail
              </el-button>
              <el-button
                size="small"
                plain
                :loading="disconnecting === app.slug"
                @click="disconnectApp(app)"
              >
                Disconnect
              </el-button>
            </template>
            <el-button
              size="small"
              type="primary"
              :disabled="!app.configured"
              :loading="connecting === app.slug"
              v-if="!app.connected && app.connection_method !== 'feishu_cli'"
              @click="connectApp(app)"
            >
              {{
                app.connection_status === 'EXPIRED' || app.connection_status === 'FAILED'
                  ? 'Reconnect'
                  : 'Connect'
              }}
            </el-button>
            <el-button
              v-if="app.has_account && !app.connected && app.connection_method !== 'feishu_cli'"
              size="small"
              plain
              :loading="disconnecting === app.slug"
              @click="disconnectApp(app)"
            >
              Disconnect
            </el-button>
          </div>
        </article>
      </div>
      <FeishuBotSettings v-if="configuringFeishu && active" :key="accountKey" @changed="loadApps" />
    </template>
    <div v-else class="login-required">
      <p>Sign in to connect apps to your workspace.</p>
      <el-button type="primary" @click="router.push('/login')">Sign in</el-button>
    </div>

    <template v-if="authStore.isLoggedIn && authStore.isAdmin">
      <el-button class="provider-settings-toggle" size="small" @click="configuring = !configuring">
        {{ configuring ? 'Hide provider settings' : 'Configure connection provider' }}
      </el-button>
      <ConnectedAppProviderSettings v-if="configuring" @saved="loadApps" />
    </template>
    <p class="connection-note">
      Connected accounts are available to Chat Agent. Actions use the permissions granted during
      authorization. Disconnect an app to remove access.
    </p>
    <p v-if="apps.some(app => app.slug === 'gmail' && app.connected)" class="connection-note">
      Gmail works from the AI Assistant on every page. Ask it to read unread messages, draft an email,
      or send a message to a specified recipient. Sending requires an explicit request and Gmail permissions.
    </p>
  </section>
</template>

<script setup>
import { computed, ref, watch, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Loading, Refresh, Search } from '@element-plus/icons-vue'
import { useAuthStore } from '../stores/auth.js'
import ConnectedAppProviderSettings from './ConnectedAppProviderSettings.vue'
import FeishuBotSettings from './FeishuBotSettings.vue'
import {
  createConnectedAppLink,
  disconnectConnectedApp,
  getConnectedApps,
} from '../api/connectedApps.js'

const props = defineProps({
  active: { type: Boolean, default: true },
  returnPath: { type: String, default: '/' },
})
const emit = defineEmits(['use-app'])

const router = useRouter()
const authStore = useAuthStore()
const apps = ref([])
const loading = ref(false)
const providerConfigured = ref(false)
const providerWarning = ref('')
const error = ref('')
const search = ref('')
const activeFilter = ref('all')
const connecting = ref('')
const disconnecting = ref('')
const configuring = ref(false)
const configuringFeishu = ref(false)
let requestVersion = 0
let pendingRefresh = null
let disposed = false
const accountKey = computed(() =>
  authStore.isLoggedIn ? String(authStore.user?.id || authStore.user?.email || 'signed-in') : ''
)
const filters = [
  { label: 'All', value: 'all' },
  { label: 'Connected', value: 'connected' },
  { label: 'Not connected', value: 'not-connected' },
]

const connectedCount = computed(() => apps.value.filter(app => app.connected).length)
const filteredApps = computed(() => {
  const query = search.value.trim().toLowerCase()
  return apps.value.filter(app => {
    const matchesQuery =
      !query ||
      app.name.toLowerCase().includes(query) ||
      app.description.toLowerCase().includes(query)
    const matchesFilter =
      activeFilter.value === 'all' ||
      (activeFilter.value === 'connected' && app.connected) ||
      (activeFilter.value === 'not-connected' && !app.connected)
    return matchesQuery && matchesFilter
  })
})

watch([() => props.active, accountKey], () => {
  requestVersion += 1
  loading.value = false
  apps.value = []
  providerConfigured.value = false
  providerWarning.value = ''
  error.value = ''
  configuring.value = false
  configuringFeishu.value = false
  connecting.value = ''
  disconnecting.value = ''
  clearTimeout(pendingRefresh)
  if (props.active && accountKey.value) void loadApps()
})

onMounted(() => {
  void loadApps()
  globalThis.addEventListener('focus', refreshOnFocus)
})
onBeforeUnmount(() => {
  disposed = true
  requestVersion += 1
  clearTimeout(pendingRefresh)
  globalThis.removeEventListener('focus', refreshOnFocus)
})
function refreshOnFocus() {
  if (props.active) void loadApps()
}

async function loadApps() {
  if (!props.active || !accountKey.value || loading.value) return
  const version = ++requestVersion
  loading.value = true
  error.value = ''
  clearTimeout(pendingRefresh)
  try {
    const response = await getConnectedApps()
    if (version !== requestVersion) return
    apps.value = Array.isArray(response?.apps) ? response.apps : []
    providerConfigured.value = Boolean(response?.provider?.configured)
    providerWarning.value = response?.warning || ''
    if (apps.value.some(app => app.connection_status === 'INITIATED')) {
      pendingRefresh = setTimeout(loadApps, 5000)
    }
  } catch (loadError) {
    if (version === requestVersion)
      error.value = loadError.message || 'Could not load app connections.'
  } finally {
    if (version === requestVersion) loading.value = false
  }
}

async function connectApp(app) {
  const account = accountKey.value
  connecting.value = app.slug
  error.value = ''
  try {
    const response = await createConnectedAppLink(app.slug, props.returnPath)
    if (disposed || !props.active || accountKey.value !== account) return
    globalThis.location.assign(response.redirect_url)
  } catch (connectError) {
    error.value = connectError.message || 'Could not start app authorization.'
    connecting.value = ''
  }
}

async function disconnectApp(app) {
  const account = accountKey.value
  try {
    await ElMessageBox.confirm(
      `Revoke the ${app.name} authorization for this workspace?`,
      'Disconnect app',
      { confirmButtonText: 'Disconnect', cancelButtonText: 'Cancel', type: 'warning' }
    )
  } catch {
    return
  }
  if (disposed || !props.active || accountKey.value !== account) return
  disconnecting.value = app.slug
  error.value = ''
  try {
    await disconnectConnectedApp(app.slug)
    ElMessage.success(`${app.name} disconnected.`)
    await loadApps()
  } catch (disconnectError) {
    error.value = disconnectError.message || 'Could not disconnect this app.'
  } finally {
    disconnecting.value = ''
  }
}

function appMark(app) {
  const marks = {
    github: 'GH',
    notion: 'N',
    gmail: 'M',
    slack: 'S',
    telegram: 'TG',
    'google-drive': 'D',
    outlook: 'O',
    'google-calendar': '31',
    jira: 'J',
    bitbucket: 'B',
    linear: 'L',
    discord: 'D',
    feishu: 'FS',
  }
  return marks[app.slug] || app.name.slice(0, 2).toUpperCase()
}

function stateLabel(app) {
  if (app.connection_status === 'ACTIVE') return 'Connected'
  if (app.connection_status === 'INITIATED') return 'Authorization pending'
  if (app.connection_status === 'EXPIRED' || app.connection_status === 'FAILED')
    return 'Reconnect required'
  if (!app.has_account) return app.configured ? 'Not connected' : 'Unavailable'
  return app.connection_status.replaceAll('_', ' ').toLowerCase()
}

function stateClass(app) {
  if (app.connection_status === 'ACTIVE') return 'state-active'
  if (app.connection_status === 'INITIATED') return 'state-pending'
  if (app.has_account) return 'state-warning'
  return 'state-muted'
}
</script>

<style scoped>
.dialog-heading {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}
.dialog-heading h2 {
  margin: 0;
  color: #20242b;
  font-size: 24px;
  font-weight: 650;
}
.dialog-heading p {
  margin: 7px 0 0;
  color: #697386;
  font-size: 14px;
  line-height: 1.5;
}
.refresh-button {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border: 1px solid #dce1e8;
  border-radius: 7px;
  background: #fff;
  color: #566174;
  cursor: pointer;
}
.refresh-button:hover {
  color: #1769e0;
  border-color: #9bbcf0;
}
.refresh-button:disabled {
  cursor: default;
  opacity: 0.55;
}
.app-search {
  margin-bottom: 16px;
}
.app-search :deep(.el-input__wrapper) {
  min-height: 44px;
  border-radius: 7px;
  box-shadow: 0 0 0 1px #dce1e8 inset;
}
.app-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
}
.filter-group {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
}
.filter-button {
  min-height: 34px;
  padding: 0 13px;
  border: 1px solid #dce1e8;
  border-radius: 18px;
  background: #fff;
  color: #586273;
  font-size: 13px;
  cursor: pointer;
}
.filter-button:hover {
  border-color: #9bbcf0;
}
.filter-button.active {
  border-color: #d9e7ff;
  background: #eaf2ff;
  color: #145ed1;
}
.app-count {
  flex: none;
  color: #818b99;
  font-size: 12px;
}
.connection-alert {
  margin: 0 0 16px;
}
.login-required {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  min-height: 160px;
  color: #5f6978;
}
.login-required p {
  margin: 0;
  font-size: 14px;
}
.apps-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 360px), 1fr));
  gap: 12px;
  max-height: min(52vh, 540px);
  overflow-y: auto;
  padding: 1px 5px 4px 1px;
}
.app-card {
  display: grid;
  grid-template-columns: 48px minmax(0, 1fr) auto;
  align-items: start;
  gap: 12px;
  min-height: 126px;
  padding: 17px;
  border: 1px solid #e2e6eb;
  border-radius: 8px;
  background: #fff;
}
.app-mark {
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
  border-radius: 11px;
  background: #f0f3f7;
  color: #3e4b60;
  font-size: 13px;
  font-weight: 700;
}
.mark-github {
  background: #24292f;
  color: #fff;
}
.mark-notion {
  background: #f5f5f4;
  color: #151515;
  font-family: Georgia, serif;
  font-size: 22px;
}
.mark-gmail {
  background: #fff0ef;
  color: #db4437;
}
.mark-slack {
  background: #f3ecfa;
  color: #6b3fa0;
}
.mark-telegram {
  background: #e8f5fb;
  color: #2189bd;
}
.mark-google-drive,
.mark-discord {
  background: #e8f0ff;
  color: #3574dc;
}
.mark-outlook,
.mark-google-calendar {
  background: #eaf4ff;
  color: #1769cc;
}
.mark-jira {
  background: #e9f0ff;
  color: #205bc4;
}
.mark-bitbucket {
  background: #eaf4ff;
  color: #1466c3;
}
.mark-linear {
  background: #f0edff;
  color: #654ad4;
}
.app-copy {
  min-width: 0;
}
.app-name-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 6px 12px;
}
.app-name-row h3 {
  overflow-wrap: anywhere;
  margin: 1px 0 0;
  color: #20242b;
  font-size: 16px;
  font-weight: 650;
}
.app-copy p {
  margin: 9px 0 0;
  color: #6c7685;
  font-size: 13px;
  line-height: 1.5;
}
.connection-state {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: #687384;
  font-size: 11px;
  white-space: nowrap;
}
.state-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #9ba4b1;
}
.state-active {
  color: #218356;
}
.state-active .state-dot {
  background: #2ca36b;
}
.state-pending {
  color: #a87318;
}
.state-pending .state-dot {
  background: #d59b38;
}
.state-warning {
  color: #b45b35;
}
.state-warning .state-dot {
  background: #d57448;
}
.state-muted {
  color: #7a8491;
}
.app-actions {
  display: flex;
  justify-content: flex-end;
}
.dialog-state {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 9px;
  min-height: 140px;
  color: #748091;
  font-size: 14px;
}
.connection-note {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  color: #87909c;
  font-size: 12px;
}
.spinning {
  animation: spin 1s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@media (max-width: 700px) {
  .dialog-heading h2 {
    font-size: 21px;
  }
  .apps-grid {
    grid-template-columns: 1fr;
    max-height: 48vh;
  }
  .app-card {
    grid-template-columns: 42px minmax(0, 1fr);
    min-height: 0;
    padding: 14px;
  }
  .app-mark {
    width: 40px;
    height: 40px;
  }
  .app-actions {
    grid-column: 2;
  }
  .connection-note {
    align-items: flex-start;
  }
}
.provider-settings-toggle {
  margin-bottom: 14px;
}
.connection-note {
  margin-top: 14px;
  line-height: 1.5;
}
.dialog-heading h2 {
  font-size: 20px;
}
</style>
