<template>
  <section class="feishu-settings" aria-label="Feishu bot settings">
    <div class="settings-heading">
      <div>
        <h3>Feishu Bot</h3>
        <p>Use Chat Agent directly in your bot's private chat.</p>
      </div>
      <el-tag>{{ configuration.runtime?.status || 'Loading' }}</el-tag>
    </div>
    <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
    <el-alert
      v-if="configuration.runtime?.error"
      :title="configuration.runtime.error"
      type="warning"
      :closable="false"
      show-icon
    />
    <el-alert
      v-if="configuration.runtime && !configuration.runtime.cli_available"
      title="The official Feishu CLI must be installed on this server."
      type="warning"
      :closable="false"
    />
    <p v-if="notice" class="notice" role="status">{{ notice }}</p>
    <el-form
      label-position="top"
      :disabled="Boolean(pending) || locked || loading"
      @submit.prevent="save"
    >
      <div class="field-grid">
        <el-form-item label="Platform">
          <el-select v-model="form.brand" aria-label="Platform"
            ><el-option label="Feishu" value="feishu" /><el-option label="Lark" value="lark"
          /></el-select>
        </el-form-item>
        <el-form-item label="App ID"
          ><el-input
            v-model="form.app_id"
            placeholder="cli_..."
            aria-label="App ID"
            autocomplete="off"
        /></el-form-item>
      </div>
      <el-form-item label="App Secret">
        <el-input
          v-model="form.app_secret"
          type="password"
          show-password
          autocomplete="new-password"
          :placeholder="
            configuration.app_secret_configured
              ? 'Leave blank to keep the saved secret'
              : 'Enter the bot App Secret'
          "
          aria-label="App Secret"
        />
      </el-form-item>
      <el-form-item label="Authorized sender open_ids">
        <el-input
          v-model="form.senders"
          type="textarea"
          :rows="2"
          placeholder="ou_... (one per line)"
          aria-label="Authorized sender open_ids"
        />
      </el-form-item>
      <p class="help">
        Only listed users can use this bot. Their requests use your platform account, connected
        apps, and balance. Add only trusted users, preferably your own open_id.
      </p>
      <el-button native-type="submit" type="primary" :loading="pending === 'save'"
        >Save configuration</el-button
      >
    </el-form>
    <div class="actions">
      <el-button
        :disabled="!configuration.configured || dirty || Boolean(pending) || loading"
        :loading="pending === 'check'"
        @click="act('check', checkFeishuConnection)"
        >Check connection</el-button
      >
      <el-button
        v-if="!locked"
        type="primary"
        :disabled="
          !configuration.verified_at ||
          dirty ||
          !configuration.runtime?.cli_available ||
          Boolean(pending) ||
          loading
        "
        :loading="pending === 'start'"
        @click="act('start', startFeishuListener)"
        >Start listening</el-button
      >
      <el-button
        v-else
        :disabled="Boolean(pending) || configuration.runtime?.status === 'stopping'"
        :loading="pending === 'stop'"
        @click="act('stop', stopFeishuListener)"
        >Stop listening</el-button
      >
      <el-button
        :disabled="locked || !configuration.configured || Boolean(pending) || loading"
        :loading="pending === 'disconnect'"
        @click="act('disconnect', disconnectFeishu)"
        >Disconnect</el-button
      >
    </div>
    <p class="help">
      Save changes before checking or starting. Connection checks verify bot identity without
      sending messages. Stopping waits for an active Agent request to finish.
    </p>
    <details>
      <summary>Bot setup and supported messages</summary>
      <ol>
        <li>
          Create an internal app in the
          <a
            :href="
              form.brand === 'lark'
                ? 'https://open.larksuite.com/app'
                : 'https://open.feishu.cn/app'
            "
            target="_blank"
            rel="noopener noreferrer"
            >developer console</a
          >
          and enable its Bot capability.
        </li>
        <li>
          Enable long connection event delivery and subscribe to <code>im.message.receive_v1</code>.
          Grant permission to receive private messages and send messages as the bot, then publish
          the app.
        </li>
        <li>
          Save your credentials and authorized sender open_ids here, check the connection, and start
          listening. Open the bot in Feishu and send a private text message.
        </li>
      </ol>
      <p>
        Private text messages are supported. Group messages, files, and bot messages are ignored.
        Each sender has separate conversation history. Repeated event deliveries do not rerun Agent
        work. Failed or uncertain replies are not automatically retried.
      </p>
      <a href="https://github.com/larksuite/cli" target="_blank" rel="noopener noreferrer"
        >Official CLI documentation</a
      >
    </details>
    <div v-if="configuration.recent_messages?.length" class="recent-messages">
      <h4>Recent message outcomes</h4>
      <ul>
        <li v-for="item in configuration.recent_messages" :key="item.id">
          <strong>{{ item.status }}</strong> · {{ item.created_at
          }}<span v-if="item.error"> — {{ item.error }}</span>
        </li>
      </ul>
    </div>
  </section>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import {
  getFeishuConfiguration,
  saveFeishuConfiguration,
  checkFeishuConnection,
  startFeishuListener,
  stopFeishuListener,
  disconnectFeishu,
} from '../api/feishu.js'

const emit = defineEmits(['changed'])
const auth = useAuthStore()
const account = String(auth.user?.id || auth.user?.email || '')
const configuration = ref({})
const form = reactive({ app_id: '', app_secret: '', brand: 'feishu', senders: '' })
const pending = ref('')
const loading = ref(true)
const error = ref('')
const notice = ref('')
let disposed = false
let timer
let revision = 0
const current = () =>
  !disposed && auth.isLoggedIn && String(auth.user?.id || auth.user?.email || '') === account
const locked = computed(
  () =>
    configuration.value.enabled ||
    ['starting', 'listening', 'stopping', 'active_elsewhere'].includes(
      configuration.value.runtime?.status
    )
)
const senderIds = () => [...new Set(form.senders.split(/[\s,]+/).filter(Boolean))].sort()
const dirty = computed(
  () =>
    Boolean(form.app_secret) ||
    form.app_id !== (configuration.value.app_id || '') ||
    form.brand !== (configuration.value.brand || 'feishu') ||
    JSON.stringify(senderIds()) !==
      JSON.stringify([...(configuration.value.allowed_sender_ids || [])].sort())
)
function populate() {
  form.app_id = configuration.value.app_id || ''
  form.brand = configuration.value.brand || 'feishu'
  form.senders = (configuration.value.allowed_sender_ids || []).join('\n')
  form.app_secret = ''
}
async function refresh(reset = false) {
  const request = ++revision
  const valid = () => current() && request === revision
  clearTimeout(timer)
  try {
    const result = await getFeishuConfiguration()
    if (!valid()) return
    configuration.value = result
    if (reset) populate()
  } catch (failure) {
    if (valid()) error.value = failure.message || 'Could not load Feishu settings.'
  } finally {
    if (valid()) {
      loading.value = false
      if (locked.value) timer = setTimeout(() => refresh(), 4000)
    }
  }
}
async function act(name, operation) {
  if (pending.value || !current()) return
  clearTimeout(timer)
  revision += 1
  pending.value = name
  error.value = ''
  notice.value = ''
  try {
    const result = await operation()
    if (!current()) return
    notice.value =
      result?.message ||
      {
        save: 'Configuration saved.',
        start: 'Listener started.',
        stop: 'Stop requested. Active work will finish.',
        disconnect: 'Bot disconnected.',
      }[name] ||
      ''
    await refresh(true)
    if (current()) emit('changed')
  } catch (failure) {
    if (current()) {
      error.value = failure.message || 'The Feishu operation failed.'
      await refresh()
    }
  } finally {
    if (name === 'save') form.app_secret = ''
    if (current()) pending.value = ''
  }
}
function save() {
  return act('save', () =>
    saveFeishuConfiguration({
      app_id: form.app_id.trim(),
      brand: form.brand,
      allowed_sender_ids: senderIds(),
      ...(form.app_secret ? { app_secret: form.app_secret } : {}),
    })
  )
}
onMounted(() => refresh(true))
onBeforeUnmount(() => {
  disposed = true
  clearTimeout(timer)
  form.app_secret = ''
})
</script>

<style scoped>
.feishu-settings {
  margin-top: 18px;
  padding: 20px;
  border: 1px solid #dce5ef;
  border-radius: 10px;
  background: #f8faff;
}
.settings-heading {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 16px;
}
h3,
h4 {
  margin: 0 0 8px;
}
.settings-heading p,
.help,
details,
.recent-messages {
  font-size: 13px;
  line-height: 1.6;
  color: #596579;
}
.settings-heading p {
  margin: 0;
}
.field-grid {
  display: grid;
  grid-template-columns: 1fr 2fr;
  gap: 16px;
}
.actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 18px 0 8px;
}
.actions :deep(.el-button) {
  margin-left: 0;
}
.el-alert {
  margin-bottom: 12px;
}
.notice {
  color: #24704a;
  font-size: 13px;
}
summary {
  cursor: pointer;
  font-weight: 600;
}
li {
  margin-bottom: 7px;
  overflow-wrap: anywhere;
}
a {
  color: #2262bf;
}
.recent-messages {
  margin-top: 20px;
}
@media (max-width: 600px) {
  .field-grid {
    grid-template-columns: 1fr;
    gap: 0;
  }
  .feishu-settings {
    padding: 14px;
  }
}
</style>
