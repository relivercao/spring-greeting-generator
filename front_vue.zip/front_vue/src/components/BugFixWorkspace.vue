<template>
  <div class="bugfix-mode-workspace">
    <nav class="bugfix-mode-tabs" aria-label="Bug fix mode">
      <button type="button" :aria-pressed="mode === 'single'" :disabled="batchBusy" @click="mode = 'single'">Single Bug Fix</button>
      <button type="button" :aria-pressed="mode === 'batch'" :disabled="phase === 'running'" @click="mode = 'batch'">Batch Bug Fix</button>
    </nav>
    <BatchBugFixWorkspace v-if="mode === 'batch'" @busy="batchBusy = $event" />
  <div v-else class="bugfix-workspace">
    <header class="bugfix-topbar">
      <div class="bugfix-topbar-main">
        <div class="bugfix-agent-icon">
          <el-icon size="15">
            <Tools />
          </el-icon>
        </div>
        <div class="bugfix-topbar-copy">
          <span class="bugfix-topbar-title">Bug Fix</span>
          <span class="bugfix-topbar-desc">Trace a Jira issue to a validated repair proposal</span>
        </div>
      </div>
      <div class="bugfix-topbar-status">
        <span
          class="topbar-connection"
          :class="connectionClass(integrations.jira)"
        >
          <span class="state-dot" />Jira {{ connectionLabel(integrations.jira) }}
        </span>
        <span
          class="topbar-connection"
          :class="connectionClass(integrations.bitbucket)"
        >
          <span class="state-dot" />Bitbucket {{ connectionLabel(integrations.bitbucket) }}
        </span>
        <span
          class="topbar-ready"
          :class="{ ready: canRun }"
        >
          {{ canRun ? 'Ready' : 'Needs input' }}
        </span>
      </div>
    </header>
    <div class="left-column">
      <nav
        class="input-stepper"
        aria-label="Bug fix steps"
      >
        <div
          v-for="step in inputSteps"
          :key="step.number"
          class="input-step"
          :class="stepState(step.number)"
        >
          <span class="input-step-number">
            <el-icon
              v-if="inputStep > step.number"
              size="12"
            ><CircleCheck /></el-icon>
            <span v-else>{{ step.number }}</span>
          </span>
          <span class="input-step-copy">
            <strong>{{ step.title }}</strong>
            <small>{{ step.caption }}</small>
          </span>
        </div>
      </nav>
      <div
        class="config-section"
        aria-label="Bug fix configuration"
      >
        <BugFixJiraSource
          :integration="integrations.jira"
          :disabled="phase === 'running'"
          @selected="selectedIssue = $event"
        />
        <section class="input-section">
          <div class="input-section-header">
            <div>
              <p class="eyebrow eyebrow-emerald">
                Bitbucket Source
              </p>
              <h3>Choose the code to investigate and fix</h3>
            </div>
            <span
              class="connection-state"
              :class="connectionClass(integrations.bitbucket)"
            ><span class="state-dot" />{{ connectionLabel(integrations.bitbucket) }}</span>
          </div>
          <div class="input-section-body">
            <label
              class="input-label"
              for="bugfix-repo"
            >Repository slug</label>
            <input
              id="bugfix-repo"
              v-model.trim="repo"
              class="text-input"
              placeholder="firmware"
              :disabled="phase === 'running'"
            >
            <label
              class="input-label"
              for="bugfix-branch"
            >Branch or commit</label>
            <input
              id="bugfix-branch"
              v-model.trim="branch"
              class="text-input"
              placeholder="main"
              :disabled="phase === 'running'"
            >
            <label
              class="input-label"
              for="bugfix-paths"
            >Source file paths</label>
            <textarea
              id="bugfix-paths"
              v-model="sourcePathsText"
              class="text-area paths-area"
              placeholder="src/driver.c&#10;include/driver.h"
              rows="3"
              :disabled="phase === 'running'"
            />
            <div class="field-hint">
              One repository-relative path per line. The selected Jira Bug supplies the problem details.
            </div>
          </div>
        </section>
      </div>
      <div class="prompt-section">
        <DriverChatPanel
          v-model:input="bugDescription"
          :phase="phase"
          title="Additional Context (Optional)"
          placeholder="Add reproduction details, logs, or repair constraints to supplement the selected Jira Bug..."
          hint="The Jira ticket is the task source. Press Ctrl+Enter to generate a fix."
          @enter="runBugFix"
        />
      </div>
      <div
        v-if="!authStore.isLoggedIn"
        class="field-error"
        role="status"
      >
        Sign in to run BugFix and access connected repositories.
      </div>
      <div
        v-if="formError"
        class="field-error"
        role="alert"
      >
        {{ formError }}
      </div>
      <div
        class="readiness-bar"
        :class="{ ready: canRun && phase !== 'running', running: phase === 'running' }"
        role="status"
        aria-live="polite"
      >
        <div class="readiness-icon">
          <el-icon size="14">
            <CircleCheck v-if="canRun && phase !== 'running'" /><Cpu v-else-if="phase === 'running'" /><WarningFilled v-else />
          </el-icon>
        </div>
        <div class="readiness-copy">
          <strong>{{ phase === 'running' ? 'Task running' : canRun ? 'Ready to generate' : 'Complete the required inputs' }}</strong>
          <span v-if="phase === 'running'">{{ progressMessage || stageLabel }}</span>
          <span v-else-if="canRun">{{ sourceFiles.length }} source file{{ sourceFiles.length === 1 ? '' : 's' }} selected for {{ issueId }}.</span>
          <span v-else>{{ missingInputsText }}</span>
        </div>
      </div>
      <button
        type="button"
        class="generate-btn"
        :disabled="!canRun || phase === 'running'"
        @click="runBugFix"
      >
        <el-icon
          v-if="phase !== 'running'"
          size="15"
        >
          <Cpu />
        </el-icon><span
          v-else
          class="spinner"
        />
        {{ phase === 'running' ? 'Generating...' : 'Generate Bug Fix' }}
      </button>
    </div>
    <section
      class="right-column"
      aria-label="Bug fix results"
      aria-live="polite"
    >
      <div
        v-if="phase === 'idle' && !result && !errorMessage"
        class="guide-area"
      >
        <div class="guide-icon">
          <el-icon size="32">
            <Tools />
          </el-icon>
        </div>
        <h3 class="guide-title">
          {{ agent?.name || 'BugFix Agent' }}
        </h3>
        <p class="guide-sub">
          Select a Jira Bug and configure its source to generate a root cause analysis and repair proposal.
        </p>
        <div
          class="guide-integrations"
          aria-label="Integration status"
        >
          <span
            class="guide-integration"
            :class="connectionClass(integrations.jira)"
          ><span class="state-dot" />Jira {{ connectionLabel(integrations.jira) }}</span>
          <span
            class="guide-integration"
            :class="connectionClass(integrations.bitbucket)"
          ><span class="state-dot" />Bitbucket {{ connectionLabel(integrations.bitbucket) }}</span>
        </div>
        <div class="guide-steps">
          <div class="guide-step">
            <span class="step-num">1</span><span class="step-text">Load a Jira project or Bug ticket</span>
          </div>
          <div class="guide-step">
            <span class="step-num">2</span><span class="step-text">Select Bitbucket source and add context</span>
          </div>
          <div class="guide-step">
            <span class="step-num">3</span><span class="step-text">Generate and review the proposed fix</span>
          </div>
        </div>
      </div>
      <div
        v-else-if="phase === 'running'"
        class="loading-area"
      >
        <button
          type="button"
          class="cancel-btn-top-right"
          :disabled="isCancelling"
          @click="cancelTask"
        >
          <el-icon size="13">
            <Close />
          </el-icon>{{ isCancelling ? 'Cancelling...' : 'Cancel Task' }}
        </button>
        <DriverWorkflowProgress
          title="Bug Fix Generation"
          :description="progressMessage || stageLabel"
          :progress="progress"
          :steps="workflowSteps"
          token-status="unavailable"
        />
        <div class="task-reference">
          Task {{ currentTaskId }}
        </div>
      </div>
      <div
        v-else-if="errorMessage"
        class="error-area"
        role="alert"
      >
        <DriverWorkflowProgress
          v-if="workflowNodes.length"
          title="Bug Fix Workflow"
          :description="progressMessage || errorMessage"
          :progress="progress"
          :steps="workflowSteps"
          token-status="unavailable"
          :show-token-usage="false"
        />
        <el-icon size="32">
          <WarningFilled />
        </el-icon>
        <h3>Bug fix task stopped</h3><p>{{ errorMessage }}</p>
        <button
          type="button"
          class="quiet-button"
          @click="resetResult"
        >
          <el-icon><RefreshLeft /></el-icon>Back to inputs
        </button>
      </div>
      <BugFixResultReport
        v-else-if="result"
        :result="result"
        @reset="resetResult"
      />
    </section>
  </div>
  </div>
</template>

<script setup>
import BugFixJiraSource from './bugfix-workspace/BugFixJiraSource.vue'
import BatchBugFixWorkspace from './BatchBugFixWorkspace.vue'
import BugFixResultReport from './bugfix-workspace/BugFixResultReport.vue'
import DriverChatPanel from './driver-workspace/DriverChatPanel.vue'
import DriverWorkflowProgress from './driver-workspace/DriverWorkflowProgress.vue'
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { CircleCheck, Close, Cpu, RefreshLeft, Tools, WarningFilled } from '@element-plus/icons-vue'
import {
  apiCancelBugFixTask,
  apiCreateBugFixTask,
  apiPollBugFixTask,
  getBugFixIntegrations,
} from '../api/bugfix.js'

defineProps({ agent: { type: Object, default: null } })

const mode = ref('single')
const batchBusy = ref(false)

const selectedIssue = ref(null)
const issueId = computed(() => selectedIssue.value?.key || '')
const bugDescription = ref('')
const repo = ref('')
const branch = ref('main')
const sourcePathsText = ref('')
const integrations = ref({ jira: null, bitbucket: null })
const phase = ref('idle')
const progress = ref(0)
const progressMessage = ref('')
const workflowNodes = ref([])
const currentTaskId = ref('')
const result = ref(null)
const errorMessage = ref('')
const formError = ref('')
const isCancelling = ref(false)
let stopPolling = null
let resolveTask = null
const authStore = useAuthStore()
const mountedAccount = accountIdentity(authStore)
let disposed = false

function isCurrentAccount() {
  return !disposed && mountedAccount === accountIdentity(authStore)
}

function invalidateWorkspace() {
  disposed = true
  stopPolling?.()
  stopPolling = null
  resolveTask?.(null)
  resolveTask = null
}

watch(() => accountIdentity(authStore), invalidateWorkspace, { flush: 'sync' })

const sourceFiles = computed(() =>
  sourcePathsText.value
    .split(/[\n,]+/)
    .map(path => path.trim())
    .filter(Boolean)
)
const inputSteps = [
  { number: 1, title: 'Jira issue', caption: 'Select a ticket' },
  { number: 2, title: 'Source context', caption: 'Choose repository files' },
  { number: 3, title: 'Review & run', caption: 'Add context and start' },
]
const inputStep = computed(() => {
  if (!issueId.value) return 1
  if (!repo.value.trim() || !branch.value.trim() || !sourceFiles.value.length) return 2
  return 3
})
const missingInputs = computed(() => [
  !authStore.isLoggedIn && 'Sign in',
  !issueId.value && 'Jira issue',
  !repo.value.trim() && 'repository',
  !branch.value.trim() && 'branch',
  !sourceFiles.value.length && 'source path',
].filter(Boolean))
const missingInputsText = computed(() => missingInputs.value.join(' · '))
const canRun = computed(() =>
  Boolean(
    authStore.isLoggedIn &&
    issueId.value &&
    repo.value &&
    branch.value &&
    sourceFiles.value.length
  )
)
const stageLabel = computed(() => {
  if (progress.value < 20) return 'Retrieving Jira issue context'
  if (progress.value < 40) return 'Reading Bitbucket source files'
  if (progress.value < 50) return 'Analyzing root cause'
  if (progress.value < 65) return 'Reviewing module expert findings'
  if (progress.value < 90) return 'Generating and checking patch'
  return 'Preparing report'
})

onMounted(async () => {
  try {
    const loaded = await getBugFixIntegrations()
    if (isCurrentAccount()) integrations.value = loaded
  } catch {
    if (isCurrentAccount()) integrations.value = { jira: { available: false }, bitbucket: { available: false } }
  }
})

onBeforeUnmount(invalidateWorkspace)

function connectionLabel(integration) {
  if (!integration) return 'Checking'
  return integration.available ? 'Configured' : 'Not configured'
}

function connectionClass(integration) {
  return {
    unavailable: integration?.available === false,
    checking: !integration,
  }
}

function stepState(number) {
  return {
    complete: inputStep.value > number,
    active: inputStep.value === number,
  }
}


function updateTask(data) {
  if (!isCurrentAccount()) return
  if (Number.isFinite(data.progress)) progress.value = data.progress
  if (data.message) progressMessage.value = data.message
  if (Array.isArray(data.workflow_nodes)) workflowNodes.value = data.workflow_nodes
  if (['completed', 'failed', 'cancelled'].includes(data.status)) {
    resolveTask?.(data)
    resolveTask = null
  }
}

async function runBugFix() {
  if (!isCurrentAccount() || phase.value === 'running') return
  formError.value = ''
  if (!authStore.isLoggedIn) {
    formError.value = 'Sign in to run BugFix and access connected repositories.'
    return
  }
  if (!canRun.value) {
    formError.value =
      'Load a Jira Bug, enter a repository and branch, and add at least one source path.'
    return
  }
  phase.value = 'running'
  progress.value = 2
  progressMessage.value = 'Creating bug fix task'
  workflowNodes.value = []
  result.value = null
  errorMessage.value = ''
  try {
    const created = await apiCreateBugFixTask({
      issue_id: issueId.value || null,
      bug_description: bugDescription.value,
      repo: repo.value,
      branch: branch.value,
      source_files: sourceFiles.value,
    })
    if (!isCurrentAccount()) return
    currentTaskId.value = created.task_id
    const final = await new Promise(resolve => {
      resolveTask = resolve
      stopPolling = apiPollBugFixTask(created.task_id, updateTask)
    })
    if (!isCurrentAccount()) return
    if (final.status === 'completed') {
      result.value = final.result || {}
      phase.value = 'done'
    } else {
      errorMessage.value = final.error || final.message || 'Bug fix task did not complete.'
      phase.value = 'error'
    }
  } catch (error) {
    if (!isCurrentAccount()) return
    errorMessage.value = error.message || 'Bug fix task could not be started.'
    phase.value = 'error'
  } finally {
    if (isCurrentAccount()) {
      stopPolling?.()
      stopPolling = null
      resolveTask = null
      currentTaskId.value = ''
      isCancelling.value = false
    }
  }
}

async function cancelTask() {
  if (!isCurrentAccount() || !currentTaskId.value || isCancelling.value) return
  const taskId = currentTaskId.value
  isCancelling.value = true
  try {
    const cancelled = await apiCancelBugFixTask(taskId)
    if (!isCurrentAccount() || currentTaskId.value !== taskId || phase.value !== 'running') return
    updateTask(cancelled)
    if (!['completed', 'failed', 'cancelled'].includes(cancelled.status)) {
      progressMessage.value = 'Cancellation is still processing. Continuing to monitor the task.'
    }
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== taskId || phase.value !== 'running') return
    progressMessage.value = `${error.message || 'Task cancellation failed.'} Continuing to monitor the task. You can retry cancellation.`
  } finally {
    if (isCurrentAccount() && currentTaskId.value === taskId) isCancelling.value = false
  }
}

function resetResult() {
  if (phase.value === 'running') return
  phase.value = 'idle'
  progress.value = 0
  progressMessage.value = ''
  workflowNodes.value = []
  result.value = null
  errorMessage.value = ''
  formError.value = ''
}


const workflowSteps = computed(() => {
  if (workflowNodes.value.length) {
    return workflowNodes.value.map(node => ({
      title: node.label || node.node_name,
      state: {
        completed: 'done',
        in_progress: 'active',
        failed: 'fail',
        cancelled: 'cancelled',
        skipped: 'skipped',
      }[node.status] || 'pending',
    }))
  }

  const stages = [
    { title: 'Bug Context', progress: 10 },
    { title: 'Read Source', progress: 20 },
    { title: 'Root Cause', progress: 40 },
    { title: 'Module Experts', progress: 50 },
    { title: 'Generate Patch', progress: 65 },
    { title: 'Validate', progress: 90 },
  ]
  return stages.map((stage, index) => ({
    title: stage.title,
    state: progress.value >= (stages[index + 1]?.progress ?? 100)
      ? 'done' : progress.value >= stage.progress || index === 0 ? 'active' : 'pending',
  }))
})
</script>

<style scoped src="./bugfix-workspace/bugfix-input.css"></style>
<style scoped>
.bugfix-mode-workspace { display: flex; flex-direction: column; flex: 1; height: 100%; min-height: 0; min-width: 0; }
.bugfix-mode-tabs { display: flex; gap: 6px; padding: 8px 12px 0; background: #f8fafc; }
.bugfix-mode-tabs button { padding: 8px 14px; border: 1px solid #e2e8f0; border-radius: 8px; background: white; color: #475569; font-family: inherit; font-size: 12px; font-weight: 600; cursor: pointer; }
.bugfix-mode-tabs button[aria-pressed="true"] { color: #1d4ed8; background: #eff6ff; border-color: #93c5fd; }
.bugfix-mode-tabs button:disabled { opacity: 0.5; cursor: not-allowed; }
* { box-sizing: border-box; }
.bugfix-workspace {
  height: 100%;
  flex: 1;
  min-width: 0;
  min-height: 0;
  display: grid;
  grid-template-columns: minmax(300px, 0.6fr) minmax(0, 1.4fr);
  grid-template-rows: auto minmax(0, 1fr);
  gap: 12px;
  padding: clamp(8px, 0.75vw, 12px);
  overflow: hidden;
  color: #1e293b;
  background:
    radial-gradient(ellipse 80% 60% at 10% 0%, rgba(99, 102, 241, 0.07) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 95% 100%, rgba(16, 185, 129, 0.05) 0%, transparent 50%),
    #f8fafc;
}

.bugfix-topbar {
  grid-column: 1 / -1;
  min-width: 0;
  min-height: 52px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 8px 12px;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.92);
  box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
}
.bugfix-topbar-main, .bugfix-topbar-status { display: flex; align-items: center; min-width: 0; }
.bugfix-topbar-main { gap: 9px; }
.bugfix-agent-icon {
  width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center;
  flex: 0 0 auto; border-radius: 8px; color: #1d4ed8; background: #dbeafe;
}
.bugfix-topbar-copy { display: flex; min-width: 0; flex-direction: column; gap: 2px; }
.bugfix-topbar-title { color: #172b4d; font-size: 14px; font-weight: 800; }
.bugfix-topbar-desc { overflow: hidden; color: #6b778c; font-size: 11px; text-overflow: ellipsis; white-space: nowrap; }
.bugfix-topbar-status { flex-wrap: wrap; justify-content: flex-end; gap: 6px; }
.topbar-connection, .topbar-ready {
  display: inline-flex; align-items: center; gap: 5px; min-height: 24px; padding: 3px 8px;
  border-radius: 999px; color: #047857; background: #ecfdf5; font-size: 10px; font-weight: 700; white-space: nowrap;
}
.topbar-connection.unavailable, .topbar-ready:not(.ready) { color: #946200; background: #fff7d6; }
.topbar-connection.checking { color: #64748b; background: #f1f5f9; }
.topbar-ready.ready { color: #1d4ed8; background: #dbeafe; }

.left-column {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: #cbd5e1 transparent;
}

.input-stepper {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 5px;
  padding: 2px;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  background: #ffffff;
}
.input-step {
  min-width: 0; display: flex; align-items: center; gap: 7px; padding: 7px 8px;
  border-radius: 7px; color: #6b778c; background: transparent;
}
.input-step.active { color: #1d4ed8; background: #eff6ff; }
.input-step.complete { color: #047857; background: #ecfdf5; }
.input-step-number {
  width: 21px; height: 21px; display: inline-flex; align-items: center; justify-content: center;
  flex: 0 0 auto; border-radius: 6px; color: #64748b; background: #f1f5f9; font-size: 10px; font-weight: 800;
}
.input-step.active .input-step-number { color: #ffffff; background: #2563eb; }
.input-step.complete .input-step-number { color: #ffffff; background: #059669; }
.input-step-copy { display: flex; min-width: 0; flex-direction: column; gap: 1px; }
.input-step-copy strong { overflow: hidden; font-size: 10px; font-weight: 800; text-overflow: ellipsis; white-space: nowrap; }
.input-step-copy small { overflow: hidden; color: #8492a6; font-size: 9px; text-overflow: ellipsis; white-space: nowrap; }


.config-section { display: flex; flex-direction: column; gap: 12px; }
.prompt-section { flex: 0 0 auto; min-height: 120px; display: flex; flex-direction: column; }
.paths-area { min-height: 78px; font-family: Consolas, monospace; }
.generate-btn {
  flex-shrink: 0;
  width: 100%;
  height: 44px;
  border: none;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #ffffff;
  background: #475569;
  box-shadow: 0 2px 6px rgba(71, 85, 105, 0.3);
  cursor: pointer;
  font-family: inherit;
  font-size: 14px;
  font-weight: 700;
  transition: all 0.2s ease;
}

.generate-btn:hover:not(:disabled) {
  background: #334155;
  box-shadow: 0 4px 10px rgba(71, 85, 105, 0.4);
  transform: translateY(-1px);
}

.generate-btn:active:not(:disabled) {
  transform: translateY(0);
}

.generate-btn:disabled {
  cursor: not-allowed;
  background: #94a3b8;
  opacity: 0.7;
  transform: none;
  box-shadow: 0 1px 3px rgba(148, 163, 184, 0.2);
}

.generate-btn.loading {
  background: #94a3b8;
  cursor: not-allowed;
  box-shadow: 0 1px 3px rgba(148, 163, 184, 0.2);
}

.readiness-bar {
  display: flex; align-items: center; gap: 8px; min-height: 42px; padding: 7px 10px;
  border: 1px solid #fde68a; border-radius: 8px; color: #92400e; background: #fffbeb;
}
.readiness-bar.ready { border-color: #bbf7d0; color: #047857; background: #f0fdf4; }
.readiness-bar.running { border-color: #bfdbfe; color: #1d4ed8; background: #eff6ff; }
.readiness-icon { display: inline-flex; flex: 0 0 auto; }
.readiness-copy { display: flex; min-width: 0; flex-direction: column; gap: 1px; }
.readiness-copy strong { font-size: 11px; font-weight: 800; }
.readiness-copy span { overflow: hidden; color: #64748b; font-size: 10px; line-height: 1.35; text-overflow: ellipsis; white-space: nowrap; }

.spinner {
  width: 16px;
  height: 16px;
  display: inline-block;
  border-radius: 50%;
  border: 2px solid currentColor;
  border-right-color: transparent;
  animation: spin-btn 0.75s linear infinite;
}

@keyframes spin-btn {
  to { transform: rotate(360deg); }
}

.cancel-btn-top-right {
  position: absolute;
  top: 20px;
  right: 20px;
  height: 36px;
  min-width: 118px;
  padding: 0 16px;
  border: 1.5px solid #ef4444;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  color: #ef4444;
  background: #ffffff;
  box-shadow: 0 2px 4px rgba(239, 68, 68, 0.15);
  cursor: pointer;
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  transition: all 0.2s ease;
  white-space: nowrap;
  z-index: 10;
}

.cancel-btn-top-right:hover {
  background: #fef2f2;
  border-color: #dc2626;
  color: #dc2626;
  box-shadow: 0 4px 8px rgba(239, 68, 68, 0.25);
  transform: translateY(-1px);
}

.cancel-btn-top-right:disabled,
.cancel-btn-top-right.loading {
  cursor: not-allowed;
  opacity: 0.7;
  transform: none;
  box-shadow: 0 2px 4px rgba(239, 68, 68, 0.15);
}

.cancel-btn-top-right:active {
  transform: translateY(0);
  box-shadow: 0 2px 4px rgba(239, 68, 68, 0.15);
}

.right-column {
  display: flex;
  flex-direction: column;
  min-height: 0;
  overflow: hidden;
}

.guide-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: white;
  border: 1px solid #e8ecf1;
  border-radius: 14px;
  padding: 32px 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  overflow-y: auto;
}

.result-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0;
  overflow-y: auto;
}

.guide-icon {
  width: 64px;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #e0e7ff, #ddd6fe);
  border-radius: 16px;
  margin-bottom: 16px;
}

.guide-title {
  font-size: 18px;
  font-weight: 700;
  color: #0f172a;
  margin-bottom: 8px;
}

.guide-sub {
  font-size: 13px;
  color: #64748b;
  text-align: center;
  margin-bottom: 24px;
  max-width: 320px;
}

.guide-steps {
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: 100%;
  max-width: 380px;
}

.guide-step {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
}

.step-num {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #6366f1;
  color: white;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 700;
  flex-shrink: 0;
}

.step-text {
  font-size: 13px;
  color: #475569;
}

.loading-area {
  position: relative;  /* Required for .cancel-btn-top-right absolute positioning */
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  background: white;
  border: 1px solid #e8ecf1;
  border-radius: 14px;
  padding: 56px 24px 32px 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  overflow-y: auto;
}


.guide-title { margin: 0 0 8px; }
.guide-sub { margin: 0 0 24px; line-height: 1.6; }
.guide-integrations { display: flex; flex-wrap: wrap; justify-content: center; gap: 6px; margin: 0 0 20px; }
.guide-integration {
  display: inline-flex; align-items: center; gap: 5px; padding: 5px 8px; border-radius: 999px;
  color: #047857; background: #ecfdf5; font-size: 10px; font-weight: 700;
}
.guide-integration.unavailable { color: #946200; background: #fff7d6; }
.guide-integration.checking { color: #64748b; background: #f1f5f9; }
.guide-icon { color: #6366f1; flex-shrink: 0; }
.right-column { min-width: 0; }
.task-reference { margin: 16px 8px 0; color: #64748b; font: 11px/1.5 Consolas, monospace; overflow-wrap: anywhere; }
.error-area {
  flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
  padding: 32px 24px; background: white; border: 1px solid #e8ecf1; border-radius: 14px; color: #dc2626;
}
.error-area h3 { margin: 16px 0 8px; color: #334155; font-size: 16px; }
.error-area p { max-width: 440px; color: #64748b; font-size: 13px; line-height: 1.6; overflow-wrap: anywhere; }
.quiet-button { display: inline-flex; align-items: center; gap: 6px; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 8px; background: white; color: #475569; cursor: pointer; }
.quiet-button:hover { background: #f8fafc; }
@media (max-width: 1000px) {
  .bugfix-workspace { grid-template-columns: minmax(260px, 0.85fr) minmax(0, 1.15fr); }
  .guide-area { padding: 24px 16px; }
}
@media (max-width: 760px) {
  .bugfix-workspace { display: flex; flex-direction: column; overflow-y: auto; }
  .bugfix-topbar { flex: 0 0 auto; align-items: flex-start; flex-direction: column; gap: 8px; }
  .bugfix-topbar-status { justify-content: flex-start; }
  .input-stepper { gap: 2px; }
  .input-step { padding: 6px 5px; }
  .input-step-copy small { display: none; }
  .left-column { flex: 0 0 auto; overflow: visible; }
  .right-column { flex: 0 0 auto; min-height: 360px; overflow: visible; }
  .guide-area { min-height: 360px; }
  .loading-area { min-height: 320px; }
}
</style>
