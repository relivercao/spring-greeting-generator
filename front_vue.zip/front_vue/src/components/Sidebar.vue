<template>
  <div class="sidebar-wrapper">
    <!-- Icon bar -->
    <aside class="icon-bar">
      <el-tooltip
        :content="versionUpdateAvailable ? 'Home - version update available' : 'Home'"
        placement="right"
      >
        <div
          class="icon-bar-logo"
          @click="$emit('go-home')"
        >
          <div class="logo-icon">
            <el-icon size="20">
              <Cpu />
            </el-icon>
          </div>
          <span
            v-if="versionUpdateAvailable"
            class="home-update-dot"
            aria-label="Version update available"
          />
        </div>
      </el-tooltip>

      <div class="icon-bar-agents">
        <el-tooltip
          v-for="agent in agents"
          :key="agent.id"
          :content="agent.name"
          placement="right"
          :show-after="200"
        >
          <div
            class="agent-icon-btn"
            :class="{ active: activeAgent?.id === agent.id && panelVisible }"
            :style="{ '--agent-color': agent.color }"
            @click="handleAgentClick(agent)"
          >
            <div
              class="agent-icon-inner"
              :style="{ background: agent.color + '18', color: agent.color }"
            >
              <AgentMascot
                v-if="hasAgentMascot(agent)"
                :agent="agent"
                size="sidebar"
              />
              <img
                v-else-if="agent.logo_url"
                class="agent-logo"
                :src="agent.logo_url"
                :alt="agent.name + ' logo'"
              >
              <el-icon
                v-else
                size="20"
              >
                <component :is="agent.icon" />
              </el-icon>
            </div>
            <span class="agent-label">{{ agent.name }}</span>
          </div>
        </el-tooltip>
      </div>

      <div class="icon-bar-bottom">
        <el-tooltip
          content="Skill Market"
          placement="right"
        >
          <button
            type="button"
            class="bottom-icon-btn market-nav-btn"
            :class="{ active: activeView === 'skill-market' }"
            aria-label="Open Skill Market"
            @click="$emit('open-skill-market')"
          >
            <el-icon size="18">
              <CollectionTag />
            </el-icon>
          </button>
        </el-tooltip>
        <!-- <el-tooltip
          content="New Chat"
          placement="right"
        >
          <div
            class="bottom-icon-btn"
            @click="$emit('new-chat')"
          >
            <el-icon size="18">
              <EditPen />
            </el-icon>
          </div>
        </el-tooltip>
        <el-tooltip
          content="Profile"
          placement="right"
        >
          <div class="user-icon-btn">
            <span>P</span>
          </div>
        </el-tooltip> -->
      </div>
    </aside>

    <!-- History session panel -->
    <transition name="panel-slide">
      <div
        v-if="activeAgent && panelVisible"
        class="history-panel"
      >
        <div class="panel-header">
          <div class="panel-agent-info">
            <div
              class="panel-agent-dot"
              :style="{ background: activeAgent.color }"
            />
            <span class="panel-agent-name">{{ activeAgent.name }}</span>
          </div>
          <el-tooltip
            :content="newButtonLabel"
            placement="bottom"
          >
            <button
              class="panel-new-btn"
              :style="{ background: activeAgent.color + '18', color: activeAgent.color }"
              @click="startNewChat"
            >
              <el-icon size="14">
                <Plus />
              </el-icon>
            </button>
          </el-tooltip>
        </div>

        <div
          v-if="activeAgent.id === 2"
          class="unittest-mode-switch"
          role="tablist"
          aria-label="Unit test mode"
        >
          <button
            type="button"
            role="tab"
            class="unittest-mode-button"
            :class="{ active: unittestMode === 'single' }"
            :aria-selected="unittestMode === 'single'"
            @click="selectUnittestMode('single')"
          >
            Single
          </button>
          <button
            type="button"
            role="tab"
            class="unittest-mode-button"
            :class="{ active: unittestMode === 'batch' }"
            :aria-selected="unittestMode === 'batch'"
            @click="selectUnittestMode('batch')"
          >
            Batch
          </button>
        </div>

        <div class="panel-search">
          <el-icon
            size="12"
            class="search-icon"
          >
            <Search />
          </el-icon>
          <input
            v-model="searchText"
            class="search-input"
            placeholder="Search history..."
          >
        </div>

        <div class="panel-sessions">
          <div
            v-if="filteredHistory.length === 0"
            class="panel-empty"
          >
            <el-icon size="28">
              <component :is="emptyStateIcon" />
            </el-icon>
            <p>No history yet</p>
            <button
              class="start-btn"
              @click="startNewChat"
            >
              {{ emptyStateLabel }}
            </button>
          </div>

          <div
            v-for="session in filteredHistory"
            :key="session.id"
            class="session-item"
            :class="{ active: activeSession?.id === session.id }"
            :style="activeSession?.id === session.id ? { background: activeAgent.color + '12' } : {}"
            @click="$emit('select-session', session)"
          >
            <div class="session-body">
              <div
                class="session-title"
                :style="activeSession?.id === session.id ? { color: activeAgent.color } : {}"
              >
                {{ session.title }}
              </div>
              <div class="session-time">
                {{ session.time }}
              </div>
            </div>
            <el-tooltip
              content="Delete"
              placement="right"
            >
              <button
                class="session-delete"
                @click.stop="$emit('delete-session', session.id)"
              >
                <el-icon size="12">
                  <Delete />
                </el-icon>
              </button>
            </el-tooltip>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import AgentMascot from './AgentMascot.vue'
import { hasAgentMascot } from '../config/agentMascots.js'

const props = defineProps({
  agents: Array,
  history: Array,
  activeAgent: Object,
  activeSession: Object,
  unittestMode: {
    type: String,
    default: 'single',
  },
  activeView: {
    type: String,
    default: '',
  },
  versionUpdateAvailable: {
    type: Boolean,
    default: false,
  },
})

const emit = defineEmits(['select-agent', 'select-session', 'new-chat', 'start-agent-chat', 'go-home', 'delete-session', 'select-unittest-mode', 'open-skill-market'])

const panelVisible = ref(false)
const searchText = ref('')

// Determine whether the current Agent is Chat or Task
const isTaskAgent = computed(() => {
  return [2, 3, 4, 6, 8, 9].includes(props.activeAgent?.id)
})

const newButtonLabel = computed(() => {
  if (props.activeAgent?.id === 2 && props.unittestMode === 'batch') return 'New Batch Test'
  if (props.activeAgent?.id === 2) return 'New Unit Test'
  return isTaskAgent.value ? 'New Task' : 'New Chat'
})

const emptyStateLabel = computed(() => {
  if (props.activeAgent?.id === 2 && props.unittestMode === 'batch') return 'Start Batch Test'
  if (props.activeAgent?.id === 2) return 'Start Unit Test'
  return isTaskAgent.value ? 'Start Task' : 'Start Chat'
})

const emptyStateIcon = computed(() => {
  if (props.activeAgent?.id === 6) return 'PictureRounded'
  return isTaskAgent.value ? 'Finished' : 'ChatDotRound'
})

// When activeAgent changes externally (such as route navigation), keep the panel expanded in sync
watch(() => props.activeAgent?.id, (newId) => {
  if (newId) {
    panelVisible.value = true
    searchText.value = ''
  } else {
    panelVisible.value = false
  }
})

function handleAgentClick(agent) {
  if (props.activeAgent?.id === agent.id && panelVisible.value) {
    // Click the same agent again: collapse the panel and return to the upload page
    panelVisible.value = false
    emit('select-agent', agent)
  } else {
    panelVisible.value = true
    emit('select-agent', agent)
    searchText.value = ''
  }
}

function startNewChat() {
  emit('start-agent-chat', props.activeAgent)
}

function selectUnittestMode(mode) {
  if (props.unittestMode !== mode) emit('select-unittest-mode', mode)
}

const filteredHistory = computed(() => {
  if (!props.activeAgent) return []
  const list = props.history.filter(h => h.agentId === props.activeAgent.id)
  if (!searchText.value.trim()) return list
  return list.filter(h => h.title.toLowerCase().includes(searchText.value.toLowerCase()))
})
</script>

<style scoped>
.sidebar-wrapper {
  display: flex;
  height: 100vh;
  position: relative;
  z-index: 10;
}

/* ===== Icon bar ===== */
.icon-bar {
  width: 64px;
  min-width: 64px;
  background: #ffffff;
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 100vh;
  border-right: 1px solid #e8eaed;
  box-shadow: 1px 0 0 #f0f0f0;
}

.icon-bar-logo {
  position: relative;
  padding: 16px 0 12px;
  border-bottom: 1px solid #f0f2f5;
  width: 100%;
  display: flex;
  justify-content: center;
  margin-bottom: 10px;
  cursor: pointer;
}

.home-update-dot {
  position: absolute;
  top: 12px;
  right: 10px;
  width: 8px;
  height: 8px;
  border: 2px solid #ffffff;
  border-radius: 50%;
  background: #2563eb;
  box-shadow: 0 1px 4px rgb(37 99 235 / 40%);
}

.icon-bar-logo:hover .logo-icon {
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(37,99,235,0.3);
}

.logo-icon {
  width: 36px;
  height: 36px;
  background: linear-gradient(135deg, #2563eb, #4f8ef7);
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  transition: all 0.2s;
  box-shadow: 0 2px 8px rgba(37,99,235,0.2);
}

.icon-bar-agents {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 0;
  overflow-y: auto;
  width: 100%;
  scrollbar-width: none;
}

.icon-bar-agents::-webkit-scrollbar { display: none; }

.agent-icon-btn {
  width: 56px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  padding: 7px 4px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s;
  position: relative;
}

.agent-icon-btn:hover {
  background: #f5f7fa;
}

.agent-icon-btn.active {
  background: color-mix(in srgb, var(--agent-color) 8%, transparent);
}

.agent-icon-btn.active::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 3px;
  height: 24px;
  background: var(--agent-color);
  border-radius: 0 3px 3px 0;
}

.agent-icon-inner {
  width: 38px;
  height: 38px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: #8b97a8;
  transition: all 0.15s;
  background: #f5f7fa;
}

.agent-logo {
  width: 24px;
  height: 24px;
  object-fit: cover;
  border-radius: 6px;
}

.agent-icon-btn:hover .agent-icon-inner {
  filter: brightness(0.92);
}

.agent-label {
  font-size: 10px;
  color: #9ca3af;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 60px;
  line-height: 1.2;
}

.agent-icon-btn.active .agent-label {
  color: var(--agent-color);
  font-weight: 500;
}

.icon-bar-bottom {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 12px 0 14px;
  border-top: 1px solid #f0f2f5;
  width: 100%;
}

.bottom-icon-btn {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
  cursor: pointer;
  color: #9ca3af;
  transition: all 0.15s;
}

.bottom-icon-btn:hover {
  background: #f5f7fa;
  color: #374151;
}

.market-nav-btn.active {
  background: #e9f3f2;
  color: #087b78;
}

.user-icon-btn {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 600;
  color: white;
  cursor: pointer;
  transition: transform 0.15s, box-shadow 0.15s;
  box-shadow: 0 2px 6px rgba(99,102,241,0.3);
}

.user-icon-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 10px rgba(99,102,241,0.35);
}

/* ===== History panel ===== */
.history-panel {
  width: 212px;
  background: #fafbfc;
  border-right: 1px solid #e8eaed;
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 14px 12px;
  border-bottom: 1px solid #eef0f3;
  flex-shrink: 0;
}

.panel-agent-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.panel-agent-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

.panel-agent-name {
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
}

.panel-new-btn {
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f0f4ff;
  color: #2563eb;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
}

.panel-new-btn:hover {
  background: #dbeafe;
}

.panel-search {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 10px 10px 6px;
  padding: 7px 10px;
  background: white;
  border-radius: 8px;
  border: 1px solid #e8eaed;
  flex-shrink: 0;
}

.unittest-mode-switch {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2px;
  margin: 10px 12px 0;
  padding: 3px;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  background: #f8fafc;
}

.unittest-mode-button {
  min-width: 0;
  height: 28px;
  border: 0;
  border-radius: 4px;
  background: transparent;
  color: #64748b;
  font-size: 12px;
  cursor: pointer;
}

.unittest-mode-button.active {
  background: #ffffff;
  color: #166534;
  box-shadow: 0 1px 2px #0f172a1a;
}

.search-icon { color: #9ca3af; flex-shrink: 0; }

.search-input {
  border: none;
  outline: none;
  background: transparent;
  font-size: 12px;
  color: #374151;
  width: 100%;
}

.search-input::placeholder { color: #c4c9d4; }

.panel-sessions {
  flex: 1;
  overflow-y: auto;
  padding: 4px 8px;
  scrollbar-width: thin;
  scrollbar-color: #e5e7eb transparent;
}

.panel-sessions::-webkit-scrollbar { width: 3px; }
.panel-sessions::-webkit-scrollbar-thumb { background: #e5e7eb; border-radius: 2px; }

.panel-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 48px 16px;
  color: #c4c9d4;
  text-align: center;
}

.panel-empty p { font-size: 13px; color: #9ca3af; }

.start-btn {
  padding: 6px 18px;
  background: #2563eb;
  color: white;
  border: none;
  border-radius: 7px;
  font-size: 12px;
  cursor: pointer;
  margin-top: 4px;
  transition: background 0.15s;
}

.start-btn:hover { background: #1d4ed8; }

.session-item {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 9px 8px;
  border-radius: 8px;
  cursor: pointer;
  margin-bottom: 2px;
  transition: background 0.15s;
}

.session-item:hover { background: #f0f2f5; }
.session-item.active { }

.session-body {
  flex: 1;
  min-width: 0;
}

.session-title {
  font-size: 13px;
  color: #374151;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 2px;
}

.session-item.active .session-title { font-weight: 500; }

.session-time {
  font-size: 11px;
  color: #9ca3af;
}

.session-delete {
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 5px;
  cursor: pointer;
  color: transparent;
  transition: all 0.15s;
  flex-shrink: 0;
}

.session-item:hover .session-delete {
  color: #9ca3af;
}

.session-delete:hover {
  background: #fee2e2 !important;
  color: #ef4444 !important;
}

/* Panel slide-in */
.panel-slide-enter-active,
.panel-slide-leave-active {
  transition: all 0.2s ease;
  overflow: hidden;
}
.panel-slide-enter-from,
.panel-slide-leave-to {
  width: 0;
  opacity: 0;
}
.panel-slide-enter-to,
.panel-slide-leave-from {
  width: 212px;
  opacity: 1;
}
</style>
