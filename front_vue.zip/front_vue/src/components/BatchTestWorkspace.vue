<template>
  <div
    class="batch-test-workspace"
  >
    <section class="setup-column">
      <input
        ref="folderInputRef"
        class="hidden-input"
        type="file"
        webkitdirectory
        multiple
        @change="onBrowserFolderSelect"
      >
      <input
        ref="fileInputRef"
        class="hidden-input"
        type="file"
        accept=".c,.cpp,.h,.hpp,.cxx,.cc"
        multiple
        @change="onBrowserFileSelect"
      >

      <div class="workspace-title">
        <div class="workspace-icon">
          <el-icon size="22">
            <Tickets />
          </el-icon>
        </div>
        <div>
          <h2>Batch Test Runner</h2>
          <p>Select files, then run them serially from top to bottom.</p>
        </div>
      </div>

      <div class="picker-card">
        <div class="section-heading">
          <div class="section-label">
            <el-icon size="13">
              <FolderOpened />
            </el-icon>
            File picker
          </div>
          <span class="file-counter">{{ sourceFiles.length }} files</span>
        </div>

        <p
          v-if="isTaskTerminal"
          class="readonly-hint"
        >
          <el-icon size="12">
            <Lock />
          </el-icon>
          This batch has finished — the card is a read-only archive. Create a new task to run again.
        </p>

        <div class="picker-actions">
          <button
            class="picker-button primary"
            type="button"
            :disabled="isSelecting || isTaskTerminal"
            @click="selectFolderFromLocal"
          >
            <el-icon size="14">
              <FolderAdd />
            </el-icon>
            {{ selectingMode === 'folder' ? 'Opening folder...' : 'Select Folder' }}
          </button>
          <button
            class="picker-button"
            type="button"
            :disabled="isSelecting || isTaskTerminal"
            @click="addFileFromLocal"
          >
            <el-icon size="14">
              <DocumentAdd />
            </el-icon>
            {{ selectingMode === 'file' ? 'Opening files...' : 'Select Files' }}
          </button>
        </div>

        <div class="selection-toolbar">
          <button
            class="select-all-control"
            :class="{ checked: isAllSelected, mixed: isPartiallySelected }"
            type="button"
            :disabled="sourceFiles.length === 0 || isTaskBusy || isTaskTerminal"
            :aria-pressed="isAllSelected"
            @click="toggleAllSelected"
          >
            <span
              class="selection-mark"
              :class="{ checked: isAllSelected, mixed: isPartiallySelected }"
            >
              <el-icon
                v-if="isAllSelected"
                size="11"
              >
                <Check />
              </el-icon>
              <span
                v-else-if="isPartiallySelected"
                class="selection-mark-dash"
              />
            </span>
            <span>{{ selectedFiles.length }} selected</span>
          </button>
          <div class="selection-actions">
            <button
              class="select-toggle-button"
              type="button"
              :disabled="sourceFiles.length === 0 || isTaskBusy || isTaskTerminal"
              @click="toggleAllSelected"
            >
              {{ isAllSelected ? 'Unselect all' : 'Select all' }}
            </button>
            <button
              class="remove-selected-button"
              type="button"
              :disabled="selectedFiles.length === 0 || isTaskBusy || isTaskTerminal"
              @click="removeSelectedFiles"
            >
              <el-icon size="13">
                <Delete />
              </el-icon>
              Remove selected
            </button>
          </div>
        </div>

        <p
          v-if="emptySourceFiles.length"
          class="readonly-hint empty-files-hint"
          role="status"
        >
          Empty files are excluded from generation: {{ emptySourceFiles.map(file => file.name).join(', ') }}.
          <span v-if="selectedFiles.length === 0">Select a file containing source code to generate tests.</span>
        </p>

        <div
          v-if="sourceFiles.length === 0"
          class="empty-picker"
        >
          <div class="empty-picker-icon">
            <el-icon size="24">
              <FolderOpened />
            </el-icon>
          </div>
          <strong>No files loaded</strong>
          <span>Load a folder or add source files to build the batch list.</span>
        </div>
      </div>

      <div class="run-actions">
        <button
          class="run-button"
          type="button"
          :disabled="selectedFiles.length === 0 || isTaskBusy || isTaskTerminal"
          @click="startSerialPreview"
        >
          <el-icon size="15">
            <VideoPlay />
          </el-icon>
          {{ runButtonLabel }}
        </button>
        <button
          v-if="isTaskBusy && batchTaskId"
          class="cancel-run-button"
          type="button"
          :disabled="cancelling"
          @click="cancelBatchTask"
        >
          <el-icon size="14">
            <Close />
          </el-icon>
          {{ cancelling ? 'Cancelling...' : 'Cancel' }}
        </button>
      </div>
      <p
        v-if="executionError"
        class="execution-error"
        role="alert"
      >
        {{ executionError }}
      </p>
    </section>

    <main class="queue-column">
      <div class="queue-header">
        <div>
          <span class="eyebrow">File list</span>
          <h3>{{ sourceFiles.length }} source files</h3>
        </div>
        <span class="run-mode">{{ selectedFiles.length }} selected</span>
      </div>

      <div
        v-if="sourceFiles.length === 0"
        class="empty-queue"
      >
        <el-icon size="32">
          <Tickets />
        </el-icon>
        <strong>The file list is empty</strong>
        <span>Choose files in the first column to populate this list.</span>
      </div>

      <div
        v-else
        class="batch-file-list"
      >
        <div
          v-for="file in sourceFiles"
          :key="file.id"
          class="batch-file-row"
          :class="{ selected: isFileSelected(file.id) }"
          @click="selectQueueTaskForFile(file)"
        >
          <button
            class="selection-mark"
            :class="{ checked: isFileSelected(file.id) }"
            type="button"
            :disabled="isTaskBusy || isTaskTerminal || isEmptySource(file)"
            :aria-label="`${isFileSelected(file.id) ? 'Exclude' : 'Include'} ${file.name}`"
            @click.stop="toggleFile(file.id)"
          >
            <el-icon
              v-if="isFileSelected(file.id)"
              size="11"
            >
              <Check />
            </el-icon>
          </button>
          <el-icon
            class="file-icon"
            size="15"
          >
            <Document />
          </el-icon>
          <span class="batch-file-main">
            <button
              class="batch-file-name"
              type="button"
              :disabled="!isFileSelected(file.id)"
              @click.stop="selectQueueTaskForFile(file)"
            >
              {{ file.name }}
            </button>
            <em>{{ file.relativePath }}</em>
            <label class="batch-file-path">
              <span>Path</span>
              <input
                :value="file.path || file.relativePath"
                type="text"
                spellcheck="false"
                :disabled="isTaskBusy || isTaskTerminal"
                @click.stop
                @keydown.stop
                @input="updateFilePath(file.id, $event.target.value)"
              >
            </label>
          </span>
          <span
            class="batch-file-state"
            :class="fileQueueState(file)"
          >
            <el-icon
              v-if="fileQueueState(file) === 'pass'"
              size="14"
            ><CircleCheck /></el-icon>
            <el-icon
              v-else-if="fileQueueState(file) === 'fail'"
              size="14"
            ><CircleClose /></el-icon>
            <span
              v-else-if="fileQueueState(file) === 'running'"
              class="mini-spinner"
            />
            <span
              v-else-if="fileQueueState(file) === 'queued' || fileQueueState(file) === 'pending'"
              class="pending-dot"
            />
            {{ fileQueueLabel(file) }}
          </span>
          <button
            class="remove-file-button"
            type="button"
            :disabled="isTaskBusy || isTaskTerminal"
            :aria-label="`Remove ${file.name}`"
            :title="`Remove ${file.name}`"
            @click.stop="removeFile(file.id)"
          >
            <el-icon size="12">
              <Delete />
            </el-icon>
          </button>
        </div>
      </div>
    </main>

    <aside class="report-column">
      <BatchRunProgress
        v-if="isTaskBusy && batchDetail?.status !== 'done'"
        :status="batchDetail?.status || taskStatus"
        :progress="Number(batchDetail?.progress ?? props.activeTask?.progress) || 0"
        :items="batchItems.length ? batchItems : queueItems.map(item => ({ status: item.state }))"
      />
      <template v-if="hasExecutionState || batchTaskId">
        <div class="report-card summary-card">
          <div class="summary-icon">
            <el-icon size="24">
              <Operation />
            </el-icon>
          </div>
          <div>
            <span class="eyebrow">Run summary</span>
            <h3>{{ summaryTitle }}</h3>
            <p v-if="summaryDescription">
              {{ summaryDescription }}
            </p>
          </div>
        </div>

        <div class="metrics-grid">
          <div
            v-for="metric in metrics"
            :key="metric.label"
            class="metric-tile"
          >
            <span>{{ metric.label }}</span>
            <strong>{{ metric.value }}</strong>
          </div>
        </div>

        <div
          v-if="selectedTask"
          class="report-card task-report-card"
          :class="selectedTask.state"
        >
          <div class="detail-header report-detail-header">
            <div>
              <span class="eyebrow">Selected file report</span>
              <h3>{{ selectedTask.name }}</h3>
            </div>
            <span
              class="status-badge"
              :class="selectedTask.state"
            >
              {{ stateLabelMap[selectedTask.state] }}
            </span>
          </div>

          <template v-if="selectedTask.state === 'pass'">
            <div class="hero-banner">
              <div class="hero-glow" />

              <div class="hero-donuts">
                <div class="donut-wrap main-donut">
                  <svg
                    viewBox="0 0 120 120"
                    class="donut-svg"
                  >
                    <defs>
                      <linearGradient
                        id="grad-main"
                        x1="0%"
                        y1="0%"
                        x2="100%"
                        y2="100%"
                      >
                        <stop
                          offset="0%"
                          stop-color="#38bdf8"
                        />
                        <stop
                          offset="100%"
                          stop-color="#6366f1"
                        />
                      </linearGradient>
                    </defs>
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      class="donut-track"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="50"
                      class="donut-ring main-ring"
                      :style="donutStyle(selectedTaskReport.coverage, 314.16)"
                    />
                  </svg>
                  <div class="donut-label">
                    <span class="donut-pct">{{ selectedTaskReport.coverage.toFixed(1) }}<em>%</em></span>
                    <span class="donut-sub">Coverage</span>
                  </div>
                </div>

                <div class="mini-donuts">
                  <div
                    v-for="metric in selectedTaskReport.miniMetrics"
                    :key="metric.key"
                    class="mini-donut-item"
                  >
                    <svg
                      viewBox="0 0 60 60"
                      class="mini-svg"
                    >
                      <defs>
                        <linearGradient
                          :id="`grad-${metric.key}`"
                          x1="0%"
                          y1="0%"
                          x2="100%"
                          y2="100%"
                        >
                          <stop
                            offset="0%"
                            :stop-color="metric.c1"
                          />
                          <stop
                            offset="100%"
                            :stop-color="metric.c2"
                          />
                        </linearGradient>
                      </defs>
                      <circle
                        v-if="metric.val !== null"
                        cx="30"
                        cy="30"
                        r="23"
                        class="donut-track"
                      />
                      <circle
                        cx="30"
                        cy="30"
                        r="23"
                        class="donut-ring"
                        :style="donutStyle(metric.val, 144.51)"
                        :stroke="`url(#grad-${metric.key})`"
                      />
                    </svg>
                    <div class="mini-label">
                      <span class="mini-pct">{{ metric.val === null ? 'N/A' : `${metric.val.toFixed(1)}%` }}</span>
                      <span class="mini-sub">{{ metric.name }}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div class="kpi-grid">
                <div
                  v-for="metric in selectedTaskReport.kpiMetrics"
                  :key="metric.label"
                  class="kpi-tile"
                  :class="metric.tone"
                >
                  <span class="kpi-icon">{{ metric.icon }}</span>
                  <span class="kpi-val">{{ metric.value }}</span>
                  <span class="kpi-name">{{ metric.label }}</span>
                </div>
              </div>
            </div>

            <div class="tag-strip">
              <span class="tag tag-layer">{{ selectedTaskReport.layer }}</span>
              <span class="tag tag-fw">{{ selectedTaskReport.framework }}</span>
              <span class="tag tag-file">Run {{ selectedTask.indexLabel }}</span>
            </div>

            <div class="dark-card">
              <div class="dark-card-title">
                <el-icon size="13">
                  <Document />
                </el-icon>
                Generated Files
                <span class="card-count">{{ selectedTaskReport.generatedFiles.length }}</span>
              </div>
              <div
                v-for="file in selectedTaskReport.generatedFiles"
                :key="file.name"
                class="file-row"
              >
                <div class="file-row-head">
                  <span
                    class="file-ext-badge"
                    :class="file.extClass"
                  >{{ file.type }}</span>
                  <span class="file-row-name">{{ file.name }}</span>
                  <span class="file-row-meta">{{ file.action }}</span>
                </div>
              </div>
            </div>

            <div class="dark-card log-card">
              <div class="dark-card-title">
                <span class="dot-green" />
                Workflow Output
              </div>
              <div class="summary-inner">
                <!-- What was done -->
                <div class="summary-section">
                  <div class="summary-section-title">
                    What was done
                  </div>
                  <ul class="summary-list">
                    <li
                      v-for="line in selectedTaskReport.workflow.whatWasDone"
                      :key="line"
                    >
                      ✓ {{ line }}
                    </li>
                  </ul>
                </div>

                <!-- Result -->
                <div class="summary-section">
                  <div class="summary-section-title">
                    Result
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">Compile:</span>
                    <span :class="selectedTaskReport.compileSuccess ? 'val-green' : 'val-red'">
                      {{ selectedTaskReport.compileSuccess ? 'Passed' : 'Failed' }}
                    </span>
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">Coverage target:</span>
                    <span :class="selectedTaskReport.coverageMet ? 'val-green' : 'val-amber'">
                      {{ selectedTaskReport.coverageMet ? 'Met' : 'Not met' }}
                    </span>
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">Test result:</span>
                    <span :class="selectedTaskReport.passRate === 100 ? 'val-green' : 'val-amber'">
                      {{ selectedTaskReport.passRate }}% ({{ selectedTaskReport.passedCount }} / {{ selectedTaskReport.testCount }})
                    </span>
                  </div>
                </div>

                <!-- Coverage -->
                <div class="summary-section">
                  <div class="summary-section-title">
                    Coverage
                  </div>
                  <table class="coverage-summary-table">
                    <thead>
                      <tr>
                        <th>Coverage</th>
                        <th>Target</th>
                        <th>Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Line coverage</td>
                        <td>{{ selectedTaskReport.coverageTargets.line }}%</td>
                        <td>{{ formatCoverage(selectedTaskReport.coverageMetrics.line) }}</td>
                      </tr>
                      <tr>
                        <td>Branch coverage</td>
                        <td>{{ selectedTaskReport.coverageTargets.branch }}%</td>
                        <td>{{ formatCoverage(selectedTaskReport.coverageMetrics.branch) }}</td>
                      </tr>
                      <tr>
                        <td>Function coverage</td>
                        <td>{{ selectedTaskReport.coverageTargets.function }}%</td>
                        <td>{{ formatCoverage(selectedTaskReport.coverageMetrics.function) }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <!-- Summary -->
                <div class="summary-section summary-section-last">
                  <div class="summary-section-title">
                    Summary
                  </div>
                  <div
                    v-for="section in selectedTaskReport.workflow.summarySections"
                    :key="section.title"
                    class="summary-subsection"
                  >
                    <div class="summary-subsection-title">
                      {{ section.title }}
                    </div>
                    <p class="summary-paragraph">
                      {{ section.content }}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div class="dark-card">
              <div class="dark-card-title">
                Request Payload
                <span class="card-count">API preview</span>
              </div>
              <div class="summary-inner">
                <div class="summary-section">
                  <div class="summary-kv">
                    <span class="summary-kv-key">selected_files[0]</span>
                    <span class="summary-kv-val">{{ selectedTask.fullPath }}</span>
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">report_path</span>
                    <span class="summary-kv-val">{{ selectedTask.output }}</span>
                  </div>
                </div>
              </div>
            </div>

            <div class="download-actions-card">
              <button
                class="download-log-btn"
                type="button"
                @click="downloadTaskLog"
              >
                <el-icon size="14">
                  <Download />
                </el-icon>
                Download Task Log
              </button>
              <span class="download-hint">Full execution log with timestamps and output</span>
            </div>
          </template>

          <div
            v-else
            class="task-state-panel"
            :class="selectedTask.state"
          >
            <el-icon
              v-if="selectedTask.state === 'fail'"
              size="26"
            >
              <CircleClose />
            </el-icon>
            <span
              v-else-if="selectedTask.state === 'running'"
              class="state-spinner"
            />
            <el-icon
              v-else
              size="26"
            >
              <DocumentChecked />
            </el-icon>
            <strong>{{ selectedTaskStateTitle }}</strong>
            <span>{{ selectedTaskStateDescription }}</span>
            <dl class="payload-list compact">
              <div>
                <dt>selected_files[0]</dt>
                <dd>{{ selectedTask.fullPath }}</dd>
              </div>
            </dl>
          </div>

          <div
            v-if="selectedTask.state === 'fail' || selectedTask.state === 'running'"
            class="download-actions-card"
          >
            <button
              class="download-log-btn"
              :class="{ 'download-log-btn-disabled': selectedTask.state === 'running' }"
              type="button"
              :disabled="selectedTask.state === 'running'"
              @click="downloadTaskLog"
            >
              <el-icon size="14">
                <Download />
              </el-icon>
              {{ selectedTask.state === 'running' ? 'Log Available After Completion' : 'Download Task Log' }}
            </button>
            <span class="download-hint">
              {{ selectedTask.state === 'running' ? 'Task is still running, log will be available when finished' : 'Full execution log with error details and stack trace' }}
            </span>
          </div>
        </div>

        <div
          v-else
          class="report-card detail-empty"
        >
          <el-icon size="24">
            <DocumentChecked />
          </el-icon>
          <strong>No task selected</strong>
          <span>Choose files on the left to preview the serial execution payload.</span>
        </div>
      </template>

      <div
        v-else-if="!isTaskBusy && !batchTaskId"
        class="report-card report-placeholder"
      >
        <div class="summary-icon">
          <el-icon size="24">
            <Operation />
          </el-icon>
        </div>
        <span class="eyebrow">Results panel</span>
        <h3>Ready for execution</h3>
        <p>Run the batch to populate results, metrics, generated files, and execution details here.</p>
      </div>
    </aside>
  </div>
</template>

<script setup>
import { computed, ref, watch, onMounted, onBeforeUnmount } from 'vue'
import { ElMessage } from 'element-plus'
import {
  CircleCheck,
  CircleClose,
  Check,
  Close,
  Delete,
  Document,
  DocumentAdd,
  DocumentChecked,
  Download,
  FolderAdd,
  FolderOpened,
  Lock,
  Operation,
  Tickets,
  VideoPlay
} from '@element-plus/icons-vue'
import {
  apiCancelBatchTask,
  apiCreateBatchTask,
  apiGetTask,
  apiPollBatchTask,
  apiResumeBatchTask,
} from '../api/unittest.js'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { isLocalFileSelectorHost } from '../utils/localFileSelector.js'
import BatchRunProgress from './BatchRunProgress.vue'

const authStore = useAuthStore()
const mountedAccount = accountIdentity(authStore)
let disposed = false
watch(() => accountIdentity(authStore), () => { disposed = true }, { flush: 'sync' })
function isCurrentAccount() {
  return !disposed && mountedAccount === accountIdentity(authStore)
}

const props = defineProps({
  activeTask: Object
})

const emit = defineEmits(['task-updated', 'run-requested'])

const LOCAL_SERVICE_URL = 'http://127.0.0.1:9999'
const SOURCE_EXTENSIONS = ['.c', '.cpp', '.h', '.hpp', '.cxx', '.cc']
const DISPLAY_EXTENSIONS = ['.c', '.cpp']  // Only display .c and .cpp files in the list

const folderInputRef = ref(null)
const fileInputRef = ref(null)
const sourceRoot = ref('')
const sourceFiles = ref([])
const selectedFileIds = ref(new Set())
const selectedTaskId = ref('')
const selectingMode = ref('')
const previewRunStarted = ref(false)
const batchTaskId = ref(null)
const batchDetail = ref(null)
const batchItems = ref([])
const itemReports = ref(new Map())
const itemReportLoading = ref(new Set())
const stopBatchPolling = ref(null)
const executionError = ref('')
const resumeRequired = ref(false)
const blockedReason = ref('')
const authPromptShown = ref(false)
const cancelling = ref(false)

const taskStatus = computed(() => {
  const status = props.activeTask?.status || 'idle'
  return status === 'done' ? 'completed' : status
})
const hasExecutionState = computed(() => ['queued', 'running', 'completed', 'failed', 'cancelled'].includes(taskStatus.value))
const isTaskBusy = computed(() => ['queued', 'running'].includes(taskStatus.value))
// Terminal batches (completed/failed/cancelled) are read-only archives:
// their results must stay visible and their inputs can no longer be edited.
const isTaskTerminal = computed(() => ['completed', 'failed', 'cancelled'].includes(taskStatus.value))

const runButtonLabel = computed(() => {
  if (taskStatus.value === 'queued') return 'Queued'
  if (taskStatus.value === 'running') return 'Running...'
  if (taskStatus.value === 'completed') return 'Completed'
  if (taskStatus.value === 'failed') return 'Failed'
  if (taskStatus.value === 'cancelled') return 'Cancelled'
  return 'Generate Files'
})

// Initialize from activeTask if provided
onMounted(() => {
  if (props.activeTask) {
    restoreTask(props.activeTask)
    if (props.activeTask.batchTaskId) startBatchPolling(props.activeTask.batchTaskId)
  }
})

// Watch for activeTask changes
watch(() => props.activeTask, (newTask, oldTask) => {
  if (!isCurrentAccount()) return
  if (newTask && newTask.selectedFiles) {
    // Only update if the task ID changed or files array reference changed (external update)
    const isNewTask = !oldTask || oldTask.id !== newTask.id
    const filesChanged = !oldTask || oldTask.selectedFiles !== newTask.selectedFiles
    if (isNewTask || filesChanged || newTask.batchTaskId !== oldTask?.batchTaskId) {
      restoreTask(newTask)
    }
    if (newTask.batchTaskId && newTask.batchTaskId !== batchTaskId.value) {
      startBatchPolling(newTask.batchTaskId)
    }
  }
}, { deep: true })

// Emit task updates when files change
watch([sourceFiles, selectedFileIds], () => {
  if (!isCurrentAccount()) return
  if (props.activeTask) {
    const inputChangedAfterRun = !previewRunStarted.value && !isTaskBusy.value && !isTaskTerminal.value
    emit('task-updated', {
      id: props.activeTask.id,
      title: generateTaskTitle(),
      selectedFiles: sourceFiles.value,
      totalCount: sourceFiles.value.length,
      status: inputChangedAfterRun ? 'idle' : undefined,
      batchTaskId: inputChangedAfterRun ? null : batchTaskId.value,
      batchDetail: inputChangedAfterRun ? null : batchDetail.value,
      items: inputChangedAfterRun ? [] : batchItems.value,
      terminalReason: inputChangedAfterRun ? null : props.activeTask.terminalReason,
      blockedReason: inputChangedAfterRun ? null : blockedReason.value,
      resumeRequired: inputChangedAfterRun ? false : resumeRequired.value,
    })
  }
}, { deep: true })

function generateTaskTitle() {
  const count = sourceFiles.value.length
  if (count === 0) return 'New Batch Test'
  if (count === 1) return sourceFiles.value[0].name
  return `Batch Test (${count} files)`
}

function restoreTask(task) {
  sourceFiles.value = Array.isArray(task?.selectedFiles) ? task.selectedFiles : []
  selectedFileIds.value = new Set(sourceFiles.value.map(file => file.id))
  selectedTaskId.value = selectedFiles.value[0]?.id || ''
  previewRunStarted.value = ['queued', 'running', 'completed', 'failed', 'cancelled', 'done'].includes(task?.status)
  batchTaskId.value = task?.batchTaskId || null
  batchDetail.value = task?.batchDetail || null
  batchItems.value = Array.isArray(task?.items) ? task.items : []
  executionError.value = task?.error || task?.errorMessage || ''
  resumeRequired.value = Boolean(task?.resumeRequired)
  blockedReason.value = task?.blockedReason || ''
  authPromptShown.value = false

  if (!batchTaskId.value && stopBatchPolling.value) {
    stopBatchPolling.value()
    stopBatchPolling.value = null
  }
}

// Shared guard for every input-editing entry point. Terminal batches are
// read-only archives, so edits are refused instead of resetting the results.
function blockTerminalEdit() {
  if (!isTaskTerminal.value) return false
  ElMessage.info('This batch has finished; the card is read-only. Create a new task to run again')
  return true
}

function resetExecutionForInputChange() {
  // Terminal batches keep their batch/item state no matter what happens to the inputs.
  if (isTaskBusy.value || isTaskTerminal.value) return
  previewRunStarted.value = false
  batchTaskId.value = null
  batchDetail.value = null
  batchItems.value = []
  itemReports.value = new Map()
  itemReportLoading.value = new Set()
  resumeRequired.value = false
  blockedReason.value = ''
  executionError.value = ''
  authPromptShown.value = false
  if (stopBatchPolling.value) {
    stopBatchPolling.value()
    stopBatchPolling.value = null
  }
}

function findBatchItem(file, index = 0) {
  if (!file) return null
  return batchItems.value.find(item => (
    item.sequence === index
    || (item.filename === file.name && (
      !item.relative_path || normalizePath(item.relative_path) === normalizePath(file.relativePath)
    ))
  )) || null
}

function getPreviewState(index, backendItem = null) {
  const item = backendItem || batchItems.value.find(candidate => candidate.sequence === index)
  if (item?.status === 'pass') return 'pass'
  if (item?.status === 'fail') return 'fail'
  if (item?.status === 'running') return 'running'
  if (item?.status === 'queued') return 'queued'
  if (taskStatus.value === 'queued') return 'queued'
  return 'pending'
}

function updateBatchTask(updates = {}) {
  if (!isCurrentAccount() || !props.activeTask?.id) return
  emit('task-updated', {
    id: props.activeTask.id,
    title: generateTaskTitle(),
    selectedFiles: sourceFiles.value,
    totalCount: selectedFiles.value.length,
    batchTaskId: batchTaskId.value,
    items: batchItems.value,
    ...updates,
  })
}

function startBatchPolling(taskId) {
  if (!isCurrentAccount() || !taskId || stopBatchPolling.value && batchTaskId.value === taskId) return
  if (stopBatchPolling.value) stopBatchPolling.value()
  batchTaskId.value = taskId
  stopBatchPolling.value = apiPollBatchTask(taskId, data => {
    if (isCurrentAccount() && batchTaskId.value === taskId) handleBatchPollData(data)
  })
}

function handleBatchPollData(data) {
  if (!isCurrentAccount() || !data) return
  // Drop responses that belong to a different batch than the one this
  // workspace currently shows; a stale poll callback must never overwrite
  // the active card's status (e.g. flipping a done batch back to running).
  if (data.batch_task_id && batchTaskId.value && data.batch_task_id !== batchTaskId.value) {
    return
  }
  if (data.status === 'auth_required') {
    executionError.value = data.error || 'Authentication is required to continue the batch task.'
    resumeRequired.value = true
    ElMessage.warning(executionError.value)
    if (data.aws_auth_required && !authPromptShown.value) {
      authPromptShown.value = true
      window.dispatchEvent(new CustomEvent('aws:auth-required'))
    }
    updateBatchTask({ status: 'running', error: executionError.value, resumeRequired: true })
    return
  }
  if (data.status === 'client_error' || data.status === 'failed') {
    // The batch API never returns these statuses (only queued/running/done);
    // they are synthesized by the poller after losing the backend connection.
    // That is a transport failure, not a batch failure: keep the last known
    // server state (card status and items) and only surface the error, so a
    // transient outage can no longer persist a fake "failed + queued items"
    // card.  The next page load re-syncs the authoritative state.
    executionError.value = data.error || data.error_message || 'Lost connection to the backend; the displayed state is the last known one'
    previewRunStarted.value = true
    updateBatchTask({ error: executionError.value })
    return
  }

  batchDetail.value = data
  if (Array.isArray(data.items)) batchItems.value = data.items
  previewRunStarted.value = true
  const counts = data.counts || {}
  const isDone = data.status === 'done'
  const cancelled = isDone && String(data.terminal_reason || '').toUpperCase() === 'CANCELLED'
  resumeRequired.value = Boolean(data.resume_required)
  blockedReason.value = data.blocked_reason || ''
  const itemRequiresResume = Array.isArray(data.items) && data.items.some(item => item?.resume_required)
  if (resumeRequired.value || itemRequiresResume) {
    resumeRequired.value = true
    if (!blockedReason.value) blockedReason.value = data.items.find(item => item?.blocked_reason)?.blocked_reason || ''
    if (!authPromptShown.value) {
      authPromptShown.value = true
      window.dispatchEvent(new CustomEvent('aws:auth-required', {
        detail: { batchTaskId: batchTaskId.value, blockedReason: blockedReason.value },
      }))
    }
  }
  updateBatchTask({
    status: cancelled ? 'cancelled' : (isDone ? 'completed' : (data.status || 'running')),
    progress: Number(data.progress) || 0,
    completedCount: (Number(counts.pass) || 0) + (Number(counts.fail) || 0),
    failedCount: Number(counts.fail) || 0,
    startedAt: data.started_at || undefined,
    completedAt: data.finished_at || undefined,
    error: data.error_message || undefined,
    terminalReason: data.terminal_reason || undefined,
    blockedReason: blockedReason.value || undefined,
    resumeRequired: resumeRequired.value,
  })

  batchItems.value
    .filter(item => ['pass', 'fail'].includes(item.status) && item.unittest_task_id)
    .forEach(item => { void loadItemReport(item) })

  if (isDone && stopBatchPolling.value) {
    stopBatchPolling.value()
    stopBatchPolling.value = null
  }
}

async function cancelBatchTask() {
  if (!isCurrentAccount() || !batchTaskId.value || cancelling.value) return
  const taskId = batchTaskId.value
  cancelling.value = true
  try {
    // The endpoint only publishes the cancellation intent; the dispatcher
    // stops the running child and finalizes the batch with
    // terminal_reason=CANCELLED, which handleBatchPollData then reflects.
    await apiCancelBatchTask(taskId)
    if (!isCurrentAccount() || batchTaskId.value !== taskId) return
    ElMessage.info('Cancellation requested - stopping the current item...')
  } catch (error) {
    if (!isCurrentAccount() || batchTaskId.value !== taskId) return
    cancelling.value = false
    ElMessage.error(error?.message || 'Batch task could not be cancelled')
  }
}

async function resumeBlockedBatch() {
  if (!isCurrentAccount()) return false
  const taskId = batchTaskId.value
  const detailItems = Array.isArray(batchDetail.value?.items) ? batchDetail.value.items : batchItems.value
  const itemNeedsResume = detailItems.some(item => item?.resume_required)
  if (!batchTaskId.value || (!resumeRequired.value && !batchDetail.value?.resume_required && !itemNeedsResume)) {
    return false
  }

  try {
    await apiResumeBatchTask(taskId)
    if (!isCurrentAccount() || batchTaskId.value !== taskId) return false
    authPromptShown.value = false
    resumeRequired.value = false
    blockedReason.value = ''
    executionError.value = ''
    updateBatchTask({ status: 'running', resumeRequired: false, blockedReason: null, error: null })
    startBatchPolling(batchTaskId.value)
    return true
  } catch (error) {
    if (!isCurrentAccount() || batchTaskId.value !== taskId) return false
    executionError.value = error?.message || 'Batch task could not be resumed'
    updateBatchTask({ status: 'failed', error: executionError.value })
    ElMessage.error(executionError.value)
    return false
  }
}

defineExpose({ resumeBlockedBatch })

async function loadItemReport(item, { force = false } = {}) {
  if (!isCurrentAccount() || !item?.item_id || !item.unittest_task_id) return
  const taskId = batchTaskId.value
  if (!force && itemReports.value.has(item.item_id)) return
  if (itemReportLoading.value.has(item.item_id)) return
  itemReportLoading.value = new Set([...itemReportLoading.value, item.item_id])
  try {
    const child = await apiGetTask(item.unittest_task_id)
    if (!isCurrentAccount() || batchTaskId.value !== taskId) return
    const nextReports = new Map(itemReports.value)
    nextReports.set(item.item_id, buildReport(item, child))
    itemReports.value = nextReports
  } catch (error) {
    if (!isCurrentAccount() || batchTaskId.value !== taskId) return
    // Mirrors the unit-test history behavior: a failed fetch keeps any
    // previously loaded report and never caches a placeholder, so the next
    // selection retries instead of showing fabricated zeros forever.
    console.warn('[BatchTestWorkspace] Failed to load item report:', error)
  } finally {
    if (isCurrentAccount() && batchTaskId.value === taskId) {
      const nextLoading = new Set(itemReportLoading.value)
      nextLoading.delete(item.item_id)
      itemReportLoading.value = nextLoading
    }
  }
}

// Selecting a queue row always re-fetches that item's report from the
// server, matching the unit-test history's forced hydration on selection.
function selectQueueTask(item) {
  selectedTaskId.value = item.id
  const backendItem = item?.backendItem
  if (backendItem?.unittest_task_id && ['pass', 'fail'].includes(backendItem.status)) {
    void loadItemReport(backendItem, { force: true })
  }
}

function selectQueueTaskForFile(file) {
  const item = queueItems.value.find(candidate => candidate.id === file?.id)
  if (item) selectQueueTask(item)
}

function fileQueueState(file) {
  const item = queueItems.value.find(candidate => candidate.id === file?.id)
  return item?.state || 'pending'
}

function fileQueueLabel(file) {
  if (isEmptySource(file)) return 'Empty file'
  if (!isFileSelected(file.id)) return 'Excluded'
  return stateLabelMap[fileQueueState(file)] || 'Queued'
}

async function prepareUploadFiles(files) {
  const uploads = []
  const sourcePaths = []
  const sourceMode = !isLocalFileSelectorHost(window.location.hostname) || files.some(source => (
    source.file instanceof Blob && !isAbsolutePath(source.fullPath || source.path)
  )) ? 'upload' : 'project'
  for (const source of files) {
    const sourcePath = source.fullPath || source.path || ''
    let blob = source.file instanceof Blob ? source.file : null
    if (!blob) {
      if (!isAbsolutePath(sourcePath)) {
        throw new Error('Select the source files again to restore their upload contents.')
      }
      const response = await fetch(`${LOCAL_SERVICE_URL}/read-file`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: sourcePath }),
      })
      const data = await response.json()
      if (!response.ok || !data.success) {
        throw new Error(data.error || `Unable to read ${source.name}`)
      }
      blob = new Blob([data.content], { type: 'text/plain' })
    }

    const filename = source.name || sourcePath.replace(/\\/g, '/').split('/').pop()
    const file = blob instanceof File && blob.name === filename
      ? blob
      : new File([blob], filename, { type: blob.type || 'text/plain' })
    uploads.push({ file, name: filename })
    sourcePaths.push(sourceMode === 'upload' ? source.relativePath || filename : sourcePath)
  }
  return { uploads, sourcePaths, sourceMode }
}

async function submitBatchTask(files, localTaskId) {
  try {
    const { uploads, sourcePaths, sourceMode } = await prepareUploadFiles(files)
    if (!isCurrentAccount() || props.activeTask?.id !== localTaskId) return
    const response = await apiCreateBatchTask(uploads, { source_paths: sourcePaths, source_mode: sourceMode })
    if (!isCurrentAccount() || props.activeTask?.id !== localTaskId) return
    batchTaskId.value = response.batch_task_id
    batchDetail.value = response
    batchItems.value = Array.isArray(response.items) ? response.items : []
    executionError.value = ''
    updateBatchTask({
      id: localTaskId,
      status: response.status || 'queued',
      progress: Number(response.progress) || 0,
      completedCount: Number(response.counts?.pass) || 0,
      failedCount: Number(response.counts?.fail) || 0,
      batchTaskId: response.batch_task_id,
    })
    startBatchPolling(response.batch_task_id)
  } catch (error) {
    if (!isCurrentAccount() || props.activeTask?.id !== localTaskId) return
    executionError.value = error?.message || 'Unable to create batch task'
    previewRunStarted.value = true
    updateBatchTask({ id: localTaskId, status: 'idle', progress: 0, error: executionError.value })
    ElMessage.error(executionError.value)
  }
}

function isAbsolutePath(path = '') {
  return /^([A-Za-z]:[\\/]|\\\\|\/)/.test(String(path))
}

function authHeaders() {
  const token = localStorage.getItem('token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

function toApiUrl(path = '') {
  if (/^https?:\/\//i.test(path)) return path
  if (path.startsWith('/api/')) return path
  return `/api${path.startsWith('/') ? path : `/${path}`}`
}

function toNumber(value, fallback = 0) {
  const number = Number(value)
  return Number.isFinite(number) ? number : fallback
}

function formatCoverage(value) {
  return value === null || value === undefined ? 'N/A' : `${toNumber(value).toFixed(1)}%`
}

function buildReport(item, childResponse) {
  const raw = childResponse?.result || {}
  const coverage = raw.coverage_report || {}
  const cliSummary = raw.cli_summary || {}
  const cliCoverage = cliSummary.coverage || {}
  const targets = {
    line: toNumber(cliCoverage.line_target, 90),
    branch: toNumber(cliCoverage.branch_target, 80),
    function: toNumber(cliCoverage.function_target, 80),
  }
  const line = coverage.line_coverage ?? cliCoverage.line ?? item?.result_summary?.line_coverage
  const branchAvailable = coverage.branch_coverage_applicable !== false && (
    coverage.branches_total > 0 || coverage.branch_coverage !== null && coverage.branch_coverage !== undefined
  )
  const functionAvailable = Number(coverage.functions_total || 0) > 0
  const branch = branchAvailable ? (coverage.branch_coverage ?? cliCoverage.branch) : null
  const func = functionAvailable ? (coverage.function_coverage ?? cliCoverage.function) : null
  const testFiles = Array.isArray(raw.test_files) ? raw.test_files : []
  const savedFiles = Array.isArray(raw.saved_files) ? raw.saved_files : []
  const generatedFiles = (testFiles.length ? testFiles : savedFiles.map(filename => ({ filename })))
    .map(file => {
      const name = typeof file === 'string' ? file.split(/[\\/]/).pop() : (file.filename || file.path || 'generated-test')
      const extension = getExtension(name).replace('.', '').toUpperCase() || 'FILE'
      return { type: extension, name, action: 'Created', extClass: `ext-${extension.toLowerCase()}` }
    })
  const testCount = toNumber(raw.test_count ?? raw.test_results?.total ?? item?.result_summary?.test_count)
  const passedCount = toNumber(raw.passed_count ?? raw.test_results?.passed ?? item?.result_summary?.passed_count)
  const compileSuccess = raw.compile_success ?? item?.result_summary?.compile_success ?? childResponse?.status === 'completed'
  const passRate = testCount > 0 ? Math.round((passedCount / testCount) * 100) : 0
  const coverageMet = cliSummary.result?.coverage_met ?? (
    line !== null && line !== undefined && toNumber(line) >= targets.line
    && (branch === null || branch === undefined || toNumber(branch) >= targets.branch)
    && func !== null && func !== undefined && toNumber(func) >= targets.function
  )
  const summaryText = cliSummary.summary || childResponse?.message || item?.message || 'No summary was provided by the task.'
  const whatWasDone = Array.isArray(cliSummary.what_was_done) ? cliSummary.what_was_done : [
    `Processed ${item?.filename || 'source file'}`,
    ...(generatedFiles.length ? [`Generated ${generatedFiles.length} test file(s)`] : []),
    ...(compileSuccess ? ['Compilation and test execution completed'] : ['Compilation or test execution did not complete successfully']),
  ]
  return {
    coverage: toNumber(line),
    layer: raw.layer || 'Detected layer unavailable',
    framework: raw.framework || raw.test_framework || 'Unit Test',
    miniMetrics: [
      { key: 'branch', name: 'Branch', val: branch === null ? null : toNumber(branch), c1: '#6366f1', c2: '#a5b4fc' },
      { key: 'func', name: 'Function', val: func === null ? null : toNumber(func), c1: '#0ea5e9', c2: '#7dd3fc' },
    ],
    kpiMetrics: [
      { label: 'Pass Rate', value: `${passRate}%`, icon: '✓', tone: passRate === 100 ? 'kpi-green' : 'kpi-amber' },
      { label: 'Functions', value: String(Array.isArray(raw.functions_tested) ? raw.functions_tested.length : 0), icon: '⬡', tone: 'kpi-indigo' },
      { label: 'Files', value: String(generatedFiles.length), icon: '◎', tone: 'kpi-blue' },
      { label: 'Tests', value: String(testCount), icon: '↻', tone: 'kpi-amber' },
    ],
    generatedFiles,
    compileSuccess: Boolean(compileSuccess),
    passRate,
    passedCount,
    testCount,
    coverageMet: Boolean(coverageMet),
    coverageTargets: targets,
    coverageMetrics: { line, branch, function: func },
    workflow: {
      whatWasDone,
      summarySections: [
        { title: 'Conclusion', content: summaryText },
        { title: 'Generated artifacts status', content: generatedFiles.length ? `${generatedFiles.length} generated file(s) returned by the task.` : 'The task returned no generated files.' },
        { title: 'Quality / risk signal', content: cliSummary.issues?.length ? cliSummary.issues.join(' ') : (coverageMet ? 'Coverage targets were met.' : 'Coverage targets were not fully met or coverage was unavailable.') },
        { title: 'Recommendation', content: cliSummary.next_steps?.length ? cliSummary.next_steps.join(' ') : 'Review the generated artifacts and execution log before integration.' },
      ],
    },
  }
}

function createEmptyReport(item = null, message = '') {
  const summary = item?.result_summary || {}
  return buildReport(item, {
    status: item?.status === 'pass' ? 'completed' : 'failed',
    message: message || item?.message || 'Report is not available yet.',
    result: {
      compile_success: summary.compile_success ?? false,
      test_count: summary.test_count ?? 0,
      passed_count: summary.passed_count ?? 0,
      coverage_report: { line_coverage: summary.line_coverage ?? 0 },
      test_files: [],
    },
  })
}

const isSelecting = computed(() => selectingMode.value !== '')

function isEmptySource(file) {
  return file.file instanceof Blob ? file.file.size === 0 : file.size === 0
}

const emptySourceFiles = computed(() => sourceFiles.value.filter(isEmptySource))
const selectableFiles = computed(() => sourceFiles.value.filter(file => !isEmptySource(file)))

const selectedFiles = computed(() => {
  return selectableFiles.value.filter(file => selectedFileIds.value.has(file.id))
})

const isAllSelected = computed(() => (
  selectableFiles.value.length > 0 &&
  selectableFiles.value.every(file => selectedFileIds.value.has(file.id))
))

const isPartiallySelected = computed(() => (
  selectedFiles.value.length > 0 &&
  selectedFiles.value.length < selectableFiles.value.length
))

const queueItems = computed(() => {
  return selectedFiles.value.map((file, index) => {
    const backendItem = findBatchItem(file, index)
    const state = previewRunStarted.value || hasExecutionState.value
      ? getPreviewState(index, backendItem)
      : 'pending'
    return {
      ...file,
      id: file.id,
      indexLabel: String(index + 1).padStart(2, '0'),
      command: createCommandPayload(file),
      output: backendItem?.report_url || 'Available after execution',
      target: file.relativePath,
      state,
      itemId: backendItem?.item_id || null,
      fullPath: file.fullPath || file.path || file.relativePath,
      backendItem,
    }
  })
})

const selectedTask = computed(() => {
  if (!queueItems.value.length) return null
  return queueItems.value.find(item => item.id === selectedTaskId.value) || queueItems.value[0]
})

const selectedTaskReport = computed(() => {
  const item = selectedTask.value?.backendItem || null
  const report = item ? itemReports.value.get(item.item_id) : null
  return report || createEmptyReport(item)
})

const summaryTitle = computed(() => {
  if (selectedFiles.value.length === 0) return 'Waiting for file selection'
  if (taskStatus.value === 'cancelled') return 'Batch execution cancelled'
  if (!previewRunStarted.value) return 'Queue is ready'
  if (isTaskBusy.value) return 'Batch running'
  return 'Batch finished'
})

const summaryDescription = computed(() => {
  if (selectedFiles.value.length === 0) {
    return 'Pick one file or select a folder, then choose the files to include.'
  }
  if (taskStatus.value === 'cancelled') {
    return 'The batch was cancelled before all selected files completed.'
  }
  if (!previewRunStarted.value) {
    return 'The selected files will be submitted in the same top-to-bottom order shown in the queue.'
  }
  return ''
})

const metrics = computed(() => [
  { label: 'Selected', value: String(selectedFiles.value.length) },
  { label: 'Passed', value: String(queueItems.value.filter(item => item.state === 'pass').length) },
  { label: 'Failed', value: String(queueItems.value.filter(item => item.state === 'fail').length) },
  { label: 'Queued', value: String(queueItems.value.filter(item => ['pending', 'queued'].includes(item.state)).length) }
])

const stateLabelMap = {
  pass: 'Passed',
  fail: 'Failed',
  running: 'Running',
  pending: 'Queued',
  queued: 'Queued'
}

const selectedTaskStateTitle = computed(() => {
  if (!selectedTask.value) return ''
  const stateMap = {
    running: 'Test generation in progress',
    fail: 'Generation failed',
    pending: 'Queued for execution',
    queued: 'Queued for execution'
  }
  return stateMap[selectedTask.value.state] || ''
})

const selectedTaskStateDescription = computed(() => {
  if (!selectedTask.value) return ''
  const item = selectedTask.value.backendItem
  if (item?.error_message || item?.message) return item.error_message || item.message
  const descMap = {
    running: 'The AI agent is analyzing the source file and generating unit tests.',
    fail: 'An error occurred during test generation. Check the logs for details.',
    pending: 'This file is waiting in the queue. It will be processed when ready.',
    queued: 'This file is waiting in the queue. It will be processed when ready.'
  }
  return descMap[selectedTask.value.state] || ''
})

function donutStyle(pct, circumference) {
  const offset = circumference - (pct / 100) * circumference
  return {
    strokeDasharray: circumference,
    strokeDashoffset: offset,
    transition: 'stroke-dashoffset 1s ease'
  }
}

function downloadTaskLog() {
  if (!selectedTask.value) {
    ElMessage.warning('No task selected')
    return
  }

  if (selectedTask.value.state === 'running') {
    ElMessage.warning('Task is still running, please wait until completion')
    return
  }

  if (selectedTask.value.state === 'pending') {
    ElMessage.warning('Task has not started yet')
    return
  }

  const logUrl = selectedTask.value.backendItem?.cli_log_url
  if (!logUrl) {
    ElMessage.warning('The execution log is not available for this file')
    return
  }

  fetch(toApiUrl(logUrl), { headers: authHeaders() }).then(async response => {
    if (!response.ok) throw new Error(`Log download failed (${response.status})`)
    const blob = await response.blob()
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `batch-test-${selectedTask.value.name}-${selectedTask.value.state}-${Date.now()}.md`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
    ElMessage.success('Log downloaded successfully')
  }).catch(error => {
    ElMessage.error(error?.message || 'Log download failed')
  })
}

async function selectFolderFromLocal() {
  if (!isLocalFileSelectorHost(window.location.hostname)) {
    folderInputRef.value?.click()
    return
  }
  selectingMode.value = 'folder'

  try {
    const response = await fetch(`${LOCAL_SERVICE_URL}/select-folder`, {
      method: 'POST'
    })
    const data = await response.json()

    if (data.success && Array.isArray(data.files)) {
      applySourceFiles(data.files.map(createFileFromService), data.path || '')
      ElMessage.success(`${data.files.length} source files loaded`)
      return
    }

    if (!isSelectionCanceled(data.error)) {
      ElMessage.warning(data.error || 'Folder selection failed')
    }
  } catch {
    folderInputRef.value?.click()
  } finally {
    selectingMode.value = ''
  }
}

async function addFileFromLocal() {
  if (!isLocalFileSelectorHost(window.location.hostname)) {
    fileInputRef.value?.click()
    return
  }
  selectingMode.value = 'file'

  try {
    const response = await fetch(`${LOCAL_SERVICE_URL}/select-file`, {
      method: 'POST'
    })
    const data = await response.json()

    if (data.success && (Array.isArray(data.files) || data.path)) {
      const serviceFiles = Array.isArray(data.files) && data.files.length > 0
        ? data.files
        : [{
          name: data.name,
          path: data.path,
          relative_path: data.name,
          extension: getExtension(data.name)
        }]
      const addedCount = appendSourceFiles(serviceFiles.map(createFileFromService), data.directory || '')
      if (addedCount > 0) {
        ElMessage.success(`${addedCount} file${addedCount > 1 ? 's' : ''} added`)
      }
      return
    }

    if (!isSelectionCanceled(data.error)) {
      ElMessage.warning(data.error || 'File selection failed')
    }
  } catch {
    fileInputRef.value?.click()
  } finally {
    selectingMode.value = ''
  }
}

function onBrowserFolderSelect(event) {
  const files = Array.from(event.target.files || [])
  const mappedFiles = files
    .filter(file => isDisplayFile(file.name))
    .map(createFileFromBrowser)
    .sort((left, right) => left.relativePath.localeCompare(right.relativePath))

  const rootName = mappedFiles[0]?.relativePath?.split('/')[0] || ''
  applySourceFiles(mappedFiles, rootName)
  event.target.value = ''
}

function onBrowserFileSelect(event) {
  const files = Array.from(event.target.files || [])
    .filter(file => isDisplayFile(file.name))
    .map(createFileFromBrowser)

  const sourceLabel = files.length > 1
    ? 'Selected files'
    : getParentPath(files[0]?.relativePath || '')
  const addedCount = appendSourceFiles(files, sourceLabel)
  if (addedCount > 0) {
    ElMessage.success(`${addedCount} file${addedCount > 1 ? 's' : ''} added`)
  }
  event.target.value = ''
}

function applySourceFiles(files, rootPath) {
  if (isTaskBusy.value) {
    ElMessage.warning('The batch is running; wait for completion before changing files')
    return sourceFiles.value.length
  }
  if (blockTerminalEdit()) return sourceFiles.value.length
  const normalizedFiles = files.filter(Boolean)
  sourceFiles.value = normalizedFiles
  sourceRoot.value = normalizePath(rootPath)

  // Only auto-select .c and .cpp files
  const autoSelectExtensions = ['.c', '.cpp']
  selectedFileIds.value = new Set(
    sourceFiles.value
      .filter(file => autoSelectExtensions.includes(file.extension.toLowerCase()))
      .map(file => file.id)
  )

  selectedTaskId.value = selectedFiles.value[0]?.id || ''
  resetExecutionForInputChange()

  if (sourceFiles.value.length === 0) {
    ElMessage.warning('No .c or .cpp files found')
  }

  return normalizedFiles.length
}

function appendSourceFiles(files, rootPath) {
  if (isTaskBusy.value) {
    ElMessage.warning('The batch is running; wait for completion before changing files')
    return 0
  }
  if (blockTerminalEdit()) return 0
  const incomingFiles = files.filter(Boolean)
  if (incomingFiles.length === 0) {
    ElMessage.warning('No .c or .cpp files found')
    return 0
  }

  const existingIds = new Set(sourceFiles.value.map(file => file.id))
  const newFiles = incomingFiles.filter(file => !existingIds.has(file.id))

  if (newFiles.length === 0) {
    ElMessage.info('Selected file is already in the list')
    return 0
  }

  const rootLabel = normalizePath(rootPath)
  if (!sourceRoot.value) {
    sourceRoot.value = rootLabel || 'Selected files'
  } else if (rootLabel && sourceRoot.value !== rootLabel) {
    sourceRoot.value = 'Mixed selected files'
  }

  sourceFiles.value = [...sourceFiles.value, ...newFiles]
  selectedFileIds.value = new Set([
    ...selectedFileIds.value,
    ...newFiles.map(file => file.id)
  ])
  selectedTaskId.value = selectedTaskId.value && selectedFileIds.value.has(selectedTaskId.value)
    ? selectedTaskId.value
    : selectedFiles.value[0]?.id || ''
  resetExecutionForInputChange()

  return newFiles.length
}

function createFileFromService(file, index = 0) {
  const path = normalizePath(file.path || file.relative_path || file.name || '')
  const relativePath = normalizePath(file.relative_path || file.relativePath || file.name || path)
  const name = file.name || relativePath.split('/').pop() || `source-${index + 1}`
  const extension = (file.extension || getExtension(name)).toLowerCase()

  if (!DISPLAY_EXTENSIONS.includes(extension)) return null

  return {
    id: path || relativePath || `${name}-${index}`,
    name,
    path,
    relativePath,
    size: typeof file.size === 'number' ? file.size : undefined,
    extension
  }
}

function createFileFromBrowser(file, index = 0) {
  const relativePath = normalizePath(file.webkitRelativePath || file.name)
  const name = file.name || relativePath.split('/').pop() || `source-${index + 1}`
  const extension = getExtension(name)

  return {
    id: relativePath || `${name}-${index}`,
    file,
    name,
    path: relativePath,
    relativePath,
    size: file.size,
    extension
  }
}

function isFileSelected(fileId) {
  return selectedFiles.value.some(file => file.id === fileId)
}

function toggleFile(fileId) {
  if (isTaskBusy.value) {
    ElMessage.warning('The batch is running; wait for completion before changing files')
    return
  }
  if (blockTerminalEdit()) return
  const file = sourceFiles.value.find(source => source.id === fileId)
  if (!file || isEmptySource(file)) return
  const nextIds = new Set(selectedFileIds.value)
  if (nextIds.has(fileId)) {
    nextIds.delete(fileId)
  } else {
    nextIds.add(fileId)
  }

  selectedFileIds.value = nextIds
  selectedTaskId.value = selectedFiles.value[0]?.id || ''
  resetExecutionForInputChange()
}

function toggleAllSelected() {
  if (sourceFiles.value.length === 0) return
  if (isTaskBusy.value) {
    ElMessage.warning('The batch is running; wait for completion before changing files')
    return
  }
  if (blockTerminalEdit()) return

  selectedFileIds.value = isAllSelected.value
    ? new Set()
    : new Set(selectableFiles.value.map(file => file.id))
  selectedTaskId.value = selectedFiles.value[0]?.id || ''
  resetExecutionForInputChange()
}

function updateFilePath(fileId, nextPath) {
  if (isTaskBusy.value) return
  if (blockTerminalEdit()) return
  const normalizedPath = normalizePath(nextPath)
  sourceFiles.value = sourceFiles.value.map(file => {
    if (file.id !== fileId) return file

    const fallbackName = normalizedPath.split('/').pop() || file.name
    return {
      ...file,
      path: normalizedPath,
      relativePath: normalizedPath || file.relativePath,
      name: fallbackName,
      extension: getExtension(fallbackName) || file.extension,
    }
  })
  resetExecutionForInputChange()
}

function removeFile(fileId) {
  if (isTaskBusy.value) {
    ElMessage.warning('The batch is running; wait for completion before changing files')
    return
  }
  if (blockTerminalEdit()) return
  const removedFile = sourceFiles.value.find(file => file.id === fileId)
  sourceFiles.value = sourceFiles.value.filter(file => file.id !== fileId)

  const nextSelectedIds = new Set(selectedFileIds.value)
  nextSelectedIds.delete(fileId)
  selectedFileIds.value = nextSelectedIds

  if (sourceFiles.value.length === 0) {
    sourceRoot.value = ''
  }

  selectedTaskId.value = selectedTaskId.value === fileId || !selectedFileIds.value.has(selectedTaskId.value)
    ? selectedFiles.value[0]?.id || ''
    : selectedTaskId.value
  resetExecutionForInputChange()

  if (removedFile) {
    ElMessage.info(`${removedFile.name} removed`)
  }
}

function removeSelectedFiles() {
  if (isTaskBusy.value) {
    ElMessage.warning('The batch is running; wait for completion before changing files')
    return
  }
  if (blockTerminalEdit()) return
  const removedCount = selectedFiles.value.length
  if (removedCount === 0) return

  sourceFiles.value = sourceFiles.value.filter(file => !selectedFileIds.value.has(file.id))
  selectedFileIds.value = new Set()
  selectedTaskId.value = ''
  resetExecutionForInputChange()

  if (sourceFiles.value.length === 0) {
    sourceRoot.value = ''
  }

  ElMessage.info(`${removedCount} selected file${removedCount > 1 ? 's' : ''} removed`)
}

function startSerialPreview() {
  if (!isCurrentAccount()) return
  if (selectedFiles.value.length === 0) {
    ElMessage.warning('Select at least one file first')
    return
  }
  if (isTaskBusy.value) return
  if (isTaskTerminal.value) return

  previewRunStarted.value = true
  selectedTaskId.value = selectedFiles.value[0].id
  // A rerun creates a new durable batch.  Clear the previous ID before the
  // request so a refresh or failed upload cannot resume/poll stale work.
  batchTaskId.value = null
  executionError.value = ''
  resumeRequired.value = false
  blockedReason.value = ''
  authPromptShown.value = false
  batchDetail.value = null
  batchItems.value = []
  itemReports.value = new Map()
  itemReportLoading.value = new Set()
  if (stopBatchPolling.value) {
    stopBatchPolling.value()
    stopBatchPolling.value = null
  }
  emit('run-requested', {
    id: props.activeTask?.id,
    title: generateTaskTitle(),
    selectedFiles: selectedFiles.value,
    totalCount: selectedFiles.value.length,
    batchTaskId: null,
    items: [],
    batchDetail: null,
    requestedAt: new Date().toISOString()
  })
  // Upload and task creation happen after the parent records the local task.
  // The visible workspace remains responsive while the durable batch ID is
  // being allocated by the backend.
  void submitBatchTask(selectedFiles.value, props.activeTask?.id)
}

function createCommandPayload(file) {
  return `batch_unittest.py --file "${file.path || file.relativePath}" --continue-on-fail`
}

function getExtension(filename = '') {
  const dotIndex = filename.lastIndexOf('.')
  return dotIndex >= 0 ? filename.slice(dotIndex).toLowerCase() : ''
}

function getParentPath(path = '') {
  const normalizedPath = normalizePath(path)
  const splitIndex = normalizedPath.lastIndexOf('/')
  return splitIndex > 0 ? normalizedPath.slice(0, splitIndex) : ''
}

function isSelectionCanceled(errorMessage = '') {
  const text = String(errorMessage).toLowerCase()
  return text.includes('cancel')
}

function isSourceFile(filename = '') {
  return SOURCE_EXTENSIONS.includes(getExtension(filename))
}

function isDisplayFile(filename = '') {
  return DISPLAY_EXTENSIONS.includes(getExtension(filename))
}

function normalizePath(path = '') {
  return String(path || '').replace(/\\/g, '/')
}

onBeforeUnmount(() => {
  disposed = true
  if (stopBatchPolling.value) {
    stopBatchPolling.value()
    stopBatchPolling.value = null
  }
})
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.batch-test-workspace {
  height: 100%;
  min-height: 0;
  display: grid;
  grid-template-columns: minmax(240px, 0.78fr) minmax(300px, 1fr) minmax(260px, 0.88fr);
  gap: 12px;
  padding: clamp(8px, 0.8vw, 12px);
  overflow: hidden;
  color: #1f2937;
  background:
    linear-gradient(135deg, rgba(14, 165, 233, 0.08), transparent 28%),
    linear-gradient(315deg, rgba(22, 163, 74, 0.08), transparent 30%),
    #f8fafc;
}

.hidden-input {
  display: none;
}

.setup-column,
.queue-column,
.report-column {
  min-height: 0;
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.94);
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
}

.setup-column,
.report-column {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px;
  overflow-y: auto;
}

.report-placeholder {
  min-height: 260px;
  align-items: center;
  justify-content: center;
  padding: 28px 22px;
  text-align: center;
  color: #64748b;
}

.report-placeholder .summary-icon {
  margin-bottom: 4px;
  background: linear-gradient(135deg, #64748b, #94a3b8);
  box-shadow: none;
}

.report-placeholder h3 {
  margin: 0;
  color: #334155;
  font-size: 17px;
}

.report-placeholder p {
  max-width: 280px;
  margin: 6px 0 0;
  font-size: 12px;
  line-height: 1.55;
}

.queue-column {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 18px;
  overflow: hidden;
}

.batch-file-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-height: 0;
  overflow-y: auto;
  padding-right: 2px;
}

.batch-file-row {
  width: 100%;
  min-width: 0;
  display: grid;
  grid-template-columns: 18px 18px minmax(0, 1fr) auto 30px;
  align-items: start;
  gap: 8px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 9px;
  background: #ffffff;
  cursor: pointer;
}

.batch-file-row.selected {
  border-color: #93c5fd;
  background: #f8fbff;
}

.batch-file-main {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.batch-file-name {
  width: fit-content;
  max-width: 100%;
  border: 0;
  padding: 0;
  overflow: hidden;
  color: #334155;
  background: transparent;
  font: inherit;
  font-size: 12px;
  font-weight: 700;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.batch-file-name:not(:disabled) { cursor: pointer; }
.batch-file-name:not(:disabled):hover { color: #1d4ed8; }
.batch-file-name:disabled { opacity: 1; }

.batch-file-main em {
  overflow: hidden;
  color: #64748b;
  font-size: 11px;
  font-style: normal;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.batch-file-path {
  display: grid;
  grid-template-columns: 32px minmax(0, 1fr);
  align-items: center;
  gap: 6px;
  color: #94a3b8;
  font-size: 10px;
}

.batch-file-path input {
  width: 100%;
  min-width: 0;
  height: 25px;
  border: 1px solid #e2e8f0;
  border-radius: 4px;
  padding: 0 6px;
  color: #475569;
  background: #f8fafc;
  font: 10px Consolas, Monaco, monospace;
}

.batch-file-state {
  min-height: 24px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: #64748b;
  font-size: 10px;
  white-space: nowrap;
}

.batch-file-state .pending-dot { width: 7px; height: 7px; }

.workspace-title {
  display: flex;
  align-items: center;
  gap: 12px;
  padding-bottom: 4px;
}

.workspace-icon,
.summary-icon {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  background: linear-gradient(135deg, #0f766e, #2563eb);
  box-shadow: 0 8px 18px rgba(15, 118, 110, 0.22);
  flex-shrink: 0;
}

.workspace-title h2,
.queue-header h3,
.summary-card h3,
.detail-header h3 {
  margin: 0;
  color: #0f172a;
  font-size: 18px;
  font-weight: 800;
  line-height: 1.2;
}

.workspace-title p,
.summary-card p {
  margin: 5px 0 0;
  color: #64748b;
  font-size: 12px;
  line-height: 1.45;
}

.picker-card,
.report-card {
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  background: #ffffff;
}

.picker-card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 14px;
}

.picker-card {
  min-height: 0;
  flex: 1;
}

.section-heading,
.queue-header,
.detail-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.section-label,
.eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: #64748b;
  font-size: 11px;
  font-weight: 800;
  line-height: 1.2;
  text-transform: uppercase;
}

.file-counter,
.run-mode,
.status-badge {
  display: inline-flex;
  align-items: center;
  min-height: 24px;
  padding: 3px 9px;
  border-radius: 999px;
  white-space: nowrap;
  font-size: 11px;
  font-weight: 800;
}

.file-counter {
  color: #0f766e;
  background: #ccfbf1;
}

.picker-actions {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.picker-button,
.select-all-control,
.select-toggle-button,
.remove-selected-button,
.remove-file-button,
.run-button {
  border: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-family: inherit;
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease, transform 0.15s ease;
}

.picker-button {
  min-height: 38px;
  gap: 7px;
  border: 1px solid #dbe3ef;
  border-radius: 10px;
  color: #334155;
  background: #f8fafc;
  font-size: 12px;
  font-weight: 800;
}

.picker-button.primary {
  border-color: #99f6e4;
  color: #0f766e;
  background: #f0fdfa;
}

.picker-button:hover:not(:disabled) {
  border-color: #93c5fd;
  color: #1d4ed8;
  background: #eff6ff;
}

.picker-button:disabled,
.selection-toolbar button:disabled,
.run-button:disabled,
.selection-mark:disabled,
.file-path-editor input:disabled,
.remove-file-button:disabled {
  cursor: not-allowed;
  opacity: 0.54;
}

/* File names stay fully readable in the read-only archive view. */
.file-tree-name-button:disabled {
  cursor: default;
  opacity: 1;
}

.readonly-hint {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  border: 1px solid #fde68a;
  border-radius: 8px;
  padding: 7px 10px;
  color: #92400e;
  background: #fffbeb;
  font-size: 11.5px;
  font-weight: 700;
}

.empty-files-hint,
.execution-error {
  overflow-wrap: anywhere;
}

.execution-error {
  margin: 0;
  border: 1px solid #fecaca;
  border-radius: 8px;
  padding: 10px;
  color: #991b1b;
  background: #fef2f2;
  font-size: 12px;
}

.source-root {
  display: flex;
  flex-direction: column;
  gap: 4px;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 9px 10px;
  background: #f8fafc;
}

.source-root span {
  color: #94a3b8;
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
}

.source-root strong {
  overflow-wrap: anywhere;
  color: #334155;
  font-family: Consolas, Monaco, monospace;
  font-size: 11.5px;
  line-height: 1.35;
}

.selection-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 10px;
  border-top: 1px solid #eef2f7;
  padding-top: 10px;
}

.selection-actions {
  display: inline-flex;
  align-items: center;
  justify-content: flex-end;
  flex: 1 1 220px;
  flex-wrap: wrap;
  gap: 6px;
}

.select-all-control {
  gap: 8px;
  min-height: 28px;
  padding: 0;
  color: #475569;
  background: transparent;
  font-size: 12px;
  font-weight: 800;
}

.select-all-control:hover:not(:disabled) {
  color: #0f766e;
}

.selection-mark {
  width: 17px;
  height: 17px;
  border: 1.5px solid #cbd5e1;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  background: #ffffff;
  flex-shrink: 0;
  transition: background 0.15s ease, border-color 0.15s ease, box-shadow 0.15s ease;
}

.selection-mark.checked {
  border-color: #0f766e;
  background: #0f766e;
  box-shadow: 0 0 0 3px rgba(15, 118, 110, 0.12);
}

.selection-mark.mixed {
  border-color: #2563eb;
  background: #2563eb;
}

.selection-mark-dash {
  width: 7px;
  height: 2px;
  border-radius: 999px;
  background: #ffffff;
}

.select-toggle-button,
.remove-selected-button {
  min-height: 28px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 800;
}

.select-toggle-button {
  border: 1px solid #cbd5e1;
  color: #0f766e;
  background: #ffffff;
}

.select-toggle-button:hover:not(:disabled) {
  border-color: #0f766e;
  background: #f0fdfa;
}

.remove-selected-button {
  gap: 5px;
  border: 1px solid #fed7aa;
  color: #c2410c;
  background: #fff7ed;
}

.remove-selected-button:hover:not(:disabled) {
  border-color: #fb923c;
  background: #ffedd5;
}

.empty-picker,
.empty-queue,
.detail-empty {
  min-height: 170px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border: 1px dashed #cbd5e1;
  border-radius: 12px;
  padding: 18px;
  color: #94a3b8;
  text-align: center;
}

.empty-picker {
  flex: 1;
}

.empty-picker-icon {
  width: 46px;
  height: 46px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #0f766e;
  background: #ccfbf1;
}

.empty-picker strong,
.empty-queue strong,
.detail-empty strong {
  color: #334155;
  font-size: 13px;
}

.empty-picker span,
.empty-queue span,
.detail-empty span {
  max-width: 270px;
  font-size: 12px;
  line-height: 1.45;
}

.file-tree {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-height: 0;
  overflow-y: auto;
  padding-right: 2px;
}

.file-tree-row {
  width: 100%;
  min-height: 58px;
  display: grid;
  grid-template-columns: 18px 18px minmax(0, 1fr) 30px;
  align-items: start;
  gap: 8px;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 8px 9px;
  background: #ffffff;
  font-family: inherit;
  text-align: left;
  transition: border-color 0.15s ease, background 0.15s ease;
}

.file-tree-row:hover,
.file-tree-row.selected {
  border-color: #93c5fd;
  background: #f8fbff;
}

.file-icon {
  margin-top: 4px;
  color: #94a3b8;
}

.file-tree-content {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.file-tree-header {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}

.file-tree-name-button {
  min-width: 0;
  flex: 1;
  border: none;
  padding: 0;
  overflow: hidden;
  color: #334155;
  background: transparent;
  font-family: Consolas, Monaco, monospace;
  font-size: 12px;
  font-weight: 700;
  line-height: 1.25;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
}

.file-tree-name-button:focus-visible {
  border-radius: 4px;
  outline: 2px solid rgba(37, 99, 235, 0.3);
  outline-offset: 2px;
}

.file-path-editor {
  display: grid;
  grid-template-columns: 32px minmax(0, 1fr);
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.file-path-editor span {
  color: #94a3b8;
  font-size: 10px;
  font-weight: 800;
  text-transform: uppercase;
}

.file-path-editor input {
  width: 100%;
  min-width: 0;
  height: 26px;
  border: 1px solid #dbeafe;
  border-radius: 7px;
  padding: 0 8px;
  color: #475569;
  background: #f8fbff;
  font-family: Consolas, Monaco, monospace;
  font-size: 11px;
}

.file-path-editor input:focus {
  border-color: #2563eb;
  background: #ffffff;
  outline: none;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

.ext-badge {
  min-width: 38px;
  border-radius: 6px;
  padding: 2px 6px;
  color: #0f766e;
  background: #ccfbf1;
  font-size: 10px;
  font-weight: 900;
  text-align: center;
}

.remove-file-button {
  width: 28px;
  height: 26px;
  border: 1px solid #fecaca;
  border-radius: 7px;
  color: #dc2626;
  background: #fff7f7;
}

.remove-file-button:hover:not(:disabled),
.remove-file-button:focus-visible:not(:disabled) {
  color: #dc2626;
  background: #fee2e2;
  border-color: #fca5a5;
  outline: none;
}

.run-actions {
  display: flex;
  gap: 8px;
  flex-shrink: 0;
}

.run-button {
  height: 42px;
  flex: 1;
  flex-shrink: 0;
  gap: 8px;
  border-radius: 10px;
  color: #ffffff;
  background: #0f766e;
  box-shadow: 0 4px 10px rgba(15, 118, 110, 0.24);
  font-size: 14px;
  font-weight: 800;
}

.cancel-run-button {
  height: 42px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 0 16px;
  border: 1px solid #fca5a5;
  border-radius: 10px;
  background: #fef2f2;
  color: #dc2626;
  font-family: inherit;
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease, opacity 0.15s ease;
}

.cancel-run-button:hover:not(:disabled) {
  background: #fee2e2;
  border-color: #f87171;
}

.cancel-run-button:disabled {
  cursor: not-allowed;
  opacity: 0.65;
}

.run-button:hover:not(:disabled) {
  background: #115e59;
  box-shadow: 0 7px 14px rgba(15, 118, 110, 0.28);
  transform: translateY(-1px);
}

.run-mode {
  color: #0369a1;
  background: #e0f2fe;
  border: 1px solid #bae6fd;
}

.pipeline-strip {
  display: grid;
  gap: 7px;
}

.pipeline-dot {
  height: 8px;
  border-radius: 999px;
  background: #e5e7eb;
}

.pipeline-dot.pass {
  background: #22c55e;
}

.pipeline-dot.fail {
  background: #ef4444;
}

.pipeline-dot.running {
  background: #f59e0b;
  box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.16);
}

.pipeline-dot.queued {
  background: #8b5cf6;
}

.task-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-height: 0;
  overflow-y: auto;
  padding-right: 2px;
}

.task-row {
  width: 100%;
  min-height: 68px;
  display: grid;
  grid-template-columns: 42px minmax(0, 1fr) 104px;
  align-items: center;
  gap: 12px;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 10px 12px;
  background: #ffffff;
  cursor: pointer;
  font-family: inherit;
  text-align: left;
  transition: border-color 0.15s ease, background 0.15s ease, transform 0.15s ease;
}

.task-row:hover,
.task-row.selected {
  border-color: #93c5fd;
  background: #f8fbff;
}

.task-row.selected {
  transform: translateY(-1px);
  box-shadow: 0 8px 18px rgba(37, 99, 235, 0.09);
}

.task-index {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #0f766e;
  background: #ccfbf1;
  font-size: 12px;
  font-weight: 900;
}

.task-main {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.task-main strong {
  overflow: hidden;
  color: #1f2937;
  font-size: 14px;
  line-height: 1.25;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.task-main em {
  overflow: hidden;
  color: #64748b;
  font-family: Consolas, Monaco, monospace;
  font-size: 11px;
  font-style: normal;
  line-height: 1.3;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.task-status {
  display: inline-flex;
  align-items: center;
  justify-content: flex-end;
  gap: 5px;
  color: #64748b;
  font-size: 12px;
  font-weight: 800;
}

.task-row.pass .task-status {
  color: #16a34a;
}

.task-row.fail .task-status {
  color: #dc2626;
}

.task-row.running .task-status {
  color: #d97706;
}

.task-row.queued .task-status {
  color: #6d28d9;
}

.task-row.queued .pending-dot {
  background: #8b5cf6;
}

.mini-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid #fde68a;
  border-top-color: #f59e0b;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

.pending-dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background: #cbd5e1;
}

.summary-card {
  display: flex;
  gap: 12px;
  padding: 14px;
  background: linear-gradient(135deg, #ffffff, #f0fdfa);
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.metric-tile {
  min-height: 72px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 5px;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 12px;
  background: #ffffff;
}

.metric-tile span {
  color: #64748b;
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
}

.metric-tile strong {
  color: #0f172a;
  font-size: 23px;
  line-height: 1;
}

.detail-card {
  padding: 14px;
}

.status-badge.pass {
  color: #15803d;
  background: #dcfce7;
}

.status-badge.fail {
  color: #b91c1c;
  background: #fee2e2;
}

.status-badge.running {
  color: #d97706;
  background: #fef3c7;
}

.status-badge.queued {
  color: #6d28d9;
  background: #ede9fe;
}

.status-badge.pending {
  color: #64748b;
  background: #f1f5f9;
}

.detail-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 14px 0 0;
}

.detail-list div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.detail-list dt {
  color: #94a3b8;
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
}

.detail-list dd {
  margin: 0;
  overflow-wrap: anywhere;
  color: #334155;
  font-family: Consolas, Monaco, monospace;
  font-size: 12px;
  line-height: 1.45;
}

.detail-empty {
  padding: 20px;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* ── Hero banner (from UnittestWorkspace) ──────────────────────────────────── */
.hero-banner {
  position: relative;
  display: flex;
  gap: 20px;
  align-items: center;
  padding: 20px 22px;
  background: linear-gradient(135deg, #eef2ff 0%, #f0f9ff 100%);
  border: 1px solid #c7d2fe;
  border-radius: 14px;
  overflow: hidden;
}

.hero-glow {
  position: absolute;
  top: -40px;
  right: -40px;
  width: 180px;
  height: 180px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(99, 102, 241, 0.12) 0%, transparent 70%);
  pointer-events: none;
}

/* Donuts */
.hero-donuts {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  flex-shrink: 0;
}

.donut-wrap {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.main-donut {
  width: 110px;
  height: 110px;
}

.donut-svg {
  width: 110px;
  height: 110px;
  transform: rotate(-90deg);
}

.donut-track {
  fill: none;
  stroke: #e0e7ff;
  stroke-width: 8;
}

.donut-ring {
  fill: none;
  stroke: url(#grad-main);
  stroke-width: 8;
  stroke-linecap: round;
}

.main-ring {
  stroke-width: 9;
}

.donut-label {
  position: absolute;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.donut-pct {
  font-size: 20px;
  font-weight: 800;
  color: #3730a3;
  line-height: 1;
}

.donut-pct em {
  font-size: 12px;
  font-style: normal;
  color: #6366f1;
}

.donut-sub {
  font-size: 10px;
  color: #818cf8;
  font-weight: 600;
  letter-spacing: 0.5px;
  margin-top: 2px;
}

.mini-donuts {
  display: flex;
  gap: 16px;
}

.mini-donut-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.mini-svg {
  width: 56px;
  height: 56px;
  transform: rotate(-90deg);
}

.mini-label {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.mini-pct {
  font-size: 12px;
  font-weight: 700;
  color: #3730a3;
  line-height: 1.2;
}

.mini-sub {
  font-size: 10px;
  color: #94a3b8;
}

/* KPI grid */
.kpi-grid {
  flex: 1;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(90px, 1fr));
  gap: 10px;
}

.kpi-tile {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  padding: 12px 8px;
  border-radius: 10px;
  border: 1px solid transparent;
  transition: transform 0.15s;
}

.kpi-tile:hover {
  transform: translateY(-2px);
}

.kpi-icon {
  font-size: 16px;
  line-height: 1;
}

.kpi-val {
  font-size: 16px;
  font-weight: 800;
  line-height: 1.2;
}

.kpi-name {
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
}

.kpi-green {
  background: #f0fdf4;
  border-color: #bbf7d0;
}

.kpi-green .kpi-icon,
.kpi-green .kpi-val {
  color: #15803d;
}

.kpi-green .kpi-name {
  color: #4ade80;
}

.kpi-red {
  background: #fef2f2;
  border-color: #fecaca;
}

.kpi-red .kpi-icon,
.kpi-red .kpi-val {
  color: #dc2626;
}

.kpi-red .kpi-name {
  color: #f87171;
}

.kpi-indigo {
  background: #eef2ff;
  border-color: #c7d2fe;
}

.kpi-indigo .kpi-icon,
.kpi-indigo .kpi-val {
  color: #4338ca;
}

.kpi-indigo .kpi-name {
  color: #818cf8;
}

.kpi-blue {
  background: #f0f9ff;
  border-color: #bae6fd;
}

.kpi-blue .kpi-icon,
.kpi-blue .kpi-val {
  color: #0369a1;
}

.kpi-blue .kpi-name {
  color: #38bdf8;
}

.kpi-amber {
  background: #fffbeb;
  border-color: #fde68a;
}

.kpi-amber .kpi-icon,
.kpi-amber .kpi-val {
  color: #b45309;
}

.kpi-amber .kpi-name {
  color: #fbbf24;
}

/* Tag strip */
.tag-strip {
  display: flex;
  flex-wrap: wrap;
  gap: 7px;
}

.tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 10px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 500;
}

.tag-layer {
  background: #eef2ff;
  color: #4338ca;
  border: 1px solid #c7d2fe;
}

.tag-fw {
  background: #f0f9ff;
  color: #0369a1;
  border: 1px solid #bae6fd;
}

.tag-file {
  background: #f8fafc;
  color: #475569;
  border: 1px solid #e2e8f0;
}

/* Dark cards */
.dark-card {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  overflow: hidden;
}

.dark-card-title {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 11px 16px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  font-size: 12px;
  font-weight: 600;
  color: #334155;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.card-count {
  margin-left: auto;
  background: #e0e7ff;
  color: #4338ca;
  border-radius: 10px;
  padding: 1px 8px;
  font-size: 11px;
  font-weight: 600;
  text-transform: none;
  letter-spacing: 0;
}

/* Dot indicators */
.dot-green {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
  background: #16a34a;
  box-shadow: 0 0 4px #16a34a80;
}

/* File rows */
.file-row {
  border-bottom: 1px solid #f1f5f9;
}

.file-row:last-child {
  border-bottom: none;
}

.file-row-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 9px 16px;
  font-size: 13px;
}

.file-ext-badge {
  flex-shrink: 0;
  padding: 1px 7px;
  border-radius: 5px;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.5px;
}

.ext-cpp {
  background: #e0e7ff;
  color: #3730a3;
}

.ext-h {
  background: #fef9c3;
  color: #854d0e;
}

.ext-c {
  background: #dcfce7;
  color: #166534;
}

.file-row-name {
  flex: 1;
  color: #374151;
  font-size: 12.5px;
  font-family: 'Consolas', monospace;
}

.file-row-meta {
  font-size: 11px;
  color: #9ca3af;
}

/* CLI Summary */
.summary-inner {
  padding-bottom: 4px;
}

.summary-section {
  padding: 8px 16px 4px;
}

.summary-section-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.5px;
  color: #6366f1;
  text-transform: uppercase;
  margin-bottom: 6px;
}

.summary-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.summary-list li {
  font-size: 12.5px;
  color: #374151;
  line-height: 1.5;
}

.summary-kv {
  display: flex;
  gap: 8px;
  align-items: baseline;
  font-size: 12.5px;
  line-height: 1.7;
  margin-bottom: 6px;
}

.summary-kv-key {
  color: #6b7280;
  min-width: 140px;
  font-weight: 600;
}

.summary-kv-val {
  color: #374151;
  font-family: 'Consolas', monospace;
  font-size: 12px;
  word-break: break-all;
}

/* Task state panel (for running/failed/pending states) */
.task-state-panel {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 32px 20px;
  text-align: center;
}

.task-state-panel strong {
  color: #1f2937;
  font-size: 15px;
  font-weight: 700;
}

.task-state-panel span {
  color: #64748b;
  font-size: 12.5px;
  line-height: 1.6;
  max-width: 320px;
}

.task-state-panel.running {
  background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
  border: 1px solid #fde68a;
  border-radius: 12px;
}

.task-state-panel.fail {
  background: linear-gradient(135deg, #fef2f2 0%, #fff5f5 100%);
  border: 1px solid #fecaca;
  border-radius: 12px;
}

.task-state-panel.queued {
  background: linear-gradient(135deg, #f5f3ff 0%, #ede9fe 100%);
  border: 1px solid #ddd6fe;
  border-radius: 12px;
}

.task-state-panel.pending {
  background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  border: 1px solid #e2e8f0;
  border-radius: 12px;
}

.state-spinner {
  width: 26px;
  height: 26px;
  border: 3px solid #fde68a;
  border-top-color: #f59e0b;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

.payload-list {
  width: 100%;
  margin: 16px 0 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.payload-list div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.payload-list dt {
  color: #94a3b8;
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
}

.payload-list dd {
  margin: 0;
  overflow-wrap: anywhere;
  color: #334155;
  font-family: Consolas, Monaco, monospace;
  font-size: 11.5px;
  line-height: 1.45;
}

.payload-list.compact {
  margin-top: 12px;
  padding: 12px 14px;
  background: #f8fafc;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
}

/* Task report card */
.task-report-card {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.report-detail-header {
  padding-bottom: 0;
}

.report-detail-header > div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.report-detail-header h3 {
  margin: 0;
  color: #0f172a;
  font-size: 16px;
  font-weight: 800;
  line-height: 1.3;
}

/* Value color classes */
.val-green {
  color: #16a34a;
  font-weight: 600;
}

.val-amber {
  color: #d97706;
  font-weight: 600;
}

.val-red {
  color: #dc2626;
  font-weight: 600;
}

/* Coverage summary table */
.coverage-summary-table {
  width: 100%;
  max-width: 400px;
  table-layout: fixed;
  border-collapse: collapse;
  font-size: 12.5px;
  color: #374151;
  margin-top: 4px;
}

.coverage-summary-table th,
.coverage-summary-table td {
  padding: 6px 8px;
  border: 1px solid #e5e7eb;
  text-align: left;
}

.coverage-summary-table th {
  background: #f9fafb;
  color: #6b7280;
  font-weight: 700;
}

/* Summary subsections */
.summary-subsection {
  margin-bottom: 10px;
}

.summary-subsection:last-child {
  margin-bottom: 0;
}

.summary-subsection-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.35px;
  color: #4b5563;
  margin-bottom: 4px;
}

.summary-paragraph {
  margin: 0;
  max-width: 920px;
  padding: 10px 12px;
  border: 1px solid #eef2ff;
  border-radius: 8px;
  background: linear-gradient(180deg, #f8fafc 0%, #f9fafb 100%);
  font-size: 12.5px;
  color: #374151;
  line-height: 1.7;
  white-space: normal;
}

.summary-section-last {
  padding-bottom: 12px;
}

/* Download actions card */
.download-actions-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 16px;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  background: #ffffff;
}

.download-log-btn {
  width: 100%;
  min-height: 40px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border: 1px solid #93c5fd;
  border-radius: 10px;
  padding: 0 18px;
  color: #1d4ed8;
  background: #eff6ff;
  font-size: 13px;
  font-weight: 700;
  font-family: inherit;
  cursor: pointer;
  transition: all 0.15s ease;
}

.download-log-btn:hover {
  border-color: #60a5fa;
  background: #dbeafe;
  transform: translateY(-1px);
  box-shadow: 0 4px 10px rgba(29, 78, 216, 0.15);
}

.download-log-btn:active {
  transform: translateY(0);
}

.download-log-btn-disabled {
  cursor: not-allowed;
  opacity: 0.6;
  border-color: #cbd5e1;
  background: #f1f5f9;
  color: #64748b;
}

.download-log-btn-disabled:hover {
  border-color: #cbd5e1;
  background: #f1f5f9;
  transform: none;
  box-shadow: none;
}

.download-hint {
  font-size: 11px;
  color: #94a3b8;
  text-align: center;
  line-height: 1.4;
}

@media (max-width: 980px) {
  .batch-test-workspace {
    grid-template-columns: minmax(0, 0.82fr) minmax(0, 1.18fr);
    overflow-y: auto;
  }

  .report-column {
    grid-column: 1 / -1;
    min-height: 280px;
  }
}

@media (max-width: 860px) {
  .batch-test-workspace {
    grid-template-columns: minmax(0, 1fr);
    grid-auto-rows: max-content;
    align-content: start;
    overflow-y: auto;
  }

  .setup-column {
    min-height: 420px;
    overflow: visible;
  }

  .queue-column,
  .report-column {
    min-height: 280px;
    overflow: visible;
  }

  .task-row {
    grid-template-columns: 38px minmax(0, 1fr);
  }

  .task-status {
    grid-column: 2;
    justify-content: flex-start;
  }
}
</style>
