<template>
  <details
    v-if="traces.length"
    class="skill-runtime-trace"
  >
    <summary>Skill collaboration <span>{{ traces.length }} stage records</span></summary>
    <div
      v-for="trace in traces"
      :key="`${trace.stage}:${trace.scope}`"
      class="skill-stage"
    >
      <div class="skill-stage-heading">
        <strong>{{ trace.stage.replaceAll('_', ' ') }}</strong>
        <span
          class="skill-status"
          :class="trace.status"
        >{{ trace.status }}</span>
        <span>Attempt {{ trace.attempt || 1 }}</span>
      </div>
      <div
        v-if="trace.scope"
        class="skill-scope"
        :title="trace.scope"
      >
        {{ trace.scope }}
      </div>
      <div
        v-for="skill in trace.skills || []"
        :key="skill.name"
        class="skill-record"
      >
        <span>{{ skill.name }} v{{ skill.version }}</span>
        <code :title="skill.sha256">{{ skill.sha256?.slice(0, 12) }}</code>
        <span v-if="skill.references?.length">{{ skill.references.length }} references</span>
      </div>
      <details
        v-for="action in trace.actions || []"
        :key="action.name"
        class="skill-action"
      >
        <summary>{{ action.name }} <span>{{ action.status }}</span></summary>
        <pre v-if="action.evidence">{{ JSON.stringify(action.evidence, null, 2) }}</pre>
      </details>
      <div
        v-for="skip in trace.skipped || []"
        :key="skip.name"
        class="skill-warning"
      >
        {{ skip.name }}: {{ skip.reason }}
      </div>
      <div
        v-if="trace.error"
        class="skill-warning"
      >
        {{ trace.error }}
      </div>
    </div>
  </details>
</template>

<script setup>
defineProps({ traces: { type: Array, default: () => [] } })
</script>

<style scoped>
.skill-runtime-trace { border-top: 1px solid var(--el-border-color, #e5e7eb); padding: 10px 0; font-size: 12px; min-width: 0; }
summary { cursor: pointer; overflow-wrap: anywhere; }
summary span { margin-left: 8px; color: var(--el-text-color-secondary, #6b7280); }
.skill-stage { padding: 10px 0; border-bottom: 1px solid var(--el-border-color, #e5e7eb); min-width: 0; }
.skill-stage-heading, .skill-record { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 5px; }
.skill-stage-heading strong { text-transform: capitalize; font-size: 12px; }
.skill-status { color: #0369a1; }
.skill-status.failed, .skill-warning { color: #b91c1c; }
.skill-status.cancelled { color: #6b7280; }
.skill-scope, .skill-warning, .skill-record { overflow-wrap: anywhere; word-break: break-word; }
.skill-scope { margin-bottom: 6px; color: var(--el-text-color-secondary, #6b7280); }
.skill-action { padding: 4px 0; }
pre { white-space: pre-wrap; overflow-wrap: anywhere; max-height: 240px; overflow: auto; font-size: 11px; margin: 6px 0; }
</style>
