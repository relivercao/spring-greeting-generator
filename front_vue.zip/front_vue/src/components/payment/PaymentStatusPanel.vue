<template>
  <div class="status-panel">
    <!-- ═══ Success ═══ -->
    <div
      v-if="phase === 'success'"
      class="panel-card"
    >
      <div class="state-wrap">
        <div class="state-circle success">
          <svg
            viewBox="0 0 24 24"
            fill="none"
          >
            <path
              d="M4.5 12.75l6 6 9-13.5"
              stroke="currentColor"
              stroke-width="2.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </div>
        <p class="state-title">
          Payment successful
        </p>
        <div
          v-if="order"
          class="result-summary"
        >
          <div class="summary-row">
            <span>Order no.</span>
            <span class="mono">{{ order.out_trade_no || order.id }}</span>
          </div>
          <div class="summary-row">
            <span>Paid</span>
            <span class="strong">{{ formatMoney(order.pay_amount ?? order.amount) }}</span>
          </div>
          <div
            v-if="creditedAmount > 0"
            class="summary-row"
          >
            <span>Credited to balance</span>
            <span class="credit">+{{ formatMoney(creditedAmount) }}</span>
          </div>
        </div>
        <el-button
          type="primary"
          @click="emit('done')"
        >
          Done
        </el-button>
      </div>
    </div>

    <!-- ═══ Cancelled / Expired / Failed / Refunded ═══ -->
    <div
      v-else-if="phase === 'failure'"
      class="panel-card"
    >
      <div class="state-wrap">
        <div
          class="state-circle"
          :class="failureTone"
        >
          <svg
            v-if="orderStatus === 'cancelled'"
            viewBox="0 0 24 24"
            fill="none"
          >
            <path
              d="M6 18L18 6M6 6l12 12"
              stroke="currentColor"
              stroke-width="2.5"
              stroke-linecap="round"
            />
          </svg>
          <svg
            v-else
            viewBox="0 0 24 24"
            fill="none"
          >
            <circle
              cx="12"
              cy="12"
              r="9"
              stroke="currentColor"
              stroke-width="2"
            />
            <path
              d="M12 7v5l3.5 2"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
            />
          </svg>
        </div>
        <p class="state-title">
          {{ failureTitle }}
        </p>
        <p class="state-desc">
          {{ failureDescription }}
        </p>
        <div class="state-actions">
          <el-button
            type="primary"
            @click="emit('retry')"
          >
            Try again
          </el-button>
          <el-button @click="emit('done')">
            Back
          </el-button>
        </div>
      </div>
    </div>

    <!-- ═══ Crediting (paid / recharging) ═══ -->
    <div
      v-else-if="phase === 'processing'"
      class="panel-card"
    >
      <div class="state-wrap">
        <div class="spinner" />
        <p class="state-title">
          Payment received
        </p>
        <p class="state-desc">
          Your balance is being credited. This usually takes a few seconds.
        </p>
      </div>
    </div>

    <!-- ═══ Waiting: QR or popup ═══ -->
    <template v-else>
      <div
        v-if="qrTarget"
        class="panel-card qr-card"
      >
        <p class="qr-title">
          {{ scanTitle }}
        </p>
        <div
          class="qr-frame"
          :class="brandClass"
        >
          <img
            v-if="qrImageSrc"
            :src="qrImageSrc"
            alt="Payment QR code"
            class="qr-image"
          >
          <div
            v-else
            class="qr-pending"
          >
            <div class="spinner small" />
          </div>
          <span class="qr-logo">
            <span
              class="qr-logo-dot"
              :class="brandClass"
            >{{ brandGlyph }}</span>
          </span>
        </div>
        <p class="qr-hint">
          {{ scanHint }}
        </p>
        <el-button
          v-if="payUrl"
          class="reopen-btn"
          @click="openPayPage"
        >
          Open payment page
        </el-button>
      </div>

      <div
        v-else
        class="panel-card"
      >
        <div class="state-wrap">
          <div class="spinner" />
          <p class="state-desc">
            Complete the payment in the opened window.
            This page updates automatically.
          </p>
          <el-button
            v-if="payUrl"
            @click="openPayPage"
          >
            Open payment page
          </el-button>
        </div>
      </div>

      <!-- Countdown card -->
      <div class="panel-card countdown-card">
        <p class="countdown-label">
          Order expires in
        </p>
        <p
          class="countdown-value"
          :class="{ urgent: remainingSeconds !== null && remainingSeconds <= 60 }"
        >
          {{ countdownDisplay }}
        </p>
        <p class="countdown-sub">
          Waiting for payment · refreshing every 3s
        </p>
      </div>

      <div class="order-brief">
        <div class="brief-row">
          <span>Order no.</span>
          <span class="mono">{{ order?.out_trade_no || order?.id || '-' }}</span>
        </div>
        <div class="brief-row">
          <span>Amount</span>
          <span class="strong">{{ formatMoney(order?.pay_amount ?? order?.amount) }}</span>
        </div>
      </div>

      <el-button
        class="cancel-btn"
        :loading="cancelling"
        @click="cancelOrder"
      >
        Cancel order
      </el-button>
    </template>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import QRCode from 'qrcode'
import { apiOrderDetail, apiCancelOrder } from '@/api/payment'

const POLL_INTERVAL_MS = 3000

const props = defineProps({
  orderId: { type: [String, Number], required: true },
  // Optional initial order snapshot to render before the first poll lands
  initialOrder: { type: Object, default: null },
  paymentType: { type: String, default: '' },
})

const emit = defineEmits(['done', 'retry', 'success'])

const order = ref(props.initialOrder)
const qrDataUrl = ref('')
const cancelling = ref(false)
const nowTs = ref(Date.now())

let pollTimer = null
let clockTimer = null
let pollInFlight = false

// ── Status classification ──
const FAILURE_STATUSES = ['expired', 'cancelled', 'failed', 'refunded']
const PROCESSING_STATUSES = ['paid', 'recharging']

const orderStatus = computed(() => order.value?.status || '')

const phase = computed(() => {
  if (orderStatus.value === 'completed') return 'success'
  if (FAILURE_STATUSES.includes(orderStatus.value)) return 'failure'
  if (PROCESSING_STATUSES.includes(orderStatus.value)) return 'processing'
  return 'waiting'
})

const creditedAmount = computed(() => Number(order.value?.credited_amount) || 0)

const payUrl = computed(() => order.value?.pay_url || '')

const effectivePaymentType = computed(
  () => order.value?.payment_type || props.paymentType || '',
)

const isAlipay = computed(() => effectivePaymentType.value.toLowerCase().includes('alipay'))
const isWxpay = computed(() => {
  const key = effectivePaymentType.value.toLowerCase()
  return key.includes('wxpay') || key.includes('wechat')
})

const brandClass = computed(() => {
  if (isAlipay.value) return 'alipay'
  if (isWxpay.value) return 'wxpay'
  return 'generic'
})

const brandGlyph = computed(() => {
  if (isAlipay.value) return '支'
  if (isWxpay.value) return '微'
  return '¥'
})

const scanTitle = computed(() => {
  if (isAlipay.value) return 'Scan with Alipay'
  if (isWxpay.value) return 'Scan with WeChat'
  return 'Scan to pay'
})

const scanHint = computed(() => {
  if (isAlipay.value) return 'Open Alipay, tap Scan, and scan this code.'
  if (isWxpay.value) return 'Open WeChat, tap the + menu, and scan this code.'
  return 'Scan the QR code with your payment app.'
})

const qrTarget = computed(() => {
  const qr = order.value?.qr_code
  return typeof qr === 'string' && qr.trim() ? qr.trim() : ''
})

const qrImageSrc = computed(() => {
  if (!qrTarget.value) return ''
  return /^https?:\/\//i.test(qrTarget.value) ? qrTarget.value : qrDataUrl.value
})

const remainingSeconds = computed(() => {
  if (!order.value?.expires_at || orderStatus.value !== 'pending') return null
  const ms = parseServerTime(order.value.expires_at).getTime() - nowTs.value
  return Number.isFinite(ms) ? Math.max(0, Math.floor(ms / 1000)) : null
})

const countdownDisplay = computed(() => {
  if (remainingSeconds.value === null) return '--:--'
  const m = Math.floor(remainingSeconds.value / 60)
  const s = remainingSeconds.value % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
})

const failureTone = computed(() => (orderStatus.value === 'cancelled' ? 'muted' : 'warn'))

const failureTitle = computed(() => {
  const titles = {
    expired: 'Order expired',
    cancelled: 'Order cancelled',
    refunded: 'Order refunded',
    failed: 'Payment failed',
  }
  return titles[orderStatus.value] || 'Payment not completed'
})

const failureDescription = computed(() => {
  const descriptions = {
    expired: 'This order was not paid in time and has expired. No money was deducted.',
    cancelled: 'The order was cancelled. You can create a new one at any time.',
    refunded: 'This order has been refunded.',
  }
  if (descriptions[orderStatus.value]) return descriptions[orderStatus.value]
  return order.value?.failed_reason || 'The payment could not be completed. Please try again.'
})

// ── Helpers ──
function parseServerTime(value) {
  if (typeof value !== 'string') return new Date(value)
  // Server datetimes are UTC but may omit the timezone marker
  return new Date(/Z$|[+-]\d{2}:?\d{2}$/.test(value) ? value : `${value}Z`)
}

function formatMoney(value) {
  const num = Number(value)
  return `¥${(Number.isFinite(num) ? num : 0).toFixed(2)}`
}

function stopTimers() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null }
  if (clockTimer) { clearInterval(clockTimer); clockTimer = null }
}

function applyOrder(next) {
  const previousStatus = order.value?.status
  order.value = next
  if (next?.status === 'completed' && previousStatus !== 'completed') {
    stopTimers()
    emit('success', next)
  } else if (next && (next.status === 'completed' || FAILURE_STATUSES.includes(next.status))) {
    stopTimers()
  }
}

async function pollStatus() {
  if (pollInFlight || phase.value === 'success' || phase.value === 'failure') return
  pollInFlight = true
  try {
    const next = await apiOrderDetail(props.orderId)
    applyOrder(next)
  } catch {
    // Transient polling errors are ignored; the next tick retries
  } finally {
    pollInFlight = false
  }
}

function openPayPage() {
  if (!payUrl.value) return
  window.open(payUrl.value, '_blank', 'noopener')
}

async function cancelOrder() {
  if (cancelling.value) return
  cancelling.value = true
  try {
    await apiCancelOrder(props.orderId)
    stopTimers()
    const next = { ...(order.value || {}), status: 'cancelled' }
    order.value = next
    applyOrder(next)
  } catch (e) {
    ElMessage.error(e.message || 'Failed to cancel the order.')
  } finally {
    cancelling.value = false
  }
}

// Render non-URL QR payloads locally
watch(qrTarget, async (target) => {
  qrDataUrl.value = ''
  if (!target || /^https?:\/\//i.test(target)) return
  try {
    qrDataUrl.value = await QRCode.toDataURL(target, { width: 220, margin: 1 })
  } catch {
    ElMessage.error('Failed to render the payment QR code.')
  }
})

onMounted(async () => {
  if (!order.value) await pollStatus()
  if (phase.value === 'waiting' || phase.value === 'processing') {
    clockTimer = setInterval(() => { nowTs.value = Date.now() }, 1000)
    pollTimer = setInterval(pollStatus, POLL_INTERVAL_MS)
  }
})

onUnmounted(stopTimers)
</script>

<style scoped>
.status-panel { display: flex; flex-direction: column; gap: 14px; }

.panel-card {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 24px;
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.03);
}

/* ── State screens ── */
.state-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 18px 8px;
  text-align: center;
}

.state-circle {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.state-circle svg { width: 30px; height: 30px; }

.state-circle.success { background: #dcfce7; color: #16a34a; }
.state-circle.warn { background: #ffedd5; color: #ea580c; }
.state-circle.muted { background: #f3f4f6; color: #6b7280; }

.state-title { font-size: 18px; font-weight: 800; color: #111827; margin: 0; }

.state-desc { font-size: 13px; color: #6b7280; margin: 0; }

.state-actions { display: flex; gap: 12px; margin-top: 4px; }

.result-summary {
  width: 100%;
  max-width: 340px;
  background: #f8fafc;
  border-radius: 12px;
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.summary-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  color: #6b7280;
}

.summary-row .mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  color: #111827;
  font-weight: 600;
}

.summary-row .strong { color: #111827; font-weight: 700; }

.summary-row .credit { color: #16a34a; font-weight: 700; }

/* ── Spinner ── */
.spinner {
  width: 36px;
  height: 36px;
  border: 4px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  animation: sp-spin 0.9s linear infinite;
}

.spinner.small { width: 28px; height: 28px; border-width: 3px; }

@keyframes sp-spin { to { transform: rotate(360deg); } }

/* ── QR card ── */
.qr-card { display: flex; flex-direction: column; align-items: center; gap: 12px; }

.qr-title { font-size: 16px; font-weight: 700; color: #111827; margin: 0; }

.qr-frame {
  position: relative;
  border: 2.5px solid #e5e7eb;
  border-radius: 14px;
  padding: 14px;
  background: #ffffff;
}

.qr-frame.alipay { border-color: #1677ff; background: #f0f7ff; }
.qr-frame.wxpay { border-color: #09bb07; background: #f0fdf0; }

.qr-image {
  width: 200px;
  height: 200px;
  border-radius: 8px;
  background: #ffffff;
  display: block;
}

.qr-pending {
  width: 200px;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.qr-logo {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}

.qr-logo-dot {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 17px;
  font-weight: 700;
  box-shadow: 0 0 0 3px #ffffff, 0 2px 8px rgba(15, 23, 42, 0.25);
}

.qr-logo-dot.alipay { background: #1677ff; }
.qr-logo-dot.wxpay { background: #09bb07; }
.qr-logo-dot.generic { background: #6b7280; }

.qr-hint { font-size: 12px; color: #6b7280; margin: 0; text-align: center; }

.reopen-btn { margin-top: 2px; }

/* ── Countdown card ── */
.countdown-card { text-align: center; padding: 18px 24px; }

.countdown-label { font-size: 13px; color: #6b7280; margin: 0; }

.countdown-value {
  font-size: 34px;
  font-weight: 800;
  color: #111827;
  margin: 6px 0 0;
  font-variant-numeric: tabular-nums;
  letter-spacing: 1px;
}

.countdown-value.urgent { color: #dc2626; }

.countdown-sub { font-size: 11px; color: #9ca3af; margin: 6px 0 0; }

/* ── Order brief + cancel ── */
.order-brief {
  background: #ffffff;
  border: 1px solid #e8edf3;
  border-radius: 14px;
  padding: 14px 18px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.brief-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  color: #6b7280;
}

.brief-row .mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  color: #111827;
}

.brief-row .strong { color: #111827; font-weight: 700; }

.cancel-btn { width: 100%; }
</style>
