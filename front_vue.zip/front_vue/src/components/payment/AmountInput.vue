<template>
  <div class="amount-input">
    <!-- Quick amount chips -->
    <div class="block">
      <label class="block-label">
        {{ isCustomOnly ? 'Recharge amount' : 'Quick amounts' }}
      </label>
      <div
        v-if="filteredAmounts.length"
        class="chip-grid"
      >
        <button
          v-for="amt in filteredAmounts"
          :key="amt"
          type="button"
          class="chip"
          :class="{ active: modelValue === amt }"
          @click="selectAmount(amt)"
        >
          <span class="chip-currency">¥</span>{{ amt }}
        </button>
      </div>
    </div>

    <!-- Custom amount -->
    <div class="block">
      <label class="block-label">Custom amount</label>
      <div class="custom-wrap">
        <span class="currency-prefix">¥</span>
        <input
          type="text"
          inputmode="decimal"
          class="custom-field"
          :value="customText"
          :placeholder="placeholderText"
          @input="handleInput"
        >
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  modelValue: { type: Number, default: null },
  amounts: {
    type: Array,
    default: () => [10, 20, 50, 100, 200, 500, 1000],
  },
  min: { type: Number, default: 0 },
  max: { type: Number, default: 0 },
})

const emit = defineEmits(['update:modelValue'])

const customText = ref('')

// 0 means "no limit" for either bound
const filteredAmounts = computed(() =>
  props.amounts.filter(
    (a) => (props.min <= 0 || a >= props.min) && (props.max <= 0 || a <= props.max),
  ),
)

const isCustomOnly = computed(() => filteredAmounts.value.length === 0)

const placeholderText = computed(() => {
  if (props.min > 0 && props.max > 0) return `¥ ${props.min} - ${props.max}`
  if (props.min > 0) return `At least ¥ ${props.min}`
  if (props.max > 0) return `Up to ¥ ${props.max}`
  return 'Enter an amount'
})

// Digits with at most two decimals
const AMOUNT_PATTERN = /^\d*(\.\d{0,2})?$/

function selectAmount(amt) {
  customText.value = String(amt)
  emit('update:modelValue', amt)
}

function handleInput(event) {
  const value = event.target.value
  if (!AMOUNT_PATTERN.test(value)) return
  customText.value = value
  if (value === '') {
    emit('update:modelValue', null)
    return
  }
  const num = parseFloat(value)
  emit('update:modelValue', Number.isFinite(num) && num > 0 ? num : null)
}

watch(
  () => props.modelValue,
  (value) => {
    if (value !== null && String(value) !== customText.value) {
      customText.value = String(value)
    }
  },
  { immediate: true },
)
</script>

<style scoped>
.amount-input { display: flex; flex-direction: column; gap: 18px; }

.block-label {
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 10px;
}

.chip-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.chip {
  border: 1.5px solid #e5e7eb;
  border-radius: 10px;
  background: #ffffff;
  padding: 12px 8px;
  font-size: 15px;
  font-weight: 600;
  color: #374151;
  cursor: pointer;
  transition: border-color 0.15s, background 0.15s, color 0.15s, box-shadow 0.15s;
}

.chip:hover { border-color: #93c5fd; }

.chip.active {
  border-color: #2563eb;
  background: #eff6ff;
  color: #1d4ed8;
  box-shadow: 0 2px 10px rgba(37, 99, 235, 0.14);
}

.chip-currency { font-size: 12px; margin-right: 1px; opacity: 0.7; }

.custom-wrap { position: relative; }

.currency-prefix {
  position: absolute;
  left: 14px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 15px;
  font-weight: 600;
  color: #9ca3af;
  pointer-events: none;
}

.custom-field {
  width: 100%;
  border: 1.5px solid #e5e7eb;
  border-radius: 10px;
  padding: 12px 14px 12px 34px;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
  box-sizing: border-box;
}

.custom-field::placeholder { font-weight: 400; color: #9ca3af; font-size: 14px; }

.custom-field:focus {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
}

@media (max-width: 768px) {
  .chip-grid { grid-template-columns: repeat(3, 1fr); }
}
</style>
