<template>
  <div class="method-selector">
    <label class="selector-label">Payment method</label>
    <div class="method-grid">
      <button
        v-for="method in methods"
        :key="method.value"
        type="button"
        class="method-btn"
        :class="[brandClass(method.value), { selected: selected === method.value }]"
        @click="emit('select', method.value)"
      >
        <span class="method-icon">
          <!-- Alipay: blue rounded mark -->
          <svg
            v-if="isAlipay(method.value)"
            viewBox="0 0 24 24"
            fill="none"
          >
            <rect
              x="1"
              y="4"
              width="22"
              height="16"
              rx="3"
              fill="#1677FF"
            />
            <path
              d="M8.2 8.1c2.6.9 5 2.2 6.9 3.9.7.6 1.7.5 2.2-.2.4-.7.2-1.5-.5-2C14.4 7.6 11.4 6 8.2 5.2c-.8-.2-1.6.3-1.7 1.1-.1.8.4 1.5 1.2 1.8h.5Z"
              fill="#fff"
            />
            <path
              d="M5.5 13.6c3.5 2 8 3.3 12.4 3.6.9.1 1.5-.5 1.6-1.3 0-.8-.6-1.4-1.4-1.5-4-.3-8.1-1.5-11.2-3.2-.7-.4-1.6-.2-2 .5-.4.8-.1 1.6.6 1.9Z"
              fill="#fff"
            />
          </svg>
          <!-- WeChat Pay: green chat bubbles -->
          <svg
            v-else-if="isWxpay(method.value)"
            viewBox="0 0 24 24"
            fill="none"
          >
            <path
              d="M9.2 3C4.9 3 1.5 5.9 1.5 9.5c0 2 1.1 3.8 2.9 5l-.7 2.3 2.6-1.4c.9.3 1.9.4 2.9.4h.5c-.2-.5-.3-1.1-.3-1.7 0-3.4 3.2-6.1 7.2-6.1h.6C16.6 5.2 13.3 3 9.2 3Zm-2.5 4a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm5 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z"
              fill="#09BB07"
            />
            <path
              d="M16.5 9.5c-3.3 0-6 2.2-6 5 0 1.6.9 3 2.3 3.9l-.6 2 2.2-1.2c.7.2 1.4.3 2.1.3 3.3 0 6-2.2 6-5s-2.7-5-6-5Zm-2.1 3a.8.8 0 1 1 0 1.6.8.8 0 0 1 0-1.6Zm4.2 0a.8.8 0 1 1 0 1.6.8.8 0 0 1 0-1.6Z"
              fill="#09BB07"
            />
          </svg>
          <!-- Generic card mark -->
          <svg
            v-else
            viewBox="0 0 24 24"
            fill="none"
          >
            <rect
              x="2"
              y="5"
              width="20"
              height="14"
              rx="2.5"
              stroke="#6b7280"
              stroke-width="2"
            />
            <path
              d="M2 9.5h20"
              stroke="#6b7280"
              stroke-width="2"
            />
          </svg>
        </span>
        <span class="method-text">
          <span class="method-name">{{ method.label }}</span>
          <span
            v-if="feeRate > 0"
            class="method-fee"
          >Fee {{ feeRate }}%</span>
        </span>
        <span
          v-if="selected === method.value"
          class="check-dot"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
          >
            <path
              d="M5 12.5l4.5 4.5L19 7.5"
              stroke="#fff"
              stroke-width="3"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </span>
      </button>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  methods: { type: Array, default: () => [] },
  selected: { type: String, default: '' },
  feeRate: { type: Number, default: 0 },
})

const emit = defineEmits(['select'])

function isAlipay(value) {
  return String(value).toLowerCase().includes('alipay')
}

function isWxpay(value) {
  const key = String(value).toLowerCase()
  return key.includes('wxpay') || key.includes('wechat')
}

function brandClass(value) {
  if (isAlipay(value)) return 'brand-alipay'
  if (isWxpay(value)) return 'brand-wxpay'
  return 'brand-generic'
}
</script>

<style scoped>
.selector-label {
  display: block;
  font-size: 13px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 10px;
}

.method-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

@media (min-width: 640px) {
  .method-grid { grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); }
}

.method-btn {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  border: 1.5px solid #e5e7eb;
  border-radius: 12px;
  background: #ffffff;
  padding: 12px 14px;
  min-height: 60px;
  cursor: pointer;
  transition: border-color 0.15s, background 0.15s, box-shadow 0.15s;
}

.method-btn:hover { border-color: #d1d5db; }

.method-btn.brand-alipay.selected {
  border-color: #1677ff;
  background: #f0f7ff;
  box-shadow: 0 2px 12px rgba(22, 119, 255, 0.16);
}

.method-btn.brand-wxpay.selected {
  border-color: #09bb07;
  background: #f0fdf0;
  box-shadow: 0 2px 12px rgba(9, 187, 7, 0.16);
}

.method-btn.brand-generic.selected {
  border-color: #2563eb;
  background: #eff6ff;
  box-shadow: 0 2px 12px rgba(37, 99, 235, 0.16);
}

.method-icon { display: inline-flex; width: 28px; height: 28px; flex-shrink: 0; }

.method-icon svg { width: 100%; height: 100%; }

.method-text { display: flex; flex-direction: column; align-items: flex-start; line-height: 1.2; }

.method-name { font-size: 15px; font-weight: 700; color: #1f2937; }

.method-fee { font-size: 11px; color: #9ca3af; margin-top: 2px; }

.check-dot {
  position: absolute;
  top: -7px;
  right: -7px;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.brand-alipay .check-dot { background: #1677ff; }
.brand-wxpay .check-dot { background: #09bb07; }
.brand-generic .check-dot { background: #2563eb; }

.check-dot svg { width: 12px; height: 12px; }
</style>
