<template>
  <div
    class="plan-card"
    :class="[`accent-${accentIndex % 4}`, { selected }]"
    @click="emit('select')"
  >
    <!-- Colored top accent bar -->
    <div class="accent-bar" />

    <div class="card-body">
      <!-- Header: name + badge + price -->
      <div class="card-head">
        <div class="head-left">
          <div class="name-row">
            <h3 class="plan-name">
              {{ plan.name }}
            </h3>
            <span
              v-if="isFeatured"
              class="featured-badge"
            >Best value</span>
          </div>
          <p
            v-if="plan.description"
            class="plan-desc"
          >
            {{ plan.description }}
          </p>
        </div>
        <div class="head-right">
          <div class="price-row">
            <span class="price-currency">¥</span>
            <span class="price-now">{{ formatAmount(plan.price) }}</span>
          </div>
          <span class="validity">{{ validitySuffix }}</span>
          <div
            v-if="discountPercent > 0"
            class="discount-row"
          >
            <span class="price-origin">¥{{ formatAmount(plan.original_price) }}</span>
            <span class="discount-badge">-{{ discountPercent }}%</span>
          </div>
        </div>
      </div>

      <!-- Credited quota block -->
      <div class="quota-block">
        <div class="quota-row">
          <span class="quota-label">Balance credited</span>
          <span class="quota-value credit">¥{{ formatAmount(creditedBalance) }}</span>
        </div>
        <div
          v-if="bonusPercent > 0"
          class="quota-row"
        >
          <span class="quota-label">Extra bonus</span>
          <span class="quota-value bonus">+{{ bonusPercent }}%</span>
        </div>
      </div>

      <!-- Features -->
      <ul
        v-if="features.length"
        class="feature-list"
      >
        <li
          v-for="feature in features"
          :key="feature"
        >
          <svg
            class="feature-check"
            viewBox="0 0 24 24"
            fill="none"
          >
            <path
              d="M4.5 12.75l6 6 9-13.5"
              stroke="currentColor"
              stroke-width="2.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
          <span>{{ feature }}</span>
        </li>
      </ul>

      <!-- CTA -->
      <button
        type="button"
        class="select-btn"
        :class="{ active: selected }"
      >
        {{ selected ? 'Selected' : 'Select plan' }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  plan: { type: Object, required: true },
  selected: { type: Boolean, default: false },
  accentIndex: { type: Number, default: 0 },
})

const emit = defineEmits(['select'])

const features = computed(() => {
  const raw = props.plan.features
  if (Array.isArray(raw)) return raw.filter(Boolean)
  return []
})

const isFeatured = computed(() => features.value.length >= 3 || discountPercent.value >= 20)

const discountPercent = computed(() => {
  const price = Number(props.plan.price)
  const original = Number(props.plan.original_price)
  if (!Number.isFinite(original) || original <= price || original <= 0) return 0
  return Math.round((1 - price / original) * 100)
})

const creditedBalance = computed(() => Number(props.plan.credited_amount) || Number(props.plan.price) || 0)

const bonusPercent = computed(() => {
  const price = Number(props.plan.price)
  if (!Number.isFinite(price) || price <= 0) return 0
  const extra = creditedBalance.value - price
  if (extra <= 0.005) return 0
  return Math.round((extra / price) * 100)
})

const validitySuffix = computed(() => {
  const days = Number(props.plan.validity_days) || 0
  return days > 0 ? `/ ${days} days` : '/ permanent'
})

function formatAmount(value) {
  const num = Number(value)
  return (Number.isFinite(num) ? num : 0).toFixed(2).replace(/\.00$/, '')
}
</script>

<style scoped>
.plan-card {
  position: relative;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1.5px solid #e5e7eb;
  border-radius: 14px;
  background: #ffffff;
  cursor: pointer;
  transition: border-color 0.18s, box-shadow 0.18s, transform 0.15s;
}

.plan-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 26px rgba(15, 23, 42, 0.10);
}

.plan-card.selected {
  border-color: #2563eb;
  box-shadow: 0 6px 20px rgba(37, 99, 235, 0.18);
}

/* Rotating accent palette */
.accent-bar { height: 5px; width: 100%; }

.accent-0 .accent-bar { background: linear-gradient(90deg, #2563eb, #60a5fa); }
.accent-1 .accent-bar { background: linear-gradient(90deg, #7c3aed, #a78bfa); }
.accent-2 .accent-bar { background: linear-gradient(90deg, #0891b2, #22d3ee); }
.accent-3 .accent-bar { background: linear-gradient(90deg, #d97706, #fbbf24); }

.card-body {
  display: flex;
  flex-direction: column;
  flex: 1;
  padding: 16px;
}

.card-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 12px;
}

.head-left { min-width: 0; flex: 1; }

.name-row { display: flex; align-items: center; gap: 6px; }

.plan-name {
  font-size: 15px;
  font-weight: 800;
  color: #111827;
  margin: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.featured-badge {
  flex-shrink: 0;
  font-size: 10px;
  font-weight: 700;
  color: #b45309;
  background: #fef3c7;
  border-radius: 999px;
  padding: 2px 8px;
}

.plan-desc {
  font-size: 12px;
  color: #6b7280;
  margin: 4px 0 0;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.head-right { text-align: right; flex-shrink: 0; }

.price-row { display: flex; align-items: baseline; justify-content: flex-end; gap: 2px; }

.price-currency { font-size: 12px; color: #2563eb; font-weight: 600; }

.price-now {
  font-size: 26px;
  font-weight: 800;
  letter-spacing: -0.5px;
  color: #2563eb;
}

.validity { font-size: 11px; color: #9ca3af; }

.discount-row {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 5px;
  margin-top: 2px;
}

.price-origin {
  font-size: 12px;
  color: #9ca3af;
  text-decoration: line-through;
}

.discount-badge {
  font-size: 10px;
  font-weight: 700;
  color: #dc2626;
  background: #fee2e2;
  border-radius: 4px;
  padding: 1px 5px;
}

/* Quota block */
.quota-block {
  display: flex;
  flex-direction: column;
  gap: 4px;
  background: #f8fafc;
  border-radius: 10px;
  padding: 10px 12px;
  margin-bottom: 12px;
}

.quota-row { display: flex; align-items: center; justify-content: space-between; }

.quota-label { font-size: 12px; color: #6b7280; }

.quota-value { font-size: 13px; font-weight: 700; }

.quota-value.credit { color: #16a34a; }

.quota-value.bonus { color: #d97706; }

/* Features */
.feature-list {
  list-style: none;
  margin: 0 0 14px;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 7px;
}

.feature-list li {
  display: flex;
  align-items: flex-start;
  gap: 7px;
  font-size: 12px;
  color: #374151;
}

.feature-check {
  width: 13px;
  height: 13px;
  flex-shrink: 0;
  margin-top: 1px;
  color: #16a34a;
}

.card-body > .select-btn { margin-top: auto; }

.select-btn {
  width: 100%;
  border: 1.5px solid #2563eb;
  border-radius: 10px;
  background: #ffffff;
  color: #2563eb;
  font-size: 13px;
  font-weight: 700;
  padding: 9px 0;
  cursor: pointer;
  transition: background 0.15s, color 0.15s, transform 0.1s;
}

.select-btn:hover { background: #eff6ff; }

.select-btn:active { transform: scale(0.98); }

.select-btn.active {
  background: #2563eb;
  color: #ffffff;
}
</style>
