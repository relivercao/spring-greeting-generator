<template>
  <ShutdownDialog ref="shutdownDialog" />
  <ConnectedAppsDialog
    v-model="connectedAppsVisible"
    :return-path="route.fullPath"
    @use-app="useConnectedApp"
  />
  <header class="header">
    <div class="header-left">
      <div
        v-if="activeAgent"
        class="agent-badge"
      >
        <AgentMascot :agent="activeAgent" size="header">
          <div
            class="agent-icon"
            :style="{ background: activeAgent.color }"
          >
            <el-icon size="14">
              <component :is="activeAgent.icon" />
            </el-icon>
          </div>
        </AgentMascot>
        <span class="agent-title">{{ activeAgent.id === 1 ? 'Macode' : activeAgent.name }}</span>
      </div>
      <span
        v-else
        class="header-brand"
      >Macode</span>
    </div>

    <div class="header-right">
      <el-tooltip content="Connect apps" placement="bottom">
        <button
          class="connect-apps-button"
          type="button"
          aria-label="Connect apps"
          @click="connectedAppsVisible = true"
        >
          <el-icon size="15"><Connection /></el-icon>
          <span>Apps</span>
        </button>
      </el-tooltip>
      <button v-if="authStore.isLoggedIn" class="connect-apps-button" type="button" aria-label="Open Event Center" @click="router.push('/events')">
        <el-icon size="15"><Connection /></el-icon><span>Events</span>
      </button>

      <!-- <el-tooltip
        content="Search history"
        placement="bottom"
      >
        <button class="icon-btn">
          <el-icon size="16">
            <Search />
          </el-icon>
        </button>
      </el-tooltip> -->

      <button
        v-if="authStore.isLoggedIn"
        class="balance-chip"
        title="Account balance - click to recharge"
        @click="router.push('/recharge')"
      >
        <el-icon size="14">
          <Coin />
        </el-icon>
        <span>¥{{ balanceText }}</span>
      </button>

      <el-popover
        v-if="authStore.isLoggedIn"
        placement="bottom-end"
        :width="360"
        trigger="click"
      >
        <template #reference>
          <button
            class="notification-button"
            type="button"
            title="Jira and Bitbucket updates"
            aria-label="Jira and Bitbucket updates"
          >
            <el-icon size="17">
              <Bell />
            </el-icon>
            <span
              v-if="unreadNotificationCount"
              class="notification-count"
            >{{ unreadNotificationCount > 99 ? '99+' : unreadNotificationCount }}</span>
          </button>
        </template>
        <div class="notification-panel">
          <div class="notification-panel-header">
            <div>
              <strong>Work updates</strong>
              <span>Jira Bugs and Bitbucket pull requests</span>
            </div>
            <button
              class="notification-refresh"
              type="button"
              :disabled="notificationsLoading"
              title="Refresh updates"
              aria-label="Refresh updates"
              @click="refreshIntegrationNotifications"
            >
              <el-icon :class="{ spinning: notificationsLoading }">
                <Refresh />
              </el-icon>
            </button>
          </div>
          <div
            v-if="notificationsError"
            class="notification-error"
            role="alert"
          >
            {{ notificationsError }}
          </div>
          <div
            v-if="notificationsLoading && !integrationNotifications.length"
            class="notification-empty"
          >
            Checking Jira and Bitbucket...
          </div>
          <div
            v-else-if="!notificationsError && !integrationNotifications.length"
            class="notification-empty"
          >
            No recent updates assigned to you.
          </div>
          <button
            v-for="item in integrationNotifications"
            :key="item.id"
            type="button"
            class="notification-item"
            @click="openIntegrationNotification(item)"
          >
            <span
              class="notification-source"
              :class="`source-${item.source}`"
            >{{ item.source === 'jira' ? 'Jira' : 'PR' }}</span>
            <span class="notification-copy">
              <strong>{{ item.title }}</strong>
              <span>{{ item.message }}</span>
              <small>{{ formatNotificationTime(item.updated_at) }}</small>
            </span>
            <span
              v-if="!seenNotificationIds.has(item.id)"
              class="notification-unread-dot"
            />
          </button>
          <div
            v-if="lastNotificationCheck"
            class="notification-footer"
          >
            Last checked {{ formatNotificationTime(lastNotificationCheck) }}
          </div>
        </div>
      </el-popover>

      <button
        class="shutdown-btn-text"
        aria-label="Shutdown system"
        @click="handleShutdown"
      >
        <el-icon size="14">
          <SwitchButton />
        </el-icon>
        <span>Shutdown System</span>
      </button>

      <el-dropdown
        trigger="click"
        @command="handleCommand"
      >
        <div class="user-trigger">
          <div class="avatar">
            {{ user?.name?.charAt(0) || 'U' }}
          </div>
          <span class="username">{{ user.name }}</span>
          <el-icon
            size="12"
            class="arrow"
          >
            <ArrowDown />
          </el-icon>
        </div>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item
              v-if="authStore.isGuest"
              command="sign-in"
            >
              <el-icon><User /></el-icon>Sign in to an account
            </el-dropdown-item>
            <template v-if="authStore.isLoggedIn">
              <el-dropdown-item command="recharge">
                <el-icon><Coin /></el-icon>Recharge
              </el-dropdown-item>
              <el-dropdown-item command="orders">
                <el-icon><List /></el-icon>My Orders
              </el-dropdown-item>
              <el-dropdown-item command="transactions">
                <el-icon><Tickets /></el-icon>Transactions
              </el-dropdown-item>
              <el-dropdown-item command="usage">
                <el-icon><Tickets /></el-icon>Usage &amp; Costs
              </el-dropdown-item>
              <el-dropdown-item
                v-if="authStore.isAdmin"
                command="admin"
              >
                <el-icon><Monitor /></el-icon>Admin
              </el-dropdown-item>
            </template>
            <el-dropdown-item command="provider-settings">
              <el-icon><Connection /></el-icon>Provider Configuration
            </el-dropdown-item>
            <el-dropdown-item command="settings">
              <el-icon><Setting /></el-icon>System Settings
            </el-dropdown-item>
            <el-dropdown-item
              divided
              command="logout"
            >
              <el-icon><SwitchButton /></el-icon>{{ authStore.isGuest ? 'Exit guest mode' : 'Sign Out' }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </header>

  <!-- Settings Popover Panel -->
  <el-drawer
    v-model="settingsVisible"
    title=""
    direction="rtl"
    size="min(520px, 100vw)"
    :show-close="true"
    class="settings-drawer"
  >
    <div class="drawer-header">
      <div class="drawer-icon">
        <el-icon size="20">
          <Setting />
        </el-icon>
      </div>
      <div class="drawer-title-group">
        <div class="drawer-title">
          Macode Settings
        </div>
        <div class="drawer-subtitle">
          Model and connection configuration
        </div>
      </div>
    </div>

    <div class="drawer-body">
      <div class="config-section app-settings-section">
        <ConnectedAppsPanel v-if="settingsVisible" :return-path="route.fullPath" @use-app="useConnectedApp" />
      </div>
      <div v-if="authStore.isAdmin" class="config-section">
        <GlobalEmailSettings v-if="settingsVisible" />
      </div>
      <!-- Model Selection -->
      <div class="config-section">
        <div class="section-label">
          Macode Model
        </div>
        <el-select
          v-model="envData.TURING_DEFAULT_MODEL"
          size="large"
          style="width: 100%"
        >
          <el-option
            v-for="model in modelOptions"
            :key="model.value"
            :label="model.label"
            :value="model.value"
          >
            <div class="model-option">
              <span class="model-name">{{ model.label }}</span>
              <span
                v-if="model.recommended"
                class="model-badge"
              >Recommended</span>
            </div>
          </el-option>
        </el-select>
        <div class="field-hint">
          Select Macode model version
        </div>
      </div>

      <!-- Connection Settings -->
      <div class="config-section">
        <div class="section-label">
          API Connection
        </div>
        <div class="fields-grid">
          <div class="field-item">
            <label>Base URL</label>
            <el-input
              v-model="envData.TURING_API_BASE"
              placeholder="https://your-api-base/v1"
              clearable
            />
          </div>
          <div class="field-item">
            <label>API Key</label>
            <el-input
              v-model="envData.TURING_API_KEY"
              placeholder="Enter API key"
              show-password
              clearable
            />
          </div>
        </div>
        <div class="field-hint">
          Router endpoint and credentials
        </div>
      </div>

      <div class="config-section">
        <div class="section-label">
          Integration Profile
        </div>
        <el-select
          v-model="envData.INTEGRATION_PROFILE"
          size="large"
          style="width: 100%"
        >
          <el-option
            label="General engineering"
            value="general"
          />
          <el-option
            label="Embedded and firmware"
            value="embedded"
          />
          <el-option
            label="Software and SaaS"
            value="software"
          />
          <el-option
            label="Hardware and electronics"
            value="hardware"
          />
          <el-option
            label="Custom industry"
            value="custom"
          />
        </el-select>
        <div class="field-hint">
          Selects the default terminology and repository workflow. Connection credentials remain provider-specific.
        </div>
      </div>

      <div class="config-section">
        <div class="section-label">
          Jira Connection
        </div>
        <div class="fields-grid">
          <div class="field-item">
            <label>Deployment</label>
            <el-select
              v-model="envData.JIRA_DEPLOYMENT"
              style="width: 100%"
            >
              <el-option
                label="Cloud"
                value="cloud"
              />
              <el-option
                label="Server / Data Center"
                value="server"
              />
            </el-select>
          </div>
          <div class="field-item">
            <label>Base URL</label>
            <el-input
              v-model="envData.JIRA_BASE_URL"
              placeholder="https://company.atlassian.net"
              clearable
            />
          </div>
          <div class="field-item">
            <label>Account Email</label>
            <el-input
              v-model="envData.JIRA_EMAIL"
              placeholder="jira-service@example.com"
              clearable
            />
          </div>
          <div class="field-item field-wide">
            <label>API Token</label>
            <el-input
              v-model="envData.JIRA_API_TOKEN"
              placeholder="Enter Jira API token"
              show-password
              clearable
            />
          </div>
          <div class="field-item">
            <label>Default Project</label>
            <el-input
              v-model="envData.JIRA_PROJECT_KEY"
              placeholder="FW"
              clearable
            />
          </div>
          <div class="field-item">
            <label>Issue Types</label>
            <el-input
              v-model="envData.JIRA_ISSUE_TYPES"
              placeholder="Bug, Defect, Incident"
              clearable
            />
          </div>
        </div>
        <div class="field-hint">
          Comma-separated issue types support different Jira workflows and industries.
        </div>
      </div>

      <div class="config-section">
        <div class="section-label">
          Bitbucket Connection
        </div>
        <div class="fields-grid">
          <div class="field-item">
            <label>Deployment</label>
            <el-select
              v-model="envData.BITBUCKET_DEPLOYMENT"
              style="width: 100%"
            >
              <el-option
                label="Cloud"
                value="cloud"
              />
              <el-option
                label="Server / Data Center"
                value="server"
              />
            </el-select>
          </div>
          <div class="field-item">
            <label>Base URL</label>
            <el-input
              v-model="envData.BITBUCKET_BASE_URL"
              placeholder="https://api.bitbucket.org/2.0"
              clearable
            />
          </div>
          <div class="field-item">
            <label>Username</label>
            <el-input
              v-model="envData.BITBUCKET_USERNAME"
              placeholder="Bitbucket username"
              clearable
            />
          </div>
          <div class="field-item field-wide">
            <label>App Password</label>
            <el-input
              v-model="envData.BITBUCKET_APP_PASSWORD"
              placeholder="Enter Bitbucket app password"
              show-password
              clearable
            />
          </div>
          <div class="field-item">
            <label>Workspace</label>
            <el-input
              v-model="envData.BITBUCKET_WORKSPACE"
              placeholder="Workspace or project key"
              clearable
            />
          </div>
        </div>
        <div class="field-hint">
          Supports Bitbucket Cloud and Server / Data Center credentials.
        </div>
      </div>

      <div class="config-section">
        <div class="section-label">
          Git Repository Connection
        </div>
        <div class="fields-grid">
          <div class="field-item">
            <label>Provider</label>
            <el-select
              v-model="envData.GIT_PROVIDER"
              style="width: 100%"
            >
              <el-option
                label="Local Git"
                value="local"
              />
              <el-option
                label="GitHub"
                value="github"
              />
              <el-option
                label="GitLab"
                value="gitlab"
              />
              <el-option
                label="Gitea"
                value="gitea"
              />
              <el-option
                label="Custom Git service"
                value="custom"
              />
            </el-select>
          </div>
          <div class="field-item">
            <label>Default Branch</label>
            <el-input
              v-model="envData.GIT_DEFAULT_BRANCH"
              placeholder="main"
              clearable
            />
          </div>
          <div class="field-item field-wide">
            <label>Local Repository Path</label>
            <el-input
              v-model="envData.GIT_REPOSITORY_PATH"
              placeholder="D:/projects/firmware"
              clearable
            />
          </div>
          <div class="field-item field-wide">
            <label>Remote Repository URL</label>
            <el-input
              v-model="envData.GIT_REPOSITORY_URL"
              placeholder="https://git.example.com/org/repository"
              clearable
            />
          </div>
          <div class="field-item">
            <label>API Base URL</label>
            <el-input
              v-model="envData.GIT_BASE_URL"
              placeholder="https://api.github.com"
              clearable
            />
          </div>
          <div class="field-item">
            <label>Username</label>
            <el-input
              v-model="envData.GIT_USERNAME"
              placeholder="Optional service account"
              clearable
            />
          </div>
          <div class="field-item field-wide">
            <label>Access Token</label>
            <el-input
              v-model="envData.GIT_TOKEN"
              placeholder="Enter Git access token"
              show-password
              clearable
            />
          </div>
        </div>
        <div class="field-hint">
          Local Git is used for working-tree diffs. Provider fields document remote repository defaults for GitHub, GitLab, Gitea, and custom services.
        </div>
      </div>

      <!-- Status -->
      <transition name="fade">
        <div
          v-if="statusMsg"
          :class="['status-bar', statusType]"
        >
          <el-icon size="14">
            <CircleCheck v-if="statusType === 'success'" />
            <CircleClose v-else />
          </el-icon>
          {{ statusMsg }}
        </div>
      </transition>
    </div>

    <div class="drawer-footer">
      <el-button @click="settingsVisible = false">
        Cancel
      </el-button>
      <el-button
        type="primary"
        :loading="saving"
        @click="handleSaveSettings"
      >
        Save
      </el-button>
    </div>
  </el-drawer>

  <!-- Provider Settings Drawer -->
  <el-drawer
    v-model="providerVisible"
    title=""
    direction="rtl"
    size="420px"
    :show-close="true"
    class="provider-drawer"
  >
    <div class="drawer-header">
      <div class="drawer-icon provider-icon">
        <el-icon size="20">
          <Connection />
        </el-icon>
      </div>
      <div class="drawer-title-group">
        <div class="drawer-title">
          Provider Settings
        </div>
        <div class="drawer-subtitle">
          Configure LLM provider
        </div>
      </div>
    </div>

    <div class="drawer-body">
      <!-- Provider Selector -->
      <div class="config-section">
        <div class="section-label">
          Select Provider
        </div>
        <div
          class="provider-segments"
          role="radiogroup"
          aria-label="LLM provider"
        >
          <button
            v-for="p in providerList"
            :key="p.key"
            type="button"
            role="radio"
            :aria-checked="selectedProvider === p.key"
            :class="['provider-segment', { active: selectedProvider === p.key }]"
            @click="selectedProvider = p.key"
          >
            <div
              class="provider-segment-icon"
              :style="{ color: colors[p.key] }"
            >
              <el-icon size="16">
                <component :is="icons[p.key]" />
              </el-icon>
            </div>
            <div class="provider-segment-copy">
              <span class="provider-segment-name">{{ p.title }}</span>
              <span :class="['provider-segment-status', { configured: p.configured }]">
                {{ p.configured ? 'Configured' : 'Not configured' }}
              </span>
            </div>
            <el-icon
              v-if="selectedProvider === p.key"
              class="provider-segment-check"
            >
              <Check />
            </el-icon>
          </button>
        </div>
      </div>

      <!-- Default toggle -->
      <div
        class="default-row"
        :class="{ disabled: !isCurrentConfigured }"
      >
        <div class="default-left">
          <el-icon
            size="16"
            class="default-icon"
          >
            <Star />
          </el-icon>
          <div>
            <div class="default-title">
              Default Provider
            </div>
            <div class="default-hint">
              {{ isCurrentConfigured ? 'Fallback for Agents without an override' : 'Please configure this provider first' }}
            </div>
          </div>
        </div>
        <el-switch
          v-model="isDefaultProvider"
          :disabled="!isCurrentConfigured"
        />
      </div>

      <!-- Configuration fields -->
      <div class="config-section">
        <div class="section-label">
          {{ currentMeta?.title }} Configuration
        </div>
        <div class="fields-grid">
          <div
            v-for="f in currentFields"
            :key="f.key"
            class="field-item"
          >
            <label>{{ f.label }}</label>
            <el-select
              v-if="f.key === 'default_model'"
              v-model="currentForm[f.key]"
              filterable
              allow-create
              default-first-option
            >
              <el-option v-for="model in catalogOptions(selectedProvider, currentForm[f.key])" :key="model.value" :label="model.label" :value="model.value" />
            </el-select>
            <el-input
              v-else
              v-model="currentForm[f.key]"
              :type="f.type || 'text'"
              :placeholder="f.placeholder"
              :show-password="f.type === 'password'"
            />
          </div>
        </div>
      </div>

      <div class="config-section agent-defaults-section">
        <div class="section-label">
          Agent Defaults
        </div>
        <div class="agent-llm-list">
          <div
            v-for="agent in agentDefinitions"
            :key="agent.key"
            class="agent-llm-row"
          >
            <div class="agent-llm-name">
              {{ agent.title }}
            </div>
            <el-select
              v-model="agentLLM[agent.key].provider"
              class="agent-provider-select"
              @change="handleAgentProviderChange(agent.key)"
            >
              <el-option
                v-for="provider in providerList"
                :key="provider.key"
                :label="provider.title"
                :value="provider.key"
              />
            </el-select>
            <el-select
              v-model="agentLLM[agent.key].model"
              class="agent-model-input"
              filterable
              allow-create
              default-first-option
              placeholder="Model name"
            >
              <el-option v-for="model in catalogOptions(agentLLM[agent.key].provider, agentLLM[agent.key].model)" :key="model.value" :label="model.label" :value="model.value" />
            </el-select>
          </div>
        </div>
      </div>

      <!-- JSON button -->
      <div class="json-section">
        <div class="json-row">
          <div class="json-info">
            <el-icon size="16">
              <Document />
            </el-icon>
            <span>JSON Configuration</span>
          </div>
          <el-button
            size="small"
            @click="showJsonDialog = true"
          >
            View / Edit
          </el-button>
        </div>
      </div>

      <!-- Status -->
      <transition name="fade">
        <div
          v-if="providerStatus"
          :class="['status-bar', providerStatusType]"
        >
          <el-icon size="14">
            <CircleCheck v-if="providerStatusType === 'success'" />
            <CircleClose v-else />
          </el-icon>
          {{ providerStatus }}
        </div>
      </transition>
    </div>

    <div class="drawer-footer">
      <el-button @click="providerVisible = false">
        Cancel
      </el-button>
      <el-button
        type="primary"
        :loading="providerSaving"
        @click="handleSaveProvider"
      >
        Save
      </el-button>
    </div>

    <!-- JSON Dialog -->
    <el-dialog
      v-model="showJsonDialog"
      title="JSON Configuration"
      width="600px"
      append-to-body
    >
      <div class="json-dialog-content">
        <div class="json-dialog-toolbar">
          <span>Paste or edit configuration JSON</span>
          <div class="json-dialog-btns">
            <el-button
              size="small"
              @click="copyJson"
            >
              Copy
            </el-button>
            <el-button
              size="small"
              type="primary"
              @click="applyJson"
            >
              Apply
            </el-button>
          </div>
        </div>
        <el-input
          v-model="jsonText"
          type="textarea"
          :rows="15"
          placeholder="{&quot;default_provider&quot;: &quot;macode&quot;, ...}"
          class="json-textarea"
        />
      </div>
    </el-dialog>
  </el-drawer>
</template>

<script setup>
import { ref, reactive, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getEnvJson, saveEnvJson, saveProviderSettings } from '../api/settings.js'
import { getIntegrationNotifications } from '../api/notifications.js'
import { useModelCatalog } from '../composables/useModelCatalog.js'
import { useAuthStore } from '../stores/auth.js'
import ShutdownDialog from './ShutdownDialog.vue'
import ConnectedAppsDialog from './ConnectedAppsDialog.vue'
import ConnectedAppsPanel from './ConnectedAppsPanel.vue'
import AgentMascot from './AgentMascot.vue'
import GlobalEmailSettings from './GlobalEmailSettings.vue'
import { composeGmailRequest } from '../utils/assistantEvents.js'
import {
  Setting, Connection, Star, Document, Check, CircleCheck, CircleClose,
  Platform, Grid, Coin, List, Tickets, Monitor, SwitchButton, Bell, Refresh
} from '@element-plus/icons-vue'

const props = defineProps({
  activeAgent: Object,
  user: Object
})

const emit = defineEmits(['logout'])
const shutdownDialog = ref(null)

const router = useRouter()
const route = useRoute()
const authStore = useAuthStore()
const connectedAppsVisible = ref(false)

function useConnectedApp(app) {
  if (app !== 'gmail') return
  connectedAppsVisible.value = false
  settingsVisible.value = false
  composeGmailRequest()
}

// Balance chip: CNY balance with 2 decimals, sourced from the auth profile.
const balanceText = computed(() => Number(authStore.user?.balance ?? 0).toFixed(2))
const integrationNotifications = ref([])
const notificationsLoading = ref(false)
const notificationsError = ref('')
const lastNotificationCheck = ref('')
const notificationAccountKey = computed(() => {
  if (!authStore.isLoggedIn) return 'anonymous'
  const identity = authStore.user?.id
    || authStore.user?.email
    || authStore.user?.name
    || 'guest'
  return String(identity)
})
const seenNotificationIds = ref(loadSeenNotificationIds(notificationAccountKey.value))
let notificationRefreshTimer = null
let notificationRequestVersion = 0

const unreadNotificationCount = computed(() =>
  integrationNotifications.value.filter(item => !seenNotificationIds.value.has(item.id)).length
)

onMounted(() => {
  // Refresh balance and admin role when the header mounts. The call is
  // guarded so the header keeps working before the profile endpoint lands.
  if (authStore.isLoggedIn && typeof authStore.fetchProfile === 'function') {
    authStore.fetchProfile().catch(() => {})
  }
  void refreshIntegrationNotifications()
  if (typeof route.query.app_connection === 'string') {
    connectedAppsVisible.value = true
    const query = { ...route.query }
    delete query.app_connection
    delete query.status
    delete query.connected_account_id
    void router.replace({ path: route.path, query })
  }
  notificationRefreshTimer = globalThis.setInterval(
    refreshIntegrationNotifications,
    60 * 60 * 1000,
  )
})

onBeforeUnmount(() => {
  if (notificationRefreshTimer) {
    globalThis.clearInterval(notificationRefreshTimer)
    notificationRefreshTimer = null
  }
})

watch(notificationAccountKey, (nextAccountKey, previousAccountKey) => {
  if (nextAccountKey === previousAccountKey) return
  notificationRequestVersion += 1
  seenNotificationIds.value = loadSeenNotificationIds(nextAccountKey)
  integrationNotifications.value = []
  notificationsError.value = ''
  lastNotificationCheck.value = ''
  if (authStore.isLoggedIn) {
    void refreshIntegrationNotifications({ force: true })
  }
})

function notificationStorageKey(accountKey = notificationAccountKey.value) {
  return `macode.integration-notifications.seen:${encodeURIComponent(accountKey)}`
}

function loadSeenNotificationIds(accountKey = notificationAccountKey.value) {
  try {
    const parsed = JSON.parse(globalThis.localStorage.getItem(notificationStorageKey(accountKey)) || '[]')
    return new Set(Array.isArray(parsed) ? parsed.filter(Boolean) : [])
  } catch {
    return new Set()
  }
}

function persistSeenNotificationIds() {
  try {
    globalThis.localStorage.setItem(
      notificationStorageKey(),
      JSON.stringify([...seenNotificationIds.value].slice(-200)),
    )
  } catch {
    // Browser storage can be unavailable in private browsing contexts.
  }
}

async function refreshIntegrationNotifications({ force = false } = {}) {
  if (!authStore.isLoggedIn || (!force && notificationsLoading.value)) return
  const requestVersion = ++notificationRequestVersion
  const requestAccountKey = notificationAccountKey.value
  notificationsLoading.value = true
  notificationsError.value = ''
  try {
    const response = await getIntegrationNotifications()
    if (requestVersion !== notificationRequestVersion || requestAccountKey !== notificationAccountKey.value) return
    integrationNotifications.value = Array.isArray(response?.notifications)
      ? response.notifications
      : []
    lastNotificationCheck.value = response?.checked_at || new Date().toISOString()
    const sourceErrors = Object.entries(response?.sources || {})
      .map(([source, details]) => {
        if (!details || typeof details.error !== 'string' || !details.error.trim()) return ''
        const label = source === 'jira' ? 'Jira' : source === 'bitbucket' ? 'Bitbucket' : source
        return `${label} updates could not be read. ${details.error.trim()}`
      })
      .filter(Boolean)
    notificationsError.value = sourceErrors.join(' ')
  } catch (error) {
    if (requestVersion === notificationRequestVersion && requestAccountKey === notificationAccountKey.value) {
      notificationsError.value = error.message || 'Could not load work updates.'
    }
  } finally {
    if (requestVersion === notificationRequestVersion) notificationsLoading.value = false
  }
}

function markNotificationRead(item) {
  const next = new Set(seenNotificationIds.value)
  if (item?.id) next.add(item.id)
  seenNotificationIds.value = next
  persistSeenNotificationIds()
}

function openIntegrationNotification(item) {
  markNotificationRead(item)
  router.push({ path: item.route, query: item.query || {} })
}

function formatNotificationTime(value) {
  if (!value) return 'Unknown time'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return String(value)
  return new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short' }).format(date)
}

// Settings Drawer
const settingsVisible = ref(false)
const saving = ref(false)
const statusMsg = ref('')
const statusType = ref('success')
const settingsBaseline = ref({})
const systemSettingsKeys = [
  'TURING_DEFAULT_MODEL', 'TURING_API_BASE', 'TURING_API_KEY',
  'INTEGRATION_PROFILE',
  'JIRA_BASE_URL', 'JIRA_EMAIL', 'JIRA_API_TOKEN', 'JIRA_DEPLOYMENT', 'JIRA_PROJECT_KEY', 'JIRA_ISSUE_TYPES',
  'BITBUCKET_BASE_URL', 'BITBUCKET_USERNAME', 'BITBUCKET_APP_PASSWORD', 'BITBUCKET_DEPLOYMENT', 'BITBUCKET_WORKSPACE',
  'GIT_PROVIDER', 'GIT_BASE_URL', 'GIT_REPOSITORY_PATH', 'GIT_REPOSITORY_URL', 'GIT_USERNAME', 'GIT_TOKEN', 'GIT_DEFAULT_BRANCH',
]
const envData = reactive({
  TURING_DEFAULT_MODEL: 'claude-sonnet-4-6',
  TURING_API_BASE: '',
  TURING_API_KEY: '',
  INTEGRATION_PROFILE: 'general',
  JIRA_BASE_URL: '',
  JIRA_EMAIL: '',
  JIRA_API_TOKEN: '',
  JIRA_DEPLOYMENT: 'cloud',
  JIRA_PROJECT_KEY: '',
  JIRA_ISSUE_TYPES: 'Bug',
  BITBUCKET_BASE_URL: '',
  BITBUCKET_USERNAME: '',
  BITBUCKET_APP_PASSWORD: '',
  BITBUCKET_DEPLOYMENT: 'cloud',
  BITBUCKET_WORKSPACE: '',
  GIT_PROVIDER: 'local',
  GIT_BASE_URL: '',
  GIT_REPOSITORY_PATH: '',
  GIT_REPOSITORY_URL: '',
  GIT_USERNAME: '',
  GIT_TOKEN: '',
  GIT_DEFAULT_BRANCH: 'main',
})

const { loadCatalog, options: catalogOptions } = useModelCatalog()
const modelOptions = computed(() => catalogOptions('macode', envData.TURING_DEFAULT_MODEL, ['claude-sonnet-4-6', 'claude-sonnet-4-5']))

// Provider Drawer
const providerVisible = ref(false)
const providerSaving = ref(false)
const providerStatus = ref('')
const providerStatusType = ref('success')
const selectedProvider = ref('macode')
const defaultProvider = ref('macode')
const configuredKeys = ref({})
const showJsonDialog = ref(false)
const jsonText = ref('')

const icons = {
  bedrock: Grid,
  macode: Platform,
}

const colors = {
  bedrock: '#ec4899',
  macode: '#2563eb',
}

const providers = reactive({
  bedrock: { aws_region: 'eu-west-1', aws_profile: '', default_model: 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0' },
  macode: { api_base: 'https://macode.cloud/v1', api_key: '', default_model: 'claude-sonnet-4-6' },
})

const meta = {
  bedrock: {
    title: 'AWS Bedrock',
    fields: [
      { key: 'aws_region', label: 'Region', placeholder: 'eu-west-1' },
      { key: 'aws_profile', label: 'Profile', placeholder: ' ' },
      { key: 'default_model', label: 'Model', placeholder: 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0' },
    ],
  },
  macode: {
    title: 'Macode',
    fields: [
      { key: 'api_base', label: 'API Base', placeholder: 'https://macode.cloud/v1' },
      { key: 'api_key', label: 'API Key', type: 'password', placeholder: 'Enter Macode API key' },
      { key: 'default_model', label: 'Model', placeholder: 'claude-sonnet-4-6' },
    ],
  },
}

const agentDefinitions = [
  { key: 'chat', title: 'Chat Agent' },
  { key: 'unittest', title: 'UnitTest Agent' },
  { key: 'driver', title: 'Driver Agent' },
  { key: 'build', title: 'Build Agent' },
  { key: 'bugfix', title: 'BugFix Agent' },
  { key: 'debug', title: 'Debug Agent' },
  { key: 'review', title: 'CodeReview Agent' },
  { key: 'knowledge', title: 'Knowledge Base Agent' },
  { key: 'image_generation', title: 'Image Generation Agent' },
  { key: 'agent_generator', title: 'Agent Generator' },
  { key: 'cad', title: 'CAD Agent' },
]

const agentLLM = reactive(Object.fromEntries(
  agentDefinitions.map(agent => [agent.key, { provider: 'macode', model: 'claude-sonnet-4-6' }])
))

const providerList = computed(() =>
  Object.keys(meta).map(key => ({
    key,
    title: meta[key].title,
    configured: isConfigured(key),
  }))
)

const currentMeta = computed(() => meta[selectedProvider.value])
const currentForm = computed(() => providers[selectedProvider.value])
const currentFields = computed(() => meta[selectedProvider.value]?.fields || [])
const isCurrentConfigured = computed(() => isConfigured(selectedProvider.value))

const isDefaultProvider = computed({
  get: () => defaultProvider.value === selectedProvider.value,
  set: v => { if (v && isCurrentConfigured.value) defaultProvider.value = selectedProvider.value },
})

function isConfigured(key) {
  const p = providers[key]
  const ck = configuredKeys.value
  switch (key) {
    case 'bedrock': return !!(p.aws_profile || ck.AWS_PROFILE || (p.aws_access_key_id || ck.AWS_ACCESS_KEY_ID) && (p.aws_secret_access_key || ck.AWS_SECRET_ACCESS_KEY))
    case 'macode': return !!(p.api_base && (p.api_key || ck.TURING_API_KEY))
    default: return false
  }
}

function unmask(v) { return v?.includes('***') ? '' : v || '' }
function hasVal(v) { return !!v?.trim() }

function defaultModelForProvider(provider) {
  return providers[provider]?.default_model || (
    provider === 'bedrock'
      ? 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0'
      : 'claude-sonnet-4-6'
  )
}

function handleAgentProviderChange(agentKey) {
  agentLLM[agentKey].model = defaultModelForProvider(agentLLM[agentKey].provider)
}

function loadAgentLLMConfig(rawConfig) {
  let saved
  try {
    saved = typeof rawConfig === 'string' && rawConfig ? JSON.parse(rawConfig) : (rawConfig || {})
  } catch {
    saved = {}
  }
  for (const agent of agentDefinitions) {
    const provider = ['macode', 'bedrock'].includes(saved[agent.key]?.provider)
      ? saved[agent.key].provider
      : defaultProvider.value
    agentLLM[agent.key].provider = provider
    agentLLM[agent.key].model = saved[agent.key]?.model || defaultModelForProvider(provider)
  }
}

function serializedAgentLLM() {
  return Object.fromEntries(
    agentDefinitions.map(agent => [agent.key, { ...agentLLM[agent.key] }])
  )
}

function handleShutdown() {
  shutdownDialog.value?.open()
}

function handleCommand(cmd) {
  if (cmd === 'sign-in') {
    router.push({ name: 'login', query: { switch: '1' } })
  }
  if (cmd === 'logout') {
    authStore.logout()
    emit('logout')
    router.push('/login')
  }
  if (cmd === 'recharge') router.push('/recharge')
  if (cmd === 'orders') router.push('/orders')
  if (cmd === 'transactions') router.push('/transactions')
  if (cmd === 'usage') router.push('/usage')
  if (cmd === 'admin') router.push('/admin')
  if (cmd === 'settings') {
    loadSettings()
    settingsVisible.value = true
  }
  if (cmd === 'provider-settings') {
    loadProviderConfig()
    providerVisible.value = true
  }
}

// Settings
async function loadSettings() {
  void loadCatalog()
  try {
    const res = await getEnvJson()
    const data = res?.data ?? res ?? {}
    const defaults = {
      INTEGRATION_PROFILE: 'general',
      JIRA_DEPLOYMENT: 'cloud',
      JIRA_ISSUE_TYPES: 'Bug',
      BITBUCKET_DEPLOYMENT: 'cloud',
      GIT_PROVIDER: 'local',
      GIT_DEFAULT_BRANCH: 'main',
    }
    for (const key of systemSettingsKeys) envData[key] = data[key] || defaults[key] || ''
    envData.TURING_DEFAULT_MODEL = data.TURING_DEFAULT_MODEL || 'claude-sonnet-4-6'
    settingsBaseline.value = Object.fromEntries(
      systemSettingsKeys.map(key => [key, envData[key]])
    )
  } catch {
    setSettingsStatus('Failed to load', 'error')
  }
}

function setSettingsStatus(msg, type = 'success') {
  statusMsg.value = msg
  statusType.value = type
}

async function handleSaveSettings() {
  saving.value = true
  try {
    const updates = Object.fromEntries(
      systemSettingsKeys
        .filter(key => envData[key] !== settingsBaseline.value[key])
        .map(key => [key, envData[key] || ''])
    )
    if (!Object.keys(updates).length) {
      setSettingsStatus('No settings changed', 'success')
      return
    }
    const res = await saveEnvJson(updates)
    settingsBaseline.value = Object.fromEntries(
      systemSettingsKeys.map(key => [key, envData[key]])
    )
    setSettingsStatus(res?.message || 'Saved', 'success')
    if (Object.keys(updates).some(key => key.startsWith('JIRA_') || key.startsWith('BITBUCKET_') || key.startsWith('GIT_') || key === 'INTEGRATION_PROFILE')) {
      void refreshIntegrationNotifications()
    }
  } catch (e) {
    setSettingsStatus(e?.message || 'Save failed', 'error')
  } finally {
    saving.value = false
  }
}

// Provider
async function loadProviderConfig() {
  void loadCatalog()
  try {
    const res = await getEnvJson()
    const env = res?.data ?? res ?? {}
    configuredKeys.value = {
      TURING_API_KEY: hasVal(env.TURING_API_KEY),
      AWS_PROFILE: hasVal(env.AWS_PROFILE),
      AWS_ACCESS_KEY_ID: hasVal(env.AWS_ACCESS_KEY_ID),
      AWS_SECRET_ACCESS_KEY: hasVal(env.AWS_SECRET_ACCESS_KEY),
    }
    providers.macode.api_base = env.TURING_API_BASE || 'https://macode.cloud/v1'
    providers.macode.api_key = unmask(env.TURING_API_KEY)
    providers.macode.default_model = env.TURING_DEFAULT_MODEL || 'claude-sonnet-4-6'
    providers.bedrock.aws_region = env.AWS_REGION || 'eu-west-1'
    providers.bedrock.aws_profile = env.AWS_PROFILE || ''
    providers.bedrock.default_model = env.BEDROCK_DEFAULT_MODEL || env.ANTHROPIC_DEFAULT_SONNET_MODEL || 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0'
    defaultProvider.value = env.DEFAULT_PROVIDER || 'macode'
    selectedProvider.value = defaultProvider.value
    loadAgentLLMConfig(env.AGENT_LLM_CONFIG)
  } catch {
    setProviderStatus('Load failed', 'error')
  }
}

watch([providers, defaultProvider, agentLLM], () => {
  jsonText.value = JSON.stringify({
    default_provider: defaultProvider.value,
    providers: {
      bedrock: { ...providers.bedrock },
      macode: { ...providers.macode },
    },
    agents: serializedAgentLLM(),
  }, null, 2)
}, { deep: true })

function copyJson() {
  globalThis.navigator.clipboard.writeText(jsonText.value)
  setProviderStatus('Copied!', 'success')
}

function applyJson() {
  try {
    const data = JSON.parse(jsonText.value)
    const p = data.providers || {}
    if (p.bedrock) Object.assign(providers.bedrock, p.bedrock)
    if (p.macode) Object.assign(providers.macode, p.macode)
    if (data.default_provider) defaultProvider.value = data.default_provider
    if (data.agents) loadAgentLLMConfig(data.agents)
    setProviderStatus('Applied!', 'success')
  } catch {
    setProviderStatus('Invalid JSON', 'error')
  }
}

function setProviderStatus(msg, type = 'success') {
  providerStatus.value = msg
  providerStatusType.value = type
}

async function handleSaveProvider() {
  providerSaving.value = true
  try {
    await saveProviderSettings({
      default_provider: defaultProvider.value,
      providers: {
        bedrock: { ...providers.bedrock },
        macode: { ...providers.macode },
      },
      agents: serializedAgentLLM(),
    })
    setProviderStatus('Saved!', 'success')
    await loadProviderConfig()
  } catch (e) {
    // The shared HTTP layer throws HttpError with the normalized message on
    // `message`; it does not expose Axios-style response.data fields.
    setProviderStatus(e?.message || e?.details?.detail || 'Save failed', 'error')
  } finally {
    providerSaving.value = false
  }
}
</script>

<style scoped>
.header {
  height: 50px;
  background: #ffffff;
  border-bottom: 1px solid #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  flex-shrink: 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.agent-badge {
  display: flex;
  align-items: center;
  gap: 8px;
}

.agent-icon {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.agent-title {
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
}

.header-brand {
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.connect-apps-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 34px;
  padding: 0 10px;
  border: 1px solid #dbe1e8;
  border-radius: 7px;
  background: #fff;
  color: #465263;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: border-color 0.15s, color 0.15s, background 0.15s;
}

.connect-apps-button:hover {
  border-color: #9bbcf0;
  background: #f8fbff;
  color: #1769e0;
}

.icon-btn {
  width: 34px;
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 8px;
  cursor: pointer;
  color: #6b7280;
  transition: background 0.15s, color 0.15s;
}

.icon-btn:hover {
  background: #f3f4f6;
  color: #1f2937;
}

.balance-chip {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border: 1px solid #dbeafe;
  background: #eff6ff;
  color: #2563eb;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.balance-chip:hover {
  background: #dbeafe;
  border-color: #93c5fd;
}

.notification-button {
  position: relative;
  width: 34px;
  height: 34px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #dbe1e8;
  border-radius: 8px;
  color: #475569;
  background: #ffffff;
  cursor: pointer;
}

.notification-button:hover {
  color: #2563eb;
  border-color: #93c5fd;
  background: #f8fbff;
}

.notification-count {
  position: absolute;
  top: -6px;
  right: -7px;
  min-width: 17px;
  height: 17px;
  padding: 0 4px;
  border: 2px solid #ffffff;
  border-radius: 9px;
  color: #ffffff;
  background: #dc2626;
  font-size: 9px;
  font-weight: 700;
  line-height: 13px;
  text-align: center;
}

.notification-panel {
  display: flex;
  flex-direction: column;
  max-height: 440px;
  overflow-y: auto;
  color: #334155;
}

.notification-panel-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #e5e7eb;
}

.notification-panel-header > div {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.notification-panel-header strong { color: #172b4d; font-size: 13px; }
.notification-panel-header span { color: #6b778c; font-size: 10px; }
.notification-refresh { border: 0; color: #6b778c; background: transparent; cursor: pointer; }
.notification-refresh:hover { color: #2563eb; }
.notification-refresh:disabled { cursor: wait; opacity: 0.6; }
.notification-refresh .spinning { animation: notification-spin 0.8s linear infinite; }

@keyframes notification-spin { to { transform: rotate(360deg); } }

.notification-item {
  display: grid;
  grid-template-columns: 30px minmax(0, 1fr) 7px;
  align-items: start;
  gap: 9px;
  width: 100%;
  padding: 10px 2px;
  border: 0;
  border-bottom: 1px solid #eef0f2;
  color: inherit;
  background: #ffffff;
  text-align: left;
  cursor: pointer;
}

.notification-item:hover { background: #f8fbff; }
.notification-source { display: inline-flex; align-items: center; justify-content: center; min-height: 20px; border-radius: 4px; font-size: 9px; font-weight: 700; }
.source-jira { color: #0747a6; background: #deebff; }
.source-bitbucket { color: #0747a6; background: #e6f0ff; }
.notification-copy { display: flex; min-width: 0; flex-direction: column; gap: 3px; }
.notification-copy strong { color: #172b4d; font-size: 11px; overflow-wrap: anywhere; }
.notification-copy span { color: #44546f; font-size: 10px; line-height: 1.35; overflow-wrap: anywhere; }
.notification-copy small { color: #8993a4; font-size: 9px; }
.notification-unread-dot { width: 7px; height: 7px; margin-top: 5px; border-radius: 50%; background: #2563eb; }
.notification-empty, .notification-error { padding: 22px 8px; color: #6b778c; font-size: 11px; text-align: center; }
.notification-error { color: #ae2e24; }
.notification-footer { padding-top: 9px; color: #8993a4; font-size: 9px; text-align: right; }

.shutdown-btn-text {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border: 1px solid #fecaca;
  background: #fef2f2;
  color: #dc2626;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.shutdown-btn-text:hover {
  background: #fee2e2;
  border-color: #fca5a5;
}

.user-trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
}

.user-trigger:hover {
  background: #f3f4f6;
}

.avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: #2563eb;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 600;
}

.username {
  font-size: 13px;
  color: #374151;
  font-weight: 500;
}

.arrow {
  color: #9ca3af;
}

@media (max-width: 640px) {
  .header { padding: 0 10px; }
  .header-left { min-width: 0; }
  .header-right { gap: 4px; }
  .agent-title { max-width: 96px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .connect-apps-button span, .shutdown-btn-text span, .username { display: none; }
  .connect-apps-button, .shutdown-btn-text { padding: 7px; }
  .user-trigger { padding: 6px 4px; gap: 4px; }
}

/* Drawer Styles */
.drawer-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid #e5e7eb;
  margin-bottom: 14px;
}

.drawer-icon {
  width: 36px;
  height: 36px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}

.drawer-icon.provider-icon {
  background: linear-gradient(135deg, #10b981, #059669);
  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

.drawer-title {
  font-size: 15px;
  font-weight: 700;
  color: #1f2937;
}

.drawer-subtitle {
  font-size: 12px;
  color: #6b7280;
  margin-top: 2px;
}

.drawer-body {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.section-label {
  font-size: 12px;
  font-weight: 600;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 10px;
}

.config-section {
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 13px;
}

.fields-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.field-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.field-item label {
  font-size: 13px;
  font-weight: 600;
  color: #374151;
}

.field-hint {
  margin-top: 8px;
  font-size: 11px;
  color: #9ca3af;
}

.model-option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
}

.model-badge {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 8px;
  background: #dbeafe;
  color: #2563eb;
  font-weight: 600;
}

.status-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 14px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
}

.status-bar.success {
  background: #d1fae5;
  color: #059669;
}

.status-bar.error {
  background: #fee2e2;
  color: #dc2626;
}

.drawer-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  padding-top: 20px;
  border-top: 1px solid #e5e7eb;
  margin-top: 20px;
}

/* Provider specific */
.default-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  background: linear-gradient(135deg, #fef3c7, #fff);
  border: 1px solid #fcd34d;
  border-radius: 10px;
  transition: opacity 0.2s;
}

.default-row.disabled {
  opacity: 0.5;
  background: #f3f4f6;
  border-color: #e5e7eb;
}

.default-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.default-icon { color: #f59e0b; }
.default-row.disabled .default-icon { color: #9ca3af; }

.default-title { font-size: 14px; font-weight: 600; color: #1f2937; }
.default-hint { font-size: 11px; color: #92400e; margin-top: 1px; }

.provider-segments {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.provider-segment {
  min-width: 0;
  min-height: 58px;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 9px 10px;
  border: 1px solid #dbe1e8;
  border-radius: 7px;
  background: #ffffff;
  color: #374151;
  cursor: pointer;
  text-align: left;
}

.provider-segment:hover {
  border-color: #93c5fd;
  background: #f8fbff;
}

.provider-segment.active {
  border-color: #2563eb;
  box-shadow: inset 0 0 0 1px #2563eb;
}

.provider-segment-icon,
.provider-segment-check {
  flex-shrink: 0;
}

.provider-segment-copy {
  min-width: 0;
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 2px;
}

.provider-segment-name {
  font-size: 13px;
  font-weight: 650;
  color: #1f2937;
}

.provider-segment-status {
  font-size: 10px;
  color: #9ca3af;
}

.provider-segment-status.configured {
  color: #059669;
}

.provider-segment-check {
  color: #2563eb;
}

.agent-llm-list {
  display: flex;
  flex-direction: column;
}

.agent-llm-row {
  display: grid;
  grid-template-columns: minmax(104px, 0.8fr) minmax(112px, 0.85fr) minmax(160px, 1.35fr);
  gap: 8px;
  align-items: center;
  padding: 7px 0;
  border-bottom: 1px solid #e5e7eb;
}

.agent-llm-row:last-child {
  border-bottom: none;
}

.agent-llm-name {
  min-width: 0;
  font-size: 12px;
  font-weight: 600;
  color: #374151;
}

.agent-provider-select,
.agent-model-input {
  width: 100%;
}

@media (max-width: 520px) {
  .agent-llm-row {
    grid-template-columns: 1fr 1fr;
  }

  .agent-llm-name {
    grid-column: 1 / -1;
  }
}

/* JSON Section */
.json-section {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  background: #f9fafb;
  padding: 12px 14px;
}

.json-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.json-info {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #374151;
}

/* JSON Dialog */
.json-dialog-content {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.json-dialog-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.json-dialog-toolbar span {
  font-size: 13px;
  color: #6b7280;
}

.json-dialog-btns {
  display: flex;
  gap: 8px;
}

.json-textarea :deep(textarea) {
  font-family: 'SF Mono', Monaco, Menlo, monospace;
  font-size: 12px;
  background: #1f2937;
  color: #e5e7eb;
  border: none;
  border-radius: 8px;
  padding: 12px;
}

/* Transitions */
.fade-enter-active, .fade-leave-active { transition: opacity 0.2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
