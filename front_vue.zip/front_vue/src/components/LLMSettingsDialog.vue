<template>
  <el-dialog
    v-model="visible"
    width="480px"
    :close-on-click-modal="false"
    class="settings-dialog"
    @open="onOpen"
  >
    <template #header>
      <div class="dlg-header">
        <div class="dlg-icon">
          <el-icon size="20">
            <Setting />
          </el-icon>
        </div>
        <div class="dlg-title-group">
          <div class="dlg-title">
            Macode Settings
          </div>
          <div class="dlg-subtitle">
            Model and connection configuration
          </div>
        </div>
      </div>
    </template>

    <div class="dlg-body">
      <!-- Model Selection -->
      <div class="config-section">
        <div class="section-label">
          Macode Model
        </div>
        <el-select
          v-model="envData.TURING_DEFAULT_MODEL"
          size="large"
          style="width: 100%"
        >
          <el-option
            v-for="model in modelOptions"
            :key="model.value"
            :label="model.label"
            :value="model.value"
          >
            <div class="model-option">
              <span class="model-name">{{ model.label }}</span>
              <span
                v-if="model.recommended"
                class="model-badge"
              >Recommended</span>
            </div>
          </el-option>
        </el-select>
        <div class="field-hint">
          Select Claude model version for all requests
        </div>
      </div>

      <!-- Connection Settings -->
      <div class="config-section">
        <div class="section-label">
          API Connection
        </div>
        <div class="fields-grid">
          <div class="field-item">
            <label>Base URL</label>
            <el-input
              v-model="envData.TURING_API_BASE"
              placeholder="https://your-api-base/v1"
              clearable
            />
          </div>
          <div class="field-item">
            <label>API Key</label>
            <el-input
              v-model="envData.TURING_API_KEY"
              placeholder="Enter API key"
              show-password
              clearable
            />
          </div>
        </div>
        <div class="field-hint">
          Configure Router endpoint and access credentials
        </div>
      </div>

      <!-- Status -->
      <transition name="fade">
        <div
          v-if="statusMsg"
          :class="['status-bar', statusType]"
        >
          <el-icon size="14">
            <CircleCheck v-if="statusType === 'success'" />
            <CircleClose v-else />
          </el-icon>
          {{ statusMsg }}
        </div>
      </transition>
    </div>

    <template #footer>
      <div class="dlg-footer">
        <el-button @click="visible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :loading="saving"
          @click="handleSave"
        >
          Save
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { useModelCatalog } from '../composables/useModelCatalog.js'
import { getEnvJson, saveEnvJson } from '../api/settings.js'
import { Setting, CircleCheck, CircleClose } from '@element-plus/icons-vue'

const visible = ref(false)
const saving = ref(false)
const statusMsg = ref('')
const statusType = ref('success')
const envData = reactive({
  TURING_DEFAULT_MODEL: 'claude-sonnet-4-6',
  TURING_API_BASE: '',
  TURING_API_KEY: '',
})

const { loadCatalog, options } = useModelCatalog()
const modelOptions = computed(() => options('macode', envData.TURING_DEFAULT_MODEL, ['claude-sonnet-4-6', 'claude-sonnet-4-5']))

function open() {
  visible.value = true
}

async function onOpen() {
  void loadCatalog()
  statusMsg.value = ''
  try {
    const res = await getEnvJson()
    const data = res?.data ?? res ?? {}
    if (data.TURING_API_BASE) envData.TURING_API_BASE = data.TURING_API_BASE
    if (data.TURING_API_KEY) envData.TURING_API_KEY = data.TURING_API_KEY
    if (data.TURING_DEFAULT_MODEL) envData.TURING_DEFAULT_MODEL = data.TURING_DEFAULT_MODEL
  } catch {
    setStatus('Failed to load', 'error')
  }
}

function setStatus(msg, type = 'success') {
  statusMsg.value = msg
  statusType.value = type
}

async function handleSave() {
  saving.value = true
  try {
    const res = await saveEnvJson({
      TURING_DEFAULT_MODEL: envData.TURING_DEFAULT_MODEL || 'claude-sonnet-4-6',
      TURING_API_BASE: envData.TURING_API_BASE || '',
      TURING_API_KEY: envData.TURING_API_KEY || '',
    })
    setStatus(res?.message || 'Saved', 'success')
  } catch (e) {
    setStatus(e?.message || 'Save failed', 'error')
  } finally {
    saving.value = false
  }
}

defineExpose({ open })
</script>

<style scoped>
.dlg-header {
  display: flex;
  align-items: center;
  gap: 14px;
}

.dlg-icon {
  width: 42px;
  height: 42px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}

.dlg-title {
  font-size: 17px;
  font-weight: 700;
  color: #1f2937;
}

.dlg-subtitle {
  font-size: 12px;
  color: #6b7280;
  margin-top: 2px;
}

.dlg-body {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.section-label {
  font-size: 12px;
  font-weight: 600;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 10px;
}

.config-section {
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 16px;
}

.fields-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.field-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.field-item label {
  font-size: 13px;
  font-weight: 600;
  color: #374151;
}

.field-hint {
  margin-top: 8px;
  font-size: 11px;
  color: #9ca3af;
}

.model-option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
}

.model-name {
  font-weight: 500;
}

.model-badge {
  font-size: 10px;
  padding: 2px 8px;
  border-radius: 8px;
  background: #dbeafe;
  color: #2563eb;
  font-weight: 600;
}

.status-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 14px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
}

.status-bar.success {
  background: #d1fae5;
  color: #059669;
}

.status-bar.error {
  background: #fee2e2;
  color: #dc2626;
}

.dlg-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.fade-enter-active, .fade-leave-active { transition: opacity 0.2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
