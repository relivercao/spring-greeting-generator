<template>
  <el-dialog
    v-model="dialogVisible"
    width="min(920px, 94vw)"
    :close-on-click-modal="false"
    class="mask-dialog"
    @opened="initializeEditor"
  >
    <template #header>
      <div class="mask-heading">
        <div>
          <div class="mask-title">
            Mask Editor
          </div>
          <div class="mask-file">
            {{ image?.name || 'Reference image' }}
          </div>
        </div>
        <div class="mask-legend">
          <span><i class="keep-swatch" />Keep</span>
          <span><i class="edit-swatch" />Edit</span>
        </div>
      </div>
    </template>

    <div class="editor-shell">
      <div class="editor-toolbar">
        <div class="brush-control">
          <el-icon><Brush /></el-icon>
          <span>Brush size</span>
          <el-slider
            v-model="brushSize"
            :min="10"
            :max="300"
            :step="5"
          />
          <span class="brush-value">{{ brushSize }}</span>
        </div>
        <div class="tool-actions">
          <el-tooltip
            content="Undo"
            placement="top"
          >
            <button
              class="icon-button"
              :disabled="history.length === 0"
              @click="undo"
            >
              <el-icon><RefreshLeft /></el-icon>
            </button>
          </el-tooltip>
          <el-tooltip
            content="Clear mask"
            placement="top"
          >
            <button
              class="icon-button"
              @click="clearMask"
            >
              <el-icon><Delete /></el-icon>
            </button>
          </el-tooltip>
        </div>
      </div>

      <div
        v-loading="loading"
        class="canvas-viewport"
      >
        <canvas
          ref="displayCanvas"
          class="mask-canvas"
          @pointerdown="startStroke"
          @pointermove="continueStroke"
          @pointerup="endStroke"
          @pointercancel="endStroke"
          @pointerleave="endStroke"
        />
      </div>
    </div>

    <template #footer>
      <div class="dialog-actions">
        <el-button @click="dialogVisible = false">
          Cancel
        </el-button>
        <el-button
          type="primary"
          :disabled="loading"
          @click="saveMask"
        >
          Apply Mask
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Brush, Delete, RefreshLeft } from '@element-plus/icons-vue'

const props = defineProps({
  modelValue: Boolean,
  image: Object,
})
const emit = defineEmits(['update:modelValue', 'save'])

const dialogVisible = computed({
  get: () => props.modelValue,
  set: (value) => emit('update:modelValue', value),
})
const displayCanvas = ref(null)
const brushSize = ref(80)
const history = ref([])
const loading = ref(false)
let maskCanvas = null
let sourceImage = null
let drawing = false
let lastPoint = null

async function initializeEditor() {
  if (!props.image?.url || !displayCanvas.value) return
  loading.value = true
  history.value = []
  try {
    sourceImage = await loadImage(props.image.url)
    const canvas = displayCanvas.value
    const longestEdge = Math.max(sourceImage.naturalWidth, sourceImage.naturalHeight)
    const scale = Math.min(1, 1920 / longestEdge)
    canvas.width = scale < 1
      ? Math.max(16, Math.floor(sourceImage.naturalWidth * scale / 16) * 16)
      : sourceImage.naturalWidth
    canvas.height = scale < 1
      ? Math.max(16, Math.floor(sourceImage.naturalHeight * scale / 16) * 16)
      : sourceImage.naturalHeight
    maskCanvas = document.createElement('canvas')
    maskCanvas.width = canvas.width
    maskCanvas.height = canvas.height
    const context = maskCanvas.getContext('2d')
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, maskCanvas.width, maskCanvas.height)
    renderCanvas()
  } catch (error) {
    ElMessage.error(error.message || 'Failed to load the reference image')
  } finally {
    loading.value = false
  }
}

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = () => reject(new Error('Failed to load the reference image'))
    image.src = url
  })
}

function renderCanvas() {
  if (!displayCanvas.value || !sourceImage || !maskCanvas) return
  const context = displayCanvas.value.getContext('2d')
  context.clearRect(0, 0, displayCanvas.value.width, displayCanvas.value.height)
  context.globalAlpha = 1
  context.drawImage(sourceImage, 0, 0, displayCanvas.value.width, displayCanvas.value.height)
  context.globalAlpha = 0.42
  context.drawImage(maskCanvas, 0, 0)
  context.globalAlpha = 1
}

function pointerPosition(event) {
  const rect = displayCanvas.value.getBoundingClientRect()
  return {
    x: (event.clientX - rect.left) * (displayCanvas.value.width / rect.width),
    y: (event.clientY - rect.top) * (displayCanvas.value.height / rect.height),
  }
}

function startStroke(event) {
  if (!maskCanvas) return
  event.preventDefault()
  displayCanvas.value.setPointerCapture?.(event.pointerId)
  const context = maskCanvas.getContext('2d')
  history.value.push(context.getImageData(0, 0, maskCanvas.width, maskCanvas.height))
  if (history.value.length > 8) history.value.shift()
  drawing = true
  lastPoint = pointerPosition(event)
  drawSegment(lastPoint, lastPoint)
}

function continueStroke(event) {
  if (!drawing || !lastPoint) return
  event.preventDefault()
  const point = pointerPosition(event)
  drawSegment(lastPoint, point)
  lastPoint = point
}

function endStroke() {
  drawing = false
  lastPoint = null
}

function drawSegment(from, to) {
  const context = maskCanvas.getContext('2d')
  context.save()
  context.globalCompositeOperation = 'destination-out'
  context.lineCap = 'round'
  context.lineJoin = 'round'
  context.lineWidth = brushSize.value
  context.beginPath()
  context.moveTo(from.x, from.y)
  context.lineTo(to.x, to.y)
  context.stroke()
  context.restore()
  renderCanvas()
}

function undo() {
  const snapshot = history.value.pop()
  if (!snapshot || !maskCanvas) return
  maskCanvas.getContext('2d').putImageData(snapshot, 0, 0)
  renderCanvas()
}

function clearMask() {
  if (!maskCanvas) return
  const context = maskCanvas.getContext('2d')
  history.value.push(context.getImageData(0, 0, maskCanvas.width, maskCanvas.height))
  context.globalCompositeOperation = 'source-over'
  context.fillStyle = '#ffffff'
  context.fillRect(0, 0, maskCanvas.width, maskCanvas.height)
  renderCanvas()
}

function saveMask() {
  if (!maskCanvas) return
  const alpha = maskCanvas.getContext('2d').getImageData(
    0,
    0,
    maskCanvas.width,
    maskCanvas.height,
  ).data
  let hasEditableRegion = false
  for (let index = 3; index < alpha.length; index += 4) {
    if (alpha[index] < 255) {
      hasEditableRegion = true
      break
    }
  }
  if (!hasEditableRegion) {
    ElMessage.warning('Paint at least one region before applying the mask')
    return
  }
  maskCanvas.toBlob((blob) => {
    if (!blob) {
      ElMessage.error('Failed to create the mask image')
      return
    }
    emit('save', blob)
    dialogVisible.value = false
  }, 'image/png')
}
</script>

<style scoped>
.mask-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.mask-title {
  color: #111827;
  font-size: 16px;
  font-weight: 700;
}

.mask-file {
  max-width: 420px;
  margin-top: 2px;
  overflow: hidden;
  color: #6b7280;
  font-size: 12px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mask-legend {
  display: flex;
  gap: 12px;
  color: #6b7280;
  font-size: 12px;
}

.mask-legend span {
  display: flex;
  align-items: center;
  gap: 5px;
}

.mask-legend i {
  width: 10px;
  height: 10px;
  border: 1px solid #cbd5e1;
  border-radius: 2px;
}

.keep-swatch {
  background: #ffffff;
}

.edit-swatch {
  background: #2563eb;
}

.editor-shell {
  overflow: hidden;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  background: #f8fafc;
}

.editor-toolbar {
  min-height: 52px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 8px 12px;
  border-bottom: 1px solid #e5e7eb;
  background: #ffffff;
}

.brush-control {
  min-width: 0;
  display: grid;
  flex: 1;
  grid-template-columns: 18px auto minmax(120px, 280px) 34px;
  align-items: center;
  gap: 9px;
  color: #475569;
  font-size: 12px;
}

.brush-value {
  color: #64748b;
  font-variant-numeric: tabular-nums;
  text-align: right;
}

.tool-actions {
  display: flex;
  gap: 6px;
}

.icon-button {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  color: #475569;
  background: #ffffff;
  cursor: pointer;
}

.icon-button:hover:not(:disabled) {
  color: #2563eb;
  border-color: #93c5fd;
  background: #eff6ff;
}

.icon-button:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

.canvas-viewport {
  min-height: 360px;
  max-height: 64vh;
  display: grid;
  place-items: center;
  overflow: auto;
  padding: 18px;
  background-color: #e5e7eb;
  background-image:
    linear-gradient(45deg, #f8fafc 25%, transparent 25%),
    linear-gradient(-45deg, #f8fafc 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #f8fafc 75%),
    linear-gradient(-45deg, transparent 75%, #f8fafc 75%);
  background-position: 0 0, 0 8px, 8px -8px, -8px 0;
  background-size: 16px 16px;
}

.mask-canvas {
  max-width: 100%;
  max-height: calc(64vh - 36px);
  display: block;
  border: 1px solid #cbd5e1;
  background: #ffffff;
  box-shadow: 0 8px 28px rgb(15 23 42 / 14%);
  cursor: crosshair;
  touch-action: none;
}

.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

@media (max-width: 640px) {
  .mask-heading,
  .editor-toolbar {
    align-items: stretch;
    flex-direction: column;
  }

  .brush-control {
    grid-template-columns: 18px auto minmax(80px, 1fr) 34px;
  }

  .tool-actions {
    justify-content: flex-end;
  }

  .canvas-viewport {
    min-height: 280px;
    padding: 10px;
  }
}
</style>
