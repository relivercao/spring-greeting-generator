<template>
  <section v-if="documents.length" class="generated-files" aria-label="Generated files">
    <div class="files-heading">
      Generated files <span>{{ documents.length }}</span>
    </div>
    <article v-for="file in documents" :key="file.url" class="generated-file">
      <div class="file-format" aria-hidden="true">{{ file.extension }}</div>
      <div class="file-details">
        <a
          class="file-name"
          :href="file.url"
          target="_blank"
          rel="noopener noreferrer"
          :title="file.name"
        >
          {{ file.name }}
        </a>
        <div class="file-meta">
          {{ file.extension
          }}<span v-if="file.size !== null"> · {{ fileSizeLabel(file.size) }}</span>
        </div>
        <div v-if="file.path" class="file-path" :title="file.path">{{ file.path }}</div>
        <div class="file-actions">
          <a
            :href="file.url"
            target="_blank"
            rel="noopener noreferrer"
            :aria-label="`Open ${file.name}`"
          >
            Open file <span aria-hidden="true">↗</span>
          </a>
          <a :href="file.downloadUrl" :download="file.name" :aria-label="`Download ${file.name}`">
            Download
          </a>
          <button type="button" :aria-label="`Copy link for ${file.name}`" @click="copyLink(file)">
            {{ copied === file.url ? 'Copied' : 'Copy link' }}
          </button>
        </div>
      </div>
    </article>
    <p v-if="copyError" class="copy-error" role="alert">{{ copyError }}</p>
    <span class="copy-status" role="status" aria-live="polite">{{
      copied ? 'File link copied.' : ''
    }}</span>
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'
import { generatedFiles, fileSizeLabel } from '../utils/generatedFiles.js'

const props = defineProps({
  files: { type: Array, default: () => [] },
  content: { type: String, default: '' },
})
const documents = computed(() => generatedFiles(props.files, props.content))
const copied = ref('')
const copyError = ref('')

async function copyLink(file) {
  copyError.value = ''
  copied.value = ''
  try {
    await navigator.clipboard.writeText(new URL(file.url, window.location.origin).href)
    copied.value = file.url
  } catch {
    copyError.value = 'Could not copy the link. Right-click the file link to copy it.'
  }
}
</script>

<style scoped>
.generated-files {
  position: relative;
  width: 100%;
  min-width: 0;
  margin-top: 12px;
  color: #334155;
}
.files-heading {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 8px;
  color: #64748b;
  font-size: 11px;
  font-weight: 600;
}
.files-heading span {
  padding: 1px 5px;
  border-radius: 4px;
  background: #e8edf4;
}
.generated-file {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px;
  margin-top: 6px;
  border: 1px solid #dce4ef;
  border-radius: 10px;
  background: #fff;
}
.file-format {
  flex: 0 0 40px;
  padding: 10px 2px;
  border-radius: 7px;
  background: #eef2ff;
  color: #5561b8;
  text-align: center;
  font-size: 10px;
  font-weight: 700;
}
.file-details {
  min-width: 0;
  flex: 1;
}
.file-name {
  display: block;
  color: #2563eb;
  font-size: 13px;
  font-weight: 600;
  line-height: 1.5;
  overflow-wrap: anywhere;
  text-decoration: underline;
  text-underline-offset: 3px;
}
.file-name:hover,
.file-actions a:hover {
  color: #1e40af;
}
.file-meta {
  margin-top: 3px;
  color: #64748b;
  font-size: 10px;
}
.file-path {
  overflow: hidden;
  margin-top: 4px;
  color: #94a3b8;
  font-size: 10px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.file-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 14px;
  margin-top: 9px;
}
.file-actions a {
  color: #2563eb;
  font-size: 11px;
  font-weight: 500;
  text-underline-offset: 3px;
}
.file-actions button {
  border: 0;
  padding: 0;
  background: none;
  color: #64748b;
  font: inherit;
  font-size: 11px;
  cursor: pointer;
}
.file-actions button:hover {
  color: #2563eb;
  text-decoration: underline;
}
a:focus-visible,
button:focus-visible {
  outline: 2px solid #6366f1;
  outline-offset: 3px;
  border-radius: 2px;
}
.copy-error {
  margin: 8px 0 0;
  color: #b91c1c;
  font-size: 11px;
}
.copy-status {
  position: absolute;
  top: 0;
  left: 0;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
