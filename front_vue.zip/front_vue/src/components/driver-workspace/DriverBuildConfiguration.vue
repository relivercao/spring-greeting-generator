<!--
  @file DriverBuildConfiguration.vue
  @author zhangjian
  @brief Build configuration form for Driver workspace platform settings.
  @version 1.0
  @date 2026-07-24
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component loads and saves Driver build configuration through the Driver
  API client while keeping editable platform settings in the parent workspace
  config payload.
-->
<template>
  <div class="input-section">
    <div class="input-section-header">
      <div>
        <p class="eyebrow eyebrow-orange">
          Build Configuration
        </p>
        <h3>Select platform-specific build settings</h3>
      </div>
      <span class="input-section-badge optional">Optional</span>
    </div>
    <div class="input-section-body">
      <label class="input-label">
        Platform
        <span class="label-hint">(Select first)</span>
      </label>
      <select
        :value="selectedPlatform"
        class="select-input"
        :disabled="isLoadingBuildConfig || isSavingBuildConfig"
        @change="handlePlatformChange"
      >
        <option
          v-for="platform in platformOptions"
          :key="platform.value"
          :value="platform.value"
        >
          {{ platform.label }}
        </option>
      </select>
      <p class="field-description">
        Saved paths are loaded separately for each target platform.
      </p>

      <label class="input-label">
        {{ currentPlatform.editorPathLabel }}
        <span class="label-hint">(Optional; auto-detected for STM32)</span>
      </label>
      <input
        :value="editorPath"
        type="text"
        class="text-input"
        :placeholder="currentPlatform.editorPathPlaceholder"
        :disabled="isLoadingBuildConfig || isSavingBuildConfig"
        @input="updateField('editor_path', $event.target.value)"
        @change="commitField('editor_path', $event.target.value)"
      >
      <p class="field-description">
        <template v-if="selectedPlatform === 'stm32' && props.config.resolved_stm32cubeide_path">
          Detected on this PC: {{ props.config.resolved_stm32cubeide_path }}
          <span v-if="props.config.path_source">({{ props.config.path_source }})</span>.
          Leave the field blank to use automatic detection.
        </template>
        <template v-else>
          {{ currentPlatform.editorPathDescription }}
        </template>
      </p>

      <label class="input-label">
        Project Path
        <span class="label-hint">(Required for compilation)</span>
      </label>
      <input
        :value="config.project_path"
        type="text"
        class="text-input"
        :placeholder="currentPlatform.projectPathPlaceholder"
        :disabled="isLoadingBuildConfig || isSavingBuildConfig"
        @input="updateField('project_path', $event.target.value)"
        @change="commitField('project_path', $event.target.value)"
      >
      <p class="field-description">
        {{ currentPlatform.projectPathDescription }}
      </p>
      <p
        v-if="buildConfigStatusMessage"
        :class="['field-status', buildConfigStatusClass]"
      >
        {{ buildConfigStatusMessage }}
      </p>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { apiGetDriverBuildConfig, apiSaveDriverBuildConfig } from '../../api/driver.js'

const DEFAULT_PLATFORM = 'stm32'
const LEGACY_STM32_PLATFORM = 'st32'

const PLATFORM_OPTIONS = [
  {
    value: DEFAULT_PLATFORM,
    label: 'STM32',
    editorPathLabel: 'Editor / Build Tool Path',
    editorPathPlaceholder: 'e.g., C:\\Tools\\PlatformIDE',
    editorPathDescription: 'Path to the selected platform editor or build tooling directory',
    projectPathPlaceholder: 'e.g., D:\\work\\project\\NonSecure',
    projectPathDescription: 'Path to the selected platform project directory',
  },
]

const props = defineProps({
  config: {
    type: Object,
    required: true,
  },
})

const emit = defineEmits(['update:config'])

const savedBuildConfig = ref(createEmptyBuildConfig())
const isLoadingBuildConfig = ref(false)
const isSavingBuildConfig = ref(false)
const buildConfigError = ref('')
const hasSavedBuildConfig = ref(false)

const platformOptions = PLATFORM_OPTIONS

const selectedPlatform = computed(() =>
  normalizePlatform(props.config.platform || DEFAULT_PLATFORM)
)
const currentPlatform = computed(
  () =>
    platformOptions.find(platform => platform.value === selectedPlatform.value) ||
    platformOptions[0]
)
const editorPath = computed(() => props.config.editor_path || props.config.stm32cubeide_path || '')
const buildConfigStatusMessage = computed(() => {
  if (isLoadingBuildConfig.value) return 'Loading saved build configuration...'
  if (isSavingBuildConfig.value) return 'Saving build configuration...'
  if (buildConfigError.value) return buildConfigError.value
  if (hasSavedBuildConfig.value) return 'Build configuration saved.'
  return ''
})
const buildConfigStatusClass = computed(() => (buildConfigError.value ? 'error' : 'muted'))

onMounted(async () => {
  isLoadingBuildConfig.value = true
  buildConfigError.value = ''

  try {
    const savedConfig = await apiGetDriverBuildConfig()
    savedBuildConfig.value = normalizeSavedBuildConfig(savedConfig)

    const platform = normalizePlatform(
      savedConfig?.selected_platform ||
        savedConfig?.platform ||
        props.config.platform ||
        DEFAULT_PLATFORM
    )
    const platformConfig = getSavedPlatformConfig(platform)

    emit('update:config', {
      ...props.config,
      platform,
      editor_path: platformConfig.editor_path || platformConfig.stm32cubeide_path || '',
      stm32cubeide_path: platformConfig.stm32cubeide_path || platformConfig.editor_path || '',
      project_path: platformConfig.project_path || '',
      resolved_stm32cubeide_path: savedConfig.resolved_stm32cubeide_path || null,
      stm32cubeide_executable: savedConfig.stm32cubeide_executable || null,
      path_source: savedConfig.path_source || null,
    })
  } catch (error) {
    buildConfigError.value = 'Unable to load saved build configuration.'
    console.error('Failed to load driver build config:', error)
  } finally {
    isLoadingBuildConfig.value = false
  }
})

async function handlePlatformChange(event) {
  const platform = normalizePlatform(event.target.value)
  const platformConfig = getSavedPlatformConfig(platform)
  const newConfig = {
    ...props.config,
    platform,
    editor_path: platformConfig.editor_path || platformConfig.stm32cubeide_path || '',
    stm32cubeide_path: platformConfig.stm32cubeide_path || platformConfig.editor_path || '',
    project_path: platformConfig.project_path || '',
  }

  emit('update:config', newConfig)
  await saveBuildConfig(newConfig)
}

function updateField(key, value) {
  const newConfig = {
    ...props.config,
    [key]: value,
  }

  if (key === 'editor_path') {
    newConfig.stm32cubeide_path = value
  }

  emit('update:config', newConfig)
  buildConfigError.value = ''
  hasSavedBuildConfig.value = false
}

async function commitField(key, value) {
  const newConfig = {
    ...props.config,
    [key]: value,
  }

  if (key === 'editor_path') {
    newConfig.stm32cubeide_path = value
  }

  emit('update:config', newConfig)
  await saveBuildConfig(newConfig)
}

async function saveBuildConfig(config) {
  isSavingBuildConfig.value = true
  buildConfigError.value = ''

  try {
    const payload = {
      platform: normalizePlatform(config.platform || selectedPlatform.value),
      editor_path: config.editor_path || config.stm32cubeide_path || '',
      stm32cubeide_path: config.stm32cubeide_path || config.editor_path || '',
      project_path: config.project_path || '',
    }
    const savedConfig = await apiSaveDriverBuildConfig(payload)
    mergeSavedPlatformConfig({ ...payload, ...(savedConfig || {}) })
    emit('update:config', {
      ...props.config,
      resolved_stm32cubeide_path: savedConfig?.resolved_stm32cubeide_path || null,
      stm32cubeide_executable: savedConfig?.stm32cubeide_executable || null,
      path_source: savedConfig?.path_source || null,
    })
    hasSavedBuildConfig.value = true
  } catch (error) {
    buildConfigError.value = 'Unable to save build configuration.'
    console.error('Failed to save driver build config:', error)
  } finally {
    isSavingBuildConfig.value = false
  }
}

function createEmptyBuildConfig() {
  return { platform_configs: {} }
}

function normalizeSavedBuildConfig(savedConfig) {
  if (!savedConfig) {
    return createEmptyBuildConfig()
  }

  const platform = normalizePlatform(
    savedConfig.selected_platform || savedConfig.platform || DEFAULT_PLATFORM
  )
  const platformConfigs = { ...(savedConfig.platform_configs || {}) }
  const legacyPlatformConfig =
    platform === DEFAULT_PLATFORM ? platformConfigs[LEGACY_STM32_PLATFORM] : null

  if (!platformConfigs[platform]) {
    platformConfigs[platform] = {
      editor_path:
        legacyPlatformConfig?.editor_path ||
        legacyPlatformConfig?.stm32cubeide_path ||
        savedConfig.editor_path ||
        savedConfig.stm32cubeide_path ||
        '',
      stm32cubeide_path:
        legacyPlatformConfig?.stm32cubeide_path ||
        legacyPlatformConfig?.editor_path ||
        savedConfig.stm32cubeide_path ||
        savedConfig.editor_path ||
        '',
      project_path: legacyPlatformConfig?.project_path || savedConfig.project_path || '',
      updated_at: legacyPlatformConfig?.updated_at || savedConfig.updated_at || null,
    }
  }

  return {
    ...savedConfig,
    selected_platform: platform,
    platform_configs: platformConfigs,
  }
}

function getSavedPlatformConfig(platform) {
  const configs = savedBuildConfig.value?.platform_configs || {}
  const normalizedPlatform = normalizePlatform(platform)
  if (normalizedPlatform === DEFAULT_PLATFORM) {
    return configs[DEFAULT_PLATFORM] || configs[LEGACY_STM32_PLATFORM] || {}
  }
  return configs[normalizedPlatform] || {}
}

function mergeSavedPlatformConfig(savedConfig) {
  const platform = normalizePlatform(
    savedConfig.platform || savedConfig.selected_platform || DEFAULT_PLATFORM
  )
  const platformConfigs = {
    ...(savedBuildConfig.value?.platform_configs || {}),
    [platform]: {
      ...(savedBuildConfig.value?.platform_configs?.[platform] || {}),
      editor_path: savedConfig.editor_path || savedConfig.stm32cubeide_path || '',
      stm32cubeide_path: savedConfig.stm32cubeide_path || savedConfig.editor_path || '',
      project_path: savedConfig.project_path || '',
      updated_at: savedConfig.updated_at || null,
    },
  }

  savedBuildConfig.value = {
    ...savedBuildConfig.value,
    ...savedConfig,
    selected_platform: platform,
    platform_configs: platformConfigs,
  }
}

function normalizePlatform(platform) {
  const value = String(platform || '')
    .trim()
    .toLowerCase()
  if (!value) {
    return DEFAULT_PLATFORM
  }
  // Keep the legacy "st32" alias for persisted configs created before platform normalization.
  if (value === LEGACY_STM32_PLATFORM) {
    return DEFAULT_PLATFORM
  }
  if (platformOptions.some(option => option.value === value)) {
    return value
  }
  return value
}
</script>

<style scoped>
.input-section {
  border-bottom: 1px solid rgba(148, 163, 184, 0.12);
}

.input-section:last-child {
  border-bottom: none;
}

.input-section-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  padding: clamp(8px, 1.1vh, 10px) clamp(10px, 0.9vw, 12px) 0;
}

.input-section-header h3 {
  margin: 0;
  color: #64748b;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.3;
}

.input-section-badge {
  flex-shrink: 0;
  padding: 3px 9px;
  border-radius: 20px;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.04em;
  white-space: nowrap;
}

.input-section-badge.optional {
  color: #64748b;
  background: #f1f5f9;
}

.eyebrow {
  margin: 0 0 3px;
  font-size: 11px;
  font-weight: 800;
  line-height: 1.2;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.eyebrow-orange {
  color: #ea580c;
}

.input-section-body {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: clamp(7px, 1vh, 8px) clamp(10px, 0.9vw, 12px) clamp(9px, 1.2vh, 12px);
}

.input-label {
  display: flex;
  align-items: baseline;
  gap: 6px;
  color: #334155;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.03em;
}

.label-hint {
  color: #94a3b8;
  font-size: 10px;
  font-weight: 500;
}

.select-input,
.text-input {
  width: 100%;
  height: 38px;
  padding: 0 14px;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  color: #0f172a;
  background: #ffffff;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  transition:
    border-color 0.18s ease,
    box-shadow 0.18s ease;
}

.select-input {
  cursor: pointer;
}

.text-input::placeholder {
  color: #94a3b8;
}

.select-input:hover,
.text-input:hover {
  border-color: #fb923c;
}

.select-input:disabled,
.text-input:disabled {
  cursor: not-allowed;
  color: #94a3b8;
  background: #f8fafc;
}

.select-input:focus,
.text-input:focus {
  outline: none;
  border-color: #ea580c;
  box-shadow: 0 0 0 3px rgba(234, 88, 12, 0.08);
}

.field-description {
  margin: -4px 0 0;
  color: #94a3b8;
  font-size: 10px;
  line-height: 1.4;
}

.field-status {
  margin: 2px 0 0;
  font-size: 10px;
  line-height: 1.4;
}

.field-status.muted {
  color: #64748b;
}

.field-status.error {
  color: #dc2626;
}
</style>
