<!--
  @file DriverChipConfiguration.vue
  @author zhangjian
  @brief Module configuration form for Driver workspace generation inputs.
  @version 1.0
  @date 2026-07-23
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component updates Driver module options through a single config payload
  emitted to the parent. It does not persist configuration or call backend APIs.
-->
<template>
  <div class="input-section">
    <div class="input-section-header">
      <div>
        <p class="eyebrow eyebrow-emerald">
          Module Configuration
        </p>
        <h3>Select the target driver module</h3>
      </div>
      <span class="input-section-badge required">Required</span>
    </div>
    <div class="input-section-body">
      <label class="input-label">Module Type</label>
      <select
        v-if="!isCustomModuleType"
        :value="selectedModuleType"
        class="select-input"
        @change="onModuleTypeChange($event.target.value)"
      >
        <option
          v-for="type in moduleTypes"
          :key="type"
          :value="type"
        >
          {{ type }}
        </option>
      </select>
      <div
        v-else
        class="custom-type-row"
      >
        <input
          :value="config.moduleType"
          type="text"
          class="text-input"
          placeholder="Enter custom module type (e.g., Motor Driver)"
          @input="updateField('moduleType', $event.target.value)"
        >
        <button
          type="button"
          class="back-to-list-btn"
          title="Back to preset list"
          @click="onModuleTypeChange('')"
        >
          <svg
            viewBox="0 0 16 16"
            width="16"
            height="16"
            fill="none"
            stroke="currentColor"
            stroke-width="1.6"
            stroke-linecap="round"
            stroke-linejoin="round"
          >
            <polyline points="4 10 8 14 12 10" />
            <line
              x1="8"
              y1="2"
              x2="8"
              y2="13.5"
            />
          </svg>
        </button>
      </div>

      <label class="input-label">Module Name</label>
      <input
        :value="config.moduleName"
        type="text"
        class="text-input"
        placeholder="e.g., IMU Sensor, LED Matrix, GPIO Button"
        @input="updateField('moduleName', $event.target.value)"
      >

      <div class="checkbox-group">
        <label class="checkbox-label">
          <input
            type="checkbox"
            :checked="config.generateTests"
            class="checkbox-input"
            @change="updateField('generateTests', $event.target.checked)"
          >
          <span class="checkbox-text">Generate unit tests</span>
        </label>
        <label class="checkbox-label">
          <input
            type="checkbox"
            :checked="config.generateCodeReview"
            class="checkbox-input"
            @change="updateField('generateCodeReview', $event.target.checked)"
          >
          <span class="checkbox-text">Generate code review</span>
        </label>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  config: {
    type: Object,
    required: true,
  },
  moduleTypes: {
    type: Array,
    required: true,
  },
})

const emit = defineEmits(['update:config'])

const CUSTOM_MODULE_TYPE = 'Other'

const isCustomModuleType = computed(() => {
  const current = props.config.moduleType || ''
  return !props.moduleTypes.includes(current) || current === CUSTOM_MODULE_TYPE
})

const selectedModuleType = computed(() => {
  const current = props.config.moduleType
  return props.moduleTypes.includes(current) ? current : props.moduleTypes[0]
})

function updateField(key, value) {
  emit('update:config', {
    ...props.config,
    [key]: value,
  })
}

function onModuleTypeChange(value) {
  if (value === CUSTOM_MODULE_TYPE) {
    updateField('moduleType', '')
    return
  }
  updateField('moduleType', value || props.moduleTypes[0])
}
</script>

<style scoped>
.input-section {
  border-bottom: 1px solid rgba(148, 163, 184, 0.12);
}

.input-section:last-child {
  border-bottom: none;
}

.input-section-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  padding: clamp(8px, 1.1vh, 10px) clamp(10px, 0.9vw, 12px) 0;
}

.input-section-header h3 {
  margin: 0;
  color: #64748b;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.3;
}

.input-section-badge {
  flex-shrink: 0;
  padding: 3px 9px;
  border-radius: 20px;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.04em;
  white-space: nowrap;
}

.input-section-badge.required {
  color: #b45309;
  background: #fef3c7;
}

.eyebrow {
  margin: 0 0 3px;
  font-size: 11px;
  font-weight: 800;
  line-height: 1.2;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.eyebrow-emerald {
  color: #059669;
}

.input-section-body {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: clamp(7px, 1vh, 8px) clamp(10px, 0.9vw, 12px) clamp(9px, 1.2vh, 12px);
}

.input-label {
  color: #334155;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.03em;
}

.select-input,
.text-input {
  width: 100%;
  height: 38px;
  padding: 0 14px;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  color: #0f172a;
  background: #ffffff;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  transition: border-color 0.18s ease, box-shadow 0.18s ease;
}

.select-input {
  cursor: pointer;
}

.text-input::placeholder {
  color: #94a3b8;
}

.select-input:hover,
.text-input:hover {
  border-color: #93c5fd;
}

.select-input:focus,
.text-input:focus {
  outline: none;
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.08);
}

.custom-type-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.back-to-list-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 38px;
  height: 38px;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  color: #64748b;
  background: #ffffff;
  cursor: pointer;
  transition: border-color 0.18s ease, color 0.18s ease;
}

.back-to-list-btn:hover {
  border-color: #93c5fd;
  color: #2563eb;
}

.checkbox-group {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 4px;
}

.checkbox-label {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
  user-select: none;
}

.checkbox-input {
  width: 18px;
  height: 18px;
  cursor: pointer;
  accent-color: #2563eb;
}

.checkbox-input:disabled {
  cursor: not-allowed;
}

.checkbox-text {
  color: #334155;
  font-size: 12px;
  font-weight: 500;
}

.checkbox-label:hover .checkbox-text {
  color: #0f172a;
}

</style>
