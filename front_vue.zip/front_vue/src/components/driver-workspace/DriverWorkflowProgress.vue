<!--
  @file DriverWorkflowProgress.vue
  @author zhangjian
  @brief Progress display for the Driver workspace generation workflow.
  @version 1.0
  @date 2026-07-24
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component renders backend task progress, token usage, and pipeline step
  state supplied by the parent Driver workspace. It does not poll or mutate
  task state.
-->
<template>
  <div class="workflow-progress">
    <div class="loading-header">
      <div
        class="ring-wrap"
        role="progressbar"
        :aria-label="`${title} progress`"
        :aria-valuenow="roundedProgress"
        aria-valuemin="0"
        aria-valuemax="100"
      >
        <svg
          class="ring-svg"
          viewBox="0 0 36 36"
          aria-hidden="true"
        >
          <circle
            class="ring-bg"
            cx="18"
            cy="18"
            r="15"
          />
          <circle
            class="ring-fg"
            cx="18"
            cy="18"
            r="15"
            :style="{ strokeDashoffset: progressOffset }"
          />
        </svg>
        <span class="ring-pct">{{ progressLabel }}</span>
      </div>
      <div class="loading-msg">
        <div class="msg-title">
          {{ statusTitle }}
        </div>
        <div class="msg-sub">
          {{ statusDescription }}
        </div>
      </div>
    </div>

    <div
      v-if="showTokenUsage"
      class="token-usage-display"
    >
      <div class="token-usage-header">
        <span class="token-usage-title">Token Usage</span>
        <span class="token-usage-status">{{ tokenUsageStatusLabel }}</span>
      </div>
      <div class="token-item">
        <span class="token-label">Input</span>
        <span class="token-value">{{ formatTokenCount(normalizedTokenStats.input) }}</span>
      </div>
      <div class="token-item">
        <span class="token-label">Output</span>
        <span class="token-value">{{ formatTokenCount(normalizedTokenStats.output) }}</span>
      </div>
      <div class="token-item">
        <span class="token-label">Cache Write</span>
        <span class="token-value">{{ formatTokenCount(normalizedTokenStats.cacheWrite) }}</span>
      </div>
      <div class="token-item">
        <span class="token-label">Cache Read</span>
        <span class="token-value">{{ formatTokenCount(normalizedTokenStats.cacheRead) }}</span>
      </div>
      <div class="token-item total">
        <span class="token-label">Total</span>
        <span class="token-value">{{ formatTokenCount(normalizedTokenStats.total) }}</span>
      </div>
    </div>

    <div class="pipeline">
      <template
        v-for="(step, index) in steps"
        :key="getStepKey(step, index)"
      >
        <div
          class="pipe-node"
          :class="step.state"
        >
          <div class="pipe-icon">
            <el-icon
              v-if="step.state === 'done'"
              size="18"
              class="pipe-check"
            >
              <CircleCheck />
            </el-icon>
            <el-icon
              v-else-if="step.state === 'fail'"
              size="18"
              class="pipe-fail"
            >
              <CircleClose />
            </el-icon>
            <el-icon
              v-else-if="step.state === 'cancelled'"
              size="18"
              class="pipe-cancelled"
            >
              <CircleClose />
            </el-icon>
            <span
              v-else-if="step.state === 'active'"
              class="pipe-spinner"
            />
            <span
              v-else
              class="pipe-dot"
            />
          </div>
          <span class="pipe-label">{{ step.title }}</span>
        </div>
        <div
          v-if="index < steps.length - 1"
          class="pipe-arrow"
          :class="{ lit: step.state === 'done' }"
          aria-hidden="true"
        >
          <svg
            width="28"
            height="12"
            viewBox="0 0 28 12"
          >
            <line
              x1="0"
              y1="6"
              x2="20"
              y2="6"
              stroke-width="2"
            />
            <polyline
              points="16,2 22,6 16,10"
              stroke-width="2"
              fill="none"
              stroke-linejoin="round"
            />
          </svg>
        </div>
      </template>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { CircleCheck, CircleClose } from '@element-plus/icons-vue'

const CIRCLE_CIRCUMFERENCE = 94.2

const props = defineProps({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  progress: {
    type: Number,
    required: true,
  },
  steps: {
    type: Array,
    required: true,
  },
  tokenStats: {
    type: Object,
    default: () => ({}),
  },
  showTokenUsage: {
    type: Boolean,
    default: true,
  },
  tokenStatus: {
    type: String,
    default: 'pending',
  },
})

const boundedProgress = computed(() => {
  const progress = Number(props.progress)
  if (!Number.isFinite(progress)) return 0
  return Math.min(100, Math.max(0, progress))
})

const roundedProgress = computed(() => Math.round(boundedProgress.value))
const progressLabel = computed(() => `${roundedProgress.value}%`)
const progressOffset = computed(
  () => CIRCLE_CIRCUMFERENCE - (boundedProgress.value / 100) * CIRCLE_CIRCUMFERENCE
)
const hasFailedStep = computed(() => props.steps.some(step => step?.state === 'fail'))
const hasActiveStep = computed(() => props.steps.some(step => step?.state === 'active'))
const allStepsDone = computed(
  () => props.steps.length > 0 && props.steps.every(step => step?.state === 'done')
)

const normalizedTokenStats = computed(() => {
  const input = toTokenNumber(props.tokenStats.input)
  const output = toTokenNumber(props.tokenStats.output)
  const cacheWrite = toTokenNumber(props.tokenStats.cacheWrite)
  const cacheRead = toTokenNumber(props.tokenStats.cacheRead)
  const total =
    props.tokenStats.total === null || props.tokenStats.total === undefined
      ? input + output + cacheWrite + cacheRead
      : toTokenNumber(props.tokenStats.total)

  return {
    input,
    output,
    cacheWrite,
    cacheRead,
    total,
  }
})

const tokenUsageStatusLabel = computed(() => {
  if (props.tokenStatus === 'available') return 'Reported by provider'
  if (props.tokenStatus === 'unavailable') return 'Not reported by provider'
  return 'Waiting for provider usage'
})

const statusTitle = computed(() => {
  if (hasFailedStep.value) return 'Generation Failed'
  if (allStepsDone.value && roundedProgress.value >= 100) return 'Finalizing Package'
  if (hasActiveStep.value && roundedProgress.value >= 100) return 'Finalizing Package'
  if (hasActiveStep.value || roundedProgress.value > 0) return props.title
  return 'Pending'
})

const statusDescription = computed(() => {
  if (hasFailedStep.value) return 'Generation stopped before all workflow steps completed.'
  if (allStepsDone.value && roundedProgress.value >= 100)
    return 'Waiting for generated artifacts from the backend.'
  if (hasActiveStep.value && roundedProgress.value >= 100)
    return 'Waiting for generated artifacts from the backend.'
  return props.description
})

function toTokenNumber(value) {
  const tokenCount = Number(value)
  if (!Number.isFinite(tokenCount)) return 0
  return Math.max(0, Math.round(tokenCount))
}

function formatTokenCount(value) {
  return props.tokenStatus === 'available' ? value.toLocaleString() : 'N/A'
}

function getStepKey(step, index) {
  return `${step?.title || 'step'}-${index}`
}
</script>

<style scoped>
.workflow-progress {
  padding: 8px;
}

.loading-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 20px;
}

.ring-wrap {
  position: relative;
  width: 52px;
  height: 52px;
  flex-shrink: 0;
}

.ring-svg {
  width: 52px;
  height: 52px;
  transform: rotate(-90deg);
}

.ring-bg {
  fill: none;
  stroke: #e5e7eb;
  stroke-width: 3;
}

.ring-fg {
  fill: none;
  stroke: #2563eb;
  stroke-width: 3;
  stroke-dasharray: 94.2;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.5s ease;
}

.ring-pct {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #2563eb;
  font-size: 10px;
  font-weight: 700;
}

.loading-msg {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.msg-title {
  color: #1f2937;
  font-size: 14px;
  font-weight: 600;
}

.msg-sub {
  color: #6b7280;
  font-size: 12px;
  line-height: 1.4;
  overflow-wrap: anywhere;
}

.token-usage-display {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(118px, 1fr));
  gap: 8px 12px;
  padding: 12px 16px;
  margin-bottom: 16px;
  border: 1px solid #bae6fd;
  border-radius: 10px;
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
}

.token-usage-header {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-width: 0;
}

.token-usage-title,
.token-usage-status {
  color: #0369a1;
  font-size: 12px;
  font-weight: 600;
}

.token-usage-status {
  overflow-wrap: anywhere;
  text-align: right;
}

.token-item {
  min-width: 0;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 6px;
}

.token-label {
  color: #0369a1;
  font-size: 12px;
  font-weight: 500;
}

.token-value {
  min-width: 0;
  color: #0c4a6e;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  font-weight: 600;
  overflow-wrap: anywhere;
}

.token-item.total {
  padding-left: 12px;
  border-left: 1px solid #7dd3fc;
}

.token-item.total .token-label {
  color: #0369a1;
  font-weight: 600;
}

.token-item.total .token-value {
  color: #0c4a6e;
  font-size: 14px;
  font-weight: 700;
}

.pipeline {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: nowrap;
  gap: 0;
  padding: 4px 0;
  overflow-x: auto;
}

.pipe-node {
  min-width: 72px;
  display: flex;
  flex-shrink: 0;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.pipe-icon {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid #e5e7eb;
  border-radius: 50%;
  background: #f9fafb;
  transition: all 0.3s;
}

.pipe-label {
  color: #6b7280;
  font-size: 11px;
  text-align: center;
  white-space: nowrap;
}

.pipe-node.done .pipe-icon {
  border-color: #16a34a;
  background: #f0fdf4;
}

.pipe-node.done .pipe-label {
  color: #166534;
  font-weight: 500;
}

.pipe-check {
  color: #16a34a;
}

.pipe-fail {
  color: #ef4444;
}

.pipe-cancelled {
  color: #d97706;
}

.pipe-node.fail .pipe-icon {
  border-color: #ef4444;
  background: #fef2f2;
}

.pipe-node.fail .pipe-label {
  color: #ef4444;
}

.pipe-node.cancelled .pipe-icon {
  border-color: #f59e0b;
  background: #fffbeb;
}

.pipe-node.cancelled .pipe-label {
  color: #b45309;
}

.pipe-node.active .pipe-icon {
  border-color: #2563eb;
  background: #eff6ff;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

.pipe-node.active .pipe-label {
  color: #1d4ed8;
  font-weight: 600;
}

.pipe-node.pending .pipe-label {
  color: #9ca3af;
}

.pipe-node.skipped .pipe-label {
  color: #9ca3af;
}

.pipe-spinner {
  width: 18px;
  height: 18px;
  display: inline-block;
  border: 2px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

.pipe-dot {
  width: 10px;
  height: 10px;
  display: inline-block;
  border-radius: 50%;
  background: #d1d5db;
}

.pipe-arrow {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  margin: 0 2px 22px;
}

.pipe-arrow svg line,
.pipe-arrow svg polyline {
  stroke: #d1d5db;
  transition: stroke 0.3s;
}

.pipe-arrow.lit svg line,
.pipe-arrow.lit svg polyline {
  stroke: #16a34a;
}

@media (max-width: 720px) {
  .loading-header {
    align-items: flex-start;
  }

  .token-item.total {
    padding-left: 0;
    border-left: none;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
