<!--
  @file DriverChatPanel.vue
  @author zhangjian
  @brief Prompt input panel for Driver workspace generation requests.
  @version 1.0
  @date 2026-07-23
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component collects the user's generation prompt and emits input changes
  and submit shortcuts to the parent Driver workspace flow.
-->
<template>
  <div class="prompt-input-section">
    <div class="section-label">
      <el-icon size="13">
        <Edit />
      </el-icon>
      {{ title }}
    </div>

    <textarea
      :value="input"
      :aria-label="title"
      :placeholder="placeholder"
      :disabled="phase === 'running'"
      class="prompt-textarea"
      @input="$emit('update:input', $event.target.value)"
      @keyup.ctrl.enter="$emit('enter')"
    />

    <div class="prompt-hint">
      {{ hint }}
    </div>
  </div>
</template>

<script setup>
import { Edit } from '@element-plus/icons-vue'

defineProps({
  title: {
    type: String,
    default: 'Generation Prompt',
  },
  placeholder: {
    type: String,
    default: "Describe what you want to generate, e.g., 'Generate an IMU driver for the target STM32 MCU over I2C with initialization and error handling'...",
  },
  hint: {
    type: String,
    default: 'Press Ctrl+Enter or click Generate button below to start',
  },
  input: {
    type: String,
    required: true,
  },
  phase: {
    type: String,
    required: true,
  },
})

defineEmits(['update:input', 'enter'])
</script>

<style scoped>
.prompt-input-section {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.section-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 600;
  color: #334155;
  letter-spacing: 0.01em;
}

.prompt-textarea {
  flex: 1;
  min-height: 140px;
  padding: 12px 14px;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  outline: none;
  color: #1e293b;
  background: #ffffff;
  font-family: inherit;
  font-size: 13px;
  line-height: 1.6;
  resize: vertical;
  transition: all 0.2s ease;
  scrollbar-width: thin;
  scrollbar-color: #cbd5e1 transparent;
}

.prompt-textarea::-webkit-scrollbar {
  width: 6px;
}

.prompt-textarea::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.prompt-textarea::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

.prompt-textarea:focus {
  border-color: #6366f1;
  background: #ffffff;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}

.prompt-textarea::placeholder {
  color: #94a3b8;
}

.prompt-textarea:disabled {
  cursor: not-allowed;
  background: #f1f5f9;
  color: #94a3b8;
  border-color: #e2e8f0;
}

.prompt-hint {
  font-size: 12px;
  color: #64748b;
  margin-top: -4px;
}

@media (max-width: 760px) {
  .prompt-textarea {
    min-height: 120px;
  }
}
</style>
