<template>
  <section
    class="agent-monitor"
    aria-live="polite"
  >
    <header class="monitor-header">
      <div>
        <h3>Agent Runtime</h3>
        <p>{{ currentStageLabel }}</p>
      </div>
      <span class="event-count">{{ events.length }} events</span>
    </header>

    <div
      v-if="runs.length"
      class="agent-runs"
    >
      <div
        v-for="run in runs"
        :key="`${run.agent}:${run.task_id}`"
        class="agent-run"
      >
        <span class="agent-name">{{ run.agent }}</span>
        <span class="run-stage">{{ run.stage || 'Starting' }}</span>
        <span
          class="run-status"
          :class="`status-${run.status}`"
        >{{ run.status }}</span>
      </div>
    </div>
    <p
      v-else
      class="empty-state"
    >
      Waiting for agent runtime details.
    </p>

    <div
      v-if="cliRuntime"
      class="cli-runtime"
    >
      <div class="runtime-metrics">
        <div>
          <span>Elapsed</span><strong>{{ cliRuntime.elapsed_seconds ?? 0 }}s</strong>
        </div>
        <div>
          <span>Tool calls</span><strong>{{ cliRuntime.tool_calls ?? 0 }}</strong>
        </div>
        <div>
          <span>Tool errors</span><strong>{{ cliRuntime.tool_errors ?? 0 }}</strong>
        </div>
        <div>
          <span>MCP</span><strong>{{ cliRuntime.driver_mcp_status || 'pending' }}</strong>
        </div>
      </div>
      <div
        v-if="activeTools.length"
        class="active-tools"
      >
        <span class="section-label">Active tools</span>
        <div
          v-for="tool in activeTools"
          :key="tool.name"
          class="active-tool"
        >
          <code>{{ tool.name }}</code>
          <span>{{ tool.elapsed_seconds }}s</span>
        </div>
      </div>
      <p class="runtime-note">
        Last output {{ cliRuntime.silence_seconds ?? 0 }}s ago
        <span v-if="cliRuntime.last_tool">· {{ cliRuntime.last_tool }}</span>
      </p>
    </div>

    <div
      v-if="events.length"
      class="activity-list"
    >
      <span class="section-label">Recent activity</span>
      <div
        v-for="(event, index) in recentEvents"
        :key="eventKey(event, index)"
        class="activity-row"
      >
        <time>{{ formatTime(event.timestamp) }}</time>
        <div class="activity-copy">
          <strong>{{ event.agent }} · {{ event.stage || 'runtime' }}</strong>
          <span>{{ event.message }}</span>
        </div>
        <span
          v-if="event.runtime"
          class="activity-count"
        >
          {{ event.runtime.tool_calls ?? 0 }} calls
        </span>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  runs: { type: Array, default: () => [] },
  events: { type: Array, default: () => [] },
  cliRuntime: { type: Object, default: null },
  currentStage: { type: String, default: '' },
})

const activeTools = computed(() => props.cliRuntime?.active_tools || [])
const recentEvents = computed(() => props.events.slice(-8).reverse())
const currentStageLabel = computed(() => props.currentStage || 'Monitoring task activity')

function formatTime(value) {
  if (!value) return '--:--:--'
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleTimeString()
}

function eventKey(event, index) {
  return `${event.timestamp || index}:${event.agent}:${event.stage}`
}
</script>

<style scoped>
.agent-monitor {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-width: 0;
  padding: 14px 16px;
  border: 1px solid #d8e0e8;
  border-radius: 8px;
  background: #fff;
  color: #243240;
}

.monitor-header,
.agent-run,
.runtime-note,
.active-tool,
.activity-row {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}

.monitor-header {
  justify-content: space-between;
}

.monitor-header h3 {
  margin: 0;
  font-size: 14px;
  font-weight: 650;
}

.monitor-header p,
.empty-state,
.runtime-note {
  margin: 3px 0 0;
  color: #657482;
  font-size: 12px;
  line-height: 1.45;
  overflow-wrap: anywhere;
}

.event-count,
.activity-count {
  flex: 0 0 auto;
  color: #657482;
  font-size: 11px;
}

.agent-runs {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.agent-run {
  padding: 7px 9px;
  border-left: 3px solid #23836a;
  background: #f3f8f6;
  font-size: 12px;
}

.agent-name {
  flex: 0 0 auto;
  font-weight: 650;
}

.run-stage {
  flex: 1 1 auto;
  min-width: 0;
  color: #526271;
  overflow-wrap: anywhere;
}

.run-status {
  flex: 0 0 auto;
  color: #23836a;
  font-size: 11px;
  text-transform: capitalize;
}

.status-failed,
.status-cancelled {
  color: #bd3d3d;
}

.status-running {
  color: #2867a2;
}

.cli-runtime {
  padding-top: 11px;
  border-top: 1px solid #e7edf1;
}

.runtime-metrics {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 8px;
}

.runtime-metrics div {
  display: flex;
  flex-direction: column;
  gap: 3px;
  min-width: 0;
}

.runtime-metrics span,
.section-label {
  color: #71808d;
  font-size: 10px;
  font-weight: 650;
  text-transform: uppercase;
}

.runtime-metrics strong {
  color: #263746;
  font-size: 12px;
  overflow-wrap: anywhere;
}

.active-tools,
.activity-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 10px;
}

.active-tool {
  justify-content: space-between;
  color: #42515e;
  font-size: 11px;
}

.active-tool code {
  min-width: 0;
  overflow-wrap: anywhere;
}

.active-tool span {
  flex: 0 0 auto;
}

.runtime-note {
  margin-top: 8px;
}

.activity-list {
  padding-top: 11px;
  border-top: 1px solid #e7edf1;
}

.activity-row {
  align-items: flex-start;
  padding: 4px 0;
  border-bottom: 1px solid #f0f3f5;
}

.activity-row:last-child {
  border-bottom: 0;
}

.activity-row time {
  flex: 0 0 68px;
  color: #7b8994;
  font-size: 10px;
  font-variant-numeric: tabular-nums;
}

.activity-copy {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
  font-size: 11px;
}

.activity-copy strong,
.activity-copy span {
  overflow-wrap: anywhere;
}

.activity-copy span {
  color: #657482;
}

@media (max-width: 560px) {
  .runtime-metrics {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .agent-run {
    align-items: flex-start;
    flex-wrap: wrap;
  }

  .run-stage {
    flex-basis: 100%;
    order: 1;
  }
}
</style>
