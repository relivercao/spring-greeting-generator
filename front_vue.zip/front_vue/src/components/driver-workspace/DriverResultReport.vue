<!--
  @file DriverResultReport.vue
  @author zhangjian
  @brief Result report display for Driver workspace generation output.
  @version 1.0
  @date 2026-07-29
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component renders generated driver results, report artifacts, token usage,
  validation status, and downloadable output files supplied by the parent Driver
  workspace. It owns presentation, preview, copy, and download interactions only;
  it does not poll backend task state or mutate the generation workflow.
-->

<template>
  <div class="result-area">
    <!-- Hero banner with stats -->
    <div class="hero-banner">
      <div class="hero-glow" />

      <!-- KPI tiles -->
      <div class="kpi-grid">
        <div
          class="kpi-tile"
          :class="overallSuccess ? 'kpi-green' : 'kpi-red'"
        >
          <span class="kpi-icon">{{ overallSuccess ? '✓' : '✕' }}</span>
          <span class="kpi-val">{{ overallSuccess ? 'Pass' : 'Fail' }}</span>
          <span class="kpi-name">Compile</span>
        </div>
        <div
          v-if="moduleConfig.generateTests"
          class="kpi-tile kpi-blue"
        >
          <span class="kpi-icon">✓</span>
          <span class="kpi-val">{{ formattedUnitTestCoverage }}</span>
          <span class="kpi-name kpi-name-multiline">Unit Test<br>Coverage</span>
        </div>
        <div
          v-if="moduleConfig.generateCodeReview"
          class="kpi-tile"
          :class="codeReviewStatus.success ? 'kpi-green' : 'kpi-red'"
        >
          <span class="kpi-icon">{{ codeReviewStatus.success ? '✓' : '✕' }}</span>
          <span class="kpi-val">{{ codeReviewStatus.success ? 'Pass' : 'Fail' }}</span>
          <span class="kpi-name kpi-name-multiline">Code<br>Review</span>
        </div>
        <div class="kpi-tile kpi-amber">
          <span class="kpi-icon">🔄</span>
          <span class="kpi-val">2</span>
          <span class="kpi-name">Iterations</span>
        </div>
        <div class="kpi-tile kpi-purple">
          <span class="kpi-icon">🪙</span>
          <span class="kpi-val">{{ formatUsageTokenCount(totalTokens) }}</span>
          <span class="kpi-name">Total Tokens</span>
          <span class="token-usage-status">{{ tokenUsageStatusLabel }}</span>
          <div class="kpi-breakdown">
            Input: {{ formatUsageTokenCountInK(normalizedTokenUsage.input_tokens) }}<br>
            Output: {{ formatUsageTokenCountInK(normalizedTokenUsage.output_tokens) }}<br>
            Cache Write: {{ formatUsageTokenCountInK(normalizedTokenUsage.cache_creation_input_tokens) }}<br>
            Cache Read: {{ formatUsageTokenCountInK(normalizedTokenUsage.cache_read_input_tokens) }}<br>
            Total: {{ formatUsageTokenCountInK(totalTokens) }}
          </div>
        </div>
        <div class="kpi-tile kpi-green">
          <span class="kpi-icon">💰</span>
          <span class="kpi-val">{{ formatUsageCost(totalCost) }}</span>
          <span class="kpi-name">Total Cost</span>
          <div class="kpi-breakdown">
            Input: {{ formatUsageCost(normalizedTokenUsage.input_tokens * TOKEN_PRICE_USD_PER_MILLION.input / 1000000) }}<br>
            Output: {{ formatUsageCost(normalizedTokenUsage.output_tokens * TOKEN_PRICE_USD_PER_MILLION.output / 1000000) }}<br>
            Cache Write: {{ formatUsageCost(normalizedTokenUsage.cache_creation_input_tokens * TOKEN_PRICE_USD_PER_MILLION.cacheWrite / 1000000) }}<br>
            Cache Read: {{ formatUsageCost(normalizedTokenUsage.cache_read_input_tokens * TOKEN_PRICE_USD_PER_MILLION.cacheRead / 1000000) }}
          </div>
        </div>
      </div>
    </div>

    <!-- Generated files -->
    <div class="dark-card files-card">
      <div class="dark-card-title">
        Generated Files
        <span class="card-count">{{ reportArtifacts.length }} files</span>
      </div>

      <div
        v-for="file in reportArtifacts"
        :key="file.name"
        class="file-row"
      >
        <div class="file-row-head">
          <span
            class="file-ext-badge"
            :class="getExtClass(file.name)"
          >{{ getExtLabel(file.name) }}</span>
          <span class="file-row-name">{{ file.name }}</span>
          <button
            type="button"
            class="icon-btn preview-btn"
            :aria-expanded="expanded.has(file.name)"
            @click="togglePreview(file.name)"
          >
            {{ expanded.has(file.name) ? '▲ Collapse' : '▼ Preview' }}
          </button>
          <button
            type="button"
            class="icon-btn dl-btn2"
            @click="downloadFile(file.name, file.content)"
          >
            ↓ download
          </button>
        </div>
        <div
          v-if="expanded.has(file.name)"
          class="code-preview"
        >
          <div class="code-header">
            <span>{{ file.name }}</span>
            <button
              type="button"
              class="copy-sm-btn"
              @click="copyText(file.content, file.name)"
            >
              {{ copiedMap[file.name] ? '✓ Copied' : '⎘ Copy' }}
            </button>
          </div>
          <pre class="code-block">{{ file.content }}</pre>
        </div>
      </div>
    </div>

    <!-- Workflow output (collapsible) -->
    <div class="dark-card log-card">
      <div
        class="dark-card-title clickable"
        role="button"
        tabindex="0"
        :aria-expanded="showWorkflowOutput"
        @click="toggleWorkflowOutput"
        @keydown.enter.prevent="toggleWorkflowOutput"
        @keydown.space.prevent="toggleWorkflowOutput"
      >
        Workflow Output
        <span class="card-toggle">{{ showWorkflowOutput ? '▲' : '▼' }}</span>
      </div>

      <div v-show="showWorkflowOutput">
        <!-- Summary inner -->
        <div class="summary-inner">
          <!-- What was done -->
          <div class="summary-section">
            <div class="summary-section-title">
              What was done
            </div>
            <ul class="summary-list">
              <li>✓ Analyzed {{ knowledgeBaseCount }} knowledge base files</li>
              <li>✓ Generated {{ reportArtifacts.length }} report files</li>
              <li>✓ Created driver implementation ({{ totalLines }} lines)</li>
              <li>✓ Generated configuration headers</li>
            </ul>
          </div>

          <!-- Result -->
          <div class="summary-section">
            <div class="summary-section-title">
              Result
            </div>
            <div class="summary-kv">
              <span class="summary-kv-key">Driver Generation:</span>
              <span :class="driverStatus.success ? 'val-green' : 'val-red'">
                {{ driverStatus.success ? 'Success' : 'Failed' }}
              </span>
            </div>
            <div
              v-if="moduleConfig.generateTests"
              class="summary-kv"
            >
              <span class="summary-kv-key">Unit Test Generation:</span>
              <span :class="unittestStatus.success ? 'val-green' : 'val-red'">
                {{ unittestStatus.success ? 'Success' : 'Failed' }}
              </span>
            </div>
            <div
              v-if="moduleConfig.generateCodeReview"
              class="summary-kv"
            >
              <span class="summary-kv-key">Code Review:</span>
              <span :class="codeReviewStatus.success ? 'val-green' : 'val-red'">
                {{ codeReviewStatus.success ? 'Success' : 'Failed' }}
              </span>
            </div>
            <div class="summary-kv">
              <span class="summary-kv-key">Module type:</span>
              <span class="val-green">{{ displayModuleType }}</span>
            </div>
            <div class="summary-kv">
              <span class="summary-kv-key">Files generated:</span>
              <span class="val-green">{{ reportArtifacts.length }}</span>
            </div>
          </div>

          <!-- Driver Summary -->
          <div
            class="summary-section"
            :class="{ 'summary-section-last': !moduleConfig.generateTests && !moduleConfig.generateCodeReview }"
          >
            <div class="summary-section-title">
              Driver Generation Summary
            </div>

            <!-- Error message if driver generation failed -->
            <div
              v-if="!driverStatus.success"
              class="summary-subsection"
            >
              <div class="error-banner">
                <span class="error-icon">✖</span>
                <div class="error-content">
                  <div class="error-title">
                    Driver Generation Failed
                  </div>
                  <div class="error-message">
                    {{ driverStatus.error || 'An unknown error occurred during driver generation.' }}
                  </div>
                </div>
              </div>
            </div>

            <!-- Success content -->
            <template v-if="driverStatus.success">
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Conclusion
                </div>
                <p class="summary-paragraph">
                  Successfully generated {{ displayModuleType }} driver for {{ displayModuleName }}.
                  All {{ reportArtifacts.length }} files were created with proper structure and documentation,
                  totaling {{ totalLines }} lines of code.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Generated artifacts status
                </div>
                <p class="summary-paragraph">
                  The package includes implementation files, header files, and configuration templates.
                  All files follow firmware coding standards and are ready for integration into your project.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Quality / risk signal
                </div>
                <p class="summary-paragraph">
                  The generated driver code requires manual review and hardware validation. Ensure proper
                  initialization sequence, error handling, and hardware-specific timing requirements are met.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Recommendation
                </div>
                <p class="summary-paragraph">
                  Review the generated code and integrate it into your project. Validate hardware-specific timing,
                  initialization sequence, and error handling with your target hardware.
                </p>
              </div>
            </template>
          </div>

          <!-- Unit Test Summary (optional) -->
          <div
            v-if="moduleConfig.generateTests"
            class="summary-section"
            :class="{ 'summary-section-last': !moduleConfig.generateCodeReview }"
          >
            <div class="summary-section-title">
              Unit Test Summary
            </div>

            <!-- Error message if unit test generation failed -->
            <div
              v-if="!unittestStatus.success"
              class="summary-subsection"
            >
              <div class="error-banner">
                <span class="error-icon">✖</span>
                <div class="error-content">
                  <div class="error-title">
                    Unit Test Generation Failed
                  </div>
                  <div class="error-message">
                    {{ unittestStatus.error || 'An unknown error occurred during unit test generation.' }}
                  </div>
                </div>
              </div>
            </div>

            <!-- Success content -->
            <template v-if="unittestStatus.success">
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Conclusion
                </div>
                <p class="summary-paragraph">
                  Generated comprehensive unit tests for {{ displayModuleName }} driver. Test suite covers
                  initialization, core functionality, edge cases, and error handling scenarios.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Generated artifacts status
                </div>
                <p class="summary-paragraph">
                  Test files include setup/teardown functions, mock HAL interfaces, and assertion utilities.
                  Tests are ready to be integrated into your test framework (Unity, CMock, etc.).
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Quality / risk signal
                </div>
                <p class="summary-paragraph">
                  All critical paths are covered with positive and negative test cases. Run the test suite
                  before deploying to production to validate driver behavior.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Recommendation
                </div>
                <p class="summary-paragraph">
                  Execute the test suite in your target environment and verify all tests pass. Review any test
                  failures and adjust mock configurations or test assertions as needed.
                </p>
              </div>
            </template>
          </div>

          <!-- Code Review Summary (optional) -->
          <div
            v-if="moduleConfig.generateCodeReview"
            class="summary-section summary-section-last"
          >
            <div class="summary-section-title">
              Code Review Summary
            </div>

            <!-- Error message if code review failed -->
            <div
              v-if="!codeReviewStatus.success"
              class="summary-subsection"
            >
              <div class="error-banner">
                <span class="error-icon">✖</span>
                <div class="error-content">
                  <div class="error-title">
                    Code Review Failed
                  </div>
                  <div class="error-message">
                    {{ codeReviewStatus.error || 'An unknown error occurred during code review.' }}
                  </div>
                </div>
              </div>
            </div>

            <!-- Success content -->
            <template v-if="codeReviewStatus.success">
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Conclusion
                </div>
                <p class="summary-paragraph">
                  Automated code review completed for {{ displayModuleName }} driver. Analysis covered
                  code style, potential bugs, performance issues, and security vulnerabilities.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Generated artifacts status
                </div>
                <p class="summary-paragraph">
                  Code follows industry best practices with proper error handling, memory management, and
                  resource cleanup. All functions have clear documentation and appropriate comments.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Quality / risk signal
                </div>
                <p class="summary-paragraph">
                  The generated code meets coding standards but requires hardware-specific validation.
                  Pay special attention to timing-critical sections and interrupt handling.
                </p>
              </div>
              <div class="summary-subsection">
                <div class="summary-subsection-title">
                  Recommendation
                </div>
                <p class="summary-paragraph">
                  Consider additional hardware-specific optimizations based on your target platform.
                  Review interrupt priorities and timing-critical sections for your specific use case.
                </p>
              </div>
            </template>
          </div>

          <!-- Divider before raw log -->
          <div class="summary-divider" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'

const TOKEN_PRICE_USD_PER_MILLION = Object.freeze({
  input: 3.0,
  output: 15.0,
  cacheRead: 0.30,
  cacheWrite: 3.75,
})
const DEFAULT_MODULE_NAME = 'Driver'
const DEFAULT_MODULE_TYPE = 'Driver'
const DEFAULT_PLATFORM = 'STM32'
const COPY_FEEDBACK_MS = 2000
const TEXT_FILE_MIME_TYPE = 'text/plain;charset=utf-8'
const SOURCE_ARTIFACT_EXTENSIONS = new Set(['c', 'h', 'cpp', 'cxx', 'hpp'])
const HIDDEN_DRIVER_ARTIFACT_NAMES = new Set(['driver-build.log'])
const HIDDEN_DRIVER_ARTIFACT_TYPES = new Set(['build_log'])

const props = defineProps({
  generatedCodeTabs: {
    type: Array,
    required: true,
  },
  moduleConfig: {
    type: Object,
    required: true,
  },
  knowledgeBaseCount: {
    type: Number,
    default: 0,
  },
  duration: {
    type: Number,
    default: 8,
  },
  tokenUsage: {
    type: Object,
    default: () => ({
      input_tokens: 0,
      output_tokens: 0,
      cache_creation_input_tokens: 0,
      cache_read_input_tokens: 0,
    }),
  },
  tokenUsageStatus: {
    type: String,
    default: 'pending',
  },
  outputDir: {
    type: String,
    default: '',
  },
  driverStatus: {
    type: Object,
    default: () => ({
      success: true,
      error: null,
    }),
  },
  unittestStatus: {
    type: Object,
    default: () => ({
      success: true,
      error: null,
    }),
  },
  codeReviewStatus: {
    type: Object,
    default: () => ({
      success: true,
      error: null,
    }),
  },
})

const expanded = ref(new Set())
const copiedMap = ref({})
const showWorkflowOutput = ref(false)

const displayModuleName = computed(() => {
  return props.moduleConfig.moduleName || props.moduleConfig.moduleType || DEFAULT_MODULE_NAME
})

const displayModuleType = computed(() => {
  return props.moduleConfig.moduleType || DEFAULT_MODULE_TYPE
})

const displayPlatform = computed(() => {
  return props.moduleConfig.platform || DEFAULT_PLATFORM
})

const overallSuccess = computed(() => {
  const compilationSummary = generatedArtifacts.value.find(file => (
    file.name.toLowerCase().includes('compilation-summary')
  ))

  if (compilationSummary?.content) {
    try {
      const summary = JSON.parse(compilationSummary.content)
      if (typeof summary.success === 'boolean') return summary.success
      if (typeof summary.status === 'string') {
        return ['pass', 'passed', 'success', 'completed'].includes(summary.status.toLowerCase())
      }
    } catch {
      return Boolean(props.driverStatus?.success)
    }
  }

  return Boolean(props.driverStatus?.success)
})

const generatedArtifacts = computed(() => {
  const tabs = Array.isArray(props.generatedCodeTabs) ? props.generatedCodeTabs : []

  return tabs
    .filter(Boolean)
    .filter(file => !isHiddenDriverArtifact(file))
    .map((file, index) => ({
      ...file,
      name: String(file.name || `artifact-${index + 1}.txt`),
      content: String(file.content ?? ''),
    }))
})

const reportArtifacts = computed(() => {
  const reports = []

  // Keep a downloadable frontend summary when the backend did not return a report artifact.
  if (!generatedArtifacts.value.some(isDriverReportFile)) {
    reports.push(buildDriverFallbackSummary())
  }

  if (props.moduleConfig.generateTests && !generatedArtifacts.value.some(isUnitTestReportFile)) {
    reports.push(buildUnitTestFallbackSummary())
  }

  if (props.moduleConfig.generateCodeReview && !generatedArtifacts.value.some(isCodeReviewReportFile)) {
    reports.push(buildCodeReviewFallbackSummary())
  }

  return [...generatedArtifacts.value, ...reports]
})

const codeArtifacts = computed(() => {
  return generatedArtifacts.value.filter(file => {
    const ext = getFileExtension(file.name)
    return SOURCE_ARTIFACT_EXTENSIONS.has(ext)
  })
})

const totalLines = computed(() => {
  return codeArtifacts.value.reduce((sum, file) => {
    return sum + (file.content || '').split('\n').length
  }, 0)
})

const normalizedTokenUsage = computed(() => {
  const usage = props.tokenUsage || {}
  const inputTokens = toTokenCount(usage.input_tokens)
  const outputTokens = toTokenCount(usage.output_tokens)
  const cacheCreationInputTokens = toTokenCount(usage.cache_creation_input_tokens)
  const cacheReadInputTokens = toTokenCount(usage.cache_read_input_tokens)
  const componentTotal = inputTokens + outputTokens + cacheCreationInputTokens + cacheReadInputTokens
  const reportedTotal = toTokenCount(usage.total_tokens)

  return {
    input_tokens: inputTokens,
    output_tokens: outputTokens,
    cache_creation_input_tokens: cacheCreationInputTokens,
    cache_read_input_tokens: cacheReadInputTokens,
    total_tokens: reportedTotal > 0 ? reportedTotal : componentTotal,
  }
})

const totalTokens = computed(() => {
  return normalizedTokenUsage.value.total_tokens
})

const hasReportedTokenUsage = computed(() => {
  return props.tokenUsageStatus === 'available' || totalTokens.value > 0
})

const tokenUsageStatusLabel = computed(() => {
  if (hasReportedTokenUsage.value) return 'Reported by provider'
  if (props.tokenUsageStatus === 'unavailable') return 'Not reported by provider'
  return 'Waiting for provider usage'
})

const totalCost = computed(() => {
  const usage = normalizedTokenUsage.value
  const inputCost = usage.input_tokens * TOKEN_PRICE_USD_PER_MILLION.input / 1000000
  const outputCost = usage.output_tokens * TOKEN_PRICE_USD_PER_MILLION.output / 1000000
  const cacheReadCost = usage.cache_read_input_tokens * TOKEN_PRICE_USD_PER_MILLION.cacheRead / 1000000
  const cacheWriteCost = usage.cache_creation_input_tokens * TOKEN_PRICE_USD_PER_MILLION.cacheWrite / 1000000

  return inputCost + outputCost + cacheReadCost + cacheWriteCost
})

const unitTestCoverage = computed(() => {
  return props.unittestStatus.coverage ?? props.unittestStatus.final_coverage ?? props.moduleConfig.testCoverage ?? null
})

const formattedUnitTestCoverage = computed(() => {
  if (unitTestCoverage.value === null || unitTestCoverage.value === undefined) return 'N/A'
  const coverage = Number(unitTestCoverage.value)
  return Number.isFinite(coverage) ? coverage.toFixed(1) + '%' : 'N/A'
})

function formatTokenCount(count) {
  const normalizedCount = toTokenCount(count)

  if (normalizedCount >= 1000000) {
    return (normalizedCount / 1000000).toFixed(1) + 'M'
  } else if (normalizedCount >= 1000) {
    return (normalizedCount / 1000).toFixed(1) + 'K'
  }
  return normalizedCount.toString()
}

function formatTokenCountInK(count) {
  const normalizedCount = toTokenCount(count)

  if (normalizedCount >= 1000) {
    return (normalizedCount / 1000).toFixed(1) + 'K'
  }
  return normalizedCount.toString()
}

function formatUsageTokenCount(count) {
  return hasReportedTokenUsage.value ? formatTokenCount(count) : 'N/A'
}

function formatUsageTokenCountInK(count) {
  return hasReportedTokenUsage.value ? formatTokenCountInK(count) : 'N/A'
}

function formatUsageCost(cost) {
  return hasReportedTokenUsage.value ? formatCost(cost) : 'N/A'
}

function formatCost(cost) {
  const normalizedCost = Number(cost)
  if (!Number.isFinite(normalizedCost) || normalizedCost <= 0) {
    return '$0.00'
  }

  if (normalizedCost >= 1) {
    return '$' + normalizedCost.toFixed(2)
  } else if (normalizedCost >= 0.01) {
    return '$' + normalizedCost.toFixed(3)
  }
  return '$' + normalizedCost.toFixed(4)
}

function toTokenCount(value) {
  const count = Number(value || 0)
  return Number.isFinite(count) && count > 0 ? Math.trunc(count) : 0
}

function getExtClass(filename) {
  const ext = getFileExtension(filename)
  if (ext === 'c') return 'ext-c'
  if (ext === 'h') return 'ext-h'
  if (ext === 'cpp' || ext === 'cxx') return 'ext-cpp'
  if (ext === 'md') return 'ext-md'
  return 'ext-other'
}

function getExtLabel(filename) {
  return getFileExtension(filename).toUpperCase() || 'FILE'
}

function getFileExtension(filename) {
  const normalizedFilename = String(filename || '').trim()
  const extensionIndex = normalizedFilename.lastIndexOf('.')
  if (extensionIndex < 0 || extensionIndex === normalizedFilename.length - 1) {
    return ''
  }
  return normalizedFilename.slice(extensionIndex + 1).toLowerCase()
}

function isHiddenDriverArtifact(file) {
  const name = String(file?.name || '').toLowerCase()
  const artifactType = String(file?.type || file?.artifact_type || '').toLowerCase()
  return HIDDEN_DRIVER_ARTIFACT_NAMES.has(name) || HIDDEN_DRIVER_ARTIFACT_TYPES.has(artifactType)
}

function isUnitTestReportFile(file) {
  const name = String(file?.name || '').toLowerCase()
  return name.endsWith('.md') && (
    name.includes('unittest-report') ||
    name.includes('unit-test-report')
  )
}

function isCodeReviewReportFile(file) {
  const name = String(file?.name || '').toLowerCase()
  return name.endsWith('.md') && (
    name.includes('code-review-report') ||
    name.includes('codereview-report') ||
    name.includes('review-report')
  )
}

function isDriverReportFile(file) {
  const name = String(file?.name || '').toLowerCase()
  return name.endsWith('.md') && (
    name.includes('driver-report') ||
    name.includes('driver-generation-report')
  )
}

function buildDriverFallbackSummary() {
  const moduleName = displayModuleName.value
  const reportName = `${slugify(moduleName)}-driver-frontend-summary.md`
  const status = props.driverStatus.success ? 'Success' : 'Failed'
  const summary = props.driverStatus.success
    ? [
        `Driver generation completed for ${moduleName}.`,
        `The backend did not return a dedicated Driver Agent report artifact, so this frontend summary lists the visible task status and generated files.`,
      ]
    : [
        `Driver generation failed for ${moduleName}.`,
        props.driverStatus.error || 'No additional error detail was returned.',
      ]
  const content = [
    `# ${moduleName} Driver Frontend Summary`,
    '',
    '## Metadata',
    `- Status: ${status}`,
    '- Report Source: Frontend summary',
    `- Module Type: ${displayModuleType.value}`,
    `- Platform: ${displayPlatform.value}`,
    `- Files Generated: ${codeArtifacts.value.length}`,
    '',
    '## Summary',
    ...summary,
    '',
    '## Visible Artifacts',
    ...buildArtifactLines(codeArtifacts.value),
    '',
    '## Recommendation',
    props.driverStatus.success
      ? 'Review the generated code and validate hardware-specific timing, initialization sequence, and error handling with your target hardware.'
      : 'Check the task error message, update the input configuration if needed, and rerun Driver generation.',
    '',
  ].join('\n')

  return {
    name: reportName,
    content,
    type: 'frontend_driver_summary',
    language: 'markdown',
  }
}

function buildCodeReviewFallbackSummary() {
  const moduleName = displayModuleName.value
  const reportName = `${slugify(moduleName)}-code-review-frontend-summary.md`
  const status = props.codeReviewStatus.success ? 'Pass' : 'Fail'
  const summary = props.codeReviewStatus.success
    ? 'Code review completed according to the task status, but no dedicated code review report artifact was returned by the backend.'
    : (props.codeReviewStatus.error || 'Code review did not complete successfully, and no dedicated report artifact was returned.')
  const content = [
    `# ${moduleName} Code Review Frontend Summary`,
    '',
    '## Summary',
    `- Code Review Status: ${status}`,
    '- Report Source: Frontend summary',
    '',
    '## Current State',
    summary,
    '',
    '## Recommendation',
    props.codeReviewStatus.success
      ? 'Review the generated source files and attach the backend code review report when it is available.'
      : 'Check the code review error message and rerun the review after resolving the reported issue.',
    '',
  ].join('\n')

  return {
    name: reportName,
    content,
    type: 'frontend_code_review_summary',
    language: 'markdown',
  }
}

function buildUnitTestFallbackSummary() {
  const moduleName = displayModuleName.value
  const reportName = `${slugify(moduleName)}-unittest-frontend-summary.md`
  const status = props.unittestStatus.success ? 'Pass' : 'Fail'
  const summary = props.unittestStatus.success
    ? 'Unit test generation completed according to the task status, but no dedicated Unit Test Agent report artifact was returned by the backend.'
    : (props.unittestStatus.error || 'Unit test generation did not complete successfully, and no dedicated report artifact was returned.')
  const content = [
    `# ${moduleName} Unit Test Frontend Summary`,
    '',
    '## Summary',
    `- Unit Test Status: ${status}`,
    `- Coverage: ${formattedUnitTestCoverage.value}`,
    '- Report Source: Frontend summary',
    '',
    '## Current State',
    summary,
    '',
  ].join('\n')

  return {
    name: reportName,
    content,
    type: 'frontend_unittest_summary',
    language: 'markdown',
  }
}

function buildArtifactLines(files) {
  if (!files.length) {
    return ['- No source artifacts are currently visible in the result payload.']
  }
  return files.map(file => `- ${String(file.name || 'Unnamed artifact')}`)
}

function slugify(value) {
  return String(value || 'driver')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'driver'
}

function togglePreview(filename) {
  if (expanded.value.has(filename)) {
    expanded.value.delete(filename)
  } else {
    expanded.value.add(filename)
  }
}

function toggleWorkflowOutput() {
  showWorkflowOutput.value = !showWorkflowOutput.value
}

async function copyText(text, key) {
  const copyKey = String(key || 'artifact')
  const content = String(text ?? '')

  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(content)
    } else {
      copyTextWithTextArea(content)
    }

    copiedMap.value[copyKey] = true
    ElMessage.success('Copied to clipboard')
    setTimeout(() => {
      copiedMap.value[copyKey] = false
    }, COPY_FEEDBACK_MS)
  } catch {
    ElMessage.error('Failed to copy')
  }
}

function copyTextWithTextArea(text) {
  const textarea = document.createElement('textarea')
  textarea.value = text
  textarea.setAttribute('readonly', '')
  textarea.style.position = 'fixed'
  textarea.style.opacity = '0'
  textarea.style.pointerEvents = 'none'
  document.body.appendChild(textarea)
  textarea.select()

  try {
    const copied = document.execCommand('copy')
    if (!copied) {
      throw new Error('Copy command was rejected.')
    }
  } finally {
    document.body.removeChild(textarea)
  }
}

function downloadFile(filename, content) {
  const safeFilename = String(filename || 'driver-artifact.txt')
  const blob = new Blob([String(content ?? '')], { type: TEXT_FILE_MIME_TYPE })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = safeFilename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  setTimeout(() => URL.revokeObjectURL(url), 0)
  ElMessage.success(`${safeFilename} downloaded`)
}
</script>

<style scoped>
/* Result */
.result-area {
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
  height: 100%;
  overflow-y: auto;
  padding: 24px;
  scrollbar-width: thin;
  scrollbar-color: #64748b #e2e8f0;
}
.result-area::-webkit-scrollbar {
  width: 8px;
}
.result-area::-webkit-scrollbar-track {
  background: #e2e8f0;
}
.result-area::-webkit-scrollbar-thumb {
  background: #64748b;
  border-radius: 4px;
}
.result-area::-webkit-scrollbar-thumb:hover {
  background: #475569;
}
/* Hero banner — horizontal layout: left status + right KPI grid */
.hero-banner {
  position: relative;
  display: flex;
  gap: 12px;
  align-items: flex-start;
  padding: 28px 32px 40px 32px;
  background: linear-gradient(135deg, #eef2ff 0%, #f0f9ff 100%);
  border: 1px solid #c7d2fe;
  border-radius: 12px;
  overflow: visible;
  flex-shrink: 0;
  width: 100%;
}

/* Dark / light cards */
.dark-card {
  width: 100%;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  overflow: hidden;
  flex-shrink: 0;
}
.hero-glow {
  position: absolute; top: -40px; right: -40px;
  width: 180px; height: 180px; border-radius: 50%;
  background: radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%);
  pointer-events: none;
}

/* Mini donuts are removed — not in unittest layout */
.mini-donuts { display: none; }
.mini-donut-item { display: none; }
.mini-svg   { display: none; }
.mini-label { display: none; }
.mini-pct   { display: none; }
.mini-sub   { display: none; }

/* KPI row */
.kpi-grid {
  display: flex;
  gap: 12px;
  height: 180px;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: wrap;
}
.kpi-tile {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 8px; padding: 20px 4px; border-radius: 10px;
  border: 1px solid transparent; transition: transform 0.15s;
  position: relative;
  height: 170px;
  width: 90px;
}
.kpi-tile:hover { transform: translateY(-2px); }
.kpi-icon { font-size: 16px; line-height: 1; }
.kpi-val  { font-size: 16px; font-weight: 800; line-height: 1.2; }
.kpi-name {
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.3px;
  line-height: 1.25;
  text-align: center;
}
.kpi-name-multiline {
  display: inline-block;
  min-height: 28px;
}

.kpi-green  { background: #f0fdf4; border-color: #bbf7d0; }
.kpi-green  .kpi-icon, .kpi-green .kpi-val  { color: #16a34a; }
.kpi-green  .kpi-name { color: #4ade80; }
.kpi-indigo { background: #eef2ff; border-color: #c7d2fe; }
.kpi-indigo .kpi-icon, .kpi-indigo .kpi-val { color: #4338ca; }
.kpi-indigo .kpi-name { color: #818cf8; }
.kpi-blue   { background: #f0f9ff; border-color: #bae6fd; }
.kpi-blue   .kpi-icon, .kpi-blue .kpi-val   { color: #0369a1; }
.kpi-blue   .kpi-name { color: #38bdf8; }
.kpi-amber  { background: #fffbeb; border-color: #fde68a; }
.kpi-amber  .kpi-icon, .kpi-amber .kpi-val  { color: #b45309; }
.kpi-amber  .kpi-name { color: #fbbf24; }
.kpi-purple { background: #faf5ff; border-color: #e9d5ff; }
.kpi-purple .kpi-icon, .kpi-purple .kpi-val { color: #7c3aed; }
.kpi-purple .kpi-name { color: #a78bfa; }
.kpi-purple .token-usage-status {
  max-width: 84px;
  color: #8b5cf6;
  font-size: 8px;
  line-height: 1.2;
  text-align: center;
  overflow-wrap: anywhere;
}
.kpi-red { background: #fef2f2; border-color: #fecaca; }
.kpi-red .kpi-icon, .kpi-red .kpi-val { color: #dc2626; }
.kpi-red .kpi-name { color: #f87171; }
.kpi-detail {
  display: none;
  position: absolute;
  top: calc(100% + 8px);
  left: 50%;
  transform: translateX(-50%);
  padding: 10px 14px;
  background: #1e293b;
  border: 1px solid #475569;
  border-radius: 6px;
  font-size: 11px;
  color: #e2e8f0;
  white-space: nowrap;
  z-index: 1000;
  line-height: 1.5;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}
.kpi-tile:hover .kpi-detail {
  display: block;
}
.kpi-breakdown {
  font-size: 9px;
  color: inherit;
  opacity: 0.75;
  line-height: 1.4;
  margin-top: 4px;
  text-align: center;
}

/* Dark / light cards */
.dark-card {
  width: 100%;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  overflow: hidden;
}
.dark-card-title {
  display: flex; align-items: center; gap: 8px;
  padding: 11px 16px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  font-size: 12px; font-weight: 600; color: #334155;
  text-transform: uppercase; letter-spacing: 0.5px;
}
.dark-card-title.clickable { cursor: pointer; user-select: none; }
.dark-card-title.clickable:hover { background: #f1f5f9; }
.card-count { margin-left: auto; background: #e0e7ff; color: #4338ca; border-radius: 10px; padding: 1px 8px; font-size: 11px; font-weight: 600; text-transform: none; letter-spacing: 0; }
.card-toggle { margin-left: auto; color: #94a3b8; font-size: 11px; }

/* Dot indicators - removed */

/* File rows */
.file-row { border-bottom: 1px solid #f1f5f9; }
.file-row:last-child { border-bottom: none; }
.file-row-head {
  display: flex; align-items: center; gap: 8px;
  padding: 9px 16px; font-size: 13px;
}
.file-ext-badge {
  flex-shrink: 0; padding: 1px 7px; border-radius: 5px;
  font-size: 10px; font-weight: 700; letter-spacing: 0.5px;
}
.ext-cpp   { background: #e0e7ff; color: #3730a3; }
.ext-h     { background: #fef9c3; color: #854d0e; }
.ext-c     { background: #dcfce7; color: #166534; }
.ext-md {
  min-width: 30px;
  text-align: center;
  background: #e0f2fe;
  color: #0369a1;
}
.ext-other { background: #f1f5f9; color: #475569; }
.file-row-name { flex: 1; color: #374151; font-size: 12.5px; font-family: 'Consolas', monospace; }

.icon-btn {
  flex-shrink: 0; padding: 3px 10px; border-radius: 6px;
  font-size: 11px; cursor: pointer; border: 1px solid; transition: all 0.15s;
  background: transparent;
}
.preview-btn { color: #6366f1; border-color: #c7d2fe; }
.preview-btn:hover { background: #eef2ff; }
.dl-btn2 { color: #0369a1; border-color: #bae6fd; }
.dl-btn2:hover { background: #f0f9ff; }

/* Code preview */
.code-preview { background: #0f172a; overflow: hidden; }
.code-header  { display: flex; align-items: center; justify-content: space-between; padding: 6px 14px; background: #1e293b; font-size: 11px; color: #94a3b8; }
.copy-sm-btn  { padding: 2px 8px; border: 1px solid #334155; border-radius: 4px; background: transparent; color: #94a3b8; font-size: 11px; cursor: pointer; transition: all 0.15s; }
.copy-sm-btn:hover { background: #334155; color: #e2e8f0; }
.code-block   {
  padding: 14px 16px; font-size: 11.5px;
  font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  line-height: 1.6; color: #e2e8f0;
  white-space: pre !important; word-break: normal; overflow-wrap: normal;
  margin: 0; max-height: 400px; overflow: auto;
  scrollbar-width: thin; scrollbar-color: #334155 transparent;
  display: block; tab-size: 4;
}

/* Build output */
.build-output {
  font-size: 11.5px; font-family: 'Consolas', monospace;
  white-space: pre !important; word-break: normal;
  padding: 14px 16px; margin: 0;
  max-height: 280px; overflow-y: auto; line-height: 1.6;
  display: block; tab-size: 4;
  scrollbar-width: thin;
  scrollbar-color: #94a3b8 #f1f5f9;
}
.build-ok  { background: #f8fffe; color: #065f46; }

/* CLI Summary — embedded inside Workflow Output card */
.summary-inner {
  padding-bottom: 4px;
}
.summary-section { padding: 8px 16px 4px; }
.summary-section-last { padding-bottom: 12px; }
.summary-section-title {
  font-size: 11px; font-weight: 700; letter-spacing: 0.5px;
  color: #6366f1; text-transform: uppercase; margin-bottom: 6px;
}
.summary-list {
  list-style: none; padding: 0; margin: 0;
  display: flex; flex-direction: column; gap: 3px;
}
.summary-list li { font-size: 12.5px; color: #374151; line-height: 1.5; }
.summary-subsection {
  margin-bottom: 10px;
}
.summary-subsection:last-child {
  margin-bottom: 0;
}
.summary-subsection-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.35px;
  color: #4b5563;
  margin-bottom: 4px;
}
.summary-paragraph {
  margin: 0;
  max-width: 920px;
  padding: 10px 12px;
  border: 1px solid #eef2ff;
  border-radius: 8px;
  background: linear-gradient(180deg, #f8fafc 0%, #f9fafb 100%);
  font-size: 12.5px;
  color: #374151;
  line-height: 1.7;
  white-space: normal;
}
.summary-kv {
  display: flex; gap: 8px; align-items: baseline;
  font-size: 12.5px; line-height: 1.7;
}
.summary-kv-key { color: #6b7280; min-width: 110px; }
.val-green  { color: #16a34a; font-weight: 600; }
.val-red    { color: #dc2626; font-weight: 600; }
.summary-divider { margin: 0 16px; border-top: 1px solid #e5e7eb; }

/* Error banner */
.error-banner {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px 14px;
  background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
  border: 1px solid #fca5a5;
  border-radius: 8px;
  margin-bottom: 8px;
}
.error-icon {
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #dc2626;
  color: white;
  border-radius: 50%;
  font-size: 14px;
  font-weight: 700;
}
.error-content {
  flex: 1;
}
.error-title {
  font-size: 13px;
  font-weight: 700;
  color: #991b1b;
  margin-bottom: 4px;
}
.error-message {
  font-size: 12px;
  color: #dc2626;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
}
</style>
