<!--
  @file DriverUploadSection.vue
  @author zhangjian
  @brief Upload panel for Driver workspace source and reference files.
  @version 1.0
  @date 2026-07-23
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component owns local file-selection interactions only. Uploading,
  parsing, and backend source state remain controlled by the parent Driver
  workspace flow.
-->
<template>
  <div class="input-section">
    <div class="input-section-header">
      <div>
        <p :class="['eyebrow', eyebrowClass]">
          {{ eyebrow }}
        </p>
        <h3>{{ sectionDescription }}</h3>
      </div>
      <span class="input-section-badge optional">Optional</span>
    </div>
    <div class="input-section-body">
      <input
        ref="fileInputRef"
        class="hidden-input"
        type="file"
        multiple
        accept=".c,.h,.cpp,.hpp,.net,.txt,.md,.pdf,.doc,.docx"
        @change="handleFilesChange"
      >
      <div class="upload-action-row">
        <button
          :class="['upload-zone', uploadZoneClass, { dragging: isDragging }]"
          @click="triggerFilesInput"
          @dragover.prevent="isDragging = true"
          @dragleave="isDragging = false"
          @drop.prevent="handleDrop"
        >
          <span :class="['upload-zone-icon', iconClass]">
            <el-icon size="20">
              <Upload />
            </el-icon>
          </span>
          <span class="upload-zone-text">
            <strong>{{ actionTitle }}</strong>
            <small>{{ actionDescription }}</small>
          </span>
        </button>
      </div>

      <div
        v-if="files.length > 0"
        class="selected-file-list"
      >
        <div
          v-for="(file, index) in files"
          :key="index"
          :class="['selected-file-chip', chipClass]"
        >
          <div class="selected-file-meta">
            <span :class="['file-ext-badge', badgeClass]">{{ fileHelpers.getFileExtension(file.name) }}</span>
            <div class="selected-file-main">
              <span class="file-name">{{ file.name }}</span>
              <span class="file-size">{{ fileHelpers.formatFileSize(file.size) }}</span>
              <span :class="['file-status', fileHelpers.getFileStatusClass(file)]">
                {{ fileHelpers.getFileStatusLabel(file) }}
              </span>
            </div>
          </div>
          <div class="selected-file-actions">
            <button
              class="remove-file-btn"
              @click="$emit('remove', index)"
            >
              &times;
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { Upload } from '@element-plus/icons-vue'
import { computed, ref } from 'vue'

const props = defineProps({
  files: {
    type: Array,
    required: true,
  },
  tone: {
    type: String,
    default: 'blue',
  },
  eyebrow: {
    type: String,
    required: true,
  },
  actionTitle: {
    type: String,
    required: true,
  },
  actionDescription: {
    type: String,
    required: true,
  },
  fileHelpers: {
    type: Object,
    required: true,
  },
})

const emit = defineEmits(['files-added', 'remove'])

const fileInputRef = ref(null)
const isDragging = ref(false)

const isViolet = computed(() => props.tone === 'violet')
const eyebrowClass = computed(() => isViolet.value ? 'eyebrow-violet' : 'eyebrow-blue')
const sectionDescription = computed(() => isViolet.value
  ? 'Upload circuit diagrams, reference examples, or supporting technical files'
  : 'Upload specifications, datasheets, manuals, or requirement documents'
)
const uploadZoneClass = computed(() => isViolet.value ? 'upload-zone-violet' : '')
const iconClass = computed(() => isViolet.value ? 'violet' : '')
const chipClass = computed(() => isViolet.value ? 'violet' : '')
const badgeClass = computed(() => isViolet.value ? 'violet' : '')

function triggerFilesInput() {
  fileInputRef.value?.click()
}

function handleFilesChange(event) {
  const files = Array.from(event.target.files || [])
  event.target.value = ''
  if (files.length === 0) return
  emit('files-added', files)
}

function handleDrop(event) {
  isDragging.value = false
  const files = Array.from(event.dataTransfer.files || [])
  if (files.length === 0) return
  emit('files-added', files)
}
</script>

<style scoped>
.input-section {
  border-bottom: 1px solid rgba(148, 163, 184, 0.12);
}

.input-section-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  padding: clamp(8px, 1.1vh, 10px) clamp(10px, 0.9vw, 12px) 0;
}

.input-section-header h3 {
  margin: 0;
  color: #64748b;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.3;
}

.input-section-badge {
  flex-shrink: 0;
  padding: 3px 9px;
  border-radius: 20px;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.04em;
  white-space: nowrap;
}

.input-section-badge.optional {
  color: #2563eb;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
}

.eyebrow {
  margin: 0 0 3px;
  font-size: 11px;
  font-weight: 800;
  line-height: 1.2;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.eyebrow-blue {
  color: #2563eb;
}

.eyebrow-violet {
  color: #7c3aed;
}

.input-section-body {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: clamp(7px, 1vh, 8px) clamp(10px, 0.9vw, 12px) clamp(9px, 1.2vh, 12px);
}

.upload-action-row {
  display: block;
}

.upload-zone {
  position: relative;
  width: 100%;
  display: flex;
  align-items: center;
  gap: 12px;
  padding: clamp(8px, 1.1vh, 10px) clamp(10px, 0.9vw, 12px);
  border: 1.5px solid #e2e8f0;
  border-radius: 12px;
  color: #1e293b;
  background: linear-gradient(135deg, #f8fbff 0%, #f1f5f9 100%);
  cursor: pointer;
  font-family: inherit;
  text-align: left;
  transition: all 0.2s ease;
}

.upload-zone:hover {
  border-color: #93c5fd;
  background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.08);
  transform: translateY(-1px);
}

.upload-zone.dragging {
  border-color: #2563eb;
  background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
  box-shadow: 0 8px 24px rgba(37, 99, 235, 0.14);
}

.upload-zone-violet {
  border-color: #ede9fe;
  background: linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%);
}

.upload-zone-violet:hover {
  border-color: #c4b5fd;
  background: linear-gradient(135deg, #f3e8ff 0%, #ede9fe 100%);
  box-shadow: 0 4px 12px rgba(124, 58, 237, 0.08);
}

.upload-zone-icon {
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  border-radius: 10px;
  color: #ffffff;
  background: linear-gradient(135deg, #2563eb, #0ea5e9);
}

.upload-zone-icon.violet {
  background: linear-gradient(135deg, #7c3aed, #a855f7);
}

.upload-zone-text {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.upload-zone-text strong {
  color: #0f172a;
  font-size: 13px;
  line-height: 1.2;
}

.upload-zone-text small {
  color: #94a3b8;
  font-size: 11px;
}

.selected-file-chip {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 8px 10px;
  border: 1px solid #bbf7d0;
  border-radius: 10px;
  background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
  transition: all 0.2s ease;
}

.selected-file-chip.violet {
  border-color: #c4b5fd;
  background: linear-gradient(135deg, #faf5ff 0%, #f3e8ff 100%);
}

.selected-file-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.selected-file-meta {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
}

.selected-file-main {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1;
}

.selected-file-actions {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.file-ext-badge {
  width: 36px;
  height: 20px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  border-radius: 5px;
  color: #ffffff;
  background: linear-gradient(135deg, #059669, #10b981);
  font-size: 9px;
  font-weight: 900;
  letter-spacing: 0.02em;
}

.file-ext-badge.violet {
  background: linear-gradient(135deg, #7c3aed, #a855f7);
}

.file-name {
  min-width: 0;
  overflow: hidden;
  color: #0f172a;
  font-size: 12px;
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.file-size {
  color: #94a3b8;
  font-size: 11px;
  flex-shrink: 0;
}

.file-status {
  width: fit-content;
  padding: 2px 7px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 800;
}

.file-status.uploaded {
  color: #15803d;
  background: #dcfce7;
}

.file-status.uploading {
  color: #2563eb;
  background: #dbeafe;
}

.remove-file-btn {
  width: 20px;
  height: 20px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  border: none;
  border-radius: 5px;
  color: #ef4444;
  background: transparent;
  cursor: pointer;
  font-size: 18px;
  font-weight: 700;
  line-height: 1;
  transition: all 0.18s ease;
}

.remove-file-btn:hover {
  color: #ffffff;
  background: #ef4444;
}

.hidden-input {
  display: none;
}
</style>
