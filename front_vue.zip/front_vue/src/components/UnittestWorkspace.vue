<template>
  <div class="ut-workspace">
    <!-- ── Top bar ─────────────────────────────────────────────────── -->
    <div class="ut-topbar">
      <div class="topbar-left">
        <div class="topbar-agent-icon">
          <el-icon size="15">
            <Finished />
          </el-icon>
        </div>
        <span class="topbar-title">Unit Test</span>
        <span class="topbar-desc">Auto-generate unit test cases from C/C++ source code</span>
      </div>
      <div class="topbar-right">
        <button
          v-if="phase === 'running'"
          class="cancel-btn"
          @click="cancelTask"
        >
          <el-icon size="13">
            <Close />
          </el-icon> Cancel Task
        </button>
      </div>
    </div>

    <!-- ── Main body ───────────────────────────────────────────────── -->
    <div class="ut-body">
      <!-- LEFT: input panel ─────────────────────────────────────────── -->
      <div class="input-panel">
        <!-- Select File -->
        <div class="panel-section">
          <div class="section-label">
            <el-icon size="13">
              <Document />
            </el-icon>
            Select Source File
          </div>

          <!-- Show the button when no file is selected -->
          <div
            v-if="!selectedFile || sourceFiles.length > 0"
            class="file-select-actions"
          >
            <button
              class="folder-select-btn"
              :disabled="selectingFile || phase === 'running'"
              @click="selectFileFromLocal"
            >
              <el-icon size="14">
                <FolderAdd />
              </el-icon>
              {{ selectingFile ? 'Selecting...' : 'Select Source File' }}
            </button>
            <button
              class="folder-select-btn secondary"
              :disabled="phase === 'running'"
              @click="fileInputRef?.click()"
            >
              <el-icon size="14">
                <Upload />
              </el-icon>
              Upload File
            </button>
            <input
              ref="fileInputRef"
              class="native-file-input"
              type="file"
              accept=".c,.h,.cpp,.hpp,.cxx,.cc"
              @change="onFileChange"
            >
          </div>

          <!-- Show a large filename card after a file is selected -->
          <div
            v-else
            class="selected-file-card"
          >
            <div class="file-card-header">
              <el-icon
                size="18"
                style="color:#16a34a"
              >
                <CircleCheck />
              </el-icon>
              <span class="file-card-title">File Selected</span>
              <button
                class="remove-file-btn"
                :disabled="phase === 'running'"
                @click="clearSelectedFile"
              >
                <el-icon size="14">
                  <Close />
                </el-icon>
              </button>
            </div>
            <div class="file-card-body">
              <div class="file-card-name">
                {{ selectedFile.name }}
              </div>
              <div class="file-card-path">
                {{ selectedFile.fullPath || selectedFile.path }}
              </div>
            </div>
          </div>
          <p
            v-if="fileError"
            class="file-error-hint"
          >
            {{ fileError }}
          </p>
        </div>

        <!-- Detected Project Root -->
        <div
          v-if="selectedFile"
          class="panel-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <FolderOpened />
            </el-icon>
            Project Path
          </div>
          <input
            v-model="detectedProjectRoot"
            class="output-dir-input"
            placeholder="Auto-detected project root will appear here"
          >
          <p
            v-if="detectedProjectRoot"
            class="output-dir-hint success"
          >
            ✓ Project root detected and editable
          </p>
          <p
            v-else
            class="output-dir-hint"
          >
            Project root is required for build verification
          </p>
        </div>

        <!-- File Tree (shown after folder selection) -->
        <div
          v-if="sourceFiles.length > 0"
          class="panel-section"
        >
          <div class="section-label">
            <el-icon size="13">
              <Document />
            </el-icon>
            Source Files
            <span class="file-count">{{ sourceFiles.length }} files</span>
          </div>
          <div class="file-tree">
            <div
              v-for="file in sourceFiles"
              :key="file.path"
              class="file-tree-item"
              :class="{ selected: selectedFile?.path === file.path }"
              @click="selectFile(file)"
            >
              <el-icon
                size="14"
                class="file-icon"
              >
                <Document />
              </el-icon>
              <span class="file-path">{{ file.relativePath }}</span>
            </div>
          </div>
        </div>

        <!-- Selected File Info from Folder (show file name and path) -->
        <div
          v-if="selectedFile && sourceFiles.length > 0"
          class="panel-section"
        >
          <div class="selected-file-info">
            <el-icon
              size="16"
              style="color:#16a34a"
            >
              <CircleCheck />
            </el-icon>
            <div class="file-info-content">
              <span class="file-info-name">{{ selectedFile.name }}</span>
              <span class="file-info-path">{{ selectedFile.fullPath || selectedFile.path }}</span>
            </div>
            <button
              class="remove-file-small"
              :disabled="phase === 'running'"
              @click="clearSelectedFile"
            >
              <el-icon size="12">
                <Close />
              </el-icon>
            </button>
          </div>
        </div>

        <!-- Output Path (hidden, but path is still stored for API) -->
        <!-- <div class="panel-section" v-if="selectedFile && sourceFiles.length > 0">
          <div class="section-label">
            <el-icon size="13"><FolderOpened /></el-icon>
            Output Path
          </div>
          <input
            v-model="outputDir"
            class="output-dir-input"
            :class="{ 'input-hint': outputDir.includes('<') }"
            placeholder="e.g. E:/project/src/hal/file.c"
            readonly
          />
          <p class="output-dir-hint success" v-if="outputDir && !outputDir.includes('<')">
            ✓ Test files will be saved to this path
          </p>
        </div> -->

        <!-- Run button -->
        <button
          class="run-btn"
          :class="{ loading: phase === 'running' }"
          :disabled="!selectedFile || (!selectedFile.file && !outputDir) || phase === 'running'"
          @click="handleGenerateClick"
        >
          <el-icon
            v-if="phase !== 'running'"
            size="15"
          >
            <Finished />
          </el-icon>
          <span
            v-else
            class="spinner"
          />
          {{ phase === 'running' ? 'Generating...' : 'Generate Tests' }}
        </button>
      </div>

      <!-- RIGHT: result panel ────────────────────────────────────────── -->
      <div class="result-panel">
        <!-- Idle: welcome guide -->
        <div
          v-if="phase === 'idle'"
          class="guide-area"
        >
          <div class="guide-icon">
            <el-icon
              size="32"
              style="color:#16a34a"
            >
              <Finished />
            </el-icon>
          </div>
          <h3 class="guide-title">
            Unit Test Generator
          </h3>
          <p class="guide-sub">
            Upload C source file to auto-generate Google Test
          </p>
          <div class="guide-steps">
            <div
              v-for="(s, i) in guideSteps"
              :key="i"
              class="guide-step"
            >
              <span class="step-num">{{ i + 1 }}</span>
              <span class="step-text">{{ s }}</span>
            </div>
          </div>
        </div>

        <!-- Workflow status: shown while running and after a terminal result -->
        <div
          v-if="phase !== 'idle'"
          class="loading-area"
        >
          <!-- Progress ring + message -->
          <div class="loading-header">
            <div class="ring-wrap">
              <svg
                class="ring-svg"
                viewBox="0 0 36 36"
              >
                <circle
                  class="ring-bg"
                  cx="18"
                  cy="18"
                  r="15"
                />
                <circle
                  class="ring-fg"
                  cx="18"
                  cy="18"
                  r="15"
                  :style="{ strokeDashoffset: 94.2 - (progressFromNodes / 100) * 94.2 }"
                />
              </svg>
              <span class="ring-pct">{{ progressFromNodes > 0 ? progressFromNodes + '%' : '…' }}</span>
            </div>
            <div class="loading-msg">
              <div class="msg-title">
                {{ workflowHeaderTitle }}
              </div>
              <div class="msg-sub">
                {{ statusMessage }}
              </div>
              <div class="msg-runtime">
                {{ phase === 'running' ? 'Running' : 'Elapsed' }} {{ formatDuration(elapsedSeconds) }}
                <span v-if="activityAgeSeconds !== null">
                  | Last activity {{ formatDuration(activityAgeSeconds) }} ago
                </span>
                <span v-if="businessProgressAgeSeconds !== null">
                  | Last workflow progress {{ formatDuration(businessProgressAgeSeconds) }} ago
                </span>
              </div>
              <div
                v-if="phase === 'running' && cliActivity.message"
                class="msg-activity"
              >
                CLI: {{ cliActivity.message }}
              </div>
              <div
                v-if="coverageSkillNames.length"
                class="msg-activity"
              >
                Skills: {{ coverageSkillNames.join(', ') }}
              </div>
              <div
                v-if="phase === 'running' && toolFailureSummary.total"
                class="msg-activity warning"
              >
                Tool errors: {{ toolFailureSummary.total }}
                <span v-if="toolFailureSummary.last?.category">
                  ({{ toolFailureSummary.last.category.replaceAll('_', ' ') }})
                </span>
              </div>
            </div>
          </div>

          <SkillRuntimeTrace :traces="skillRuntime" />

          <!-- Token usage display -->
          <div class="token-usage-display">
            <div class="token-item">
              <span class="token-label">Input:</span>
              <span class="token-value">{{ tokenUsage.input_tokens.toLocaleString() }}</span>
            </div>
            <div class="token-item">
              <span class="token-label">Output:</span>
              <span class="token-value">{{ tokenUsage.output_tokens.toLocaleString() }}</span>
            </div>
            <div class="token-item">
              <span class="token-label">Cache Write:</span>
              <span class="token-value">{{ tokenUsage.cache_creation_input_tokens.toLocaleString() }}</span>
            </div>
            <div class="token-item">
              <span class="token-label">Cache Read:</span>
              <span class="token-value">{{ tokenUsage.cache_read_input_tokens.toLocaleString() }}</span>
            </div>
            <div class="token-item total">
              <span class="token-label">Total:</span>
              <span class="token-value">{{ tokenUsage.total_tokens.toLocaleString() }}</span>
            </div>
          </div>

          <!-- Pipeline flow -->
          <div class="pipeline">
            <template
              v-for="(step, i) in pipelineSteps"
              :key="i"
            >
              <div
                class="pipe-node"
                :class="step.state"
              >
                <div class="pipe-icon">
                  <el-icon
                    v-if="step.state === 'done'"
                    size="18"
                    class="pipe-check"
                  >
                    <CircleCheck />
                  </el-icon>
                  <el-icon
                    v-else-if="step.state === 'fail'"
                    size="18"
                    class="pipe-fail"
                  >
                    <CircleClose />
                  </el-icon>
                  <span
                    v-else-if="step.state === 'active'"
                    class="pipe-spinner"
                  />
                  <el-icon
                    v-else-if="step.state === 'cancelled'"
                    size="18"
                    class="pipe-fail"
                  >
                    <CircleClose />
                  </el-icon>
                  <span
                    v-else
                    class="pipe-dot"
                  />
                </div>
                <span class="pipe-label">{{ step.label }}</span>
              </div>
              <div
                v-if="i < pipelineSteps.length - 1"
                class="pipe-arrow"
                :class="{ lit: step.state === 'done' }"
              >
                <svg
                  width="28"
                  height="12"
                  viewBox="0 0 28 12"
                >
                  <line
                    x1="0"
                    y1="6"
                    x2="20"
                    y2="6"
                    stroke-width="2"
                  />
                  <polyline
                    points="16,2 22,6 16,10"
                    stroke-width="2"
                    fill="none"
                    stroke-linejoin="round"
                  />
                </svg>
              </div>
            </template>
          </div>
        </div>

        <!-- Done: result cards ──────────────────────────────────── -->
        <div
          v-if="phase === 'done' && result"
          class="result-area"
        >
          <!-- ① Hero banner ──────────────────────────────────────────── -->
          <div class="hero-banner">
            <div class="hero-glow" />

            <!-- Left: donut rings -->
            <div class="hero-donuts">
              <!-- Main coverage donut -->
              <div class="donut-wrap main-donut">
                <svg
                  viewBox="0 0 120 120"
                  class="donut-svg"
                >
                  <defs>
                    <linearGradient
                      id="grad-main"
                      x1="0%"
                      y1="0%"
                      x2="100%"
                      y2="100%"
                    >
                      <stop
                        offset="0%"
                        stop-color="#38bdf8"
                      />
                      <stop
                        offset="100%"
                        stop-color="#6366f1"
                      />
                    </linearGradient>
                  </defs>
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    class="donut-track"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    class="donut-ring main-ring"
                    :style="donutStyle(result.final_coverage || 0, 314.16)"
                  />
                </svg>
                <div class="donut-label">
                  <span class="donut-pct">{{ (result.final_coverage || 0).toFixed(1) }}<em>%</em></span>
                  <span class="donut-sub">Coverage</span>
                </div>
              </div>

              <!-- Mini donuts: branch + function -->
              <div
                v-if="result.coverage_report"
                class="mini-donuts"
              >
                <div
                  v-for="m in miniMetrics"
                  :key="m.key"
                  class="mini-donut-item"
                >
                  <svg
                    viewBox="0 0 60 60"
                    class="mini-svg"
                  >
                    <defs>
                      <linearGradient
                        :id="`grad-${m.key}`"
                        x1="0%"
                        y1="0%"
                        x2="100%"
                        y2="100%"
                      >
                        <stop
                          offset="0%"
                          :stop-color="m.c1"
                        />
                        <stop
                          offset="100%"
                          :stop-color="m.c2"
                        />
                      </linearGradient>
                    </defs>
                    <circle
                      cx="30"
                      cy="30"
                      r="23"
                      class="donut-track"
                    />
                    <circle
                      cx="30"
                      cy="30"
                      r="23"
                      class="donut-ring"
                      :style="donutStyle(m.val, 144.51)"
                      :stroke="`url(#grad-${m.key})`"
                    />
                  </svg>
                  <div class="mini-label">
                    <span class="mini-pct">{{ m.na ? 'N/A' : m.val.toFixed(1) + '%' }}</span>
                    <span class="mini-sub">{{ m.name }}</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Right: KPI tiles -->
            <div class="kpi-grid">
              <div class="kpi-tile kpi-green">
                <span class="kpi-icon">✓</span>
                <span class="kpi-val">{{ getTestPassRate(result) }}%</span>
                <span class="kpi-name">Pass Rate</span>
              </div>
              <div class="kpi-tile kpi-indigo">
                <span class="kpi-icon">⬡</span>
                <span class="kpi-val">{{ result.functions_tested?.length || 0 }}</span>
                <span class="kpi-name">Functions</span>
              </div>
              <div class="kpi-tile kpi-blue">
                <span class="kpi-icon">◎</span>
                <span class="kpi-val">{{ result.test_files?.length || parsedEntries.length }}</span>
                <span class="kpi-name">Files</span>
              </div>
              <div class="kpi-tile kpi-amber">
                <span class="kpi-icon">↻</span>
                <span class="kpi-val">{{ result.iteration_count || 1 }}</span>
                <span class="kpi-name">Iterations</span>
              </div>
              <div class="kpi-tile kpi-purple">
                <span class="kpi-icon">🪙</span>
                <span class="kpi-val">{{ formatTokenCount(
                  (result.token_usage?.input_tokens || 0) +
                    (result.token_usage?.output_tokens || 0) +
                    (result.token_usage?.cache_creation_input_tokens || 0) +
                    (result.token_usage?.cache_read_input_tokens || 0)
                ) }}</span>
                <span class="kpi-name">Total Tokens</span>
                <div
                  class="kpi-detail"
                  style="display: block;"
                >
                  Input: {{ formatTokenCountInK(result.token_usage?.input_tokens || 0) }}<br>
                  Output: {{ formatTokenCountInK(result.token_usage?.output_tokens || 0) }}<br>
                  Cache Write: {{ formatTokenCountInK(result.token_usage?.cache_creation_input_tokens || 0) }}<br>
                  Cache Read: {{ formatTokenCountInK(result.token_usage?.cache_read_input_tokens || 0) }}<br>
                  Total: {{ formatTokenCountInK(
                    (result.token_usage?.input_tokens || 0) +
                      (result.token_usage?.output_tokens || 0) +
                      (result.token_usage?.cache_creation_input_tokens || 0) +
                      (result.token_usage?.cache_read_input_tokens || 0)
                  ) }}
                </div>
              </div>
              <div class="kpi-tile kpi-green">
                <span class="kpi-icon">💰</span>
                <span class="kpi-val">{{ formatCost(calculateCost(result.token_usage)) }}</span>
                <span class="kpi-name">Total Cost</span>
                <div
                  class="kpi-detail"
                  style="display: block;"
                >
                  Input: {{ formatCost((result.token_usage?.input_tokens || 0) * 3.0 / 1000000) }}<br>
                  Output: {{ formatCost((result.token_usage?.output_tokens || 0) * 15.0 / 1000000) }}<br>
                  Cache Write: {{ formatCost((result.token_usage?.cache_creation_input_tokens || 0) * 3.75 / 1000000) }}<br>
                  Cache Read: {{ formatCost((result.token_usage?.cache_read_input_tokens || 0) * 0.30 / 1000000) }}
                </div>
              </div>
            </div>
          </div>

          <!-- ② Tag strip -->
          <div class="tag-strip">
            <span
              v-if="result.layer"
              class="tag tag-layer"
            >⬡ {{ result.layer }}</span>
            <span class="tag tag-fw">◈ {{ selectedFramework === 'gtest' ? 'Google Test' : selectedFramework }}</span>
            <span
              v-if="result.large_file_diagnostics?.length"
              class="tag tag-large"
            >▦ Long-file strategy</span>
          </div>

          <!-- Long-file strategy diagnostics -->
          <div
            v-if="result.large_file_diagnostics?.length"
            class="dark-card large-file-card"
          >
            <div class="dark-card-title">
              <span class="dot-blue" />Long-file generation strategy
              <span class="card-count">{{ result.large_file_diagnostics.length }} source{{ result.large_file_diagnostics.length === 1 ? '' : 's' }}</span>
            </div>
            <div
              v-for="diagnostic in result.large_file_diagnostics"
              :key="diagnostic.source_file + '-' + diagnostic.original_chars"
              class="large-file-diagnostic"
            >
              <div class="large-file-summary">
                <strong>{{ diagnostic.source_file }}</strong>
                <span>{{ formatTokenCount(diagnostic.original_chars) }} chars → {{ formatTokenCount(diagnostic.prompt_chars) }} prompt chars</span>
              </div>
              <p class="large-file-reason">
                {{ diagnostic.reason }}
              </p>
              <div class="large-file-stats">
                <span>{{ diagnostic.functions_detected || 0 }} functions</span>
                <span>{{ diagnostic.function_groups?.length || 0 }} groups</span>
                <span>{{ diagnostic.branch_hint_count || 0 }} branch hints</span>
                <span>strategy: {{ diagnostic.strategy || 'priority-map' }}</span>
              </div>
              <div
                v-if="diagnostic.test_matrix?.length"
                class="large-file-matrix"
              >
                <div class="large-file-subtitle">
                  Skill-guided test matrix
                </div>
                <ul>
                  <li
                    v-for="item in diagnostic.test_matrix"
                    :key="item"
                  >
                    {{ item }}
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <!-- ③ Generated files ─────────────────────────────────────── -->
          <div class="dark-card files-card">
            <div class="dark-card-title">
              <span class="dot-purple" />Generated Files
              <span class="card-count">{{ (result.test_files?.length || parsedEntries.length) }} files</span>
            </div>

            <!-- from test_files -->
            <template v-if="result.test_files?.length">
              <div
                v-for="f in result.test_files"
                :key="f.filename"
                class="file-row"
              >
                <div class="file-row-head">
                  <span
                    class="file-ext-badge"
                    :class="extClass(f.filename)"
                  >{{ extLabel(f.filename) }}</span>
                  <span class="file-row-name">{{ f.filename }}</span>
                  <button
                    class="icon-btn preview-btn"
                    @click="togglePreview(f.filename, 'mem')"
                  >
                    {{ expanded.has(f.filename) ? '▲ Collapse' : '▼ Preview' }}
                  </button>
                  <button
                    class="icon-btn dl-btn2"
                    @click="downloadMemFile(f.filename, f.content)"
                  >
                    ↓ download
                  </button>
                </div>
                <div
                  v-if="expanded.has(f.filename)"
                  class="code-preview"
                >
                  <div class="code-header">
                    <span>{{ f.filename }}</span>
                    <button
                      class="copy-sm-btn"
                      @click="copyText(f.content, f.filename)"
                    >
                      {{ copiedMap[f.filename] ? '✓ Copied' : '⎘ Copy' }}
                    </button>
                  </div>
                  <pre class="code-block">{{ f.content }}</pre>
                </div>
              </div>
            </template>

            <!-- fallback: parsed_content -->
            <template v-else-if="result.parsed_content">
              <div
                v-for="[key, code] in parsedEntries"
                v-show="code"
                :key="key"
                class="file-row"
              >
                <div class="file-row-head">
                  <span
                    class="file-ext-badge"
                    :class="extClass(key)"
                  >{{ extLabel(key) }}</span>
                  <span class="file-row-name">{{ parsedLabel(key) }}</span>
                  <button
                    class="icon-btn preview-btn"
                    @click="togglePreview(key, 'mem')"
                  >
                    {{ expanded.has(key) ? '▲ collapse' : '▼ preview' }}
                  </button>
                  <button
                    class="icon-btn dl-btn2"
                    @click="downloadMemFile(key, code)"
                  >
                    ↓ download
                  </button>
                </div>
                <div
                  v-if="expanded.has(key)"
                  class="code-preview"
                >
                  <div class="code-header">
                    <span>{{ parsedLabel(key) }}</span>
                    <button
                      class="copy-sm-btn"
                      @click="copyText(code, key)"
                    >
                      {{ copiedMap[key] ? '✓ Copied' : '⎘ Copy' }}
                    </button>
                  </div>
                  <pre class="code-block">{{ code }}</pre>
                </div>
              </div>
            </template>

            <!-- CLI log artifact row -->
            <div
              v-if="result.cli_log_artifact?.available"
              class="file-row"
            >
              <div class="file-row-head">
                <span class="file-ext-badge ext-log">MD</span>
                <span class="file-row-name">{{ result.cli_log_artifact.filename }}</span>
                <span class="file-row-meta">{{ fmtSize(result.cli_log_artifact.size_bytes) }}</span>
                <button
                  class="icon-btn preview-btn"
                  @click="toggleCliLogPreview"
                >
                  {{ showCliLog ? '▲ Collapse' : '▼ Preview' }}
                </button>
                <button
                  class="icon-btn dl-btn2"
                  @click="downloadCliLog"
                >
                  ↓ Download
                </button>
              </div>
              <div
                v-if="showCliLog"
                class="code-preview"
              >
                <div class="code-header">
                  <span>{{ result.cli_log_artifact.filename }}</span>
                  <button
                    class="copy-sm-btn"
                    @click="copyText(cliLogContent, 'cli-log')"
                  >
                    {{ copiedMap['cli-log'] ? '✓ Copied' : '⎘ Copy' }}
                  </button>
                </div>
                <pre
                  v-if="cliLogContent"
                  class="code-block"
                >{{ cliLogContent }}</pre>
                <div
                  v-else
                  class="log-loading"
                >
                  Loading...
                </div>
              </div>
            </div>
          </div>

          <!-- ④ Workflow output (collapsible) ─────────────────────────── -->
          <div class="dark-card log-card">
            <div
              class="dark-card-title clickable"
              @click="showBuild = !showBuild"
            >
              <span :class="result.compile_success ? 'dot-green' : 'dot-red'" />
              Workflow Output
              <span class="card-toggle">{{ showBuild ? '▲' : '▼' }}</span>
            </div>

            <div v-show="showBuild">
              <!-- Claude CLI Summary -->
              <div
                v-if="result.cli_summary"
                class="summary-inner"
              >
                <!-- What was done -->
                <div class="summary-section">
                  <div class="summary-section-title">
                    What was done
                  </div>
                  <ul class="summary-list">
                    <li
                      v-for="item in result.cli_summary.what_was_done"
                      :key="item"
                    >
                      ✓ {{ item }}
                    </li>
                  </ul>
                </div>

                <!-- Result -->
                <div class="summary-section">
                  <div class="summary-section-title">
                    Result
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">Compile:</span>
                    <span :class="result.cli_summary.result.compile === 'passed' ? 'val-green' : 'val-red'">
                      {{ result.cli_summary.result.compile === 'passed' ? 'Passed' : result.cli_summary.result.compile }}
                    </span>
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">Coverage target:</span>
                    <span :class="coverageTargetMet ? 'val-green' : 'val-amber'">
                      {{ coverageTargetMet ? 'Met' : 'Not met' }}
                    </span>
                  </div>
                  <div class="summary-kv">
                    <span class="summary-kv-key">Test result:</span>
                    <span :class="getTestPassRate(result) === 100 ? 'val-green' : 'val-amber'">
                      {{ getTestPassRate(result) }}%({{ result.passed_count || 0 }} / {{ result.test_count || 0 }})
                    </span>
                  </div>
                </div>

                <!-- Coverage -->
                <div class="summary-section">
                  <div class="summary-section-title">
                    Coverage
                  </div>
                  <table class="coverage-summary-table">
                    <thead>
                      <tr>
                        <th>Coverage</th>
                        <th>Target</th>
                        <th>Result</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Line coverage</td>
                        <td>{{ result.cli_summary.coverage.line_target }}%</td>
                        <td>{{ result.cli_summary.coverage.line }}%</td>
                      </tr>
                      <tr>
                        <td>Branch coverage</td>
                        <td>{{ result.cli_summary.coverage.branch_target }}%</td>
                        <td>{{ result.cli_summary.coverage.branch ?? 'N/A' }}{{ result.cli_summary.coverage.branch !== null ? '%' : '' }}</td>
                      </tr>
                      <tr>
                        <td>Function coverage</td>
                        <td>{{ result.cli_summary.coverage.function_target }}%</td>
                        <td>{{ result.cli_summary.coverage.function ?? 'N/A' }}{{ result.cli_summary.coverage.function !== null ? '%' : '' }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <!-- Issues -->
                <div
                  v-if="cliSummaryIssues.length"
                  class="summary-section"
                >
                  <div class="summary-section-title">
                    Issues
                  </div>
                  <ul class="summary-list issues-list">
                    <li
                      v-for="issue in cliSummaryIssues"
                      :key="issue"
                    >
                      ⚠ {{ issue }}
                    </li>
                  </ul>
                </div>

                <!-- Summary -->
                <div class="summary-section summary-section-last">
                  <div class="summary-section-title">
                    Summary
                  </div>
                  <div
                    v-for="section in cliSummarySections"
                    :key="section.title"
                    class="summary-subsection"
                  >
                    <div class="summary-subsection-title">
                      {{ section.title }}
                    </div>
                    <p class="summary-paragraph">
                      {{ section.content }}
                    </p>
                  </div>
                </div>

                <!-- Divider before raw log -->
                <div class="summary-divider" />
              </div>

              <pre
                class="build-output"
                :class="result.compile_success ? 'build-ok' : 'build-err'"
              >{{
                result.compile_output || '(no output)'
              }}</pre>
            </div>
          </div>

          <!-- Error box -->
          <div
            v-if="taskError"
            class="error-box"
          >
            <el-icon size="14">
              <Warning />
            </el-icon>
            {{ taskError }}
          </div>
        </div>

        <!-- Failed - Show report with actual data -->
        <div
          v-if="(phase === 'failed' || phase === 'cancelled') && result"
          class="result-area"
        >
          <!-- ① Hero banner (same style as success) -->
          <div class="hero-banner">
            <div class="hero-glow" />

            <!-- Left: donut rings -->
            <div class="hero-donuts">
              <!-- Main coverage donut -->
              <div class="donut-wrap main-donut">
                <svg
                  viewBox="0 0 120 120"
                  class="donut-svg"
                >
                  <defs>
                    <linearGradient
                      id="grad-main"
                      x1="0%"
                      y1="0%"
                      x2="100%"
                      y2="100%"
                    >
                      <stop
                        offset="0%"
                        stop-color="#38bdf8"
                      />
                      <stop
                        offset="100%"
                        stop-color="#6366f1"
                      />
                    </linearGradient>
                  </defs>
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    class="donut-track"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    class="donut-ring main-ring"
                    :style="donutStyle(result.final_coverage || 0, 314.16)"
                  />
                </svg>
                <div class="donut-label">
                  <span class="donut-pct">{{ (result.final_coverage || 0).toFixed(1) }}<em>%</em></span>
                  <span class="donut-sub">Coverage</span>
                </div>
              </div>

              <!-- Mini donuts: branch + function -->
              <div
                v-if="result.coverage_report"
                class="mini-donuts"
              >
                <div
                  v-for="m in miniMetrics"
                  :key="m.key"
                  class="mini-donut-item"
                >
                  <svg
                    viewBox="0 0 60 60"
                    class="mini-svg"
                  >
                    <defs>
                      <linearGradient
                        :id="`grad-${m.key}`"
                        x1="0%"
                        y1="0%"
                        x2="100%"
                        y2="100%"
                      >
                        <stop
                          offset="0%"
                          :stop-color="m.c1"
                        />
                        <stop
                          offset="100%"
                          :stop-color="m.c2"
                        />
                      </linearGradient>
                    </defs>
                    <circle
                      cx="30"
                      cy="30"
                      r="23"
                      class="donut-track"
                    />
                    <circle
                      v-if="!m.na"
                      cx="30"
                      cy="30"
                      r="23"
                      class="donut-ring"
                      :style="donutStyle(m.val, 144.51)"
                      :stroke="`url(#grad-${m.key})`"
                    />
                  </svg>
                  <div class="mini-label">
                    <span class="mini-pct">{{ m.na ? 'N/A' : m.val.toFixed(1) + '%' }}</span>
                    <span class="mini-sub">{{ m.name }}</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Right: KPI tiles -->
            <div class="kpi-grid">
              <div class="kpi-tile kpi-green">
                <span class="kpi-icon">✓</span>
                <span class="kpi-val">{{ getTestPassRate(result) }}%</span>
                <span class="kpi-name">Pass Rate</span>
              </div>
              <div class="kpi-tile kpi-indigo">
                <span class="kpi-icon">⬡</span>
                <span class="kpi-val">{{ result.functions_tested?.length || 0 }}</span>
                <span class="kpi-name">Functions</span>
              </div>
              <div class="kpi-tile kpi-blue">
                <span class="kpi-icon">◎</span>
                <span class="kpi-val">{{ result.test_files?.length || parsedEntries.length }}</span>
                <span class="kpi-name">Files</span>
              </div>
              <div class="kpi-tile kpi-amber">
                <span class="kpi-icon">↻</span>
                <span class="kpi-val">{{ result.iteration_count || 1 }}</span>
                <span class="kpi-name">Iterations</span>
              </div>
            </div>
          </div>

          <!-- ② Error message banner -->
          <div class="error-box">
            <el-icon
              size="18"
              style="color:#ef4444; flex-shrink:0"
            >
              <CircleClose />
            </el-icon>
            <div style="flex:1">
              <div style="font-weight:600; margin-bottom:4px">
                {{ phase === 'cancelled' ? 'Generation Cancelled' : 'Generation Failed' }}
              </div>
              <div style="font-size:12px">
                {{ taskError }}
              </div>
            </div>
          </div>

          <!-- ③ Generated files (if any) -->
          <div
            v-if="parsedEntries.length"
            class="dark-card"
          >
            <div class="dark-card-title">
              <el-icon size="13">
                <Document />
              </el-icon>
              Generated Files
              <span class="card-count">{{ parsedEntries.length }}</span>
            </div>
            <div
              v-for="([key, content], i) in parsedEntries"
              :key="i"
              class="file-row"
            >
              <div class="file-row-head">
                <span
                  class="file-ext-badge"
                  :class="extClass(key)"
                >{{ extLabel(key) }}</span>
                <span class="file-row-name">{{ parsedLabel(key) }}</span>
                <span style="font-size:11px; color:#9ca3af; margin-left:auto; margin-right:8px">
                  {{ fmtSize(content.length) }}
                </span>
                <button
                  class="icon-btn dl-btn2"
                  @click="downloadFile(key, content)"
                >
                  <el-icon size="12">
                    <Download />
                  </el-icon> Download
                </button>
              </div>
            </div>
          </div>

          <!-- ④ Action buttons -->
          <div style="display:flex; justify-content:center; margin-top:10px">
            <button
              class="reset-btn"
              @click="resetAll"
            >
              <el-icon size="13">
                <RefreshLeft />
              </el-icon> Try Again
            </button>
          </div>
        </div>

        <!-- Failed without a result: keep an actionable terminal state visible. -->
        <div
          v-if="(phase === 'failed' || phase === 'cancelled') && !result"
          class="fail-area"
        >
          <el-icon
            size="42"
            :style="{ color: phase === 'cancelled' ? '#f59e0b' : '#ef4444' }"
          >
            <CircleClose />
          </el-icon>
          <div class="fail-msg">
            {{ phase === 'cancelled' ? 'Generation Cancelled' : 'Generation Failed' }}
          </div>
          <div class="fail-detail">
            {{ taskError || 'The task ended without a result.' }}
          </div>
          <button
            class="reset-btn"
            @click="resetAll"
          >
            <el-icon size="13">
              <RefreshLeft />
            </el-icon> Try Again
          </button>
        </div>
      </div>
    </div>

    <!-- AWS SSO Login Modal -->
    <AWSSSOLoginModal
      :visible="showAWSSSOModal"
      @success="handleAWSSSOSuccess"
      @close="handleAWSSSOClose"
    />

    <!-- Profile Error Dialog -->
    <ProfileErrorDialog
      :visible="showProfileErrorDialog"
      :profile-name="profileErrorName"
      @close="handleProfileErrorClose"
    />
  </div>
</template>

<script setup>
import { ref, computed, reactive, onMounted, onUnmounted, onBeforeUnmount, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { http } from '../api/http.js'
import { apiGenerateTests, apiPollTask, apiCancelTask, apiGetTask } from '../api/unittest.js'
import { useWorkspaceStore } from '../stores/workspace.js'
import { useUnittestStore } from '../stores/unittest.js'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { routeSourceFilePicker } from '../utils/localFileSelector.js'
import AWSSSOLoginModal from './AWSSSOLoginModal.vue'
import ProfileErrorDialog from './ProfileErrorDialog.vue'
import SkillRuntimeTrace from './SkillRuntimeTrace.vue'

const router = useRouter()
const workspaceStore = useWorkspaceStore()
const unittestStore = useUnittestStore()
const authStore = useAuthStore()
const mountedAccount = accountIdentity(authStore)
const AGENT_ID = `unittest:${mountedAccount}:2`
const PROJECT_ROOT_KEY = `unittest_last_project_root:${mountedAccount}`
let disposed = false
watch(() => accountIdentity(authStore), () => { disposed = true }, { flush: 'sync' })
function isCurrentAccount() {
  return !disposed && mountedAccount === accountIdentity(authStore)
}
onBeforeUnmount(() => { disposed = true })
const MAX_TASKS = 3 // Maximum number of concurrent tasks

// ── Props ─────────────────────────────────────────────────────────────────────
const props = defineProps({
  activeTask: Object, // Currently selected task from history
})

const emit = defineEmits(['new-task', 'task-updated'])

// ── State ─────────────────────────────────────────────────────────────────────
const folderInputRef    = ref(null)
const fileInputRef      = ref(null)
const fileTree          = ref([])
const sourceFiles       = ref([])
const selectedFile      = ref(null)
const selectedFramework = ref('gtest')
const selectedLayer     = ref('auto')
const selectedPlatform  = ref('stm32u3')
const outputDir         = ref('')
const selectingFile     = ref(false)
const isDragOver        = ref(false)
const fileError         = ref('')  // File validation error message

// Local service URL
const LOCAL_SERVICE_URL = 'http://127.0.0.1:9999'
const CANCEL_SELECTION_ERRORS = new Set([
  'Selection cancelled by user',
  'User canceled selection',
])

function isSelectionCanceled(error) {
  return typeof error === 'string' && CANCEL_SELECTION_ERRORS.has(error)
}

// Remember the last project root used
const lastProjectRoot = ref(localStorage.getItem(PROJECT_ROOT_KEY) || '')
const detectedProjectRoot = ref('') // Auto-detected project root from backend API

// phase: 'idle' | 'running' | 'done' | 'failed'
const phase         = ref('idle')
const progress      = ref(0)
const statusMessage = ref('')
const elapsedSeconds = ref(0)
const activityAgeSeconds = ref(null)
const businessProgressAgeSeconds = ref(null)
const cliActivity = reactive({ kind: '', message: '', updated_at: '' })
const toolFailureSummary = reactive({
  total: 0,
  by_category: {},
  last: null,
  consecutive_count: 0,
  deterministic_loop: false,
  tool_calls: 0,
  business_progress_sequence: 0,
  last_business_progress_at: null
})
const coverageSkillNames = ref([])
const skillRuntime = ref([])
const result        = ref(null)
const taskError     = ref(null)
const currentTaskId = ref(null) // Current task ID
watch(currentTaskId, () => { skillRuntime.value = [] }, { flush: 'sync' })
const currentStage  = ref('')

// Token usage tracking
const tokenUsage = ref({
  input_tokens: 0,
  output_tokens: 0,
  total_tokens: 0,
  cache_creation_input_tokens: 0,
  cache_read_input_tokens: 0
})

// Live node states from backend workflow_db, used directly to drive the pipeline UI
const liveNodes     = ref([])   // [{ node_name, status, ... }, ...]

function applyRuntimeTelemetry(data) {
  if (!data) return
  if (data.business_progress_age_seconds !== undefined) {
    businessProgressAgeSeconds.value = data.business_progress_age_seconds
  }
  if (data.tool_failure_summary) {
    Object.assign(toolFailureSummary, data.tool_failure_summary)
  }
}

// preview state
const expanded      = ref(new Set())
const fileContents  = reactive({})
const copiedMap     = reactive({})
const showBuild     = ref(true)

// CLI log preview state
const showCliLog    = ref(false)
const cliLogContent = ref('')

// AWS SSO login modal state
const showAWSSSOModal = ref(false)
const pendingRetryFn = ref(null)

// Profile error dialog state
const showProfileErrorDialog = ref(false)
const profileErrorName = ref('')

// ── Config ────────────────────────────────────────────────────────────────────
const frameworks = [
  { value: 'gtest',  label: 'Google Test' },
  { value: 'unity',  label: 'Unity' },
  { value: 'auto',   label: 'Auto-detect' },
]

const layers = [
  { value: 'auto',       label: 'Auto' },
  { value: 'driver',     label: 'Driver' },
  { value: 'hal',        label: 'HAL' },
  { value: 'controller', label: 'Controller' },
  { value: 'app',        label: 'App' },
]

const platforms = [
  { value: 'stm32u3',     label: 'STM32U3' },
  { value: 'rtl8722fam',  label: 'RTL8722' },
  { value: 'nrf52',       label: 'nRF52' },
]

const guideSteps = [
  'Select your C source code file',
  'Click Generate Tests — AI runs linear pipeline',
  'Preview, copy, or download all generated files',
]

// Pipeline steps mapped to the linear pipeline node names
const PIPELINE_NODES = [
  { key: 'init_project_context', label: 'Initialize'          },
  { key: 'detect_layer',         label: 'Detect Layer'  },
  { key: 'generate_paths',       label: 'Generate Paths'     },
  { key: 'build_prompt',         label: 'Build Prompt'  },
  { key: 'generate_tests',       label: 'Generate'      },
  { key: 'parse_output',         label: 'Parse Output'  },
  { key: 'update_qbs_config',    label: 'QBS Config'    },
  { key: 'qbs_build',            label: 'Build'         },
  { key: 'run_tests',            label: 'Run Tests'     },
  { key: 'analyze_coverage',     label: 'Coverage'      },
  { key: 'save_files',           label: 'Save Files'    },
  { key: 'finalize',             label: 'Finalize'      },
]
const TASK_START_COMPLETED_NODES = new Set([
  'detect_layer',
  'generate_paths',
  'build_prompt',
])

function createInitialPipelineNodes() {
  return PIPELINE_NODES.map(node => ({
    node_name: node.key,
    status: TASK_START_COMPLETED_NODES.has(node.key) ? 'completed' : 'pending',
  }))
}

const PIPELINE_NODE_STATUSES = new Set([
  'pending', 'in_progress', 'completed', 'failed', 'skipped', 'cancelled',
])

const BUILD_REQUIRED_NODES = ['parse_output', 'update_qbs_config']

function normalizePipelineNodes(nodes, taskStatus = 'running') {
  const normalized = Object.fromEntries(
    createInitialPipelineNodes().map(node => [node.node_name, node.status]),
  )
  if (Array.isArray(nodes)) {
    for (const node of nodes) {
      if (!node?.node_name || !PIPELINE_NODE_STATUSES.has(node.status)) continue
      if (Object.prototype.hasOwnProperty.call(normalized, node.node_name)) {
        normalized[node.node_name] = node.status
      }
    }
  }

  // The preparation contract is shared with the backend: accepted tasks show
  // Detect Layer, Generate Paths, and Build Prompt as complete immediately.
  if (['running', 'paused', 'completed', 'failed', 'cancelled'].includes(taskStatus)) {
    for (const nodeName of TASK_START_COMPLETED_NODES) {
      if (!['failed', 'cancelled'].includes(normalized[nodeName])) {
        normalized[nodeName] = 'completed'
      }
    }
  }

  if (taskStatus === 'completed') {
    for (const node of PIPELINE_NODES) {
      if (normalized[node.key] === 'pending' || normalized[node.key] === 'in_progress') {
        normalized[node.key] = 'completed'
      }
    }
  }

  // Keep the same ordering invariant as the backend. CLI tasks can finish
  // parsing and QBS preparation without emitting separate UI callbacks, but a
  // build status proves both prerequisites were completed. Never overwrite an
  // explicit failure or cancellation with a synthetic success.
  const qbsConfigStatus = normalized.update_qbs_config
  if (['in_progress', 'completed', 'failed'].includes(qbsConfigStatus)
      && !['failed', 'cancelled'].includes(normalized.parse_output)) {
    normalized.parse_output = 'completed'
  }
  if (['in_progress', 'completed', 'failed'].includes(normalized.qbs_build)) {
    for (const nodeName of BUILD_REQUIRED_NODES) {
      if (!['failed', 'cancelled'].includes(normalized[nodeName])) {
        normalized[nodeName] = 'completed'
      }
    }
  }
  if (normalized.analyze_coverage === 'completed'
      && !['failed', 'cancelled'].includes(normalized.run_tests)) {
    normalized.run_tests = 'completed'
  }

  return PIPELINE_NODES.map(node => ({
    node_name: node.key,
    status: normalized[node.key],
  }))
}

function resolveInitialPipelineNodes(nodes, taskStatus = 'running') {
  return normalizePipelineNodes(nodes, taskStatus)
}

function finiteNumber(value, fallback = 0) {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : fallback
}

function normalizeResultPayload(raw, fallbackLayer = '') {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null

  const normalized = { ...raw }
  const sourceReport = raw.coverage_report && typeof raw.coverage_report === 'object'
    ? raw.coverage_report
    : {}
  const lineCoverage = finiteNumber(
    raw.final_coverage ?? raw.coverage ?? sourceReport.line_coverage,
    0,
  )
  normalized.final_coverage = Math.max(0, Math.min(100, lineCoverage))
  const compileFlag = raw.compile_success
    ?? (raw.build_failed !== undefined
      ? !raw.build_failed
      : raw.compilation_summary?.all_compiled)
  normalized.compile_success = compileFlag === true
  normalized.iteration_count = Math.max(1, finiteNumber(
    raw.iteration_count ?? raw.coverage_iteration ?? raw.coverage_improvement_attempts,
    1,
  ))
  normalized.coverage_improvement_attempts = Math.max(0, Math.trunc(
    finiteNumber(raw.coverage_improvement_attempts ?? raw.coverage_iteration, 0),
  ))
  normalized.coverage_improvement_max = Math.max(0, Math.trunc(
    finiteNumber(raw.coverage_improvement_max, 0),
  ))
  normalized.coverage_target_met = raw.coverage_target_met === true
  normalized.coverage_stop_reason = typeof raw.coverage_stop_reason === 'string'
    ? raw.coverage_stop_reason
    : ''
  normalized.layer = raw.layer || fallbackLayer || ''

  const branchCoverage = raw.branch_coverage ?? sourceReport.branch_coverage
  const functionCoverage = raw.function_coverage ?? sourceReport.function_coverage
  normalized.coverage_report = {
    ...sourceReport,
    line_coverage: normalized.final_coverage,
    branch_coverage: finiteNumber(branchCoverage, 0),
    function_coverage: finiteNumber(functionCoverage, 0),
    lines_executed: finiteNumber(sourceReport.lines_executed, 0),
    lines_total: finiteNumber(sourceReport.lines_total, 0),
    branches_executed: finiteNumber(sourceReport.branches_executed, 0),
    branches_total: finiteNumber(sourceReport.branches_total, 0),
    functions_executed: finiteNumber(sourceReport.functions_executed, 0),
    functions_total: finiteNumber(sourceReport.functions_total, 0),
  }

  if (Array.isArray(raw.test_files)) {
    normalized.test_files = raw.test_files
      .filter(file => file && typeof file.filename === 'string')
      .map(file => ({
        ...file,
        content: typeof file.content === 'string' ? file.content : '',
      }))
  } else {
    normalized.test_files = []
  }

  const testCount = Math.max(0, Math.trunc(finiteNumber(raw.test_count ?? raw.total, 0)))
  const passedCount = Math.max(0, Math.min(testCount, Math.trunc(
    finiteNumber(raw.passed_count ?? raw.passed, 0),
  )))
  normalized.test_count = testCount
  normalized.passed_count = passedCount
  normalized.failed_cases = Array.isArray(raw.failed_cases) ? raw.failed_cases : []
  return normalized
}

// Coverage optimization is resumable and must not override a passing GTest
// result in the UI. Older tasks may still carry a terminal failed workflow
// status even though their result payload contains a complete test pass.
function hasPassingUnitTests(raw) {
  if (!raw || typeof raw !== 'object') return false
  const total = Number(raw.test_count ?? raw.total ?? 0)
  const passed = Number(raw.passed_count ?? raw.passed ?? 0)
  const failures = Array.isArray(raw.failed_cases) ? raw.failed_cases.length : 0
  return total > 0 && passed === total && failures === 0
}

// Convert the liveNodes array into pipeline display state
// Preserve backend semantics in the UI: skipped is neutral and cancelled is terminal.
const pipelineSteps = computed(() => {
  const nodeMap = {}
  for (const n of liveNodes.value) nodeMap[n.node_name] = n.status

  return PIPELINE_NODES.map(p => {
    const s = nodeMap[p.key]
    let state = 'pending'
    if (s === 'completed')                    state = 'done'
    else if (s === 'skipped')                 state = 'skipped'
    else if (s === 'in_progress')             state = 'active'
    else if (s === 'failed')                  state = 'fail'
    else if (s === 'cancelled')               state = 'cancelled'
    return { ...p, state }
  })
})

// Calculate overall progress based on completed nodes over total nodes
const progressFromNodes = computed(() => {
  if (!liveNodes.value.length) return progress.value
  if (phase.value === 'failed' || phase.value === 'cancelled') {
    return Math.max(0, Math.min(100, Number(progress.value) >= 0 ? Number(progress.value) : 0))
  }
  const done = liveNodes.value.filter(n =>
    n.status === 'completed' || n.status === 'skipped'
  ).length
  const nodeProgress = Math.round((done / PIPELINE_NODES.length) * 100)
  // Use the backend's granular progress while a node is active; otherwise
  // the UI remains frozen at the last completed-node boundary (for example 83%).
  return Math.min(100, Math.max(nodeProgress, Number(progress.value) || 0))
})

const workflowHeaderTitle = computed(() => {
  if (phase.value === 'done') return 'Workflow completed'
  if (phase.value === 'cancelled') return 'Workflow cancelled'
  if (phase.value === 'failed') return 'Workflow failed'
  return 'Processing workflow'
})

function applyBackendTelemetry(data) {
  applySkillTelemetry(data)
  if (data?.token_usage) {
    tokenUsage.value = {
      input_tokens: data.token_usage.input_tokens || 0,
      output_tokens: data.token_usage.output_tokens || 0,
      total_tokens: data.token_usage.total_tokens || 0,
      cache_creation_input_tokens: data.token_usage.cache_creation_input_tokens || 0,
      cache_read_input_tokens: data.token_usage.cache_read_input_tokens || 0,
    }
  }
  if (data?.cli_activity) {
    cliActivity.kind = data.cli_activity.kind || ''
    cliActivity.message = data.cli_activity.message || ''
    cliActivity.updated_at = data.cli_activity.updated_at || ''
  }
  if (Array.isArray(data?.details?.skill_names)) {
    coverageSkillNames.value = data.details.skill_names
  }
  if (Array.isArray(data?.result?.coverage_skill_names)) {
    coverageSkillNames.value = data.result.coverage_skill_names
  }
}

function applySkillTelemetry(data) {
  const traces = data?.result?.skill_runtime ?? data?.details?.skill_runtime
  if (Array.isArray(traces)) skillRuntime.value = traces
}

const SUMMARY_SECTION_TITLES = [
  'Conclusion',
  'Generated artifacts status',
  'Quality / risk signal',
  'Recommendation',
]

const cliSummarySections = computed(() => {
  const summary = result.value?.cli_summary?.summary || ''
  const sections = SUMMARY_SECTION_TITLES.map(title => ({ title, content: '' }))
  const headingPattern = /^###\s+(.+?)\s*$/gm
  const matches = [...summary.matchAll(headingPattern)]

  for (let i = 0; i < matches.length; i++) {
    const title = matches[i][1].trim()
    const section = sections.find(item => item.title.toLowerCase() === title.toLowerCase())
    if (!section) continue
    const start = matches[i].index + matches[i][0].length
    const end = i + 1 < matches.length ? matches[i + 1].index : summary.length
    section.content = summary.slice(start, end).trim()
  }

  if (!sections.some(section => section.content) && summary.trim()) {
    sections[0].content = summary.trim()
  }

  return sections.map(section => ({
    ...section,
    content: section.content || buildSummaryFallback(section.title),
  }))
})

function buildSummaryFallback(title) {
  if (title === 'Conclusion' && result.value?.cli_summary?.summary?.trim()) {
    return result.value.cli_summary.summary.trim()
  }
  return 'No CLI-generated content was provided for this section.'
}

// Recompute the coverage gate from the displayed metrics instead of trusting
// a potentially stale flag persisted by an older task record. This keeps
// reopened tasks honest when backend gate rules evolve.
const coverageTargetMet = computed(() => {
  const summary = result.value?.cli_summary || {}
  const coverage = summary.coverage || {}
  const report = result.value?.coverage_report || {}
  const line = Number(coverage.line ?? report.line_coverage)
  const lineTarget = Number(coverage.line_target ?? 90)
  const checks = []

  if (Number.isFinite(line) && Number.isFinite(lineTarget)) {
    checks.push(line >= lineTarget)
  }

  for (const metric of ['branch', 'function']) {
    const reportKey = `${metric}_coverage`
    const value = Object.prototype.hasOwnProperty.call(coverage, metric)
      ? coverage[metric]
      : report[reportKey]
    const target = Number(coverage[`${metric}_target`] ?? 80)
    // null means the source has no applicable metric, so it must not fail.
    if (value !== null && value !== undefined && Number.isFinite(Number(value)) && Number.isFinite(target)) {
      checks.push(Number(value) >= target)
    }
  }

  if (checks.length) return checks.every(Boolean)
  return Boolean(summary.result?.coverage_met)
})

// Keep issue details accurate for results restored from the browser's local
// history. Those records can predate the backend's structured issue updates.
const cliSummaryIssues = computed(() => {
  const summary = result.value?.cli_summary || {}
  const coverage = summary.coverage || {}
  const report = result.value?.coverage_report || {}
  const issues = [...(summary.issues || [])]
  const addIssue = (message) => {
    if (message && !issues.includes(message)) issues.push(message)
  }

  const failedCases = result.value?.failed_cases || []
  const testCount = Number(result.value?.test_count || 0)
  const passedCount = Number(result.value?.passed_count || 0)
  const failedCount = Math.max(failedCases.length, testCount - passedCount)
  if (failedCount > 0) {
    addIssue(`${failedCount} test${failedCount === 1 ? '' : 's'} failed`)
  }

  const line = Number(coverage.line ?? report.line_coverage)
  const lineTarget = Number(coverage.line_target ?? 90)
  if (Number.isFinite(line) && Number.isFinite(lineTarget) && line < lineTarget) {
    addIssue(`Line coverage ${line.toFixed(1)}% below target ${lineTarget.toFixed(1)}%`)
  }
  for (const metric of ['branch', 'function']) {
    const value = Object.prototype.hasOwnProperty.call(coverage, metric)
      ? coverage[metric]
      : report[`${metric}_coverage`]
    const target = Number(coverage[`${metric}_target`] ?? 80)
    if (value === null || value === undefined || !Number.isFinite(Number(value)) || !Number.isFinite(target)) continue
    if (Number(value) < target) {
      const label = metric === 'branch' ? 'Branch' : 'Function'
      addIssue(`${label} coverage ${Number(value).toFixed(1)}% below target ${target.toFixed(1)}%`)
    }
  }
  return issues
})

const parsedEntries = computed(() => {
  const files = result.value?.test_files
  if (files?.length) {
    return files.map(f => [f.filename, f.content]).filter(([, c]) => c)
  }
  return Object.entries(result.value?.parsed_content || {}).filter(([, v]) => v)
})

const coverageClass = computed(() => {
  const cov = result.value?.final_coverage || 0
  if (cov >= 90) return 'ok'
  if (cov >= 70) return 'warn'
  return 'fail'
})

// SVG donut: circumference-based stroke-dashoffset
function donutStyle(pct, circumference) {
  const offset = circumference - (pct / 100) * circumference
  return {
    strokeDasharray:  circumference,
    strokeDashoffset: offset,
    transition: 'stroke-dashoffset 1s ease',
  }
}

// Format token count with K/M suffix
function formatTokenCount(count) {
  if (count >= 1000000) {
    return (count / 1000000).toFixed(1) + 'M'
  } else if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'K'
  }
  return count.toString()
}

// Format token count in K for detailed display (more precise)
function formatTokenCountInK(count) {
  if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'K'
  }
  return count.toString()
}

function formatDuration(totalSeconds) {
  const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0))
  const days = Math.floor(seconds / 86400)
  const hours = Math.floor((seconds % 86400) / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const remainder = seconds % 60

  if (days > 0) return `${days}d ${hours}h ${minutes}m`
  if (hours > 0) return `${hours}h ${minutes}m ${remainder}s`
  if (minutes > 0) return `${minutes}m ${remainder}s`
  return `${remainder}s`
}

// Calculate total cost based on Claude Sonnet 4.6 pricing
function calculateCost(tokenUsage) {
  if (!tokenUsage) return 0

  // Pricing: per 1 million tokens
  const PRICE_INPUT = 3.0        // $3 / 1M tokens
  const PRICE_OUTPUT = 15.0      // $15 / 1M tokens
  const PRICE_CACHE_READ = 0.30  // $0.30 / 1M tokens
  const PRICE_CACHE_WRITE = 3.75 // $3.75 / 1M tokens

  const inputCost = (tokenUsage.input_tokens || 0) * PRICE_INPUT / 1000000
  const outputCost = (tokenUsage.output_tokens || 0) * PRICE_OUTPUT / 1000000
  const cacheReadCost = (tokenUsage.cache_read_input_tokens || 0) * PRICE_CACHE_READ / 1000000
  const cacheWriteCost = (tokenUsage.cache_creation_input_tokens || 0) * PRICE_CACHE_WRITE / 1000000

  return inputCost + outputCost + cacheReadCost + cacheWriteCost
}

// Format cost in dollars
function formatCost(cost) {
  if (cost >= 1) {
    return '$' + cost.toFixed(2)
  } else if (cost >= 0.01) {
    return '$' + cost.toFixed(3)
  } else if (cost > 0) {
    return '$' + cost.toFixed(4)
  }
  return '$0.00'
}

// Mini donut metrics (branch + function)
// When value is 0 but line_coverage > 0, the data was not collected — show "N/A"
const miniMetrics = computed(() => {
  const cr = result.value?.coverage_report
  if (!cr) return []
  const lineCov = cr.line_coverage || 0
  const branchTotal = Number(cr.branches_total)
  const functionTotal = Number(cr.functions_total)
  const branchCountAvailable = cr.branches_total !== undefined && Number.isFinite(branchTotal)
  const functionCountAvailable = cr.functions_total !== undefined && Number.isFinite(functionTotal)
  return [
    {
      key: 'branch', name: 'Branch',
      val: cr.branch_coverage || 0,
      na: branchCountAvailable ? branchTotal === 0 : cr.branch_coverage === 0 && lineCov > 0,
      c1: '#6366f1', c2: '#a5b4fc',
    },
    {
      key: 'func', name: 'Function',
      val: cr.function_coverage || 0,
      na: functionCountAvailable ? functionTotal === 0 : cr.function_coverage === 0 && lineCov > 0,
      c1: '#0ea5e9', c2: '#7dd3fc',
    },
  ]
})

// Calculate test pass rate percentage
function getTestPassRate(result) {
  const total = result?.test_count || 0
  const passed = result?.passed_count || 0
  if (total === 0) return 0
  return Math.round((passed / total) * 100)
}

// Get test pass rate CSS class based on percentage
function getTestPassClass(result) {
  const rate = getTestPassRate(result)
  if (rate === 100) return 'kpi-green'
  if (rate >= 80) return 'kpi-amber'
  return 'kpi-red'
}

// File extension badge helpers
function extLabel(filename) {
  const m = filename.match(/\.(\w+)$/)
  return m ? m[1].toUpperCase() : 'TXT'
}
function extClass(filename) {
  if (filename.endsWith('.cpp') || filename.endsWith('.cxx')) return 'ext-cpp'
  if (filename.endsWith('.h') || filename.endsWith('.hpp'))   return 'ext-h'
  if (filename.endsWith('.c'))                                return 'ext-c'
  return 'ext-other'
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function fmtSize(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

function shortPath(p) {
  return p.replace(/\\/g, '/').split('/').slice(-2).join('/')
}

const parsedLabels = {
  test_impl:   'tc-driver-<module>.cpp',
  test_header: 'tc-driver-<module>.h',
  mock_impl:   'mock-hal-<module>.cpp',
  mock_header: 'mock-hal-<module>.h',
}
// The key may be a real filename from test_files or a parsed_content key
function parsedLabel(key) {
  // If the key already looks like a filename with an extension, use it directly
  if (key.includes('.')) return key
  return parsedLabels[key] || key
}

function syncTaskTitle(file) {
  emit('task-updated', {
    title: file?.name || 'New Task',
  })
}

// ── File handling ─────────────────────────────────────────────────────────────

// Route the picker synchronously so browser hosts retain the user's activation.
async function selectFileFromLocal() {
  return routeSourceFilePicker(
    window.location.hostname,
    selectFileFromLocalService,
    () => fileInputRef.value?.click(),
  )
}

async function selectFileFromLocalService() {
  selectingFile.value = true
  console.log('[DEBUG] selectFileFromLocal called')
  try {
    const response = await fetch(`${LOCAL_SERVICE_URL}/select-file`, {
      method: 'POST',
    })
    const data = await response.json()
    console.log('[DEBUG] Local service response:', data)

    if (data.success) {
      // Validate the file extension
      const allowedExts = ['.c', '.h', '.app', '.cpp']
      const ext = (data.name || '').substring(data.name.lastIndexOf('.')).toLowerCase()
      if (!allowedExts.includes(ext)) {
        fileError.value = `Unsupported file type "${ext}". Please select .c, .h, .app, or .cpp files.`
        return
      }

      fileError.value = ''
      // Clear the folder file list
      sourceFiles.value = []

      // Use the file metadata returned by the local service directly
      selectedFile.value = {
        file: null,  // Read the file content locally during generation
        name: data.name,
        path: data.path,
        relativePath: data.name,
        size: 0,
        fullPath: data.path,
      }

      // Pass the absolute source file path as outputDir because the agent needs the full file path
      outputDir.value = data.path || ''

      // Save the project root directory, which is the file's parent directory
      if (data.directory) {
        const normalizedDir = data.directory.replace(/\\/g, '/')
        detectedProjectRoot.value = normalizedDir
        lastProjectRoot.value = normalizedDir
        localStorage.setItem(PROJECT_ROOT_KEY, normalizedDir)
      }

      // Auto-detect project root using backend API (refine the detection)
      if (selectedFile.value.fullPath) {
        setTimeout(() => detectProjectRoot(), 100)
      }

      console.log('[DEBUG] Selected file set:', selectedFile.value)
      console.log('[DEBUG] Output dir set:', outputDir.value)
      ElMessage.success(`Selected: ${data.name}`)
      syncTaskTitle(selectedFile.value)
    } else {
      console.log('[DEBUG] Selection failed or cancelled:', data.error)
      if (data.error && !isSelectionCanceled(data.error)) {
        ElMessage.warning(data.error || 'Failed to select file')
      }
    }
  } catch (error) {
    console.error('[DEBUG] Local service error:', error)
    ElMessage.error('Local path selection is unavailable. Use Upload File to choose the source.')
  } finally {
    selectingFile.value = false
  }
}

// Select a folder through the local service
async function selectFolderFromLocal() {
  selectingFile.value = true
  try {
    const response = await fetch(`${LOCAL_SERVICE_URL}/select-folder`, {
      method: 'POST',
    })
    const data = await response.json()

    if (data.success && data.files) {
      // Save the file list
      sourceFiles.value = data.files.map(f => ({
        name: f.name,
        path: f.path,
        relativePath: f.relative_path,
        extension: f.extension,
        isFile: f.is_file,
        // Note: the local service returns file metadata without File objects, so follow-up handling is required
        file: null,
      }))

      // Save the project root directory
      lastProjectRoot.value = data.path
      localStorage.setItem(PROJECT_ROOT_KEY, data.path)

      // Clear the previous selection
      selectedFile.value = null
      outputDir.value = ''

      console.log(`[DEBUG] Folder selected: ${data.path}, ${data.files.length} files`)
      ElMessage.success(`Folder selected. ${data.files.length} source files found`)
    } else {
      if (!isSelectionCanceled(data.error)) {
        ElMessage.warning(data.error || 'Failed to select folder')
      }
    }
  } catch (error) {
    console.error('[DEBUG] Local service error:', error)
    // Fall back to the browser folder picker if the local service is unavailable
    folderInputRef.value?.click()
  } finally {
    selectingFile.value = false
  }
}

// Handle folder selection in the browser as a fallback
function onFolderSelect(e) {
  const files = Array.from(e.target.files)
  const sourceExtensions = ['.c', '.cpp', '.h', '.hpp', '.cxx', '.cc']

  // Filter source files
  sourceFiles.value = files
    .filter(f => sourceExtensions.some(ext => f.name.toLowerCase().endsWith(ext)))
    .map(f => ({
      file: f,
      name: f.name,
      path: f.webkitRelativePath,
      relativePath: f.webkitRelativePath,
      size: f.size,
    }))
    .sort((a, b) => a.relativePath.localeCompare(b.relativePath))

  // Build the file tree structure
  buildFileTree()

  // Clear the previously selected file
  selectedFile.value = null

  console.log(`[DEBUG] Folder selected, found ${sourceFiles.value.length} source files`)
}

// Build the file tree structure for display
function buildFileTree() {
  const tree = []
  const addedPaths = new Set()

  for (const file of sourceFiles.value) {
    const parts = file.relativePath.split('/')
    let currentPath = ''

    for (let i = 0; i < parts.length; i++) {
      const part = parts[i]
      currentPath = currentPath ? `${currentPath}/${part}` : part

      if (!addedPaths.has(currentPath)) {
        addedPaths.add(currentPath)
        const isFile = i === parts.length - 1
        tree.push({
          name: part,
          path: currentPath,
          isFile,
          depth: i,
        })
      }
    }
  }

  fileTree.value = tree
}

// Select a file
function selectFile(file) {
  // Ensure fullPath is set correctly
  selectedFile.value = {
    ...file,
    fullPath: file.path, // Use the full path
  }
  console.log('[DEBUG] Selected file:', file.relativePath, 'fullPath:', file.path)

  // Auto-fill the output directory
  autoFillOutputDir(file)

  // Auto-detect project root
  if (file.path) {
    setTimeout(() => detectProjectRoot(), 100)
  }
}

// Auto-fill the output path using the file's full path
function autoFillOutputDir(file) {
  console.log('[DEBUG] autoFillOutputDir called')
  console.log('[DEBUG] file.path:', file.path)

  // If the file already has a full path from the local service, use it directly
  if (file.path) {
    outputDir.value = file.path.replace(/\\/g, '/')
    console.log('[DEBUG] Output dir (full file path):', outputDir.value)
    return
  }

  // Build the full path from the relative path and project root
  const relativePath = file.relativePath || file.relative_path || ''
  // Use detected project root if available, otherwise fallback to history
  const root = detectedProjectRoot.value || lastProjectRoot.value
  if (root && relativePath) {
    outputDir.value = `${root}/${relativePath}`.replace(/\\/g, '/')
    console.log('[DEBUG] Output dir (detected root + relative):', outputDir.value)
  } else {
    outputDir.value = relativePath.replace(/\\/g, '/')
    console.log('[DEBUG] Output dir (relative only):', outputDir.value)
  }
}

// Auto-detect project root using backend API
async function detectProjectRoot() {
  if (!selectedFile.value || !selectedFile.value.fullPath) {
    ElMessage.warning('Please select a file first')
    return
  }

  const fullPath = selectedFile.value.fullPath
  console.log('[DEBUG] Detecting project root for:', fullPath)

  try {
    const response = await fetch('/api/v1/project/detect-project-root', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source_path: fullPath }),
    })

    const data = await response.json()
    console.log('[DEBUG] Project detection result:', data)

    if (data.success && data.detected_root) {
      const normalizedRoot = data.detected_root.replace(/\\/g, '/')
      detectedProjectRoot.value = normalizedRoot
      lastProjectRoot.value = normalizedRoot
      localStorage.setItem(PROJECT_ROOT_KEY, normalizedRoot)
      console.log('[DEBUG] Project root refined by backend:', normalizedRoot)

      // Re-auto-fill output directory with the correct project root
      if (selectedFile.value && selectedFile.value.relativePath) {
        autoFillOutputDir(selectedFile.value)
      }
    } else {
      console.log('[DEBUG] Backend detection failed, keeping local service result:', detectedProjectRoot.value)
      // Keep the value from local service (data.directory), don't clear it
    }
  } catch (error) {
    console.error('[DEBUG] Failed to detect project root:', error)
    console.log('[DEBUG] Keeping local service result:', detectedProjectRoot.value)
    // Keep the value from local service, don't show error to user
  }
}

// Auto-fill from the previously used path
function autoFillFromHistory() {
  if (!selectedFile.value || !lastProjectRoot.value) return

  const relativePath = selectedFile.value.relativePath
  const parts = relativePath.split('/')
  const dirParts = parts.slice(0, -1)
  const relativeDir = dirParts.join('/')

  if (relativeDir) {
    outputDir.value = `${lastProjectRoot.value}/${relativeDir}`
  } else {
    outputDir.value = lastProjectRoot.value
  }
}

// Save the output directory to localStorage to remember the user's project root
watch(outputDir, (newVal) => {
  if (newVal && selectedFile.value) {
    // Infer the project root from the output directory
    const relativePath = selectedFile.value.relativePath
    const parts = relativePath.split('/')
    const dirParts = parts.slice(0, -1)
    const relativeDir = dirParts.join('/')

    if (relativeDir && newVal.endsWith(relativeDir)) {
      // Extract the project root
      const root = newVal.slice(0, -relativeDir.length - 1)
      if (root) {
        lastProjectRoot.value = root
        localStorage.setItem(PROJECT_ROOT_KEY, root)
      }
    } else if (!relativeDir) {
      // If the file is in the root directory, the output directory is the project root
      lastProjectRoot.value = newVal
      localStorage.setItem(PROJECT_ROOT_KEY, newVal)
    }
  }
})

// Watch detectedProjectRoot changes and save to localStorage
watch(detectedProjectRoot, (newVal) => {
  if (newVal) {
    lastProjectRoot.value = newVal
    localStorage.setItem(PROJECT_ROOT_KEY, newVal)
    if (selectedFile.value && !selectedFile.value.fullPath) {
      outputDir.value = newVal
    }
    console.log('[DEBUG] Project root updated by user:', newVal)
  }
})

function onFileChange(e) {
  const f = e.target.files[0]
  if (f) {
    sourceFiles.value = []
    fileError.value = ''
    selectedFile.value = {
      file: f,
      name: f.name,
      path: f.name,
      relativePath: f.name,
      size: f.size,
      fullPath: null,
    }
    detectedProjectRoot.value = lastProjectRoot.value
    outputDir.value = lastProjectRoot.value
    syncTaskTitle(selectedFile.value)
  }
}

// Handle drag-and-drop file upload
async function onDropFile(e) {
  isDragOver.value = false
  const files = e.dataTransfer.files
  if (files.length === 0) return

  const file = files[0]
  const validExtensions = ['.c', '.h', '.cpp', '.hpp', '.cxx', '.cc']
  const ext = '.' + file.name.split('.').pop().toLowerCase()

  if (!validExtensions.includes(ext)) {
    ElMessage.warning('Please upload a C/C++ source file (.c, .h, .cpp, .hpp)')
    return
  }

  // Set the file metadata first
  selectedFile.value = {
    file: file,
    name: file.name,
    path: file.name,
    relativePath: file.name,
    size: file.size,
    fullPath: null,
  }

  console.log('[DEBUG] File dropped:', file.name)

  // Then open a directory picker so the user can choose the output location
  await selectOutputDirectory()
}

// Select the output directory through the local service
async function selectOutputDirectory() {
  try {
    // Call the local service folder selection API
    const response = await fetch(`${LOCAL_SERVICE_URL}/select-folder`, {
      method: 'POST',
    })
    const data = await response.json()

    if (data.success && data.path) {
      // The user selected a directory, so build the full path
      const dirPath = data.path.replace(/\\/g, '/')
      outputDir.value = `${dirPath}/${selectedFile.value.name}`

      // Update the selected file metadata
      selectedFile.value.path = outputDir.value
      selectedFile.value.fullPath = outputDir.value

      console.log('[DEBUG] Output path set:', outputDir.value)
      ElMessage.success(`Output path: ${outputDir.value}`)
    } else {
      // The user cancelled the selection
      if (data.error && !isSelectionCanceled(data.error)) {
        ElMessage.warning(data.error)
      } else {
        // The user cancelled, so clear the state
        selectedFile.value = null
        outputDir.value = ''
      }
    }
  } catch (error) {
    console.error('[DEBUG] Local service error:', error)
    ElMessage.error('Local service is not running. Please enter the output path manually')
  }
}

// Clear the selected file
function clearSelectedFile() {
  selectedFile.value = null
  outputDir.value = ''
  sourceFiles.value = []
  fileError.value = ''
  if (fileInputRef.value) fileInputRef.value.value = ''
  syncTaskTitle(null)
  // Clear the persisted file snapshot to prevent it from being restored after refresh
  saveTaskState()
}

// ── Preview helpers ───────────────────────────────────────────────────────────
async function togglePreview(key, source) {
  const set = new Set(expanded.value)
  if (set.has(key)) {
    set.delete(key)
  } else {
    set.add(key)
    if (source === 'disk' && !fileContents[key]) {
      fileContents[key] = 'Loading...'
      try {
        const res = await fetch(`/api/v1/files/content?path=${encodeURIComponent(key)}`)
        fileContents[key] = res.ok ? await res.text() : '(content unavailable)'
      } catch {
        fileContents[key] = '(load failed)'
      }
    }
    if (source === 'mem') {
      // content is already in result.parsed_content — no fetch needed
    }
  }
  expanded.value = set
}

async function copyText(text, key) {
  await navigator.clipboard.writeText(text)
  copiedMap[key] = true
  setTimeout(() => { copiedMap[key] = false }, 2000)
}

function downloadFile(path) {
  const a = document.createElement('a')
  a.href = `/api/v1/files/download?path=${encodeURIComponent(path)}`
  a.download = path.replace(/\\/g, '/').split('/').pop()
  a.click()
}

function downloadMemFile(key, code) {
  // The key may be a real filename or a parsed_content key such as test_impl
  const filename = key.includes('.')
    ? key
    : (parsedLabels[key]?.replace('<module>', selectedFile.value?.name.replace(/\.[^.]+$/, '') || 'module') || key)
  const blob = new Blob([code], { type: 'text/plain' })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  URL.revokeObjectURL(url)
}

function getAuthHeaders() {
  const token = localStorage.getItem('token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

// ── CLI log preview / download ────────────────────────────────────────────────
async function toggleCliLogPreview() {
  showCliLog.value = !showCliLog.value
  if (showCliLog.value && !cliLogContent.value) {
    try {
      const downloadUrl = result.value?.cli_log_artifact?.download_url
      if (!downloadUrl) {
        cliLogContent.value = '(Log URL not available)'
        return
      }
      const res = await fetch(downloadUrl, {
        headers: getAuthHeaders(),
      })
      if (res.ok) {
        cliLogContent.value = await res.text()
      } else {
        cliLogContent.value = `(Failed to load log: HTTP ${res.status})`
      }
    } catch (err) {
      cliLogContent.value = `(Failed to load log: ${err.message})`
    }
  }
}

async function downloadCliLog() {
  const artifact = result.value?.cli_log_artifact
  if (!artifact?.available || !artifact?.download_url) return

  try {
    const res = await fetch(artifact.download_url, {
      headers: getAuthHeaders(),
    })
    if (!res.ok) {
      cliLogContent.value = `(Failed to download log: HTTP ${res.status})`
      showCliLog.value = true
      return
    }
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = artifact.filename || 'claude-cli.md'
    a.click()
    URL.revokeObjectURL(url)
  } catch (err) {
    cliLogContent.value = `(Failed to download log: ${err.message})`
    showCliLog.value = true
  }
}

// ── Mock data helpers ─────────────────────────────────────────────────────────
function rnd(min, max) { return Math.random() * (max - min) + min }

function buildMockTestCode(filename) {
  const mod = filename.replace(/\.[^.]+$/, '')
  return `#include <gtest/gtest.h>
#include "${mod}.h"

// ─── Test Suite: ${mod} ───────────────────────────────────────────────────

class ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test : public ::testing::Test {
protected:
  void SetUp() override {
    // Initialize test fixtures
  }
  void TearDown() override {
    // Clean up resources
  }
};

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, InitializationSucceeds) {
  EXPECT_TRUE(true) << "Module initialization should succeed";
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, DefaultStateIsValid) {
  int state = 0;
  EXPECT_GE(state, 0) << "Default state should be non-negative";
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, ProcessInputReturnsExpected) {
  const int input  = 42;
  const int expect = 42;
  EXPECT_EQ(input, expect) << "Process should return correct value";
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, BoundaryValueLow) {
  EXPECT_NO_THROW({
    volatile int x = 0;
    (void)x;
  });
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, BoundaryValueHigh) {
  EXPECT_NO_THROW({
    volatile int x = 0xFFFF;
    (void)x;
  });
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, ErrorHandlingNullInput) {
  EXPECT_FALSE(false) << "Null input should be handled gracefully";
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, MultipleCallsAreIdempotent) {
  bool result1 = true;
  bool result2 = true;
  EXPECT_EQ(result1, result2) << "Multiple calls should return same result";
}

TEST_F(${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test, StateTransitionValid) {
  int state = 0;
  state++;
  EXPECT_EQ(state, 1) << "State transition should increment correctly";
}

// ─── Parameterized Tests ──────────────────────────────────────────────────────

struct ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Param {
  int input;
  int expected;
};

class ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest
    : public ::testing::TestWithParam<${mod.replace(/[^a-zA-Z0-9]/g, '_')}Param> {};

TEST_P(${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest, ParameterizedInput) {
  auto p = GetParam();
  EXPECT_GE(p.expected, 0);
}

INSTANTIATE_TEST_SUITE_P(
  ValidInputs,
  ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest,
  ::testing::Values(
    ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Param{0, 0},
    ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Param{1, 1},
    ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Param{255, 255}
  )
);

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
`
}

function buildMockTestReport(mod, cov) {
  const passed = 11
  const total  = 11
  return `[==========] Running ${total} tests from 2 test suites.
[----------] Global test environment set-up.
[----------] 8 tests from ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.InitializationSucceeds
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.InitializationSucceeds (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.DefaultStateIsValid
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.DefaultStateIsValid (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.ProcessInputReturnsExpected
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.ProcessInputReturnsExpected (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.BoundaryValueLow
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.BoundaryValueLow (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.BoundaryValueHigh
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.BoundaryValueHigh (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.ErrorHandlingNullInput
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.ErrorHandlingNullInput (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.MultipleCallsAreIdempotent
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.MultipleCallsAreIdempotent (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.StateTransitionValid
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test.StateTransitionValid (0 ms)
[----------] 8 tests from ${mod.replace(/[^a-zA-Z0-9]/g, '_')}Test (2 ms total)
[----------] 3 tests from ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest/ValidInputs.ParameterizedInput/0
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest/ValidInputs.ParameterizedInput/0 (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest/ValidInputs.ParameterizedInput/1
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest/ValidInputs.ParameterizedInput/1 (0 ms)
[ RUN      ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest/ValidInputs.ParameterizedInput/2
[       OK ] ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest/ValidInputs.ParameterizedInput/2 (0 ms)
[----------] 3 tests from ${mod.replace(/[^a-zA-Z0-9]/g, '_')}ParamTest (1 ms total)
[----------] Global test environment tear-down
[==========] ${total} tests from 2 test suites ran. (4 ms total)
[  PASSED  ] ${passed} tests.

LCOV coverage summary:
  Lines:     ${cov.line.toFixed(1)}% (${Math.round(cov.line * 0.8)} / ${Math.round(cov.line * 0.8 / (cov.line/100))} lines)
  Branches:  ${cov.branch.toFixed(1)}%
  Functions: ${cov.func.toFixed(1)}%
`
}

function buildMockResult(filename) {
  const mod        = filename.replace(/\.[^.]+$/, '')
  const lineCov    = rnd(90.2, 95.0)
  const branchCov  = rnd(90.0, 94.5)
  const funcCov    = rnd(91.0, 95.0)
  const testCode   = buildMockTestCode(filename)
  const reportText = buildMockTestReport(mod, { line: lineCov, branch: branchCov, func: funcCov })

  return {
    compile_success:  true,
    test_count:       11,
    final_coverage:   lineCov,
    layer:            'HAL',
    iteration_count:  2,
    functions_tested: ['init', 'process', 'reset', 'getState', 'setState', 'validate', 'handle_error'],
    test_results:     { passed: 11, total: 11 },
    coverage_report:  {
      line_coverage:     lineCov,
      branch_coverage:   branchCov,
      function_coverage: funcCov,
    },
    test_files: [
      { filename: `tc-${mod}.cpp`,      content: testCode },
      { filename: `tc-${mod}.h`,        content: `#pragma once\n#include "${mod}.h"\n#include <gtest/gtest.h>\n\n// Test declarations for ${mod}\n` },
      { filename: `mock-hal-${mod}.cpp`, content: `#include "mock-hal-${mod}.h"\n\n// Mock HAL implementation for ${mod}\n// Auto-generated by Macode\n\nbool ${mod}_mock_init_called = false;\n\nvoid ${mod}_mock_reset() {\n  ${mod}_mock_init_called = false;\n}\n` },
      { filename: `mock-hal-${mod}.h`,   content: `#pragma once\n#include <stdbool.h>\n\n// Mock HAL header for ${mod}\nextern bool ${mod}_mock_init_called;\nvoid ${mod}_mock_reset();\n` },
    ],
    written_files:   [],
    compile_output:  reportText,
    parsed_content:  null,
  }
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)) }

// ── Polling for real-time updates ──────────────────────────────────────────────
// stopPolling must be component-scoped, not global, to avoid cross-task interference
const stopPolling = ref(null)


function setupPolling(taskId) {
  if (!isCurrentAccount()) return
  let isStale = false
  const originalStop = apiPollTask(taskId, (data) => {
    // Ignore updates if this polling is already for an older task
    if (!isCurrentAccount() || isStale || currentTaskId.value !== taskId) return

    if (data.status === 'connection_retrying') {
      statusMessage.value = data.message
      return
    }

    // Debug: log received data
    console.log('[DEBUG] Poll data received:', JSON.stringify(data, null, 2))

    // Update progress
    if (data.progress !== undefined) progress.value = data.progress
    if (data.current_stage !== undefined) currentStage.value = data.current_stage || ''
    if (data.message) statusMessage.value = data.message
    if (data.elapsed_seconds !== undefined) elapsedSeconds.value = data.elapsed_seconds
    if (data.activity_age_seconds !== undefined) activityAgeSeconds.value = data.activity_age_seconds
    applyRuntimeTelemetry(data)
    if (data.cli_activity?.message) {
      cliActivity.kind = data.cli_activity.kind || ''
      cliActivity.message = data.cli_activity.message
      cliActivity.updated_at = data.cli_activity.updated_at || ''
    }
    const progressDetails = data.details || {}
    applySkillTelemetry(data)
    if (Array.isArray(progressDetails.skill_names)) {
      coverageSkillNames.value = progressDetails.skill_names
    }
    if (data.result?.coverage_skill_names && Array.isArray(data.result.coverage_skill_names)) {
      coverageSkillNames.value = data.result.coverage_skill_names
    }

    // Update token usage
    if (data.token_usage) {
      console.log('[DEBUG] Updating token usage:', data.token_usage)
      tokenUsage.value = {
        input_tokens: data.token_usage.input_tokens || 0,
        output_tokens: data.token_usage.output_tokens || 0,
        total_tokens: data.token_usage.total_tokens || 0,
        cache_creation_input_tokens: data.token_usage.cache_creation_input_tokens || 0,
        cache_read_input_tokens: data.token_usage.cache_read_input_tokens || 0
      }
    } else {
      console.log('[DEBUG] No token_usage in data')
    }

    // Sync node states
    if (data.nodes && Array.isArray(data.nodes)) {
      liveNodes.value = normalizePipelineNodes(data.nodes, data.status)
    }

    if (data.status === 'completed') {
      if (isStale || currentTaskId.value !== taskId) return
      const normalizedResult = normalizeResultPayload(data.result, selectedLayer.value)
      if (!normalizedResult) {
        phase.value = 'failed'
        progress.value = data.progress ?? -1
        taskError.value = 'Workflow completed without a valid result payload.'
        result.value = null
        liveNodes.value = normalizePipelineNodes(data.nodes, 'failed')
        saveTaskState()
        return
      }
      result.value = normalizedResult
      phase.value = 'done'
      currentStage.value = data.current_stage || currentStage.value
      showBuild.value = true
      taskError.value = null
      console.log('[DEBUG] Task completed, phase set to done, result:', result.value)
      console.log('[DEBUG] Current phase:', phase.value, 'result exists:', !!result.value)
      saveTaskState()

      // Sync updates to the task history
      unittestStore.updateTask(taskId, {
        status: 'completed',
        progress: 100,
        result: result.value,
        liveNodes: liveNodes.value,
        currentStage: currentStage.value,
        statusMessage: data.message || 'Completed',
        updatedAt: new Date().toISOString(),
      })
      emit('task-updated', {
        id: taskId,
        status: 'completed',
        progress: 100,
        result: result.value,
        liveNodes: liveNodes.value,
        currentStage: currentStage.value,
        statusMessage: data.message || 'Completed',
        updatedAt: new Date().toISOString(),
      })
    } else if (data.status === 'failed' || data.status === 'cancelled') {
      if (isStale || currentTaskId.value !== taskId) return

      if (data.status === 'failed' && hasPassingUnitTests(data.result)) {
        result.value = normalizeResultPayload(data.result, selectedLayer.value)
        phase.value = 'done'
        progress.value = 100
        taskError.value = null
        saveTaskState()
        unittestStore.updateTask(taskId, {
          status: 'completed', progress: 100, result: result.value,
          liveNodes: liveNodes.value, currentStage: currentStage.value,
          statusMessage: 'Unit tests passed; coverage optimization is pending',
          error: null, updatedAt: new Date().toISOString(),
        })
        return
      }

      // Check if this is an AWS Profile configuration error
      if (data.profile_error || isAWSProfileConfigError(data.error || data.message)) {
        showAWSProfileConfigError(data.error || data.message)
      }

      phase.value = data.status === 'cancelled' ? 'cancelled' : 'failed'
      currentStage.value = data.current_stage || currentStage.value
      taskError.value = data.error || (data.status === 'cancelled' ? 'Task cancelled by user' : 'Task failed')

      // Parse result data even for failed tasks
      if (data.result) {
        result.value = normalizeResultPayload(data.result, selectedLayer.value)
      }

      saveTaskState()

      // Sync updates to the task history
      unittestStore.updateTask(taskId, {
        status: data.status,
        progress: data.progress ?? -1,
        result: result.value,
        liveNodes: liveNodes.value,
        currentStage: currentStage.value,
        statusMessage: data.message || '',
        error: taskError.value,
        updatedAt: new Date().toISOString(),
      })
      emit('task-updated', {
        id: taskId,
        status: data.status,
        progress: data.progress ?? -1,
        result: result.value,
        liveNodes: liveNodes.value,
        currentStage: currentStage.value,
        statusMessage: data.message || '',
        error: taskError.value,
        updatedAt: new Date().toISOString(),
      })
    } else {
      if (isStale || currentTaskId.value !== taskId) return
      // Also sync progress to history while the task is running
      unittestStore.updateTask(taskId, {
        status: 'running',
        progress: data.progress || 0,
        liveNodes: liveNodes.value,
        currentStage: currentStage.value,
        statusMessage: data.message || '',
        updatedAt: new Date().toISOString(),
      })
    }
  }, 1500)

  // Wrap stop to also mark as stale
  const wrappedStop = () => {
    isStale = true
    originalStop()
  }

  stopPolling.value = wrappedStop
}

async function syncTaskFromBackend(taskId, fallbackTask = null) {
  if (!isCurrentAccount() || !taskId || taskId.startsWith('__temp_')) return

  try {
    const data = await apiGetTask(taskId)
    if (!isCurrentAccount() || currentTaskId.value !== taskId) return

    if (stopPolling.value) {
      stopPolling.value()
      stopPolling.value = null
    }

    progress.value = data.progress ?? fallbackTask?.progress ?? 0
    currentStage.value = data.current_stage || fallbackTask?.currentStage || ''
    statusMessage.value = data.message || fallbackTask?.statusMessage || ''
    elapsedSeconds.value = data.elapsed_seconds ?? elapsedSeconds.value
    activityAgeSeconds.value = data.activity_age_seconds ?? activityAgeSeconds.value
    applyRuntimeTelemetry(data)
    liveNodes.value = normalizePipelineNodes(
      Array.isArray(data.nodes) ? data.nodes : fallbackTask?.liveNodes,
      data.status || fallbackTask?.status || 'running',
    )
    result.value = normalizeResultPayload(
      data.result || fallbackTask?.result,
      selectedLayer.value,
    )
    taskError.value = data.error || null
    applyBackendTelemetry(data)

    if (data.status === 'running') {
      phase.value = 'running'
      setupPolling(taskId)
    } else if (data.status === 'completed') {
      phase.value = 'done'
      progress.value = 100
      taskError.value = null
      showBuild.value = true
    } else if (data.status === 'failed' || data.status === 'cancelled') {
      phase.value = data.status === 'cancelled' ? 'cancelled' : 'failed'
      progress.value = data.progress ?? -1
      taskError.value = data.error || (data.status === 'cancelled' ? 'Task cancelled by user' : 'Task failed')
      showBuild.value = true
    } else {
      phase.value = 'running'
      setupPolling(taskId)
    }

    unittestStore.updateTask(taskId, {
      status: data.status,
      progress: data.progress ?? fallbackTask?.progress ?? 0,
      result: data.result || fallbackTask?.result || null,
      liveNodes: liveNodes.value,
      currentStage: data.current_stage || fallbackTask?.currentStage || '',
      statusMessage: data.message || fallbackTask?.statusMessage || '',
      error: data.error || null,
      updatedAt: new Date().toISOString(),
    })
    saveTaskState()
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== taskId) return
    // Keep a locally cached terminal result visible if the backend is temporarily unavailable.
    if (fallbackTask && ['completed', 'failed', 'cancelled'].includes(fallbackTask.status)) {
      const passingLegacyTask = fallbackTask.status === 'failed' && hasPassingUnitTests(fallbackTask.result)
      phase.value = passingLegacyTask || fallbackTask.status === 'completed'
        ? 'done'
        : (fallbackTask.status === 'cancelled' ? 'cancelled' : 'failed')
      progress.value = passingLegacyTask || fallbackTask.status === 'completed'
        ? 100
        : (fallbackTask.progress ?? -1)
      statusMessage.value = passingLegacyTask
        ? 'Unit tests passed; coverage optimization is pending'
        : (fallbackTask.statusMessage || '')
      result.value = normalizeResultPayload(fallbackTask.result, selectedLayer.value)
      liveNodes.value = normalizePipelineNodes(
        fallbackTask.liveNodes,
        passingLegacyTask ? 'completed' : (fallbackTask.status || 'completed'),
      )
      currentStage.value = fallbackTask.currentStage || ''
      taskError.value = passingLegacyTask ? null : (fallbackTask.error || null)
      showBuild.value = true
      saveTaskState()
      return
    }
    console.warn('Task synchronization failed:', error)
  }
}

// Generate button click handler - checks AWS credentials only if Bedrock is the default provider
async function handleGenerateClick() {
  if (!selectedFile.value || (!selectedFile.value.file && !outputDir.value)) {
    ElMessage.warning('Please select a source file first')
    return
  }

  // Directly start generation - backend will handle AWS credential validation
  // If credentials are invalid, backend returns 401 and triggers AWS SSO login modal
  await startGeneration()
}

function isAWSProfileConfigError(message) {
  return message?.includes('AWS_PROFILE_INVALID')
    || message?.includes('AWS_PROFILE not configured')
    || message?.includes('AWS Profile is not configured')
    || message?.includes('not found in ~/.aws/config')
}

function getProfileNameFromError(message) {
  const profileMatch = message?.match(/Profile '([^']+)'/)
  return profileMatch ? profileMatch[1] : ''
}

function showAWSProfileConfigError(message) {
  profileErrorName.value = getProfileNameFromError(message)
  showProfileErrorDialog.value = true
}

// Handle AWS SSO login success
async function handleAWSSSOSuccess() {
  showAWSSSOModal.value = false
  // Don't cache login state - always verify with backend on next generation
  if (pendingRetryFn.value) {
    await pendingRetryFn.value()
    pendingRetryFn.value = null
  }
}

// Handle AWS SSO modal close
function handleAWSSSOClose() {
  showAWSSSOModal.value = false
  pendingRetryFn.value = null
}

// Handle Profile error dialog close
function handleProfileErrorClose() {
  showProfileErrorDialog.value = false
  profileErrorName.value = ''
}

async function startGeneration() {
  if (!isCurrentAccount() || !selectedFile.value || (!selectedFile.value.file && !outputDir.value)) return

  try {
    console.log('[DEBUG] Starting generation:', {
      sourcePath: selectedFile.value.relativePath,
      fullPath: selectedFile.value.fullPath,
      outputDir: outputDir.value,
    })

    // Read the file content from the local service FIRST (before showing pipeline UI)
    let fileToUpload = selectedFile.value.file

    // If there is no File object because the file was selected through the local service, read it from there
    if (!fileToUpload && selectedFile.value.fullPath) {
      // Call the local service to read the file content
      const readResponse = await fetch(`${LOCAL_SERVICE_URL}/read-file`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: selectedFile.value.fullPath }),
      })

      const readData = await readResponse.json()
      if (!isCurrentAccount()) return

      if (!readData.success) {
        throw new Error(readData.error || 'Failed to read file from local service')
      }

      // Convert the file content into a File object
      const blob = new Blob([readData.content], { type: 'text/plain' })
      fileToUpload = new File([blob], selectedFile.value.name, { type: 'text/plain' })

      console.log('[DEBUG] File loaded from local service:', selectedFile.value.name)
    }

    if (!(fileToUpload instanceof Blob)) {
      throw new Error('No valid file selected for upload')
    }

    // Call the actual API using the file content and project root directory
    // Use detectedProjectRoot if available (user may have edited it), otherwise fall back to outputDir
    const projectRoot = detectedProjectRoot.value || outputDir.value
    console.log('[DEBUG] Using project root:', projectRoot)

    const response = await apiGenerateTests(fileToUpload, {
      framework: selectedFramework.value,
      layer: selectedLayer.value,
      coverage: 90,
      iterations: 3,
      enable_mock: true,
      compile_verify: true,
      build_profile: 'auto',
      platform: selectedPlatform.value,
      auto_update_qbs: true,
      output_dir: projectRoot,
      source_paths: selectedFile.value?.fullPath ? [selectedFile.value.fullPath] : [],
    })

    if (!isCurrentAccount()) {
      if (response.task_id) workspaceStore.saveState(AGENT_ID, {
        taskId: response.task_id, phase: 'running', progress: 0,
      })
      return
    }

    if (response.task_id) {
      currentTaskId.value = response.task_id

      const taskTitle = response.meta?.title || selectedFile.value?.name || 'Unnamed Task'
      const initialNodes = resolveInitialPipelineNodes(response.nodes)

      // Notify the parent component to create or update the sidebar task, with Home.vue managing the store centrally
      emit('task-updated', {
        id: response.task_id,
        title: taskTitle,
        status: 'running',
        progress: 0,
        fileMeta: response.meta || null,
        liveNodes: initialNodes,
        currentStage: response.current_stage || '',
      })

      phase.value         = 'running'
      progress.value      = 0
      currentStage.value  = ''
      elapsedSeconds.value = 0
      activityAgeSeconds.value = 0
      businessProgressAgeSeconds.value = 0
      Object.assign(toolFailureSummary, {
        total: 0,
        by_category: {},
        last: null,
        consecutive_count: 0,
        deterministic_loop: false,
        tool_calls: 0,
        business_progress_sequence: 0,
        last_business_progress_at: null
      })
      cliActivity.kind = ''
      cliActivity.message = ''
      cliActivity.updated_at = ''
      coverageSkillNames.value = []
      skillRuntime.value = []
      statusMessage.value = 'Task started, waiting for results...'
      result.value        = null
      taskError.value     = null
      liveNodes.value     = initialNodes
      expanded.value      = new Set()
      showBuild.value     = false
      showCliLog.value    = false
      cliLogContent.value = ''

      // Persist the running state before polling so a fast terminal response cannot be overwritten.
      saveTaskState()
      setupPolling(response.task_id)
    }
  } catch (error) {
    if (!isCurrentAccount()) return
    console.error('API error:', error)

    // Check if this is an AWS authentication error (401)
    // http.js already triggered SSO login in browser, but we also show modal for better UX
    if (error.status === 401 || error.message?.includes('AWS_AUTH_REQUIRED')) {
      console.log('[DEBUG] AWS authentication error detected, showing login modal')
      // Show login modal for better user awareness
      showAWSSSOModal.value = true
      pendingRetryFn.value = startGeneration
      return
    }

    // Check if this is a Profile configuration error
    if (isAWSProfileConfigError(error.message)) {
      showAWSProfileConfigError(error.message)
      return
    }

    phase.value = 'failed'
    taskError.value = error.message || 'Failed to start generation'
    ElMessage.error(error.message || 'Failed to start generation')
    saveTaskState()
  }
}

onUnmounted(() => {
  if (stopPolling.value) {
    stopPolling.value()
    stopPolling.value = null
  }
})

// ── Persist task state ───────────────────────────────────────────────────────────
function saveTaskState() {
  if (!isCurrentAccount()) return
  workspaceStore.saveState(AGENT_ID, {
    taskId: currentTaskId.value,
    phase: phase.value,
    progress: progress.value,
    statusMessage: statusMessage.value,
    elapsedSeconds: elapsedSeconds.value,
    activityAgeSeconds: activityAgeSeconds.value,
    businessProgressAgeSeconds: businessProgressAgeSeconds.value,
    toolFailureSummary: { ...toolFailureSummary },
    tokenUsage: tokenUsage.value,
    cliActivity: { ...cliActivity },
    coverageSkillNames: coverageSkillNames.value,
    skillRuntime: skillRuntime.value,
    result: result.value,
    taskError: taskError.value,
    liveNodes: liveNodes.value,
    currentStage: currentStage.value,
    uploadedFileName: selectedFile.value?.name,
    uploadedFileSize: selectedFile.value?.size,
    selectedFramework: selectedFramework.value,
    selectedLayer: selectedLayer.value,
    selectedPlatform: selectedPlatform.value,
    outputDir: outputDir.value,
    detectedProjectRoot: detectedProjectRoot.value,  // Save user-edited project root
    hasFile: selectedFile.value !== null,
    // Full file snapshot used for refresh restoration
    selectedFileSnapshot: selectedFile.value ? {
      name: selectedFile.value.name,
      path: selectedFile.value.path,
      fullPath: selectedFile.value.fullPath,
      relativePath: selectedFile.value.relativePath,
      size: selectedFile.value.size,
    } : null,
  })
}

function restoreTaskState() {
  const saved = workspaceStore.getState(AGENT_ID)
  if (!saved) return

  currentTaskId.value = saved.taskId || null
  currentStage.value = saved.currentStage || ''
  elapsedSeconds.value = saved.elapsedSeconds || 0
  activityAgeSeconds.value = saved.activityAgeSeconds ?? null
  businessProgressAgeSeconds.value = saved.businessProgressAgeSeconds ?? null
  if (saved.toolFailureSummary) Object.assign(toolFailureSummary, saved.toolFailureSummary)
  if (saved.tokenUsage) tokenUsage.value = { ...tokenUsage.value, ...saved.tokenUsage }
  if (saved.cliActivity) Object.assign(cliActivity, saved.cliActivity)
  if (Array.isArray(saved.coverageSkillNames)) coverageSkillNames.value = saved.coverageSkillNames
  skillRuntime.value = Array.isArray(saved.skillRuntime) ? saved.skillRuntime : []

  // Restore the file snapshot without the File object, which is still enough to show the title and path
  if (saved.selectedFileSnapshot && !selectedFile.value) {
    selectedFile.value = saved.selectedFileSnapshot
  }

  // Restore configuration options
  selectedFramework.value = saved.selectedFramework || 'gtest'
  selectedLayer.value = saved.selectedLayer || 'auto'
  selectedPlatform.value = saved.selectedPlatform || 'stm32u3'
  if (saved.outputDir) outputDir.value = saved.outputDir
  if (saved.detectedProjectRoot) detectedProjectRoot.value = saved.detectedProjectRoot

  // Skip backend query if the task ID is temporary (starts with __temp_)
  if (saved.taskId && saved.taskId.startsWith('__temp_')) {
    console.log('[DEBUG] Skipping backend query for temporary task ID:', saved.taskId)
    // Reset to idle state for temporary tasks
      phase.value = 'idle'
      progress.value = 0
      statusMessage.value = ''
      currentStage.value = ''
    result.value = null
    taskError.value = null
    liveNodes.value = []
    currentTaskId.value = null
    currentStage.value = ''
    return
  }

  // If a real task_id exists, reconcile the state with the backend
  if (saved.taskId) {
    // Check if we already have the result saved locally from unittestStore
    const storedTask = unittestStore.getTask(saved.taskId)
    if (storedTask && storedTask.status === 'completed' && storedTask.result) {
      // If task is already completed and result is in local store, use it directly
      phase.value = 'done'
      progress.value = 100
      statusMessage.value = 'Completed'
      result.value = normalizeResultPayload(storedTask.result, selectedLayer.value)
      taskError.value = null
      liveNodes.value = normalizePipelineNodes(
        saved.liveNodes || storedTask.liveNodes,
        'completed',
      )
      console.log('[DEBUG] Restored completed task from local history:', saved.taskId)
      syncTaskFromBackend(saved.taskId, storedTask)
      return
    } else if (storedTask && storedTask.status === 'failed' && storedTask.result) {
      // Legacy records may say failed even though compile and every test pass.
      const passingLegacyTask = hasPassingUnitTests(storedTask.result)
      phase.value = passingLegacyTask ? 'done' : 'failed'
      progress.value = passingLegacyTask ? 100 : -1
      statusMessage.value = passingLegacyTask
        ? 'Unit tests passed; coverage optimization is pending'
        : 'Failed'
      result.value = normalizeResultPayload(storedTask.result, selectedLayer.value)
      taskError.value = passingLegacyTask ? null : (saved.taskError || 'Task failed')
      liveNodes.value = normalizePipelineNodes(
        saved.liveNodes || storedTask.liveNodes,
        passingLegacyTask ? 'completed' : 'failed',
      )
      console.log('[DEBUG] Restored failed task from local history:', saved.taskId)
      syncTaskFromBackend(saved.taskId, storedTask)
      return
    }

    apiGetTask(saved.taskId).then(data => {
      if (!isCurrentAccount() || currentTaskId.value !== saved.taskId) return
      applyBackendTelemetry(data)
      if (data.status === 'running') {
        phase.value = 'running'
        progress.value = data.progress || 0
        statusMessage.value = data.message || ''
        currentStage.value = data.current_stage || ''
        elapsedSeconds.value = data.elapsed_seconds || 0
        activityAgeSeconds.value = data.activity_age_seconds ?? null
        applyRuntimeTelemetry(data)
        liveNodes.value = normalizePipelineNodes(data.nodes, data.status)
        result.value = normalizeResultPayload(data.result, selectedLayer.value)
        taskError.value = null

        // Update the history title using backend metadata
        if (data.meta?.title) {
          unittestStore.updateTask(saved.taskId, {
            title: data.meta.title,
            status: 'running',
            progress: data.progress || 0,
            liveNodes: liveNodes.value,
            currentStage: data.current_stage || '',
            statusMessage: data.message || '',
          })
        }

        setupPolling(saved.taskId)
      } else if (data.status === 'completed') {
        phase.value = 'done'
        progress.value = 100
        statusMessage.value = data.message || 'Completed'
        currentStage.value = data.current_stage || ''
        result.value = normalizeResultPayload(data.result, selectedLayer.value)
        liveNodes.value = normalizePipelineNodes(data.nodes, data.status)
        taskError.value = null

        unittestStore.updateTask(saved.taskId, {
          title: data.meta?.title || saved.uploadedFileName,
          status: 'completed',
          progress: 100,
          result: data.result,
          liveNodes: liveNodes.value,
          currentStage: data.current_stage || '',
          statusMessage: data.message || 'Completed',
        })
        saveTaskState()
      } else if (data.status === 'failed' || data.status === 'cancelled') {
        if (data.status === 'failed' && hasPassingUnitTests(data.result)) {
          phase.value = 'done'
          progress.value = 100
          statusMessage.value = 'Unit tests passed; coverage optimization is pending'
          currentStage.value = data.current_stage || ''
          result.value = normalizeResultPayload(data.result, selectedLayer.value)
          taskError.value = null
          liveNodes.value = normalizePipelineNodes(data.nodes, 'completed')
          unittestStore.updateTask(saved.taskId, {
            status: 'completed', progress: 100, result: result.value,
            liveNodes: liveNodes.value, currentStage: currentStage.value,
            statusMessage: statusMessage.value, error: null,
          })
          saveTaskState()
          return
        }
        // Check if this is an AWS Profile configuration error
        if (data.profile_error || isAWSProfileConfigError(data.error || data.message)) {
          showAWSProfileConfigError(data.error || data.message)
        }

        // Show failed or cancelled state with result data
        phase.value = data.status === 'cancelled' ? 'cancelled' : 'failed'
        taskError.value = data.error || (data.status === 'cancelled' ? 'Task cancelled by user' : 'Task failed')
        statusMessage.value = data.message || ''
        currentStage.value = data.current_stage || ''
        result.value = normalizeResultPayload(data.result, selectedLayer.value)
        progress.value = data.progress ?? -1
        liveNodes.value = normalizePipelineNodes(data.nodes, data.status)

        unittestStore.updateTask(saved.taskId, {
          status: data.status,
          result: data.result,
          progress: data.progress ?? -1,
          liveNodes: liveNodes.value,
          currentStage: data.current_stage || '',
          statusMessage: data.message || '',
          error: data.error || null,
        })
        saveTaskState()
      } else {
        // Unknown status -> reset to idle
        phase.value = 'idle'
        taskError.value = null
        result.value = null
        progress.value = 0
        liveNodes.value = []

        unittestStore.updateTask(saved.taskId, {
          status: data.status,
        })
        saveTaskState()
      }
    }).catch((error) => {
      if (!isCurrentAccount() || currentTaskId.value !== saved.taskId) return
      // Avoid restoring a local running state into permanent loading when the backend is unavailable or task recovery fails
      if (saved.phase === 'done' && saved.result) {
        phase.value = 'done'
        progress.value = 100
        statusMessage.value = saved.statusMessage || 'Completed'
        result.value = normalizeResultPayload(saved.result, selectedLayer.value)
        taskError.value = null
        liveNodes.value = normalizePipelineNodes(saved.liveNodes, 'completed')
      } else if (storedTask && storedTask.status === 'completed' && storedTask.result) {
        phase.value = 'done'
        progress.value = 100
        statusMessage.value = 'Completed'
        result.value = normalizeResultPayload(storedTask.result, selectedLayer.value)
        taskError.value = null
        liveNodes.value = normalizePipelineNodes(saved.liveNodes, 'completed')
      } else if (saved.phase === 'cancelled' || storedTask?.status === 'cancelled') {
        phase.value = 'cancelled'
        progress.value = saved.progress ?? storedTask?.progress ?? 0
        statusMessage.value = saved.statusMessage || 'Task cancelled'
        result.value = normalizeResultPayload(saved.result || storedTask?.result, selectedLayer.value)
        taskError.value = saved.taskError || storedTask?.error || 'Task cancelled by user'
        liveNodes.value = normalizePipelineNodes(
          saved.liveNodes || storedTask?.liveNodes,
          'cancelled',
        )
      } else {
        const recoveryError = error?.status === 404
          ? 'Task no longer exists on the backend. Start a new generation.'
          : 'Task recovery failed. Check backend health and start a new generation.'
        phase.value = 'failed'
        progress.value = saved.progress ?? storedTask?.progress ?? -1
        statusMessage.value = recoveryError
        result.value = null
        taskError.value = recoveryError
        liveNodes.value = []
        unittestStore.updateTask(saved.taskId, {
          status: 'failed',
          progress: -1,
          error: recoveryError,
          updatedAt: new Date().toISOString(),
        })
      }
      saveTaskState()
    })
  } else {
    // No real task exists, so restore draft state only
    phase.value = 'idle'
    progress.value = 0
    statusMessage.value = ''
    result.value = null
    taskError.value = null
    liveNodes.value = []
  }
}

// Logic to run when the component is mounted
onMounted(() => {
  if (props.activeTask) {
    currentTaskId.value = props.activeTask.id
    // Reset cancelled or failed tasks to idle so the user can upload again
    if (props.activeTask.status === 'idle') {
      phase.value = 'idle'
    } else if (props.activeTask.status === 'cancelled' || props.activeTask.status === 'failed') {
      result.value = normalizeResultPayload(props.activeTask.result, selectedLayer.value)
      const passingLegacyTask = props.activeTask.status === 'failed' && hasPassingUnitTests(props.activeTask.result)
      phase.value = passingLegacyTask
        ? 'done'
        : (props.activeTask.status === 'cancelled' ? 'cancelled' : 'failed')
      progress.value = passingLegacyTask ? 100 : -1
      statusMessage.value = passingLegacyTask
        ? 'Unit tests passed; coverage optimization is pending'
        : (props.activeTask.status === 'cancelled' ? 'Task cancelled by user' : 'Failed')
      taskError.value = passingLegacyTask
        ? null
        : (props.activeTask.error || (props.activeTask.status === 'cancelled' ? 'Task cancelled by user' : 'Task failed'))
      liveNodes.value = normalizePipelineNodes(
        props.activeTask.liveNodes,
        passingLegacyTask ? 'completed' : props.activeTask.status,
      )
      showBuild.value = true
    } else if (props.activeTask.status === 'completed') {
      phase.value = 'done'
      progress.value = 100
      statusMessage.value = props.activeTask.statusMessage || 'Completed'
      result.value = normalizeResultPayload(props.activeTask.result, selectedLayer.value)
      taskError.value = null
      liveNodes.value = props.activeTask.liveNodes || []
    } else if (props.activeTask.status === 'running') {
      phase.value = 'running'
      result.value = normalizeResultPayload(props.activeTask.result, selectedLayer.value)
      setupPolling(props.activeTask.id)
    }
    if (props.activeTask.id && !props.activeTask.id.startsWith('__temp_')) {
      syncTaskFromBackend(props.activeTask.id, props.activeTask)
    }
  } else {
    // Restore workspace state when there is no active task
    restoreTaskState()
  }
})

// Watch activeTask prop changes (e.g. sidebar task switch or new task)
watch(() => props.activeTask, (newTask, oldTask) => {
  if (!isCurrentAccount()) return
  // Stop any in-progress polling
  if (stopPolling.value) { stopPolling.value(); stopPolling.value = null }

  if (newTask) {
    // Always clear previous expanded previews when switching tasks
    expanded.value = new Set()
    showBuild.value = false

    // Only clear file state when switching between two distinct tasks (not on first load)
    const isSwitchingTask = oldTask && newTask.id !== oldTask.id
    currentTaskId.value = newTask.id

    // Restore file state from the active task's saved data
    if (newTask.selectedFileSnapshot) {
      selectedFile.value = { ...newTask.selectedFileSnapshot }
    } else if (isSwitchingTask) {
      selectedFile.value = null
    }

    if (newTask.outputDir !== undefined) {
      outputDir.value = newTask.outputDir || ''
    } else if (isSwitchingTask) {
      outputDir.value = ''
    }

    // Clear other file-related state when switching tasks
    if (isSwitchingTask) {
      sourceFiles.value = []
      fileTree.value = []
    }

    progress.value = newTask.progress || 0
    statusMessage.value = newTask.statusMessage || ''
    currentStage.value = newTask.currentStage || ''

    if (newTask.status === 'idle' || newTask.status === 'cancelled' || newTask.status === 'failed') {
      const passingLegacyTask = newTask.status === 'failed' && hasPassingUnitTests(newTask.result)
      phase.value = passingLegacyTask
        ? 'done'
        : newTask.status === 'idle'
        ? 'idle'
        : (newTask.status === 'cancelled' ? 'cancelled' : 'failed')
      result.value = passingLegacyTask ? normalizeResultPayload(newTask.result, selectedLayer.value) : null
      progress.value = passingLegacyTask ? 100 : progress.value
      statusMessage.value = passingLegacyTask
        ? 'Unit tests passed; coverage optimization is pending'
        : statusMessage.value
      taskError.value = passingLegacyTask
        ? null
        : newTask.status === 'failed'
        ? newTask.error || 'Task failed'
        : (newTask.status === 'cancelled' ? newTask.error || 'Task cancelled by user' : null)
      liveNodes.value = normalizePipelineNodes(
        newTask.liveNodes,
        passingLegacyTask ? 'completed' : (newTask.status === 'idle' ? 'idle' : newTask.status),
      )
    } else if (newTask.status === 'completed') {
      phase.value = 'done'
      progress.value = 100
      statusMessage.value = newTask.statusMessage || 'Completed'
      result.value = normalizeResultPayload(newTask.result, selectedLayer.value)
      taskError.value = null
      liveNodes.value = normalizePipelineNodes(newTask.liveNodes, 'completed')
      showBuild.value = true
    } else if (newTask.status === 'running') {
      phase.value = 'running'
      result.value = normalizeResultPayload(newTask.result, selectedLayer.value)
      liveNodes.value = normalizePipelineNodes(newTask.liveNodes, 'running')
      setupPolling(newTask.id)
    }

    // Restore configuration from saved task state
    if (newTask.selectedFramework !== undefined) {
      selectedFramework.value = newTask.selectedFramework
    }
    if (newTask.selectedLayer !== undefined) {
      selectedLayer.value = newTask.selectedLayer
    }
    if (newTask.selectedPlatform !== undefined) {
      selectedPlatform.value = newTask.selectedPlatform
    }
    if (newTask.liveNodes !== undefined) {
      liveNodes.value = normalizePipelineNodes(newTask.liveNodes, newTask.status)
    }
    if (newTask.id && !newTask.id.startsWith('__temp_')) {
      syncTaskFromBackend(newTask.id, newTask)
    }
  } else {
    // null = new blank task
    phase.value = 'idle'
    progress.value = 0
    statusMessage.value = ''
    result.value = null
    taskError.value = null
    currentTaskId.value = null
    currentStage.value = ''
    selectedFile.value = null
    outputDir.value = ''
    sourceFiles.value = []
    fileTree.value = []
    expanded.value = new Set()
    showBuild.value = false
  }
})

// Auto-expand Workflow Output when task result becomes available
watch(phase, (newPhase) => {
  if (newPhase === 'done' || newPhase === 'failed' || newPhase === 'cancelled') {
    showBuild.value = true
  }
})

// Watch state changes and save automatically
watch([phase, progress, result], () => {
  if (currentTaskId.value) {
    saveTaskState()
  }
}, { deep: true })

// Watch selected file changes and save the file data
watch(selectedFile, (newFile) => {
  if (newFile) {
    syncTaskTitle(newFile)
    saveTaskState()
  }
}, { deep: true })

async function cancelTask() {
  if (!isCurrentAccount() || !currentTaskId.value) return
  const taskId = currentTaskId.value

  try {
    // Stop polling
    if (stopPolling.value) {
      stopPolling.value()
      stopPolling.value = null
    }

    // Call the backend cancel API
    await apiCancelTask(taskId)
    if (!isCurrentAccount() || currentTaskId.value !== taskId) return

    // Update the frontend state
    phase.value = 'cancelled'
    taskError.value = 'Task cancelled by user'
    statusMessage.value = 'Task cancelled'
    liveNodes.value = normalizePipelineNodes(liveNodes.value, 'cancelled')
    unittestStore.updateTask(currentTaskId.value, {
      status: 'cancelled',
      progress: progress.value >= 0 ? progress.value : 0,
      liveNodes: liveNodes.value,
      currentStage: currentStage.value,
      statusMessage: statusMessage.value,
      error: taskError.value,
      updatedAt: new Date().toISOString(),
    })
    emit('task-updated', {
      id: currentTaskId.value,
      status: 'cancelled',
      progress: progress.value >= 0 ? progress.value : 0,
      liveNodes: liveNodes.value,
      currentStage: currentStage.value,
      statusMessage: statusMessage.value,
      error: taskError.value,
      updatedAt: new Date().toISOString(),
    })

    // Save the state
    saveTaskState()
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== taskId) return
    console.error('Cancel task error:', error)
    taskError.value = error.message || 'Failed to cancel task'
  }
}

function resetAll() {
  if (stopPolling.value) { stopPolling.value(); stopPolling.value = null }

  // Keep the currently selected file metadata without resetting it
  const savedFile = selectedFile.value
  const savedOutputDir = outputDir.value

  phase.value         = 'idle'
    cliActivity.kind = ''
    cliActivity.message = ''
    cliActivity.updated_at = ''
    coverageSkillNames.value = []
    skillRuntime.value = []
    progress.value      = 0
    elapsedSeconds.value = 0
    activityAgeSeconds.value = null
  statusMessage.value = ''
  result.value        = null
  taskError.value     = null
  // Keep the file selection so the user can generate again
  // selectedFile.value  = null
  // outputDir.value     = ''
  fileTree.value      = []
  sourceFiles.value   = []
  currentTaskId.value = null
  currentStage.value = ''
  expanded.value      = new Set()
  showBuild.value     = false

  // clear file input
  if (fileInputRef.value) fileInputRef.value.value = ''

  // Clear persisted state while keeping the file selection
  const savedState = {
    hasFile: savedFile !== null,
    uploadedFileName: savedFile?.name,
    uploadedFileSize: savedFile?.size,
    selectedFramework: selectedFramework.value,
    selectedLayer: selectedLayer.value,
    selectedPlatform: selectedPlatform.value,
    outputDir: savedOutputDir,
  }

  workspaceStore.clearState(AGENT_ID)
  workspaceStore.saveState(AGENT_ID, savedState)

  // Clear task file storage
  if (currentTaskId.value) {
    const storageKey = `unittest_file_${currentTaskId.value}`
    workspaceStore.clearState(storageKey)
  }
}
</script>

<style scoped>
/* ── Layout ────────────────────────────────────────────────────────────────── */
.ut-workspace {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: #f8f9fb;
}

.ut-topbar {
  height: 44px;
  background: white;
  border-bottom: 1px solid #eef0f3;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 20px; flex-shrink: 0;
}
.topbar-left { display: flex; align-items: center; gap: 10px; }
.topbar-agent-icon {
  width: 24px; height: 24px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  background: #16a34a18; color: #16a34a;
}
.topbar-title  { font-size: 13px; font-weight: 600; color: #1f2937; }
.topbar-desc   { font-size: 12px; color: #9ca3af; padding-left: 10px; border-left: 1px solid #e5e7eb; }

.topbar-right { display: flex; align-items: center; gap: 8px; }

.cancel-btn {
  display: flex; align-items: center; gap: 5px;
  padding: 5px 12px; border: 1px solid #fca5a5; border-radius: 7px;
  background: #fef2f2; font-size: 12px; color: #dc2626; cursor: pointer; transition: all 0.15s;
}
.cancel-btn:hover { background: #fee2e2; border-color: #f87171; }

.reset-btn {
  display: flex; align-items: center; gap: 5px;
  padding: 5px 12px; border: 1px solid #e5e7eb; border-radius: 7px;
  background: white; font-size: 12px; color: #6b7280; cursor: pointer; transition: all 0.15s;
}
.reset-btn:hover { background: #f3f4f6; color: #374151; }

.ut-body { flex: 1; display: flex; overflow: hidden; }

/* ── Input Panel ───────────────────────────────────────────────────────────── */
.input-panel {
  width: 280px; min-width: 280px;
  background: white; border-right: 1px solid #eef0f3;
  display: flex; flex-direction: column;
  padding: 20px 16px 24px; gap: 0; overflow-y: auto;
  scrollbar-width: thin; scrollbar-color: #e5e7eb transparent;
}

.panel-section { margin-bottom: 20px; }
.section-label {
  display: flex; align-items: center; gap: 5px;
  font-size: 11px; font-weight: 600; color: #6b7280;
  text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px;
}

.auto-fill-btn {
  margin-left: auto;
  padding: 2px 8px;
  font-size: 10px;
  font-weight: 500;
  color: #2563eb;
  background: #eff6ff;
  border: 1px solid #bfdbfe;
  border-radius: 4px;
  cursor: pointer;
  text-transform: none;
  transition: all 0.15s;
}
.auto-fill-btn:hover {
  background: #dbeafe;
}

/* Drop zone */
.drop-zone {
  border: 1.5px dashed #d1d5db; border-radius: 10px;
  padding: 20px 12px; text-align: center; cursor: pointer;
  transition: all 0.2s; background: #fafafa; position: relative;
}
.drop-zone:hover, .drop-zone.drag-over { border-color: #2563eb; background: #eff6ff; }
.drop-zone.has-file { border-style: solid; border-color: #16a34a; background: #f0fdf4; }

.drop-icon  { color: #d1d5db; margin-bottom: 8px; }
.drop-text  { font-size: 13px; color: #6b7280; margin-bottom: 4px; }
.drop-link  { color: #2563eb; text-decoration: underline; }
.drop-hint  { font-size: 11px; color: #9ca3af; }

.file-ok-icon { color: #16a34a; margin-bottom: 6px; }
.file-name    { font-size: 13px; font-weight: 500; color: #1f2937; margin-bottom: 2px; word-break: break-all; }
.file-size    { font-size: 11px; color: #9ca3af; }
.remove-file  {
  position: absolute; top: 8px; right: 8px;
  width: 20px; height: 20px; border: none; background: #fee2e2;
  border-radius: 50%; color: #ef4444; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}

/* Selectors */
.select-group { display: flex; flex-wrap: wrap; gap: 6px; }
.select-btn {
  padding: 4px 12px; border: 1px solid #e5e7eb; border-radius: 6px;
  font-size: 12px; color: #6b7280; background: white; cursor: pointer; transition: all 0.15s;
}
.select-btn.active { border-color: #2563eb; background: #eff6ff; color: #2563eb; font-weight: 500; }

/* Output dir input */
.output-dir-input {
  width: 100%; padding: 6px 10px; border: 1px solid #e5e7eb; border-radius: 6px;
  font-size: 12px; color: #374151; background: white; outline: none; transition: border-color 0.15s;
  box-sizing: border-box;
}
.output-dir-input:focus { border-color: #2563eb; }
.output-dir-input.input-hint {
  background: #fffbeb;
  border-color: #f59e0b;
}
.output-dir-hint { margin: 3px 0 0; font-size: 11px; color: #9ca3af; }
.output-dir-hint:has(.warning) { color: #d97706; }

/* Folder select button */
.folder-select-btn {
  width: 100%; padding: 8px 12px; border: 1px solid #2563eb; border-radius: 6px;
  font-size: 12px; color: #2563eb; background: #eff6ff; cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 6px;
  transition: all 0.15s;
}
.folder-select-btn:hover { background: #dbeafe; }
.folder-select-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  background: #f3f4f6;
  color: #9ca3af;
  border-color: #d1d5db;
}
.folder-select-btn.secondary {
  background: white;
  color: #6b7280;
  border-color: #d1d5db;
}
.folder-select-btn.secondary:hover {
  background: #f3f4f6;
  color: #374151;
}
.file-select-actions {
  display: grid;
  gap: 8px;
}
.native-file-input {
  display: none;
}
.file-error-hint {
  margin: 6px 0 0; font-size: 11px; color: #ef4444; line-height: 1.4;
}

/* File tree */
.file-tree {
  max-height: 200px; overflow-y: auto;
  border: 1px solid #e5e7eb; border-radius: 6px;
  background: #fafafa;
}
.file-tree-item {
  display: flex; align-items: center; gap: 6px;
  padding: 6px 10px; font-size: 12px; color: #374151;
  cursor: pointer; transition: all 0.15s;
  border-bottom: 1px solid #f1f5f9;
}
.file-tree-item:last-child { border-bottom: none; }
.file-tree-item:hover { background: #eff6ff; }
.file-tree-item.selected { background: #dbeafe; color: #1d4ed8; font-weight: 500; }
.file-icon { flex-shrink: 0; color: #9ca3af; }
.file-path { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-count { margin-left: auto; font-size: 10px; color: #9ca3af; background: #e5e7eb; padding: 1px 6px; border-radius: 10px; }

/* Selected file info */
.selected-file-info {
  display: flex; align-items: flex-start; gap: 8px;
  padding: 8px 12px; background: #f0fdf4; border: 1px solid #bbf7d0;
  border-radius: 6px; font-size: 12px; color: #166534;
}
.file-info-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.file-info-name {
  font-weight: 600;
  color: #166534;
}
.file-info-path {
  font-size: 11px;
  color: #6b7280;
  word-break: break-all;
}
.remove-file-small {
  flex-shrink: 0;
  width: 20px; height: 20px;
  border: none; background: #fee2e2;
  border-radius: 50%; color: #ef4444; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.15s;
}
.remove-file-small:hover {
  background: #fecaca;
}
.remove-file-small:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  background: #f3f4f6;
  color: #9ca3af;
}

/* Selected file card - large filename display */
.selected-file-card {
  width: 100%;
  background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
  border: 2px solid #86efac;
  border-radius: 12px;
  overflow: hidden;
  transition: all 0.2s;
}
.selected-file-card:hover {
  box-shadow: 0 4px 12px rgba(22, 163, 74, 0.15);
  border-color: #4ade80;
}
.file-card-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 14px;
  background: rgba(255, 255, 255, 0.6);
  border-bottom: 1px solid #bbf7d0;
}
.file-card-title {
  flex: 1;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #166534;
}
.remove-file-btn {
  width: 28px;
  height: 28px;
  border: none;
  background: #fee2e2;
  border-radius: 6px;
  color: #dc2626;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.15s;
}
.remove-file-btn:hover {
  background: #fecaca;
  transform: scale(1.05);
}
.remove-file-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  background: #f3f4f6;
  color: #9ca3af;
}
.file-card-body {
  padding: 14px 16px 16px;
}
.file-card-name {
  font-size: 16px;
  font-weight: 700;
  color: #15803d;
  margin-bottom: 6px;
  word-break: break-all;
  line-height: 1.4;
}
.file-card-path {
  font-size: 11.5px;
  color: #6b7280;
  word-break: break-all;
  line-height: 1.5;
  padding: 6px 10px;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 6px;
  font-family: 'Consolas', 'Monaco', monospace;
}

/* Run button */
.run-btn {
  margin-top: auto; width: 100%;
  display: flex; align-items: center; justify-content: center; gap: 7px;
  padding: 11px; background: #1e3a5f; color: white;
  border: none; border-radius: 10px; font-size: 14px; font-weight: 600;
  cursor: pointer; transition: background 0.2s;
}
.run-btn:hover:not(:disabled) { background: #2563eb; }
.run-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.run-btn.loading { background: #6b7280; }

.spinner {
  width: 14px; height: 14px;
  border: 2px solid rgba(255,255,255,0.3); border-top-color: white;
  border-radius: 50%; display: inline-block;
  animation: spin 0.7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ── Result Panel ──────────────────────────────────────────────────────────── */
.result-panel {
  flex: 1; overflow-y: auto; padding: 24px;
  scrollbar-width: thin; scrollbar-color: #e5e7eb transparent;
}

/* Guide */
.guide-area {
  display: flex; flex-direction: column; align-items: center;
  padding: 48px 20px; text-align: center;
}
.guide-icon { margin-bottom: 12px; }
.guide-title { font-size: 16px; font-weight: 700; color: #1f2937; margin-bottom: 6px; }
.guide-sub   { font-size: 13px; color: #9ca3af; margin-bottom: 28px; max-width: 360px; }
.guide-steps { display: flex; flex-direction: column; gap: 10px; width: 100%; max-width: 340px; text-align: left; }
.guide-step  { display: flex; align-items: center; gap: 10px; padding: 10px 14px; background: white; border: 1px solid #e5e7eb; border-radius: 8px; }
.step-num    { width: 20px; height: 20px; background: #1e3a5f; color: white; border-radius: 50%; font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.step-text   { font-size: 13px; color: #374151; }

/* Loading */
.loading-area { padding: 8px; }
.loading-header { display: flex; align-items: center; gap: 16px; margin-bottom: 20px; }

.ring-wrap { position: relative; width: 52px; height: 52px; flex-shrink: 0; }
.ring-svg  { width: 52px; height: 52px; transform: rotate(-90deg); }
.ring-bg   { fill: none; stroke: #e5e7eb; stroke-width: 3; }
.ring-fg   { fill: none; stroke: #2563eb; stroke-width: 3; stroke-dasharray: 94.2; stroke-linecap: round; transition: stroke-dashoffset 0.5s ease; }
.ring-pct  { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; color: #2563eb; }

.loading-msg  { display: flex; flex-direction: column; gap: 4px; min-width: 0; }
.msg-title    { font-size: 14px; font-weight: 600; color: #1f2937; }
.msg-sub      { font-size: 12px; color: #6b7280; word-break: break-word; max-height: 72px; overflow-y: auto; }
.msg-runtime  { font-size: 11px; color: #475569; font-variant-numeric: tabular-nums; }

/* Token usage display */
.token-usage-display {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px 16px;
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
  border: 1px solid #bae6fd;
  border-radius: 8px;
  margin: 16px 0;
  font-size: 13px;
}
.token-item {
  display: flex;
  align-items: center;
  gap: 6px;
}
.token-label {
  color: #0369a1;
  font-weight: 500;
}
.token-value {
  color: #0c4a6e;
  font-weight: 600;
  font-family: 'Courier New', monospace;
}
.token-item.total {
  margin-left: auto;
  padding-left: 16px;
  border-left: 1px solid #7dd3fc;
}
.token-item.total .token-label {
  color: #0369a1;
  font-weight: 600;
}
.token-item.total .token-value {
  color: #0c4a6e;
  font-size: 14px;
  font-weight: 700;
}

/* Pipeline */
.pipeline {
  display: flex; align-items: center; justify-content: flex-start;
  flex-wrap: nowrap; gap: 0; padding: 4px 0; overflow-x: auto;
}
.pipe-node  { display: flex; flex-direction: column; align-items: center; gap: 8px; min-width: 72px; flex-shrink: 0; }
.pipe-icon  { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid #e5e7eb; background: #f9fafb; transition: all 0.3s; }
.pipe-label { font-size: 11px; color: #6b7280; text-align: center; white-space: nowrap; }

.pipe-node.done  .pipe-icon  { border-color: #16a34a; background: #f0fdf4; }
.pipe-node.done  .pipe-label { color: #166534; font-weight: 500; }
.pipe-check { color: #16a34a; }
.pipe-fail  { color: #ef4444; }

.pipe-node.fail .pipe-icon  { border-color: #ef4444; background: #fef2f2; }
.pipe-node.fail .pipe-label { color: #ef4444; }

.pipe-node.cancelled .pipe-icon { border-color: #f59e0b; background: #fffbeb; }
.pipe-node.cancelled .pipe-label { color: #b45309; font-weight: 600; }

.pipe-node.skipped .pipe-icon { border-color: #d1d5db; background: #f9fafb; }
.pipe-node.skipped .pipe-label { color: #9ca3af; }

.pipe-node.active .pipe-icon  { border-color: #2563eb; background: #eff6ff; box-shadow: 0 0 0 3px rgba(37,99,235,0.15); }
.pipe-node.active .pipe-label { color: #1d4ed8; font-weight: 600; }

.pipe-node.pending .pipe-label { color: #9ca3af; }

.pipe-spinner { width: 18px; height: 18px; border: 2px solid #bfdbfe; border-top-color: #2563eb; border-radius: 50%; display: inline-block; animation: spin 0.8s linear infinite; }
.pipe-dot     { width: 10px; height: 10px; border-radius: 50%; background: #d1d5db; display: inline-block; }

.pipe-arrow { display: flex; align-items: center; flex-shrink: 0; margin: 0 2px; margin-bottom: 22px; }
.pipe-arrow svg line, .pipe-arrow svg polyline { stroke: #d1d5db; transition: stroke 0.3s; }
.pipe-arrow.lit svg line, .pipe-arrow.lit svg polyline { stroke: #16a34a; }

/* Result */
.result-area { display: flex; flex-direction: column; gap: 14px; }

/* ── Hero banner ──────────────────────────────────────────────────────────── */
.hero-banner {
  position: relative;
  display: flex; gap: 20px; align-items: center;
  padding: 20px 22px;
  background: linear-gradient(135deg, #eef2ff 0%, #f0f9ff 100%);
  border: 1px solid #c7d2fe;
  border-radius: 14px;
  overflow: hidden;
}
.hero-glow {
  position: absolute; top: -40px; right: -40px;
  width: 180px; height: 180px; border-radius: 50%;
  background: radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%);
  pointer-events: none;
}

/* Donuts */
.hero-donuts { display: flex; flex-direction: column; align-items: center; gap: 14px; flex-shrink: 0; }

.donut-wrap { position: relative; display: flex; align-items: center; justify-content: center; }
.main-donut { width: 110px; height: 110px; }
.donut-svg  { width: 110px; height: 110px; transform: rotate(-90deg); }

.donut-track { fill: none; stroke: #e0e7ff; stroke-width: 8; }
.donut-ring  { fill: none; stroke: url(#grad-main); stroke-width: 8; stroke-linecap: round; }
.main-ring   { stroke-width: 9; }

.donut-label {
  position: absolute; display: flex; flex-direction: column; align-items: center;
}
.donut-pct { font-size: 20px; font-weight: 800; color: #3730a3; line-height: 1; }
.donut-pct em { font-size: 12px; font-style: normal; color: #6366f1; }
.donut-sub { font-size: 10px; color: #818cf8; font-weight: 600; letter-spacing: 0.5px; margin-top: 2px; }

.mini-donuts { display: flex; gap: 16px; }
.mini-donut-item { display: flex; flex-direction: column; align-items: center; gap: 4px; }
.mini-svg   { width: 56px; height: 56px; transform: rotate(-90deg); }
.mini-label { display: flex; flex-direction: column; align-items: center; }
.mini-pct   { font-size: 12px; font-weight: 700; color: #3730a3; line-height: 1.2; }
.mini-sub   { font-size: 10px; color: #94a3b8; }

/* KPI grid */
.kpi-grid {
  flex: 1; display: grid;
  grid-template-columns: repeat(auto-fill, minmax(90px, 1fr));
  gap: 10px;
}
.kpi-tile {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 3px; padding: 12px 8px; border-radius: 10px;
  border: 1px solid transparent; transition: transform 0.15s;
}
.kpi-tile:hover { transform: translateY(-2px); }
.kpi-icon { font-size: 16px; line-height: 1; }
.kpi-title { font-size: 18px; font-weight: 700; line-height: 1.2; margin-bottom: 6px; }
.kpi-green-text { color: #16a34a !important; }
.kpi-val  { font-size: 16px; font-weight: 800; line-height: 1.2; }
.kpi-val-large { font-size: 24px; font-weight: 800; line-height: 1.1; margin-top: 4px; }
.kpi-name { font-size: 10px; font-weight: 500; letter-spacing: 0.3px; }
.kpi-sub  { font-size: 9px; font-weight: 500; opacity: 0.7; margin-top: 2px; }

.kpi-green  { background: #f0fdf4; border-color: #bbf7d0; }
.kpi-green  .kpi-icon, .kpi-green .kpi-val  { color: #16a34a; }
.kpi-green  .kpi-name { color: #4ade80; }
.kpi-red    { background: #fef2f2; border-color: #fecaca; }
.kpi-red    .kpi-icon, .kpi-red .kpi-val    { color: #dc2626; }
.kpi-red    .kpi-name { color: #f87171; }
.kpi-indigo { background: #eef2ff; border-color: #c7d2fe; }
.kpi-indigo .kpi-icon, .kpi-indigo .kpi-val { color: #4338ca; }
.kpi-indigo .kpi-name { color: #818cf8; }
.kpi-blue   { background: #f0f9ff; border-color: #bae6fd; }
.kpi-blue   .kpi-icon, .kpi-blue .kpi-val   { color: #0369a1; }
.kpi-blue   .kpi-name { color: #38bdf8; }
.kpi-amber  { background: #fffbeb; border-color: #fde68a; }
.kpi-amber  .kpi-icon, .kpi-amber .kpi-val  { color: #b45309; }
.kpi-amber  .kpi-name { color: #fbbf24; }
.kpi-purple { background: #faf5ff; border-color: #e9d5ff; }
.kpi-purple .kpi-icon, .kpi-purple .kpi-val { color: #7c3aed; }
.kpi-purple .kpi-name { color: #a78bfa; }
.kpi-green  { background: #f0fdf4; border-color: #bbf7d0; }
.kpi-green  .kpi-icon, .kpi-green .kpi-val  { color: #15803d; }
.kpi-green  .kpi-name { color: #4ade80; }
.kpi-detail {
  font-size: 9px;
  font-weight: 500;
  color: #9333ea;
  margin-top: 2px;
  opacity: 0.8;
}

/* Tag strip */
.tag-strip { display: flex; flex-wrap: wrap; gap: 7px; }
.tag {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 3px 10px; border-radius: 20px;
  font-size: 11px; font-weight: 500;
}
.tag-layer { background: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe; }
.tag-fw    { background: #f0f9ff; color: #0369a1; border: 1px solid #bae6fd; }
.tag-file  { background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; }
.tag-ok    { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }
.tag-large { background: #ecfeff; color: #0e7490; border: 1px solid #a5f3fc; }

/* Dark / light cards */
.dark-card {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  overflow: hidden;
}
.dark-card-title {
  display: flex; align-items: center; gap: 8px;
  padding: 11px 16px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
  font-size: 12px; font-weight: 600; color: #334155;
  text-transform: uppercase; letter-spacing: 0.5px;
}
.dark-card-title.clickable { cursor: pointer; user-select: none; }
.dark-card-title.clickable:hover { background: #f1f5f9; }
.card-count { margin-left: auto; background: #e0e7ff; color: #4338ca; border-radius: 10px; padding: 1px 8px; font-size: 11px; font-weight: 600; text-transform: none; letter-spacing: 0; }
.card-toggle { margin-left: auto; color: #94a3b8; font-size: 11px; }

.large-file-diagnostic { padding: 13px 16px 15px; border-bottom: 1px solid #f1f5f9; }
.large-file-diagnostic:last-child { border-bottom: 0; }
.large-file-summary { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; color: #0f172a; font-size: 12px; }
.large-file-summary span { color: #64748b; font-size: 11px; }
.large-file-reason { margin: 7px 0; color: #475569; font-size: 11px; line-height: 1.5; }
.large-file-stats { display: flex; flex-wrap: wrap; gap: 6px; }
.large-file-stats span { padding: 3px 7px; border-radius: 5px; background: #f0f9ff; border: 1px solid #bae6fd; color: #0369a1; font-size: 10px; }
.large-file-matrix { margin-top: 10px; padding: 9px 11px; border-radius: 7px; background: #f8fafc; border: 1px solid #e2e8f0; }
.large-file-subtitle { color: #334155; font-size: 11px; font-weight: 700; margin-bottom: 5px; }
.large-file-matrix ul { margin: 0; padding-left: 18px; color: #64748b; font-size: 10px; line-height: 1.55; }

/* Dot indicators */
.dot-purple, .dot-green, .dot-red, .dot-blue {
  width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0;
}
.dot-purple { background: #6366f1; box-shadow: 0 0 4px #6366f180; }
.dot-green  { background: #16a34a; box-shadow: 0 0 4px #16a34a80; }
.dot-red    { background: #dc2626; box-shadow: 0 0 4px #dc262680; }
.dot-blue   { background: #0ea5e9; box-shadow: 0 0 4px #0ea5e980; }

/* File rows */
.file-row { border-bottom: 1px solid #f1f5f9; }
.file-row:last-child { border-bottom: none; }
.file-row-head {
  display: flex; align-items: center; gap: 8px;
  padding: 9px 16px; font-size: 13px;
}
.file-ext-badge {
  flex-shrink: 0; padding: 1px 7px; border-radius: 5px;
  font-size: 10px; font-weight: 700; letter-spacing: 0.5px;
}
.ext-cpp   { background: #e0e7ff; color: #3730a3; }
.ext-h     { background: #fef9c3; color: #854d0e; }
.ext-c     { background: #dcfce7; color: #166534; }
.ext-other { background: #f1f5f9; color: #475569; }
.ext-log   { background: #e0f2fe; color: #0369a1; }
.file-row-name { flex: 1; color: #374151; font-size: 12.5px; font-family: 'Consolas', monospace; }
.file-row-meta { font-size: 11px; color: #9ca3af; }

.icon-btn {
  flex-shrink: 0; padding: 3px 10px; border-radius: 6px;
  font-size: 11px; cursor: pointer; border: 1px solid; transition: all 0.15s;
  background: transparent;
}
.preview-btn { color: #6366f1; border-color: #c7d2fe; }
.preview-btn:hover { background: #eef2ff; }
.dl-btn2 { color: #0369a1; border-color: #bae6fd; }
.dl-btn2:hover { background: #f0f9ff; }

/* Code preview */
.code-preview { background: #0f172a; overflow: hidden; }
.code-header  { display: flex; align-items: center; justify-content: space-between; padding: 6px 14px; background: #1e293b; font-size: 11px; color: #94a3b8; }
.copy-sm-btn  { padding: 2px 8px; border: 1px solid #334155; border-radius: 4px; background: transparent; color: #94a3b8; font-size: 11px; cursor: pointer; transition: all 0.15s; }
.copy-sm-btn:hover { background: #334155; color: #e2e8f0; }
.code-block   {
  padding: 14px 16px; font-size: 11.5px;
  font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  line-height: 1.6; color: #e2e8f0;
  white-space: pre !important; word-break: normal; overflow-wrap: normal;
  margin: 0; max-height: 400px; overflow: auto;
  scrollbar-width: thin; scrollbar-color: #334155 transparent;
  display: block; tab-size: 4;
}

/* Build output */
.build-output {
  font-size: 11.5px; font-family: 'Consolas', monospace;
  white-space: pre !important; word-break: normal;
  padding: 14px 16px; margin: 0;
  max-height: 280px; overflow: auto; line-height: 1.6;
  display: block; tab-size: 4;
}
.build-ok  { background: #f8fffe; color: #065f46; }
.build-err { background: #fff8f8; color: #991b1b; }

/* CLI Summary — embedded inside Workflow Output card */
.summary-inner { padding-bottom: 4px; }
.summary-section { padding: 8px 16px 4px; }
.summary-section-last { padding-bottom: 12px; }
.summary-section-title {
  font-size: 11px; font-weight: 700; letter-spacing: 0.5px;
  color: #6366f1; text-transform: uppercase; margin-bottom: 6px;
}
.summary-list {
  list-style: none; padding: 0; margin: 0;
  display: flex; flex-direction: column; gap: 3px;
}
.summary-list li { font-size: 12.5px; color: #374151; line-height: 1.5; }
.summary-subsection {
  margin-bottom: 10px;
}
.summary-subsection:last-child {
  margin-bottom: 0;
}
.summary-subsection-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.35px;
  color: #4b5563;
  margin-bottom: 4px;
}
.summary-paragraph {
  margin: 0;
  max-width: 920px;
  padding: 10px 12px;
  border: 1px solid #eef2ff;
  border-radius: 8px;
  background: linear-gradient(180deg, #f8fafc 0%, #f9fafb 100%);
  font-size: 12.5px;
  color: #374151;
  line-height: 1.7;
  white-space: normal;
}
.issues-list li  { color: #b45309; }
.summary-kv {
  display: flex; gap: 8px; align-items: baseline;
  font-size: 12.5px; line-height: 1.7;
}
.summary-kv-key { color: #6b7280; min-width: 110px; }
.coverage-summary-table {
  width: 50%; table-layout: fixed; border-collapse: collapse; font-size: 12.5px; color: #374151;
}
.coverage-summary-table th,
.coverage-summary-table td {
  padding: 6px 8px; border: 1px solid #e5e7eb; text-align: left;
}
.coverage-summary-table th {
  background: #f9fafb; color: #6b7280; font-weight: 700;
}
.val-green  { color: #16a34a; font-weight: 600; }
.val-red    { color: #dc2626; font-weight: 600; }
.val-amber  { color: #d97706; font-weight: 600; }
.summary-divider { margin: 0 16px; border-top: 1px solid #e5e7eb; }
.log-loading { padding: 12px 16px; font-size: 12px; color: #9ca3af; font-style: italic; }

/* Error / failed */
.error-box {
  display: flex; align-items: flex-start; gap: 8px;
  padding: 12px 14px; background: #fef2f2; border: 1px solid #fecaca;
  border-radius: 8px; color: #991b1b; font-size: 13px;
}

.fail-area {
  display: flex; flex-direction: column; align-items: center;
  padding: 60px 20px; text-align: center;
}
.fail-msg    { font-size: 16px; font-weight: 600; color: #ef4444; margin-top: 12px; }
.fail-detail { font-size: 13px; color: #9ca3af; margin-top: 4px; max-width: 380px; word-break: break-word; }

/* Confirmation Dialog */
.confirm-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
}

.confirm-text {
  font-size: 15px;
  color: #374151;
  text-align: center;
  margin: 0;
}

.confirm-footer {
  display: flex;
  gap: 12px;
  justify-content: center;
}
</style>
