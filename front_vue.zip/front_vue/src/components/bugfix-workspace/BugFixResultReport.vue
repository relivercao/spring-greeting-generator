<template>
  <div class="result-content">
    <div class="result-heading">
      <div>
        <div class="result-kicker">
          ANALYSIS &amp; PATCH
        </div>
        <h2>Bug fix proposal</h2>
      </div>
      <div class="report-actions">
        <button
          v-if="showReset"
          type="button"
          class="quiet-button"
          @click="$emit('reset')"
        >
          <el-icon><RefreshLeft /></el-icon>New task
        </button>
        <button
          type="button"
          class="icon-button"
          title="Copy analysis report"
          aria-label="Copy analysis report"
          @click="copyReport"
        >
          <el-icon><CopyDocument /></el-icon>
        </button>
        <button
          class="icon-button"
          title="Download analysis report"
          aria-label="Download analysis report"
          @click="downloadReport"
        >
          <el-icon><Download /></el-icon>
        </button>
      </div>
    </div>

    <div class="result-meta">
      <span
        class="severity"
        :class="'severity-' + (result.severity || result.analysis?.severity || 'medium')"
      >
        {{ result.severity || result.analysis?.severity || 'medium' }}
      </span>
      <span>{{ result.files_analyzed ?? Object.keys(result.patches || {}).length }} source files
        analyzed</span>
      <span v-if="result.issue_id">{{ result.issue_id }}</span>
    </div>

    <div
      class="result-stats"
      aria-label="Bug fix result summary"
    >
      <div class="result-stat">
        <strong>{{ filesAnalyzed }}</strong>
        <span>Files analyzed</span>
      </div>
      <div class="result-stat">
        <strong>{{ patchEntries.length }}</strong>
        <span>Patches</span>
      </div>
      <div class="result-stat">
        <strong>{{ patchAttempts.length }}</strong>
        <span>Attempts</span>
      </div>
      <div
        class="result-stat"
        :class="{ attention: validationWarnings.length }"
      >
        <strong>{{ validationWarnings.length }}</strong>
        <span>Warnings</span>
      </div>
    </div>

    <div
      class="validation-banner"
      :class="{ attention: validationWarnings.length }"
      role="status"
    >
      <el-icon size="16">
        <WarningFilled v-if="validationWarnings.length" /><CircleCheck v-else />
      </el-icon>
      <div>
        <strong>{{ validationWarnings.length ? 'Review notes available' : 'No validation warnings returned' }}</strong>
        <span>{{ validationWarnings.length ? 'Check the notes before applying the generated patch.' : 'Review the proposed changes before applying them to the repository.' }}</span>
      </div>
    </div>

    <section class="result-section">
      <h3>Root cause</h3>
      <p class="preserve-lines">
        {{
          result.root_cause || result.analysis?.root_cause || 'No root cause was returned.'
        }}
      </p>
    </section>
    <section class="result-section">
      <h3>Fix approach</h3>
      <p class="preserve-lines">
        {{
          result.fix_approach ||
            result.analysis?.fix_approach ||
            result.patch_explanation ||
            'No fix approach was returned.'
        }}
      </p>
    </section>
    <section class="result-section">
      <h3>Affected files</h3>
      <div
        v-if="affectedFiles.length"
        class="file-list"
      >
        <code
          v-for="path in affectedFiles"
          :key="path"
        >{{ path }}</code>
      </div>
      <p
        v-else
        class="muted-copy"
      >
        No affected files identified.
      </p>
    </section>
    <section
      v-if="patchAttempts.length"
      class="result-section iteration-section"
    >
      <h3>Action and observation</h3>
      <p class="muted-copy iteration-note">
        Static structure checks only; no project build or runtime tests were executed.
      </p>
      <ol class="iteration-list">
        <li
          v-for="attempt in patchAttempts"
          :key="attempt.attempt"
        >
          <strong>Attempt {{ attempt.attempt }}: {{ attempt.validation }}</strong>
          <span>{{ attempt.patch_paths?.join(', ') || 'No patch files produced' }}</span>
          <ul v-if="attempt.validation_errors?.length">
            <li
              v-for="error in attempt.validation_errors"
              :key="error"
            >
              {{ error }}
            </li>
          </ul>
        </li>
      </ol>
    </section>
    <BugFixExpertReviews
      v-if="Array.isArray(result.expert_reviews)"
      :reviews="result.expert_reviews"
      :conflicts="result.expert_conflicts || []"
    />
    <section v-if="Object.keys(result.code_diffs || {}).length" class="result-section">
      <h3>Final code diffs</h3>
      <p class="muted-copy">Compared with the loaded source. Review the final explanation for how expert recommendations were reconciled.</p>
      <details v-for="(diff, path) in result.code_diffs" :key="path" class="patch-item">
        <summary><code>{{ path }}</code><button type="button" class="quiet-button" @click.stop.prevent="downloadPatch(path + '.diff', diff)">Download diff</button></summary>
        <pre><code>{{ diff }}</code></pre>
      </details>
    </section>
    <section class="result-section patch-section">
      <div class="patch-section-heading">
        <h3>Generated patches</h3>
        <span>{{ patchEntries.length }}</span>
      </div>
      <div
        v-if="patchEntries.length"
        class="patch-list"
      >
        <details
          v-for="([path, content], index) in patchEntries"
          :key="path"
          class="patch-item"
          :open="index === 0"
        >
          <summary>
            <code>{{ path }}</code>
            <span class="patch-actions">
              <button
                class="icon-button small"
                :title="'Copy ' + path"
                :aria-label="'Copy ' + path"
                @click.stop.prevent="copyPatch(path, content)"
              >
                <el-icon><CopyDocument /></el-icon>
              </button>
              <button
                class="icon-button small"
                :title="'Download ' + path"
                :aria-label="'Download ' + path"
                @click.stop.prevent="downloadPatch(path, content)"
              >
                <el-icon><Download /></el-icon>
              </button>
            </span>
          </summary>
          <pre><code>{{ content }}</code></pre>
        </details>
      </div>
      <p
        v-else
        class="muted-copy"
      >
        No patch content was generated.
      </p>
    </section>
    <section
      v-if="validationWarnings.length"
      class="result-section warnings-section"
    >
      <h3>Validation notes</h3>
      <ul>
        <li
          v-for="warning in validationWarnings"
          :key="warning"
        >
          {{ warning }}
        </li>
      </ul>
    </section>
    <section
      v-if="result.patch_explanation"
      class="result-section"
    >
      <h3>Patch explanation</h3>
      <p class="preserve-lines">
        {{ result.patch_explanation }}
      </p>
    </section>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import BugFixExpertReviews from './BugFixExpertReviews.vue'
import { ElMessage } from 'element-plus'
import { CircleCheck, CopyDocument, Download, RefreshLeft, WarningFilled } from '@element-plus/icons-vue'
const props = defineProps({
  result: { type: Object, required: true },
  showReset: { type: Boolean, default: true },
})
defineEmits(['reset'])
const result = computed(() => props.result)
const patchEntries = computed(() => Object.entries(result.value?.patches || {}))
const affectedFiles = computed(() => {
  const files = result.value?.analysis?.affected_files || result.value?.source_files || []
  return [...new Set(files)]
})
const validationWarnings = computed(() => result.value?.validation_warnings || [])
const patchAttempts = computed(() => result.value?.patch_attempt_history || [])
const filesAnalyzed = computed(() =>
  result.value?.files_analyzed ?? affectedFiles.value.length ?? patchEntries.value.length
)

function reportContent() {
  return (
    result.value?.report_markdown ||
    [
      '# Bug Fix Proposal',
      '',
      `Root cause: ${result.value?.root_cause || ''}`,
      '',
      `Fix approach: ${result.value?.fix_approach || ''}`,
      '',
      ...(result.value?.expert_reviews || []).flatMap(review => [
        `## Module expert: ${review.skill} (${review.module})`,
        '',
        `Status: ${review.status}`,
        review.summary || '',
        review.fix_logic || '',
        ...(review.findings || []).flatMap(finding => [
          `### ${finding.file}${finding.line ? `:${finding.line}` : ''}: ${finding.problem}`,
          `Source quote verified: ${Boolean(finding.evidence_verified)}`,
          '````text', finding.evidence, '````',
          `Fix logic: ${finding.fix_logic}`,
          `Risk: ${finding.risk || ''}`,
        ]),
        ...Object.entries(review.code_diffs || {}).flatMap(([path, diff]) => [
          `### Expert candidate diff: ${path}`, '````diff', diff, '````', '',
        ]),
        ...(review.verification || []).map(check => `Proposed verification (not executed): ${check}`),
        ...(review.warnings || []).map(warning => `Review warning: ${warning}`),
        '',
      ]),
      ...(result.value?.expert_conflicts || []).map(conflict =>
        `Proposal conflict: ${conflict.file} (${conflict.skills.join(', ')}): ${conflict.message}`
      ),
      ...Object.entries(result.value?.code_diffs || {}).flatMap(([path, diff]) => [
        `## Final code diff: ${path}`, '', '````diff', diff, '````', '',
      ]),
      ...patchEntries.value.flatMap(([path, content]) => [
        `## ${path}`,
        '',
        '```',
        content,
        '```',
        '',
      ]),
    ].join('\n')
  )
}

function downloadText(name, content, type = 'text/plain') {
  const url = globalThis.URL.createObjectURL(new globalThis.Blob([content], { type }))
  const anchor = globalThis.document.createElement('a')
  anchor.href = url
  anchor.download = name
  anchor.click()
  globalThis.URL.revokeObjectURL(url)
}

function downloadReport() {
  downloadText('bugfix-report.md', reportContent(), 'text/markdown')
}

async function copyReport() {
  try {
    await globalThis.navigator.clipboard.writeText(reportContent())
    ElMessage.success('Analysis report copied.')
  } catch {
    ElMessage.error('Could not copy the analysis report.')
  }
}

function downloadPatch(path, content) {
  const safeName = path.replace(/[\\/:*?"<>|]/g, '_')
  downloadText(safeName, content)
}

async function copyPatch(path, content) {
  try {
    await globalThis.navigator.clipboard.writeText(content)
    ElMessage.success(`${path} copied.`)
  } catch {
    ElMessage.error('Could not copy patch content.')
  }
}
</script>

<style scoped>
* { box-sizing: border-box; }
.result-content {
  flex: 1; min-height: 0; overflow-y: auto; padding: 24px; background: white;
  border: 1px solid #e8ecf1; border-radius: 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);
  scrollbar-width: thin; scrollbar-color: #cbd5e1 transparent;
}
.report-actions { display: flex; align-items: center; gap: 8px; }
.quiet-button, .icon-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  border: 1px solid #dfe4eb;
  border-radius: 6px;
  background: #fff;
  color: #475569;
  cursor: pointer;
}
.quiet-button {
  min-height: 32px;
  padding: 0 10px;
  font-size: 12px;
}
.quiet-button:hover,
.icon-button:hover {
  background: #f8fafc;
  border-color: #c8d0db;
}

.result-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding-bottom: 15px;
  border-bottom: 1px solid #e2e7ed;
}
.result-kicker {
  margin-bottom: 5px;
  color: #8b95a3;
  font-size: 9px;
  font-weight: 700;
}
.result-heading h2 {
  margin: 0;
  color: #253247;
  font-size: 18px;
}
.icon-button {
  width: 30px;
  height: 30px;
  flex: 0 0 30px;
  font-size: 14px;
}
.icon-button.small {
  width: 26px;
  height: 26px;
  flex-basis: 26px;
  border-color: transparent;
}
.result-meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 14px;
  margin: 13px 0 18px;
  color: #6b7280;
  font-size: 10px;
}
.result-stats {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px;
  margin: 0 0 10px;
}
.result-stat {
  min-width: 0;
  padding: 8px 9px;
  border: 1px solid #e6eaf0;
  border-radius: 7px;
  background: #f8fafc;
}
.result-stat strong,
.result-stat span {
  display: block;
}
.result-stat strong {
  color: #253247;
  font-size: 15px;
  line-height: 1.15;
}
.result-stat span {
  margin-top: 3px;
  overflow: hidden;
  color: #7b8797;
  font-size: 9px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.result-stat.attention {
  border-color: #fde68a;
  background: #fffbeb;
}
.result-stat.attention strong,
.result-stat.attention span {
  color: #92400e;
}
.validation-banner {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  margin: 0 0 4px;
  padding: 9px 10px;
  border: 1px solid #bbf7d0;
  border-radius: 7px;
  color: #047857;
  background: #f0fdf4;
}
.validation-banner.attention {
  border-color: #fde68a;
  color: #92400e;
  background: #fffbeb;
}
.validation-banner > .el-icon {
  flex: 0 0 auto;
  margin-top: 1px;
}
.validation-banner strong,
.validation-banner span {
  display: block;
}
.validation-banner strong {
  font-size: 11px;
  line-height: 1.3;
}
.validation-banner span {
  margin-top: 2px;
  color: #64748b;
  font-size: 10px;
  line-height: 1.4;
}
.severity {
  padding: 3px 7px;
  border-radius: 4px;
  background: #eef2f7;
  color: #475569;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
}
.severity-high,
.severity-critical {
  background: #fee2e2;
  color: #b91c1c;
}
.severity-medium {
  background: #fef3c7;
  color: #92400e;
}
.severity-low {
  background: #dcfce7;
  color: #166534;
}
.result-section {
  padding: 13px 0;
  border-bottom: 1px solid #e8ecf1;
}
.result-section h3 {
  margin: 0 0 8px;
  color: #344054;
  font-size: 12px;
  font-weight: 650;
}
.result-section p {
  margin: 0;
  color: #536174;
  font-size: 12px;
  line-height: 1.65;
}
.preserve-lines {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.muted-copy {
  color: #8b95a3 !important;
}
.file-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.file-list code,
.patch-item summary code {
  max-width: 100%;
  overflow-wrap: anywhere;
  border: 1px solid #e2e7ed;
  border-radius: 4px;
  background: #f8fafc;
  color: #334155;
  font-family: Consolas, monospace;
  font-size: 10px;
}
.file-list code {
  padding: 4px 6px;
}
.patch-section-heading {
  display: flex;
  align-items: center;
  gap: 7px;
}
.patch-section-heading span {
  display: grid;
  min-width: 18px;
  height: 18px;
  place-items: center;
  border-radius: 9px;
  background: #edf0f4;
  color: #64748b;
  font-size: 10px;
}
.patch-list {
  display: grid;
  gap: 8px;
}
.patch-item {
  overflow: hidden;
  border: 1px solid #e1e6ed;
  border-radius: 6px;
  background: #fff;
}
.patch-item summary {
  display: flex;
  min-height: 38px;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 5px 8px 5px 10px;
  cursor: pointer;
  list-style: none;
}
.patch-item summary::-webkit-details-marker {
  display: none;
}
.patch-item summary code {
  padding: 4px 6px;
  border: 0;
  background: transparent;
}
.patch-actions {
  display: flex;
  flex: 0 0 auto;
  gap: 3px;
}
.patch-item pre {
  overflow: auto;
  max-height: 400px;
  margin: 0;
  padding: 12px;
  border-top: 1px solid #e8ecf1;
  background: #f8fafc;
  color: #263244;
  font:
    11px/1.55 Consolas,
    monospace;
  tab-size: 4;
}
.patch-item pre code {
  white-space: pre;
}
.warnings-section {
  border-bottom: 0;
}
.warnings-section ul {
  display: grid;
  gap: 6px;
  margin: 0;
  padding-left: 18px;
  color: #8a5a00;
  font-size: 11px;
  line-height: 1.5;
}
.iteration-note { margin-bottom: 8px !important; }
.iteration-list {
  display: grid;
  gap: 8px;
  margin: 0;
  padding-left: 20px;
  color: #536174;
  font-size: 11px;
  line-height: 1.5;
}
.iteration-list > li > strong,
.iteration-list > li > span { display: block; }
.iteration-list > li > strong { color: #344054; }
.iteration-list ul { margin-top: 3px; padding-left: 16px; color: #8a5a00; }

@media (max-width: 560px) {
  .result-content { padding: 16px; }
  .result-heading { flex-wrap: wrap; }
  .report-actions { width: 100%; justify-content: flex-end; }
  .result-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
</style>
