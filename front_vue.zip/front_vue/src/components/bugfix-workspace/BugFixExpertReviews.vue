<template>
  <section class="expert-reviews" aria-label="Module expert reviews">
    <h3>Module expert analysis</h3>
    <p class="review-notice">
      Independent skill-based proposals. Evidence checks compare source text; candidate diffs have
      not been applied, built, or tested.
    </p>
    <p v-if="!reviews.length">No applicable module expert review is available for this task.</p>
    <article v-for="review in reviews" :key="review.skill" class="expert-card">
      <header>
        <div>
          <strong>{{ review.skill }}</strong
          ><span>{{ review.module }}</span>
        </div>
        <span class="expert-status" :class="review.status">{{ review.status }}</span>
      </header>
      <p>{{ review.summary }}</p>
      <ul v-if="review.selection_reasons?.length" class="selection-reasons">
        <li v-for="reason in review.selection_reasons" :key="reason">{{ reason }}</li>
      </ul>
      <h4 v-if="review.fix_logic">Expert fix logic</h4>
      <p v-if="review.fix_logic" class="preserve-lines">{{ review.fix_logic }}</p>
      <ol v-if="review.findings?.length" class="findings">
        <li v-for="(finding, index) in review.findings" :key="index">
          <div class="finding-location">
            <code>{{ finding.file }}{{ finding.line ? `:${finding.line}` : '' }}</code
            ><span :class="finding.evidence_verified ? 'verified' : 'unverified'">{{
              finding.evidence_verified ? 'Source quote verified' : 'Evidence needs review'
            }}</span>
          </div>
          <h4>{{ finding.problem }}</h4>
          <pre><code>{{ finding.evidence }}</code></pre>
          <p><strong>Fix logic:</strong> {{ finding.fix_logic }}</p>
          <p v-if="finding.risk"><strong>Risk:</strong> {{ finding.risk }}</p>
        </li>
      </ol>
      <p v-else-if="review.status === 'completed'">
        No supported problem points were identified by this expert.
      </p>
      <h4 v-if="Object.keys(review.code_diffs || {}).length">Expert candidate code diffs</h4>
      <details v-for="(diff, path) in review.code_diffs || {}" :key="path" class="diff-item">
        <summary>
          <code>{{ path }}</code
          ><button
            type="button"
            :aria-label="`Download ${review.skill} diff for ${path}`"
            @click.stop.prevent="downloadDiff(review.skill, path, diff)"
          >
            Download diff
          </button>
        </summary>
        <pre><code>{{ diff }}</code></pre>
      </details>
      <p
        v-if="review.status === 'completed' && !Object.keys(review.code_diffs || {}).length"
        class="review-notice"
      >
        No changed candidate file was returned for a source-backed diff.
      </p>
      <template v-if="review.verification?.length"
        ><h4>Proposed verification (not executed)</h4>
        <ul>
          <li v-for="check in review.verification" :key="check">{{ check }}</li>
        </ul></template
      >
      <ul v-if="review.warnings?.length" class="review-warnings">
        <li v-for="warning in review.warnings" :key="warning">{{ warning }}</li>
      </ul>
    </article>
    <div v-if="conflicts.length" class="review-warnings" role="status">
      <h4>Expert proposal conflicts</h4>
      <p v-for="conflict in conflicts" :key="conflict.file">
        <code>{{ conflict.file }}</code> · {{ conflict.skills.join(', ') }}: {{ conflict.message }}
      </p>
    </div>
  </section>
</template>

<script setup>
defineProps({
  reviews: { type: Array, default: () => [] },
  conflicts: { type: Array, default: () => [] },
})

function downloadDiff(skill, path, content) {
  const url = globalThis.URL.createObjectURL(new Blob([content], { type: 'text/x-diff' }))
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = `${skill}-${path}.diff`.replace(/[\\/:*?"<>|]/g, '_')
  anchor.click()
  globalThis.URL.revokeObjectURL(url)
}
</script>

<style scoped>
.expert-reviews {
  padding: 20px 0;
  border-top: 1px solid #e2e8f0;
  color: #334155;
}
h3 {
  margin: 0 0 10px;
  font-size: 14px;
}
h4 {
  margin: 12px 0 6px;
  font-size: 12px;
}
p,
li {
  font-size: 12px;
  line-height: 1.65;
  overflow-wrap: anywhere;
}
.review-notice,
.selection-reasons {
  color: #64748b;
  font-size: 11px;
}
.expert-card {
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  margin-top: 12px;
  padding: 14px;
}
header,
.finding-location,
summary {
  display: flex;
  gap: 10px;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
}
header > div {
  display: flex;
  gap: 8px;
  align-items: center;
  font-size: 12px;
  flex-wrap: wrap;
  overflow-wrap: anywhere;
}
header > div > span {
  color: #64748b;
}
.expert-status {
  font-size: 10px;
  border-radius: 12px;
  padding: 3px 8px;
  background: #fff7d6;
  color: #92400e;
}
.expert-status.completed {
  background: #dcfce7;
  color: #166534;
}
.expert-status.failed {
  background: #fee2e2;
  color: #b91c1c;
}
.findings {
  padding-left: 20px;
}
.findings > li {
  margin: 14px 0;
}
.finding-location {
  font-size: 10px;
}
.verified {
  color: #15803d;
}
.unverified {
  color: #b45309;
}
pre {
  overflow: auto;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 7px;
  padding: 10px;
  font:
    11px/1.6 Consolas,
    monospace;
  max-height: 360px;
}
.diff-item {
  margin: 8px 0;
}
summary {
  cursor: pointer;
  font-size: 11px;
}
summary code {
  overflow-wrap: anywhere;
}
button {
  cursor: pointer;
  background: white;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  padding: 4px 8px;
  font: inherit;
  color: #1d4ed8;
}
.review-warnings {
  background: #fffbeb;
  color: #92400e;
  border-radius: 8px;
  padding: 10px 20px;
}
.preserve-lines {
  white-space: pre-wrap;
}
</style>
