<template>
  <section
    class="input-section"
    aria-label="Jira bug source"
  >
    <div class="input-section-header">
      <div>
        <p class="eyebrow eyebrow-blue">
          Jira Bug
        </p>
        <h3>Select a ticket to start a repair task</h3>
      </div>
      <span
        class="connection-state"
        :class="{ unavailable: integration?.available === false, checking: !integration }"
      >
        <span class="state-dot" />{{ !integration ? 'Checking' : integration.available ? 'Configured' : 'Not configured' }}
      </span>
    </div>
    <div class="input-section-body">
      <label
        for="bugfix-jira-query"
        class="input-label"
      >Filter by project or issue key</label>
      <div class="query-row">
        <input
          id="bugfix-jira-query"
          v-model="query"
          class="text-input"
          placeholder="Project key or FW-123"
          :disabled="disabled"
          @input="invalidateSelection"
          @keyup.enter="searchBugs"
        >
        <button
          type="button"
          class="load-button"
          :disabled="disabled || loading"
          @click="searchBugs"
        >
          {{ loading ? 'Loading...' : query.trim() ? 'Search' : 'Refresh' }}
        </button>
      </div>
      <p
        v-if="integration?.available === false"
        class="field-hint"
      >
        Configure Jira in the backend integration settings to load Bug tickets.
      </p>
      <div
        v-else
        class="field-hint"
      >
        Recent Jira Bugs load automatically. Enter a project key to filter, or an issue key to open directly.
      </div>
      <p
        v-if="errorMessage"
        class="field-error"
        role="alert"
      >
        {{ errorMessage }}
      </p>
      <div class="jira-browser">
        <section
          class="ticket-results"
          aria-label="Jira Bug tickets"
        >
          <div class="ticket-list-heading">
            <span>{{ query.trim() ? `Bugs in ${query.trim().toUpperCase()}` : 'Recent Jira Bugs' }}</span>
            <span>{{ issues.length }} shown</span>
          </div>
          <label v-if="multiple && issues.length" class="batch-selection-heading">
            <input
              type="checkbox"
              aria-label="Select all visible Jira Bugs"
              :checked="issues.every(issue => batchIssues.has(issue.key))"
              :disabled="disabled || loading"
              @change="toggleVisibleIssues($event.target.checked)"
            >
            Select visible · {{ batchIssues.size }} selected
          </label>
          <div
            v-if="issues.length"
            class="ticket-list"
          >
            <div
              v-for="issue in issues"
              :key="issue.key"
              class="jira-ticket-row"
            >
              <input
                v-if="multiple"
                type="checkbox"
                :aria-label="`Select ${issue.key}`"
                :checked="batchIssues.has(issue.key)"
                :disabled="disabled || loading"
                @change="toggleBatchIssue(issue, $event.target.checked)"
              >
              <button
              type="button"
              class="ticket-option"
              :class="{ selected: selectedIssue?.key === issue.key || pendingIssueKey === issue.key }"
              :aria-pressed="selectedIssue?.key === issue.key"
              :disabled="disabled || loading"
              @click="selectIssue(issue.key)"
            >
              <span
                class="bug-type-mark"
                aria-label="Bug issue type"
              ><el-icon><WarningFilled /></el-icon></span>
              <span class="ticket-option-copy">
                <strong class="ticket-option-summary">{{ issue.summary || 'Untitled Jira issue' }}</strong>
                <span class="ticket-option-meta">
                  <code>{{ issue.key }}</code>
                  <span
                    v-if="issue.priority"
                    class="priority-label"
                    :class="priorityTone(issue.priority)"
                  >{{ issue.priority }}</span>
                  <span
                    v-if="issue.assignee"
                    class="ticket-assignee"
                  >{{ issue.assignee }}</span>
                </span>
              </span>
              <span
                class="status-badge"
                :class="statusTone(issue.status)"
              >{{ issue.status || 'Unresolved' }}</span>
              </button>
            </div>
          </div>
          <div
            v-else
            class="ticket-list-empty"
            role="status"
          >
            <el-icon><WarningFilled /></el-icon>
            <strong>{{ loading ? 'Loading Jira Bugs' : integration?.available === false ? 'Jira is not connected' : searched ? 'No Jira Bugs found' : 'No tickets loaded' }}</strong>
          </div>
        </section>

        <article
          class="ticket-preview"
          aria-label="Jira Bug details"
          aria-live="polite"
        >
          <template v-if="selectedIssue">
            <div class="issue-detail-header">
              <div class="issue-breadcrumb">
                <span class="bug-type-label"><el-icon><WarningFilled /></el-icon>Bug</span>
                <span class="breadcrumb-divider">/</span>
                <code>{{ selectedIssue.key }}</code>
              </div>
              <span
                class="status-badge"
                :class="statusTone(selectedIssue.status)"
              >{{ selectedIssue.status || 'Unresolved' }}</span>
            </div>
            <h4>{{ selectedIssue.summary || 'Untitled Jira issue' }}</h4>
            <div class="ticket-fields">
              <div class="ticket-field">
                <span>Priority</span><strong
                  class="priority-label"
                  :class="priorityTone(selectedIssue.priority)"
                >{{ selectedIssue.priority || 'Not set' }}</strong>
              </div>
              <div class="ticket-field">
                <span>Assignee</span><strong>{{ selectedIssue.assignee || 'Unassigned' }}</strong>
              </div>
              <div class="ticket-field">
                <span>Updated</span><strong>{{ formatDate(selectedIssue.updated) }}</strong>
              </div>
            </div>
            <section class="ticket-description">
              <h5>Description</h5>
              <p>{{ selectedIssue.description || 'This ticket has no description.' }}</p>
            </section>
            <div
              v-if="pendingIssueKey"
              class="detail-loading"
              role="status"
            >
              Loading {{ pendingIssueKey }}...
            </div>
          </template>
          <div
            v-else-if="pendingIssueKey"
            class="ticket-detail-empty"
            role="status"
          >
            <span class="detail-key">{{ pendingIssueKey }}</span>
            <strong>Loading ticket details</strong>
            <span>Retrieving the Jira issue description and fields.</span>
          </div>
          <div
            v-else-if="errorMessage"
            class="ticket-detail-empty detail-error"
            role="alert"
          >
            <strong>Ticket details unavailable</strong>
            <span>{{ errorMessage }}</span>
          </div>
          <div
            v-else
            class="ticket-detail-empty"
          >
            <div class="issue-detail-header">
              <div class="issue-breadcrumb">
                <span class="bug-type-label"><el-icon><WarningFilled /></el-icon>Bug</span>
                <span class="breadcrumb-divider">/</span>
                <code>—</code>
              </div>
              <span class="status-badge">Not selected</span>
            </div>
            <h4>{{ integration?.available === false ? 'Jira connection required' : issues.length ? 'No issue selected' : 'No issue loaded' }}</h4>
            <div class="ticket-fields ticket-field-placeholders">
              <div class="ticket-field">
                <span>Priority</span><strong>—</strong>
              </div>
              <div class="ticket-field">
                <span>Assignee</span><strong>—</strong>
              </div>
              <div class="ticket-field">
                <span>Updated</span><strong>—</strong>
              </div>
            </div>
            <section class="ticket-description">
              <h5>Description</h5>
              <p>—</p>
            </section>
          </div>
        </article>
      </div>
    </div>
  </section>
</template>

<script setup>
import { onBeforeUnmount, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { WarningFilled } from '@element-plus/icons-vue'
import { apiGetJiraBug, apiGetJiraBugs } from '../../api/bugfix.js'

const props = defineProps({
  integration: { type: Object, default: null },
  disabled: { type: Boolean, default: false },
  multiple: { type: Boolean, default: false },
})
const route = useRoute()
const emit = defineEmits(['selected', 'batch-selected'])
const batchIssues = ref(new Map())

function toggleBatchIssue(issue, checked) {
  if (props.disabled) return
  const next = new Map(batchIssues.value)
  if (checked) next.set(issue.key, { key: issue.key, summary: issue.summary })
  else next.delete(issue.key)
  batchIssues.value = next
  emit('batch-selected', [...next.values()])
}

function toggleVisibleIssues(checked) {
  if (props.disabled) return
  for (const issue of issues.value) toggleBatchIssue(issue, checked)
}
const query = ref('')
const loading = ref(false)
const searched = ref(false)
const issues = ref([])
const selectedIssue = ref(null)
const pendingIssueKey = ref('')
const errorMessage = ref('')
let requestVersion = 0
let autoLoadAttempts = 0
let autoLoadTimer = null
let autoIssueKey = ''

const AUTO_LOAD_RETRY_LIMIT = 3
const AUTO_LOAD_RETRY_DELAY_MS = 1500

watch(() => props.integration?.project, project => {
  const configuredProject = String(project || '').trim().toUpperCase()
  if (configuredProject && !query.value) query.value = configuredProject
}, { immediate: true })

onBeforeUnmount(() => {
  requestVersion += 1
  if (autoLoadTimer) {
    globalThis.clearTimeout(autoLoadTimer)
    autoLoadTimer = null
  }
})

watch(() => [props.integration?.available, route.query.issue, props.disabled, loading.value], ([available, issue, disabled]) => {
  if (!available) {
    autoLoadAttempts = 0
    autoIssueKey = ''
    if (autoLoadTimer) {
      globalThis.clearTimeout(autoLoadTimer)
      autoLoadTimer = null
    }
    return
  }
  if (disabled) return
  const issueKey = String(issue || '').trim().toUpperCase()
  if (/^[A-Z][A-Z0-9_]*-[1-9][0-9]*$/.test(issueKey)) {
    query.value = issueKey
    if (!loading.value && autoIssueKey !== issueKey) {
      autoIssueKey = issueKey
      if (autoLoadTimer) {
        globalThis.clearTimeout(autoLoadTimer)
        autoLoadTimer = null
      }
      void selectIssue(issueKey)
    }
    return
  }
  autoIssueKey = ''
  scheduleAutoLoad()
}, { immediate: true })

function invalidateSelection() {
  requestVersion += 1
  if (autoLoadTimer) {
    globalThis.clearTimeout(autoLoadTimer)
    autoLoadTimer = null
  }
  loading.value = false
  searched.value = false
  issues.value = []
  selectedIssue.value = null
  pendingIssueKey.value = ''
  errorMessage.value = ''
  emit('selected', null)
}

async function searchBugs() {
  if (props.disabled || loading.value) return
  const key = query.value.trim().toUpperCase()
  if (key && !/^[A-Z][A-Z0-9_]*(?:-[1-9][0-9]*)?$/.test(key)) {
    errorMessage.value = 'Enter a project key such as FW or a Bug ticket key such as FW-123.'
    return
  }
  if (key.includes('-')) return selectIssue(key)
  const version = ++requestVersion
  let retryAutomaticLoad = false
  loading.value = true
  errorMessage.value = ''
  selectedIssue.value = null
  pendingIssueKey.value = ''
  emit('selected', null)
  try {
    const data = await apiGetJiraBugs(key)
    if (version !== requestVersion) return
    issues.value = data.issues || []
    searched.value = true
    autoLoadAttempts = AUTO_LOAD_RETRY_LIMIT
  } catch (error) {
    if (version === requestVersion) {
      errorMessage.value = error.message || 'Could not load Jira Bugs.'
      retryAutomaticLoad = true
    }
  } finally {
    if (version === requestVersion) {
      loading.value = false
      if (retryAutomaticLoad) scheduleAutoLoad()
    }
  }
}

function scheduleAutoLoad() {
  if (
    props.disabled ||
    props.integration?.available !== true ||
    loading.value ||
    searched.value ||
    autoLoadAttempts >= AUTO_LOAD_RETRY_LIMIT
  ) return

  autoLoadAttempts += 1
  if (autoLoadTimer) globalThis.clearTimeout(autoLoadTimer)
  autoLoadTimer = globalThis.setTimeout(() => {
    autoLoadTimer = null
    void searchBugs()
  }, autoLoadAttempts === 1 ? 0 : AUTO_LOAD_RETRY_DELAY_MS)
}

async function selectIssue(key) {
  if (props.disabled || loading.value) return
  const version = ++requestVersion
  loading.value = true
  pendingIssueKey.value = key
  errorMessage.value = ''
  try {
    const ticket = await apiGetJiraBug(key)
    if (version !== requestVersion) return
    const requestedIssue = String(route.query.issue || '').trim().toUpperCase()
    if (autoIssueKey === key && requestedIssue && requestedIssue !== key) return
    selectedIssue.value = ticket
    if (props.multiple && !issues.value.some(issue => issue.key === ticket.key)) {
      issues.value = [ticket, ...issues.value]
      toggleBatchIssue(ticket, true)
    }
    pendingIssueKey.value = ''
    emit('selected', ticket)
  } catch (error) {
    if (version === requestVersion) errorMessage.value = error.message || 'Could not load the Jira Bug.'
  } finally {
    if (version === requestVersion) {
      loading.value = false
      pendingIssueKey.value = ''
    }
  }
}

function statusTone(status) {
  const normalized = String(status || '').toLowerCase()
  if (/done|closed|resolved|complete/.test(normalized)) return 'status-done'
  if (/progress|review|testing/.test(normalized)) return 'status-active'
  if (/blocked|rejected|failed/.test(normalized)) return 'status-blocked'
  return 'status-open'
}

function priorityTone(priority) {
  const normalized = String(priority || '').toLowerCase()
  if (/blocker|critical|highest|major|high/.test(normalized)) return 'priority-high'
  if (/low|minor|trivial/.test(normalized)) return 'priority-low'
  return 'priority-medium'
}

function formatDate(value) {
  if (!value) return 'Not available'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat('en-US', { day: '2-digit', month: 'short', year: 'numeric' }).format(date)
}
</script>

<style scoped src="./bugfix-input.css"></style>
<style scoped>
.jira-ticket-row { display: flex; align-items: center; gap: 8px; }
.jira-ticket-row .ticket-option { flex: 1; min-width: 0; }
.batch-selection-heading { display: flex; align-items: center; gap: 8px; padding: 8px; color: #475569; font-size: 12px; }
.input-section { container-type: inline-size; }
.query-row { display: flex; gap: 8px; }
.jira-browser {
  display: grid;
  grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr);
  min-width: 0;
  min-height: 248px;
  border: 1px solid #dfe3e8;
  border-radius: 6px;
  overflow: hidden;
  background: #fff;
}
.ticket-results { display: flex; min-width: 0; flex-direction: column; border-right: 1px solid #dfe3e8; background: #f7f8f9; }
.load-button {
  flex-shrink: 0; padding: 0 14px; border: 1px solid #dfe3e8; border-radius: 6px;
  color: #475569; background: white; font: inherit; font-size: 12px; font-weight: 600; cursor: pointer;
}
.load-button:hover:not(:disabled) { color: #2563eb; border-color: #93c5fd; }
.load-button:disabled, .ticket-option:disabled { opacity: 0.6; cursor: not-allowed; }
.ticket-list { display: grid; min-height: 0; max-height: 300px; overflow-y: auto; scrollbar-width: thin; }
.ticket-list-heading { position: sticky; top: 0; z-index: 1; display: flex; min-height: 34px; justify-content: space-between; align-items: center; gap: 8px; padding: 7px 9px; border-bottom: 1px solid #dfe3e8; color: #44546f; background: #f7f8f9; font-size: 10px; font-weight: 700; }
.ticket-list-heading span:last-child { color: #6b778c; font-size: 10px; font-weight: 500; }
.ticket-list-empty { display: flex; min-height: 212px; flex: 1; flex-direction: column; justify-content: center; align-items: center; gap: 7px; padding: 18px 14px; color: #6b778c; text-align: center; }
.ticket-list-empty .el-icon { color: #7a869a; font-size: 20px; }
.ticket-list-empty strong { color: #44546f; font-size: 11px; }
.ticket-list-empty span { font-size: 10px; line-height: 1.5; }
.ticket-option {
  display: grid; grid-template-columns: 16px minmax(0, 1fr) auto; align-items: start; gap: 8px;
  min-width: 0; padding: 10px 8px; border: 0; border-bottom: 1px solid #e9ebee;
  text-align: left; color: #44546f; background: white; font: inherit; font-size: 12px; cursor: pointer; overflow-wrap: anywhere;
}
.ticket-option:hover { background: #f7f8f9; }
.ticket-option.selected { background: #e9f2fe; box-shadow: inset 3px 0 #0c66e4; }
.bug-type-mark, .bug-type-label { color: #c9372c; }
.bug-type-mark { display: inline-flex; padding-top: 2px; }
.ticket-option-copy { display: grid; min-width: 0; gap: 4px; }
.ticket-option-summary { color: #172b4d; font-size: 11px; font-weight: 600; line-height: 1.4; }
.ticket-option-meta { display: flex; flex-wrap: wrap; align-items: center; gap: 7px; color: #6b778c; font-size: 10px; }
.ticket-option-meta code, .issue-breadcrumb code { color: #44546f; font-family: inherit; font-size: 10px; line-height: 1.4; }
.ticket-assignee { min-width: 0; overflow-wrap: anywhere; }
.status-badge { display: inline-flex; align-items: center; max-width: 110px; padding: 3px 6px; border: 0; border-radius: 3px; color: #44546f; background: #e9ebee; font-size: 9px; font-weight: 700; line-height: 1.2; text-transform: uppercase; overflow-wrap: anywhere; }
.status-open { color: #0747a6; background: #deebff; }
.status-active { color: #164b35; background: #dcfff1; }
.status-done { color: #216e4e; background: #dcfff1; }
.status-blocked { color: #ae2e24; background: #ffeceb; }
.priority-label { color: #44546f; font-size: 10px; font-weight: 600; }
.priority-high { color: #c9372c; }
.priority-medium { color: #974f0c; }
.priority-low { color: #216e4e; }
.ticket-preview { position: relative; display: flex; min-width: 0; flex-direction: column; padding: 11px 12px; overflow-y: auto; scrollbar-width: thin; }
.issue-detail-header { display: flex; min-width: 0; justify-content: space-between; align-items: flex-start; gap: 8px; }
.issue-breadcrumb { display: flex; align-items: center; gap: 8px; color: #6b778c; font-size: 11px; }
.bug-type-label { display: inline-flex; align-items: center; gap: 4px; font-weight: 700; }
.breadcrumb-divider { color: #a5adba; }
.ticket-preview h4 { margin: 10px 0 14px; color: #172b4d; font-size: 14px; line-height: 1.45; overflow-wrap: anywhere; }
.ticket-fields { display: grid; grid-template-columns: minmax(0, 1fr); gap: 7px; padding: 10px 0; border-top: 1px solid #dfe3e8; border-bottom: 1px solid #dfe3e8; }
.ticket-field { display: grid; min-width: 0; grid-template-columns: 62px minmax(0, 1fr); align-items: center; gap: 6px; }
.ticket-field > span { color: #6b778c; font-size: 10px; }
.ticket-field > strong { min-width: 0; color: #44546f; font-size: 10px; font-weight: 600; overflow-wrap: anywhere; }
.ticket-field .status-badge { justify-self: start; }
.ticket-description { margin-top: 12px; color: #44546f; font-size: 11px; }
.ticket-description h5 { margin: 0; color: #172b4d; font-size: 11px; }
.ticket-description p { max-height: 180px; overflow-y: auto; margin: 8px 0 0; white-space: pre-wrap; overflow-wrap: anywhere; line-height: 1.6; }
.ticket-detail-empty { display: flex; min-height: 212px; flex: 1; flex-direction: column; justify-content: center; align-items: flex-start; gap: 8px; color: #6b778c; }
.ticket-detail-empty strong { color: #44546f; font-size: 12px; }
.ticket-detail-empty .ticket-field-placeholders { width: 100%; }
.detail-key { color: #44546f; font-size: 10px; font-weight: 700; }
.detail-error > span:last-child { color: #ae2e24; overflow-wrap: anywhere; }
.detail-loading { position: sticky; bottom: 0; margin: auto -12px -11px; padding: 7px 12px; border-top: 1px solid #dfe3e8; color: #44546f; background: rgba(255, 255, 255, 0.96); font-size: 10px; }
@container (max-width: 520px) {
  .jira-browser { grid-template-columns: minmax(0, 1fr); }
  .ticket-results { border-right: 0; border-bottom: 1px solid #dfe3e8; }
  .ticket-list { max-height: 200px; }
  .ticket-list-empty { min-height: 110px; }
  .ticket-preview { min-height: 180px; }
  .ticket-detail-empty { min-height: 150px; }
}
@media (max-width: 560px) {
  .ticket-option { grid-template-columns: 14px minmax(0, 1fr); }
  .ticket-option > .status-badge { grid-column: 2; justify-self: start; }
}
</style>
