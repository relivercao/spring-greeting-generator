<template>
  <article
    class="agent-card"
    :style="{ '--agent-color': agent.color }"
    role="button"
    tabindex="0"
    :aria-label="`Open ${agent.name}`"
    @click="$emit('click', agent)"
    @keydown.enter="$emit('click', agent)"
    @keydown.space.prevent="$emit('click', agent)"
  >
    <div class="card-visual">
      <AgentMascot
        v-if="hasAgentMascot(agent)"
        :agent="agent"
        size="feature"
      />
      <img
        v-else-if="agent.logo_url"
        class="card-logo"
        :src="agent.logo_url"
        :alt="`${agent.name} logo`"
      >
      <div
        v-else
        class="card-icon-fallback"
      >
        <el-icon
          size="28"
          :style="{ color: agent.color }"
        >
          <component :is="agent.icon" />
        </el-icon>
      </div>
      <div class="card-visual-overlay" />
      <span class="card-number">{{ String(index).padStart(2, '0') }}</span>
      <span class="card-category">{{ agent.category }}</span>
    </div>

    <div class="card-body">
      <div class="card-heading">
        <h3 class="card-name">
          {{ agent.name }}
        </h3>
        <span
          class="card-arrow"
          aria-hidden="true"
        >
          <el-icon size="15"><TopRight /></el-icon>
        </span>
      </div>
      <p class="card-desc">
        {{ agent.description }}
      </p>
      <div class="card-meta">
        <span>Open workspace</span>
      </div>
    </div>
  </article>
</template>

<script setup>
import { TopRight } from '@element-plus/icons-vue'
import AgentMascot from './AgentMascot.vue'
import { hasAgentMascot } from '../config/agentMascots.js'

defineProps({
  agent: { type: Object, required: true },
  index: { type: Number, default: 1 },
})

defineEmits(['click'])
</script>

<style scoped>
.agent-card {
  min-width: 0;
  overflow: hidden;
  border: 1px solid color-mix(in srgb, var(--agent-color) 28%, #d9e4ec);
  border-radius: 14px;
  background: #ffffff;
  box-shadow: 0 3px 10px rgba(31, 73, 106, 0.06);
  cursor: pointer;
  outline: none;
  transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
}

.agent-card:hover,
.agent-card:focus-visible {
  border-color: color-mix(in srgb, var(--agent-color) 64%, #ffffff);
  box-shadow: 0 10px 22px color-mix(in srgb, var(--agent-color) 16%, transparent);
  transform: translateY(-3px);
}

.card-visual {
  position: relative;
  aspect-ratio: 1.5;
  overflow: hidden;
  background: color-mix(in srgb, var(--agent-color) 18%, #eef5f8);
}

.card-visual-overlay {
  position: absolute;
  inset: 0;
  z-index: 1;
  background: color-mix(in srgb, var(--agent-color) 10%, transparent);
  pointer-events: none;
}

.card-number,
.card-category {
  position: absolute;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-weight: 750;
}

.card-number {
  top: 10px;
  left: 10px;
  width: 34px;
  height: 30px;
  border-radius: 9px;
  background: var(--agent-color);
  font-size: 12px;
  letter-spacing: 0.3px;
}

.card-category {
  right: 10px;
  bottom: 10px;
  min-height: 23px;
  padding: 0 9px;
  border: 1px solid rgba(255, 255, 255, 0.5);
  border-radius: 6px;
  background: color-mix(in srgb, var(--agent-color) 86%, #1f2937);
  font-size: 10px;
  letter-spacing: 0.3px;
}

.card-logo,
.card-icon-fallback {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center 34%;
}

.card-icon-fallback {
  display: flex;
  align-items: center;
  justify-content: center;
}

.card-body { padding: 13px 14px 14px; }

.card-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.card-name {
  min-width: 0;
  margin: 0;
  overflow: hidden;
  color: #16334d;
  font-size: 15px;
  font-weight: 750;
  line-height: 1.25;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-arrow {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 25px;
  height: 25px;
  flex: 0 0 auto;
  border-radius: 7px;
  background: color-mix(in srgb, var(--agent-color) 12%, #ffffff);
  color: var(--agent-color);
  transition: background 0.15s, transform 0.15s;
}

.agent-card:hover .card-arrow,
.agent-card:focus-visible .card-arrow {
  background: color-mix(in srgb, var(--agent-color) 20%, #ffffff);
  transform: translate(1px, -1px);
}

.card-desc {
  display: -webkit-box;
  min-height: 34px;
  margin: 7px 0 12px;
  overflow: hidden;
  color: #64798a;
  font-size: 12px;
  line-height: 1.45;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.card-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  color: color-mix(in srgb, var(--agent-color) 80%, #476273);
  font-size: 11px;
  font-weight: 650;
}

@media (prefers-reduced-motion: reduce) {
  .agent-card, .card-arrow { transition: none; transform: none; }
}
</style>
