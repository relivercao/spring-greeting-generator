<!--
  @file DriverWorkspace.vue
  @author zhangjian
  @brief Main Driver workspace container for driver generation tasks.
  @version 1.0
  @date 2026-07-29
  @copyright Copyright (c) 2026 relivercao@gmail.com
  All rights reserved.

  This component orchestrates Driver workspace inputs, task persistence,
  source uploads, generation requests, polling, cancellation, and generated
  artifact presentation through focused child components.
-->

<template>
  <div class="driver-workspace">
    <!-- LEFT COLUMN: Config (top) + Chat (bottom) -->
    <div class="left-column">
      <!-- Config section -->
      <div class="config-section">
        <DriverUploadSection
          :files="knowledgeBaseFiles"
          tone="blue"
          eyebrow="Knowledge Base Files"
          action-title="Add Knowledge Base Files"
          action-description="Specifications, manuals, and supporting documents"
          :file-helpers="fileHelpers"
          @files-added="addKnowledgeBaseFiles"
          @remove="removeKnowledgeBaseFile"
        />

        <DriverUploadSection
          :files="referenceFiles"
          tone="violet"
          eyebrow="Reference Files"
          action-title="Add Reference Files"
          action-description="PDFs, circuit diagrams, and technical docs"
          :file-helpers="fileHelpers"
          @files-added="addReferenceFiles"
          @remove="removeReferenceFile"
        />

        <DriverChipConfiguration
          :config="moduleConfig"
          :module-types="moduleTypes"
          @update:config="moduleConfig = $event"
        />

        <DriverBuildConfiguration
          :config="moduleConfig"
          @update:config="moduleConfig = $event"
        />
      </div>

      <!-- Prompt input section -->
      <div class="prompt-section">
        <DriverChatPanel
          :input="chatInput"
          :phase="phase"
          @update:input="updateChatInput"
          @enter="handleEnterKey"
        />
      </div>

      <transition name="validation-notice">
        <div
          v-if="generationValidationNotice"
          class="generation-validation"
          role="alert"
        >
          <div class="generation-validation-icon">
            <el-icon size="16">
              <WarningFilled />
            </el-icon>
          </div>
          <div class="generation-validation-copy">
            <div class="generation-validation-title">
              {{ generationValidationNotice.title }}
            </div>
            <div class="generation-validation-message">
              {{ generationValidationNotice.message }}
            </div>
            <div class="generation-validation-items">
              <span
                v-for="item in generationValidationNotice.items"
                :key="item"
                class="generation-validation-chip"
              >
                {{ item }}
              </span>
            </div>
          </div>
          <button
            type="button"
            class="generation-validation-close"
            aria-label="Dismiss validation notice"
            @click="clearGenerationValidationNotice"
          >
            <el-icon size="12">
              <Close />
            </el-icon>
          </button>
        </div>
      </transition>

      <!-- Generate button -->
      <button
        class="generate-btn"
        :class="{ loading: phase === 'running' || uploadingFiles }"
        :disabled="phase === 'running' || uploadingFiles"
        @click="startPromptExecution"
      >
        <el-icon
          v-if="phase !== 'running'"
          size="15"
        >
          <Cpu />
        </el-icon>
        <span
          v-else
          class="spinner"
        />
        {{ phase === 'running' ? 'Generating...' : uploadingFiles ? 'Uploading files...' : 'Generate Driver' }}
      </button>
    </div>

    <!-- RIGHT COLUMN: Result panel -->
    <div class="right-column">
      <!-- Idle state -->
      <div
        v-if="phase === 'idle'"
        class="guide-area"
      >
        <div class="guide-icon">
          <el-icon
            size="32"
            style="color:#6366f1"
          >
            <Cpu />
          </el-icon>
        </div>
        <h3 class="guide-title">
          Driver Generator
        </h3>
        <p class="guide-sub">
          Configure chip settings and enter prompt to generate driver package
        </p>
        <div class="guide-steps">
          <div class="guide-step">
            <span class="step-num">1</span>
            <span class="step-text">Upload knowledge base or reference files (optional)</span>
          </div>
          <div class="guide-step">
            <span class="step-num">2</span>
            <span class="step-text">Configure target chip and module type</span>
          </div>
          <div class="guide-step">
            <span class="step-num">3</span>
            <span class="step-text">Enter generation prompt in chat</span>
          </div>
          <div class="guide-step">
            <span class="step-num">4</span>
            <span class="step-text">Click "Generate Driver" to generate driver code</span>
          </div>
        </div>
      </div>

      <!-- Running state: workflow progress -->
      <div
        v-if="phase === 'running'"
        class="loading-area"
      >
        <button
          class="cancel-btn-top-right"
          :class="{ loading: isCancellingTask }"
          :disabled="isCancellingTask"
          @click="cancelTask"
        >
          <el-icon size="13">
            <Close />
          </el-icon>
          {{ isCancellingTask ? 'Cancelling...' : 'Cancel Task' }}
        </button>
        <DriverWorkflowProgress
          title="Driver Generation"
          description="Generating firmware driver package"
          :progress="workflowProgress"
          :steps="workflowSteps"
          :token-stats="tokenStats"
          :token-status="tokenUsageStatus"
        />
        <DriverAgentMonitor
          :runs="agentRuns"
          :events="activityEvents"
          :cli-runtime="cliRuntime"
          :current-stage="currentBackendStep"
        />
        <el-alert
          v-if="pollingNotice"
          :title="pollingNotice"
          type="warning"
          :closable="false"
          show-icon
          role="status"
        >
          <el-button
            v-if="pollingStopped"
            @click="startPollingDriverTask(currentDriverTaskId)"
          >
            Reconnect monitoring
          </el-button>
        </el-alert>
      </div>

      <!-- Done state: generated code -->
      <div
        v-if="phase === 'done' || phase === 'error'"
        class="result-wrapper"
      >
        <DriverResultReport
          :generated-code-tabs="generatedCodeTabs"
          :module-config="moduleConfig"
          :knowledge-base-count="knowledgeBaseFiles.length"
          :duration="workflowDuration"
          :token-usage="tokenUsage"
          :token-usage-status="tokenUsageStatus"
          :workflow-steps="4"
          :output-dir="outputDir"
          :driver-status="driverStatus"
          :unittest-status="unittestStatus"
          :code-review-status="codeReviewStatus"
          class="driver-result-report"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, nextTick, ref, watch, onBeforeUnmount } from 'vue'
import { ElMessage } from 'element-plus'
import { Cpu, Close, WarningFilled } from '@element-plus/icons-vue'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'

import DriverUploadSection from './driver-workspace/DriverUploadSection.vue'
import DriverChipConfiguration from './driver-workspace/DriverChipConfiguration.vue'
import DriverBuildConfiguration from './driver-workspace/DriverBuildConfiguration.vue'
import DriverChatPanel from './driver-workspace/DriverChatPanel.vue'
import DriverResultReport from './driver-workspace/DriverResultReport.vue'
import DriverWorkflowProgress from './driver-workspace/DriverWorkflowProgress.vue'
import DriverAgentMonitor from './driver-workspace/DriverAgentMonitor.vue'

import {
  MODULE_TYPES,
} from '@/constants/driverWorkspace'

import { useDriverFiles } from '@/composables/useDriverFiles'
import { WORKFLOW_STAGE_ORDER, useDriverWorkflow } from '@/composables/useDriverWorkflow'

import {
  apiUploadDriverSources,
  apiGenerateDriver,
  apiPollDriverTask,
  apiGetDriverArtifacts,
  apiGetDriverTask,
  apiCancelDriverTask,
  isTransientDriverError,
} from '@/api/driver.js'

const PREVIEW_REPORT_TASK_ID = '__driver_report_preview__'
const PREVIEW_STEP_DELAY_MS = 900
const PREVIEW_FINALIZE_DELAY_MS = 900
const ARTIFACT_FETCH_RETRY_DELAYS_MS = [800, 1600, 2400, 4000, 6000, 8000, 10000, 10000, 15000, 15000]
const ARTIFACTS_NOT_READY_MESSAGE = 'Generated report artifacts are not available yet'
const TERMINAL_DRIVER_STATUSES = new Set(['completed', 'failed', 'cancelled'])
const DRIVER_WIKI_MODE_DISABLED = 'disabled'

const props = defineProps({
  agent: Object,
  activeTask: Object,
})

const emit = defineEmits(['task-updated'])

const currentTaskId = ref(null)
const currentDriverTaskId = ref(null)
const pendingTaskId = ref(null)  // Temporary taskId before backend confirms
const knowledgeBaseFiles = ref([])
const referenceFiles = ref([])
const phase = ref('idle')
const chatInput = ref('')
const generationValidationNotice = ref(null)
const uploadingFiles = ref(false)  // Track file upload status
const isCancellingTask = ref(false)
const errorMessage = ref('')  // Store error message for error phase
const outputDir = ref('')  // Store output directory path
const driverStatus = ref({ success: true, error: null })  // Track driver generation status
const unittestStatus = ref({ success: true, coverage: null, error: null })
const codeReviewStatus = ref({ success: true, error: null })
const moduleConfig = ref(createDefaultModuleConfig())
const repositoryConfig = ref({
  repositoryUrl: '',
  branch: 'main',
  pathInput: '',
  selectedPaths: [],
})
let workflowCleanup = null
let abortController = null  // AbortController for cancelling API requests
let previewPlaybackTimers = []
let artifactFetchTaskId = null
let cancellationRequest = null
let isRestoringTask = false
let restorePersistGuardVersion = 0
const authStore = useAuthStore()
const mountedAccount = accountIdentity(authStore)
let disposed = false

function isCurrentAccount() {
  return !disposed && mountedAccount === accountIdentity(authStore)
}

function invalidateWorkspace() {
  disposed = true
  clearPreviewPlaybackTimers()
  stopDriverTaskPolling()
}

watch(() => accountIdentity(authStore), invalidateWorkspace, { flush: 'sync' })

const tokenUsage = ref({
  input_tokens: 0,
  output_tokens: 0,
  cache_creation_input_tokens: 0,
  cache_read_input_tokens: 0,
  total_tokens: 0,
})
const tokenUsageStatus = ref('pending')

const moduleTypes = MODULE_TYPES

const generatedCodeTabs = ref([])

const workflowDuration = ref(0)
const workflowStartTime = ref(0)

const {
  fileHelpers,
  createFileMetaList,
} = useDriverFiles(
  knowledgeBaseFiles,
  referenceFiles
)

const currentProgress = ref(0)
const cliRuntime = ref(null)
const agentRuns = ref([])
const activityEvents = ref([])
const currentBackendStep = ref(null)
const pollingNotice = ref('')
const pollingStopped = ref(false)

const {
  workflowSteps,
  workflowProgress,
} = useDriverWorkflow(phase, moduleConfig, currentBackendStep, currentProgress)

const tokenStats = computed(() => {
  const normalized = normalizeTokenUsage(tokenUsage.value)
  return {
    input: normalized.input_tokens,
    output: normalized.output_tokens,
    cacheWrite: normalized.cache_creation_input_tokens,
    cacheRead: normalized.cache_read_input_tokens,
    total: normalized.total_tokens,
  }
})

function createDefaultModuleConfig() {
  return {
    moduleType: 'IMU',
    moduleName: 'IMU Sensor',
    deviceType: 'sensor',
    interface: 'i2c',
    platform: 'stm32',
    generateTests: true,
    generateCodeReview: true,
    useWiki: false,
    editor_path: '',
    stm32cubeide_path: '',
    project_path: '',
  }
}

function normalizeModuleConfig(config = {}) {
  const normalized = {
    ...createDefaultModuleConfig(),
    ...(config || {}),
  }
  normalized.editor_path = normalized.editor_path || normalized.stm32cubeide_path || ''
  normalized.stm32cubeide_path = normalized.stm32cubeide_path || normalized.editor_path || ''
  normalized.useWiki = false
  return normalized
}

function resetExecutionResultState() {
  errorMessage.value = ''
  driverStatus.value = { success: true, error: null }
  unittestStatus.value = { success: true, coverage: null, error: null }
  codeReviewStatus.value = { success: true, error: null }
}

function markCompletedExecutionState() {
  errorMessage.value = ''
  driverStatus.value = { success: true, error: null }
}

function getDriverWikiGenerationMode() {
  return DRIVER_WIKI_MODE_DISABLED
}

function isStm32Platform(platform) {
  const normalizedPlatform = String(platform || 'stm32').toLowerCase()
  return normalizedPlatform === 'stm32' || normalizedPlatform === 'st32'
}

function getStm32CubeIdePath(config) {
  if (!isStm32Platform(config.platform)) {
    return ''
  }
  return config.stm32cubeide_path || config.editor_path || ''
}

function hasUploadedDriverSourceFiles() {
  return [...knowledgeBaseFiles.value, ...referenceFiles.value].some(file => {
    return Boolean(file?.source_id || file?.sourceId || (file?.fileId && String(file.fileId).startsWith('src_')))
  })
}

function getDriverGenerationBlockNotice(prompt) {
  const hasSourceFiles = hasUploadedDriverSourceFiles()
  const hasPrompt = Boolean(prompt)

  if (!hasSourceFiles && !hasPrompt) {
    return {
      title: 'Add the required inputs',
      message: 'Upload a knowledge base or reference file, then describe the driver you want to generate.',
      items: ['Source file required', 'Prompt required'],
    }
  }
  if (!hasSourceFiles) {
    return {
      title: 'Source file required',
      message: 'Add at least one knowledge base or reference file before starting Driver generation.',
      items: ['Upload knowledge base or reference file'],
    }
  }
  if (!hasPrompt) {
    return {
      title: 'Prompt required',
      message: 'Enter a short prompt that explains what driver package should be generated.',
      items: ['Enter generation prompt'],
    }
  }
  return null
}

function clearGenerationValidationNotice() {
  generationValidationNotice.value = null
}

function showGenerationValidationNotice(notice) {
  generationValidationNotice.value = notice
}

function updateChatInput(value) {
  chatInput.value = value
  if (generationValidationNotice.value) {
    clearGenerationValidationNotice()
  }
}

function phaseToStatus(value) {
  if (value === 'running') return 'running'
  if (value === 'done') return 'completed'
  if (value === 'failed') return 'failed'
  if (value === 'error') return 'failed'
  return 'idle'
}

function isValidBackendDriverTaskId(taskId) {
  const id = String(taskId || '')
  return Boolean(id && id !== 'pending' && !id.startsWith('temp_'))
}

function createBackendDriverTaskId() {
  const randomBytes = new Uint8Array(16)
  globalThis.crypto.getRandomValues(randomBytes)
  return 'task_' + Array.from(
    randomBytes,
    value => value.toString(16).padStart(2, '0'),
  ).join('')
}

function isPendingTaskRegistration(taskState) {
  return taskState?.state_data?.task_registration_pending === true
}

function isTerminalDriverStatus(status) {
  return TERMINAL_DRIVER_STATUSES.has(status)
}

function isPreviewPlaybackTask(task, state = task?.driverState || {}) {
  return task?.id === PREVIEW_REPORT_TASK_ID && state.previewPlayback === true
}

function clearPreviewPlaybackTimers() {
  previewPlaybackTimers.forEach(timer => clearTimeout(timer))
  previewPlaybackTimers = []
}

function schedulePreviewPlayback(callback, delayMs) {
  const timer = setTimeout(() => {
    previewPlaybackTimers = previewPlaybackTimers.filter(item => item !== timer)
    if (isCurrentAccount()) callback()
  }, delayMs)
  previewPlaybackTimers.push(timer)
}

function beginRestorePersistGuard() {
  isRestoringTask = true
  const guardVersion = ++restorePersistGuardVersion
  nextTick(() => {
    if (guardVersion === restorePersistGuardVersion) {
      isRestoringTask = false
    }
  })
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function createEmptyTokenUsage() {
  return {
    input_tokens: 0,
    output_tokens: 0,
    cache_creation_input_tokens: 0,
    cache_read_input_tokens: 0,
    total_tokens: 0,
  }
}

function normalizeTokenUsage(rawUsage) {
  const usage = rawUsage && typeof rawUsage === 'object' ? rawUsage : {}
  const inputTokens = Math.max(0, Math.round(Number(usage.input_tokens) || 0))
  const outputTokens = Math.max(0, Math.round(Number(usage.output_tokens) || 0))
  const cacheCreationTokens = Math.max(0, Math.round(Number(usage.cache_creation_input_tokens) || 0))
  const cacheReadTokens = Math.max(0, Math.round(Number(usage.cache_read_input_tokens) || 0))
  const componentTotal = inputTokens + outputTokens + cacheCreationTokens + cacheReadTokens
  const reportedTotal = Math.max(0, Math.round(Number(usage.total_tokens) || 0))

  return {
    input_tokens: inputTokens,
    output_tokens: outputTokens,
    cache_creation_input_tokens: cacheCreationTokens,
    cache_read_input_tokens: cacheReadTokens,
    total_tokens: componentTotal || reportedTotal,
  }
}

function hasTokenUsage(rawUsage) {
  return normalizeTokenUsage(rawUsage).total_tokens > 0
}

function normalizeTokenUsageStatus(rawStatus, terminal = false, rawUsage = null) {
  if (hasTokenUsage(rawUsage)) return 'available'
  if (['available', 'unavailable', 'pending'].includes(rawStatus)) return rawStatus
  return terminal ? 'unavailable' : 'pending'
}

function updateTokenUsageStatus(rawStatus, terminal = false, rawUsage = null) {
  const nextStatus = normalizeTokenUsageStatus(rawStatus, terminal, rawUsage)
  if (tokenUsageStatus.value !== 'available' || nextStatus === 'available') {
    tokenUsageStatus.value = nextStatus
  }
}

function scalePreviewTokenUsage(finalTokenUsage, progress) {
  const ratio = Math.min(1, Math.max(0, Number(progress) / 100))
  const inputTokens = Math.round((Number(finalTokenUsage.input_tokens) || 0) * ratio)
  const outputTokens = Math.round((Number(finalTokenUsage.output_tokens) || 0) * ratio)
  const cacheCreationTokens = Math.round((Number(finalTokenUsage.cache_creation_input_tokens) || 0) * ratio)
  const cacheReadTokens = Math.round((Number(finalTokenUsage.cache_read_input_tokens) || 0) * ratio)
  const reportedTotal = Number(finalTokenUsage.total_tokens) || 0

  return {
    input_tokens: inputTokens,
    output_tokens: outputTokens,
    cache_creation_input_tokens: cacheCreationTokens,
    cache_read_input_tokens: cacheReadTokens,
    total_tokens: reportedTotal > 0
      ? Math.round(reportedTotal * ratio)
      : inputTokens + outputTokens + cacheCreationTokens + cacheReadTokens,
  }
}

function getPreviewStepCount() {
  let stepCount = 4
  if (moduleConfig.value.generateTests) stepCount += 1
  if (moduleConfig.value.generateCodeReview) stepCount += 1
  return stepCount
}

function startPreviewPlayback(state) {
  clearPreviewPlaybackTimers()
  const finalTokenUsage = state.previewFinalTokenUsage || state.tokenUsage || createEmptyTokenUsage()
  const stepCount = getPreviewStepCount()

  phase.value = 'running'
  currentProgress.value = 0
  resetBackendWorkflowStep()
  workflowStartTime.value = Date.now()
  tokenUsage.value = createEmptyTokenUsage()
  tokenUsageStatus.value = hasTokenUsage(finalTokenUsage) ? 'available' : 'unavailable'

  for (let stepIndex = 1; stepIndex <= stepCount; stepIndex++) {
    schedulePreviewPlayback(() => {
      const nextProgress = stepIndex === stepCount
        ? 100
        : Math.ceil((stepIndex / stepCount) * 100)
      currentProgress.value = nextProgress
      tokenUsage.value = scalePreviewTokenUsage(finalTokenUsage, nextProgress)
    }, stepIndex * PREVIEW_STEP_DELAY_MS)
  }

  schedulePreviewPlayback(() => {
    currentProgress.value = 100
    tokenUsage.value = scalePreviewTokenUsage(finalTokenUsage, 100)
    workflowDuration.value = state.duration || Math.round((Date.now() - workflowStartTime.value) / 1000)
    driverStatus.value = state.driverStatus || { success: true, error: null }
    unittestStatus.value = state.unittestStatus || { success: true, coverage: null, error: null }
    codeReviewStatus.value = state.codeReviewStatus || { success: true, error: null }
    phase.value = 'done'
  }, (stepCount * PREVIEW_STEP_DELAY_MS) + PREVIEW_FINALIZE_DELAY_MS)
}

function restoreFromTask(task) {
  if (!isCurrentAccount()) return
  resetCancellationRequest()
  beginRestorePersistGuard()
  clearPreviewPlaybackTimers()
  console.log('[restoreFromTask] === START ===')
  console.log('[restoreFromTask] task:', JSON.stringify(task, null, 2))

  currentTaskId.value = task?.id || null
  tokenUsage.value = createEmptyTokenUsage()
  tokenUsageStatus.value = 'pending'

  if (!task) {
    knowledgeBaseFiles.value = []
    referenceFiles.value = []
    moduleConfig.value = createDefaultModuleConfig()
    repositoryConfig.value = {
      repositoryUrl: '',
      branch: 'main',
      pathInput: '',
      selectedPaths: [],
    }
    phase.value = 'idle'
    currentProgress.value = 0
    resetBackendWorkflowStep()
    driverStatus.value = { success: true, error: null }
    unittestStatus.value = { success: true, coverage: null, error: null }
    codeReviewStatus.value = { success: true, error: null }
    return
  }

  const state = task.driverState || {}
  const shouldRunPreviewPlayback = isPreviewPlaybackTask(task, state)
  console.log('[restoreFromTask] state.phase:', state.phase, 'task.status:', task.status)

  knowledgeBaseFiles.value = task.knowledgeBaseFilesMeta ? task.knowledgeBaseFilesMeta.map(f => ({ ...f })) : []
  referenceFiles.value = task.referenceFilesMeta ? task.referenceFilesMeta.map(f => ({ ...f })) : []

  // Restore progress. Preserve 0 as a valid progress value; using || would
  // incorrectly fall back and make the first workflow node appear completed.
  const restoredProgress = task.status === 'cancelled' ? 0 : (state.progress ?? task.progress ?? 0)
  const isCompletedTask = task.status === 'completed'

  // Terminal task status must override stale persisted phase.
  if (shouldRunPreviewPlayback) {
    phase.value = 'running'
  } else if (task.status === 'cancelled') {
    phase.value = 'idle'
  } else if (isCompletedTask) {
    phase.value = 'done'
  } else if (task.status === 'failed') {
    phase.value = 'error'
  } else if (task.status === 'running' || task.status === 'pending') {
    phase.value = 'running'
  } else if (state.phase) {
    phase.value = state.phase
  } else {
    phase.value = 'idle'
  }

  currentProgress.value = restoredProgress
  currentBackendStep.value = state.currentStep || null
  agentRuns.value = Array.isArray(state.agentRuns) ? state.agentRuns : []
  activityEvents.value = Array.isArray(state.activityEvents) ? state.activityEvents : []
  updateTokenUsageStatus(
    state.tokenUsageStatus,
    task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled',
    state.tokenUsage,
  )
  console.log('[restoreFromTask] Final phase:', phase.value, 'progress:', currentProgress.value)
  console.log('[restoreFromTask] state.driverTaskId:', state.driverTaskId)

  // Restore pendingTaskId if available (for Cancel button)
  if (state.pendingTaskId) {
    pendingTaskId.value = state.pendingTaskId
    console.log('[restoreFromTask] Restored pendingTaskId:', pendingTaskId.value)
  }

  const restorableDriverTaskId = isValidBackendDriverTaskId(state.driverTaskId)
    ? state.driverTaskId
    : null
  if (restorableDriverTaskId) {
    currentDriverTaskId.value = restorableDriverTaskId
  }

  // Restore currentDriverTaskId if the task is running and has valid taskId
  // Skip if driverTaskId is 'pending' (old placeholder) or starts with 'temp_' (frontend-only temporary ID)
  if (!shouldRunPreviewPlayback &&
      restorableDriverTaskId &&
      phase.value === 'running') {
    console.log('[restoreFromTask] Restored currentDriverTaskId:', currentDriverTaskId.value)

    // Resume polling for the running task
    console.log('[restoreFromTask] Resuming polling for running task:', currentDriverTaskId.value)
    startPollingDriverTask(currentDriverTaskId.value)
  } else if (!shouldRunPreviewPlayback && phase.value === 'running' && !state.driverTaskId) {
    // Task is running but no backend taskId yet - try pendingTaskId
    if (state.pendingTaskId) {
      console.log('[restoreFromTask] driverTaskId is null, using pendingTaskId for polling:', state.pendingTaskId)
      currentDriverTaskId.value = state.pendingTaskId
      startPollingDriverTask(state.pendingTaskId)
    } else {
      console.warn('[restoreFromTask] Task is running but driverTaskId and pendingTaskId are both null - keeping UI in running state without polling')
      console.warn('[restoreFromTask] Task will resume polling once backend API returns')
    }
  } else if (!shouldRunPreviewPlayback && (state.driverTaskId === 'pending' || state.driverTaskId?.startsWith('temp_'))) {
    console.warn('[restoreFromTask] Skipping restore - driverTaskId is temporary:', state.driverTaskId)
  } else {
    console.log('[restoreFromTask] Not resuming polling - phase:', phase.value, 'driverTaskId:', state.driverTaskId)
  }

  moduleConfig.value = normalizeModuleConfig(state.moduleConfig)
  repositoryConfig.value = state.repositoryConfig || {
    repositoryUrl: '',
    branch: 'main',
    pathInput: '',
    selectedPaths: [],
  }

  // Restore full artifacts only. Persisted history intentionally keeps
  // metadata-only summaries so refreshes reload large content from backend.
  const persistedArtifacts = Array.isArray(task.artifacts) ? task.artifacts : []
  const hasFullPersistedArtifacts = persistedArtifacts.some(
    artifact => typeof artifact?.content === 'string' && artifact.content.length > 0
  )
  if (hasFullPersistedArtifacts) {
    generatedCodeTabs.value = task.artifacts
    console.log('[restoreFromTask] Restored artifacts:', task.artifacts.length, 'files')
  } else {
    generatedCodeTabs.value = []
  }

  // Restore output directory
  if (state.outputDir) {
    outputDir.value = state.outputDir
    console.log('[restoreFromTask] Restored outputDir:', state.outputDir)
  }

  // Restore workflow duration
  if (state.duration) {
    workflowDuration.value = state.duration
    console.log('[restoreFromTask] Restored duration:', state.duration)
  }

  // Restore token usage
  if (state.tokenUsage) {
    tokenUsage.value = normalizeTokenUsage(state.tokenUsage)
    console.log('[restoreFromTask] Restored token usage')
  }

  // Restore driver status
  if (state.driverStatus) {
    driverStatus.value = state.driverStatus
    console.log('[restoreFromTask] Restored driver status:', state.driverStatus)
  }

  if (state.unittestStatus) {
    unittestStatus.value = state.unittestStatus
  }

  if (state.codeReviewStatus) {
    codeReviewStatus.value = state.codeReviewStatus
  }

  if (isCompletedTask) {
    markCompletedExecutionState()
    nextTick(() => {
      if (currentTaskId.value === task.id) {
        persistTask({ status: 'completed', progress: 100 })
      }
    })
  }

  if (
    !shouldRunPreviewPlayback &&
    isCompletedTask &&
    generatedCodeTabs.value.length === 0 &&
    restorableDriverTaskId
  ) {
    currentProgress.value = 100
    phase.value = 'done'
    fetchArtifactsAndDisplay(restorableDriverTaskId)
  }

  if (shouldRunPreviewPlayback) {
    startPreviewPlayback(state)
  }
}

function persistTask(patch = {}) {
  if (!isCurrentAccount()) return
  if (isRestoringTask) return
  if (!currentTaskId.value || currentTaskId.value === '__driver_report_preview__') return

  const knowledgeBaseFilesMeta = createFileMetaList(knowledgeBaseFiles.value)
  const referenceFilesMeta = createFileMetaList(referenceFiles.value)

  const finalStatus = patch.status || phaseToStatus(phase.value)
  const safePatch = { ...patch }
  delete safePatch.artifacts

  console.log('[persistTask] Saving task - phase:', phase.value, 'finalStatus:', finalStatus, 'patch:', patch, 'driverTaskId:', currentDriverTaskId.value)

  const taskUpdate = {
    id: currentTaskId.value,
    title: props.activeTask?.title || 'New Driver Task',
    status: finalStatus,
    progress: currentProgress.value,
    result: null,
    knowledgeBaseFilesMeta,
    referenceFilesMeta,
    driverState: {
      phase: phase.value,
      progress: currentProgress.value,  // Save current progress for restoration
      currentStep: currentBackendStep.value,
      driverTaskId: currentDriverTaskId.value,  // Save for restoration
      pendingTaskId: pendingTaskId.value,  // Save pending taskId for Cancel
      moduleConfig: { ...moduleConfig.value },
      repositoryConfig: { ...repositoryConfig.value },
      outputDir: outputDir.value,  // Save output directory
      duration: workflowDuration.value,  // Save workflow duration
      tokenUsage: { ...tokenUsage.value },  // Save token usage
      tokenUsageStatus: tokenUsageStatus.value,
      agentRuns: [...agentRuns.value],
      activityEvents: [...activityEvents.value],
      driverStatus: { ...driverStatus.value },  // Save driver status
      unittestStatus: { ...unittestStatus.value },
      codeReviewStatus: { ...codeReviewStatus.value },
    },
    ...safePatch,
  }

  if (generatedCodeTabs.value.length > 0) {
    taskUpdate.artifacts = generatedCodeTabs.value
  }

  emit('task-updated', taskUpdate)
}

watch(() => props.activeTask, (task) => {
  console.log('[DriverWorkspace] activeTask changed:', task?.id, task)
  restoreFromTask(task)
}, { immediate: true })

watch(moduleConfig, () => {
  persistTask()
}, { deep: true })

watch(repositoryConfig, () => {
  persistTask()
}, { deep: true })

async function addKnowledgeBaseFiles(files) {
  if (!isCurrentAccount()) return
  const workspaceTaskId = currentTaskId.value
  console.log('[addKnowledgeBaseFiles] === START ===')
  console.log('[addKnowledgeBaseFiles] Received', files.length, 'files:', files.map(f => f.name))
  console.log('[addKnowledgeBaseFiles] uploadingFiles before:', uploadingFiles.value)

  // Upload files immediately to backend
  uploadingFiles.value = true  // Start uploading
  console.log('[addKnowledgeBaseFiles] uploadingFiles set to true')

  try {
    console.log('[addKnowledgeBaseFiles] Starting upload...')
    const uploadResult = await apiUploadDriverSources(files, 'knowledge_base')
    if (!isCurrentAccount() || currentTaskId.value !== workspaceTaskId) return
    console.log('[addKnowledgeBaseFiles] Upload result:', uploadResult)

    if (!uploadResult || !uploadResult.sources) {
      console.error('[addKnowledgeBaseFiles] Invalid upload result:', uploadResult)
      ElMessage.error('Upload failed: Invalid response from server')
      uploadingFiles.value = false  // Reset immediately on error
      return
    }

    // Create file metadata with source_id from backend
    const newFiles = uploadResult.sources.map((source) => {
      console.log('[addKnowledgeBaseFiles] Processing source:', source)
      const originalFile = files.find(f => f.name === source.name)
      return {
        fileId: source.source_id,
        name: source.name,
        size: source.size,
        type: source.mime_type || '',
        uploadStatus: 'uploaded',
        parseStatus: source.parse_status || 'parsing',  // Track parse status
        source_id: source.source_id,  // Store backend source_id
        _originalFile: originalFile,  // Keep reference for debugging
      }
    })

    console.log('[addKnowledgeBaseFiles] New files with source_ids:', newFiles)
    knowledgeBaseFiles.value.push(...newFiles)
    console.log('[addKnowledgeBaseFiles] Total knowledgeBaseFiles after adding:', knowledgeBaseFiles.value)
    clearGenerationValidationNotice()

    if (currentTaskId.value) {
      persistTask({ knowledgeBaseFilesMeta: createFileMetaList(knowledgeBaseFiles.value) })
    }

    ElMessage.success(`${files.length} knowledge base file(s) uploaded successfully`)
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== workspaceTaskId) return
    console.error('[addKnowledgeBaseFiles] === CATCH ERROR ===')
    console.error('[addKnowledgeBaseFiles] Error type:', error.constructor.name)
    console.error('[addKnowledgeBaseFiles] Error message:', error.message)
    console.error('[addKnowledgeBaseFiles] Error stack:', error.stack)
    ElMessage.error('Failed to upload knowledge base files: ' + error.message)
  } finally {
    console.log('[addKnowledgeBaseFiles] === FINALLY ===')
    uploadingFiles.value = false  // Upload complete
    console.log('[addKnowledgeBaseFiles] uploadingFiles set to false')
    console.log('[addKnowledgeBaseFiles] === END ===')
  }
}

function removeKnowledgeBaseFile(index) {
  knowledgeBaseFiles.value.splice(index, 1)
  if (currentTaskId.value) {
    persistTask({ knowledgeBaseFilesMeta: createFileMetaList(knowledgeBaseFiles.value) })
  }
  ElMessage.info('Knowledge base file removed')
}

async function addReferenceFiles(files) {
  if (!isCurrentAccount()) return
  const workspaceTaskId = currentTaskId.value
  console.log('[addReferenceFiles] Received', files.length, 'files')

  // Upload files immediately to backend
  uploadingFiles.value = true
  try {
    const uploadResult = await apiUploadDriverSources(files, 'reference')
    if (!isCurrentAccount() || currentTaskId.value !== workspaceTaskId) return
    console.log('[addReferenceFiles] Upload successful:', uploadResult)

    if (!uploadResult || !uploadResult.sources) {
      console.error('[addReferenceFiles] Invalid upload result:', uploadResult)
      ElMessage.error('Upload failed: Invalid response from server')
      return
    }

    // Create file metadata with source_id from backend
    const newFiles = uploadResult.sources.map((source) => {
      const originalFile = files.find(f => f.name === source.name)
      return {
        fileId: source.source_id,
        name: source.name,
        size: source.size,
        type: source.mime_type || '',
        uploadStatus: 'uploaded',
        parseStatus: source.parse_status || 'parsing',  // Track parse status
        source_id: source.source_id,  // Store backend source_id
        _originalFile: originalFile,  // Keep reference for debugging
      }
    })

    referenceFiles.value.push(...newFiles)
    clearGenerationValidationNotice()

    if (currentTaskId.value) {
      persistTask({ referenceFilesMeta: createFileMetaList(referenceFiles.value) })
    }

    ElMessage.success(`${files.length} reference file(s) uploaded successfully`)
  } catch (error) {
    if (!isCurrentAccount() || currentTaskId.value !== workspaceTaskId) return
    console.error('[addReferenceFiles] Upload failed:', error)
    ElMessage.error('Failed to upload reference files: ' + error.message)
  } finally {
    uploadingFiles.value = false  // Upload complete
  }
}

function removeReferenceFile(index) {
  referenceFiles.value.splice(index, 1)
  if (currentTaskId.value) {
    persistTask({ referenceFilesMeta: createFileMetaList(referenceFiles.value) })
  }
  ElMessage.info('Reference file removed')
}

function handleEnterKey() {
  if (phase.value !== 'running') {
    startPromptExecution()
  }
}

function startPromptExecution() {
  if (!currentTaskId.value) {
    ElMessage.warning('Please start a Driver task first')
    return
  }

  if (phase.value === 'running') {
    ElMessage.info('Execution is already in progress')
    return
  }

  const prompt = chatInput.value.trim()
  const blockNotice = getDriverGenerationBlockNotice(prompt)
  if (blockNotice) {
    showGenerationValidationNotice(blockNotice)
    return
  }

  clearGenerationValidationNotice()
  chatInput.value = ''
  persistTask({
    title: props.activeTask?.title === 'New Driver Task'
      ? prompt.slice(0, 24) + (prompt.length > 24 ? '...' : '')
      : props.activeTask?.title || 'New Driver Task',
  })
  startGeneration(prompt)
}

async function startGeneration(prompt) {
  if (!isCurrentAccount()) return
  if (!currentTaskId.value) {
    ElMessage.warning('Please start a Driver task first')
    return
  }

  if (phase.value === 'running') {
    ElMessage.info('Execution is already in progress')
    return
  }

  // Reset progress and phase
  resetCancellationRequest()
  currentProgress.value = 0
  resetBackendWorkflowStep()
  phase.value = 'running'
  currentDriverTaskId.value = null
  pendingTaskId.value = null
  resetExecutionResultState()

  // Create AbortController for this request
  abortController = new AbortController()

  // Don't set currentDriverTaskId yet - we'll set it after backend confirms
  // This prevents saving an unconfirmed taskId to localStorage if user refreshes before API returns

  // Generate the backend taskId
  const taskId = createBackendDriverTaskId()
  pendingTaskId.value = taskId  // Save for Cancel button
  currentDriverTaskId.value = taskId
  console.log('[startGeneration] Generated taskId:', taskId)

  // Reset token usage
  tokenUsage.value = {
    input_tokens: 0,
    output_tokens: 0,
    cache_creation_input_tokens: 0,
    cache_read_input_tokens: 0,
    total_tokens: 0,
  }
  tokenUsageStatus.value = 'pending'

  const sourceSummary = [
    knowledgeBaseFiles.value.length > 0 ? `${knowledgeBaseFiles.value.length} knowledge base file(s)` : '',
    referenceFiles.value.length > 0 ? `${referenceFiles.value.length} reference file(s)` : '',
    repositoryConfig.value.selectedPaths.length > 0 ? `${repositoryConfig.value.selectedPaths.length} repository path(s)` : '',
  ].filter(Boolean).join(' and ')

  console.log(`Starting driver generation with ${sourceSummary} | Module: ${moduleConfig.value.moduleType} ${moduleConfig.value.moduleName} | Prompt: ${prompt}`)

  // Save and poll with the client-provided backend task id immediately. The
  // backend publishes the task before Docling parsing, so token usage from the
  // knowledge-base phase can appear without a page refresh.
  persistTask({ status: 'running', progress: 0 })
  workflowStartTime.value = Date.now()
  startPollingDriverTask(taskId)

  // Phase 1: Collect source_ids from already-uploaded files
  const uploadedSourceIds = []

  console.log('[startGeneration] knowledgeBaseFiles.value:', knowledgeBaseFiles.value)
  if (knowledgeBaseFiles.value.length > 0) {
    const kbSourceIds = knowledgeBaseFiles.value
      .map(f => f.source_id || f.sourceId)
      .filter(Boolean)
    uploadedSourceIds.push(...kbSourceIds)
    console.log('[startGeneration] Collected', kbSourceIds.length, 'knowledge base source_ids')
  }

  if (referenceFiles.value.length > 0) {
    const refSourceIds = referenceFiles.value
      .map(f => f.source_id || f.sourceId)
      .filter(Boolean)
    uploadedSourceIds.push(...refSourceIds)
    console.log('[startGeneration] Collected', refSourceIds.length, 'reference source_ids')
  }

  console.log('[startGeneration] Total source_ids to send:', uploadedSourceIds)

  // Phase 2: Start generation
  const payload = {
    task_id: taskId,
    prompt,
    module_config: {
      module_type: moduleConfig.value.moduleType,
      module_name: moduleConfig.value.moduleName,
      device_name: moduleConfig.value.moduleName,
      device_type: moduleConfig.value.deviceType || 'sensor',
      interface: moduleConfig.value.interface || 'i2c',
      mcu_family: moduleConfig.value.mcuFamily || moduleConfig.value.mcu_family || null,
      platform: moduleConfig.value.platform || 'stm32',
      editor_path: moduleConfig.value.editor_path || moduleConfig.value.stm32cubeide_path || '',
      stm32cubeide_path: getStm32CubeIdePath(moduleConfig.value),
      project_path: moduleConfig.value.project_path || '',
    },
    source_ids: uploadedSourceIds,
    output_options: {
      include_tests: moduleConfig.value.generateTests || false,
      include_config: true,
      wiki_generation_mode: getDriverWikiGenerationMode()
    }
  }

  console.log('[startGeneration] Final uploadedSourceIds:', uploadedSourceIds)
  console.log('[startGeneration] About to call apiGenerateDriver with payload:', payload)

  let sessionId
  try {
    console.log('[startGeneration] Calling apiGenerateDriver...')
    const genResult = await apiGenerateDriver(payload, { signal: abortController.signal })
    if (!isCurrentAccount()) return

    // pendingTaskId is the source of truth until the backend confirms the task.
    // cancelTask() clears it while polling uses the same client-provided taskId.
    if (pendingTaskId.value !== taskId || phase.value !== 'running') {
      console.log('[startGeneration] Task was cancelled during API call, aborting')
      return
    }

    if (!genResult || !genResult.task_id) {
      throw new Error('Invalid response from server: missing task_id')
    }

    if (genResult.task_id !== taskId) {
      throw new Error(`Task ID mismatch: expected ${taskId}, received ${genResult.task_id}`)
    }

    sessionId = genResult.session_id

    console.log('[startGeneration] Driver generation started:', { taskId, sessionId })

    currentDriverTaskId.value = genResult.task_id
    pendingTaskId.value = null

    // Clear AbortController since request completed successfully
    abortController = null

    // Keep the visible workspace task stable; store backend task ID only for polling/cancel.
    persistTask({
      status: 'running',
      progress: 0,
      sessionId,
      sourceIds: uploadedSourceIds,
    })
  } catch (err) {
    if (!isCurrentAccount()) return
    console.error('[startGeneration] API call failed:', err)
    if (currentDriverTaskId.value !== taskId || phase.value !== 'running') return

    // Check if this was an intentional abort (user clicked Cancel)
    if (err.name === 'AbortError' || err.message?.includes('aborted')) {
      console.log('[startGeneration] Request was aborted by user')
      return
    }

    const sourceSessionMismatch = err.code === 'DRIVER_SOURCE_SESSION_MISMATCH'
    const generationError = sourceSessionMismatch
      ? 'The uploaded files belong to an expired browser session. Please upload them again before generating.'
      : err.message || err.response?.data?.detail || 'Unknown error'

    if (sourceSessionMismatch) {
      // Source IDs are scoped to the signed guest cookie or logged-in user.
      // Remove stale IDs so the next attempt cannot repeat the same 400.
      knowledgeBaseFiles.value = []
      referenceFiles.value = []
      stopDriverTaskPolling()
      phase.value = 'error'
      errorMessage.value = generationError
      pendingTaskId.value = null
      currentDriverTaskId.value = null
      persistTask({
        status: 'failed',
        progress: currentProgress.value,
        error: generationError,
        knowledgeBaseFilesMeta: [],
        referenceFilesMeta: [],
      })
      ElMessage.error(generationError)
      return
    }

    abortController = null
    const taskState = await apiGetDriverTask(taskId).catch(() => null)
    if (!isCurrentAccount() || currentDriverTaskId.value !== taskId || phase.value !== 'running') return
    if (taskState && !isPendingTaskRegistration(taskState)) {
      if (await applyTerminalTaskState(taskState, taskId)) return
      persistTask({
        status: 'running',
        progress: currentProgress.value,
      })
      return
    }

    if (isTransientDriverError(err)) {
      startPollingDriverTask(taskId)
      pollingNotice.value = 'The generation request was interrupted. The task may still be running; monitoring will continue.'
      persistTask({
        status: 'running',
        progress: currentProgress.value,
      })
      return
    }

    ElMessage.error('Generation failed: ' + generationError)

    stopDriverTaskPolling()
    phase.value = 'error'
    errorMessage.value = generationError
    pendingTaskId.value = null
    currentDriverTaskId.value = null
    persistTask({
      status: 'failed',
      progress: currentProgress.value,
      error: generationError
    })
    return
  }
}

function startPollingDriverTask(taskId) {
  if (!isCurrentAccount()) return
  pollingNotice.value = ''
  pollingStopped.value = false
  // Clean up previous polling if any
  if (workflowCleanup) {
    workflowCleanup()
    workflowCleanup = null
  }

  if (isValidBackendDriverTaskId(taskId)) {
    currentDriverTaskId.value = taskId
  }

  console.log('[startPollingDriverTask] Starting polling for task:', taskId)

  const stopPolling = apiPollDriverTask(taskId, async (data) => {
    if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) {
      console.warn('[Polling] Ignoring stale update for task:', taskId)
      return
    }

    if (['polling_retry', 'polling_unavailable', 'auth_required'].includes(data.status)) {
      pollingNotice.value = data.error || 'Task monitoring is temporarily unavailable.'
      pollingStopped.value = !data.retrying
      return
    }
    pollingNotice.value = ''
    pollingStopped.value = false

    const stateData = data.state_data || {}
    cliRuntime.value = stateData.details?.cli_runtime || null
    agentRuns.value = Array.isArray(stateData.agent_runs) ? stateData.agent_runs : agentRuns.value
    activityEvents.value = Array.isArray(stateData.activity_events)
      ? stateData.activity_events
      : activityEvents.value
    updateBackendWorkflowStep(data.current_step, stateData)
    currentProgress.value = Math.max(
      currentProgress.value,
      clampProgress(stateData.progress ?? currentProgress.value)
    )

    if (stateData.token_usage) {
      tokenUsage.value = normalizeTokenUsage(stateData.token_usage)
    }
    updateTokenUsageStatus(
      stateData.token_usage_status,
      data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled',
      stateData.token_usage,
    )

    // Persist progress and token usage to store immediately so it survives page refresh
    // This ensures that if user refreshes during task execution, the running state is restored
    persistTask()

    if (data.status === 'completed') {
      await applyTerminalTaskState(data, taskId)
    } else if (data.status === 'failed') {
      // Failed is already a backend terminal state. Only the explicit Cancel
      // button may call the cancel endpoint; polling must never convert a
      // refreshed or failed task into "cancelled".
      applyFailedTaskState(data)
      ElMessage.error(errorMessage.value)
    } else if (data.status === 'cancelled') {
      applyCancelledTaskState(data.last_error || data.error_message || 'Task cancelled by user')
    }
  })

  workflowCleanup = stopPolling
}

function clampProgress(rawProgress) {
  const progress = Number(rawProgress)
  if (!Number.isFinite(progress)) return 0
  return Math.min(100, Math.max(0, progress))
}

function updateBackendWorkflowStep(nextStep, stateData = {}) {
  const normalizedNextStep = String(stateData.backend_stage || nextStep || '').trim()
  if (!normalizedNextStep) return

  const currentStep = currentBackendStep.value
  if (!currentStep) {
    currentBackendStep.value = normalizedNextStep
    return
  }

  const currentOrder = WORKFLOW_STAGE_ORDER[currentStep]
  const nextOrder = WORKFLOW_STAGE_ORDER[normalizedNextStep]
  if (nextOrder === undefined) return
  if (currentOrder === undefined || nextOrder >= currentOrder) {
    currentBackendStep.value = normalizedNextStep
  }
}

function resetBackendWorkflowStep() {
  currentBackendStep.value = null
  cliRuntime.value = null
  agentRuns.value = []
  activityEvents.value = []
}

function stopDriverTaskPolling() {
  pollingNotice.value = ''
  pollingStopped.value = false
  if (workflowCleanup) {
    workflowCleanup()
    workflowCleanup = null
  }
}

function abortPendingGenerationRequest() {
  if (abortController) {
    abortController.abort()
    abortController = null
  }
}

function applyCancelledTaskState(message = 'Task cancelled by user') {
  resetCancellationRequest()
  stopDriverTaskPolling()
  clearPreviewPlaybackTimers()
  phase.value = 'idle'
  currentProgress.value = 0
  resetBackendWorkflowStep()
  currentDriverTaskId.value = null
  pendingTaskId.value = null
  errorMessage.value = message
  persistTask({
    status: 'cancelled',
    progress: 0,
    error: message,
  })
}

function applyFailedTaskState(data = {}) {
  resetCancellationRequest()
  workflowDuration.value = Math.round((Date.now() - workflowStartTime.value) / 1000)
  errorMessage.value = data.last_error || data.error_message || data.error || 'Generation failed'
  driverStatus.value = {
    success: false,
    error: errorMessage.value
  }
  updateTokenUsageStatus('unavailable', true, data.state_data?.token_usage)
  phase.value = 'error'
  persistTask({ status: 'failed', progress: currentProgress.value, error: errorMessage.value })
}

async function applyTerminalTaskState(data, taskId) {
  if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return false
  if (data.status === 'completed') {
    resetCancellationRequest()
    currentDriverTaskId.value = taskId
    pendingTaskId.value = null
    currentProgress.value = 100
    workflowDuration.value = Math.round((Date.now() - workflowStartTime.value) / 1000)
    markCompletedExecutionState()
    await fetchArtifactsAndDisplay(taskId)
    return true
  }

  if (data.status === 'failed') {
    currentDriverTaskId.value = taskId
    pendingTaskId.value = null
    applyFailedTaskState(data)
    return true
  }

  if (data.status === 'cancelled') {
    applyCancelledTaskState(data.reason || data.last_error || data.error_message || 'Task cancelled by user')
    return true
  }

  return false
}

async function fetchArtifactsAndDisplay(taskId) {
  if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return
  if (artifactFetchTaskId === taskId) return
  artifactFetchTaskId = taskId

  try {
    const artifactsResult = await fetchDriverArtifactsWithRetry(taskId)

    if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return

    const artifacts = Array.isArray(artifactsResult.artifacts) ? artifactsResult.artifacts : []
    generatedCodeTabs.value = artifacts.map(artifact => ({
      name: artifact.name,
      content: artifact.content || '// No content',
      type: artifact.artifact_type,
      language: artifact.language
    }))

    // Extract output directory from response
    if (artifactsResult.output_dir) {
      outputDir.value = artifactsResult.output_dir
    }

    // Set driver status to success
    driverStatus.value = {
      success: true,
      error: null
    }
    codeReviewStatus.value = {
      success: true,
      error: null
    }

    phase.value = 'done'
    persistTask({
      status: 'completed',
      progress: 100
    })
    ElMessage.success('Driver generation completed!')
  } catch (err) {
    if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return

    console.warn('[DriverWorkspace] Driver completed but artifacts could not be loaded:', err)
    currentProgress.value = 100
    phase.value = 'done'
    driverStatus.value = {
      success: true,
      error: null
    }
    persistTask({
      status: 'completed',
      progress: 100
    })
    ElMessage.warning('Driver completed, but generated files are still unavailable. Reopen the task to retry loading the report.')
  } finally {
    if (artifactFetchTaskId === taskId) {
      artifactFetchTaskId = null
    }
  }
}

async function fetchDriverArtifactsWithRetry(taskId) {
  let lastError = null

  for (let attempt = 0; attempt <= ARTIFACT_FETCH_RETRY_DELAYS_MS.length; attempt++) {
    if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return null
    try {
      const result = await apiGetDriverArtifacts(taskId)
      if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return null
      const artifacts = Array.isArray(result?.artifacts) ? result.artifacts : []
      if (artifacts.length > 0) {
        return { ...result, artifacts }
      }
      throw new Error(ARTIFACTS_NOT_READY_MESSAGE)
    } catch (err) {
      if (!isCurrentAccount() || currentDriverTaskId.value !== taskId) return null
      lastError = err
      const retryDelay = ARTIFACT_FETCH_RETRY_DELAYS_MS[attempt]
      if (retryDelay === undefined) break
      await delay(retryDelay)
    }
  }

  throw lastError || new Error('Unable to fetch driver artifacts')
}

function resetCancellationRequest() {
  cancellationRequest = null
  isCancellingTask.value = false
}

async function cancelTask() {
  if (!isCurrentAccount() || isCancellingTask.value) return
  const workspaceTaskId = currentTaskId.value
  const taskIds = Array.from(new Set([
    pendingTaskId.value,
    currentDriverTaskId.value,
  ].filter(isValidBackendDriverTaskId)))
  const primaryTaskId = taskIds[0] || null
  const request = {}
  cancellationRequest = request
  isCancellingTask.value = true
  const isCurrentRequest = () => (
    isCurrentAccount() && currentTaskId.value === workspaceTaskId &&
    cancellationRequest === request &&
    (pendingTaskId.value || currentDriverTaskId.value || null) === primaryTaskId
  )

  try {
    clearPreviewPlaybackTimers()
    abortPendingGenerationRequest()
    if (!primaryTaskId) {
      applyCancelledTaskState()
      ElMessage.info('Task cancelled')
      return
    }

    // Keep observing the server while cancellation is pending or rejected.
    let primaryResult
    let primaryError
    for (const taskId of taskIds) {
      if (!isCurrentRequest()) return
      try {
        const result = await apiCancelDriverTask(taskId)
        if (!isCurrentRequest()) return
        if (taskId === primaryTaskId) primaryResult = result
      } catch (error) {
        if (!isCurrentRequest()) return
        console.warn('[cancelTask] Backend cancel failed:', taskId, error)
        if (taskId === primaryTaskId) primaryError = error
      }
    }
    if (!isCurrentRequest()) return
    if (primaryError) throw primaryError
    if (primaryResult?.cancelled === true || primaryResult?.status === 'cancelled') {
      applyCancelledTaskState()
      ElMessage.info('Task cancelled')
      return
    }
    if (isTerminalDriverStatus(primaryResult?.status)) {
      await applyTerminalTaskState(primaryResult, primaryTaskId)
      return
    }
    pollingNotice.value = (primaryResult?.reason || 'Cancellation is not confirmed.') +
      ' Monitoring will continue.'
    ElMessage.info(pollingNotice.value)
  } catch (error) {
    if (!isCurrentRequest()) return
    console.error('[cancelTask] Cancel error:', error)
    pollingNotice.value = 'Cancellation failed: ' + error.message + '. Monitoring will continue.'
    ElMessage.error(pollingNotice.value)
  } finally {
    if (cancellationRequest === request) resetCancellationRequest()
  }
}

onBeforeUnmount(() => {
  invalidateWorkspace()
})
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.driver-workspace {
  height: 100%;
  display: grid;
  grid-template-columns: minmax(320px, 0.6fr) minmax(560px, 1.4fr);
  gap: 12px;
  padding: clamp(8px, 0.75vw, 12px);
  overflow: hidden;
  color: #1e293b;
  background:
    radial-gradient(ellipse 80% 60% at 10% 0%, rgba(99, 102, 241, 0.07) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 95% 100%, rgba(16, 185, 129, 0.05) 0%, transparent 50%),
    #f8fafc;
}

.left-column {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: #cbd5e1 transparent;
}

.left-column::-webkit-scrollbar {
  width: 6px;
}

.left-column::-webkit-scrollbar-track {
  background: transparent;
}

.left-column::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.left-column::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

.config-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
  scrollbar-width: thin;
  scrollbar-color: #cbd5e1 transparent;
}

.config-section::-webkit-scrollbar {
  width: 6px;
}

.config-section::-webkit-scrollbar-track {
  background: transparent;
}

.config-section::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.config-section::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

.prompt-section {
  flex: 0 0 auto;
  min-height: 120px;
  display: flex;
  flex-direction: column;
}

.generation-validation {
  position: relative;
  display: grid;
  grid-template-columns: 30px minmax(0, 1fr) 24px;
  gap: 10px;
  align-items: flex-start;
  padding: 12px 12px;
  border: 1px solid #f8d18d;
  border-radius: 8px;
  background:
    linear-gradient(135deg, rgba(255, 251, 235, 0.98), rgba(255, 247, 237, 0.96));
  box-shadow: 0 8px 20px rgba(180, 83, 9, 0.10);
}

.generation-validation::before {
  position: absolute;
  top: 10px;
  bottom: 10px;
  left: 0;
  width: 3px;
  border-radius: 0 3px 3px 0;
  background: #f59e0b;
  content: '';
}

.generation-validation-icon {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #b45309;
  background: #fef3c7;
  border: 1px solid #fde68a;
}

.generation-validation-copy {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.generation-validation-title {
  color: #78350f;
  font-size: 13px;
  font-weight: 800;
  line-height: 1.25;
}

.generation-validation-message {
  color: #92400e;
  font-size: 12px;
  line-height: 1.45;
}

.generation-validation-items {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 2px;
}

.generation-validation-chip {
  display: inline-flex;
  align-items: center;
  min-height: 22px;
  padding: 2px 8px;
  border-radius: 999px;
  color: #7c2d12;
  background: #ffffff;
  border: 1px solid #fed7aa;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.2;
}

.generation-validation-close {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #b45309;
  background: transparent;
  cursor: pointer;
  transition: background 0.15s ease, color 0.15s ease;
}

.generation-validation-close:hover {
  color: #78350f;
  background: rgba(251, 191, 36, 0.18);
}

.validation-notice-enter-active,
.validation-notice-leave-active {
  transition: opacity 0.16s ease, transform 0.16s ease;
}

.validation-notice-enter-from,
.validation-notice-leave-to {
  opacity: 0;
  transform: translateY(4px);
}

.generate-btn {
  flex-shrink: 0;
  width: 100%;
  height: 44px;
  border: none;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #ffffff;
  background: #475569;
  box-shadow: 0 2px 6px rgba(71, 85, 105, 0.3);
  cursor: pointer;
  font-family: inherit;
  font-size: 14px;
  font-weight: 700;
  transition: all 0.2s ease;
}

.generate-btn:hover:not(:disabled) {
  background: #334155;
  box-shadow: 0 4px 10px rgba(71, 85, 105, 0.4);
  transform: translateY(-1px);
}

.generate-btn:active:not(:disabled) {
  transform: translateY(0);
}

.generate-btn:disabled {
  cursor: not-allowed;
  background: #94a3b8;
  opacity: 0.7;
  transform: none;
  box-shadow: 0 1px 3px rgba(148, 163, 184, 0.2);
}

.generate-btn.loading {
  background: #94a3b8;
  cursor: not-allowed;
  box-shadow: 0 1px 3px rgba(148, 163, 184, 0.2);
}

.spinner {
  width: 16px;
  height: 16px;
  display: inline-block;
  border-radius: 50%;
  border: 2px solid currentColor;
  border-right-color: transparent;
  animation: spin-btn 0.75s linear infinite;
}

@keyframes spin-btn {
  to { transform: rotate(360deg); }
}

.cancel-btn-top-right {
  position: absolute;
  top: 20px;
  right: 20px;
  height: 36px;
  min-width: 118px;
  padding: 0 16px;
  border: 1.5px solid #ef4444;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  color: #ef4444;
  background: #ffffff;
  box-shadow: 0 2px 4px rgba(239, 68, 68, 0.15);
  cursor: pointer;
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  transition: all 0.2s ease;
  white-space: nowrap;
  z-index: 10;
}

.cancel-btn-top-right:hover {
  background: #fef2f2;
  border-color: #dc2626;
  color: #dc2626;
  box-shadow: 0 4px 8px rgba(239, 68, 68, 0.25);
  transform: translateY(-1px);
}

.cancel-btn-top-right:disabled,
.cancel-btn-top-right.loading {
  cursor: not-allowed;
  opacity: 0.7;
  transform: none;
  box-shadow: 0 2px 4px rgba(239, 68, 68, 0.15);
}

.cancel-btn-top-right:active {
  transform: translateY(0);
  box-shadow: 0 2px 4px rgba(239, 68, 68, 0.15);
}

.chat-section {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

.right-column {
  display: flex;
  flex-direction: column;
  min-height: 0;
  overflow: hidden;
}

.guide-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: white;
  border: 1px solid #e8ecf1;
  border-radius: 14px;
  padding: 32px 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  overflow-y: auto;
}

.result-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 0;
  overflow-y: auto;
}

.guide-icon {
  width: 64px;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #e0e7ff, #ddd6fe);
  border-radius: 16px;
  margin-bottom: 16px;
}

.guide-title {
  font-size: 18px;
  font-weight: 700;
  color: #0f172a;
  margin-bottom: 8px;
}

.guide-sub {
  font-size: 13px;
  color: #64748b;
  text-align: center;
  margin-bottom: 24px;
  max-width: 320px;
}

.guide-steps {
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: 100%;
  max-width: 380px;
}

.guide-step {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
}

.step-num {
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #6366f1;
  color: white;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 700;
  flex-shrink: 0;
}

.step-text {
  font-size: 13px;
  color: #475569;
}

.cli-runtime-status {
  margin-top: 16px;
  padding: 12px 16px;
  border: 1px solid var(--border-color, #d1d5db);
  border-radius: 8px;
  font-size: 12px;
  line-height: 1.8;
  overflow-wrap: anywhere;
}

.loading-area {
  position: relative;  /* Required for .cancel-btn-top-right absolute positioning */
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  justify-content: flex-start;
  background: white;
  border: 1px solid #e8ecf1;
  border-radius: 14px;
  padding: 56px 24px 32px 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  overflow-y: auto;
}

.loading-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 20px;
  margin-top: 8px;
}

.ring-wrap {
  position: relative;
  width: 52px;
  height: 52px;
  flex-shrink: 0;
}

.ring-svg {
  width: 52px;
  height: 52px;
  transform: rotate(-90deg);
}

.ring-bg {
  fill: none;
  stroke: #e5e7eb;
  stroke-width: 3;
}

.ring-fg {
  fill: none;
  stroke: #2563eb;
  stroke-width: 3;
  stroke-dasharray: 94.2;
  stroke-linecap: round;
  transition: stroke-dashoffset 0.5s ease;
}

.ring-pct {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 700;
  color: #2563eb;
}

.loading-msg {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.msg-title {
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
}

.msg-sub {
  font-size: 12px;
  color: #6b7280;
  word-break: break-word;
}

.token-usage-display {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px 16px;
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
  border: 1px solid #bae6fd;
  border-radius: 8px;
  margin: 16px 0;
  font-size: 13px;
}

.token-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.token-label {
  color: #0369a1;
  font-weight: 500;
}

.token-value {
  color: #0c4a6e;
  font-weight: 600;
  font-family: 'Courier New', monospace;
}

.token-item.total {
  margin-left: auto;
  padding-left: 16px;
  border-left: 1px solid #7dd3fc;
}

.token-item.total .token-label {
  color: #0369a1;
  font-weight: 600;
}

.token-item.total .token-value {
  color: #0c4a6e;
  font-size: 14px;
  font-weight: 700;
}

.pipeline {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: nowrap;
  gap: 0;
  padding: 4px 0;
  overflow-x: auto;
}

.pipe-node {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 72px;
  flex-shrink: 0;
}

.pipe-icon {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid #e5e7eb;
  background: #f9fafb;
  transition: all 0.3s;
}

.pipe-label {
  font-size: 11px;
  color: #6b7280;
  text-align: center;
  white-space: nowrap;
}

.pipe-node.done .pipe-icon {
  border-color: #16a34a;
  background: #f0fdf4;
}

.pipe-node.done .pipe-label {
  color: #166534;
  font-weight: 500;
}

.pipe-check {
  color: #16a34a;
}

.pipe-node.active .pipe-icon {
  border-color: #2563eb;
  background: #eff6ff;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
}

.pipe-node.active .pipe-label {
  color: #1d4ed8;
  font-weight: 600;
}

.pipe-node.pending .pipe-label {
  color: #9ca3af;
}

.pipe-spinner {
  width: 18px;
  height: 18px;
  border: 2px solid #bfdbfe;
  border-top-color: #2563eb;
  border-radius: 50%;
  display: inline-block;
  animation: spin 0.8s linear infinite;
}

.pipe-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #d1d5db;
  display: inline-block;
}

.pipe-arrow {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  margin: 0 2px;
  margin-bottom: 22px;
}

.pipe-arrow svg line,
.pipe-arrow svg polyline {
  stroke: #d1d5db;
  transition: stroke 0.3s;
}

.pipe-arrow.lit svg line,
.pipe-arrow.lit svg polyline {
  stroke: #16a34a;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.result-wrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
  overflow: hidden;
}

.driver-result-report {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
}

.result-wrapper::-webkit-scrollbar {
  width: 6px;
}

.result-wrapper::-webkit-scrollbar-track {
  background: transparent;
}

.result-wrapper::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.result-wrapper::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

@media (max-width: 1180px) {
  .driver-workspace {
    grid-template-columns: 1fr;
    overflow-y: auto;
  }

  .left-column {
    min-height: 500px;
  }

  .right-column {
    min-height: 400px;
  }
}

@media (max-width: 760px) {
  .driver-workspace {
    padding: 8px;
  }
}
</style>
