<template>
  <el-drawer
    :model-value="modelValue"
    title="Skill Submissions"
    size="min(850px, 100vw)"
    @update:model-value="emit('update:modelValue', $event)"
  >
    <div class="submission-panel">
      <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
      <el-alert v-if="notice" :title="notice" type="success" :closable="false" show-icon />
      <section class="submission-upload">
        <h3>Submit a Skill</h3>
        <p>
          Upload SKILL.md or a ZIP with SKILL.md and references/. Name and description come from the
          file. An administrator reviews the package before publishing it to this deployment.
        </p>
        <label class="upload-field"
          >Skill file<input ref="fileInput" type="file" accept=".md,.zip" @change="selectFile"
        /></label>
        <details>
          <summary>Agent mapping (optional)</summary>
          <p>Keep the package mapping, or choose an Agent and stage for runtime use.</p>
          <el-select
            v-model="agent"
            placeholder="Keep package mapping"
            clearable
            @change="stage = ''"
          >
            <el-option
              v-for="target in targets"
              :key="target.agent"
              :value="target.agent"
              :label="target.agent"
            />
          </el-select>
          <el-select v-if="agent" v-model="stage" placeholder="Choose a stage">
            <el-option v-for="value in stages" :key="value" :value="value" :label="value" />
          </el-select>
        </details>
        <el-button
          type="primary"
          :loading="submitting"
          :disabled="!file || (!!agent && !stage)"
          @click="submit"
          >Submit for Review</el-button
        >
        <span class="submission-hint"
          >UTF-8 text only · 1 MiB total · 256 KiB per file · no scripts</span
        >
      </section>
      <div class="submission-toolbar">
        <el-button :type="!reviewQueue ? 'primary' : 'default'" @click="reviewQueue = false"
          >My Submissions</el-button
        >
        <el-button
          v-if="auth.isAdmin"
          :type="reviewQueue ? 'primary' : 'default'"
          @click="reviewQueue = true"
          >Review Queue</el-button
        >
        <el-button :loading="loading" @click="load">Refresh</el-button>
      </div>
      <div v-if="!items.length && !loading" class="submission-hint">No submissions yet.</div>
      <article v-for="item in items" :key="item.id" class="submission-row">
        <div>
          <strong>{{ item.name }}</strong
          ><el-tag size="small">{{ item.status }}</el-tag>
        </div>
        <p>{{ item.description }}</p>
        <p v-if="item.review_note" class="submission-hint">Review note: {{ item.review_note }}</p>
        <div class="submission-actions">
          <el-button @click="preview(item)">{{
            reviewQueue && item.status === 'pending' ? 'Review Package' : 'View Submission'
          }}</el-button>
          <el-button
            v-if="item.installed_id"
            tag="a"
            :href="skillPackageDownloadUrl(item.installed_id)"
            download
            >Export ZIP</el-button
          >
        </div>
      </article>
      <el-pagination
        :current-page="page"
        :page-size="20"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="changePage"
      />
      <p class="submission-hint">
        Published skills persist across application deployments. To move a skill to another
        deployment, export its ZIP and submit it there. Existing same-name packages are never
        overwritten.
      </p>
    </div>
    <el-dialog
      v-model="previewOpen"
      :title="selected?.name || 'Submission Preview'"
      width="min(780px, 94vw)"
      append-to-body
    >
      <el-alert v-if="reviewError" :title="reviewError" type="error" :closable="false" />
      <div v-if="previewLoading">Loading submitted package...</div>
      <template v-else-if="selected">
        <p class="submission-hint">SHA-256: {{ selected.content_sha256 }}</p>
        <details v-for="(text, path) in selected.files" :key="path" :open="path === 'SKILL.md'">
          <summary>{{ path }}</summary>
          <pre class="submission-preview">{{ text }}</pre>
        </details>
        <template v-if="auth.isAdmin && selected.status === 'pending'">
          <el-input
            v-model="reviewNote"
            type="textarea"
            :rows="2"
            maxlength="500"
            placeholder="Review note (required to reject)"
          />
          <p class="submission-hint">
            Publishing shares this package with all users of this deployment and loads its declared
            Agent mapping. Review its instructions and references before publishing.
          </p>
        </template>
      </template>
      <template #footer>
        <el-button @click="previewOpen = false">Close</el-button>
        <template v-if="auth.isAdmin && selected?.status === 'pending' && !previewLoading">
          <el-button :loading="reviewing" :disabled="!reviewNote.trim()" @click="review(false)"
            >Reject</el-button
          >
          <el-button type="primary" :loading="reviewing" @click="review(true)"
            >Publish &amp; Deploy</el-button
          >
        </template>
      </template>
    </el-dialog>
  </el-drawer>
</template>

<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import {
  submissionTargets,
  submitUserSkill,
  listSkillSubmissions,
  getSkillSubmission,
  publishSkillSubmission,
  rejectSkillSubmission,
  skillPackageDownloadUrl,
} from '../api/skillMarket.js'

const props = defineProps({ modelValue: Boolean })
const emit = defineEmits(['update:modelValue', 'published'])
const auth = useAuthStore()
const fileInput = ref(null),
  file = ref(null),
  targets = ref([]),
  agent = ref(''),
  stage = ref('')
const items = ref([]),
  total = ref(0),
  page = ref(1),
  reviewQueue = ref(false)
const error = ref(''),
  notice = ref(''),
  loading = ref(false),
  submitting = ref(false)
const previewOpen = ref(false),
  previewLoading = ref(false),
  selected = ref(null),
  reviewError = ref(''),
  reviewNote = ref(''),
  reviewing = ref(false)
const stages = computed(() => targets.value.find(item => item.agent === agent.value)?.stages || [])
let generation = 0,
  listVersion = 0,
  previewVersion = 0
function selectFile(event) {
  file.value = event.target.files?.[0] || null
  error.value = ''
  if (file.value?.size > 1024 * 1024) {
    file.value = null
    error.value = 'Skill upload exceeds the 1 MiB limit'
  }
}
async function load() {
  const version = ++listVersion
  if (!auth.isLoggedIn || !props.modelValue) return
  loading.value = true
  try {
    const result = await listSkillSubmissions(reviewQueue.value, page.value)
    if (version !== listVersion) return
    items.value = result.items
    total.value = result.total
  } catch (failure) {
    if (version === listVersion) error.value = failure.message
  } finally {
    if (version === listVersion) loading.value = false
  }
}
async function submit() {
  if (!file.value || submitting.value) return
  const current = generation
  submitting.value = true
  error.value = ''
  notice.value = ''
  try {
    const result = await submitUserSkill(file.value, agent.value, stage.value)
    if (current !== generation) return
    notice.value =
      result.status === 'rejected'
        ? `This package was already rejected. Revise it before resubmitting. ${result.review_note || ''}`
        : result.status === 'published'
          ? 'This package is already published. Open its submission to export the installed ZIP.'
          : 'Skill submitted for administrator review. It has not been deployed yet.'
    file.value = null
    if (fileInput.value) fileInput.value.value = ''
    reviewQueue.value = false
    page.value = 1
    await load()
  } catch (failure) {
    if (current === generation) error.value = failure.message
  } finally {
    if (current === generation) submitting.value = false
  }
}
async function preview(item) {
  const current = ++previewVersion
  selected.value = null
  reviewError.value = ''
  reviewNote.value = ''
  previewOpen.value = true
  previewLoading.value = true
  try {
    const result = await getSkillSubmission(item.id)
    if (current === previewVersion) selected.value = result
  } catch (failure) {
    if (current === previewVersion) reviewError.value = failure.message
  } finally {
    if (current === previewVersion) previewLoading.value = false
  }
}
async function review(publish) {
  if (!selected.value || reviewing.value) return
  const current = generation
  reviewing.value = true
  reviewError.value = ''
  try {
    const result = publish
      ? await publishSkillSubmission(selected.value.id)
      : await rejectSkillSubmission(selected.value.id, reviewNote.value.trim())
    if (current !== generation) return
    notice.value = publish
      ? `Published. ${result.integration?.message || 'Runtime integration status is unavailable.'}`
      : 'Submission rejected with a review note.'
    previewOpen.value = false
    await load()
    if (publish) emit('published')
  } catch (failure) {
    if (current === generation) reviewError.value = failure.message
  } finally {
    if (current === generation) reviewing.value = false
  }
}
function changePage(value) {
  page.value = value
  void load()
}
watch(reviewQueue, () => {
  page.value = 1
  items.value = []
  void load()
})
watch(
  () => [props.modelValue, auth.user?.id, auth.user?.name, auth.isLoggedIn, auth.isAdmin],
  async (values, previous) => {
    ++generation
    ++listVersion
    ++previewVersion
    items.value = []
    total.value = 0
    file.value = null
    selected.value = null
    previewOpen.value = false
    error.value = ''
    reviewError.value = ''
    notice.value = ''
    loading.value = false
    submitting.value = false
    reviewing.value = false
    if (!auth.isAdmin) reviewQueue.value = false
    if (fileInput.value) fileInput.value.value = ''
    if (previous && (values[1] !== previous[1] || values[2] !== previous[2] || !values[3])) {
      emit('update:modelValue', false)
      return
    }
    if (!props.modelValue || !auth.isLoggedIn) return
    const current = generation
    try {
      const result = await submissionTargets()
      if (current === generation) targets.value = result.items
    } catch (failure) {
      if (current === generation) error.value = failure.message
    }
    if (current === generation) void load()
  },
  { immediate: true }
)
onBeforeUnmount(() => {
  ++generation
  ++listVersion
  ++previewVersion
})
</script>

<style scoped>
.submission-panel {
  display: grid;
  gap: 18px;
}
.submission-upload {
  padding: 18px;
  background: #f1f5f9;
  border-radius: 12px;
  display: grid;
  gap: 12px;
}
.submission-upload h3,
.submission-upload p {
  margin: 0;
}
.submission-upload p,
.submission-hint {
  font-size: 12px;
  color: #64748b;
  line-height: 1.7;
  overflow-wrap: anywhere;
}
.upload-field {
  display: grid;
  gap: 8px;
}
.submission-toolbar,
.submission-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.submission-toolbar .el-button,
.submission-actions .el-button {
  margin: 0;
}
.submission-row {
  border-bottom: 1px solid #e2e8f0;
  padding: 14px 0;
}
.submission-row strong {
  margin-right: 12px;
}
.submission-row p {
  font-size: 13px;
}
.submission-preview {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  max-height: 320px;
  overflow-y: auto;
  background: #f8fafc;
  padding: 14px;
  font-size: 12px;
}
summary {
  cursor: pointer;
  padding: 8px 0;
}
</style>
