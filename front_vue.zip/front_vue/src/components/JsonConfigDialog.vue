<template>
  <el-dialog
    v-model="visible"
    width="720px"
    :close-on-click-modal="false"
    :show-close="false"
    @open="onOpen"
  >
    <template #header>
      <div class="dialog-header">
        <div class="header-icon">
          <el-icon size="20">
            <Document />
          </el-icon>
        </div>
        <div class="header-text">
          <div class="header-title">
            ENV Configuration
          </div>
          <div class="header-sub">
            Keys are fixed, only values can be modified
          </div>
        </div>
        <button
          class="close-btn"
          @click="visible = false"
        >
          <el-icon size="16">
            <Close />
          </el-icon>
        </button>
      </div>
    </template>

    <div class="editor-body">
      <div class="editor-toolbar">
        <div class="toolbar-info">
          <el-icon size="14">
            <InfoFilled />
          </el-icon>
          <span>Copy JSON to share with colleagues. Keys cannot be modified.</span>
        </div>
        <el-button
          size="small"
          text
          @click="resetToDefault"
        >
          <el-icon><RefreshRight /></el-icon> Reset
        </el-button>
      </div>

      <div class="config-lines">
        <div class="json-line opening">
          {
        </div>
        <div
          v-for="(key, index) in allowedKeys"
          :key="key"
          class="json-line field-line"
        >
          <span class="json-indent" />
          <span class="json-key">"{{ key }}"</span>
          <span class="json-colon">: </span>
          <input
            v-model="configValues[key]"
            class="json-value-input"
            :placeholder="`enter ${key}`"
          >
          <span
            v-if="index < allowedKeys.length - 1"
            class="json-comma"
          >,</span>
        </div>
        <div class="json-line closing">
          }
        </div>
      </div>

      <div class="preview-section">
        <div class="preview-header">
          <span class="preview-label">JSON Preview (copy to share)</span>
          <el-button
            size="small"
            text
            @click="copyJson"
          >
            <el-icon><DocumentCopy /></el-icon> Copy
          </el-button>
        </div>
        <pre class="json-preview">{{ jsonPreview }}</pre>
      </div>

      <transition name="fade">
        <div
          v-if="statusMsg"
          :class="['status-bar', statusType]"
        >
          <el-icon size="14">
            <SuccessFilled v-if="statusType === 'success'" />
            <WarningFilled v-else-if="statusType === 'warn'" />
            <CircleCloseFilled v-else />
          </el-icon>
          <span>{{ statusMsg }}</span>
        </div>
      </transition>
    </div>

    <template #footer>
      <div class="dialog-footer">
        <el-button
          size="large"
          @click="visible = false"
        >
          Cancel
        </el-button>
        <el-button
          size="large"
          type="primary"
          :loading="saving"
          @click="handleSave"
        >
          <el-icon v-if="!saving">
            <Check />
          </el-icon>
          Save
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, computed } from 'vue'
import { getEnvJson, saveEnvJson } from '../api/settings.js'

const visible = ref(false)
const saving = ref(false)
const statusMsg = ref('')
const statusType = ref('success')

// Fixed keys - CANNOT BE MODIFIED
const allowedKeys = ['TURING_API_BASE', 'TURING_API_KEY', 'TURING_DEFAULT_MODEL']

const configValues = reactive({
  TURING_API_BASE: '',
  TURING_API_KEY: '',
  TURING_DEFAULT_MODEL: '',
})

// Computed JSON preview for copying
const jsonPreview = computed(() => {
  const obj = {}
  allowedKeys.forEach(key => {
    obj[key] = configValues[key] || ''
  })
  return JSON.stringify(obj, null, 2)
})

function open() {
  visible.value = true
}

async function onOpen() {
  statusMsg.value = ''
  // Reset values
  allowedKeys.forEach(key => {
    configValues[key] = ''
  })

  try {
    const res = await getEnvJson()
    const envData = res?.data ?? res ?? {}
    // Only load allowed keys
    allowedKeys.forEach(key => {
      if (envData[key]) {
        configValues[key] = envData[key]
      }
    })
  } catch {
    statusMsg.value = 'Failed to load configuration'
    statusType.value = 'error'
  }
}

function resetToDefault() {
  allowedKeys.forEach(key => {
    configValues[key] = ''
  })
}

async function copyJson() {
  try {
    await navigator.clipboard.writeText(jsonPreview.value)
    statusMsg.value = 'Copied to clipboard!'
    statusType.value = 'success'
    setTimeout(() => {
      statusMsg.value = ''
    }, 2000)
  } catch {
    statusMsg.value = 'Failed to copy'
    statusType.value = 'error'
  }
}

async function handleSave() {
  saving.value = true
  statusMsg.value = ''

  try {
    // Only send allowed keys with non-empty values
    const payload = {}
    allowedKeys.forEach(key => {
      if (configValues[key]) {
        payload[key] = configValues[key]
      }
    })

    const res = await saveEnvJson(payload)
    statusMsg.value = res?.message || 'Saved successfully'
    statusType.value = 'success'
  } catch (e) {
    statusMsg.value = e?.message || 'Save failed'
    statusType.value = 'error'
  } finally {
    saving.value = false
  }
}

defineExpose({ open })
</script>

<style scoped>
.dialog-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 4px 0;
}

.header-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  background: linear-gradient(135deg, #f59e0b, #d97706);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  flex-shrink: 0;
}

.header-text {
  flex: 1;
}

.header-title {
  font-size: 16px;
  font-weight: 600;
  color: #111827;
  line-height: 1.3;
}

.header-sub {
  font-size: 13px;
  color: #6b7280;
  margin-top: 2px;
}

.close-btn {
  width: 32px;
  height: 32px;
  border: none;
  background: transparent;
  border-radius: 8px;
  cursor: pointer;
  color: #9ca3af;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.15s, color 0.15s;
}

.close-btn:hover {
  background: #f3f4f6;
  color: #374151;
}

.editor-body {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 8px 0 4px;
}

.editor-toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.toolbar-info {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: #6b7280;
}

.config-lines {
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 14px;
  font-family: 'JetBrains Mono', 'Menlo', 'Monaco', 'Courier New', monospace;
  font-size: 14px;
  font-weight: 500;
  letter-spacing: 0.3px;
}

.json-line {
  line-height: 2;
}

.json-line.opening,
.json-line.closing {
  color: #6b7280;
  font-weight: 500;
}

.json-line.field-line {
  display: flex;
  align-items: center;
  gap: 0;
}

.json-indent {
  color: #9ca3af;
}

.json-key {
  color: #92400e;
  background: #fef3c7;
  padding: 2px 6px;
  border-radius: 3px;
  font-weight: 600;
  user-select: none;
}

.json-colon {
  color: #6b7280;
}

.json-value-input {
  flex: 1;
  min-width: 200px;
  padding: 4px 8px;
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
  font-size: 13px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  background: white;
  color: #059669;
  outline: none;
  transition: all 0.15s ease;
}

.json-value-input:focus {
  border-color: #f59e0b;
  box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.15);
}

.json-value-input::placeholder {
  color: #9ca3af;
  font-style: italic;
}

.json-comma {
  color: #6b7280;
  margin-left: 2px;
}

.preview-section {
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  overflow: hidden;
}

.preview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  background: #f3f4f6;
  border-bottom: 1px solid #e5e7eb;
}

.preview-label {
  font-size: 12px;
  font-weight: 500;
  color: #6b7280;
}

.json-preview {
  margin: 0;
  padding: 12px;
  font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
  font-size: 12px;
  line-height: 1.6;
  color: #374151;
  overflow-x: auto;
  white-space: pre;
}

.status-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
}

.status-bar.success {
  background: #f0fdf4;
  color: #16a34a;
  border: 1px solid #bbf7d0;
}

.status-bar.warn {
  background: #fffbeb;
  color: #d97706;
  border: 1px solid #fde68a;
}

.status-bar.error {
  background: #fef2f2;
  color: #dc2626;
  border: 1px solid #fecaca;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s, transform 0.2s;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateY(-4px);
}
</style>