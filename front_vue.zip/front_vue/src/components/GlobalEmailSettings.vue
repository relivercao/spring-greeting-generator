<template>
  <details class="global-email-settings" @toggle="handleToggle">
    <summary>
      <span>Global email</span>
      <span class="mail-status">{{
        loaded ? (configured ? 'Configured' : 'Setup required') : 'Gmail / SMTP'
      }}</span>
    </summary>
    <div class="mail-settings-body">
      <p>
        Share one mailbox for registration codes and Agent approval emails. Gmail supports a Google
        app password with 2-Step Verification enabled.
      </p>
      <el-alert v-if="error" :title="error" type="error" :closable="false" />
      <el-alert v-if="status" :title="status" type="success" :closable="false" />
      <p v-if="loading" role="status">Loading email settings...</p>
      <el-button v-else-if="!loaded" size="small" @click="load">Retry</el-button>
      <template v-else>
        <label for="global-mail-provider">Provider</label>
        <el-select id="global-mail-provider" v-model="form.provider" @change="changeProvider">
          <el-option label="Gmail / Google Workspace" value="gmail" />
          <el-option label="Custom SMTP" value="custom" />
        </el-select>
        <div class="mail-grid">
          <div>
            <label for="global-mail-host">SMTP host</label>
            <el-input
              id="global-mail-host"
              v-model="form.host"
              :disabled="form.provider === 'gmail'"
              placeholder="smtp.gmail.com"
            />
          </div>
          <div>
            <label for="global-mail-port">Port</label>
            <el-input
              id="global-mail-port"
              v-model="form.port"
              inputmode="numeric"
              placeholder="587"
            />
          </div>
        </div>
        <label for="global-mail-security">Encryption</label>
        <el-select id="global-mail-security" v-model="form.security" @change="changeSecurity">
          <el-option label="STARTTLS" value="starttls" />
          <el-option label="SSL / TLS" value="ssl" />
          <el-option
            v-if="form.provider !== 'gmail'"
            label="None (unauthenticated relay only)"
            value="none"
          />
        </el-select>
        <label for="global-mail-username">{{
          form.provider === 'gmail' ? 'Gmail address' : 'SMTP username'
        }}</label>
        <el-input
          id="global-mail-username"
          v-model="form.username"
          placeholder="account@gmail.com"
          autocomplete="off"
        />
        <label for="global-mail-password">{{
          form.provider === 'gmail' ? 'Google app password' : 'SMTP password'
        }}</label>
        <el-input
          id="global-mail-password"
          v-model="password"
          type="password"
          show-password
          autocomplete="new-password"
          :placeholder="
            passwordConfigured ? 'Configured; leave blank to keep' : 'Enter the app password'
          "
        />
        <label for="global-mail-sender">Sender address</label>
        <el-input
          id="global-mail-sender"
          v-model="form.sender"
          placeholder="Defaults to the account address"
        />
        <p class="mail-hint">
          For Gmail, use the account address or a verified Send mail as alias. Personal Gmail access
          in Connected apps is authorized separately.
        </p>
        <label class="mail-switch">
          <el-switch v-model="form.approval_use_global" />
          Use the global mailbox for Agent approvals
        </label>
        <p v-if="!form.approval_use_global" class="mail-hint">
          The existing dedicated approval SMTP configuration will be retained.
        </p>
        <label class="mail-switch">
          <el-switch v-model="form.approval_enabled" />
          Enable email approval notifications
        </label>
        <p class="mail-hint">
          Disabled by default. Tasks must explicitly select the email approval channel.
        </p>
        <label for="global-mail-reviewers">Default reviewers</label>
        <el-input
          id="global-mail-reviewers"
          v-model="form.approval_recipients"
          placeholder="reviewer@example.com, team@example.com"
        />
        <div class="mail-actions">
          <el-button type="primary" :loading="saving" :disabled="checking" @click="save"
            >Save email settings</el-button
          >
          <el-button :loading="checking" :disabled="saving || dirty || !configured" @click="check"
            >Check saved connection</el-button
          >
        </div>
        <p class="mail-hint">
          Connection checks verify the saved SMTP login without sending an email.
        </p>
      </template>
    </div>
  </details>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import {
  getGlobalEmailSettings,
  saveGlobalEmailSettings,
  checkGlobalEmailConnection,
} from '../api/settings.js'

const form = reactive({
  provider: 'gmail',
  host: 'smtp.gmail.com',
  port: 587,
  security: 'starttls',
  username: '',
  sender: '',
  approval_enabled: false,
  approval_use_global: true,
  approval_recipients: '',
})
const loaded = ref(false)
const loading = ref(false)
const configured = ref(false)
const passwordConfigured = ref(false)
const password = ref('')
const baseline = ref('')
const saving = ref(false)
const checking = ref(false)
const error = ref('')
const status = ref('')
const dirty = computed(() => Boolean(password.value) || JSON.stringify(form) !== baseline.value)

function apply(configuration) {
  for (const key of Object.keys(form))
    if (configuration[key] !== undefined) form[key] = configuration[key]
  if (!configuration.configured && !configuration.host && !configuration.username) {
    form.provider = 'gmail'
    changeProvider()
  }
  configured.value = Boolean(configuration.configured)
  passwordConfigured.value = Boolean(configuration.password_configured)
  baseline.value = JSON.stringify(form)
  password.value = ''
}

function handleToggle(event) {
  if (event.target.open && !loaded.value && !loading.value) void load()
}

async function load() {
  loading.value = true
  error.value = ''
  try {
    apply(await getGlobalEmailSettings())
    loaded.value = true
  } catch (failure) {
    error.value = failure.message || 'Could not load email settings.'
  } finally {
    loading.value = false
  }
}

function changeProvider() {
  status.value = ''
  if (form.provider === 'gmail') {
    form.host = 'smtp.gmail.com'
    form.port = 587
    form.security = 'starttls'
  }
}

function changeSecurity() {
  status.value = ''
  if (form.provider === 'gmail') form.port = form.security === 'ssl' ? 465 : 587
}

async function save() {
  saving.value = true
  error.value = ''
  status.value = ''
  try {
    const result = await saveGlobalEmailSettings({
      ...form,
      port: Number(form.port),
      password: password.value || null,
    })
    apply(result)
    status.value = result.message || 'Global email settings saved.'
  } catch (failure) {
    error.value = failure.message || 'Could not save email settings.'
  } finally {
    saving.value = false
  }
}

async function check() {
  checking.value = true
  error.value = ''
  status.value = ''
  try {
    const result = await checkGlobalEmailConnection()
    status.value = result.message || 'SMTP connection verified.'
  } catch (failure) {
    error.value = failure.message || 'Could not verify the email connection.'
  } finally {
    checking.value = false
  }
}
</script>

<style scoped>
.global-email-settings {
  border: 1px solid #e2e6eb;
  border-radius: 8px;
  background: #fff;
}
summary {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  padding: 16px;
  cursor: pointer;
  color: #20242b;
  font-size: 15px;
  font-weight: 600;
}
summary::after {
  content: '+';
  color: #697386;
}
details[open] summary::after {
  content: '-';
}
.mail-status {
  margin-left: auto;
  color: #697386;
  font-size: 11px;
  font-weight: 400;
}
.mail-settings-body {
  padding: 0 16px 16px;
}
p {
  color: #697386;
  font-size: 12px;
  line-height: 1.6;
  margin: 0 0 14px;
}
label {
  display: block;
  margin: 14px 0 6px;
  color: #4b5563;
  font-size: 12px;
  font-weight: 600;
}
.el-select {
  width: 100%;
}
.mail-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 84px;
  gap: 12px;
}
.mail-switch {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 400;
}
.mail-hint {
  margin: 7px 0;
  color: #87909c;
  font-size: 11px;
}
.mail-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 18px;
}
.mail-actions .el-button {
  margin-left: 0;
}
.el-alert {
  margin-bottom: 12px;
}
</style>
