<template>
  <aside
    v-if="visible && updateStatus?.update_available"
    class="version-update-banner"
    :class="{ mandatory: updateStatus.release?.mandatory }"
    role="status"
    aria-live="polite"
  >
    <div class="update-icon" aria-hidden="true">
      <el-icon><Download /></el-icon>
    </div>
    <div class="update-copy">
      <div class="update-heading">
        <strong>Version {{ updateStatus.latest_version }} is available</strong>
        <span v-if="updateStatus.release?.mandatory" class="persistent-label">Persistent</span>
      </div>
      <span class="update-title">{{ updateStatus.release?.title || 'Application update' }}</span>
      <p v-if="updateStatus.release?.release_notes" class="update-notes">
        {{ updateStatus.release.release_notes }}
      </p>
      <small>Current version {{ updateStatus.current_version }}</small>
    </div>
    <div class="update-actions">
      <el-button type="primary" size="small" @click="confirmUpgrade">
        <el-icon><Download /></el-icon>
        Download update
      </el-button>
      <el-button
        v-if="!updateStatus.release?.mandatory"
        text
        size="small"
        aria-label="Dismiss update reminder"
        title="Dismiss update reminder"
        @click="dismissUpdate"
      >
        <el-icon><Close /></el-icon>
      </el-button>
    </div>
  </aside>
</template>

<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Close, Download } from '@element-plus/icons-vue'
import { checkForVersionUpdate } from '../api/version.js'

const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000
const updateStatus = ref(null)
const visible = ref(false)
let checkTimer = null
let requestInProgress = false

function dismissedVersionKey(version) {
  return `macode.dismissed-update:${version}`
}

function updateIsDismissed(version) {
  try {
    return globalThis.localStorage.getItem(dismissedVersionKey(version)) === '1'
  } catch {
    return false
  }
}

async function checkVersion() {
  if (requestInProgress) return
  requestInProgress = true
  try {
    const result = await checkForVersionUpdate()
    updateStatus.value = result
    globalThis.dispatchEvent(new CustomEvent('version:update-status', {
      detail: result,
    }))
    visible.value = Boolean(
      result?.update_available
      && (result.release?.mandatory || !updateIsDismissed(result.latest_version)),
    )
  } catch (error) {
    console.warn('Could not check for application updates:', error)
  } finally {
    requestInProgress = false
  }
}

function dismissUpdate() {
  try {
    globalThis.localStorage.setItem(
      dismissedVersionKey(updateStatus.value.latest_version),
      '1',
    )
  } catch {
    // The reminder remains dismissible for this page session without storage.
  }
  visible.value = false
}

async function confirmUpgrade() {
  const release = updateStatus.value?.release
  if (!release?.download_url) {
    ElMessage.error('The installer download is not configured for this release.')
    return
  }
  try {
    await ElMessageBox.confirm(
      `Download the installer for version ${release.version}? Run the installer to complete the upgrade.`,
      'Upgrade Macode',
      { confirmButtonText: 'Download update', cancelButtonText: 'Cancel', type: 'warning' },
    )
    globalThis.location.assign(release.download_url)
    visible.value = false
  } catch {
    // A cancelled confirmation requires no action.
  }
}

onMounted(() => {
  void checkVersion()
  checkTimer = globalThis.setInterval(checkVersion, CHECK_INTERVAL_MS)
  globalThis.addEventListener('focus', checkVersion)
})

onBeforeUnmount(() => {
  if (checkTimer) globalThis.clearInterval(checkTimer)
  globalThis.removeEventListener('focus', checkVersion)
})
</script>

<style scoped>
.version-update-banner {
  position: fixed;
  z-index: 3000;
  top: 64px;
  right: 16px;
  display: flex;
  align-items: flex-start;
  gap: 12px;
  width: min(520px, calc(100vw - 32px));
  padding: 14px;
  border: 1px solid #b6d4fe;
  border-left: 4px solid #2563eb;
  border-radius: 6px;
  background: #ffffff;
  box-shadow: 0 8px 24px rgb(15 23 42 / 16%);
  color: #1f2937;
}

.version-update-banner.mandatory {
  border-color: #f3b7b7;
  border-left-color: #c62828;
}

.update-icon {
  display: grid;
  flex: 0 0 30px;
  width: 30px;
  height: 30px;
  place-items: center;
  border-radius: 5px;
  background: #eaf2ff;
  color: #1d4ed8;
}

.mandatory .update-icon {
  background: #fff0f0;
  color: #b42318;
}

.update-copy {
  display: flex;
  flex: 1;
  min-width: 0;
  flex-direction: column;
  gap: 3px;
}

.update-heading {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  font-size: 13px;
}

.persistent-label {
  padding: 2px 5px;
  border-radius: 3px;
  background: #fde8e7;
  color: #a61b1b;
  font-size: 10px;
  font-weight: 700;
}

.update-title {
  color: #475569;
  font-size: 12px;
  overflow-wrap: anywhere;
}

.update-notes {
  display: -webkit-box;
  margin: 3px 0 0;
  overflow: hidden;
  color: #526174;
  font-size: 12px;
  line-height: 1.45;
  white-space: pre-line;
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
}

.update-copy small {
  margin-top: 2px;
  color: #7b8797;
  font-size: 11px;
}

.update-actions {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  gap: 2px;
}

@media (max-width: 540px) {
  .version-update-banner {
    top: 58px;
    right: 8px;
    width: calc(100vw - 16px);
    gap: 9px;
    padding: 11px;
  }

  .update-actions {
    flex-direction: column;
    align-items: flex-end;
  }

  .update-actions :deep(.el-button--primary) {
    min-height: 30px;
  }
}
</style>
