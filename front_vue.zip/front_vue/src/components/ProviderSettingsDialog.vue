<template>
  <el-dialog
    v-model="visible"
    width="540px"
    :close-on-click-modal="false"
    class="provider-dialog"
    @open="onOpen"
  >
    <template #header>
      <div class="dlg-header">
        <div class="dlg-icon">
          <el-icon size="20">
            <Connection />
          </el-icon>
        </div>
        <div class="dlg-title-group">
          <div class="dlg-title">
            Provider Settings v3.2
          </div>
          <div class="dlg-subtitle">
            Configure LLM providers and set default
          </div>
        </div>
      </div>
    </template>

    <div class="dlg-body">
      <!-- Provider Selector -->
      <div class="select-section">
        <div class="section-label">
          Select Provider
        </div>
        <el-select
          v-model="selectedProvider"
          size="large"
          class="provider-select"
        >
          <el-option
            v-for="p in providerList"
            :key="p.key"
            :label="p.title"
            :value="p.key"
          >
            <div class="select-option">
              <div
                class="select-option-icon"
                :style="{ background: colors[p.key] + '15', color: colors[p.key] }"
              >
                <el-icon size="14">
                  <component :is="icons[p.key]" />
                </el-icon>
              </div>
              <span class="select-option-name">{{ p.title }}</span>
              <span :class="['select-option-badge', { ok: p.configured }]">
                {{ p.configured ? 'Configured' : 'Not set' }}
              </span>
            </div>
          </el-option>
        </el-select>
      </div>

      <!-- Default Toggle -->
      <div class="default-row">
        <div class="default-left">
          <el-icon
            size="16"
            class="default-icon"
          >
            <Star />
          </el-icon>
          <div>
            <div class="default-title">
              Default Provider
            </div>
            <div class="default-hint">
              Use for all AI requests
            </div>
          </div>
        </div>
        <el-switch
          v-model="isDefaultProvider"
          :disabled="!isCurrentConfigured"
        />
      </div>

      <!-- Config Fields -->
      <div class="fields-section">
        <div class="section-label">
          {{ currentMeta?.title }} Configuration
        </div>

        <!-- DEBUG: Show raw backend data -->
        <div style="background: #fff3cd; padding: 8px; margin-bottom: 12px; border-radius: 4px; font-size: 11px;">
          <strong>DEBUG - Backend Data:</strong><br>
          AWS_PROFILE from backend: <code>{{ debugBackendData.AWS_PROFILE || '(empty)' }}</code><br>
          bedrockConfig.aws_profile: <code>{{ bedrockConfig.aws_profile || '(empty)' }}</code><br>
          <strong>Input field v-model:</strong> <code>{{ bedrockConfig.aws_profile }}</code><br>
          <el-button
            size="small"
            type="primary"
            style="margin-top: 8px;"
            @click="loadConfig"
          >
            🔄 Manual Reload Config
          </el-button>
        </div>

        <div class="fields-grid">
          <!-- Bedrock Fields -->
          <template v-if="selectedProvider === 'bedrock'">
            <div class="field-group">
              <label>Region</label>
              <el-input
                v-model="bedrockConfig.aws_region"
                placeholder="eu-west-1"
              />
            </div>
            <div class="field-group">
              <label>Profile</label>
              <el-input
                v-model="bedrockConfig.aws_profile"
                placeholder="default"
              />
            </div>
            <div class="field-group">
              <label>Model</label>
              <el-input
                v-model="bedrockConfig.default_model"
                placeholder="eu.anthropic.claude-sonnet-4-5-20250929-v1:0"
              />
            </div>
          </template>
          <template v-else-if="selectedProvider === 'macode'">
            <div class="field-group">
              <label>API Base</label>
              <el-input
                v-model="macodeConfig.api_base"
                placeholder="https://macode.cloud/v1"
              />
            </div>
            <div class="field-group">
              <label>API Key</label>
              <el-input
                v-model="macodeConfig.api_key"
                type="password"
                show-password
                placeholder="Enter Macode API key"
              />
            </div>
            <div class="field-group">
              <label>Model</label>
              <el-input
                v-model="macodeConfig.default_model"
                placeholder="claude-sonnet-4-6"
              />
            </div>
          </template>
        </div>
      </div>

      <!-- JSON Panel -->
      <div class="json-section">
        <div class="json-row">
          <div class="json-info">
            <el-icon size="16">
              <Document />
            </el-icon>
            <span>JSON Configuration</span>
          </div>
          <div class="json-btns">
            <el-button
              size="small"
              @click="showJsonDialog = true"
            >
              View / Edit
            </el-button>
          </div>
        </div>
      </div>

      <!-- JSON Dialog -->
      <el-dialog
        v-model="showJsonDialog"
        title="JSON Configuration"
        width="600px"
        append-to-body
      >
        <div class="json-dialog-content">
          <div class="json-dialog-toolbar">
            <span>Paste or edit configuration JSON</span>
            <div class="json-dialog-btns">
              <el-button
                size="small"
                @click="copyJson"
              >
                Copy
              </el-button>
              <el-button
                size="small"
                type="primary"
                @click="applyJson"
              >
                Apply
              </el-button>
            </div>
          </div>
          <el-input
            v-model="jsonText"
            type="textarea"
            :rows="15"
            placeholder="{&quot;default_provider&quot;: &quot;macode&quot;, ...}"
            class="json-textarea"
          />
        </div>
      </el-dialog>

      <!-- Status -->
      <transition name="fade">
        <div
          v-if="statusMsg"
          :class="['status-bar', statusType]"
        >
          <el-icon size="14">
            <CircleCheck v-if="statusType === 'success'" />
            <CircleClose v-else />
          </el-icon>
          {{ statusMsg }}
        </div>
      </transition>
    </div>

    <template #footer>
      <div class="dlg-footer">
        <el-button
          size="default"
          @click="visible = false"
        >
          Cancel
        </el-button>
        <el-button
          size="default"
          type="primary"
          :loading="saving"
          @click="handleSave"
        >
          Save Changes
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { computed, ref, watch, onMounted } from 'vue'
import { getEnvJson, saveProviderSettings } from '../api/settings.js'
import {
  Connection, Star, Document, CircleCheck, CircleClose,
  Platform, Cpu, Grid
} from '@element-plus/icons-vue'

const visible = ref(false)
const saving = ref(false)
const statusMsg = ref('')
const statusType = ref('success')
const selectedProvider = ref('macode')
const defaultProvider = ref('macode')
const showJsonDialog = ref(false)
const jsonText = ref('')
const debugBackendData = ref({})

// Separate config objects for each provider
const bedrockConfig = ref({
  aws_region: 'eu-west-1',
  aws_profile: '',
  default_model: 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0'
})
const macodeConfig = ref({
  api_base: 'https://macode.cloud/v1',
  api_key: '',
  default_model: 'claude-sonnet-4-6',
})

const icons = {
  bedrock: Grid,
  macode: Platform,
}

const colors = {
  bedrock: '#ec4899',
  macode: '#2563eb',
}

const meta = {
  bedrock: {
    title: 'AWS Bedrock',
    fields: [
      { key: 'aws_region', label: 'Region', placeholder: 'eu-west-1' },
      { key: 'aws_profile', label: 'Profile', placeholder: 'default' },
      { key: 'default_model', label: 'Model', placeholder: 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0' },
    ],
  },
  macode: {
    title: 'Macode',
    fields: [
      { key: 'api_base', label: 'API Base', placeholder: 'https://macode.cloud/v1' },
      { key: 'api_key', label: 'API Key', placeholder: 'Enter Macode API key' },
      { key: 'default_model', label: 'Model', placeholder: 'claude-sonnet-4-6' },
    ],
  },
}

const providerList = computed(() =>
  Object.keys(meta).map(key => ({
    key,
    title: meta[key].title,
    configured: isConfigured(key),
  }))
)

const currentMeta = computed(() => meta[selectedProvider.value])
const isCurrentConfigured = computed(() => isConfigured(selectedProvider.value))

const isDefaultProvider = computed({
  get: () => defaultProvider.value === selectedProvider.value,
  set: v => { if (v && isCurrentConfigured.value) defaultProvider.value = selectedProvider.value },
})

function unmask(value) {
  return value?.includes('***') ? '' : value || ''
}

function isConfigured(key) {
  if (key === 'bedrock') {
    return !!(bedrockConfig.value.aws_profile || bedrockConfig.value.aws_region)
  }
  if (key === 'macode') {
    return !!(macodeConfig.value.api_base && macodeConfig.value.api_key)
  }
  return false
}

// Update JSON when config changes
watch([bedrockConfig, macodeConfig, defaultProvider], () => {
  jsonText.value = JSON.stringify({
    default_provider: defaultProvider.value,
    providers: {
      bedrock: { ...bedrockConfig.value },
      macode: { ...macodeConfig.value },
    },
  }, null, 2)
}, { deep: true })

function copyJson() {
  navigator.clipboard.writeText(jsonText.value)
  setStatus('Copied!', 'success')
}

function applyJson() {
  try {
    const data = JSON.parse(jsonText.value)
    const p = data.providers || {}

    if (p.bedrock) {
      Object.assign(bedrockConfig.value, p.bedrock)
    }
    if (p.macode) {
      Object.assign(macodeConfig.value, p.macode)
    }
    if (data.default_provider) {
      defaultProvider.value = data.default_provider
    }

    setStatus('Applied!', 'success')
    showJsonDialog.value = false
  } catch (e) {
    setStatus('Invalid JSON', 'error')
  }
}

function open() {
  visible.value = true
}

async function onOpen() {
  console.log('[onOpen] Dialog opened, loading config...')
  await loadConfig()
}

// Watch visible changes to ensure config is loaded when dialog opens
watch(visible, async (newVal) => {
  if (newVal) {
    console.log('[watch] Dialog became visible, loading config...')
    await loadConfig()
  }
})

// Load config on component mount
onMounted(async () => {
  console.log('[onMounted] Component mounted, loading initial config...')
  await loadConfig()
})

async function loadConfig() {
  console.log('[loadConfig] Function called! Starting to load config...')
  try {
    console.log('[loadConfig] Calling getEnvJson()...')
    const res = await getEnvJson()
    console.log('[loadConfig] getEnvJson() returned:', res)
    const env = res?.data || {}

    // Load provider configuration while preserving masked credentials.
    Object.assign(bedrockConfig.value, {
      aws_region: env.AWS_REGION || 'eu-west-1',
      aws_profile: env.AWS_PROFILE || '',
      default_model: env.BEDROCK_DEFAULT_MODEL || env.ANTHROPIC_DEFAULT_SONNET_MODEL || 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0'
    })
    Object.assign(macodeConfig.value, {
      api_base: env.TURING_API_BASE || 'https://macode.cloud/v1',
      api_key: unmask(env.TURING_API_KEY),
      default_model: env.TURING_DEFAULT_MODEL || 'claude-sonnet-4-6',
    })

    // Set default provider
    defaultProvider.value = env.DEFAULT_PROVIDER || 'macode'

  } catch (e) {
    console.error('[loadConfig] Error:', e)
    setStatus('Load failed', 'error')
  }
}

function setStatus(msg, type = 'success') {
  statusMsg.value = msg
  statusType.value = type
  setTimeout(() => {
    statusMsg.value = ''
  }, 3000)
}

async function handleSave() {
  saving.value = true

  console.log('[handleSave] Saving bedrockConfig:', bedrockConfig.value)
  console.log('[handleSave] aws_profile value:', bedrockConfig.value.aws_profile)

  try {
    await saveProviderSettings({
      default_provider: defaultProvider.value,
      providers: {
        bedrock: { ...bedrockConfig.value },
        macode: { ...macodeConfig.value },
      },
    })

    setStatus('Saved successfully!', 'success')
    console.log('[handleSave] Save successful, reloading from backend to confirm')
    
    // Reload config from backend to ensure UI shows saved values
    await loadConfig()

  } catch (e) {
    console.error('[handleSave] Error:', e)
    // The shared HTTP client normalizes API errors to HttpError.message.
    setStatus(e?.message || e?.details?.detail || 'Save failed', 'error')
  } finally {
    saving.value = false
  }
}

defineExpose({ open })
</script>

<style scoped>
.dlg-header {
  display: flex;
  align-items: center;
  gap: 14px;
  padding-bottom: 6px;
}

.dlg-icon {
  width: 42px;
  height: 42px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}

.dlg-title {
  font-size: 17px;
  font-weight: 700;
  color: #1f2937;
}

.dlg-subtitle {
  font-size: 12px;
  color: #6b7280;
  margin-top: 2px;
}

.dlg-body {
  display: flex;
  flex-direction: column;
  gap: 18px;
  max-height: 65vh;
  overflow-y: auto;
  padding-right: 4px;
}

.section-label {
  font-size: 12px;
  font-weight: 600;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 10px;
}

/* Provider Select */
.provider-select {
  width: 100%;
}

.select-option {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
}

.select-option-icon {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.select-option-name {
  flex: 1;
  font-weight: 500;
  color: #1f2937;
}

.select-option-badge {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 10px;
  background: #f3f4f6;
  color: #9ca3af;
}

.select-option-badge.ok {
  background: #d1fae5;
  color: #059669;
}

/* Default Row */
.default-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  background: linear-gradient(135deg, #fef3c7, #fff);
  border: 1px solid #fcd34d;
  border-radius: 10px;
}

.default-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.default-icon { color: #f59e0b; }

.default-title { font-size: 14px; font-weight: 600; color: #1f2937; }
.default-hint { font-size: 11px; color: #92400e; margin-top: 1px; }

/* Fields */
.fields-section {
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  padding: 16px;
}

.fields-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.field-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.field-group label {
  font-size: 12px;
  font-weight: 600;
  color: #4b5563;
}

/* JSON Section */
.json-section {
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  background: #f9fafb;
  padding: 12px 14px;
}

.json-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.json-info {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #374151;
}

.json-btns {
  display: flex;
  gap: 8px;
}

/* JSON Dialog */
.json-dialog-content {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.json-dialog-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.json-dialog-toolbar span {
  font-size: 13px;
  color: #6b7280;
}

.json-dialog-btns {
  display: flex;
  gap: 8px;
}

.json-textarea :deep(textarea) {
  font-family: 'SF Mono', Monaco, Menlo, monospace;
  font-size: 12px;
  background: #1f2937;
  color: #e5e7eb;
  border: none;
  border-radius: 8px;
  padding: 12px;
}

/* Status */
.status-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 14px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
}

.status-bar.success {
  background: #d1fae5;
  color: #059669;
}

.status-bar.error {
  background: #fee2e2;
  color: #dc2626;
}

.dlg-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

/* Transitions */
.fade-enter-active, .fade-leave-active { transition: opacity 0.2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

.slide-enter-active, .slide-leave-active { transition: all 0.2s ease; }
.slide-enter-from, .slide-leave-to { opacity: 0; max-height: 0; }
.slide-enter-to, .slide-leave-from { max-height: 200px; }
</style>
