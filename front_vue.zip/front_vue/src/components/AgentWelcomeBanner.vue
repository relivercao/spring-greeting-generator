<template>
  <section
    class="hero-banner"
    aria-labelledby="welcome-title"
  >
    <div class="hero-copy">
      <div class="hero-kicker">
        <span class="hero-kicker-mark" />
        <span>Macode AI development studio</span>
      </div>
      <h1
        id="welcome-title"
        class="hero-title"
      >
        Meet your <span>Omni Agent</span>
      </h1>
      <p class="hero-sub">
        A focused team of specialist Agents for building, testing, debugging, and shipping firmware.
      </p>
      <div class="hero-details">
        <span><strong>{{ agentCount }}</strong> specialist Agents</span>
        <span>One connected workspace</span>
      </div>
      <button
        type="button"
        class="hero-cta"
        @click="$emit('explore-agents')"
      >
        Explore Agents
        <el-icon size="15">
          <ArrowDown />
        </el-icon>
      </button>
    </div>

    <div
      class="hero-art"
      aria-hidden="true"
    >
      <div class="hero-art-caption">
        <span class="hero-art-number">01</span>
        <span>Chat Agent</span>
      </div>
      <AgentMascot
        :agent="{ id: 1, name: 'Chat Agent', color: '#2563eb' }"
        size="hero-art"
      />
      <span class="hero-art-mark hero-art-mark--one">OMNI</span>
      <span class="hero-art-mark hero-art-mark--two">AI</span>
    </div>
  </section>
</template>

<script setup>
import { ArrowDown } from '@element-plus/icons-vue'
import AgentMascot from './AgentMascot.vue'

defineProps({ agentCount: { type: Number, default: 0 } })
defineEmits(['explore-agents'])
</script>

<style scoped>
.hero-banner {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(270px, 340px);
  min-height: 276px;
  overflow: hidden;
  border: 1px solid #c7d9e8;
  border-radius: 24px;
  background: #edf7ff;
  box-shadow: 0 8px 22px rgba(31, 73, 106, 0.08);
}

.hero-banner::before {
  position: absolute;
  inset: 18px auto 18px 0;
  width: 4px;
  border-radius: 0 4px 4px 0;
  background: #2563eb;
  content: '';
}

.hero-copy {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 34px 42px;
}

.hero-kicker {
  display: flex;
  align-items: center;
  gap: 9px;
  color: #3c6c95;
  font-size: 11px;
  font-weight: 750;
  letter-spacing: 1.35px;
  text-transform: uppercase;
}

.hero-kicker-mark {
  width: 22px;
  height: 3px;
  border-radius: 2px;
  background: #2563eb;
}

.hero-title {
  max-width: 580px;
  margin: 14px 0 10px;
  color: #102a43;
  font-size: clamp(30px, 4vw, 48px);
  font-weight: 760;
  line-height: 1.06;
  letter-spacing: -0.6px;
}

.hero-title span { color: #2563eb; }

.hero-sub {
  max-width: 560px;
  margin: 0;
  color: #536d83;
  font-size: 14px;
  line-height: 1.65;
}

.hero-details {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 16px;
  margin-top: 18px;
  color: #58738a;
  font-size: 12px;
}

.hero-details strong { color: #173b5b; font-size: 14px; }

.hero-cta {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-height: 36px;
  margin-top: 22px;
  padding: 0 15px;
  border: 1px solid #2563eb;
  border-radius: 9px;
  background: #2563eb;
  color: #ffffff;
  font-family: inherit;
  font-size: 12px;
  font-weight: 700;
  cursor: pointer;
  transition: background 0.15s, transform 0.15s;
}

.hero-cta:hover { background: #1d4ed8; transform: translateY(-1px); }

.hero-art {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 276px;
  padding: 58px 0 28px;
  overflow: hidden;
  border-left: 1px solid #c7d9e8;
  background: #d8efff;
}

.hero-art::before,
.hero-art::after {
  position: absolute;
  border: 1px solid rgba(37, 99, 235, 0.2);
  content: '';
}

.hero-art::before {
  width: 210px;
  height: 210px;
  border-radius: 50%;
}

.hero-art::after {
  width: 140px;
  height: 140px;
  border-radius: 50%;
}

.hero-art-caption {
  position: absolute;
  top: 18px;
  left: 20px;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 8px;
  color: #315b7c;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}

.hero-art-number {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 27px;
  height: 27px;
  border-radius: 8px;
  background: #2563eb;
  color: #ffffff;
  font-size: 11px;
}

.hero-art-mark {
  position: absolute;
  z-index: 2;
  color: rgba(37, 99, 235, 0.4);
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 2px;
}

.hero-art-mark--one { right: 18px; top: 23px; }
.hero-art-mark--two { right: 22px; bottom: 20px; color: rgba(8, 123, 120, 0.5); }

@media (max-width: 1000px) {
  .hero-banner { grid-template-columns: minmax(0, 1fr) 250px; }
  .hero-copy { padding: 30px; }
}

@media (max-width: 640px) {
  .hero-banner { display: block; }
  .hero-copy { padding: 26px 24px 24px; }
  .hero-art { min-height: 230px; border-top: 1px solid #c7d9e8; border-left: 0; }
}

@media (prefers-reduced-motion: reduce) {
  .hero-cta { transition: none; transform: none; }
}
</style>
