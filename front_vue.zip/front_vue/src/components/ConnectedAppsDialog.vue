<template>
  <el-dialog
    :model-value="modelValue"
    title=""
    aria-label="Connected apps"
    width="min(1040px, calc(100vw - 32px))"
    top="5vh"
    append-to-body
    :close-on-click-modal="false"
    class="connected-apps-dialog"
    @update:model-value="emit('update:modelValue', $event)"
  >
    <ConnectedAppsPanel v-if="modelValue" :return-path="returnPath" @use-app="emit('use-app', $event)" />
    <template #footer>
      <el-button @click="emit('update:modelValue', false)">Done</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import ConnectedAppsPanel from './ConnectedAppsPanel.vue'

defineProps({
  modelValue: { type: Boolean, default: false },
  returnPath: { type: String, default: '/' },
})
const emit = defineEmits(['update:modelValue', 'use-app'])
</script>
