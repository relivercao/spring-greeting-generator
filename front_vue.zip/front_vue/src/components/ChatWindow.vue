<template>
  <div class="chat-window">
    <!-- Top bar -->
    <div class="chat-topbar">
      <div class="topbar-left">
        <div
          v-if="agent"
          class="topbar-agent"
        >
          <AgentMascot :agent="agent" size="chat">
            <div
              class="topbar-agent-icon"
              :style="{ background: agent.color + '18', color: agent.color }"
            >
              <el-icon size="14">
                <component :is="agent.icon" />
              </el-icon>
            </div>
          </AgentMascot>
          <span class="topbar-agent-name">{{ agent.name }}</span>
          <span
            v-if="session.messages.length > 0"
            class="topbar-msg-count"
          >
            {{ session.messages.length }} messages
          </span>
        </div>
      </div>
      <div class="topbar-actions">
        <el-tooltip
          content="Clear messages"
          placement="bottom"
        >
          <button
            class="topbar-btn"
            :disabled="session.messages.length === 0"
            @click="handleClearChat"
          >
            <el-icon size="14">
              <Delete />
            </el-icon>
          </button>
        </el-tooltip>
      </div>
    </div>

    <!-- Messages Area -->
    <div
      ref="messagesEl"
      class="messages-area"
      @scroll="handleScroll"
      @click="handleCodeCopy"
    >
      <div class="messages-inner">
        <!-- Empty state -->
        <div
          v-if="session.messages.length === 0"
          class="empty-chat"
        >
          <div
            class="empty-icon-wrap"
            :style="agent ? { background: agent.color + '12' } : {}"
          >
            <el-icon
              size="28"
              :style="agent ? { color: agent.color } : {}"
            >
              <component :is="agent?.icon || 'ChatDotRound'" />
            </el-icon>
          </div>
          <p class="empty-text">
            Start a conversation with <strong>{{ agent?.name }}</strong>
          </p>
          <p class="empty-sub">
            {{ agent?.description }}
          </p>
        </div>

        <!-- Messages -->
        <div
          v-for="msg in session.messages"
          :key="msg.id"
          class="message-row"
          :class="msg.role"
        >
          <!-- Shared left-side avatar -->
          <div
            class="msg-avatar"
            :class="msg.role + '-avatar'"
            :style="msg.role === 'assistant' && agent ? { background: agent.color } : {}"
          >
            <el-icon
              v-if="msg.role === 'assistant'"
              size="13"
            >
              <component :is="agent?.icon || 'Cpu'" />
            </el-icon>
            <span v-else>Me</span>
          </div>

          <!-- Shared right-side message bubble -->
          <div
            class="msg-bubble"
            :class="msg.role + '-bubble'"
          >
            <!-- Message header (role name) -->
            <div class="msg-header">
              <span class="msg-role">{{ msg.role === 'user' ? 'My Question' : (agent?.name || 'AI Assistant') }}</span>
              <button
                class="delete-msg-btn"
                title="Delete message"
                @click="handleDeleteMessage(msg.id)"
              >
                <el-icon size="11">
                  <Delete />
                </el-icon>
              </button>
            </div>

            <!-- Message body: truncate with displayIndex while keeping code blocks intact -->
            <div
              v-if="msg.role === 'assistant' && withoutGeneratedFileLines(msg.content)"
              class="msg-content"
              v-html="renderContent(
                msg.typing && msg.displayIndex != null && msg.displayIndex < msg.content.length
                  ? msg.content.slice(0, msg.displayIndex)
                  : msg.content
              )"
            />
            <div
              v-else-if="msg.role !== 'assistant'"
              class="msg-content"
            >
              {{ msg.content }}
            </div>
            <div v-if="msg.attachments?.length" class="message-attachments">
              <span v-for="name in msg.attachments" :key="name" class="message-attachment">
                {{ name }}
              </span>
            </div>
            <ChatGeneratedFiles
              v-if="msg.role === 'assistant'"
              :files="msg.artifacts || msg.metadata?.data?.artifacts || []"
              :content="msg.content"
            />
            <span
              v-if="msg.typing"
              class="typing-cursor"
            >▌</span>

            <!-- Message footer (time) -->
            <div class="msg-footer">
              <span class="msg-time">{{ msg.time }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Scroll buttons -->
    <transition name="fade">
      <div
        v-if="showScrollButtons"
        class="scroll-buttons"
      >
        <el-tooltip
          content="Scroll to top"
          placement="left"
        >
          <button
            class="scroll-btn"
            @click="scrollToTop"
          >
            <el-icon size="16">
              <ArrowUp />
            </el-icon>
          </button>
        </el-tooltip>
        <el-tooltip
          content="Scroll to bottom"
          placement="left"
        >
          <button
            class="scroll-btn"
            @click="scrollToBottom"
          >
            <el-icon size="16">
              <ArrowDown />
            </el-icon>
          </button>
        </el-tooltip>
      </div>
    </transition>

    <!-- Input Area -->
    <div class="input-area">
      <div class="input-wrapper">
        <el-tooltip
          v-if="canAttachFiles"
          content="Attach file"
          placement="top"
        >
          <button class="attach-btn" aria-label="Attach files" @click="fileInputEl?.click()">
            <el-icon size="16">
              <Paperclip />
            </el-icon>
          </button>
        </el-tooltip>

        <input
          v-if="canAttachFiles"
          ref="fileInputEl"
          class="attachment-input"
          type="file"
          multiple
          accept=".txt,.md,.markdown,.csv,.json,.jsonl,.xml,.yaml,.yml,.toml,.ini,.cfg,.log,.c,.h,.cc,.cpp,.cxx,.hpp,.py,.js,.ts,.jsx,.tsx,.vue,.css,.html,.sh,.qbs,.sql,.rs,.go,.java,.cs,.cmake,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.png,.jpg,.jpeg,.webp,.bmp,.gif,.tif,.tiff"
          @change="handleFileChange"
        >

        <textarea
          ref="inputEl"
          v-model="inputText"
          class="chat-input"
          :placeholder="`Send message to ${agent?.name || 'AI'}...`"
          rows="1"
          @keydown.enter.exact.prevent="handleSend"
          @keydown.enter.shift.exact="() => {}"
          @input="autoResize"
        />

        <button
          class="send-btn"
          :class="{ active: inputText.trim() || attachments.length }"
          :disabled="!inputText.trim() && !attachments.length"
          @click="handleSend"
        >
          <el-icon size="15">
            <Promotion />
          </el-icon>
        </button>
      </div>
      <div v-if="attachments.length" class="attachment-list">
        <div v-for="file in attachments" :key="file.name" class="attachment-chip">
          <span class="attachment-name">{{ file.name }}</span>
          <button type="button" :aria-label="`Remove ${file.name}`" @click="removeAttachment(file.name)">
            <el-icon size="12"><Close /></el-icon>
          </button>
        </div>
      </div>
      <p v-if="attachmentError" class="attachment-error" role="alert">{{ attachmentError }}</p>
      <div class="input-hint">
        <span>Enter to send · Shift+Enter for new line</span>
        <label class="web-search-toggle">
          <input
            type="checkbox"
            :checked="webSearchEnabled"
            :disabled="attachments.length > 0"
            @change="updateWebSearchPreference"
          >
          <span>{{ attachments.length ? 'Web search paused for private files' : 'Web search' }}</span>
        </label>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, nextTick, computed } from 'vue'
import { ArrowUp, ArrowDown, Close } from '@element-plus/icons-vue'
import { renderChatContent } from '../utils/chatContent.js'
import { withoutGeneratedFileLines } from '../utils/generatedFiles.js'
import { loadWebSearchPreference, saveWebSearchPreference } from '../utils/chatPreferences.js'
import ChatGeneratedFiles from './ChatGeneratedFiles.vue'
import AgentMascot from './AgentMascot.vue'

const props = defineProps({
  session: { type: Object, default: () => ({ id: null, messages: [] }) },
  agent: Object
})

const emit = defineEmits(['send-message', 'clear-chat', 'delete-message'])

const canAttachFiles = computed(() => ['1', 'chat', 'fw_chatbot'].includes(String(props.agent?.id || '')))
const inputText = ref('')
const messagesEl = ref(null)
const inputEl = ref(null)
const fileInputEl = ref(null)
const attachments = ref([])
const attachmentError = ref('')
const showScrollButtons = ref(false)
const webSearchEnabled = ref(loadWebSearchPreference())

function updateWebSearchPreference(event) {
  webSearchEnabled.value = event.target.checked
  saveWebSearchPreference(webSearchEnabled.value)
}

function handleSend() {
  const text = inputText.value.trim()
  if (!text && !attachments.value.length) return
  if (attachments.value.length) {
    emit('send-message', text || 'Please analyze the attached files.', webSearchEnabled.value, [...attachments.value])
  } else {
    emit('send-message', text, webSearchEnabled.value)
  }
  inputText.value = ''
  attachments.value = []
  if (fileInputEl.value) fileInputEl.value.value = ''
  attachmentError.value = ''
  nextTick(() => {
    if (inputEl.value) inputEl.value.style.height = 'auto'
    scrollToBottom()
  })
}

function handleFileChange(event) {
  const files = Array.from(event.target.files || [])
  const next = [...attachments.value]
  const allowed = /\.(txt|md|markdown|csv|json|jsonl|xml|yaml|yml|toml|ini|cfg|log|c|h|cc|cpp|cxx|hpp|py|js|ts|jsx|tsx|vue|css|html|sh|qbs|sql|rs|go|java|cs|cmake|pdf|doc|docx|ppt|pptx|xls|xlsx|png|jpg|jpeg|webp|bmp|gif|tif|tiff)$/i
  for (const file of files) {
    if (!allowed.test(file.name)) {
      attachmentError.value = `${file.name}: unsupported file type`
      continue
    }
    if (file.size > 5 * 1024 * 1024) {
      attachmentError.value = `${file.name}: file exceeds the 5 MB limit`
      continue
    }
    if (next.some(item => item.name.toLowerCase() === file.name.toLowerCase())) continue
    if (next.length >= 5) {
      attachmentError.value = 'You can attach up to 5 files'
      break
    }
    if (next.reduce((sum, item) => sum + item.size, file.size) > 10 * 1024 * 1024) {
      attachmentError.value = 'Attachments are limited to 10 MB in total'
      break
    }
    next.push(file)
  }
  attachments.value = next
  event.target.value = ''
}

function removeAttachment(name) {
  attachments.value = attachments.value.filter(file => file.name !== name)
  attachmentError.value = ''
}

function handleClearChat() {
  emit('clear-chat')
}

function handleDeleteMessage(messageId) {
  emit('delete-message', messageId)
}

function autoResize(e) {
  const el = e.target
  el.style.height = 'auto'
  el.style.height = Math.min(el.scrollHeight, 160) + 'px'
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesEl.value) messagesEl.value.scrollTop = messagesEl.value.scrollHeight
  })
}

function scrollToTop() {
  if (messagesEl.value) messagesEl.value.scrollTop = 0
}

function handleScroll() {
  if (!messagesEl.value) return
  const { scrollTop, scrollHeight, clientHeight } = messagesEl.value
  showScrollButtons.value = scrollHeight > clientHeight + 100
}

function renderContent(text) {
  return renderChatContent(withoutGeneratedFileLines(text), { includeCopyButton: true })
}

async function handleCodeCopy(event) {
  const button = event.target.closest('.copy-code-btn')
  if (!button || !messagesEl.value?.contains(button)) return
  const code = button.closest('.code-block')?.querySelector('pre code')?.textContent || ''
  const originalHtml = button.innerHTML
  try {
    await navigator.clipboard.writeText(code)
    button.textContent = 'Copied'
    button.style.color = '#10b981'
  } catch (error) {
    console.error('Copy failed:', error)
    button.textContent = 'Copy failed'
    button.style.color = '#ef4444'
  }
  setTimeout(() => {
    button.innerHTML = originalHtml
    button.style.color = ''
  }, 2000)
}

watch(() => props.session?.messages?.length, () => scrollToBottom())
</script>

<style scoped>
.chat-window {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: #f8f9fb;
  position: relative;
}

/* Top bar */
.chat-topbar {
  height: 44px;
  background: white;
  border-bottom: 1px solid #eef0f3;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  flex-shrink: 0;
}

.topbar-agent {
  display: flex;
  align-items: center;
  gap: 8px;
}

.topbar-agent-icon {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.topbar-agent-name {
  font-size: 13px;
  font-weight: 600;
  color: #1f2937;
}

.topbar-msg-count {
  font-size: 11px;
  color: #9ca3af;
  background: #f3f4f6;
  padding: 1px 7px;
  border-radius: 10px;
}

.topbar-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.topbar-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 7px;
  cursor: pointer;
  color: #9ca3af;
  transition: all 0.15s;
}

.topbar-btn:not(:disabled):hover {
  background: #fee2e2;
  color: #ef4444;
}

.topbar-btn:disabled {
  opacity: 0.35;
  cursor: not-allowed;
}

/* Messages */
.messages-area {
  flex: 1;
  overflow-y: auto;
  padding: 24px 20px 16px;
  scrollbar-width: thin;
  scrollbar-color: #e5e7eb transparent;
}

.messages-area::-webkit-scrollbar { width: 5px; }
.messages-area::-webkit-scrollbar-thumb { background: #e5e7eb; border-radius: 3px; }

.messages-inner {
  max-width: 860px;
  margin: 0;          /* Left aligned, not centered */
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.empty-chat {
  text-align: center;
  padding: 80px 20px 60px;
}

.empty-icon-wrap {
  width: 60px;
  height: 60px;
  border-radius: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
  background: #f3f4f6;
  color: #9ca3af;
}

.empty-text {
  font-size: 16px;
  color: #374151;
  margin-bottom: 6px;
}

.empty-sub {
  font-size: 13px;
  color: #9ca3af;
  max-width: 320px;
  margin: 0 auto;
  line-height: 1.6;
}

.message-row {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  /* Keep everything left aligned without using flex-direction: row-reverse */
}

.msg-avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 600;
  flex-shrink: 0;
  color: white;
  margin-top: 2px;
}

.assistant-avatar { background: #6b7280; }
.user-avatar { background: #2563eb; }

.msg-bubble {
  flex: none;         /* Do not stretch; keep natural width */
  width: 66%;         /* Fixed to 2/3 width */
  padding: 12px 16px;
  border-radius: 12px;
  background: white;
  border: 1px solid #e5e7eb;
  box-shadow: 0 1px 2px rgba(0,0,0,0.03);
}

.assistant-bubble {
  background: #ffffff;
  border-color: #e5e7eb;
}

.user-bubble {
  background: #f8fafc;
  border-color: #e0e7ff;
}

.msg-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
  padding-bottom: 6px;
  border-bottom: 1px solid #f3f4f6;
}

.msg-role {
  font-size: 12px;
  font-weight: 600;
  color: #6b7280;
}

.user-bubble .msg-role {
  color: #2563eb;
}

.msg-content {
  font-size: 14px;
  line-height: 1.65;
  word-break: break-word;
  color: #1f2937;
}

.msg-footer {
  margin-top: 8px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
}

.msg-time {
  font-size: 10px;
  opacity: 0.5;
  color: #6b7280;
}

.delete-msg-btn {
  opacity: 0;
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 4px;
  cursor: pointer;
  color: #9ca3af;
  transition: all 0.15s;
  flex-shrink: 0;
}

.msg-header:hover .delete-msg-btn {
  opacity: 1;
}

.delete-msg-btn:hover {
  background: rgba(239, 68, 68, 0.1);
  color: #ef4444;
}

.typing-cursor {
  display: inline-block;
  animation: blink 0.7s infinite;
  color: #2563eb;
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
}

/* Scroll buttons */
.scroll-buttons {
  position: absolute;
  right: 20px;
  bottom: 90px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  z-index: 10;
}

.scroll-btn {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #e5e7eb;
  background: white;
  border-radius: 50%;
  cursor: pointer;
  color: #6b7280;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: all 0.2s;
}

.scroll-btn:hover {
  background: #f3f4f6;
  color: #2563eb;
  border-color: #2563eb;
  box-shadow: 0 4px 12px rgba(37,99,235,0.15);
}

.fade-enter-active, .fade-leave-active { transition: opacity 0.2s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

/* Input */
.input-area {
  padding: 14px 20px 18px;
  background: #f8f9fb;
  border-top: 1px solid #eef0f3;
}

.input-wrapper {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  background: white;
  border: 1.5px solid #e8eaed;
  border-radius: 14px;
  padding: 10px 12px;
  max-width: 860px;
  margin: 0;          /* Left aligned, not centered */
  transition: border-color 0.2s, box-shadow 0.2s;
}

.input-wrapper:focus-within {
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37,99,235,0.08);
}

.attach-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  border-radius: 7px;
  cursor: pointer;
  color: #c4c9d4;
  flex-shrink: 0;
  transition: all 0.15s;
}

.attach-btn:hover { color: #6b7280; background: #f3f4f6; }

.attachment-input { display: none; }

.attachment-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  max-width: 860px;
  margin-top: 8px;
}

.attachment-chip {
  display: flex;
  align-items: center;
  gap: 7px;
  max-width: min(100%, 280px);
  min-height: 28px;
  padding: 3px 5px 3px 9px;
  border: 1px solid #dbe3ed;
  border-radius: 6px;
  background: white;
  color: #475569;
  font-size: 11px;
}

.attachment-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.attachment-chip button { display: flex; align-items: center; border: 0; background: none; color: #64748b; cursor: pointer; }
.attachment-error { max-width: 860px; margin: 6px 0 0; color: #b91c1c; font-size: 11px; }

.message-attachments { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 8px; }
.message-attachment { padding: 3px 7px; border-radius: 4px; background: #f1f5f9; color: #475569; font-size: 11px; }

.chat-input {
  flex: 1;
  border: none;
  outline: none;
  resize: none;
  font-size: 14px;
  color: #1f2937;
  background: transparent;
  line-height: 1.55;
  min-height: 24px;
  max-height: 160px;
  font-family: inherit;
}

.chat-input::placeholder { color: #c4c9d4; }

.send-btn {
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: #f3f4f6;
  border-radius: 9px;
  cursor: pointer;
  color: #c4c9d4;
  flex-shrink: 0;
  transition: all 0.2s;
}

.send-btn.active { background: #2563eb; color: white; }
.send-btn.active:hover { background: #1d4ed8; }

.input-hint {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  text-align: left;
  font-size: 11px;
  color: #c4c9d4;
  margin-top: 7px;
  max-width: 860px;
}

.web-search-toggle {
  display: inline-flex;
  flex: 0 0 auto;
  align-items: center;
  gap: 6px;
  color: #475569;
  cursor: pointer;
  user-select: none;
}

.web-search-toggle input {
  width: 14px;
  height: 14px;
  margin: 0;
  accent-color: #2563eb;
}

.web-search-toggle:focus-within {
  outline: 2px solid #2563eb;
  outline-offset: 3px;
  border-radius: 2px;
}

:deep(code.inline-code) {
  background: #f3f4f6;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 13px;
  font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  color: #dc2626;
}

:deep(.chat-file-link),
:deep(.chat-link) {
  color: #1d4ed8;
  text-decoration: underline;
  text-underline-offset: 2px;
  overflow-wrap: anywhere;
}

:deep(.chat-file-link:hover),
:deep(.chat-link:hover) {
  color: #1e40af;
}

:deep(.code-block) {
  background: #1f2937;
  border-radius: 8px;
  margin: 12px 0;
  overflow: hidden;
  position: relative;
}

:deep(.code-lang) {
  position: absolute;
  top: 8px;
  left: 12px;
  font-size: 11px;
  color: #9ca3af;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

:deep(.copy-code-btn) {
  position: absolute;
  top: 8px;
  right: 8px;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 6px;
  cursor: pointer;
  color: #9ca3af;
  transition: all 0.2s;
  opacity: 0;
}

:deep(.code-block):hover .copy-code-btn {
  opacity: 1;
}

:deep(.copy-code-btn):hover {
  background: rgba(255, 255, 255, 0.15);
  color: #e5e7eb;
}

:deep(.copy-code-btn):active {
  transform: scale(0.95);
}

:deep(.code-block pre) {
  margin: 0;
  padding: 16px;
  padding-top: 40px; /* Leave space for the top buttons */
  overflow-x: auto;
  background: transparent;
}

:deep(.code-block code) {
  color: #e5e7eb;
  font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  font-size: 13px;
  line-height: 1.6;
  display: block;
}

:deep(.heading) {
  display: block;
  font-size: 16px;
  font-weight: 700;
  margin: 14px 0 8px;
  color: #111827;
  line-height: 1.4;
}

:deep(.list-item) {
  display: block;
  padding: 4px 0;
  padding-left: 24px;
  position: relative;
  line-height: 1.6;
}

:deep(.list-item.bullet::before) {
  content: '';
  position: absolute;
  left: 8px;
  top: 12px;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: #6b7280;
}

:deep(.list-item.numbered) {
  padding-left: 32px;
}

:deep(.list-item .num) {
  position: absolute;
  left: 0;
  color: #6b7280;
  font-weight: 600;
}
</style>
