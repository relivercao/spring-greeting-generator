<template>
  <section
    class="live-run-card"
    aria-live="polite"
  >
    <div class="run-heading">
      <span>Live execution</span>
      <strong>{{ status === 'queued' ? 'Queued for execution' : 'Batch running' }}</strong>
    </div>
    <div class="progress-label">
      <span>Batch progress</span>
      <strong>{{ batchProgress }}%</strong>
    </div>
    <div
      class="progress-track batch-progress"
      role="progressbar"
      aria-label="Batch progress"
      aria-valuemin="0"
      aria-valuemax="100"
      :aria-valuenow="batchProgress"
    >
      <span :style="{ width: `${batchProgress}%` }" />
    </div>
    <p class="run-counts">
      {{ completedCount }} / {{ totalCount }} files completed
    </p>

    <template v-if="currentItem">
      <h3>{{ currentItem.filename }}</h3>
      <div class="progress-label">
        <span>{{ stageLabel }}</span>
        <strong>{{ fileProgress }}%</strong>
      </div>
      <div
        class="progress-track file-progress"
        role="progressbar"
        aria-label="Current file progress"
        aria-valuemin="0"
        aria-valuemax="100"
        :aria-valuenow="fileProgress"
      >
        <span :style="{ width: `${fileProgress}%` }" />
      </div>
      <p class="runtime-message">
        {{ currentItem.error_message || currentItem.message || 'Waiting for the next progress update.' }}
      </p>
    </template>
    <p
      v-else
      class="runtime-message"
    >
      {{ status === 'queued' ? 'Waiting for an available worker' : 'Preparing the next file' }}
    </p>
  </section>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  status: { type: String, default: 'queued' },
  progress: { type: Number, default: 0 },
  items: { type: Array, default: () => [] },
})

function percentage(value) {
  return Math.min(100, Math.max(0, Number(value) || 0))
}

const currentItem = computed(() => props.items.find(item => item.status === 'running'))
const batchProgress = computed(() => percentage(props.progress))
const fileProgress = computed(() => percentage(currentItem.value?.progress))
const totalCount = computed(() => props.items.length)
const completedCount = computed(() => props.items.filter(item => ['pass', 'fail'].includes(item.status)).length)
const stageLabel = computed(() => {
  const stage = currentItem.value?.current_stage
  return {
    analyze: 'Analyzing source',
    generate: 'Generating tests',
    compile: 'Compiling tests',
    test: 'Running tests',
    coverage: 'Analyzing coverage',
    save: 'Saving generated files',
    report: 'Preparing report',
  }[stage] || (stage ? stage.replaceAll('_', ' ') : 'Starting generation')
})
</script>

<style scoped>
.live-run-card {
  display: flex;
  flex-direction: column;
  gap: 10px;
  border: 1px solid #c7d2fe;
  border-radius: 14px;
  padding: 16px;
  background: #f5f7ff;
}

.run-heading {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.run-heading > span,
.run-counts {
  color: #64748b;
  font-size: 12px;
}

.run-heading strong,
h3 {
  color: #1e293b;
  font-size: 15px;
}

h3,
p {
  margin: 0;
  overflow-wrap: anywhere;
}

.progress-label {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  color: #475569;
  font-size: 12px;
}

.progress-track {
  height: 7px;
  overflow: hidden;
  border-radius: 6px;
  background: #e2e8f0;
}

.progress-track > span {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: #6366f1;
  transition: width 0.25s ease;
}

.runtime-message {
  color: #334155;
  font-size: 12px;
  line-height: 1.6;
  white-space: pre-wrap;
}
</style>
