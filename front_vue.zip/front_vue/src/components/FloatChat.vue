<template>
  <div
    class="float-chat-container"
    :style="containerStyle"
  >
    <transition name="slide-up">
      <div
        v-if="isOpen"
        class="chat-window"
      >
        <div
          class="chat-header drag-handle"
          @pointerdown="startDrag"
        >
          <div class="header-left">
            <el-icon class="header-icon">
              <Service />
            </el-icon>
            <span class="header-title">AI Assistant</span>
          </div>
          <el-icon
            class="close-btn"
            @pointerdown.stop
            @click.stop="toggleChat"
          >
            <Close />
          </el-icon>
        </div>

        <div
          ref="messagesContainer"
          class="chat-messages"
        >
          <div
            v-for="(msg, index) in messages"
            :key="index"
            :class="['message', msg.role]"
          >
            <div
              v-if="msg.role === 'assistant' && withoutGeneratedFileLines(msg.content)"
              class="message-content"
              v-html="renderContent(msg.content)"
            />
            <div
              v-else-if="msg.role !== 'assistant'"
              class="message-content"
            >
              {{ msg.content }}
            </div>
            <ChatGeneratedFiles v-if="msg.role === 'assistant'" :files="msg.artifacts || []" :content="msg.content" />
            <p v-for="(operation, operationIndex) in msg.appOperations || []" :key="operationIndex" class="app-operation" role="status">
              {{ operation.app }} · {{ operation.tool }} · {{ operation.success ? 'Completed' : 'Not completed' }}
            </p>
          </div>
          <div
            v-if="isRequestPending || isTyping"
            class="message assistant"
          >
            <div class="message-content typing">
              <span class="dot" />
              <span class="dot" />
              <span class="dot" />
            </div>
          </div>
        </div>

        <div class="chat-input-area">
          <el-input
            v-model="inputMessage"
            type="textarea"
            :rows="2"
            placeholder="Type your message..."
            aria-label="Assistant message"
            resize="none"
            @keydown.enter.exact.prevent="sendMessage"
            @keydown.enter.shift.exact="() => {}"
            @compositionstart="isComposing = true"
            @compositionend="isComposing = false"
          />
          <el-button
            type="primary"
            :icon="Position"
            circle
            :disabled="isRequestPending || isTyping || !inputMessage.trim()"
            class="send-btn"
            aria-label="Send message"
            @click="sendMessage"
          />
        </div>
      </div>
    </transition>

    <div
      class="float-button drag-handle"
      @pointerdown="startDrag"
      @click="handleButtonClick"
    >
      <el-badge
        :value="unreadCount"
        :hidden="unreadCount === 0"
        :max="9"
      >
        <el-icon :size="28">
          <Service />
        </el-icon>
      </el-badge>
    </div>

    <!-- AWS SSO Login Modal -->
    <AWSSSOLoginModal
      :visible="showAWSSSOModal"
      @close="showAWSSSOModal = false"
      @success="handleAWSLoginSuccess"
    />
  </div>
</template>

<script setup>
import { ref, nextTick, watch, computed, onMounted, onBeforeUnmount } from 'vue'
import { Service, Close, Position } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { apiSendMessage } from '../api/auth.js'
import { EMPTY_CHAT_RESPONSE_MESSAGE, getChatErrorMessage } from '../api/errorMessages.js'
import { renderChatContent } from '../utils/chatContent.js'
import { generatedFiles, withoutGeneratedFileLines } from '../utils/generatedFiles.js'
import ChatGeneratedFiles from './ChatGeneratedFiles.vue'
import AWSSSOLoginModal from './AWSSSOLoginModal.vue'
import { useAuthStore } from '../stores/auth.js'
import { ASSISTANT_COMPOSE_EVENT } from '../utils/assistantEvents.js'
import { createUuid } from '../utils/uuid.js'

const AWS_PROFILE_MISSING_MESSAGE = 'AWS Profile is not configured. Please configure a valid AWS_PROFILE in Provider Settings and try again.'
const AWS_PROFILE_INVALID_MESSAGE = 'AWS Profile does not exist. Please enter a valid AWS_PROFILE in Provider Settings and try again.'

const BUTTON_SIZE = 56
const PANEL_WIDTH = 380
const PANEL_HEIGHT = 520
const PANEL_GAP = 16
const VIEWPORT_PADDING = 8
const DEFAULT_RIGHT_OFFSET = 24
const DEFAULT_BOTTOM_OFFSET = 96

const isOpen = ref(false)
const inputMessage = ref('')
const unreadCount = ref(0)
const isTyping = ref(false)
const isRequestPending = ref(false)
const isComposing = ref(false)
const messagesContainer = ref(null)
const authStore = useAuthStore()
const accountKey = computed(() => authStore.isLoggedIn
  ? String(authStore.user?.id || authStore.user?.email || authStore.user?.name || 'signed-in')
  : 'guest')
let conversationVersion = 0
let typingTimer = null
let finishTyping = null

const position = ref({ x: 0, y: 0 })
const dragState = ref({
  active: false,
  startX: 0,
  startY: 0,
  originX: 0,
  originY: 0,
  moved: false,
})

// AWS SSO Login Modal
const showAWSSSOModal = ref(false)

// Listen for AWS auth required event
const handleAWSAuthRequired = (event) => {
  console.log('[FloatChat.vue] AWS auth required event received:', event.detail)
  showAWSSSOModal.value = true
}

const handleAWSLoginSuccess = () => {
  ElMessage.success('AWS login successful! You can now use Bedrock models.')
  showAWSSSOModal.value = false
}

const sessionId = ref('float_chat_session_' + createUuid())

function initialMessages() {
  return [{ role: 'assistant', content: 'Hello! I\'m your AI assistant. How can I help you today?' }]
}

const messages = ref(initialMessages())

function cancelTyping() {
  clearInterval(typingTimer)
  typingTimer = null
  finishTyping?.()
  finishTyping = null
  isTyping.value = false
}

watch(accountKey, () => {
  conversationVersion += 1
  cancelTyping()
  messages.value = initialMessages()
  inputMessage.value = ''
  unreadCount.value = 0
  isRequestPending.value = false
  sessionId.value = 'float_chat_session_' + createUuid()
}, { flush: 'sync' })

function composeAppRequest(event) {
  if (event.detail?.app !== 'gmail' || !authStore.isLoggedIn) return
  if (!isOpen.value) toggleChat()
  if (isRequestPending.value || isTyping.value || inputMessage.value.trim()) {
    ElMessage.info('Finish the current message before starting a Gmail request.')
    return
  }
  inputMessage.value = String(event.detail.message || '').slice(0, 2000)
}

const containerStyle = computed(() => ({
  left: `${position.value.x}px`,
  top: `${position.value.y}px`,
}))

function renderContent(content) {
  return renderChatContent(withoutGeneratedFileLines(content))
}

function clampButtonPosition(nextX, nextY) {
  const panelWidth = Math.min(PANEL_WIDTH, window.innerWidth - 2 * VIEWPORT_PADDING)
  const panelHeight = Math.min(PANEL_HEIGHT, window.innerHeight - BUTTON_SIZE - PANEL_GAP - 2 * VIEWPORT_PADDING)
  const minX = isOpen.value ? panelWidth - BUTTON_SIZE + VIEWPORT_PADDING : VIEWPORT_PADDING
  const maxX = window.innerWidth - BUTTON_SIZE - VIEWPORT_PADDING
  const minY = isOpen.value ? panelHeight + PANEL_GAP + VIEWPORT_PADDING : VIEWPORT_PADDING
  const maxY = window.innerHeight - BUTTON_SIZE - VIEWPORT_PADDING

  return {
    x: Math.min(Math.max(minX, nextX), Math.max(minX, maxX)),
    y: Math.min(Math.max(minY, nextY), Math.max(minY, maxY)),
  }
}

function placeDefaultPosition() {
  position.value = clampButtonPosition(
    window.innerWidth - BUTTON_SIZE - DEFAULT_RIGHT_OFFSET,
    window.innerHeight - BUTTON_SIZE - DEFAULT_BOTTOM_OFFSET,
  )
}

function toggleChat() {
  isOpen.value = !isOpen.value
  if (isOpen.value) {
    unreadCount.value = 0
    nextTick(() => {
      position.value = clampButtonPosition(position.value.x, position.value.y)
      scrollToBottom()
    })
  }
}

function handleButtonClick() {
  if (dragState.value.moved) {
    dragState.value.moved = false
    return
  }
  toggleChat()
}

function startDrag(event) {
  if (event.button !== undefined && event.button !== 0) return
  dragState.value = {
    active: true,
    startX: event.clientX,
    startY: event.clientY,
    originX: position.value.x,
    originY: position.value.y,
    moved: false,
  }
  event.currentTarget?.setPointerCapture?.(event.pointerId)
}

function handlePointerMove(event) {
  if (!dragState.value.active) return
  const deltaX = event.clientX - dragState.value.startX
  const deltaY = event.clientY - dragState.value.startY
  if (!dragState.value.moved && Math.hypot(deltaX, deltaY) > 4) {
    dragState.value.moved = true
  }
  position.value = clampButtonPosition(
    dragState.value.originX + deltaX,
    dragState.value.originY + deltaY,
  )
}

function stopDrag() {
  if (!dragState.value.active) return
  dragState.value = {
    active: false,
    startX: 0,
    startY: 0,
    originX: position.value.x,
    originY: position.value.y,
    moved: dragState.value.moved,
  }
}

async function typewriterEffect(text, operations, artifacts, version, speed = 30) {
  isTyping.value = true

  const aiMsgIndex = messages.value.length
  messages.value.push({
    role: 'assistant',
    content: artifacts.length ? text : '',
    appOperations: operations,
    artifacts,
  })
  if (artifacts.length) {
    isTyping.value = false
    await nextTick()
    scrollToBottom()
    return
  }

  const totalLength = text.length
  let index = 0

  return new Promise((resolve) => {
    finishTyping = resolve
    typingTimer = setInterval(() => {
      if (version !== conversationVersion) {
        cancelTyping()
        return
      }
      index = Math.min(index + 2, totalLength)
      messages.value[aiMsgIndex].content = text.slice(0, index)
      scrollToBottom()

      if (index >= totalLength) {
        cancelTyping()
      }
    }, speed)
  })
}

async function sendMessage() {
  if (isComposing.value || isRequestPending.value || isTyping.value) return
  const content = inputMessage.value.trim()
  if (!content) return

  messages.value.push({ role: 'user', content })
  inputMessage.value = ''

  await nextTick()
  scrollToBottom()
  isRequestPending.value = true
  const version = conversationVersion

  try {
    const res = await apiSendMessage('chat', content, sessionId.value)
    if (version !== conversationVersion) return
    isRequestPending.value = false
    const responseText = res?.response || EMPTY_CHAT_RESPONSE_MESSAGE
    const operations = res?.metadata?.data?.app_operations
    const artifacts = generatedFiles(res?.metadata?.data?.artifacts, responseText)
    await typewriterEffect(responseText, Array.isArray(operations) ? operations : [], artifacts, version)

    if (version !== conversationVersion) return
    if (!isOpen.value) unreadCount.value++
  } catch (error) {
    if (version !== conversationVersion) return
    isRequestPending.value = false
    console.error('Failed to send message:', error)

    // Check if this is an AWS authentication error
    if (error.message && error.message.includes('AWS_AUTH_REQUIRED')) {
      console.log('[FloatChat] AWS authentication error detected, showing login modal')
      // Show AWS SSO login modal
      showAWSSSOModal.value = true
      // Show a friendly message to the user
      messages.value.push({
        role: 'assistant',
        content: 'AWS credentials expired. Please complete the login and send your message again.'
      })
      isTyping.value = false
      return
    }

    if (error.message && (
      error.message.includes('AWS_PROFILE not configured')
      || error.message.includes('AWS Profile is not configured')
    )) {
      ElMessage.error(AWS_PROFILE_MISSING_MESSAGE)
      messages.value.push({
        role: 'assistant',
        content: AWS_PROFILE_MISSING_MESSAGE
      })
      isTyping.value = false
      return
    }

    if (error.message && error.message.includes('AWS_PROFILE_INVALID')) {
      const profileMatch = error.message.match(/Profile '([^']+)'/)
      const message = profileMatch
        ? `AWS Profile '${profileMatch[1]}' does not exist. Please enter a valid AWS_PROFILE in Provider Settings and try again.`
        : AWS_PROFILE_INVALID_MESSAGE
      ElMessage.error(message)
      messages.value.push({
        role: 'assistant',
        content: message
      })
      isTyping.value = false
      return
    }

    const chatErrorMessage = getChatErrorMessage(error)
    ElMessage.error(chatErrorMessage)
    messages.value.push({
      role: 'assistant',
      content: chatErrorMessage
    })
    isTyping.value = false
  }
}

function scrollToBottom() {
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}

function handleResize() {
  position.value = clampButtonPosition(position.value.x, position.value.y)
}

watch(messages, () => {
  nextTick(scrollToBottom)
}, { deep: true })

watch(isOpen, async () => {
  await nextTick()
  handleResize()
})

onMounted(() => {
  placeDefaultPosition()
  window.addEventListener('pointermove', handlePointerMove)
  window.addEventListener('pointerup', stopDrag)
  window.addEventListener('pointercancel', stopDrag)
  window.addEventListener('resize', handleResize)
  window.addEventListener('aws:auth-required', handleAWSAuthRequired)
  window.addEventListener(ASSISTANT_COMPOSE_EVENT, composeAppRequest)
})

onBeforeUnmount(() => {
  conversationVersion += 1
  cancelTyping()
  window.removeEventListener('pointermove', handlePointerMove)
  window.removeEventListener('pointerup', stopDrag)
  window.removeEventListener('pointercancel', stopDrag)
  window.removeEventListener('resize', handleResize)
  window.removeEventListener('aws:auth-required', handleAWSAuthRequired)
  window.removeEventListener(ASSISTANT_COMPOSE_EVENT, composeAppRequest)
})
</script>

<style scoped>
.app-operation {
  margin: 6px 0;
  font-size: 11px;
  color: #64748b;
  overflow-wrap: anywhere;
}
.float-chat-container {
  position: fixed;
  width: 56px;
  height: 56px;
  z-index: 9999;
}

.float-button {
  position: absolute;
  right: 0;
  bottom: 0;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  transition: all 0.3s ease;
  color: white;
}

.float-button:hover {
  transform: scale(1.1);
  box-shadow: 0 6px 16px rgba(102, 126, 234, 0.6);
}

.chat-window {
  position: absolute;
  right: 0;
  bottom: calc(100% + 16px);
  width: min(380px, calc(100vw - 16px));
  height: min(520px, calc(100dvh - 88px));
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.drag-handle {
  touch-action: none;
}

.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  cursor: move;
  user-select: none;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.header-icon {
  font-size: 20px;
}

.header-title {
  font-size: 16px;
  font-weight: 600;
}

.close-btn {
  font-size: 18px;
  cursor: pointer;
  opacity: 0.8;
  transition: opacity 0.2s;
  pointer-events: auto;
}

.close-btn:hover {
  opacity: 1;
}

.chat-messages {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
  background: #f8f9fa;
}

.message {
  margin-bottom: 12px;
  display: flex;
}

.message.user {
  justify-content: flex-end;
}

.message.assistant {
  justify-content: flex-start;
  flex-direction: column;
  align-items: flex-start;
}

.message-content {
  min-width: 0;
  max-width: 80%;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.5;
  word-wrap: break-word;
}

.message-content :deep(.code-block) {
  max-width: 100%;
  overflow: hidden;
}

.message-content :deep(pre) {
  margin: 8px 0 0;
  overflow-x: auto;
}

.message.user .message-content {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-bottom-right-radius: 4px;
}

.message.assistant .message-content {
  background: white;
  color: #333;
  border-bottom-left-radius: 4px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

.message-content :deep(.chat-file-link),
.message-content :deep(.chat-link) {
  color: #1d4ed8;
  text-decoration: underline;
  text-underline-offset: 2px;
  overflow-wrap: anywhere;
}

.message-content :deep(.chat-file-link:hover),
.message-content :deep(.chat-link:hover) {
  color: #1e40af;
}

.message-content.typing {
  display: flex;
  gap: 4px;
  padding: 14px 18px;
}

.typing .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #667eea;
  animation: typing 1.4s infinite ease-in-out both;
}

.typing .dot:nth-child(1) {
  animation-delay: -0.32s;
}

.typing .dot:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes typing {
  0%, 80%, 100% {
    transform: scale(0.6);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

.chat-input-area {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  padding: 12px 16px;
  background: white;
  border-top: 1px solid #e8e8e8;
}

.chat-input-area .el-textarea {
  flex: 1;
}

.send-btn {
  flex-shrink: 0;
}

.slide-up-enter-active,
.slide-up-leave-active {
  transition: all 0.3s ease;
}

.slide-up-enter-from,
.slide-up-leave-to {
  opacity: 0;
  transform: translateY(20px);
}

.chat-messages::-webkit-scrollbar {
  width: 6px;
}

.chat-messages::-webkit-scrollbar-track {
  background: transparent;
}

.chat-messages::-webkit-scrollbar-thumb {
  background: #ccc;
  border-radius: 3px;
}

.chat-messages::-webkit-scrollbar-thumb:hover {
  background: #999;
}
</style>
