<template>
  <!-- Floating customer support button -->
  <div
    class="customer-service-float"
    @click="showDialog = true"
  >
    <el-icon :size="28">
      <Service />
    </el-icon>
  </div>

  <!-- Customer support dialog -->
  <el-dialog
    v-model="showDialog"
    title="Customer Support"
    width="500px"
    :append-to-body="true"
    custom-class="customer-service-dialog"
  >
    <div class="chat-container">
      <!-- Message list -->
      <div
        ref="messageListRef"
        class="message-list"
      >
        <div
          v-for="(msg, index) in messages"
          :key="index"
          :class="['message-item', msg.type]"
        >
          <div class="message-content">
            <div class="message-text">
              {{ msg.content }}
            </div>
            <div class="message-time">
              {{ msg.time }}
            </div>
          </div>
        </div>
      </div>

      <!-- Input area -->
      <div class="input-area">
        <el-input
          v-model="inputMessage"
          placeholder="Please enter your question..."
          :rows="3"
          type="textarea"
          @keyup.enter="sendMessage"
        />
        <el-button
          type="primary"
          :disabled="!inputMessage.trim()"
          @click="sendMessage"
        >
          Send
        </el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script setup>
import { ref, nextTick } from 'vue'
import { Service } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'

const showDialog = ref(false)
const inputMessage = ref('')
const messageListRef = ref(null)

const messages = ref([
  {
    type: 'system',
    content: 'Hello, I am your AI assistant. How can I help you today?',
    time: new Date().toLocaleTimeString()
  }
])

// Send message
async function sendMessage() {
  const text = inputMessage.value.trim()
  if (!text) return

  // Add user message
  messages.value.push({
    type: 'user',
    content: text,
    time: new Date().toLocaleTimeString()
  })

  inputMessage.value = ''

  // Scroll to bottom
  await nextTick()
  scrollToBottom()

  // Simulate support reply (can be replaced with a real chat API)
  setTimeout(() => {
    messages.value.push({
      type: 'system',
      content: getAutoReply(text),
      time: new Date().toLocaleTimeString()
    })
    scrollToBottom()
  }, 1000)
}

// Auto-reply logic (can be replaced with a real API)
function getAutoReply(userMessage) {
  const msg = userMessage.toLowerCase()

  if (msg.includes('upload') || msg.includes('file')) {
    return 'You can upload .c/.h/.cpp/.hpp files on the unit test page, and the system will automatically generate unit test code.'
  } else if (msg.includes('test') || msg.includes('unittest')) {
    return 'The unit test feature supports Google Test and Unity. It can automatically generate test code, mock files, and run compilation checks.'
  } else if (msg.includes('error') || msg.includes('failed')) {
    return 'If you encounter errors, please check:\n1. Whether the file format is correct (.c/.h/.cpp/.hpp)\n2. Whether the backend service is running normally\n3. The error details in the browser console'
  } else {
    return 'Thank you for contacting us. You can select different AI Agents from the left sidebar, such as Unit Test, Driver Development, Code Review, etc. If you have other questions, please describe them in detail.'
  }
}

// Scroll to bottom
function scrollToBottom() {
  if (messageListRef.value) {
    messageListRef.value.scrollTop = messageListRef.value.scrollHeight
  }
}
</script>

<style scoped>
/* Floating button */
.customer-service-float {
  position: fixed;
  right: 30px;
  bottom: 30px;
  width: 60px;
  height: 60px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  transition: all 0.3s ease;
  z-index: 1000;
  color: white;
}

.customer-service-float:hover {
  transform: scale(1.1);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
}

.customer-service-float:active {
  transform: scale(0.95);
}

/* Dialog styles */
.chat-container {
  display: flex;
  flex-direction: column;
  height: 500px;
}

.message-list {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background: #f5f7fa;
  border-radius: 8px;
  margin-bottom: 16px;
}

.message-item {
  margin-bottom: 16px;
  display: flex;
}

.message-item.user {
  justify-content: flex-end;
}

.message-item.system {
  justify-content: flex-start;
}

.message-content {
  max-width: 70%;
  padding: 12px 16px;
  border-radius: 12px;
  position: relative;
}

.message-item.user .message-content {
  background: #667eea;
  color: white;
}

.message-item.system .message-content {
  background: white;
  color: #333;
  border: 1px solid #e4e7ed;
}

.message-text {
  line-height: 1.5;
  white-space: pre-wrap;
  word-wrap: break-word;
}

.message-time {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
  text-align: right;
}

.message-item.user .message-time {
  color: rgba(255, 255, 255, 0.7);
}

.input-area {
  display: flex;
  gap: 12px;
  align-items: flex-end;
}

.input-area .el-textarea {
  flex: 1;
}

.input-area .el-button {
  height: 40px;
}

/* Custom dialog styles */
:deep(.customer-service-dialog) {
  border-radius: 12px;
}

:deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-radius: 12px 12px 0 0;
  padding: 16px 20px;
  margin: 0;
}

:deep(.el-dialog__title) {
  color: white;
  font-weight: 600;
}

:deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white;
}
</style>