<template>
  <div class="cad-workspace">
    <header class="cad-toolbar">
      <div class="cad-title">
        <span class="cad-mark"><el-icon><SetUp /></el-icon></span>
        <div>
          <strong>CAD Agent</strong>
          <span>Parametric model generation</span>
        </div>
      </div>
      <div class="cad-runtime-status">
        <span :class="['status-indicator', status?.skill_available ? 'ready' : 'missing']">
          {{ status?.skill_available ? `MaCAD ${status.skill_version}` : 'MaCAD skill unavailable' }}
        </span>
        <span :class="['status-indicator', status?.runtime_available ? 'ready' : 'missing']">
          {{ status?.build_available ? 'CAD runtime ready' : 'CAD runtime unavailable' }}
        </span>
        <span :class="['status-indicator', status?.llm_available ? 'ready' : 'missing']">
          {{ status?.llm_available ? `LLM ready · ${status.llm_model}` : 'CAD LLM unavailable' }}
        </span>
        <el-tooltip
          content="Refresh local CAD runtime status"
          placement="bottom"
        >
          <button
            class="icon-button"
            type="button"
            aria-label="Refresh status"
            @click="refreshStatus"
          >
            <el-icon><Refresh /></el-icon>
          </button>
        </el-tooltip>
      </div>
    </header>

    <main class="cad-layout">
      <section class="cad-compose-panel">
        <div class="section-heading">
          <div>
            <h2>New model</h2>
            <span>Describe shape, dimensions, features, and units</span>
          </div>
          <el-select
            v-model="outputFormat"
            aria-label="CAD output format"
            class="format-select"
          >
            <el-option
              label="STEP"
              value="step"
            />
            <el-option
              label="STEP + STL"
              value="stl"
            />
            <el-option
              label="STEP + 3MF"
              value="3mf"
            />
            <el-option
              label="STEP + GLB"
              value="glb"
            />
          </el-select>
        </div>
        <textarea
          v-model="prompt"
          class="cad-prompt"
          maxlength="12000"
          placeholder="Example: Create a 40 x 24 x 6 mm mounting plate with four 4 mm corner holes, 3 mm from each edge."
          @keydown.ctrl.enter.prevent="generate"
          @keydown.meta.enter.prevent="generate"
        />
        <div class="cad-form-footer">
          <span>{{ prompt.length }} / 12000</span>
          <el-button
            type="primary"
            :loading="generating"
            :disabled="!prompt.trim() || !status?.skill_available || !status?.build_available || status?.llm_available === false"
            @click="generate"
          >
            <el-icon><MagicStick /></el-icon>
            Generate final review
          </el-button>
        </div>
      </section>

      <section class="cad-tasks-panel">
        <div class="section-heading task-heading">
          <div>
            <h2>Recent models</h2>
            <span>{{ tasks.length }} task{{ tasks.length === 1 ? '' : 's' }}</span>
          </div>
          <el-tooltip
            content="Refresh tasks"
            placement="bottom"
          >
            <button
              class="icon-button"
              type="button"
              aria-label="Refresh tasks"
              @click="loadTasks"
            >
              <el-icon><Refresh /></el-icon>
            </button>
          </el-tooltip>
        </div>
        <div
          v-if="loading && !tasks.length"
          class="empty-state"
        >
          Loading CAD tasks
        </div>
        <div
          v-else-if="!tasks.length"
          class="empty-state"
        >
          Generated models will appear here
        </div>
        <button
          v-for="task in tasks"
          :key="task.task_id"
          class="cad-task-row"
          :class="{ selected: selectedTask?.task_id === task.task_id }"
          type="button"
          @click="selectTask(task)"
        >
          <span class="task-row-main">
            <strong>{{ task.input?.prompt || 'CAD model' }}</strong>
            <small>{{ task.input?.output_format?.toUpperCase() || 'STEP' }} · {{ formatDate(task.created_at) }}</small>
          </span>
          <span :class="['task-status', `status-${task.status}`]">{{ statusLabel(task.status) }}</span>
        </button>
      </section>

      <section
        v-if="selectedTask"
        class="cad-result-panel"
      >
        <div class="section-heading result-heading">
          <div>
            <h2>CAD workflow</h2>
            <span>{{ selectedTask.message }}</span>
          </div>
          <el-button
            v-if="selectedTask.status === 'running'"
            text
            type="danger"
            @click="cancelSelectedTask"
          >
            <el-icon><Close /></el-icon>
            Cancel
          </el-button>
          <el-button
            v-else-if="canRepair"
            type="primary"
            :loading="repairing"
            :disabled="!status?.build_available"
            @click="repairSelectedScript"
          >
            <el-icon><MagicStick /></el-icon>
            Repair and regenerate review
          </el-button>
          <el-button
            v-else-if="selectedTask.status === 'script_ready'"
            type="primary"
            :loading="repairing"
            :disabled="!status?.build_available"
            @click="continueReview"
          >
            Continue to final review
          </el-button>
        </div>

        <div
          v-if="selectedTask.error"
          class="cad-error"
        >
          {{ selectedTask.error }}
        </div>
        <section
          v-if="pipelineSteps.length"
          class="cad-workflow"
          aria-label="CAD generation workflow"
        >
          <div class="cad-workflow-heading">
            <strong>{{ workflowHeaderTitle }}</strong>
            <span>{{ workflowState?.current_stage || 'waiting' }}</span>
          </div>
          <div class="pipeline">
            <template
              v-for="(step, index) in pipelineSteps"
              :key="step.key"
            >
              <div
                class="pipe-node"
                :class="step.state"
                :aria-label="`${step.label}: ${step.state}`"
              >
                <span class="pipe-icon">
                  <el-icon v-if="step.state === 'done'"><CircleCheck /></el-icon>
                  <el-icon v-else-if="step.state === 'fail' || step.state === 'cancelled'"><CircleClose /></el-icon>
                  <span v-else-if="step.state === 'active'" class="pipe-spinner" />
                  <span v-else class="pipe-dot">{{ index + 1 }}</span>
                </span>
                <span class="pipe-label">{{ step.label }}</span>
              </div>
              <span
                v-if="index < pipelineSteps.length - 1"
                class="pipe-arrow"
                :class="{ lit: step.state === 'done' }"
                aria-hidden="true"
              >
                <span>›</span>
              </span>
            </template>
          </div>
        </section>
        <div v-else class="legacy-workflow-note">
          Workflow node history is unavailable for this earlier task.
        </div>
        <section class="cad-preview" aria-label="Final CAD review image">
          <div class="preview-heading">
            <strong>Final review image</strong>
            <el-button
              v-if="previewUrl"
              size="small"
              @click="downloadArtifact('preview', 'preview.png')"
            >
              <el-icon><Download /></el-icon>
              Download image
            </el-button>
          </div>
          <img
            v-if="previewUrl"
            :src="previewUrl"
            alt="Generated CAD review image"
          >
          <div v-else class="review-placeholder" role="status">
            {{ reviewPlaceholder }}
          </div>
        </section>

        <div
          v-if="downloadableArtifacts.length"
          class="artifact-list"
        >
          <strong>Files</strong>
          <div
            v-for="artifact in downloadableArtifacts"
            :key="artifact.type"
            class="artifact-row"
          >
            <span>{{ artifact.filename }}</span>
            <el-button
              size="small"
              @click="downloadArtifact(artifact.type, artifact.filename)"
            >
              <el-icon><Download /></el-icon>
              Download
            </el-button>
          </div>
        </div>

        <details
          v-if="designPlan"
          class="cad-plan"
          aria-label="CAD geometry plan"
        >
          <summary>Geometry plan and coverage</summary>
          <div class="plan-heading">
            <strong>LLM geometry plan</strong>
            <span
              v-if="coverageReview"
              :class="coverageReview.status === 'pass' ? 'review-pass' : 'review-revise'"
            >
              {{ coverageReview.status === 'pass' ? 'Coverage passed' : 'Revision requested' }}
            </span>
          </div>
          <p>{{ designPlan.geometry_summary }}</p>
          <div class="plan-grid">
            <div><strong>Units</strong><span>{{ designPlan.units }}</span></div>
            <div><strong>Parameters</strong><span>{{ (designPlan.parameters || []).join('; ') || 'None listed' }}</span></div>
            <div><strong>Features</strong><span>{{ (designPlan.features || []).join('; ') || 'None listed' }}</span></div>
            <div><strong>Construction</strong><span>{{ (designPlan.construction_steps || []).join('; ') || 'None listed' }}</span></div>
            <div v-if="designPlan.assumptions?.length"><strong>Assumptions</strong><span>{{ designPlan.assumptions.join('; ') }}</span></div>
            <div v-if="coverageReview?.missing_requirements?.length"><strong>Review findings</strong><span>{{ coverageReview.missing_requirements.join('; ') }}</span></div>
          </div>
        </details>
        <details
          v-if="scriptCode"
          class="script-review"
        >
          <summary>Model source · model.py</summary>
          <pre><code>{{ scriptCode }}</code></pre>
        </details>
      </section>
    </main>
  </div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import { ElMessage } from 'element-plus'
import { CircleCheck, CircleClose, Close, Download, MagicStick, Refresh, SetUp } from '@element-plus/icons-vue'
import {
  cancelCadTask,
  createCadTask,
  fetchCadArtifact,
  getCadStatus,
  getCadTask,
  getCadTasks,
  repairCadModelScript,
  startCadBuild,
} from '../api/cad.js'

const prompt = ref('')
const outputFormat = ref('step')
const status = ref(null)
const tasks = ref([])
const selectedTaskId = ref('')
const scriptCode = ref('')
const previewUrl = ref('')
const loading = ref(false)
const generating = ref(false)
const repairing = ref(false)
let pollTimer = null
let artifactRequestId = 0
let loadedArtifactKey = ''
let polling = false
let disposed = false
const authStore = useAuthStore()

function invalidateWorkspace() {
  disposed = true
  if (pollTimer) window.clearInterval(pollTimer)
  pollTimer = null
  clearTaskArtifacts()
  tasks.value = []
  selectedTaskId.value = ''
  prompt.value = ''
}

watch(() => accountIdentity(authStore), invalidateWorkspace, { flush: 'sync' })

const selectedTask = computed(() => tasks.value.find((task) => task.task_id === selectedTaskId.value) || null)
const CAD_PIPELINE_NODES = [
  { key: 'init_project_context', label: 'Initialize' },
  { key: 'plan_geometry', label: 'Plan Geometry' },
  { key: 'generate_script', label: 'Generate' },
  { key: 'review_geometry', label: 'Review Geometry' },
  { key: 'validate_script', label: 'Validate' },
  { key: 'repair_script', label: 'Revise' },
  { key: 'save_files', label: 'Save Script' },
  { key: 'build_and_snapshot', label: 'Build and Review' },
  { key: 'finalize', label: 'Finalize' },
]
const workflowState = computed(() => selectedTask.value?.result?.workflow_state || null)
const workflowNodes = computed(() => (
  Array.isArray(workflowState.value?.nodes)
    ? workflowState.value.nodes
    : (Array.isArray(selectedTask.value?.result?.workflow_nodes) ? selectedTask.value.result.workflow_nodes : [])
))
const designPlan = computed(() => {
  const plan = selectedTask.value?.result?.design_plan || workflowState.value?.details?.design_plan
  return plan?.geometry_summary ? plan : null
})
const coverageReview = computed(() => {
  const review = selectedTask.value?.result?.coverage_review || workflowState.value?.details?.coverage_review
  return review?.status ? review : null
})
const canRepair = computed(() => selectedTask.value?.status === 'failed'
  && (
    ['build_failed', 'repair_failed'].includes(selectedTask.value?.result?.phase)
    || (
      selectedTask.value?.result?.phase === 'generation_failed'
      && selectedTask.value?.result?.coverage_review?.status === 'revise'
      && Boolean(selectedTask.value?.result?.model_file)
    )
  ))
const reviewPlaceholder = computed(() => {
  if (selectedTask.value?.status === 'running') return 'The workflow is generating your model and final review image.'
  if (selectedTask.value?.status === 'failed') return 'The workflow stopped. See the error above before trying again.'
  if (selectedTask.value?.status === 'cancelled') return 'This workflow was cancelled.'
  if (selectedTask.value?.status === 'script_ready') return 'Continue this saved task to generate its final review image.'
  return 'No review image is available for this task.'
})
const pipelineSteps = computed(() => {
  if (!workflowNodes.value.length) return []
  const nodeMap = Object.fromEntries(workflowNodes.value.map((node) => [
    node.node_name || node.id,
    node.status,
  ]))
  return CAD_PIPELINE_NODES.map((node) => {
    const status = nodeMap[node.key] || 'pending'
    const state = ({
      completed: 'done',
      in_progress: 'active',
      failed: 'fail',
      cancelled: 'cancelled',
      skipped: 'skipped',
    })[status] || 'pending'
    return { ...node, state }
  })
})
const workflowHeaderTitle = computed(() => {
  if (selectedTask.value?.status === 'failed') return 'Workflow failed'
  if (selectedTask.value?.status === 'cancelled') return 'Workflow cancelled'
  if (selectedTask.value?.status === 'script_ready') return 'Source ready · review pending'
  if (selectedTask.value?.status === 'completed') return 'Workflow completed'
  return 'Processing workflow'
})
const downloadableArtifacts = computed(() => {
  const artifacts = selectedTask.value?.result?.artifacts || []
  const unique = new Map(artifacts.filter((artifact) => artifact.type !== 'preview').map((artifact) => [artifact.type, artifact]))
  if (selectedTask.value?.result?.model_file && !unique.has('model_source')) {
    unique.set('model_source', { type: 'model_source', filename: 'model.py' })
  }
  return [...unique.values()]
})

onMounted(async () => {
  await Promise.allSettled([refreshStatus(), loadTasks()])
  if (disposed) return
  pollTimer = window.setInterval(refreshRunningTasks, 2000)
})

onBeforeUnmount(invalidateWorkspace)

async function refreshStatus() {
  if (disposed) return
  try {
    const response = await getCadStatus()
    if (disposed) return
    status.value = response
  } catch (error) {
    if (disposed) return
    status.value = { skill_available: false, runtime_available: false, llm_available: false }
    ElMessage.error(error.message || 'Failed to load local CAD status')
  }
}

async function loadTasks() {
  if (disposed) return
  loading.value = true
  try {
    const response = await getCadTasks()
    if (disposed) return
    tasks.value = response.tasks || []
    if (!selectedTaskId.value && tasks.value.length) await selectTask(tasks.value[0])
    else if (selectedTaskId.value) {
      const current = tasks.value.find((task) => task.task_id === selectedTaskId.value)
      if (current) await loadTaskArtifacts(current)
    }
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to load CAD task history')
  } finally {
    loading.value = false
  }
}

async function refreshRunningTasks() {
  if (disposed || polling) return
  const running = tasks.value.filter((task) => task.status === 'running')
  if (!running.length) return
  polling = true
  try {
    await Promise.allSettled(running.map(async (task) => {
      const latest = await getCadTask(task.task_id)
      if (disposed) return
      replaceTask(latest)
      if (latest.task_id === selectedTaskId.value) await loadTaskArtifacts(latest)
    }))
  } finally {
    polling = false
  }
}

function replaceTask(task) {
  const index = tasks.value.findIndex((item) => item.task_id === task.task_id)
  if (index < 0) tasks.value.unshift(task)
  else tasks.value[index] = task
}

async function selectTask(task) {
  if (disposed) return
  selectedTaskId.value = task.task_id
  clearTaskArtifacts()
  await loadTaskArtifacts(task)
}

function clearTaskArtifacts() {
  artifactRequestId += 1
  loadedArtifactKey = ''
  scriptCode.value = ''
  if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
  previewUrl.value = ''
}

async function loadTaskArtifacts(task) {
  if (disposed || task.task_id !== selectedTaskId.value || !task?.result?.model_file) return
  const key = `${task.task_id}:${task.updated_at || task.status}:${task.result.phase || ''}`
  if (loadedArtifactKey === key) return
  const requestId = ++artifactRequestId
  try {
    const source = await fetchCadArtifact(task.task_id, 'model_source')
    const text = await source.text()
    if (requestId !== artifactRequestId || task.task_id !== selectedTaskId.value) return
    scriptCode.value = text
  } catch (error) {
    if (disposed || requestId !== artifactRequestId) return
    if (task.status !== 'running') ElMessage.error(error.message || 'Failed to load CAD source')
  }
  if (requestId !== artifactRequestId || task.task_id !== selectedTaskId.value) return
  const preview = task.result?.artifacts?.find((artifact) => artifact.type === 'preview')
  if (!preview) {
    if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
    previewUrl.value = ''
    loadedArtifactKey = key
    return
  }
  try {
    const blob = await fetchCadArtifact(task.task_id, 'preview')
    if (requestId !== artifactRequestId || task.task_id !== selectedTaskId.value) return
    if (previewUrl.value) URL.revokeObjectURL(previewUrl.value)
    previewUrl.value = URL.createObjectURL(blob)
    loadedArtifactKey = key
  } catch (error) {
    if (disposed || requestId !== artifactRequestId) return
    ElMessage.error(error.message || 'Failed to load CAD preview')
  }
}

async function generate() {
  if (disposed || !prompt.value.trim() || generating.value) return
  generating.value = true
  try {
    const response = await createCadTask({
      prompt: prompt.value.trim(),
      output_format: outputFormat.value,
      auto_build: true,
    })
    if (disposed) return
    const task = {
      task_id: response.task_id,
      status: response.status,
      progress: 5,
      message: response.message,
      input: { prompt: prompt.value.trim(), output_format: outputFormat.value },
      result: {
        workflow_state: response.workflow_state,
        workflow_nodes: response.workflow_nodes,
      },
      created_at: new Date().toISOString(),
    }
    tasks.value.unshift(task)
    selectedTaskId.value = task.task_id
    clearTaskArtifacts()
    prompt.value = ''
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to start CAD generation')
  } finally {
    generating.value = false
  }
}

async function continueReview() {
  if (disposed || !selectedTask.value || repairing.value) return
  const task = selectedTask.value
  repairing.value = true
  try {
    const response = await startCadBuild(task.task_id)
    if (disposed) return
    replaceTask({ ...task, status: response.status, message: response.message, result: { ...task.result, phase: 'building' } })
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to continue CAD review')
  } finally {
    repairing.value = false
  }
}

async function repairSelectedScript() {
  if (disposed || !selectedTask.value || repairing.value) return
  const task = selectedTask.value
  repairing.value = true
  try {
    const response = await repairCadModelScript(task.task_id)
    if (disposed) return
    replaceTask({
      ...task,
      status: response.status,
      message: response.message,
      progress: 5,
      error: null,
      result: {
        ...task.result,
        phase: 'repairing',
        artifacts: [],
        workflow_state: response.workflow_state,
        workflow_nodes: response.workflow_nodes,
      },
    })
    if (task.task_id === selectedTaskId.value) clearTaskArtifacts()
    ElMessage.info('Repairing the source and regenerating the review preview.')
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to repair the CAD model script')
  } finally {
    repairing.value = false
  }
}

async function cancelSelectedTask() {
  if (disposed || !selectedTask.value) return
  try {
    const task = await cancelCadTask(selectedTask.value.task_id)
    if (disposed) return
    replaceTask(task)
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to cancel CAD task')
  }
}

async function downloadArtifact(type, filename) {
  if (disposed || !selectedTask.value) return
  try {
    const blob = await fetchCadArtifact(selectedTask.value.task_id, type)
    if (disposed) return
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = filename
    anchor.click()
    URL.revokeObjectURL(url)
  } catch (error) {
    if (disposed) return
    ElMessage.error(error.message || 'Failed to download CAD artifact')
  }
}

function statusLabel(value) {
  return ({ running: 'Running', script_ready: 'Source ready', completed: 'Review ready', failed: 'Failed', cancelled: 'Cancelled' })[value] || value
}

function formatDate(value) {
  return value ? new Date(value).toLocaleString() : 'Just now'
}
</script>

<style scoped>
.cad-workspace { display: flex; flex-direction: column; height: 100%; min-height: 0; background: #f8fafc; color: #1f2937; }
.cad-toolbar { display: flex; align-items: center; justify-content: space-between; min-height: 64px; padding: 0 24px; background: #fff; border-bottom: 1px solid #e5e7eb; gap: 16px; }
.cad-title, .cad-runtime-status, .section-heading, .cad-form-footer, .script-heading, .preview-heading, .artifact-row { display: flex; align-items: center; }
.cad-title { gap: 12px; min-width: 0; }
.cad-mark { display: grid; place-items: center; width: 34px; height: 34px; border-radius: 7px; background: #e6f4f1; color: #0f766e; }
.cad-title strong, .cad-title span, .section-heading h2, .section-heading span { display: block; }
.cad-title strong { font-size: 14px; font-weight: 650; }
.cad-title div > span, .section-heading span { color: #6b7280; font-size: 12px; margin-top: 3px; }
.cad-runtime-status { justify-content: flex-end; gap: 10px; flex-wrap: wrap; }
.status-indicator { padding: 5px 8px; border-radius: 4px; font-size: 11px; white-space: nowrap; }
.status-indicator.ready { color: #166534; background: #ecfdf3; }
.status-indicator.missing { color: #9a3412; background: #fff7ed; }
.icon-button { display: inline-grid; place-items: center; border: 0; background: transparent; color: #64748b; width: 32px; height: 32px; cursor: pointer; }
.icon-button:hover { background: #f1f5f9; color: #0f766e; }
.cad-layout { display: grid; grid-template-columns: minmax(300px, 0.9fr) minmax(280px, 0.7fr); gap: 0; min-height: 0; flex: 1; overflow: auto; }
.cad-compose-panel, .cad-tasks-panel, .cad-result-panel { min-width: 0; padding: 22px 24px; background: #fff; border-bottom: 1px solid #e5e7eb; }
.cad-compose-panel { grid-column: 1; border-right: 1px solid #e5e7eb; }
.cad-tasks-panel { grid-column: 2; }
.cad-result-panel { grid-column: 1 / -1; border-top: 1px solid #e5e7eb; }
.section-heading { justify-content: space-between; gap: 16px; margin-bottom: 16px; }
.section-heading h2 { margin: 0; font-size: 15px; font-weight: 650; }
.format-select { width: 140px; }
.cad-prompt { display: block; box-sizing: border-box; width: 100%; min-height: 150px; resize: vertical; border: 1px solid #cbd5e1; border-radius: 5px; padding: 12px; color: #1f2937; font: inherit; font-size: 13px; line-height: 1.55; outline: none; }
.cad-prompt:focus { border-color: #0f766e; box-shadow: 0 0 0 2px #0f766e20; }
.cad-form-footer { justify-content: space-between; gap: 12px; margin-top: 12px; color: #64748b; font-size: 11px; }
.cad-form-footer :deep(.el-button) { font-weight: 600; }
.cad-task-row { display: flex; width: 100%; align-items: center; justify-content: space-between; gap: 12px; border: 0; border-top: 1px solid #eef2f6; padding: 11px 3px; background: transparent; color: inherit; text-align: left; cursor: pointer; }
.cad-task-row:hover, .cad-task-row.selected { background: #f8fafc; }
.task-row-main { display: block; min-width: 0; }
.task-row-main strong { display: -webkit-box; overflow: hidden; -webkit-box-orient: vertical; -webkit-line-clamp: 2; font-size: 12px; font-weight: 550; line-height: 1.45; }
.task-row-main small { display: block; margin-top: 4px; color: #64748b; font-size: 10px; }
.task-status { flex: none; color: #64748b; font-size: 10px; }
.status-script_ready { color: #0369a1; }
.status-completed { color: #15803d; }
.status-failed { color: #b91c1c; }
.empty-state { display: grid; min-height: 130px; place-items: center; color: #94a3b8; font-size: 12px; }
.result-heading { align-items: flex-start; }
.cad-error { white-space: pre-wrap; border-left: 3px solid #dc2626; padding: 10px 12px; margin-bottom: 14px; background: #fff7f7; color: #991b1b; font-size: 12px; line-height: 1.5; }
.cad-workflow { border-top: 1px solid #e5e7eb; padding-top: 14px; margin-top: 14px; }
.legacy-workflow-note { color: #64748b; font-size: 11px; margin-top: 12px; }
.cad-workflow-heading { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 10px; }
.cad-workflow-heading strong { font-size: 12px; }
.cad-workflow-heading span { color: #64748b; font: 10px Consolas, 'Courier New', monospace; }
.pipeline { display: flex; align-items: flex-start; gap: 4px; overflow-x: auto; padding: 4px 2px 10px; }
.pipe-node { display: flex; flex: 0 0 78px; flex-direction: column; align-items: center; gap: 5px; color: #94a3b8; }
.pipe-icon { display: grid; place-items: center; width: 26px; height: 26px; border: 1px solid #cbd5e1; border-radius: 50%; background: #fff; font-size: 10px; }
.pipe-label { font-size: 10px; line-height: 1.25; text-align: center; }
.pipe-node.done { color: #15803d; }
.pipe-node.done .pipe-icon { border-color: #16a34a; background: #f0fdf4; }
.pipe-node.active { color: #0369a1; }
.pipe-node.active .pipe-icon { border-color: #0284c7; background: #f0f9ff; }
.pipe-node.fail, .pipe-node.cancelled { color: #b91c1c; }
.pipe-node.fail .pipe-icon, .pipe-node.cancelled .pipe-icon { border-color: #dc2626; background: #fef2f2; }
.pipe-node.skipped { color: #64748b; }
.pipe-arrow { flex: 0 0 16px; margin-top: 2px; color: #cbd5e1; font-size: 25px; line-height: 25px; text-align: center; }
.pipe-arrow.lit { color: #16a34a; }
.pipe-dot { display: grid; place-items: center; width: 100%; height: 100%; }
.cad-plan, .script-review { border-top: 1px solid #e5e7eb; padding-top: 14px; margin-top: 14px; }
.cad-plan summary, .script-review summary { color: #334155; font-size: 12px; font-weight: 600; cursor: pointer; }
.review-placeholder { display: grid; min-height: 180px; place-items: center; padding: 16px; color: #64748b; font-size: 12px; text-align: center; }
.plan-heading { display: flex; justify-content: space-between; gap: 12px; align-items: center; }
.plan-heading strong { font-size: 12px; }
.plan-heading span { font-size: 10px; font-weight: 650; }
.review-pass { color: #15803d; }
.review-revise { color: #b91c1c; }
.cad-plan p { margin: 8px 0; color: #334155; font-size: 12px; line-height: 1.5; }
.plan-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px 14px; }
.plan-grid div { min-width: 0; }
.plan-grid strong, .plan-grid span { display: block; }
.plan-grid strong { color: #64748b; font-size: 10px; font-weight: 600; }
.plan-grid span { margin-top: 2px; color: #334155; font-size: 11px; line-height: 1.4; overflow-wrap: anywhere; }
@media (max-width: 620px) { .plan-grid { grid-template-columns: 1fr; } }
.script-review, .cad-preview, .artifact-list { border-top: 1px solid #e5e7eb; padding-top: 14px; margin-top: 14px; }
.script-heading, .preview-heading, .artifact-row { justify-content: space-between; gap: 12px; }
.script-heading strong, .preview-heading strong, .artifact-list > strong { font-size: 12px; }
.script-review pre { max-height: 330px; overflow: auto; margin: 10px 0 14px; padding: 12px; border-radius: 4px; background: #111827; color: #e5e7eb; font: 11px/1.55 Consolas, 'Courier New', monospace; white-space: pre; }
.cad-preview img { display: block; max-width: 100%; max-height: 480px; object-fit: contain; margin: 12px auto; background: #f8fafc; }
.artifact-list { display: flex; flex-direction: column; gap: 8px; }
.artifact-row { border-top: 1px solid #eef2f6; padding: 7px 0; font-size: 11px; }
.artifact-row span { overflow-wrap: anywhere; }
@media (max-width: 820px) {
  .cad-toolbar { align-items: flex-start; flex-direction: column; padding: 12px 16px; }
  .cad-runtime-status { justify-content: flex-start; }
  .cad-layout { grid-template-columns: 1fr; }
  .cad-compose-panel, .cad-tasks-panel, .cad-result-panel { grid-column: 1; border-right: 0; padding: 18px 16px; }
}
</style>
