/**
 * @file useDriverWorkflow.js
 * @author zhangjian
 * @brief Derived Driver workflow status and progress helpers.
 * @version 1.0
 * @date 2026-07-22
 * @copyright Copyright (c) 2026 relivercao@gmail.com
 * All rights reserved.
 *
 * This composable converts Driver task phase, progress, and module options
 * into UI-ready workflow labels and step states. It keeps progress presentation
 * separate from API polling and task persistence.
 */
import { computed } from 'vue'
import { WORKFLOW_STEP_DEFINITIONS } from '@/constants/driverWorkspace'

export const WORKFLOW_STAGE_TO_STEP_TITLE = {
  ingest_sources: 'Compile Knowledge Base',
  compile_knowledge_base: 'Compile Knowledge Base',
  build_context: 'Build Prompt',
  build_prompt: 'Build Prompt',
  review_requirements: 'Build Prompt',
  analyze: 'Build Prompt',
  generating_driver: 'Code Gen',
  code_gen: 'Code Gen',
  generate: 'Code Gen',
  writing_files: 'Code Gen',
  static_validation: 'Code Gen',
  compile: 'Compile',
  compile_start: 'Compile',
  compile_success: 'Compile',
  compile_failed: 'Compile',
  compile_error: 'Compile',
  compile_skipped: 'Compile',
  compile_unsupported: 'Compile',
  run_unittest: 'Unit Test',
  unit_test: 'Unit Test',
  code_review: 'Code Review',
  export_artifacts: 'Compile',
}

export const WORKFLOW_STAGE_ORDER = {
  ingest_sources: 0,
  compile_knowledge_base: 0,
  build_context: 1,
  build_prompt: 1,
  review_requirements: 1,
  analyze: 1,
  generating_driver: 2,
  code_gen: 2,
  generate: 2,
  writing_files: 2,
  static_validation: 2,
  compile: 3,
  compile_start: 3,
  compile_success: 3,
  compile_failed: 3,
  compile_error: 3,
  compile_skipped: 3,
  compile_unsupported: 3,
  export_artifacts: 3,
  run_unittest: 4,
  unit_test: 4,
  code_review: 5,
}

function clampPercent(value) {
  const progress = Number(value) || 0
  return Math.min(100, Math.max(0, progress))
}

function getStepIndexByTitle(steps, title) {
  if (!title) return -1
  return steps.findIndex(step => step.title === title)
}

export function useDriverWorkflow(phase, moduleConfig, currentStep, backendProgress) {
  const statusTitle = computed(() => {
    if (phase.value === 'running') return 'Generating Package'
    if (phase.value === 'done') return 'Generation Complete'
    return 'Ready for Prompt'
  })

  const statusDescription = computed(() => {
    if (phase.value === 'running') return 'The agent is assembling driver artifacts from the prompt, chip settings, and optional files.'
    if (phase.value === 'done') return 'Driver workflow completed.'
    return 'Upload optional files, configure the target chip, then enter a prompt to start driver generation.'
  })

  const dynamicStepDefinitions = computed(() => {
    const steps = [...WORKFLOW_STEP_DEFINITIONS]
    const config = moduleConfig.value || {}

    if (config.generateTests) {
      steps.push({ title: 'Unit Test', description: 'Generating unit test suites' })
    }

    if (config.generateCodeReview) {
      steps.push({ title: 'Code Review', description: 'Performing code review analysis' })
    }

    return steps
  })

  const activeStepIndex = computed(() => {
    const steps = dynamicStepDefinitions.value
    const stage = String(currentStep?.value || '').trim()
    const stageStepIndex = getStepIndexByTitle(steps, WORKFLOW_STAGE_TO_STEP_TITLE[stage])

    if (stageStepIndex >= 0) {
      return stageStepIndex
    }

    return 0
  })

  const workflowSteps = computed(() => {
    return dynamicStepDefinitions.value.map((step, index) => {
      if (phase.value === 'done') return { ...step, state: 'done' }
      if (phase.value === 'running') {
        const currentStepIndex = activeStepIndex.value
        if (index < currentStepIndex) return { ...step, state: 'done' }
        if (index === currentStepIndex) return { ...step, state: 'active' }
        return { ...step, state: 'pending' }
      }
      if (index === 0) return { ...step, state: 'active' }
      return { ...step, state: 'pending' }
    })
  })

  const workflowProgress = computed(() => {
    if (phase.value === 'done') return 100
    if (phase.value === 'running') {
      return clampPercent(backendProgress?.value)
    }
    return 0
  })

  return {
    statusTitle,
    statusDescription,
    workflowSteps,
    workflowProgress,
  }
}
