import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useAuthStore } from '../stores/auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'
import {
  apiCancelBugFixBatch, apiCreateBugFixBatch, apiGetBugFixBatch,
  apiGetBugFixTask, apiListBugFixBatches, apiPollBugFixBatch,
} from '../api/bugfix.js'

const terminal = status => ['completed', 'failed', 'cancelled'].includes(status)

export function useBugFixBatch() {
  const auth = useAuthStore()
  const identity = accountIdentity(auth)
  let disposed = false
  let stopPolling = null
  let viewVersion = 0
  let detailVersion = 0
  const current = () => !disposed && identity === accountIdentity(auth)
  const queue = ref([])
  const checked = ref(new Set())
  const selectedId = ref('')
  const snapshot = ref(null)
  const history = ref([])
  const creating = ref(false)
  const loading = ref(false)
  const cancelling = ref(false)
  const monitoring = ref(false)
  const error = ref('')
  const detail = ref(null)
  const detailError = ref('')
  const detailLoading = ref(false)
  const busy = computed(() => creating.value || loading.value || snapshot.value?.status === 'running')
  const locked = computed(() => busy.value || Boolean(snapshot.value))
  const items = computed(() => snapshot.value?.items || queue.value)
  const selectedItem = computed(() => items.value.find(item => item.task_id === selectedId.value) || null)
  const selectedCount = computed(() => queue.value.filter(item => checked.value.has(item.task_id)).length)

  function dispose() {
    disposed = true
    viewVersion++
    detailVersion++
    stopPolling?.()
    stopPolling = null
  }
  watch(() => accountIdentity(auth), () => {
    dispose()
    queue.value = []
    checked.value = new Set()
    snapshot.value = null
    history.value = []
    selectedId.value = ''
    detail.value = null
    error.value = ''
    detailError.value = ''
  }, { flush: 'sync' })
  onBeforeUnmount(dispose)

  async function refreshHistory() {
    try {
      const response = await apiListBugFixBatches()
      if (current()) history.value = response.batches || []
      return response.batches || []
    } catch (failure) {
      if (current()) error.value = failure.message || 'Unable to load batch history. Use Refresh to retry.'
      return []
    }
  }

  async function loadDetail() {
    const item = selectedItem.value
    if (!current() || !item || !snapshot.value || ['queued'].includes(item.status)) return
    // Unstarted items have reserved IDs but no server task record.
    if (item.status === 'cancelled' && item.message === 'Not started: batch stopped') return
    const version = ++detailVersion
    detailError.value = ''
    detailLoading.value = true
    try {
      const response = await apiGetBugFixTask(item.task_id)
      if (current() && version === detailVersion) detail.value = response
    } catch (failure) {
      if (current() && version === detailVersion) detailError.value = failure.message || 'Unable to load the repair report.'
    } finally {
      if (current() && version === detailVersion) detailLoading.value = false
    }
  }

  watch(selectedId, () => {
    detailVersion++
    detail.value = null
    detailError.value = ''
    detailLoading.value = false
    void loadDetail()
  })

  function acceptSnapshot(data) {
    if (!current()) return
    if (snapshot.value?.task_id === data.task_id && terminal(snapshot.value.status) && !terminal(data.status)) return
    snapshot.value = data
    if (terminal(data.status)) {
      monitoring.value = false
      stopPolling?.()
    }
    if (!data.items?.some(item => item.task_id === selectedId.value)) {
      selectedId.value = data.items?.find(item => item.status === 'running')?.task_id || data.items?.[0]?.task_id || ''
    } else {
      void loadDetail()
    }
  }

  function monitor() {
    if (!current() || !snapshot.value || terminal(snapshot.value.status)) return
    stopPolling?.()
    const id = snapshot.value.task_id
    monitoring.value = true
    stopPolling = apiPollBugFixBatch(id, data => {
      if (!current() || snapshot.value?.task_id !== id) return
      if (!data.task_id) {
        error.value = data.error || data.message || 'Unable to read batch progress.'
        if (terminal(data.status)) monitoring.value = false
        return
      }
      error.value = ''
      acceptSnapshot(data)
      if (terminal(data.status)) {
        monitoring.value = false
        void refreshHistory()
      }
    })
  }

  async function openBatch(id) {
    if (!current() || !id || busy.value) return
    const version = ++viewVersion
    loading.value = true
    error.value = ''
    try {
      const data = await apiGetBugFixBatch(id)
      if (!current() || version !== viewVersion) return
      stopPolling?.()
      detailVersion++
      detail.value = null
      selectedId.value = ''
      acceptSnapshot(data)
      monitor()
    } catch (failure) {
      if (current() && version === viewVersion) error.value = failure.message || 'Unable to open the batch.'
    } finally {
      if (current() && version === viewVersion) loading.value = false
    }
  }

  onMounted(async () => {
    if (!auth.isLoggedIn) return
    const version = viewVersion
    try {
      const batches = await refreshHistory()
      if (current() && version === viewVersion && !queue.value.length && batches.length) {
        await openBatch(batches[0].task_id)
      }
    } catch (failure) {
      if (current()) error.value = failure.message || 'Unable to load batch history.'
    }
  })

  function addItems(issues, request) {
    if (!current() || locked.value) return
    error.value = ''
    const additions = issues.filter(issue => !queue.value.some(item =>
      item.issue_id === issue.key && item.repo === request.repo && item.branch === request.branch,
    ))
    if (!additions.length) {
      error.value = 'These defects are already in the queue for this repository and branch.'
      return
    }
    if (queue.value.length + additions.length > 100) {
      error.value = 'A batch may contain at most 100 defects.'
      return
    }
    viewVersion++
    for (const issue of additions) {
      const id = `draft-${Date.now()}-${Math.random().toString(36).slice(2)}`
      const input = { ...request, source_files: [...request.source_files], issue_id: issue.key }
      queue.value.push({
        task_id: id, issue_id: issue.key, label: issue.key, summary: issue.summary,
        repo: request.repo, branch: request.branch, source_files: [...request.source_files],
        status: 'queued', progress: 0, request: input,
      })
      checked.value.add(id)
    }
    if (!selectedId.value) selectedId.value = queue.value[0].task_id
  }

  function toggle(id, selected) {
    if (!current() || locked.value) return
    const next = new Set(checked.value)
    if (selected) next.add(id)
    else next.delete(id)
    checked.value = next
  }

  function remove(id) {
    if (!current() || locked.value) return
    queue.value = queue.value.filter(item => item.task_id !== id)
    toggle(id, false)
    if (selectedId.value === id) selectedId.value = queue.value[0]?.task_id || ''
  }

  function move(id, offset) {
    if (!current() || locked.value) return
    const index = queue.value.findIndex(item => item.task_id === id)
    const target = index + offset
    if (index < 0 || target < 0 || target >= queue.value.length) return
    const next = [...queue.value]
    ;[next[index], next[target]] = [next[target], next[index]]
    queue.value = next
  }

  async function start() {
    if (!current() || locked.value || !selectedCount.value) return
    if (!auth.isLoggedIn) { error.value = 'Sign in to run a BugFix batch.'; return }
    creating.value = true
    error.value = ''
    viewVersion++
    try {
      const requests = queue.value.filter(item => checked.value.has(item.task_id)).map(item => item.request)
      const response = await apiCreateBugFixBatch(requests)
      if (!current()) return
      acceptSnapshot(response)
      monitor()
      void refreshHistory()
    } catch (failure) {
      if (current()) error.value = failure.message || 'Unable to create the batch. Check batch history before retrying.'
    } finally {
      if (current()) creating.value = false
    }
  }

  async function cancel() {
    if (!current() || !snapshot.value || snapshot.value.status !== 'running' || cancelling.value) return
    const id = snapshot.value.task_id
    cancelling.value = true
    try {
      const data = await apiCancelBugFixBatch(id)
      if (current() && snapshot.value?.task_id === id) acceptSnapshot(data)
    } catch (failure) {
      if (current() && snapshot.value?.task_id === id && !terminal(snapshot.value.status)) {
        error.value = `${failure.message || 'Cancellation failed.'} Monitoring continues; cancellation can be retried.`
      }
    } finally {
      if (current()) cancelling.value = false
    }
  }

  function newBatch() {
    if (!current() || busy.value) return
    viewVersion++
    detailVersion++
    stopPolling?.()
    snapshot.value = null
    queue.value = []
    checked.value = new Set()
    selectedId.value = ''
    detail.value = null
    detailError.value = ''
    error.value = ''
  }

  return {
    queue, checked, selectedId, snapshot, history, busy, locked, creating, cancelling,
    monitoring, loading, error, detail, detailError, detailLoading, items, selectedItem,
    selectedCount, addItems, toggle, remove, move, start, cancel, newBatch, openBatch,
    monitor, loadDetail, refreshHistory,
  }
}
