import { ref } from 'vue'
import { getModelCatalog } from '../api/modelManagement.js'

export function useModelCatalog() {
  const catalog = ref([])
  const catalogError = ref('')
  async function loadCatalog() {
    try {
      const result = await getModelCatalog()
      catalog.value = result.items || []
      catalogError.value = ''
    } catch (error) {
      catalogError.value = error.message || 'Could not load model catalog'
    }
  }
  function options(provider, current = '', defaults = []) {
    const entries = catalog.value.filter(entry => entry.provider === provider)
    const names = new Map(entries.map(entry => [entry.model, entry.display_name]))
    for (const value of [current, ...defaults].filter(Boolean)) {
      if (!names.has(value)) names.set(value, value)
    }
    return [...names].map(([value, label]) => ({ value, label }))
  }
  return { catalog, catalogError, loadCatalog, options }
}
