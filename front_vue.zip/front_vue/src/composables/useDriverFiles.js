/**
 * @file useDriverFiles.js
 * @author zhangjian
 * @brief File metadata and source-list helpers for the Driver workspace.
 * @version 1.0
 * @date 2026-07-22
 * @copyright Copyright (c) 2026 relivercao@gmail.com
 * All rights reserved.
 *
 * This composable normalizes local Driver source-file metadata and provides
 * display helpers for upload state, parse state, file size, and source labels.
 * It does not upload files or mutate backend task state.
 */
import { computed } from 'vue'
import { GENERATION_SOURCE_OPTIONS } from '@/constants/driverWorkspace'

export function useDriverFiles(knowledgeBaseFiles, referenceFiles) {
  function createFileId(file) {
    // Prefer persisted IDs when restoring uploaded files; fallback uses deterministic properties only.
    return file.fileId || `${file.name}-${file.size || 0}-${file.lastModified || 0}`
  }

  function createFileMeta(file) {
    if (!file) return null
    return {
      fileId: createFileId(file),
      name: file.name,
      size: file.size,
      type: file.type || '',
      lastModified: file.lastModified || null,
      uploadStatus: file.uploadStatus || 'uploaded',
      parseStatus: file.parseStatus || 'pending',
      source_id: file.source_id || file.sourceId || (file.fileId?.startsWith('src_') ? file.fileId : null),
      savedPath: file.savedPath || '',
    }
  }

  function createFileMetaList(files) {
    if (!files || files.length === 0) return []
    return files.map(file => createFileMeta(file))
  }

  function formatFileSize(bytes) {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`
  }

  function getFileExtension(filename) {
    if (!filename || !filename.includes('.')) return 'FILE'
    const ext = filename.split('.').pop().toUpperCase()
    return ext.length > 4 ? ext.slice(0, 4) : ext
  }

  function getFilesByKey(key) {
    return key === 'knowledgeBaseFiles' ? knowledgeBaseFiles.value : referenceFiles.value
  }

  function getUploadedFiles(key) {
    return getFilesByKey(key).filter(file => file.uploadStatus === 'uploaded')
  }

  function areFilesUploaded(key) {
    const files = getFilesByKey(key)
    return files.length > 0 && files.every(file => file.uploadStatus === 'uploaded')
  }

  function getFileStatusLabel(file) {
    if (file.parseStatus === 'parsing') {
      return 'Parsing...'
    }
    if (file.parseStatus === 'parsed') {
      return 'Parsed'
    }
    if (file.parseStatus === 'failed') {
      return 'Parse Failed'
    }
    if (file.uploadStatus === 'uploaded') {
      return 'Uploaded'
    }
    return 'Uploading'
  }

  function getFileStatusClass(file) {
    if (file.parseStatus === 'pending') {
      return 'pending'
    }
    if (file.parseStatus === 'parsing') {
      return 'parsing'
    }
    if (file.parseStatus === 'parsed') {
      return 'parsed'
    }
    if (file.parseStatus === 'failed') {
      return 'failed'
    }
    if (file.uploadStatus === 'uploaded') {
      return 'uploaded'
    }
    return 'uploading'
  }

  function getGenerationSourceFiles(key) {
    return getFilesByKey(key)
  }

  function getGenerationSourceFileCount(key) {
    return getGenerationSourceFiles(key).length
  }

  function getGenerationSourceLabel(key) {
    const source = GENERATION_SOURCE_OPTIONS.find(option => option.key === key)
    return source?.label || 'Selected Files'
  }

  function getGenerationSourceDescription(key) {
    const files = getGenerationSourceFiles(key)
    if (files.length === 0) return 'No files uploaded yet'
    return `${files.length} file(s) uploaded`
  }

  const fileHelpers = computed(() => ({
    formatFileSize,
    getFileExtension,
    getFileStatusLabel,
    getFileStatusClass,
  }))

  return {
    fileHelpers,
    createFileMeta,
    createFileMetaList,
    formatFileSize,
    getFileExtension,
    getUploadedFiles,
    areFilesUploaded,
    getFileStatusLabel,
    getFileStatusClass,
    getGenerationSourceFiles,
    getGenerationSourceFileCount,
    getGenerationSourceLabel,
    getGenerationSourceDescription,
  }
}
