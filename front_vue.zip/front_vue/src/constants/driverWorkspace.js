/**
 * @file driverWorkspace.js
 * @author zhangjian
 * @brief Shared constants and preview defaults for the Driver workspace
 *        frontend.
 * @version 1.0
 * @date 2026-07-21
 * @copyright Copyright (c) 2026 relivercao@gmail.com
 * All rights reserved.
 *
 * These values describe frontend-only options and preview/default content used
 * by Driver Workspace components. Real generated driver artifacts should come
 * from the Driver Agent backend APIs, not from these defaults.
 */
// Module types shown in the Driver configuration form.
export const MODULE_TYPES = ['IMU', 'LED', 'Charger', 'Other']

// Upload source categories supported by the Driver generation flow.
export const GENERATION_SOURCE_OPTIONS = [
  {
    key: 'knowledgeBaseFiles',
    label: 'Knowledge Base Files',
    tone: 'blue'
  },
  {
    key: 'referenceFiles',
    label: 'Reference Files',
    tone: 'violet'
  }
]

// No static generated code is bundled here. Driver artifacts must come from the backend.
export const GENERATED_CODE_TABS = []
// Base workflow shown while the Driver backend task is running.
export const WORKFLOW_STEP_DEFINITIONS = [
  { title: 'Compile Knowledge Base', description: 'Processing reference materials' },
  { title: 'Build Prompt', description: 'Constructing generation prompt from inputs' },
  { title: 'Code Gen', description: 'Generating driver code' },
  { title: 'Compile', description: 'Compiling generated code' }
]

// Default post-generation switches; actual execution remains controlled by the Driver backend.
export function createDefaultPostGenOptions() {
  return {
    flashToDevice: false,
    auxiliaryCheck: false
  }
}

// Chat history starts empty until the Driver backend or user interaction provides real messages.
export function createDefaultChatMessages() {
  return []
}

// Serial logs start empty until live Driver task logs are available.
export function createDefaultSerialLogs() {
  return []
}


