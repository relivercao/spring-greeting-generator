import {
  Box,
  CollectionTag,
  DataBoard,
  Reading,
} from '@element-plus/icons-vue'
import cosmicAnimeThumbnail from '../assets/image-presets/cosmic-anime.jpg'
import porcelainCatalogThumbnail from '../assets/image-presets/porcelain-catalog.jpg'
import fantasyGameThumbnail from '../assets/image-presets/fantasy-game.jpg'
import openWorldRacingThumbnail from '../assets/image-presets/open-world-racing.jpg'

export const imagePromptPresetCategories = [
  { id: 'creative', label: 'Creative' },
  { id: 'technical', label: 'Technical' },
]

export const imagePromptPresets = [
  {
    id: 'cosmic-anime',
    category: 'creative',
    label: 'Cosmic anime poster',
    description: 'A dramatic celestial hero poster with an original fantasy world.',
    tags: [],
    thumbnail: cosmicAnimeThumbnail,
    aspectRatio: '9:16',
    size: '864x1536',
    sizeLabel: 'Portrait 9:16',
    prompt: 'Create a cinematic vertical anime key visual for an original cosmic fantasy story. Place one memorable hero in a sweeping celestial environment with layered planets, luminous nebulae, drifting particles, and a clear focal silhouette. Use expressive painterly detail, atmospheric depth, controlled rim lighting, and a cohesive palette chosen to match the user\'s subject. Compose for a 9:16 poster with generous visual hierarchy and room for a title, but do not render text, logos, signatures, or watermarks. Keep anatomy coherent, the face readable, and the background detailed without competing with the hero.',
  },
  {
    id: 'porcelain-catalog',
    category: 'creative',
    label: 'Blue-and-white porcelain catalog',
    description: 'A museum-style artifact plate with a clean specimen-study layout.',
    tags: [],
    thumbnail: porcelainCatalogThumbnail,
    aspectRatio: '4:3',
    size: '1024x768',
    sizeLabel: 'Landscape 4:3',
    prompt: 'Create a refined 4:3 museum catalog plate centered on the blue-and-white porcelain object described by the user. Show one complete artifact at a consistent three-quarter angle, surrounded by a few restrained detail views and archival-style layout guides. Use a pale paper background, precise cobalt decoration, soft gallery lighting, and balanced negative space. Preserve only the era, motifs, materials, and provenance supplied by the user; never invent historical facts or inscriptions. Keep any labels as clean empty placeholders so accurate text can be added later. No extra artifacts, fake seals, logos, or watermark.',
  },
  {
    id: 'fantasy-game',
    category: 'creative',
    label: 'Ancient fantasy game key art',
    description: 'A misty ancient-world promotion image for a fantasy game.',
    tags: [],
    thumbnail: fantasyGameThumbnail,
    aspectRatio: '9:16',
    size: '864x1536',
    sizeLabel: 'Portrait 9:16',
    prompt: 'Create a vertical 9:16 promotional key art image for an original ancient-fantasy game. Stage the characters and setting supplied by the user against weathered stone architecture, distant mountains, and layered night mist. Use cinematic scale, clear silhouettes, dramatic but readable lighting, rich material detail, and a restrained palette suited to the story. Keep the central character recognizable and leave open space near the top for optional campaign copy. Do not add game logos, title text, UI, invented story details, or watermarks.',
  },
  {
    id: 'open-world-racing',
    category: 'creative',
    label: 'Open-world racing gameplay',
    description: 'A high-speed neon city scene framed like an in-game capture.',
    tags: [],
    thumbnail: openWorldRacingThumbnail,
    aspectRatio: '16:9',
    size: '1536x864',
    sizeLabel: 'Wide 16:9',
    prompt: 'Create a convincing 16:9 open-world racing game capture featuring the vehicle and city setting described by the user. Show the car in motion on a broad urban road at night, with believable road markings, reflections, traffic scale, and a readable skyline. Use a low chase-camera viewpoint, controlled motion blur, crisp vehicle detail, and colorful city lighting without obscuring the road. Make it feel like polished gameplay rather than a poster. Do not include brand logos, legible interface text, fake speed readouts, or watermarks.',
  },
  {
    id: 'structure',
    category: 'technical',
    label: 'Structure diagram',
    description: 'Readable system architecture, flow, and register relationships',
    tags: ['Architecture', 'Firmware', 'Labels'],
    icon: DataBoard,
    aspectRatio: '3:2',
    size: '1536x1024',
    sizeLabel: 'Landscape 1.5K',
    prompt: 'Create a publication-ready firmware system structure diagram for the system or chip named by the user. Arrange layers from hardware and registers through drivers, middleware, RTOS tasks, services, and application behavior. Use a clear left-to-right data and control flow, orthogonal connectors, consistent spacing, grouped boundaries, and a restrained engineering palette. Preserve every exact label, register name, bit-field name, value, and relationship supplied by the user; never invent technical identifiers. Use vector-like crisp lines, high contrast, legible typography, and a compact legend. Include a small title and source-note area only when requested. No decorative 3D effects, fake specifications, watermarks, or unreadable microtext.',
  },
  {
    id: 'packaging',
    category: 'technical',
    label: 'Packaging visual',
    description: 'Product box, label, and technical kit presentation',
    tags: ['Product', 'Packaging', 'Studio'],
    icon: Box,
    aspectRatio: '3:2',
    size: '1536x1024',
    sizeLabel: 'Landscape 1.5K',
    prompt: 'Create a premium studio product and packaging visual for the embedded hardware or kit named by the user. Show the physical product, its box or tray, labels, accessories, and a clean presentation surface in a balanced three-quarter composition. Use realistic materials, accurate component proportions, controlled softbox lighting, natural contact shadows, and a neutral technical brand language. Keep all supplied product names, part numbers, colors, and package text exact; do not add logos, claims, certifications, or specifications that were not provided. Make the main object large enough to inspect, keep the background uncluttered, and reserve negative space for optional copy. No distorted text, extra components, glossy overprocessing, or watermark.',
  },
  {
    id: 'article-summary',
    category: 'technical',
    label: 'Article summary',
    description: 'Editorial visual that compresses a technical article into key ideas',
    tags: ['Article', 'Editorial', 'Infographic'],
    icon: Reading,
    aspectRatio: '3:2',
    size: '1536x1024',
    sizeLabel: 'Landscape 1.5K',
    prompt: 'Create a concise editorial summary visual for the technical article supplied by the user. Distill the article into one clear visual hierarchy: a short title, the central problem or theme, three to five evidence-based takeaways, and a simple relationship or timeline that helps the reader scan it in seconds. Use clean information design, generous whitespace, consistent iconography, accessible contrast, and a calm professional palette. Use only facts, terminology, numbers, and quotations present in the source article; do not fabricate data or citations. Keep text short and legible, avoid paragraphs and tiny labels, and leave room for a source attribution line. No sensational claims, decorative filler, distorted typography, or watermark.',
  },
  {
    id: 'knowledge-base',
    category: 'technical',
    label: 'Knowledge-base configuration',
    description: 'Source-grounded map of documents, entities, and relationships',
    tags: ['Knowledge base', 'RAG', 'Traceable'],
    icon: CollectionTag,
    aspectRatio: '3:2',
    size: '1536x1024',
    sizeLabel: 'Landscape 1.5K',
    prompt: 'Create a source-grounded knowledge-base configuration visual from the selected knowledge base. Map documents and source files into normalized topics, entities, fields, and relationships, then show how retrieval, filtering, and answer generation connect to those sources. Use a readable layered map or flowchart with clear arrows, compact node labels, consistent colors by entity type, and a small legend for metadata such as source path, version, and checksum. Include only entities and relationships supported by the supplied knowledge-base content; preserve exact field names, register names, units, and references, and mark uncertain or missing values instead of guessing. Optimize for auditability and quick technical review. No invented facts, fake links, decorative filler, or illegible text.',
  },
]

export function getImagePresetUpdates(preset) {
  if (!preset) return null

  return {
    prompt: preset.prompt,
    selectedPresetId: preset.id,
    params: {
      size: preset.size,
      quality: 'high',
      outputFormat: 'png',
      transparentOutput: false,
    },
  }
}
