import chatMascot from '../assets/agent-mascots/chat.webp'
import unittestMascot from '../assets/agent-mascots/unittest.webp'
import buildMascot from '../assets/agent-mascots/build.webp'
import debugMascot from '../assets/agent-mascots/debug.webp'
import bugfixMascot from '../assets/agent-mascots/bugfix.webp'
import reviewMascot from '../assets/agent-mascots/review.webp'
import driverMascot from '../assets/agent-mascots/driver.webp'
import cadMascot from '../assets/agent-mascots/cad.webp'
import knowledgeMascot from '../assets/agent-mascots/knowledge.webp'
import imageGenerationMascot from '../assets/agent-mascots/image-generation.webp'
import agentGeneratorMascot from '../assets/agent-mascots/agent-generator.webp'
import chatScene from '../assets/agent-mascots/chat-scene.webp'
import unittestScene from '../assets/agent-mascots/unittest-scene.webp'
import bugfixScene from '../assets/agent-mascots/bugfix-scene.webp'
import reviewScene from '../assets/agent-mascots/review-scene.webp'
import driverScene from '../assets/agent-mascots/driver-scene.webp'
import cadScene from '../assets/agent-mascots/cad-scene.webp'
import knowledgeScene from '../assets/agent-mascots/knowledge-scene.webp'
import imageGenerationScene from '../assets/agent-mascots/image-generation-scene.webp'
import agentGeneratorScene from '../assets/agent-mascots/agent-generator-scene.webp'

const sceneById = {
  1: chatScene,
  2: unittestScene,
  3: driverScene,
  4: reviewScene,
  5: knowledgeScene,
  6: imageGenerationScene,
  7: agentGeneratorScene,
  8: bugfixScene,
  9: cadScene,
}

const mascotById = {
  1: chatMascot,
  2: unittestMascot,
  3: driverMascot,
  4: reviewMascot,
  5: knowledgeMascot,
  6: imageGenerationMascot,
  7: agentGeneratorMascot,
  8: bugfixMascot,
  9: cadMascot,
  10: buildMascot,
  11: debugMascot,
}

const mascotByKey = {
  chat: chatMascot,
  unittest: unittestMascot,
  driver: driverMascot,
  review: reviewMascot,
  knowledge: knowledgeMascot,
  image_generation: imageGenerationMascot,
  agent_generator: agentGeneratorMascot,
  bugfix: bugfixMascot,
  cad: cadMascot,
  build: buildMascot,
  debug: debugMascot,
}

export function agentMascotFor(agent, variant = 'portrait') {
  if (variant === 'scene' && sceneById[agent?.id]) return sceneById[agent.id]
  return mascotById[agent?.id] || mascotByKey[agent?.id] || null
}

export function hasAgentMascot(agent) {
  return Boolean(agentMascotFor(agent))
}
