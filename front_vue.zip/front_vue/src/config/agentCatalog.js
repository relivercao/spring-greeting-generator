export const AGENT_ROUTE_MAP = Object.freeze({
  1: '/chat',
  2: '/unittest',
  3: '/driver',
  4: '/mcu-review',
  5: '/knowledge',
  6: '/image-generation',
  7: '/agent-generator',
  8: '/bugfix',
  9: '/cad',
})

export const AGENT_BACKEND_MAP = Object.freeze({
  1: 'chat',
  2: 'unittest',
  3: 'driver',
  4: 'review',
  5: 'knowledge',
  6: 'image_generation',
  7: 'agent_generator',
  8: 'bugfix',
  9: 'cad',
})

export const BUILT_IN_AGENTS = Object.freeze([
  { id: 1, name: 'Chat Agent', icon: 'ChatDotRound', description: 'Free-form AI conversation for general questions and assistance.', category: 'Chat', color: '#2563eb' },
  { id: 2, name: 'Unittest', icon: 'Finished', description: 'Auto-generate unit test cases with full boundary condition coverage.', category: 'Test', color: '#16a34a' },
  { id: 8, name: 'BugFix Agent', icon: 'Tools', description: 'Trace firmware defects and generate validated patch proposals.', category: 'Fix', color: '#dc2626' },
  { id: 4, name: 'Code Review', icon: 'Cpu', description: 'Review embedded C and C++ for correctness, safety, and standards compliance.', category: 'Review', color: '#0891b2' },
  { id: 3, name: 'Driver Development', icon: 'Connection', description: 'Generate portable peripheral drivers from datasheets and interface specifications.', category: 'Driver', color: '#ea580c' },
  { id: 9, name: 'CAD Agent', icon: 'SetUp', description: 'Generate editable parametric models and build verified STEP or mesh files.', category: 'Design', color: '#0f766e' },
  { id: 5, name: 'Knowledge Base', icon: 'Collection', description: 'Register-first firmware documentation and chip specification Q&A.', category: 'Knowledge', color: '#0891b2' },
  { id: 6, name: 'Image Generation', icon: 'PictureRounded', description: 'Generate and edit images with references, masks, and precise output controls.', category: 'Creative', color: '#db2777' },
  { id: 7, name: 'Agent Generator', icon: 'MagicStick', description: 'Generate reusable Agents from prompts and canonical knowledge.', category: 'Builder', color: '#2563eb' },
])
