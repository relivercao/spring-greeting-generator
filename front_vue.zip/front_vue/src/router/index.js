import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../stores/auth.js'

const routes = [
  // Auth routes
  { path: '/login',      name: 'login',      component: () => import('../views/Login.vue'),  meta: { mode: 'login' } },
  { path: '/register',   name: 'register',   component: () => import('../views/Login.vue'),  meta: { mode: 'register' } },

  // Main application routes
  { path: '/',           name: 'home',       component: () => import('../views/Home.vue') },
  { path: '/chat',       name: 'chat',       component: () => import('../views/Home.vue'), meta: { agentId: 1 } },
  { path: '/unittest',   name: 'unittest',   component: () => import('../views/Home.vue'), meta: { agentId: 2 } },
  { path: '/driver',     name: 'driver',     component: () => import('../views/Home.vue'), meta: { agentId: 3 } },
  { path: '/mcu-review', name: 'mcu-review', component: () => import('../views/Home.vue'), meta: { agentId: 4 } },
  { path: '/image-generation', name: 'image-generation', component: () => import('../views/Home.vue'), meta: { agentId: 6 } },
  { path: '/cad', name: 'cad', component: () => import('../views/Home.vue'), meta: { agentId: 9 } },
  { path: '/knowledge', name: 'knowledge', component: () => import('../views/Home.vue'), meta: { agentId: 5 } },
  { path: '/agent-generator', name: 'agent-generator', component: () => import('../views/Home.vue'), meta: { agentId: 7 } },
  { path: '/bugfix',    name: 'bugfix',    component: () => import('../views/Home.vue'), meta: { agentId: 8 } },
  { path: '/skill-market', name: 'skill-market', component: () => import('../views/Home.vue') },
  { path: '/agent/:agentId', name: 'generated-agent', component: () => import('../views/Home.vue'), meta: { generatedAgent: true } },
  // { path: '/knowledge',  name: 'knowledge',  component: () => import('../views/Home.vue'), meta: { agentId: 5 } }, // RAG not developed yet

  // Payment routes (require a logged-in account; guests keep access to the routes above)
  { path: '/recharge',     name: 'recharge',     component: () => import('../views/RechargeView.vue'),        meta: { requiresAuth: true } },
  { path: '/orders',       name: 'orders',       component: () => import('../views/OrderListView.vue'),       meta: { requiresAuth: true } },
  { path: '/transactions', name: 'transactions', component: () => import('../views/TransactionListView.vue'), meta: { requiresAuth: true } },
  { path: '/usage', name: 'usage', component: () => import('../views/UsageView.vue'), meta: { requiresAuth: true } },
  { path: '/events', name: 'event-center', component: () => import('../views/EventCenterView.vue'), meta: { requiresAuth: true } },
  { path: '/payment/:orderId', name: 'payment',  component: () => import('../views/PaymentView.vue'),         meta: { requiresAuth: true } },

  // Admin routes
  {
    path: '/admin',
    name: 'admin',
    component: () => import('../views/admin/AdminLayout.vue'),
    redirect: '/admin/orders',
    meta: { requiresAdmin: true },
    children: [
      { path: 'models', name: 'admin-models', component: () => import('../views/admin/AdminModelsView.vue'), meta: { requiresAdmin: true } },
      { path: 'usage', name: 'admin-usage', component: () => import('../views/UsageView.vue'), meta: { requiresAdmin: true } },
      { path: 'orders',    name: 'admin-orders',    component: () => import('../views/admin/AdminOrdersView.vue'),    meta: { requiresAdmin: true } },
      { path: 'plans',     name: 'admin-plans',     component: () => import('../views/admin/AdminPlansView.vue'),     meta: { requiresAdmin: true } },
      { path: 'providers', name: 'admin-providers', component: () => import('../views/admin/AdminProvidersView.vue'), meta: { requiresAdmin: true } },
      { path: 'users',     name: 'admin-users',     component: () => import('../views/admin/AdminUsersView.vue'),     meta: { requiresAdmin: true } },
      { path: 'versions',  name: 'admin-versions',  component: () => import('../views/admin/AdminVersionsView.vue'),  meta: { requiresAdmin: true } },
    ],
  },

  // Redirect unmatched routes to home
  { path: '/:pathMatch(.*)*', redirect: '/' },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Route guard: admin pages need an admin account, protected pages need a
// logged-in user, everything else (including guest access) passes through.
router.beforeEach((to) => {
  const auth = useAuthStore()

  if ((to.name === 'login' || to.name === 'register') && auth.hasAccess && to.query.switch !== '1') {
    return { name: 'home' }
  }
  if (to.meta.requiresAdmin && !auth.isAdmin) return { name: 'login' }
  if (to.meta.requiresAuth && !auth.isLoggedIn) return { name: 'login' }
  return true
})

// 401 event triggered by HTTP layer (and by explicit sign-out) — go to login
window.addEventListener('auth:logout', () => {
  useAuthStore().clearSession()
  router.push({ name: 'login' })
})

export default router
