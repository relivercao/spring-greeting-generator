import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { useAuthStore } from './auth.js'
import { accountIdentity as getAccountIdentity } from '../utils/accountIdentity.js'
import {
  deleteImageGenerationTask,
  getImageGenerationTask,
  getImageGenerationTasks,
} from '../api/imageGeneration.js'

const AGENT_ID = 6

function normalizeTask(task) {
  const prompt = task.input?.prompt || task.result?.prompt || 'Image generation'
  return {
    ...task,
    id: task.task_id,
    title: prompt.length > 34 ? `${prompt.slice(0, 34)}...` : prompt,
    time: task.created_at ? new Date(task.created_at).toLocaleString() : '',
    agentId: AGENT_ID,
  }
}

export const useImageGenerationStore = defineStore('imageGeneration', () => {
  const auth = useAuthStore()
  const accountIdentity = computed(() => getAccountIdentity(auth))
  const taskHistory = ref([])
  const loading = ref(false)
  const accountRevision = ref(0)
  let loadingRevision = null

  watch(
    accountIdentity,
    () => {
      accountRevision.value += 1
      taskHistory.value = []
      loading.value = false
      loadingRevision = null
    },
    { flush: 'sync' },
  )

  async function loadHistory() {
    const revision = accountRevision.value
    loadingRevision = revision
    loading.value = true
    try {
      const response = await getImageGenerationTasks({ limit: 50 })
      if (revision !== accountRevision.value) return taskHistory.value
      taskHistory.value = (response.tasks || []).map(normalizeTask)
      return taskHistory.value
    } finally {
      if (loadingRevision === revision && revision === accountRevision.value) {
        loading.value = false
        loadingRevision = null
      }
    }
  }

  function upsertTask(task, expectedRevision = accountRevision.value) {
    if (expectedRevision !== accountRevision.value) return null
    const normalized = normalizeTask(task)
    const index = taskHistory.value.findIndex((item) => item.id === normalized.id)
    if (index === -1) taskHistory.value.unshift(normalized)
    else taskHistory.value[index] = normalized
    return normalized
  }

  async function refreshTask(taskId) {
    const revision = accountRevision.value
    const task = await getImageGenerationTask(taskId)
    return upsertTask(task, revision)
  }

  function getTask(taskId) {
    return taskHistory.value.find((task) => task.id === taskId) || null
  }

  async function removeTask(taskId) {
    const revision = accountRevision.value
    await deleteImageGenerationTask(taskId)
    if (revision !== accountRevision.value) return
    taskHistory.value = taskHistory.value.filter((task) => task.id !== taskId)
  }

  return {
    taskHistory,
    loading,
    accountRevision,
    loadHistory,
    upsertTask,
    refreshTask,
    getTask,
    removeTask,
  }
})
