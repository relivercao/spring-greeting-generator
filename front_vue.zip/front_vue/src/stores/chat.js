import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { useAuthStore } from './auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'

const STORAGE_KEY = 'agent_chat_history'

function loadHistory(storageKey) {
  if (!storageKey) return []
  try {
    const value = JSON.parse(localStorage.getItem(storageKey) || '[]')
    return Array.isArray(value) ? value : []
  } catch {
    return []
  }
}

function persistHistory(history, storageKey) {
  if (!storageKey) return
  const toSave = history.slice(0, 100).map(s => ({
    ...s,
    messages: Array.isArray(s.messages) ? s.messages.slice(-200) : [],
  }))
  localStorage.setItem(storageKey, JSON.stringify(toSave))
}

export const useChatStore = defineStore('chat', () => {
  const auth = useAuthStore()
  const storageKey = computed(() => {
    const identity = accountIdentity(auth)
    return identity ? `${STORAGE_KEY}:${identity}` : null
  })
  const history = ref(loadHistory(storageKey.value))

  // Switch the visible conversation set synchronously with the account.
  watch(storageKey, (key, previousKey) => {
    persistHistory(history.value, previousKey)
    history.value = loadHistory(key)
  }, { flush: 'sync' })

  // Persist: automatically write to localStorage when history changes
  watch(
    history,
    (val) => {
      // Only keep the most recent 100 sessions to avoid overflowing localStorage
      persistHistory(val, storageKey.value)
    },
    { deep: true }
  )

  function getAgentSessions(agentId) {
    return history.value.filter(h => h.agentId === agentId)
  }

  function findSession(sessionId) {
    return history.value.find(h => h.id === sessionId) || null
  }

  function createSession(agent) {
    const session = {
      id: `sess_${Date.now()}`,
      title: 'New Chat',
      agentId: agent.id,
      agentName: agent.name,
      time: 'just now',
      messages: [],
    }
    history.value.unshift(session)
    return session
  }

  function deleteSession(sessionId) {
    const idx = history.value.findIndex(h => h.id === sessionId)
    if (idx !== -1) history.value.splice(idx, 1)
  }

  function addMessage(sessionId, message) {
    const session = findSession(sessionId)
    if (session) session.messages.push(message)
  }

  function updateMessage(sessionId, messageId, patch) {
    const session = findSession(sessionId)
    if (!session) return
    const msg = session.messages.find(m => m.id === messageId)
    if (msg) Object.assign(msg, patch)
  }

  function renameSession(sessionId, title) {
    const session = findSession(sessionId)
    if (session) {
      session.title = title
      session.time = new Date().toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    }
  }

  function clearMessages(sessionId) {
    const session = findSession(sessionId)
    if (session) session.messages = []
  }

  function deleteMessage(sessionId, messageId) {
    const session = findSession(sessionId)
    if (!session) return
    const idx = session.messages.findIndex(m => m.id === messageId)
    if (idx !== -1) session.messages.splice(idx, 1)
  }

  return {
    history,
    getAgentSessions,
    findSession,
    createSession,
    deleteSession,
    addMessage,
    updateMessage,
    renameSession,
    clearMessages,
    deleteMessage,
  }
})
