import { defineStore } from 'pinia'
import { ref, watch } from 'vue'

const STORAGE_KEY = 'agent_workspace_state'

function loadState() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')
  } catch {
    return {}
  }
}

export const useWorkspaceStore = defineStore('workspace', () => {
  const saved = loadState()

  // Each agentId saves its state independently
  // Structure: { [agentId]: { uploadedFileName, uploadedFileSize, resultContent, unittestResult, showCompile } }
  const states = ref(saved)

  watch(states, (val) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(val))
  }, { deep: true })

  function getState(agentId) {
    return states.value[agentId] || null
  }

  function saveState(agentId, patch) {
    states.value[agentId] = { ...(states.value[agentId] || {}), ...patch }
  }

  function clearState(agentId) {
    delete states.value[agentId]
    states.value = { ...states.value }
  }

  return { getState, saveState, clearState }
})
