import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { useAuthStore } from './auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'

const STORAGE_KEY = 'agent_unittest_history'
const MAX_TASKS = 50 // Maximum 50 task history entries

function loadHistory(storageKey) {
  if (!storageKey) return []
  try {
    const value = JSON.parse(localStorage.getItem(storageKey) || '[]')
    return Array.isArray(value) ? value : []
  } catch {
    return []
  }
}

export const useUnittestStore = defineStore('unittest', () => {
  const auth = useAuthStore()
  const storageKey = computed(() => {
    const identity = accountIdentity(auth)
    return identity ? `${STORAGE_KEY}:${identity}` : null
  })
  const taskHistory = ref(loadHistory(storageKey.value))

  watch(storageKey, (key, previousKey) => {
    if (previousKey) localStorage.setItem(previousKey, JSON.stringify(taskHistory.value))
    taskHistory.value = loadHistory(key)
  }, { flush: 'sync' })

  // Persist to localStorage
  watch(taskHistory, (val) => {
    if (storageKey.value) localStorage.setItem(storageKey.value, JSON.stringify(val))
  }, { deep: true })

  /**
   * Add task to history
  * @param {Object} task - Task object
   * @param {string} task.id - Task ID
   * @param {string} task.title - Task title (filename)
   * @param {string} task.status - Task status (running/completed/failed/cancelled)
   * @param {number} task.progress - Progress (0-100)
   * @param {Object} task.result - Task result
   * @param {string} task.time - Creation time
   */
  function addTask(task) {
    const existing = taskHistory.value.find(t => t.id === task.id)
    if (existing) {
      // Update existing task
      Object.assign(existing, task)
    } else {
      // Add new task to the beginning
      taskHistory.value.unshift({
        id: task.id,
        title: task.title,
        status: task.status || 'running',
        progress: task.progress || 0,
        result: task.result || null,
        liveNodes: Array.isArray(task.liveNodes) ? task.liveNodes : [],
        currentStage: task.currentStage || '',
        statusMessage: task.statusMessage || '',
        error: task.error || null,
        time: task.time || new Date().toLocaleString(),
        agentId: 2, // Unittest agent ID
        fileMeta: task.fileMeta || null,
        selectedFileSnapshot: task.selectedFileSnapshot || null,
        outputDir: task.outputDir || '',
        selectedFramework: task.selectedFramework || undefined,
        selectedLayer: task.selectedLayer || undefined,
        selectedPlatform: task.selectedPlatform || undefined,
        updatedAt: task.updatedAt || new Date().toISOString(),
      })
    }

    // Enforce history size limit
    if (taskHistory.value.length > MAX_TASKS) {
      taskHistory.value = taskHistory.value.slice(0, MAX_TASKS)
    }
  }

  /**
   * Update task status
   */
  function updateTask(taskId, updates) {
    const task = taskHistory.value.find(t => t.id === taskId)
    if (task) {
      Object.assign(task, updates)
    }
  }

  /**
   * Delete task
   */
  function deleteTask(taskId) {
    const index = taskHistory.value.findIndex(t => t.id === taskId)
    if (index !== -1) {
      taskHistory.value.splice(index, 1)
    }
  }

  /**
   * Get task
   */
  function getTask(taskId) {
    return taskHistory.value.find(t => t.id === taskId)
  }

  /**
   * Clear all history
   */
  function clearHistory() {
    taskHistory.value = []
  }

  return {
    taskHistory,
    addTask,
    updateTask,
    deleteTask,
    getTask,
    clearHistory,
  }
})
