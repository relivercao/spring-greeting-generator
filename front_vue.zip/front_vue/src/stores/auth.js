import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { apiLogin, apiRegister, apiGetProfile } from '../api/auth.js'

const DEFAULT_USER = Object.freeze({
  name: 'User',
  email: '',
  balance: 0,
  total_recharged: 0,
  is_admin: false,
})

function getStoredValue(key) {
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}

function getStoredUser() {
  const rawUser = getStoredValue('user')
  if (!rawUser) return { ...DEFAULT_USER }

  try {
    const storedUser = JSON.parse(rawUser)
    if (storedUser && typeof storedUser.name === 'string' && storedUser.name.trim()) {
      // Merge over the defaults so users persisted before the balance fields
      // exist still expose balance / total_recharged / is_admin.
      return { ...DEFAULT_USER, ...storedUser }
    }
  } catch {
    // Fall back to the default user when browser storage contains invalid JSON.
  }
  return { ...DEFAULT_USER }
}

export const useAuthStore = defineStore('auth', () => {
  // ── state ──
  const token = ref(getStoredValue('token') || '')
  const refreshToken = ref(getStoredValue('refresh_token') || '')
  const user  = ref(getStoredUser())
  const guest = ref(!!getStoredValue('guest'))

  // ── getters ──
  const isLoggedIn  = computed(() => !!token.value)
  const isGuest     = computed(() => guest.value)
  const hasAccess   = computed(() => isLoggedIn.value || isGuest.value)
  const displayName = computed(() => user.value?.name || 'User')
  const isAdmin     = computed(() => !!user.value?.is_admin)

  // ── actions ──
  async function login(username, password) {
    const data = await apiLogin(username, password)
    // Login response may embed the full user object; pick up the payment
    // fields when the backend provides them, fall back to token defaults.
    const profile = data && typeof data.user === 'object' && data.user ? data.user : {}
    token.value = data.access_token
    refreshToken.value = data.refresh_token || ''
    user.value  = {
      name: data.username || profile.username || username,
      email: data.email || profile.email || '',
      balance: typeof profile.balance === 'number' ? profile.balance : 0,
      total_recharged: typeof profile.total_recharged === 'number' ? profile.total_recharged : 0,
      is_admin: !!profile.is_admin,
    }
    localStorage.setItem('token', token.value)
    if (refreshToken.value) localStorage.setItem('refresh_token', refreshToken.value)
    else localStorage.removeItem('refresh_token')
    localStorage.setItem('user', JSON.stringify(user.value))
    // Clear stale guest data
    guest.value = false
    localStorage.removeItem('guest')
    return user.value
  }

  async function register(username, email, password, options = {}) {
    await apiRegister(username, email, password, options)
  }

  // Fetch the authoritative profile (GET /v1/auth/me) and patch the local
  // user so balance / total_recharged / is_admin stay fresh after recharges.
  async function fetchProfile() {
    if (!token.value) return null
    const data = await apiGetProfile()
    const profile = data && typeof data.user === 'object' && data.user ? data.user : data
    user.value = {
      ...user.value,
      ...profile,
      name: profile.username || user.value.name,
      balance: typeof profile.balance === 'number' ? profile.balance : user.value.balance,
      total_recharged: typeof profile.total_recharged === 'number'
        ? profile.total_recharged
        : user.value.total_recharged,
      is_admin: profile.is_admin === undefined ? user.value.is_admin : !!profile.is_admin,
    }
    localStorage.setItem('user', JSON.stringify(user.value))
    return user.value
  }

  function enterGuest() {
    token.value = ''
    refreshToken.value = ''
    guest.value = true
    user.value  = { ...DEFAULT_USER, name: 'Guest', isGuest: true }
    localStorage.removeItem('token')
    localStorage.removeItem('refresh_token')
    localStorage.setItem('guest', '1')
    localStorage.setItem('user', JSON.stringify(user.value))
  }

  function clearSession() {
    token.value = ''
    refreshToken.value = ''
    user.value  = { ...DEFAULT_USER }
    guest.value = false
    localStorage.removeItem('token')
    localStorage.removeItem('refresh_token')
    localStorage.removeItem('user')
    localStorage.removeItem('guest')
  }

  function logout() {
    clearSession()
    // Notify the router listener so the app navigates to the login page.
    window.dispatchEvent(new CustomEvent('auth:logout'))
  }

  return {
    token, refreshToken, user, guest,
    isLoggedIn, isGuest, hasAccess, displayName, isAdmin,
    login, register, fetchProfile, enterGuest, clearSession, logout,
  }
})
