/**
 * @file driver.js
 * @author zhangjian
 * @brief Pinia store for Driver Agent task history and refresh persistence.
 * @version 1.0
 * @date 2026-07-21
 * @copyright Copyright (c) 2026 relivercao@gmail.com
 * All rights reserved.
 *
 * This store keeps Driver Agent task summaries available across page refreshes.
 * It is intentionally separate from unittest/chat stores so Driver task
 * lifecycle changes do not affect existing PMI frontend capabilities.
 */
import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { useAuthStore } from './auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'

// PMI localStorage key for Driver task history. Keep the agent_* prefix aligned with existing stores.
const STORAGE_KEY = 'agent_driver_history'
// Cap persisted history to avoid unbounded browser storage growth.
const MAX_TASKS = 100
const FALLBACK_MAX_TASKS = 25
const STORAGE_RETRY_LIMITS = [MAX_TASKS, 50, FALLBACK_MAX_TASKS]

// Load persisted history defensively; malformed localStorage data should not block app startup.
function loadHistory(storageKey) {
  if (!storageKey) return []
  try {
    const history = JSON.parse(localStorage.getItem(storageKey) || '[]')
    return createPersistentHistory(Array.isArray(history) ? history : [])
  } catch {
    return []
  }
}

function createArtifactSummary(artifact) {
  if (!artifact || typeof artifact !== 'object') return artifact
  return {
    name: artifact.name,
    type: artifact.type || artifact.artifact_type,
    artifact_type: artifact.artifact_type || artifact.type,
    language: artifact.language,
    size: artifact.size ?? (typeof artifact.content === 'string' ? artifact.content.length : undefined),
    contentAvailable: typeof artifact.content === 'string' && artifact.content.length > 0,
  }
}

function createPersistentTask(task) {
  if (!task || typeof task !== 'object') return task
  const driverState = task.driverState && typeof task.driverState === 'object'
    ? { ...task.driverState }
    : task.driverState
  if (driverState && typeof driverState === 'object') {
    delete driverState.artifacts
    delete driverState.generatedCodeTabs
  }
  return {
    ...task,
    driverState,
    artifacts: Array.isArray(task.artifacts)
      ? task.artifacts.map(createArtifactSummary)
      : [],
  }
}

function createPersistentHistory(history, limit = MAX_TASKS) {
  if (!Array.isArray(history)) return []
  return history.slice(0, limit).map(createPersistentTask)
}

function persistHistory(history, storageKey) {
  if (!storageKey) return
  for (const limit of STORAGE_RETRY_LIMITS) {
    try {
      localStorage.setItem(storageKey, JSON.stringify(createPersistentHistory(history, limit)))
      return
    } catch (err) {
      console.warn(`[DriverStore] Could not persist ${limit} driver task(s):`, err)
    }
  }
}

export const useDriverStore = defineStore('driver', () => {
  const auth = useAuthStore()
  const storageKey = computed(() => {
    const identity = accountIdentity(auth)
    return identity ? `${STORAGE_KEY}:${identity}` : null
  })
  const taskHistory = ref(loadHistory(storageKey.value))

  // Unscoped legacy history has no reliable owner. Preserve it without exposing it.
  watch(storageKey, (key, previousKey) => {
    persistHistory(taskHistory.value, previousKey)
    taskHistory.value = loadHistory(key)
  }, { flush: 'sync' })

  // Persist task summaries whenever Driver task state changes.
  watch(taskHistory, (val) => {
    persistHistory(val, storageKey.value)
  }, { deep: true })

  // Add new tasks or merge updates for restored/running Driver sessions.
  function addTask(task) {
    if (!task?.id) {
      console.warn('[DriverStore] Ignoring driver task without id')
      return
    }
    const existing = taskHistory.value.find(t => t.id === task.id)
    if (existing) {
      Object.assign(existing, task)
    } else {
      taskHistory.value.unshift({
        id: task.id,
        title: task.title || 'New Driver Task',
        status: task.status || 'idle',
        progress: task.progress || 0,
        result: task.result || null,
        time: task.time || new Date().toLocaleString(),
        agentId: 3,
        fileMeta: task.fileMeta || null,
        chatMessages: task.chatMessages || [],
        serialLogs: task.serialLogs || [],
        driverState: task.driverState || {},
        updatedAt: task.updatedAt || new Date().toISOString(),
        sessionId: task.sessionId || null,
        sourceIds: task.sourceIds || [],
        artifacts: task.artifacts || [],
        knowledgeBaseFilesMeta: task.knowledgeBaseFilesMeta || [],
        referenceFilesMeta: task.referenceFilesMeta || [],
      })
    }

    if (taskHistory.value.length > MAX_TASKS) {
      taskHistory.value = taskHistory.value.slice(0, MAX_TASKS)
    }
  }

  function updateTask(taskId, updates) {
    if (!taskId) {
      console.warn('[DriverStore] Ignoring driver task update without id')
      return
    }
    const task = taskHistory.value.find(t => t.id === taskId)
    if (task) {
      Object.assign(task, updates)
    }
  }

  function deleteTask(taskId) {
    const index = taskHistory.value.findIndex(t => t.id === taskId)
    if (index !== -1) {
      taskHistory.value.splice(index, 1)
    }
  }

  function getTask(taskId) {
    return taskHistory.value.find(t => t.id === taskId)
  }

  function clearHistory() {
    taskHistory.value = []
  }

  return {
    taskHistory,
    addTask,
    updateTask,
    deleteTask,
    getTask,
    clearHistory,
  }
})
