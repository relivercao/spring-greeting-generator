import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { useAuthStore } from './auth.js'
import { accountIdentity } from '../utils/accountIdentity.js'

const STORAGE_KEY = 'agent_batch_test_history'
const DISMISSED_STORAGE_KEY = 'agent_batch_test_dismissed'
const MAX_TASKS = 100
const MAX_DISMISSED = 1000
const BATCH_TEST_AGENT_ID = 2

function loadHistory(storageKey) {
  if (!storageKey) return []
  try {
    const data = localStorage.getItem(storageKey)
    if (data && data !== '[]') {
      const parsed = JSON.parse(data)
      return Array.isArray(parsed) ? parsed.map(normalizeTask).filter(Boolean) : []
    }
  } catch (err) {
    console.warn('[BatchTestStore] Failed to parse localStorage:', err)
  }
  return []
}

function loadDismissed(storageKey) {
  if (!storageKey) return new Set()
  try {
    const data = localStorage.getItem(storageKey)
    const parsed = data ? JSON.parse(data) : []
    if (Array.isArray(parsed)) {
      return new Set(parsed.filter(id => typeof id === 'string' && id))
    }
  } catch (err) {
    console.warn('[BatchTestStore] Failed to parse dismissed list:', err)
  }
  return new Set()
}

function persistDismissed(ids, storageKey) {
  if (!storageKey) return
  try {
    let list = [...ids]
    if (list.length > MAX_DISMISSED) list = list.slice(list.length - MAX_DISMISSED)
    localStorage.setItem(storageKey, JSON.stringify(list))
  } catch (err) {
    console.error('[BatchTestStore] Failed to save dismissed list:', err)
  }
}

function normalizeTask(task) {
  if (!task || !task.id) return null
  return {
    ...task,
    id: task.id,
    title: task.title || 'Batch Test Task',
    status: task.status || 'idle',
    progress: task.progress || 0,
    result: task.result || null,
    time: task.time || new Date().toLocaleString(),
    agentId: BATCH_TEST_AGENT_ID,
    selectedFiles: task.selectedFiles || [],
    completedCount: task.completedCount || 0,
    failedCount: task.failedCount || 0,
    totalCount: task.totalCount || 0,
    updatedAt: task.updatedAt || new Date().toISOString(),
  }
}

export const useBatchTestStore = defineStore('batchTest', () => {
  const auth = useAuthStore()
  const account = computed(() => accountIdentity(auth))
  const storageKey = computed(() => account.value ? `${STORAGE_KEY}:${account.value}` : null)
  const dismissedStorageKey = computed(() => account.value ? `${DISMISSED_STORAGE_KEY}:${account.value}` : null)
  const taskHistory = ref(loadHistory(storageKey.value))
  // Server batch ids the user removed from the sidebar.  The backend keeps
  // every batch durably and has no delete endpoint, so these are remembered
  // locally to stop the history sync from resurrecting dismissed cards.
  const dismissedBatchIds = ref(loadDismissed(dismissedStorageKey.value))

  watch(account, (identity, previousIdentity) => {
    if (previousIdentity) {
      try {
        localStorage.setItem(`${STORAGE_KEY}:${previousIdentity}`, JSON.stringify(taskHistory.value))
      } catch (error) {
        console.error('[BatchTestStore] Failed to save account history:', error)
      }
      persistDismissed(dismissedBatchIds.value, `${DISMISSED_STORAGE_KEY}:${previousIdentity}`)
    }
    taskHistory.value = loadHistory(identity ? `${STORAGE_KEY}:${identity}` : null)
    dismissedBatchIds.value = loadDismissed(identity ? `${DISMISSED_STORAGE_KEY}:${identity}` : null)
  }, { flush: 'sync' })

  watch(taskHistory, (val) => {
    try {
      if (storageKey.value) localStorage.setItem(storageKey.value, JSON.stringify(val))
    } catch (err) {
      console.error('[BatchTestStore] Failed to save to localStorage:', err)
    }
  }, { deep: true })

  function addTask(task) {
    const normalized = normalizeTask(task)
    if (!normalized) {
      console.warn('[BatchTestStore] addTask called without task.id, ignoring')
      return
    }

    const existing = taskHistory.value.find(t => t.id === normalized.id)
    if (existing) {
      Object.assign(existing, normalized)
    } else {
      taskHistory.value.unshift(normalized)
    }

    if (taskHistory.value.length > MAX_TASKS) {
      taskHistory.value = taskHistory.value.slice(0, MAX_TASKS)
    }
  }

  function updateTask(taskId, updates) {
    const task = taskHistory.value.find(t => t.id === taskId)
    if (task) {
      Object.assign(task, normalizeTask({ ...task, ...updates, id: taskId }))
    }
  }

  function deleteTask(taskId) {
    const index = taskHistory.value.findIndex(t => t.id === taskId)
    if (index !== -1) {
      const task = taskHistory.value[index]
      // Removing a card also dismisses its server batch so the next sync
      // does not re-add it from the durable backend list.
      if (task?.batchTaskId) {
        dismissBatch(task.batchTaskId)
      }
      taskHistory.value.splice(index, 1)
    }
  }

  function dismissBatch(batchTaskId) {
    if (!batchTaskId || dismissedBatchIds.value.has(batchTaskId)) return
    const next = new Set(dismissedBatchIds.value)
    next.add(batchTaskId)
    dismissedBatchIds.value = next
    persistDismissed(next, dismissedStorageKey.value)
  }

  function isDismissed(batchTaskId) {
    return Boolean(batchTaskId) && dismissedBatchIds.value.has(batchTaskId)
  }

  function getTask(taskId) {
    return taskHistory.value.find(t => t.id === taskId)
  }

  /**
   * Normalize history after a backend sync:
   * - discard duplicate cards that point at the same server batch (a
   *   sync-created `batch_test_task_*` copy loses to the original local card)
   * - order the server-backed cards to match `batchTaskIds` (the server's
   *   newest-first order); local-only cards stay above them and cards linked
   *   to batches outside the fetched window stay below them.
   */
  function applyServerOrder(batchTaskIds) {
    const order = new Map(batchTaskIds.map((id, index) => [id, index]))
    const localOnly = []
    const belowWindow = []
    const byBatch = new Map()

    taskHistory.value.forEach(task => {
      if (!task.batchTaskId) {
        localOnly.push(task)
        return
      }
      const prev = byBatch.get(task.batchTaskId)
      if (!prev || (String(prev.id).startsWith('batch_test_task_') && !String(task.id).startsWith('batch_test_task_'))) {
        byBatch.set(task.batchTaskId, task)
      }
    })

    const ordered = []
    order.forEach((_index, batchTaskId) => {
      const task = byBatch.get(batchTaskId)
      if (task) ordered.push(task)
    })
    byBatch.forEach((task, batchTaskId) => {
      if (!order.has(batchTaskId)) belowWindow.push(task)
    })

    taskHistory.value = [...localOnly, ...ordered, ...belowWindow]
  }

  function clearHistory() {
    taskHistory.value = []
  }

  return {
    taskHistory,
    addTask,
    updateTask,
    deleteTask,
    getTask,
    applyServerOrder,
    isDismissed,
    clearHistory,
  }
})
