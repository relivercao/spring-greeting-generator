# AI Assistant Platform - Project Documentation

## Project Overview

AI Assistant Platform is a frontend application for an intelligent assistant platform built with Vue 3 + Vite. It provides various AI-assisted features, including code generation, test generation, chat conversations, and more.

## Technology Stack

- **Frontend Framework**: Vue 3 + Vite
- **State Management**: Pinia
- **Routing**: Vue Router
- **UI Component Library**: Element Plus
- **Build Tool**: Vite
- **Code Quality**: ESLint + Prettier
- **Deployment Mode**: Local development + Docker

## Core Features

- **AI Chat**: Communicate with AI assistants to get programming help
- **Code Generation**: Generate code snippets based on requirements
- **Unit Test Generation**: Generate unit tests for existing code
- **RAG Knowledge Base**: Question-answer system based on knowledge base
- **Multi-model Support**: Support for multiple large language models

## Project Structure

```
E:\ma_code\ai_coding_agent\front_vue/
├── config/                 # Configuration files
│   ├── .env.development    # Development environment variables
│   ├── .env.production     # Production environment variables
│   ├── .prettierrc         # Prettier config
│   ├── eslint.config.js    # ESLint config
│   └── vite.config.js      # Vite config
├── docker/                 # Docker-related files
│   ├── Dockerfile          # Docker build file
│   ├── docker-compose.yml  # Docker Compose config
│   ├── nginx.conf          # Nginx config
│   └── .dockerignore       # Docker ignore file
├── docs/                   # Project documentation
│   └── DEPLOY.md           # Deployment documentation
├── src/                    # Source code
│   ├── api/                # API calls
│   ├── components/         # Components
│   ├── router/             # Router
│   ├── stores/             # Pinia state management
│   ├── views/              # Pages
│   ├── assets/             # Static resources
│   ├── utils/              # Utility functions
│   ├── styles/             # Style files
│   ├── App.vue             # Root component
│   └── main.js             # Entry file
├── index.html              # Main HTML file
├── package.json            # Project config
├── package-lock.json       # Dependency lock file
└── setup.bat               # Project initialization script
```

---

## Option 1: Local Development Mode (Daily Use)

> Suitable for daily development and debugging, code changes take effect immediately

### Startup Commands

```bash
cd E:\ma_code\ai_coding_agent\front_vue
npm install     # Install dependencies on first run
npm run dev
```

### Quick Start (Recommended)

Use the `setup.bat` script in the project root directory. It automatically checks Node.js installation, installs dependencies, and starts the development server:

```bash
cd E:\ma_code\ai_coding_agent\front_vue
setup.bat
```

### Access Addresses

| Address | Description |
|---------|-------------|
| `http://localhost:5173` | Local access |
| `http://10.84.193.132:5173` | Access from other devices on same WiFi |

### Stop Service

Press `Ctrl + C` in the terminal.

---

## Option 2: Docker Deployment (Sharing/Production)

> Suitable for packaging images for others to deploy, or simulating production environment

### Prerequisites

- Install [Docker Desktop](https://www.docker.com/products/docker-desktop/)
- Backend service must be running normally on target machine (port 8000)

---

### 2.1 Run Docker Locally

```bash
cd E:\ma_code\ai_coding_agent\front_vue

# Step 1: Build image
docker build -t ai-assistant-platform:latest .

# Step 2: Start container (Windows/Mac)
docker run -d -p 80:80 --name ai-app ai-assistant-platform:latest

# Step 2: Start container (Linux requires --add-host)
docker run -d -p 80:80 \
  --add-host=host.docker.internal:host-gateway \
  --name ai-app \
  ai-assistant-platform:latest
```

**Access Address:** `http://localhost`

---

### 2.2 Package Image for Others to Use

```bash
cd E:\ma_code\ai_coding_agent\front_vue

# Step 1: Build image
docker build -t ai-assistant-platform:latest .

# Step 2: Export as file (approx. 50-80MB)
docker save ai-assistant-platform:latest -o ai-platform.tar
```

Send `ai-platform.tar` to the other party via USB drive or cloud storage.

---

### 2.3 Deploy on Another Computer

```bash
# Step 1: Import image
docker load -i ai-platform.tar

# Step 2: Start container (Windows/Mac)
docker run -d -p 80:80 --name ai-app ai-assistant-platform:latest

# Step 2: Start container (Linux)
docker run -d -p 80:80 \
  --add-host=host.docker.internal:host-gateway \
  --name ai-app \
  ai-assistant-platform:latest
```

**Access Address:** `http://localhost` or `http://<target-computer-IP>`

---

### Common Docker Management Commands

```bash
# View running status
docker ps

# View logs
docker logs ai-app

# Stop container
docker stop ai-app

# Delete container
docker rm ai-app

# Update image (redeploy after code changes)
docker stop ai-app
docker rm ai-app
docker build -t ai-assistant-platform:latest .
docker run -d -p 80:80 --name ai-app ai-assistant-platform:latest
```

---

## Comparison of Two Options

| Comparison Item | Development Mode `npm run dev` | Docker Deployment |
|-----------------|-------------------------------|-----------------|
| Access Port | 5173 | 80 |
| Code Changes | Take effect immediately | Need to rebuild |
| Deploy to Another Computer | Need to install Node.js | Only need Docker |
| Recommended Scenario | Daily development | Delivery/Demo |

---

## Backend Connection Notes

Frontend accesses backend via `/api` path. Nginx automatically forwards requests:

```
Frontend Request
    |
Nginx (inside container)
    |
http://host.docker.internal:8000/auth/login (backend on host machine)
```

**Please ensure backend service is running normally on target machine (port 8000) for frontend login to work properly.**
