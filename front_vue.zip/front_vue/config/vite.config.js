import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import { resolve } from 'path'

export default defineConfig(({ mode }) => {
  // Load environment variables
  const env = loadEnv(mode, resolve(__dirname, '../'), '')

  return {
  resolve: {
    alias: {
      '@': resolve(__dirname, '../src')
    }
  },
  plugins: [
    vue(),
    // Element Plus on-demand auto-import (components + API, reduces bundle size by ~60%)
    AutoImport({
      resolvers: [ElementPlusResolver()],
    }),
    Components({
      resolvers: [ElementPlusResolver()],
    }),
  ],
  server: {
    port: 5173,
    host: '0.0.0.0',
    proxy: {
      // All /api requests go to backend service (port 8000)
      '/api': {
        target: env.VITE_BACKEND_URL || 'http://127.0.0.1:8000',
        changeOrigin: true,
        timeout: 0,
        proxyTimeout: 0,
      }
    }
  },
  build: {
    // Warn when chunk exceeds 500KB, for future optimization
    chunkSizeWarningLimit: 500,
    rollupOptions: {
      output: {
        // Manual code splitting: separate Vue ecosystem from business code, leverage browser caching
        manualChunks: {
          'vue-vendor': ['vue', 'vue-router', 'pinia'],
        }
      }
    }
  }
  }
})
