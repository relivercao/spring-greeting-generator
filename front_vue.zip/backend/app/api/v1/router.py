"""
@file router.py
@author caoshwen
@brief API v1 router aggregating all endpoint sub-routers.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from fastapi import APIRouter

from app.api.v1.endpoints import (
    admin_payment,
    admin_redeem,
    admin_users,
    model_management,
    usage_reporting,
    agent_generator,
    agents,
    auth,
    bedrock,
    bugfix,
    batch_unittest,
    build,
    chat,
    cad,
    connected_apps,
    debug,
    driver,
    driver_docling,
    email_settings,
    event_center,
    feishu,
    health,
    image_generation,
    image_generation_settings,
    knowledge_base,
    notifications,
    payment,
    payment_webhook,
    project_detection,
    review,
    service,
    skill_market,
    skill_submissions,
    sessions,
    settings,
    tasks,
    unittest,
    unittest_refactored,
    websocket,
    version,
)

api_router = APIRouter()
api_router.include_router(model_management.router, tags=["Model Catalog"])
api_router.include_router(model_management.admin_router, tags=["Admin Models"])
api_router.include_router(usage_reporting.router, tags=["Usage Reporting"])

# Authentication
api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])

# Task management
api_router.include_router(tasks.router, prefix="/tasks", tags=["Task Management"])

# Session management
api_router.include_router(sessions.router, prefix="/sessions", tags=["Session Management"])

# Agent info
api_router.include_router(agents.router, prefix="/agents", tags=["Agent Info"])
api_router.include_router(agent_generator.router, tags=["Agent Generator"])
api_router.include_router(skill_market.router, prefix="/skill-market", tags=["Skill Market"])
api_router.include_router(skill_submissions.router, prefix="/skill-market", tags=["Skill Submissions"])

# Agent endpoints
api_router.include_router(connected_apps.router, tags=["Connected Applications"])
api_router.include_router(feishu.router, tags=["Connected Applications"])
api_router.include_router(event_center.router)
api_router.include_router(unittest.router, tags=["UnitTest"])
api_router.include_router(batch_unittest.router, tags=["Batch Unit-Test"])
api_router.include_router(unittest_refactored.router, prefix="/unittest-v2", tags=["UnitTest-V2-Refactored"])
api_router.include_router(driver.router, tags=["Driver"])
api_router.include_router(driver_docling.router, tags=["Driver Docling"])
api_router.include_router(build.router, tags=["Build"])
api_router.include_router(bugfix.router, tags=["BugFix"])
api_router.include_router(debug.router, tags=["Debug"])
api_router.include_router(review.router, tags=["CodeReview"])
api_router.include_router(chat.router, tags=["Chat"])
api_router.include_router(cad.router, prefix="/cad", tags=["CAD Agent"])
api_router.include_router(image_generation.router, tags=["Image Generation"])
api_router.include_router(knowledge_base.router, tags=["Knowledge Base"])
api_router.include_router(notifications.router, tags=["Notifications"])
api_router.include_router(version.router, tags=["Version"])

# System settings
api_router.include_router(settings.router, tags=["System Settings"])
api_router.include_router(email_settings.router, tags=["System Settings"])
api_router.include_router(image_generation_settings.router, tags=["System Settings"])

# Bedrock AWS SSO endpoints
api_router.include_router(bedrock.router, prefix="/bedrock", tags=["Bedrock"])

# WebSocket endpoints
api_router.include_router(websocket.router, tags=["WebSocket"])

# Operations endpoints (health check / metrics)
api_router.include_router(health.router, tags=["Operations"])

# Service management endpoints (for portable version service shutdown)
api_router.include_router(service.router, tags=["Service Management"])

# Project detection endpoints
api_router.include_router(project_detection.router, prefix="/project", tags=["Project Detection"])

# Payment (user-facing checkout + external gateway webhook)
api_router.include_router(payment.router, prefix="/payment", tags=["Payment"])
api_router.include_router(payment_webhook.router, tags=["Payment Webhook"])

# Admin management (orders/config/plans/providers, users, redeem codes)
api_router.include_router(admin_payment.router, prefix="/admin/payment", tags=["Admin Payment"])
api_router.include_router(admin_users.router, prefix="/admin/users", tags=["Admin Users"])
api_router.include_router(admin_redeem.router, prefix="/admin/redeem-codes", tags=["Admin Redeem Codes"])
