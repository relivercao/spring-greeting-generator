"""Account-scoped event routing, source administration, and delivery gateway."""

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_optional_user_from_request
from app.models.agent_event import AgentEvent, EventWebhookSource
from app.models.user import User
from app.orchestration.event_agents import catalog as agent_catalog
from app.orchestration.event_routing import route_event
from app.schemas.agent_event import (
    EventInput,
    EventPreview,
    RoutingPolicyInput,
    WebhookSourceInput,
    WebhookSourceState,
)
from app.services.app_connections import AppConnectionError
from app.services.event_dispatch import EventDispatcher
from app.services.event_policy import load_policy, save_policy
from app.services.event_store import serialize_event
from app.services.event_webhooks import MAX_WEBHOOK_BYTES, create_source, rotate_secret, source_view, verify_delivery

router = APIRouter(prefix="/event-center", tags=["Event Center"])


async def get_event_user(request: Request) -> dict:
    user = get_optional_user_from_request(request, anonymous_id="")
    if not user["id"]:
        raise HTTPException(401, "An authenticated access token is required.")
    return user


async def _owner(db: AsyncSession, user: dict) -> str:
    account = await db.get(User, user["id"])
    if account is None or not account.is_active:
        raise HTTPException(401, "An active platform account is required.")
    return account.id


def _worker(request: Request) -> EventDispatcher:
    dispatcher = getattr(request.app.state, "event_dispatcher", None)
    if dispatcher is None:
        raise HTTPException(503, "The event execution service is unavailable.")
    return dispatcher


@router.get("/catalog")
async def get_catalog(user=Depends(get_event_user), db: AsyncSession = Depends(get_db)):
    await _owner(db, user)
    return {"agents": agent_catalog(), "sources": ["api", "feishu", "webhook"]}


@router.get("/routing")
async def get_routing(user=Depends(get_event_user), db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    return (await load_policy(db, user_id)).model_dump(mode="json")


@router.put("/routing")
async def put_routing(body: RoutingPolicyInput, user=Depends(get_event_user),
                      db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    try:
        return await save_policy(db, user_id, body)
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.post("/preview")
async def preview_event(body: EventPreview, user=Depends(get_event_user),
                        db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    policy = body.policy or await load_policy(db, user_id)
    decision = route_event(body.event, body.source, body.source_id, policy)
    if decision["agent"]:
        from app.orchestration.event_agents import missing_inputs
        decision["requirements"] = missing_inputs(decision["agent"], body.event)
    else:
        decision["requirements"] = []
    return decision


@router.post("/events", status_code=202)
async def submit_event(body: EventInput, request: Request, user=Depends(get_event_user),
                       db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    dispatcher = _worker(request)
    try:
        return await dispatcher.submit(user_id, "api", "", body)
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.get("/events")
async def list_events(request: Request, user=Depends(get_event_user), db: AsyncSession = Depends(get_db),
                      limit: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0),
                      status: str | None = Query(None, pattern=r"^(queued|running|completed|failed|needs_input|ignored|cancelled|interrupted)$")):
    user_id = await _owner(db, user)
    query = select(AgentEvent).where(AgentEvent.user_id == user_id)
    if status:
        query = query.where(AgentEvent.status == status)
    records = await db.scalars(query.order_by(AgentEvent.created_at.desc()).offset(offset).limit(limit))
    worker = getattr(request.app.state, "event_worker", None)
    return {"items": [serialize_event(item) for item in records], "limit": limit, "offset": offset,
            "runtime": worker.snapshot() if worker else {"status": "unavailable"}}


@router.get("/events/{event_id}")
async def get_event(event_id: str, user=Depends(get_event_user), db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    record = await db.scalar(select(AgentEvent).where(AgentEvent.id == event_id, AgentEvent.user_id == user_id))
    if record is None:
        raise HTTPException(404, "Event not found.")
    return serialize_event(record, detail=True)


@router.get("/sources")
async def list_webhook_sources(user=Depends(get_event_user), db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    records = await db.scalars(select(EventWebhookSource).where(EventWebhookSource.user_id == user_id)
                               .order_by(EventWebhookSource.created_at.desc()))
    return {"items": [source_view(item) for item in records]}


@router.post("/sources", status_code=201)
async def create_webhook_source(body: WebhookSourceInput, response: Response, user=Depends(get_event_user),
                                db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    response.headers["Cache-Control"] = "no-store"
    try:
        return await create_source(db, user_id, body.name)
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.put("/sources/{source_id}")
async def update_webhook_source(source_id: str, body: WebhookSourceState,
                                user=Depends(get_event_user), db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    source = await db.scalar(select(EventWebhookSource).where(
        EventWebhookSource.id == source_id, EventWebhookSource.user_id == user_id))
    if source is None:
        raise HTTPException(404, "Webhook source not found.")
    source.enabled = body.enabled
    await db.commit()
    return source_view(source)


@router.post("/sources/{source_id}/rotate")
async def rotate_webhook_secret(source_id: str, response: Response, user=Depends(get_event_user),
                                db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    response.headers["Cache-Control"] = "no-store"
    try:
        return await rotate_secret(db, user_id, source_id)
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.delete("/sources/{source_id}", status_code=204)
async def delete_webhook_source(source_id: str, user=Depends(get_event_user),
                                db: AsyncSession = Depends(get_db)):
    user_id = await _owner(db, user)
    source = await db.scalar(select(EventWebhookSource).where(
        EventWebhookSource.id == source_id, EventWebhookSource.user_id == user_id))
    if source is None:
        raise HTTPException(404, "Webhook source not found.")
    await db.delete(source)
    await db.commit()
    return Response(status_code=204)


@router.post("/webhooks/{source_id}", status_code=202)
async def receive_webhook(source_id: str, request: Request, db: AsyncSession = Depends(get_db)):
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > MAX_WEBHOOK_BYTES:
            raise HTTPException(413, "Webhook body exceeds the supported size.")
    raw = bytes(raw)
    if not raw or len(raw) > MAX_WEBHOOK_BYTES:
        raise HTTPException(413, "Webhook body is empty or exceeds the supported size.")
    dispatcher = _worker(request)
    try:
        source, event = await verify_delivery(db, source_id, raw,
            request.headers.get("X-Event-Timestamp", ""), request.headers.get("X-Event-Signature", ""))
        return await dispatcher.submit(source.user_id, "webhook", source.id, event)
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error
