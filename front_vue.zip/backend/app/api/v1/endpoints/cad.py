"""CAD Agent generation, user-confirmed build, and artifact endpoints."""

from __future__ import annotations

import asyncio
import json
import mimetypes
import uuid
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.base import AgentStatus
from app.agents.impl.cad import CadAgent, CadContext
from app.agents.impl.cad.workflow import build_initial_workflow_state
from app.agents.impl.cad.runtime import (
    CadRuntimeError,
    build_model,
    resolve_artifact,
    runtime_status,
    task_output_dir,
)
from app.core.config import get_settings, resolve_agent_llm_selection
from app.core.database import async_session_factory, get_db
from app.core.security import get_optional_user_from_request
from app.models.task import Task
from app.services.billing_service import enforce_billing


router = APIRouter()
_running_cad_tasks: dict[str, asyncio.Task] = {}
_running_cad_agents: dict[str, CadAgent] = {}


class CadTaskRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prompt: str = Field(min_length=1, max_length=12000)
    output_format: Literal["step", "stl", "3mf", "glb"] = "step"
    auto_build: bool = True


def _optional_user(request: Request) -> dict[str, str]:
    return get_optional_user_from_request(request, "guest")


def _cad_llm_status(llm_bridge) -> dict[str, str | bool]:
    """Report whether the runtime provider selected for CAD is ready."""
    selection = resolve_agent_llm_selection("cad")
    providers = llm_bridge.list_providers() if llm_bridge is not None else []
    provider = next(
        (item for item in providers if item.get("name") == selection.runtime_provider),
        None,
    )
    if provider is None:
        return {
            "llm_available": False,
            "llm_provider": selection.provider,
            "llm_model": selection.model,
            "llm_error": "The CAD LLM provider is not registered",
        }
    if not provider.get("healthy", False):
        return {
            "llm_available": False,
            "llm_provider": selection.provider,
            "llm_model": selection.model,
            "llm_error": "The CAD LLM provider is not ready",
        }
    return {
        "llm_available": True,
        "llm_provider": selection.provider,
        "llm_model": selection.model,
        "llm_error": "",
    }


def _load_json(value: str | None) -> dict:
    try:
        parsed = json.loads(value) if value else {}
    except (TypeError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _is_repairable_cad_task(task_status: str, result_data: dict) -> bool:
    """Allow source repair after either a build failure or a rejected review."""
    if task_status != "failed":
        return False
    if result_data.get("phase") in {"build_failed", "repair_failed"}:
        return True
    return (
        result_data.get("phase") == "generation_failed"
        and result_data.get("coverage_review", {}).get("status") == "revise"
        and bool(result_data.get("model_file"))
    )


def _serialize_task(task: Task) -> dict:
    result = _load_json(task.result_data)
    api_prefix = "/" + get_settings().API_V1_PREFIX.strip("/")
    artifacts = []
    for artifact in result.get("artifacts", []):
        if not isinstance(artifact, dict) or not artifact.get("filename"):
            continue
        filename = Path(str(artifact["filename"])).name
        artifacts.append({
            **artifact,
            "url": f"{api_prefix}/cad/tasks/{task.id}/artifacts/{artifact.get('type', 'file')}",
        })
    if result.get("model_file"):
        model_name = Path(str(result["model_file"])).name
        artifacts.insert(0, {
            "filename": model_name,
            "type": "model_source",
            "url": f"{api_prefix}/cad/tasks/{task.id}/artifacts/model_source",
        })
    result["artifacts"] = artifacts
    return {
        "task_id": task.id,
        "agent_type": task.agent_type,
        "status": task.status,
        "progress": task.progress,
        "message": task.message,
        "error": task.error_message,
        "input": _load_json(task.input_data),
        "result": result,
        "duration_ms": task.duration_ms,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "updated_at": task.updated_at.isoformat() if task.updated_at else None,
    }


def _mark_cad_workflow_terminal(result_data: dict, status: str) -> None:
    """Close the active canonical CAD node after termination."""
    workflow_state = result_data.get("workflow_state")
    nodes = workflow_state.get("nodes") if isinstance(workflow_state, dict) else None
    if not isinstance(nodes, list):
        nodes = result_data.get("workflow_nodes")
    if not isinstance(nodes, list):
        return
    terminal = "cancelled" if status == AgentStatus.CANCELLED.value else "failed"
    active_seen = False
    for node in nodes:
        if not isinstance(node, dict):
            continue
        if node.get("status") == "in_progress":
            node["status"] = terminal
            active_seen = True
        elif node.get("status") == "pending" and active_seen:
            node["status"] = "skipped"
    if isinstance(workflow_state, dict):
        workflow_state["nodes"] = nodes
        workflow_state["status"] = status
    result_data["workflow_nodes"] = nodes


async def _persist_cad_progress(task_id: str, progress: int, stage: str, message: str, details=None) -> None:
    """Persist graph snapshots so task polling can render the active CAD node."""
    async with async_session_factory() as session:
        result = await session.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task and task.status == "running":
            task.progress = max(0, min(progress, 99))
            task.message = message[:500]
            workflow_state = (details or {}).get("workflow_state")
            if isinstance(workflow_state, dict) and isinstance(workflow_state.get("nodes"), list):
                result_data = _load_json(task.result_data)
                result_data["workflow_state"] = workflow_state
                result_data["workflow_nodes"] = workflow_state["nodes"]
                task.result_data = json.dumps(result_data, ensure_ascii=False)
            await session.commit()


async def _get_owned_task(task_id: str, user_id: str, db: AsyncSession) -> Task:
    result = await db.execute(select(Task).where(Task.id == task_id, Task.agent_type == "cad"))
    task = result.scalar_one_or_none()
    if not task or task.user_id != user_id:
        raise HTTPException(status_code=404, detail="CAD task not found")
    return task


async def _run_generation_task(
    task_id: str,
    user_id: str,
    request: CadTaskRequest,
    agent: CadAgent,
    *,
    repair_source: str = "",
    repair_error: str = "",
    repair_plan: dict | None = None,
    repair_review: dict | None = None,
) -> None:
    try:
        context = CadContext(
            task_id=task_id,
            user_id=user_id,
            prompt=request.prompt.strip(),
            output_format=request.output_format,
            auto_build=request.auto_build,
            metadata={
                "cad_repair_source": repair_source,
                "cad_repair_error": repair_error,
                "cad_repair_plan": repair_plan or {},
                "cad_repair_review": repair_review or {},
            },
        )
        async for update in agent.stream_execute(request.prompt, context):
            await _persist_cad_progress(
                task_id,
                update.progress,
                update.stage,
                update.message,
                update.details,
            )
        result = agent.get_status(task_id)
        if result is None:
            raise RuntimeError("CAD generation completed without an agent result")
        async with async_session_factory() as session:
            stored_result = await session.execute(select(Task).where(Task.id == task_id))
            stored_task = stored_result.scalar_one_or_none()
            result_data = _load_json(stored_task.result_data) if stored_task else {}
        result_data.update(result.data or {})
        result_data.pop("workflow_stage", None)
        model_code = str(result_data.pop("model_code", ""))
        if model_code and not result_data.get("model_file"):
            output_dir = task_output_dir(user_id, task_id)
            output_dir.mkdir(parents=True, exist_ok=True)
            await asyncio.to_thread((output_dir / "model.py").write_text, model_code, encoding="utf-8")
            result_data["model_file"] = "model.py"
        build_result = result_data.pop("build_result", {})
        build_error = result_data.pop("build_error", "")
        if result.status == AgentStatus.COMPLETED:
            result_data.update(build_result or {})
            result_data["phase"] = "completed" if build_result else "script_ready"
            result_data.setdefault("artifacts", [])
            status = "completed" if build_result else "script_ready"
            progress = 100
            message = result.message
            error_message = None
        else:
            status = result.status.value
            progress = 0
            message = result.message
            error_message = "\n".join(result.errors)[:12000] or result.message
            result_data["phase"] = "build_failed" if build_error else result_data.get("phase", "generation_failed")
            if build_error:
                result_data["build_error"] = build_error
            result_data.setdefault("artifacts", [])
            _mark_cad_workflow_terminal(result_data, status)

        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task and task.status != "cancelled":
                task.status = status
                task.progress = progress
                task.message = message[:500]
                task.result_data = json.dumps(result_data, ensure_ascii=False)
                task.error_message = error_message
                task.duration_ms = result.duration_ms
                await session.commit()
    except asyncio.CancelledError:
        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task and task.status == "running":
                result_data = _load_json(task.result_data)
                _mark_cad_workflow_terminal(result_data, AgentStatus.CANCELLED.value)
                task.status = "cancelled"
                task.progress = 0
                task.message = "CAD generation cancelled"
                task.error_message = task.message
                task.result_data = json.dumps(result_data, ensure_ascii=False) if result_data else None
                await session.commit()
        raise
    except Exception as error:
        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task:
                result_data = _load_json(task.result_data)
                _mark_cad_workflow_terminal(result_data, AgentStatus.FAILED.value)
                task.status = "failed"
                task.progress = 0
                task.message = "CAD model generation failed"
                task.error_message = str(error)[:12000]
                task.result_data = json.dumps(result_data, ensure_ascii=False) if result_data else None
                await session.commit()
    finally:
        _running_cad_agents.pop(task_id, None)
        _running_cad_tasks.pop(task_id, None)


async def _run_build_task(
    task_id: str,
    user_id: str,
    output_format: str,
    *,
    clear_registry: bool = True,
) -> None:
    try:
        build_result = await build_model(task_id, user_id, output_format)
        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task and task.status != "cancelled":
                result_data = _load_json(task.result_data)
                result_data.update(build_result)
                result_data["phase"] = "completed"
                task.result_data = json.dumps(result_data, ensure_ascii=False)
                task.status = "completed"
                task.progress = 100
                task.message = "CAD model built and previewed"
                task.error_message = None
                await session.commit()
    except asyncio.CancelledError:
        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task and task.status == "running":
                task.status = "cancelled"
                task.progress = 0
                task.message = "CAD build cancelled"
                task.error_message = task.message
                await session.commit()
        raise
    except CadRuntimeError as error:
        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task:
                result_data = _load_json(task.result_data)
                result_data["phase"] = "build_failed"
                result_data["build_error"] = str(error)[:12000]
                task.result_data = json.dumps(result_data, ensure_ascii=False)
                task.status = "failed"
                task.progress = 0
                task.message = "CAD model build failed"
                task.error_message = str(error)[:12000]
                await session.commit()
    except Exception as error:
        async with async_session_factory() as session:
            task_result = await session.execute(select(Task).where(Task.id == task_id))
            task = task_result.scalar_one_or_none()
            if task:
                result_data = _load_json(task.result_data)
                result_data["phase"] = "build_failed"
                result_data["build_error"] = str(error)[:12000]
                task.result_data = json.dumps(result_data, ensure_ascii=False)
                task.status = "failed"
                task.progress = 0
                task.message = "CAD model build failed"
                task.error_message = str(error)[:12000]
                await session.commit()
    finally:
        if clear_registry:
            _running_cad_tasks.pop(task_id, None)


@router.get("/status")
async def get_cad_status(raw_request: Request) -> dict:
    """Return local skill and CAD runtime availability without starting processes."""
    llm_bridge = getattr(raw_request.app.state, "llm_bridge", None)
    return {**runtime_status(), **_cad_llm_status(llm_bridge)}


@router.post("/tasks", status_code=202)
async def create_cad_task(
    request: CadTaskRequest,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Create a CAD task that generates, builds, and snapshots the model in one run."""
    cad_status = runtime_status()
    if not cad_status["skill_available"]:
        raise HTTPException(status_code=503, detail="The local MaCAD skill is unavailable")
    if request.auto_build and not cad_status["build_available"]:
        raise HTTPException(status_code=503, detail="The local CAD build runtime is unavailable for review preview generation")
    if not request.prompt.strip():
        raise HTTPException(status_code=422, detail="A CAD model description is required")
    llm_bridge = getattr(raw_request.app.state, "llm_bridge", None)
    if llm_bridge is None:
        raise HTTPException(status_code=503, detail="LLM bridge is not initialized")
    llm_status = _cad_llm_status(llm_bridge)
    if not llm_status["llm_available"]:
        raise HTTPException(status_code=503, detail=str(llm_status["llm_error"]))
    current_user = _optional_user(raw_request)
    await enforce_billing(current_user)
    task_id = str(uuid.uuid4())
    initial_workflow_state = build_initial_workflow_state()
    db.add(Task(
        id=task_id,
        user_id=current_user["id"],
        agent_type="cad",
        status="running",
        progress=5,
        message="Starting CAD generation workflow",
        input_data=json.dumps({
            "prompt": request.prompt.strip(),
            "output_format": request.output_format,
            "auto_build": request.auto_build,
        }, ensure_ascii=False),
        result_data=json.dumps({
            "workflow_state": initial_workflow_state,
            "workflow_nodes": initial_workflow_state["nodes"],
        }, ensure_ascii=False),
    ))
    await db.commit()
    agent = CadAgent(
        llm_bridge,
        skill_registry=getattr(raw_request.app.state, "skill_registry", None),
    )
    task = asyncio.create_task(_run_generation_task(task_id, current_user["id"], request, agent))
    _running_cad_tasks[task_id] = task
    _running_cad_agents[task_id] = agent
    return {
        "task_id": task_id,
        "status": "running",
        "message": "CAD generation and review started",
        "auto_build": request.auto_build,
        "workflow_state": initial_workflow_state,
        "workflow_nodes": initial_workflow_state["nodes"],
    }


@router.get("/tasks")
async def list_cad_tasks(
    raw_request: Request,
    limit: int = 50,
    offset: int = 0,
    db: AsyncSession = Depends(get_db),
) -> dict:
    """List the current user's CAD task history."""
    current_user = _optional_user(raw_request)
    filters = [Task.user_id == current_user["id"], Task.agent_type == "cad"]
    result = await db.execute(
        select(Task).where(*filters).order_by(Task.created_at.desc()).offset(offset).limit(min(max(limit, 1), 100))
    )
    count = await db.execute(select(func.count()).select_from(Task).where(*filters))
    tasks = list(result.scalars().all())
    return {"tasks": [_serialize_task(task) for task in tasks], "total": count.scalar() or 0}


@router.get("/tasks/{task_id}")
async def get_cad_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
) -> dict:
    current_user = _optional_user(raw_request)
    return _serialize_task(await _get_owned_task(task_id, current_user["id"], db))


@router.post("/tasks/{task_id}/build", status_code=202)
async def start_cad_build(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Run the reviewed model script with the pinned local cadgen distribution."""
    current_user = _optional_user(raw_request)
    task = await _get_owned_task(task_id, current_user["id"], db)
    if task.status == "running":
        raise HTTPException(status_code=409, detail="CAD task is already running")
    result_data = _load_json(task.result_data)
    if not result_data.get("model_file"):
        raise HTTPException(status_code=409, detail="Generate a valid CAD model script before building")
    if not runtime_status()["build_available"]:
        raise HTTPException(status_code=503, detail="The local CAD build runtime is unavailable")
    input_data = _load_json(task.input_data)
    output_format = input_data.get("output_format", "step")
    if output_format not in {"step", "stl", "3mf", "glb"}:
        raise HTTPException(status_code=409, detail="CAD task has an unsupported output format")
    task.status = "running"
    task.progress = 15
    task.message = "Building CAD model with the local cadgen runtime"
    task.error_message = None
    result_data["phase"] = "building"
    result_data["artifacts"] = []
    for key in ("build_log", "snapshot_log", "geometry", "geometry_review"):
        result_data.pop(key, None)
    task.result_data = json.dumps(result_data, ensure_ascii=False)
    await db.commit()
    running_task = asyncio.create_task(_run_build_task(task_id, current_user["id"], output_format))
    _running_cad_tasks[task_id] = running_task
    return {"task_id": task_id, "status": "running", "message": task.message}


@router.post("/tasks/{task_id}/repair", status_code=202)
async def repair_cad_model_script(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Repair a failed CAD build and regenerate its review preview in one run."""
    current_user = _optional_user(raw_request)
    task = await _get_owned_task(task_id, current_user["id"], db)
    if task.status == "running":
        raise HTTPException(status_code=409, detail="CAD task is already running")
    result_data = _load_json(task.result_data)
    if not _is_repairable_cad_task(task.status, result_data):
        raise HTTPException(status_code=409, detail="Only a failed CAD build or review with a saved source can be repaired")
    input_data = _load_json(task.input_data)
    output_format = input_data.get("output_format", "step")
    if output_format not in {"step", "stl", "3mf", "glb"}:
        raise HTTPException(status_code=409, detail="CAD task has an unsupported output format")
    llm_bridge = getattr(raw_request.app.state, "llm_bridge", None)
    if llm_bridge is None:
        raise HTTPException(status_code=503, detail="LLM bridge is not initialized")
    source_path = resolve_artifact(task_id, current_user["id"], "model.py")
    if source_path is None:
        raise HTTPException(status_code=409, detail="The CAD model source is unavailable")
    try:
        source = await asyncio.to_thread(source_path.read_text, encoding="utf-8")
    except (OSError, UnicodeError) as error:
        raise HTTPException(status_code=409, detail="The CAD model source could not be read") from error

    if not runtime_status()["build_available"]:
        raise HTTPException(status_code=503, detail="The local CAD build runtime is unavailable")
    failure = result_data.get("build_error") or task.error_message or "The CAD build did not produce a valid artifact"
    repair_plan = result_data.get("design_plan")
    repair_review = result_data.get("coverage_review")
    initial_workflow_state = build_initial_workflow_state()
    for key in ("design_plan", "coverage_review", "build_error", "repair_error", "build_log", "snapshot_log", "geometry", "geometry_review"):
        result_data.pop(key, None)
    result_data["workflow_state"] = initial_workflow_state
    result_data["workflow_nodes"] = initial_workflow_state["nodes"]
    result_data["phase"] = "repairing"
    result_data["artifacts"] = []
    task.result_data = json.dumps(result_data, ensure_ascii=False)
    task.status = "running"
    task.progress = 5
    task.message = "Repairing CAD model source for review"
    task.error_message = None
    await db.commit()

    agent = CadAgent(
        llm_bridge,
        skill_registry=getattr(raw_request.app.state, "skill_registry", None),
    )
    repair_task = asyncio.create_task(_run_generation_task(
        task_id,
        current_user["id"],
        CadTaskRequest(prompt=input_data.get("prompt", ""), output_format=output_format, auto_build=True),
        agent,
        repair_source=source,
        repair_error=failure,
        repair_plan=repair_plan if isinstance(repair_plan, dict) else {},
        repair_review=repair_review if isinstance(repair_review, dict) else {},
    ))
    _running_cad_tasks[task_id] = repair_task
    _running_cad_agents[task_id] = agent
    return {
        "task_id": task_id,
        "status": "running",
        "message": task.message,
        "workflow_state": initial_workflow_state,
        "workflow_nodes": initial_workflow_state["nodes"],
    }


@router.post("/tasks/{task_id}/cancel")
async def cancel_cad_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
) -> dict:
    current_user = _optional_user(raw_request)
    task = await _get_owned_task(task_id, current_user["id"], db)
    if task.status != "running":
        return _serialize_task(task)
    agent = _running_cad_agents.get(task_id)
    if agent:
        await agent.cancel(task_id)
    running_task = _running_cad_tasks.get(task_id)
    if running_task and not running_task.done():
        running_task.cancel()
    task.status = "cancelled"
    task.progress = 0
    task.message = "CAD task cancelled"
    task.error_message = task.message
    result_data = _load_json(task.result_data)
    _mark_cad_workflow_terminal(result_data, AgentStatus.CANCELLED.value)
    task.result_data = json.dumps(result_data, ensure_ascii=False) if result_data else None
    await db.commit()
    return _serialize_task(task)


@router.get("/tasks/{task_id}/artifacts/{artifact_type}")
async def get_cad_artifact(
    task_id: str,
    artifact_type: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
) -> FileResponse:
    current_user = _optional_user(raw_request)
    task = await _get_owned_task(task_id, current_user["id"], db)
    result = _load_json(task.result_data)
    if artifact_type == "model_source" and result.get("model_file") == "model.py":
        filename = "model.py"
    else:
        artifact = next(
            (
                item for item in result.get("artifacts", [])
                if isinstance(item, dict) and item.get("type") == artifact_type
            ),
            None,
        )
        filename = str(artifact.get("filename")) if artifact else ""
    if not filename:
        raise HTTPException(status_code=404, detail="CAD artifact not found")
    path = resolve_artifact(task_id, current_user["id"], filename)
    if path is None:
        raise HTTPException(status_code=404, detail="CAD artifact not found")
    display_name = Path(filename).name
    media_type = mimetypes.guess_type(display_name)[0] or "application/octet-stream"
    is_preview = path.suffix.lower() == ".png"
    disposition = "inline" if is_preview or path.suffix.lower() == ".py" else "attachment"
    return FileResponse(
        path,
        media_type=media_type,
        filename=None if disposition == "inline" else path.name,
        headers={
            "Content-Disposition": f'{disposition}; filename="{display_name}"',
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "sandbox; default-src 'none'",
        },
    )
