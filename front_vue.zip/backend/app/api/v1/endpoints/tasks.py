"""
@file tasks.py
@author caoshwen
@brief Task management API endpoints.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.models.task import Task

router = APIRouter()


@router.get("/")
async def list_tasks(
    status: Optional[str] = Query(None, description="Filter by task status"),
    agent_type: Optional[str] = Query(None, description="Filter by Agent type"),
    limit: int = Query(10, ge=1, le=100, description="Maximum number of results to return"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """List all tasks"""
    query = select(Task).where(Task.user_id == current_user["id"])
    count_query = select(func.count()).select_from(Task).where(Task.user_id == current_user["id"])

    if status:
        query = query.where(Task.status == status)
        count_query = count_query.where(Task.status == status)
    if agent_type:
        query = query.where(Task.agent_type == agent_type)
        count_query = count_query.where(Task.agent_type == agent_type)

    query = query.order_by(Task.created_at.desc()).offset(offset).limit(limit)

    result = await db.execute(query)
    tasks = result.scalars().all()

    count_result = await db.execute(count_query)
    total = count_result.scalar() or 0

    task_list = []
    for t in tasks:
        task_list.append({
            "task_id": t.id,
            "agent_type": t.agent_type,
            "status": t.status,
            "progress": t.progress,
            "message": t.message,
            "created_at": t.created_at.isoformat() if t.created_at else None,
            "updated_at": t.updated_at.isoformat() if t.updated_at else None,
        })

    return {"tasks": task_list, "total": total, "limit": limit, "offset": offset}


@router.get("/{task_id}")
async def get_task_status(
    task_id: str,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Get task execution status"""
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.user_id == current_user["id"])
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    response = {
        "task_id": task.id,
        "agent_type": task.agent_type,
        "status": task.status,
        "progress": task.progress,
        "message": task.message,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "updated_at": task.updated_at.isoformat() if task.updated_at else None,
    }

    if task.result_data:
        try:
            response["result"] = json.loads(task.result_data)
        except json.JSONDecodeError:
            response["result"] = task.result_data

    if task.error_message:
        response["error"] = task.error_message

    return response


@router.delete("/{task_id}")
async def delete_task(
    task_id: str,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete task"""
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.user_id == current_user["id"])
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    await db.delete(task)
    return {"success": True, "message": "Task deleted"}
