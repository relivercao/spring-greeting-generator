"""Public skill market search, preview, and installation endpoints."""

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, ConfigDict, Field

from app.services.skill_market import SkillMarketError, SkillMarketService
from app.core.security import get_current_admin_user

router = APIRouter()
market = SkillMarketService()

from app.services.skill_integration import runtime_integration as _runtime_integration


class InstallSkillRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    github_url: str = Field(min_length=1, max_length=2048)


def _raise_http_error(error: SkillMarketError) -> None:
    raise HTTPException(status_code=error.status_code, detail=str(error)) from error


@router.get("/search")
async def search_skills(
    q: str = Query(min_length=2, max_length=120),
    page: int = Query(default=1, ge=1, le=10000),
    limit: int = Query(default=20, ge=1, le=50),
) -> dict[str, Any]:
    try:
        return await market.search(q, page, limit)
    except SkillMarketError as error:
        _raise_http_error(error)


@router.get("/installed")
async def list_installed_skills(request: Request) -> dict[str, Any]:
    registry = getattr(request.app.state, "skill_registry", None)
    items = await market.installed()
    for item in items:
        item["integration"] = _runtime_integration(item["name"], registry)
    return {"items": items}


@router.get("/preview")
async def preview_skill(github_url: str = Query(min_length=1, max_length=2048)) -> dict[str, str]:
    try:
        return await market.preview(github_url)
    except SkillMarketError as error:
        _raise_http_error(error)


@router.post("/install")
async def install_skill(payload: InstallSkillRequest, request: Request,
                        admin=Depends(get_current_admin_user)) -> dict[str, Any]:
    try:
        result = await market.install(payload.github_url)
    except SkillMarketError as error:
        _raise_http_error(error)
    registry = getattr(request.app.state, "skill_registry", None)
    if registry is not None:
        from app.skills.loader import SkillLoader
        registry.register(SkillLoader().load_all())
    result["integration"] = _runtime_integration(result["name"], registry)
    return result
