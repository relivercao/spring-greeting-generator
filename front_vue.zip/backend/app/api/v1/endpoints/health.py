"""
@file health.py
@author caoshwen
@brief Health check API endpoints.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from fastapi import APIRouter, Request, Response

from app.core.config import get_settings
from app.infrastructure.observability.health import HealthCheckAggregator
from app.infrastructure.observability.metrics import MetricsCollector

router = APIRouter()
settings = get_settings()


@router.get("/health")
async def health_check(request: Request):
    """
    Aggregated health check endpoint.

    Returns:
    - status: "healthy" | "degraded" | "unhealthy"
    - components: Detailed health status of each component
    - version: Application version number

    HTTP status codes:
    - 200: healthy
    - 503: degraded / unhealthy
    """
    aggregator: HealthCheckAggregator = request.app.state.health
    result = await aggregator.check_all()
    result["version"] = settings.APP_VERSION
    status_code = 200 if result["status"] == "healthy" else 503
    return Response(
        content=_to_json(result),
        media_type="application/json",
        status_code=status_code,
    )


@router.get("/metrics")
async def metrics_json():
    """
    Metrics endpoint -- JSON summary (Phase 1).

    Phase 2 will switch to Prometheus text format,
    for Prometheus scraper direct pull.
    """
    metrics = MetricsCollector.get_instance()
    return metrics.get_summary()


@router.get("/metrics/prometheus")
async def metrics_prometheus():
    """
    Prometheus native format metrics endpoint.

    Phase 2 production environment uses this endpoint.
    Content-Type: text/plain; version=0.0.4
    """
    metrics = MetricsCollector.get_instance()
    return Response(
        content=metrics.export_metrics(),
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


def _to_json(data: dict) -> str:
    """Use orjson for efficient JSON serialization"""
    try:
        import orjson
        return orjson.dumps(data).decode("utf-8")
    except ImportError:
        import json
        return json.dumps(data, ensure_ascii=False)
