"""Administrator endpoints for the shared system mailbox."""

from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.routing import APIRoute
from pydantic import BaseModel, ConfigDict, Field

from app.core.security import get_current_admin_user
from app.infrastructure.email import MailDeliveryError
from app.services.email_settings import check_email_connection, email_settings, save_email_settings


class EmailSettingsRoute(APIRoute):
    """Omit submitted credential values from request validation errors."""

    def get_route_handler(self):
        handler = super().get_route_handler()

        async def safe_handler(request):
            try:
                return await handler(request)
            except RequestValidationError as error:
                details = [
                    {key: item[key] for key in ("loc", "msg", "type") if key in item}
                    for item in error.errors()
                ]
                raise HTTPException(status_code=422, detail=details) from error

        return safe_handler


router = APIRouter(route_class=EmailSettingsRoute)


class EmailSettingsRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: Literal["custom", "gmail"] = "gmail"
    host: str = Field(default="", max_length=255)
    port: int = Field(default=587, ge=1, le=65535)
    username: str = Field(default="", max_length=320)
    password: str | None = Field(default=None, max_length=2048, repr=False)
    sender: str = Field(default="", max_length=320)
    security: Literal["starttls", "ssl", "none"] = "starttls"
    approval_enabled: bool = False
    approval_recipients: str = Field(default="", max_length=4000)
    approval_use_global: bool = True


@router.get("/settings/email")
async def get_email_settings(_admin=Depends(get_current_admin_user)) -> dict:
    return email_settings()


@router.put("/settings/email")
async def update_email_settings(request: EmailSettingsRequest, _admin=Depends(get_current_admin_user)) -> dict:
    try:
        return await save_email_settings(**request.model_dump())
    except MailDeliveryError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error


@router.post("/settings/email/check")
async def verify_email_connection(_admin=Depends(get_current_admin_user)) -> dict:
    try:
        return await check_email_connection()
    except MailDeliveryError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
