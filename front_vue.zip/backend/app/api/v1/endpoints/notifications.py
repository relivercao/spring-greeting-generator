"""Workspace notifications sourced from configured development systems."""

from typing import Any

from fastapi import APIRouter, Depends, Query, Request

from app.core.security import get_current_active_user
from app.services.integration_notifications import collect_integration_notifications

router = APIRouter()


@router.get("/notifications/integration-updates")
async def get_integration_updates(
    raw_request: Request,
    max_results: int = Query(default=20, ge=1, le=50),
    current_user: dict[str, Any] = Depends(get_current_active_user),
) -> dict[str, Any]:
    """Return recent Jira Bugs and Bitbucket pull-request updates for the inbox."""
    del current_user
    return await collect_integration_notifications(
        getattr(raw_request.app.state, "mcp_client", None),
        max_results=max_results,
    )
