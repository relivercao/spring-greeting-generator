"""
@file service.py
@brief Service management API endpoints for portable package.

@version 1.0
@date 2026-03-20

Provides the following endpoint functions:
- Check service status (backend/frontend)
- Gracefully shutdown all services
- Handle PID file management

For portable launcher use:
- Detect duplicate startup
- Remote shutdown from frontend UI
"""
import asyncio
import os
import signal
from pathlib import Path
from typing import Dict, Any

import psutil
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.infrastructure.observability.logger import LoggerService

router = APIRouter()
log = LoggerService.get_logger("system")


class ServiceStatus(BaseModel):
    """Service status response model"""
    running: bool
    port: int
    pid: int = None


class ShutdownResponse(BaseModel):
    """Shutdown operation response"""
    message: str
    frontend_killed: bool
    backend_pid: int


@router.get("/service/status", response_model=Dict[str, Any], summary="Get service status")
async def get_service_status() -> Dict[str, Any]:
    """
    Check if backend and frontend services are running.

    Returns:
        - Backend: always running (current process)
        - Frontend: check if port 5173 is listening
    """
    backend_running = True
    frontend_running = False
    frontend_pid = None

    # Check frontend (port 5173)
    try:
        for conn in psutil.net_connections(kind='inet'):
            if conn.laddr.port == 5173 and conn.status == 'LISTEN':
                frontend_running = True
                frontend_pid = conn.pid
                break
    except (psutil.AccessDenied, psutil.NoSuchProcess):
        pass

    return {
        "backend": {
            "running": backend_running,
            "port": 8000,
            "pid": os.getpid()
        },
        "frontend": {
            "running": frontend_running,
            "port": 5173,
            "pid": frontend_pid
        }
    }


@router.post("/service/shutdown", response_model=ShutdownResponse, summary="Shutdown all services")
async def shutdown_services() -> ShutdownResponse:
    """
    Gracefully shutdown backend and frontend services.

    This endpoint is called from frontend UI to stop all services:
    1. Terminate frontend process (port 5173)
    2. Remove PID files
    3. Terminate backend process (self-terminate after response)

    Warning: This will make the API unavailable in about 1 second.
    """
    log.info("Shutdown request received from frontend")

    killed_frontend = False
    frontend_pid = None

    # Step 1: Terminate frontend process (port 5173)
    # Use multiple detection methods for robustness:
    # 1. Port-based detection (most reliable)
    # 2. Process name/command line matching (fallback)
    try:
        # Method 1: Find process listening on port 5173
        for conn in psutil.net_connections(kind='inet'):
            if conn.laddr.port == 5173 and conn.status == 'LISTEN':
                try:
                    proc = psutil.Process(conn.pid)
                    log.info(f"Killing frontend process (port 5173): PID {conn.pid} ({proc.name()})")
                    proc.kill()
                    killed_frontend = True
                    frontend_pid = conn.pid
                    break
                except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                    log.warning(f"Failed to kill frontend by port: {e}")

        # Method 2: Fallback - search by cmdline patterns
        if not killed_frontend:
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = ' '.join(proc.info['cmdline'] or [])
                    # Match various frontend processes
                    patterns = [
                        'serve_frontend.py',
                        ':5173',
                        'vite',  # npm run dev (development)
                        'npm run dev',
                    ]
                    if any(p in cmdline.lower() for p in patterns):
                        frontend_pid = proc.info['pid']
                        log.info(f"Killing frontend process (cmdline match): PID {frontend_pid}")
                        proc.kill()
                        killed_frontend = True
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError):
                    continue
    except Exception as e:
        log.error(f"Error killing frontend: {e}")

    # Step 2: Remove PID files
    # PID file location depends on environment:
    # - Portable mode: dist/fw-agent-portable/backend.pid (2 levels up from backend/)
    # - Development mode: backend/backend.pid (1 level up from app/)
    backend_dir = Path(__file__).parent.parent.parent.parent.parent  # backend/
    portable_root = backend_dir.parent.parent  # dist/fw-agent-portable/

    # Check if we're in portable mode (start.bat exists in portable root)
    if (portable_root / "start.bat").exists():
        backend_pid_file = portable_root / "backend.pid"
        frontend_pid_file = portable_root / "frontend.pid"
    else:
        # Development mode: PID files in backend directory
        backend_pid_file = backend_dir / "backend.pid"
        frontend_pid_file = backend_dir / "frontend.pid"

    for pid_file in [backend_pid_file, frontend_pid_file]:
        if pid_file.exists():
            try:
                pid_file.unlink()
                log.info(f"Removed PID file: {pid_file}")
            except Exception as e:
                log.warning(f"Failed to remove {pid_file}: {e}")

    # Step 3: Schedule self-termination (delay to allow HTTP response to be sent)
    async def delayed_suicide():
        """Kill backend process with 1 second delay to allow response to reach client"""
        await asyncio.sleep(1)
        log.info("Shutting down backend process...")
        # Use psutil for reliable cross-platform termination
        try:
            current_proc = psutil.Process(os.getpid())
            # Kill all child processes first (uvicorn workers, etc.)
            for child in current_proc.children(recursive=True):
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass
            # Then kill self
            current_proc.kill()
        except Exception as e:
            log.error(f"Failed to kill process tree: {e}")
            # Fallback to os.kill
            os.kill(os.getpid(), signal.SIGTERM)

    asyncio.create_task(delayed_suicide())

    log.info("Shutdown initiated",
             frontend_killed=killed_frontend,
             backend_pid=os.getpid())

    return ShutdownResponse(
        message="Services shutting down",
        frontend_killed=killed_frontend,
        backend_pid=os.getpid()
    )


@router.get("/service/health", summary="Quick health check")
async def health_check() -> Dict[str, str]:
    """Simple health check endpoint for load balancers"""
    return {"status": "healthy"}