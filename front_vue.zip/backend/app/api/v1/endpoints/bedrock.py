"""
@file bedrock.py
@author caoshwen
@brief Bedrock-specific API endpoints - SSO login, cache status.

@version 3.2
@date 2026-04-13

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from fastapi import APIRouter, HTTPException
from loguru import logger
from pydantic import BaseModel

from app.core.aws_sso_cache import AWSSSOCache
from app.core.config import get_settings

router = APIRouter()


class SSOLoginResponse(BaseModel):
    status: str
    message: str


class SSOStatusResponse(BaseModel):
    exists: bool
    valid: bool
    expires_at: str | None
    profile: str


@router.post("/sso-login", response_model=SSOLoginResponse)
async def trigger_sso_login(clear_cache: bool = True):
    """
    Trigger AWS SSO login for the configured profile.

    This will execute `aws sso login --profile <profile>` and open
    the user's browser with Amazon SSO login page.

    Args:
        clear_cache: If True, clear existing SSO cache before login (default: True)

    Returns:
        SSOLoginResponse with status and message.
    """
    settings = get_settings()
    profile = settings.AWS_PROFILE

    if not profile:
        raise HTTPException(
            status_code=400,
            detail="AWS_PROFILE not configured in .env",
        )

    logger.info(f"API: Triggering AWS SSO login for profile: {profile} (clear_cache={clear_cache})")

    cache_manager = AWSSSOCache(
        profile_name=profile,
        region=settings.AWS_REGION,
    )

    result = cache_manager.trigger_sso_login(clear_cache=clear_cache)

    if result["status"] == "error":
        raise HTTPException(status_code=500, detail=result["message"])

    return SSOLoginResponse(**result)


@router.get("/sso-status", response_model=SSOStatusResponse)
async def get_sso_status(verify_credentials: bool = False):
    """
    Get current AWS SSO cache status.

    Args:
        verify_credentials: If True, perform full verification including aws sts call.
                          If False (default), only check SSO token expiration (fast).

    Returns:
        SSOStatusResponse with cache information:
        - exists: whether cache file exists
        - valid: whether credentials are valid (level depends on verify_credentials param)
        - expires_at: token expiration time (ISO format)
        - profile: AWS profile name
    """
    settings = get_settings()
    profile = settings.AWS_PROFILE

    if not profile:
        raise HTTPException(
            status_code=400,
            detail="AWS_PROFILE not configured in .env",
        )

    cache_manager = AWSSSOCache(
        profile_name=profile,
        region=settings.AWS_REGION,
    )

    # Check if Profile exists before checking token status
    sso_start_url = cache_manager._get_sso_start_url()
    if not sso_start_url:
        logger.error(f"AWS Profile '{profile}' not found in ~/.aws/config")
        raise HTTPException(
            status_code=500,
            detail=f"AWS_PROFILE_INVALID: Profile '{profile}' not found in ~/.aws/config. Please check server configuration.",
        )

    # Use verify_credentials parameter to control verification level
    is_valid = cache_manager.is_token_valid(verify_credentials=verify_credentials)

    cache_file = cache_manager._find_latest_cache_file()
    expires_at = None
    if cache_file:
        try:
            with open(cache_file, "r") as f:
                cache_data = json.load(f)
            expires_at = cache_data.get("expiresAt")
        except Exception:
            pass

    return SSOStatusResponse(
        exists=cache_file is not None,
        valid=is_valid,
        expires_at=expires_at,
        profile=profile
    )


@router.post("/clear-cache", response_model=SSOLoginResponse)
async def clear_sso_cache():
    """
    Clear AWS SSO cache files to force fresh authentication.

    This deletes all cache files in ~/.aws/sso/cache/ directory.

    Returns:
        SSOLoginResponse with status and message.
    """
    settings = get_settings()
    profile = settings.AWS_PROFILE

    if not profile:
        raise HTTPException(
            status_code=400,
            detail="AWS_PROFILE not configured in .env",
        )

    logger.info(f"API: Clearing AWS SSO cache for profile: {profile}")

    cache_manager = AWSSSOCache(
        profile_name=profile,
        region=settings.AWS_REGION,
    )

    result = cache_manager.clear_sso_cache()

    if result["status"] == "error":
        raise HTTPException(status_code=500, detail=result["message"])

    return SSOLoginResponse(**result)
