"""
@file settings.py
@author caoshwen
@brief Settings management API endpoints.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import os
import re
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request
from pydantic import BaseModel, Field

from app.core.config import (
    AGENT_LLM_IDS,
    build_claude_router_model_map,
    get_settings,
    get_resolved_cli_path,
    normalize_api_base,
    resolve_claude_cli_model,
    resolve_bedrock_default_model,
)
from app.core.env_file import read_env_file, update_env_file

router = APIRouter()

ENV_FILE = Path(__file__).parent.parent.parent.parent.parent / ".env"


# ---------- Utility functions ----------

def _read_env() -> dict[str, str]:
    """Read decoded values so subsequent runtime reloads preserve passwords."""
    return read_env_file(ENV_FILE)


def _write_env(values: dict[str, str]) -> None:
    """Share atomic writes with application and global email configuration."""
    update_env_file(ENV_FILE, values)


def _mask_key(key: Optional[str]) -> str:
    """API Key redaction: only show first 8 characters + ***"""
    if not key:
        return ""
    if len(key) <= 8:
        return "***"
    return key[:8] + "***"


def _sync_env_to_os(updates: dict[str, str]) -> None:
    """Sync updated configuration to os.environ so Pydantic BaseSettings can read the latest values.

    Pydantic BaseSettings reads from os.environ first, then .env file.
    If environment variables already exist in os.environ at process startup,
    updating only the .env file won't let new Settings() pick up the latest values,
    so os.environ must be updated in sync.
    """
    from app.infrastructure.observability.logger import LoggerService
    log = LoggerService.get_logger("system")

    for k, v in updates.items():
        if v:  # Set if non-empty
            old_val = os.environ.get(k, "<not set>")
            os.environ[k] = v
            log.debug(f"Synced {k}: {old_val} -> {'***' if 'KEY' in k or 'SECRET' in k else v}")
        elif k in os.environ:  # Clear if empty value
            old_val = os.environ.pop(k)
            log.debug(f"Cleared {k}")


# ---------- Internal tools ----------

async def _reinit_llm_bridge(request: Request) -> None:
    """Rebuild LLMBridge and mount it to app.state.

    Configuration is read from .env file (most reliable source of truth),
    avoiding inconsistencies caused by lru_cache / os.environ synchronization.
    """
    from app.llm.bridge import LLMBridge
    from app.llm.providers import (
        BedrockProvider,
        ClaudeCLIProvider,
    )
    from app.infrastructure.observability.logger import LoggerService

    log = LoggerService.get_logger("system")
    log.info("=== Starting LLMBridge reinitialization ===")

    old_bridge = getattr(request.app.state, "llm_bridge", None)

    # Sync all LLM-related values from .env to os.environ so get_settings() can see latest values
    env = _read_env()
    for k, v in env.items():
        if v:
            os.environ[k] = v
        elif k in os.environ:
            os.environ.pop(k)

    # Clear get_settings() cache so next call will reload current values
    get_settings.cache_clear()
    s = get_settings()

    bridge = LLMBridge(rate_limit_per_minute=s.LLM_RATE_LIMIT_PER_MINUTE)

    if s.AWS_PROFILE or (s.AWS_ACCESS_KEY_ID and s.AWS_SECRET_ACCESS_KEY):
        bridge.register_provider(BedrockProvider(
            region=s.AWS_REGION, profile_name=s.AWS_PROFILE,
            access_key_id=s.AWS_ACCESS_KEY_ID,
            secret_access_key=s.AWS_SECRET_ACCESS_KEY,
            default_model=resolve_bedrock_default_model(s),
        ))
    cli_model = resolve_claude_cli_model(s)
    log.info(f"Claude CLI: DEFAULT_PROVIDER={s.DEFAULT_PROVIDER}, resolved model={cli_model}")
    bridge.register_provider(ClaudeCLIProvider(
        cli_path=get_resolved_cli_path(),
        default_model=cli_model,
    ))

    # Initialize before publishing the bridge so requests cannot observe a
    # provider whose availability check is still pending.
    await bridge.initialize_all()
    from app.services.billing_service import get_billing_service
    bridge.register_usage_hook(get_billing_service().handle_usage_event)
    request.app.state.llm_bridge = bridge
    providers = bridge.list_providers()
    log.info(
        "=== LLMBridge reinitialized ===",
        provider_count=len(providers),
        providers=[provider["name"] for provider in providers],
    )

    if old_bridge is not None and old_bridge is not bridge:
        try:
            await old_bridge.shutdown_all()
            log.info("Old LLMBridge shut down successfully")
        except Exception as e:
            log.warning("Error shutting down old LLMBridge", error=str(e))

    if hasattr(request.app.state, "router_manager"):
        try:
            await request.app.state.router_manager.restart()
            log.info("Router restarted successfully")
        except Exception as e:
            log.warning("Error restarting Router", error=str(e))


# ---------- ENV JSON editor ----------

# List of sensitive keys, redacted when read
_SENSITIVE_KEYS = {
    "AWS_SECRET_ACCESS_KEY",
    "JIRA_TOKEN",
    "JIRA_API_TOKEN",
    "BITBUCKET_TOKEN",
    "BITBUCKET_APP_PASSWORD",
    "GIT_TOKEN",
    "SECRET_KEY",
    "TURING_API_KEY",
}


@router.get("/settings/env-json", summary="Read .env configuration in JSON format")
async def get_env_json() -> dict:
    """Read full .env configuration, sensitive fields are redacted"""
    env = _read_env()
    masked = {}
    # Non-sensitive keys that should never be masked
    _NON_SENSITIVE_KEYS = {"AWS_PROFILE", "AWS_REGION", "DEFAULT_PROVIDER"}

    for k, v in env.items():
        # Skip masking for explicitly non-sensitive keys
        if k.upper() in {"SMTP_PASSWORD", "APPROVAL_SMTP_PASSWORD", "COMPOSIO_API_KEY"}:
            masked[k] = "***" if v else ""
        elif k.upper() in _NON_SENSITIVE_KEYS:
            masked[k] = v
        elif k.upper() in _SENSITIVE_KEYS or "KEY" in k.upper() or "SECRET" in k.upper() or "TOKEN" in k.upper() or "PASSWORD" in k.upper():
            masked[k] = _mask_key(v)
        else:
            masked[k] = v
    return {"data": masked}


class EnvJsonUpdateRequest(BaseModel):
    data: dict[str, Optional[str]]


# List of fixed keys allowed for update
_ALLOWED_ENV_KEYS = {
    "ANTHROPIC_DEFAULT_OPUS_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL", "ANTHROPIC_DEFAULT_HAIKU_MODEL",
    "AWS_REGION", "AWS_PROFILE", "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "BEDROCK_DEFAULT_MODEL",
    "TURING_API_BASE", "TURING_API_KEY", "TURING_DEFAULT_MODEL",
    "CLAUDE_CODE_USE_BEDROCK",
    "DEFAULT_PROVIDER",
    "AGENT_LLM_CONFIG",
    "INTEGRATION_PROFILE",
    "JIRA_BASE_URL", "JIRA_EMAIL", "JIRA_API_TOKEN", "JIRA_DEPLOYMENT", "JIRA_PROJECT_KEY", "JIRA_ISSUE_TYPES",
    "BITBUCKET_BASE_URL", "BITBUCKET_USERNAME", "BITBUCKET_APP_PASSWORD", "BITBUCKET_DEPLOYMENT", "BITBUCKET_WORKSPACE",
    "GIT_PROVIDER", "GIT_BASE_URL", "GIT_REPOSITORY_PATH", "GIT_REPOSITORY_URL", "GIT_USERNAME", "GIT_TOKEN", "GIT_DEFAULT_BRANCH",
}

_LLM_ENV_KEYS = _ALLOWED_ENV_KEYS - {
    "INTEGRATION_PROFILE",
    "JIRA_BASE_URL", "JIRA_EMAIL", "JIRA_API_TOKEN", "JIRA_DEPLOYMENT", "JIRA_PROJECT_KEY", "JIRA_ISSUE_TYPES",
    "BITBUCKET_BASE_URL", "BITBUCKET_USERNAME", "BITBUCKET_APP_PASSWORD", "BITBUCKET_DEPLOYMENT", "BITBUCKET_WORKSPACE",
    "GIT_PROVIDER", "GIT_BASE_URL", "GIT_REPOSITORY_PATH", "GIT_REPOSITORY_URL", "GIT_USERNAME", "GIT_TOKEN", "GIT_DEFAULT_BRANCH",
}
_INTEGRATION_ENV_KEYS = _ALLOWED_ENV_KEYS - _LLM_ENV_KEYS

# URL type keys that need normalization
_URL_ENV_KEYS: set[str] = {
    "TURING_API_BASE", "JIRA_BASE_URL", "BITBUCKET_BASE_URL", "GIT_BASE_URL", "GIT_REPOSITORY_URL",
}

# Claude Router configuration file path
_ROUTER_CONFIG_FILE = Path(__file__).parent.parent.parent.parent.parent / "config" / "claude_router_config.json"


def _update_claude_router_config(env: dict[str, str], default_provider: str = "macode") -> None:
    """Update the Router projection without persisting API secrets."""
    from app.infrastructure.observability.logger import LoggerService
    log = LoggerService.get_logger("system")

    if _ROUTER_CONFIG_FILE.exists():
        try:
            with open(_ROUTER_CONFIG_FILE, "r", encoding="utf-8") as f:
                config = json.load(f)
        except Exception:
            config = {}
    else:
        config = {}

    config.setdefault("Router", {
        "default": "",
        "background": "",
        "endpoint": "http://127.0.0.1:8787",
    })
    config.setdefault("Settings", {
        "port": 8787, "host": "127.0.0.1", "timeout": 300,
        "retry_count": 3, "log_level": "info", "log_file": "logs/claude_router.log",
    })
    macode_base = normalize_api_base(env.get("TURING_API_BASE"))
    macode_model = (env.get("TURING_DEFAULT_MODEL") or "claude-sonnet-4-6").strip()
    # Keep every per-Agent Macode model in the Router projection.  Previously
    # only TURING_DEFAULT_MODEL was registered, so a CLI command such as
    # ``--model gpt-5.6-terra`` was silently remapped to the old global model
    # by ClaudeRouter._map_model().
    configured_macode_models: set[str] = set()
    if macode_model:
        configured_macode_models.add(macode_model)
    try:
        agent_config = json.loads(env.get("AGENT_LLM_CONFIG") or "{}")
    except (TypeError, json.JSONDecodeError):
        agent_config = {}
    if isinstance(agent_config, dict):
        for selection in agent_config.values():
            if not isinstance(selection, dict):
                continue
            if str(selection.get("provider") or "macode").strip().lower() != "macode":
                continue
            model = str(selection.get("model") or "").strip()
            if model:
                configured_macode_models.add(model)
    macode_models = build_claude_router_model_map(configured_macode_models)
    if macode_base and macode_model and env.get("TURING_API_KEY"):
        # The Router reads the key from the environment at runtime. Keeping it
        # out of this generated file prevents credentials from being persisted
        # in a tracked configuration artifact.
        config["Providers"] = [{
            "name": "macode",
            "base_url": macode_base,
            "models": macode_models,
        }]
    else:
        config["Providers"] = []
    config["Router"]["default"] = "macode" if default_provider == "macode" else ""

    _ROUTER_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(_ROUTER_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

    log.info(
        "Updated Claude Router provider projection",
        default_provider=default_provider,
        macode_configured=bool(config["Providers"]),
    )


@router.post("/settings/env-json", summary="Update .env configuration in JSON format")
async def update_env_json(body: EnvJsonUpdateRequest, request: Request) -> dict:
    """Write JSON data to .env file, only allowed to update fixed keys"""
    from app.infrastructure.observability.logger import LoggerService
    log = LoggerService.get_logger("system")

    updates: dict[str, str] = {}
    for k, v in body.data.items():
        if v is None:
            continue
        # Check if key is in the allowed list
        if k.upper() not in _ALLOWED_ENV_KEYS:
            continue
        # Skip masked placeholder values (containing ***), avoid overwriting real keys
        if "***" in str(v):
            log.debug(f"Skipping masked value for {k.upper()}")
            continue
        value = str(v).strip()
        if k.upper() in _URL_ENV_KEYS:
            value = normalize_api_base(value) or ""
        updates[k.upper()] = value

    log.info(f"update_env_json: Processing updates", keys=list(updates.keys()))

    if not updates:
        msg = "No valid configuration to update"
        log.info(msg)
        return {"message": msg, "count": 0}

    try:
        _write_env(updates)
        log.info(f"write_env completed successfully", keys=list(updates.keys()))
    except Exception as e:
        log.error(f"Failed to write .env", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to write config: {e}")

    # Rebuild only the runtime that owns the changed settings.
    if set(updates.keys()) & _LLM_ENV_KEYS:
        log.info(f"LLM config changed, reinitializing bridge")
        env = _read_env()
        _update_claude_router_config(env, env.get("DEFAULT_PROVIDER", "macode"))
        await _reinit_llm_bridge(request)
    else:
        log.info(f"No LLM config changes detected, skipping bridge reinit")

    if set(updates.keys()) & _INTEGRATION_ENV_KEYS:
        await _reinit_mcp_client(request)

    result = {"message": f"Updated {len(updates)} configuration items", "count": len(updates)}
    log.info("update_env_json completed", **result)
    return result


async def _reinit_mcp_client(request: Request) -> None:
    """Hot reload Jira and Bitbucket connections while retaining clients used by active tasks."""
    from app.core.config import get_settings
    from app.mcp.factory import create_mcp_client

    env = _read_env()
    for key, value in env.items():
        if value:
            os.environ[key] = value
        else:
            os.environ.pop(key, None)
    get_settings.cache_clear()
    client = create_mcp_client(get_settings())
    await client.initialize_all()

    old_client = getattr(request.app.state, "mcp_client", None)
    request.app.state.mcp_client = client
    if old_client is not None and old_client is not client:
        retired = getattr(request.app.state, "retired_mcp_clients", None)
        if retired is None:
            retired = []
            request.app.state.retired_mcp_clients = retired
        retired.append(old_client)


# ---------- Multi-Provider Settings API ----------

class AgentLLMSettings(BaseModel):
    """Provider and model assigned to one Agent."""

    provider: Literal["macode", "bedrock"] = "macode"
    model: str = Field(min_length=1, max_length=200)


class ProviderSettingsRequest(BaseModel):
    """Multi-provider configuration request body"""
    default_provider: Literal["macode", "bedrock"] = "macode"
    providers: dict[str, dict[str, Optional[str]]]
    agents: dict[str, AgentLLMSettings] = Field(default_factory=dict)


@router.post("/settings/providers", summary="Save multi-provider configuration")
async def save_provider_settings(
    body: ProviderSettingsRequest,
    request: Request,
) -> dict:
    """Save multi-provider configuration to .env, and automatically update claude_router_config.json.

    Hot reload workflow (no service restart needed):
    1. Write to .env immediately
    2. Call _reinit_llm_bridge() to hot-reload LLMBridge
    3. Claude Router restarts in background (non-blocking HTTP response)

    This does not affect other ongoing user sessions.
    """
    from app.infrastructure.observability.logger import LoggerService
    log = LoggerService.get_logger("system")

    log.info("save_provider_settings: received",
             default_provider=body.default_provider,
             provider_keys=list(body.providers.keys()),
             agent_keys=list(body.agents.keys()))

    unknown_agents = set(body.agents) - set(AGENT_LLM_IDS)
    if unknown_agents:
        raise HTTPException(
            status_code=422,
            detail=f"Unsupported Agent LLM settings: {', '.join(sorted(unknown_agents))}",
        )

    updates: dict[str, str] = {}

    # Map frontend provider key -> .env key
    _PROVIDER_ENV_MAP = {
        "bedrock": {
            "aws_region": "AWS_REGION",
            "aws_profile": "AWS_PROFILE",
            "aws_access_key_id": "AWS_ACCESS_KEY_ID",
            "aws_secret_access_key": "AWS_SECRET_ACCESS_KEY",
            "default_model": "ANTHROPIC_DEFAULT_SONNET_MODEL",
        },
        "macode": {
            "api_base": "TURING_API_BASE",
            "api_key": "TURING_API_KEY",
            "default_model": "TURING_DEFAULT_MODEL",
        },
    }

    for provider_key, fields in body.providers.items():
        env_map = _PROVIDER_ENV_MAP.get(provider_key)
        if not env_map:
            continue
        for field_key, env_key in env_map.items():
            value = (fields.get(field_key) or "").strip()
            if "***" in value:
                continue
            if not value and env_key not in {"AWS_PROFILE"}:
                continue
            if env_key in _URL_ENV_KEYS:
                value = normalize_api_base(value) or value
            updates[env_key] = value
        if provider_key == "bedrock":
            default_model = (fields.get("default_model") or "").strip()
            if default_model and "***" not in default_model:
                updates["ANTHROPIC_DEFAULT_OPUS_MODEL"] = default_model
                updates["ANTHROPIC_DEFAULT_SONNET_MODEL"] = default_model
                updates["ANTHROPIC_DEFAULT_HAIKU_MODEL"] = default_model
                updates["BEDROCK_DEFAULT_MODEL"] = default_model

    updates["CLAUDE_CODE_USE_BEDROCK"] = (
        "1" if body.default_provider == "bedrock" else "0"
    )

    # Save default_provider marker
    updates["DEFAULT_PROVIDER"] = body.default_provider
    if body.agents:
        updates["AGENT_LLM_CONFIG"] = json.dumps(
            {
                agent_type: config.model_dump()
                for agent_type, config in body.agents.items()
            },
            separators=(",", ":"),
        )

    log.info("save_provider_settings: env updates", keys=list(updates.keys()))

    if not updates:
        return {"message": "No valid configuration to update", "count": 0}

    # 1. Update claude_router_config.json first (does not trigger reload)
    current_env = _read_env()
    merged_env = {**current_env, **updates}
    _update_claude_router_config(merged_env, body.default_provider)

    # 2. Write to .env immediately (no delay)
    try:
        _write_env(updates)
        log.info("save_provider_settings: .env written successfully")
    except Exception as e:
        log.error("Failed to write .env", error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to write config: {e}")

    # 3. Hot-reload LLMBridge (no service restart needed)
    log.info("save_provider_settings: hot-reloading LLMBridge")
    await _reinit_llm_bridge(request)

    return {
        "message": f"Saved {len(updates)} settings. LLMBridge reloaded successfully (hot reload).",
        "count": len(updates),
        "default_provider": body.default_provider,
        "agents": {
            agent_type: config.model_dump()
            for agent_type, config in body.agents.items()
        },
    }
