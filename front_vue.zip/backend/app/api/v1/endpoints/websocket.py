"""
@file websocket.py
@author caoshwen
@brief WebSocket endpoint for real-time streaming.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import uuid

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from loguru import logger

from app.core.ws_manager import ws_manager
from app.core.database import async_session_factory
from app.core.security import decode_token
from app.core.billing_context import reset_billing_user_id, set_billing_user_id
from app.services.billing_service import enforce_billing
from app.agents.impl import (
    ChatAgent,
    UnitTestAgent,
    DriverAgent,
    BuildAgent,
    BugFixAgent,
    DebugAgent,
    ReviewAgent,
)
from app.orchestration.chat_workflow import ChatOrchestratorWorkflow
from app.repositories.task import TaskRepository
from app.repositories.driver_conversation import DriverConversationRepository

router = APIRouter()


async def _authenticate_ws(websocket: WebSocket) -> dict | None:
    """
    WebSocket authentication.

    Read an access token from the connection query before accepting.
    """
    token = websocket.query_params.get("token")
    if token:
        try:
            payload = decode_token(token)
            if payload.get("type") != "access" or not payload.get("sub") or not payload.get("user_id"):
                return None
            return {"username": payload.get("sub"), "user_id": payload.get("user_id")}
        except Exception:
            return None
    return None


async def _can_stream_task(task_id: str, user_id: str) -> bool:
    """Check persisted ownership without holding a database session during streaming."""
    async with async_session_factory() as db:
        task = await TaskRepository(db).get_by_id(task_id)
        if task is not None:
            return task.user_id == user_id
        driver_task = await DriverConversationRepository(db, user_id=user_id).get_task(task_id)
        return driver_task is not None


@router.websocket("/ws/stream/{task_id}")
async def websocket_task_stream(websocket: WebSocket, task_id: str):
    """
    WebSocket endpoint: Subscribe to task progress and stream output.

    Message types (server -> client):
    - {"type": "progress", "task_id": ..., "progress": 0-100, "stage": ..., "message": ...}
    - {"type": "stream", "task_id": ..., "content": "...", "is_final": false}
    - {"type": "complete", "task_id": ..., "result": {...}}
    - {"type": "error", "task_id": ..., "error": "..."}

    Message types (client -> server):
    - {"type": "cancel"}: Return guidance for the Agent's cancellation endpoint
    - {"type": "ping"}: Heartbeat
    """
    user = await _authenticate_ws(websocket)
    if websocket.query_params.get("token") and user is None:
        await websocket.close(code=1008)
        return
    user_id = user["user_id"] if user else "anonymous"
    try:
        if not await _can_stream_task(task_id, user_id):
            await websocket.close(code=1008)
            return
    except Exception as error:
        logger.warning("Could not verify task stream ownership: {}", type(error).__name__)
        await websocket.close(code=1011)
        return

    await ws_manager.connect(task_id, websocket)

    try:
        await websocket.send_json({
            "type": "connected",
            "task_id": task_id,
            "message": "Connected to task stream",
        })

        while True:
            try:
                raw = await websocket.receive_text()
                data = json.loads(raw)
                msg_type = data.get("type", "")

                if msg_type == "cancel":
                    await websocket.send_json({
                        "type": "error",
                        "task_id": task_id,
                        "error": "Use the Agent cancellation endpoint to cancel this task. The task is still being observed.",
                    })

                elif msg_type == "ping":
                    await websocket.send_json({"type": "pong"})

            except json.JSONDecodeError:
                await websocket.send_json({
                    "type": "error",
                    "error": "Invalid JSON message",
                })

    except WebSocketDisconnect:
        logger.debug(f"Task {task_id} WebSocket disconnected")
    except Exception as e:
        logger.error(f"Task {task_id} WebSocket error: {e}")
    finally:
        await ws_manager.disconnect(task_id, websocket)


@router.websocket("/ws/chat/{session_id}")
async def websocket_chat_stream(websocket: WebSocket, session_id: str):
    """
    WebSocket endpoint: Real-time conversation stream output.

    Provides real streaming Agent response via ChatOrchestratorWorkflow.run_stream().

    Client sends:
    - {"type": "message", "content": "User input", "agent": "chat"}

    Server pushes:
    - {"type": "processing", "message": "Processing..."}
    - {"type": "progress", "stage": ..., "message": ...}
    - {"type": "stream", "content": "Partial content", "is_final": false}
    - {"type": "complete", "task_id": ..., "response": ..., "metadata": ...}
    - {"type": "error", "error": "..."}
    """
    user = await _authenticate_ws(websocket)
    if websocket.query_params.get("token") and user is None:
        await websocket.close(code=1008)
        return
    user_id = user["user_id"] if user else "guest"
    session_manager = websocket.app.state.session_manager
    try:
        session = await session_manager.get_session(session_id)
        if session and session.get("user_id") != user_id:
            await websocket.close(code=1008)
            return
        if not session:
            # Allocate a server-owned ID instead of claiming an arbitrary client ID.
            session_id = await session_manager.create_session(user_id=user_id)
    except Exception as error:
        logger.warning("Could not verify chat stream ownership: {}", type(error).__name__)
        await websocket.close(code=1011)
        return

    await websocket.accept()

    try:
        await websocket.send_json({
            "type": "connected",
            "session_id": session_id,
            "message": "Connected to chat stream",
        })

        while True:
            try:
                raw = await websocket.receive_text()
                data = json.loads(raw)
                msg_type = data.get("type", "")

                if msg_type == "message":
                    content = data.get("content", "")
                    agent_hint = data.get("agent")
                    history = data.get("history", [])

                    if not content.strip():
                        await websocket.send_json({
                            "type": "error",
                            "error": "Message content cannot be empty",
                        })
                        continue

                    # An expired or removed session must not be recreated without ownership.
                    session = await session_manager.get_session(session_id)
                    if not session or session.get("user_id") != user_id:
                        await websocket.close(code=1008)
                        return
                    try:
                        await enforce_billing({"id": user_id, "username": user["username"] if user else "guest"})
                    except HTTPException as error:
                        await websocket.send_json({"type": "error", "error": error.detail})
                        continue

                    await websocket.send_json({
                        "type": "processing",
                        "message": "Processing...",
                    })

                    # Get dependencies from app.state
                    app = websocket.app
                    llm_bridge = app.state.llm_bridge
                    mcp_client = app.state.mcp_client
                    session_manager = app.state.session_manager
                    skill_registry = getattr(app.state, "skill_registry", None)

                    # Instantiate Agent collection
                    agents = {
                        "chat": ChatAgent(llm_bridge, mcp_client, skill_registry),
                        "unittest": UnitTestAgent(llm_bridge, mcp_client, skill_registry),
                        "driver": DriverAgent(llm_bridge, mcp_client, skill_registry),
                        "build": BuildAgent(llm_bridge, mcp_client, skill_registry),
                        "bugfix": BugFixAgent(llm_bridge, mcp_client, skill_registry),
                        "debug": DebugAgent(llm_bridge, mcp_client, skill_registry),
                        "review": ReviewAgent(llm_bridge, mcp_client, skill_registry),
                    }

                    workflow = ChatOrchestratorWorkflow(
                        llm_bridge=llm_bridge,
                        session_manager=session_manager,
                        agents=agents,
                    )

                    # Stream execution and push each chunk
                    billing_token = set_billing_user_id(user_id)
                    try:
                        async for chunk in workflow.run_stream(
                            message=content,
                            session_id=session_id,
                            user_id=user_id,
                            agent_hint=agent_hint,
                            history=history,
                        ):
                            await websocket.send_json(chunk)
                    finally:
                        reset_billing_user_id(billing_token)

                elif msg_type == "ping":
                    await websocket.send_json({"type": "pong"})

            except json.JSONDecodeError:
                await websocket.send_json({
                    "type": "error",
                    "error": "Invalid JSON message",
                })

    except WebSocketDisconnect:
        logger.debug(f"Session {session_id} chat WebSocket disconnected")
    except Exception as e:
        logger.error(f"Session {session_id} chat WebSocket error: {e}")
        await websocket.close(code=1011)
