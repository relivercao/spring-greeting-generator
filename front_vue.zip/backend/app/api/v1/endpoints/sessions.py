"""
@file sessions.py
@author caoshwen
@brief Session management API endpoints.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.models.session import Message, Session
from app.schemas.session import (
    MessageResponse,
    SessionCreateRequest,
    SessionListResponse,
    SessionResponse,
)

router = APIRouter()


@router.post("/", response_model=SessionResponse, status_code=201)
async def create_session(
    request: SessionCreateRequest,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Create new session"""
    session = Session(
        id=str(uuid.uuid4()),
        user_id=current_user["id"],
        title=request.title,
        agent_type=request.agent_type,
    )
    db.add(session)
    await db.flush()
    await db.refresh(session)
    return session


@router.get("/", response_model=SessionListResponse)
async def list_sessions(
    agent_type: str | None = Query(None, description="Filter by Agent type"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """List all sessions for current user"""
    query = select(Session).where(Session.user_id == current_user["id"])
    count_query = select(func.count()).select_from(Session).where(Session.user_id == current_user["id"])

    if agent_type:
        query = query.where(Session.agent_type == agent_type)
        count_query = count_query.where(Session.agent_type == agent_type)

    query = query.order_by(Session.updated_at.desc()).offset(offset).limit(limit)

    result = await db.execute(query)
    sessions = result.scalars().all()

    count_result = await db.execute(count_query)
    total = count_result.scalar() or 0

    return SessionListResponse(
        sessions=[SessionResponse.model_validate(s) for s in sessions],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get("/{session_id}", response_model=SessionResponse)
async def get_session(
    session_id: str,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Get session details"""
    result = await db.execute(
        select(Session).where(
            Session.id == session_id,
            Session.user_id == current_user["id"],
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session


@router.get("/{session_id}/messages", response_model=list[MessageResponse])
async def get_session_messages(
    session_id: str,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Get session message history"""
    # First verify session ownership
    session_result = await db.execute(
        select(Session.id).where(
            Session.id == session_id,
            Session.user_id == current_user["id"],
        )
    )
    if not session_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Session not found")

    result = await db.execute(
        select(Message)
        .where(Message.session_id == session_id)
        .order_by(Message.created_at.asc())
        .offset(offset)
        .limit(limit)
    )
    messages = result.scalars().all()
    return [MessageResponse.model_validate(m) for m in messages]


@router.delete("/{session_id}")
async def delete_session(
    session_id: str,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete session and all its messages"""
    result = await db.execute(
        select(Session).where(
            Session.id == session_id,
            Session.user_id == current_user["id"],
        )
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    await db.delete(session)
    return {"success": True, "message": "Session deleted"}
