"""
@file debug.py
@author caoshwen
@brief Debug analysis Agent API endpoint.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
import uuid

from fastapi import APIRouter, Depends, Request
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.models.task import Task
from app.schemas.debug import DebugRequest
from app.agents.impl import DebugAgent
from app.agents.impl.debug_agent import DebugContext
from app.agents.base import AgentStatus
from app.services.agent_task_runtime import (
    agent_task_registry,
    complete_task,
    fail_task,
    mark_task_cancelled,
    serialize_agent_result,
    serialize_task,
    task_usage_for_agent,
    update_task_progress,
)
from app.services.billing_service import enforce_billing

router = APIRouter()
_running_tasks = agent_task_registry


async def _run_debug_task(
    task_id: str,
    agent: DebugAgent,
    task_desc: str,
    context: DebugContext,
):
    """Execute a debug task with durable progress and cancellation semantics."""
    try:
        async for update in agent.stream_execute(task_desc, context):
            if update.stage not in {"completed", "failed", "cancelled"}:
                await update_task_progress(task_id, update.progress, update.stage, update.message, update.details)
        result = agent.get_status(task_id)
        if result is None:
            raise RuntimeError("Debug task completed without an Agent result")
        result_data = serialize_agent_result(result)
        result_data["token_usage"] = task_usage_for_agent(agent, task_id)
        await complete_task(result, result_data)
    except asyncio.CancelledError:
        await mark_task_cancelled(task_id, "Debug task cancelled")
    except Exception as error:
        logger.error(f"Debug task {task_id} failed: {error}", exc_info=True)
        await fail_task(task_id, str(error))
    finally:
        _running_tasks.remove(task_id)


@router.post("/debug")
async def debug_analyze(
    request: DebugRequest,
    raw_request: Request,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Analyze crash and debug information"""
    await enforce_billing(current_user)
    llm_bridge = raw_request.app.state.llm_bridge
    mcp_client = raw_request.app.state.mcp_client

    task_id = str(uuid.uuid4())

    # Create database task record
    task = Task(
        id=task_id,
        user_id=current_user["id"],
        agent_type="debug",
        status="running",
        progress=0,
        message="Debug analysis task started",
        input_data=json.dumps(request.model_dump(), ensure_ascii=False),
    )
    db.add(task)
    await db.flush()

    # Instantiate Agent and build context
    agent = DebugAgent(llm_bridge, mcp_client, getattr(raw_request.app.state, "skill_registry", None))
    context = DebugContext(
        task_id=task_id,
        user_id=current_user["id"],
        project_root=request.project_root,
        crash_description=request.crash_description,
        log_files=request.log_files,
    )

    # Commit before scheduling the independent worker session. A fast debug
    # result must not be dropped because the request transaction is pending.
    await db.commit()

    task_desc = f"Debug analysis: {request.crash_description[:100]}"

    # Execute in background
    background_task = asyncio.create_task(_run_debug_task(task_id, agent, task_desc, context), name=task_id)
    _running_tasks.register(task_id, background_task, agent)

    return {
        "task_id": task_id,
        "status": "running",
        "message": "Debug analysis task created and started",
    }


async def _get_debug_task(task_id: str, current_user: dict, db: AsyncSession) -> Task:
    """Load a debug task belonging to the current user."""
    from sqlalchemy import select
    result = await db.execute(select(Task).where(Task.id == task_id, Task.user_id == current_user["id"]))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "debug":
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Debug task not found")
    return task


@router.get("/debug/tasks/{task_id}")
async def get_debug_task(task_id: str, current_user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    """Return the current debug task state."""
    task = await _get_debug_task(task_id, current_user, db)
    return serialize_task(task)


@router.post("/debug/tasks/{task_id}/cancel")
async def cancel_debug_task(task_id: str, current_user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    """Cancel a running debug task."""
    task = await _get_debug_task(task_id, current_user, db)
    if task.status == AgentStatus.RUNNING.value:
        await _running_tasks.cancel(task_id)
        await mark_task_cancelled(task_id, "Debug task cancelled")
        await db.refresh(task)
    return serialize_task(task)
