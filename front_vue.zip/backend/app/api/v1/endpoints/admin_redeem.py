"""Admin console API endpoints for redeem code management.

Lists invitation / promotional codes with pagination and an optional
type filter, and batch-generates new codes. Generated codes use the
``MAC`` prefix plus 8 uppercase hex characters from ``secrets``; each
row records the creating administrator and an optional expiry derived
from ``expires_days``.
"""

import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Query

from app.core.security import get_current_admin_user
from app.models.redeem_code import RedeemCode
from app.models.user import User
from app.repositories import RedeemCodeRepository, get_redeem_code_repo
from app.schemas.admin import AdminListOut, RedeemCodeCreateIn, RedeemCodeOut

router = APIRouter(dependencies=[Depends(get_current_admin_user)])

# Code format: "MAC" + 8 uppercase hex characters (secrets.token_hex(4)).
CODE_PREFIX = "MAC"


@router.get("", response_model=AdminListOut[RedeemCodeOut])
async def list_redeem_codes(
    code_type: Optional[str] = Query(
        None, pattern="^(invitation|promo)$", description="Filter by code type"
    ),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    code_repo: RedeemCodeRepository = Depends(get_redeem_code_repo),
):
    """List redeem codes (optionally filtered by type), newest first."""
    filters = []
    if code_type:
        filters.append(RedeemCode.code_type == code_type)
    total = await code_repo.count(filters=filters)
    codes = await code_repo.get_all(
        filters=filters,
        order_by=RedeemCode.created_at.desc(),
        limit=page_size,
        offset=(page - 1) * page_size,
    )
    return AdminListOut[RedeemCodeOut](
        items=[RedeemCodeOut.model_validate(code) for code in codes],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.post("", response_model=list[RedeemCodeOut], status_code=201)
async def create_redeem_codes(
    payload: RedeemCodeCreateIn,
    admin: User = Depends(get_current_admin_user),
    code_repo: RedeemCodeRepository = Depends(get_redeem_code_repo),
):
    """Batch-generate redeem codes attributed to the current admin."""
    expires_at: Optional[datetime] = None
    if payload.expires_days is not None:
        expires_at = datetime.now(timezone.utc) + timedelta(days=payload.expires_days)
    rows = [
        RedeemCode(
            code=f"{CODE_PREFIX}{secrets.token_hex(4).upper()}",
            code_type=payload.code_type,
            bonus_amount=payload.bonus_amount,
            max_uses=payload.max_uses,
            expires_at=expires_at,
            is_active=True,
            created_by=admin.id,
        )
        for _ in range(payload.count)
    ]
    created = await code_repo.batch_create(rows)
    return [RedeemCodeOut.model_validate(code) for code in created]
