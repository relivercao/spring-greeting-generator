"""Authenticated, user-owned official Feishu CLI bot configuration."""

from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.api.v1.endpoints.email_settings import EmailSettingsRoute
from app.core.database import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.models.feishu import FeishuMessageReceipt
from app.services.app_connections import AppConnectionError
from app.services.feishu_cli import FeishuCLI, resolved_cli_path
from app.services.feishu_connections import get_connection, mark_verified, public_configuration, save_connection
from app.services.feishu_lease import configuration_guard, listener_owned

router = APIRouter(prefix="/connected-apps/feishu", route_class=EmailSettingsRoute)


class FeishuConfiguration(BaseModel):
    model_config = ConfigDict(extra="forbid")
    app_id: str = Field(pattern=r"^cli_[A-Za-z0-9_-]{1,96}$")
    app_secret: SecretStr | None = Field(default=None, max_length=2048)
    brand: Literal["feishu", "lark"] = "feishu"
    allowed_sender_ids: list[str] = Field(min_length=1, max_length=20)

    @field_validator("allowed_sender_ids")
    @classmethod
    def valid_senders(cls, values):
        import re
        if any(not re.fullmatch(r"ou_[A-Za-z0-9_-]{1,120}", value) for value in values):
            raise ValueError("Authorized senders must be Feishu open_id values starting with ou_.")
        return sorted(set(values))

    @field_validator("app_secret")
    @classmethod
    def valid_secret(cls, value):
        if value is not None and (not value.get_secret_value().strip() or any(
            char.isspace() for char in value.get_secret_value()
        )):
            raise ValueError("App Secret must be a nonempty single-line value; omit it to keep the saved secret.")
        return value


async def owner(db, user):
    record = await db.get(User, user["id"])
    if record is None or not record.is_active:
        raise HTTPException(401, "An active platform account is required.")
    return record.id


async def runtime(request: Request, user_id: str) -> dict:
    manager = getattr(request.app.state, "feishu_listener_manager", None)
    return await manager.snapshot(user_id) if manager else {
        "status": "unavailable", "cli_available": resolved_cli_path() is not None,
        "error": "The Feishu listener service is not running.", "pending_messages": 0,
    }


def manager_for(request: Request):
    manager = getattr(request.app.state, "feishu_listener_manager", None)
    if manager is None:
        raise HTTPException(503, "The Feishu listener service is not running.")
    return manager


async def configuration_access(user=Depends(get_current_active_user)):
    try:
        async with configuration_guard(user["id"]):
            yield
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.get("/config")
async def configuration(request: Request, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    user_id = await owner(db, user)
    result = public_configuration(await get_connection(db, user_id), await runtime(request, user_id))
    receipts = await db.scalars(select(FeishuMessageReceipt).where(
        FeishuMessageReceipt.user_id == user_id,
    ).order_by(FeishuMessageReceipt.created_at.desc()).limit(5))
    result["recent_messages"] = [{"id": item.id, "status": item.status,
        "created_at": item.created_at.isoformat(), "error": item.error} for item in receipts]
    return result


@router.put("/config", dependencies=[Depends(configuration_access)])
async def save_configuration(body: FeishuConfiguration, request: Request,
                             user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    user_id = await owner(db, user)
    manager = getattr(request.app.state, "feishu_listener_manager", None)
    if (manager and await manager.busy(user_id)) or await listener_owned(user_id):
        raise HTTPException(409, "Stop the listener and wait for its active request to finish before editing.")
    try:
        connection = await save_connection(
            db, user_id, app_id=body.app_id,
            app_secret=body.app_secret.get_secret_value() if body.app_secret is not None else None,
            brand=body.brand, allowed_sender_ids=body.allowed_sender_ids,
        )
        return public_configuration(connection, await runtime(request, user_id))
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.post("/check", dependencies=[Depends(configuration_access)])
async def check_configuration(request: Request, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    connection = await get_connection(db, await owner(db, user))
    if connection is None:
        raise HTTPException(409, "Save the Feishu bot configuration first.")
    try:
        result = await FeishuCLI(connection).check()
        await mark_verified(db, connection)
        return result
    except AppConnectionError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.post("/start", dependencies=[Depends(configuration_access)])
async def start_listener(request: Request, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    user_id = await owner(db, user)
    manager = manager_for(request)
    connection = await get_connection(db, user_id)
    if connection is None or not connection.verified_at:
        raise HTTPException(409, "Save and check the Feishu bot before starting the listener.")
    if await manager.busy(user_id):
        raise HTTPException(409, "The listener is already running or finishing a request.")
    connection.enabled = True
    await db.commit()
    try:
        await manager.start(connection)
    except AppConnectionError as error:
        connection.enabled = False
        await db.commit()
        raise HTTPException(error.status_code, str(error)) from error
    return public_configuration(connection, await runtime(request, user_id))


@router.post("/stop", dependencies=[Depends(configuration_access)])
async def stop_listener(request: Request, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    user_id = await owner(db, user)
    manager = manager_for(request)
    connection = await get_connection(db, user_id)
    if connection:
        connection.enabled = False
        await db.commit()
    manager.stop(user_id)
    return public_configuration(connection, await runtime(request, user_id))


@router.delete("/config", dependencies=[Depends(configuration_access)])
async def delete_configuration(request: Request, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    user_id = await owner(db, user)
    manager = getattr(request.app.state, "feishu_listener_manager", None)
    if (manager and await manager.busy(user_id)) or await listener_owned(user_id):
        raise HTTPException(409, "Stop the listener and wait for its active request to finish before disconnecting.")
    connection = await get_connection(db, user_id)
    if connection and connection.enabled:
        raise HTTPException(409, "Stop the listener before disconnecting the bot.")
    if connection:
        await db.delete(connection)
        await db.commit()
    return {"deleted_count": int(connection is not None)}
