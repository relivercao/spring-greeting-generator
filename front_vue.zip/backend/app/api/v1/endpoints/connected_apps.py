"""User-facing application connection APIs."""

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.feishu_tools import FEISHU_APP
from app.services.feishu_connections import get_connection
from app.services.connection_catalog import oauth_catalog

from app.core.security import get_current_active_user, get_current_admin_user
from app.services.app_connection_settings import provider_configuration, save_provider_configuration
from app.services.app_connections import AppConnectionError, AppConnectionsService

router = APIRouter()


class ConnectRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    return_path: str = Field(default="/", max_length=2048)


class ProviderConfigurationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    api_key: str | None = Field(default=None, max_length=2048)
    api_base_url: str = Field(max_length=2048)
    app_frontend_base_url: str | None = Field(default=None, max_length=2048)
    frontend_base_url: str | None = Field(default=None, max_length=2048)
    auth_configs: dict[str, str]


def _raise_http_error(error: AppConnectionError) -> None:
    raise HTTPException(status_code=error.status_code, detail=str(error)) from error


@router.get("/connected-apps/provider")
async def get_provider_configuration(_admin=Depends(get_current_admin_user)) -> dict:
    """Return server configuration without returning the provider secret."""
    return provider_configuration()


@router.put("/connected-apps/provider")
async def update_provider_configuration(
    request: ProviderConfigurationRequest,
    http_request: Request,
    _admin=Depends(get_current_admin_user),
) -> dict:
    try:
        return await save_provider_configuration(
            **request.model_dump(),
            trusted_http_origin=http_request.headers.get("origin"),
        )
    except AppConnectionError as error:
        _raise_http_error(error)


@router.get("/connected-apps")
async def list_connected_apps(
    current_user: dict[str, Any] = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
) -> dict[str, Any]:
    """Return the application directory and this user's connection states."""
    try:
        catalog = await oauth_catalog(AppConnectionsService(), current_user["id"])
        connection = await get_connection(db, current_user["id"])
        connected = bool(connection and connection.verified_at)
        catalog["apps"].append({**FEISHU_APP, "configured": True, "connected": connected,
            "has_account": connection is not None, "account_count": int(connection is not None),
            "connection_status": "ACTIVE" if connected else "NOT_CONNECTED"})
        return catalog
    except AppConnectionError as error:
        _raise_http_error(error)


@router.post("/connected-apps/{app_slug}/connect")
async def create_connected_app_link(
    app_slug: str,
    request: ConnectRequest,
    current_user: dict[str, Any] = Depends(get_current_active_user),
) -> dict[str, str]:
    """Create a hosted OAuth authorization link for the current user."""
    try:
        return await AppConnectionsService().create_link(
            current_user["id"], app_slug, request.return_path
        )
    except AppConnectionError as error:
        _raise_http_error(error)


@router.delete("/connected-apps/{app_slug}")
async def disconnect_app(
    app_slug: str,
    current_user: dict[str, Any] = Depends(get_current_active_user),
) -> dict[str, int]:
    """Revoke all of this user's connected accounts for one application."""
    try:
        return await AppConnectionsService().disconnect(current_user["id"], app_slug)
    except AppConnectionError as error:
        _raise_http_error(error)


__all__ = ["router"]
