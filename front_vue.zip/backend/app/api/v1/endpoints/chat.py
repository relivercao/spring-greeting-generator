"""
@file chat.py
@author caoshwen
@brief Chat API endpoint with intelligent Agent routing.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import time
import uuid
from datetime import timedelta
from typing import Optional
from urllib.parse import quote

from fastapi import APIRouter, File, Form, Request, HTTPException, UploadFile
from fastapi.responses import FileResponse
from loguru import logger

from app.core.security import get_optional_user_from_request
from app.schemas.chat import ChatRequest
from app.services.billing_service import enforce_billing
from app.services.chat_artifacts import ChatArtifactService, artifact_media_type
from app.services.chat_attachments import cleanup_chat_attachments, read_chat_attachments
from app.agents.impl import (
    ChatAgent,
    UnitTestAgent,
    DriverAgent,
    BuildAgent,
    BugFixAgent,
    DebugAgent,
    ReviewAgent,
    KnowledgeBaseAgent,
)
from app.orchestration.chat_workflow import ChatOrchestratorWorkflow
from app.llm.base import LLMError
from app.llm.error_mapping import http_exception_for_llm_error
from app.core.config import get_settings
from app.mcp.servers.connected_apps_server import ConnectedAppsMCPServer

router = APIRouter()


@router.get("/chat/artifacts/{owner_hash}/{session_hash}/{artifact_id}/{filename}")
async def open_chat_artifact(
    owner_hash: str,
    session_hash: str,
    artifact_id: str,
    filename: str,
    expires: Optional[int] = None,
    signature: Optional[str] = None,
    download: bool = False,
):
    """Open or download a generated Chat document through its durable link."""
    service = ChatArtifactService.from_settings()
    path = service.resolve_signed_artifact(
        owner_hash=owner_hash,
        session_hash=session_hash,
        artifact_id=artifact_id,
        filename=filename,
        expires=expires,
        signature=signature,
    )
    if path is None:
        raise HTTPException(status_code=404, detail="Chat document not found")

    safe_filename = quote(filename, safe="")
    disposition = "attachment" if download else "inline"
    headers = {
        "Content-Disposition": f"{disposition}; filename=\"{filename}\"; filename*=UTF-8''{safe_filename}",
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "no-referrer",
        "Cache-Control": "private, no-store",
    }
    if path.suffix.lower() in {".html", ".htm", ".doc"}:
        headers["Content-Security-Policy"] = "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:"
    return FileResponse(path, media_type=artifact_media_type(filename), headers=headers)


def _is_chat_cli_using_bedrock(agent_type: str = "chat") -> bool:
    """Check whether the selected Agent routes its Claude CLI through Bedrock."""
    from app.core.config import get_settings, resolve_agent_llm_selection
    settings = get_settings()
    if not hasattr(settings, "DEFAULT_PROVIDER"):
        return settings.CLAUDE_CODE_USE_BEDROCK.strip().lower() in {"1", "true", "yes"}
    return resolve_agent_llm_selection(agent_type).provider == "bedrock"


def _get_optional_user(request: Request) -> dict:
    """Extract user from Bearer token, return guest if missing or invalid."""
    try:
        return get_optional_user_from_request(request, "guest")
    except HTTPException:
        return {"id": "guest", "username": "guest"}


# Frontend agent ID -> backend AgentType mapping
_FRONTEND_AGENT_MAP = {
    "fw_chatbot": "chat",
    "chat": "chat",
    "mcu_config": "chat",    # MCU Config is handled via chat
    "rag": "knowledge",
    "knowledge": "knowledge",
    "driver_dev": "driver",
    "code_review": "review",
    "unittest": "unittest",
    "bugfix": "bugfix",
    "debug": "debug",
    "build": "build",
    "review": "review",
    "driver": "driver",
    "image_generation": "image_generation",
    "cad": "cad",
}


def _resolve_agent_hint(frontend_agent: str) -> str:
    """Map the frontend selection to the backend Agent type."""
    return _FRONTEND_AGENT_MAP.get(frontend_agent, frontend_agent)


@router.get("/chat/sessions")
async def list_chat_sessions(
    raw_request: Request,
    limit: int = 20,
):
    """List current user/Guest's session list (read from Redis, supports Guest)"""
    current_user = _get_optional_user(raw_request)
    session_manager = raw_request.app.state.session_manager
    sessions = await session_manager.list_user_sessions(
        user_id=current_user["id"], limit=limit
    )
    return {"sessions": sessions}


@router.post("/chat")
async def chat(
    request: ChatRequest,
    raw_request: Request,
):
    """Chat conversation - processed via ChatOrchestratorWorkflow (supports Guest)"""
    return await _run_chat(request, raw_request)


@router.post("/chat/with-files")
async def chat_with_files(
    raw_request: Request,
    files: list[UploadFile] = File(...),
    agent: str = Form(default="chat"),
    message: str = Form(default="Analyze the attached files."),
    session_id: Optional[str] = Form(default=None),
):
    """Analyze bounded uploaded files through the existing Chat CLI provider."""
    if _FRONTEND_AGENT_MAP.get(agent, agent) != "chat":
        raise HTTPException(400, "File analysis is available in the Chat Agent only")
    attachments = await read_chat_attachments(files)
    request = ChatRequest(
        agent=agent,
        message=message.strip() or "Analyze the attached files.",
        session_id=session_id,
        web_search_enabled=False,
    )
    # Attachment analysis is private, even when the ordinary search preference is enabled.
    try:
        return await _run_chat(request, raw_request, attachments=attachments)
    finally:
        await asyncio.to_thread(cleanup_chat_attachments, attachments)


async def _run_chat(request: ChatRequest, raw_request: Request, attachments: Optional[list[dict]] = None):
    """Share ownership, billing, provider selection, and execution for both transports."""
    current_user = _get_optional_user(raw_request)
    await enforce_billing(current_user)

    if _FRONTEND_AGENT_MAP.get(request.agent) == "image_generation":
        raise HTTPException(
            status_code=400,
            detail="Use the image generation task endpoint for image requests",
        )

    # Chat always uses Claude CLI. AWS SSO is only required when the CLI is
    # explicitly configured for direct Bedrock access instead of local Router mode.
    selected_agent_type = _FRONTEND_AGENT_MAP.get(request.agent, "chat")
    if _is_chat_cli_using_bedrock(selected_agent_type):
        # AWS SSO authentication check (same as unittest endpoint)
        from app.core.aws_sso_cache import AWSSSOCache
        from app.core.config import get_settings

        settings = get_settings()
        profile = settings.AWS_PROFILE
        region = settings.AWS_REGION

        if not profile:
            logger.error("AWS_PROFILE not configured")
            raise HTTPException(
                status_code=500,
                detail="AWS Profile is not configured. Please configure a valid AWS_PROFILE in Provider Settings and try again."
            )

        cache = AWSSSOCache(profile_name=profile, region=region)

        # Validate that the Profile exists
        sso_start_url = cache._get_sso_start_url()
        if not sso_start_url:
            logger.error(f"AWS Profile '{profile}' not found in ~/.aws/config")
            raise HTTPException(
                status_code=500,
                detail=f"AWS_PROFILE_INVALID: AWS Profile '{profile}' does not exist. Please enter a valid AWS_PROFILE in Provider Settings and try again."
            )

        # Fast check: only verify SSO token file exists and not expired (~0.1s)
        # Don't call aws sts here to avoid blocking user (5-10s delay)
        if not cache.is_token_valid(verify_credentials=False):
            logger.warning("Chat blocked: AWS SSO token not valid or missing")
            raise HTTPException(
                status_code=401,
                detail="AWS_AUTH_REQUIRED: AWS credentials expired or missing. Please login again."
            )
    else:
        logger.info("Skipping AWS SSO validation - Chat Claude CLI is using Router mode")

    llm_bridge = raw_request.app.state.llm_bridge
    mcp_client = raw_request.app.state.mcp_client
    session_manager = raw_request.app.state.session_manager
    skill_registry = getattr(raw_request.app.state, "skill_registry", None)
    connected_apps = None
    if current_user["id"] not in {"guest", "anonymous", "unknown"}:
        connected_apps = ConnectedAppsMCPServer(current_user["id"])

    # Instantiate all Agents
    agents = {
        "chat": ChatAgent(llm_bridge, mcp_client, skill_registry, connected_apps=connected_apps),
        "unittest": UnitTestAgent(llm_bridge, mcp_client, skill_registry),
        "driver": DriverAgent(llm_bridge, mcp_client, skill_registry),
        "build": BuildAgent(llm_bridge, mcp_client, skill_registry),
        "bugfix": BugFixAgent(llm_bridge, mcp_client, skill_registry),
        "debug": DebugAgent(llm_bridge, mcp_client, skill_registry),
        "review": ReviewAgent(llm_bridge, mcp_client, skill_registry),
        "knowledge": KnowledgeBaseAgent(
            llm_bridge=llm_bridge,
            skill_registry=skill_registry,
        ),
    }

    workflow = ChatOrchestratorWorkflow(
        llm_bridge=llm_bridge,
        session_manager=session_manager,
        agents=agents,
    )

    user_id = current_user["id"]

    # Ensure session is registered in SessionManager
    if request.session_id:
        session_id = request.session_id
        # Initialize if session hash does not exist
        try:
            existing = await session_manager.get_session(session_id)
            if existing and existing.get("user_id") != user_id:
                raise HTTPException(status_code=403, detail="This conversation belongs to another account.")
            if not existing:
                now = time.time()
                agent_type_str = _FRONTEND_AGENT_MAP.get(request.agent, "chat")
                await session_manager._cache.hset(f"session:{session_id}", {
                    "user_id": user_id,
                    "agent_type": agent_type_str,
                    "title": "New Session",
                    "created_at": str(now),
                    "updated_at": str(now),
                    "message_count": "0",
                    "messages": "[]",
                    "summary": "",
                })
                await session_manager._cache.expire(
                    f"session:{session_id}", timedelta(days=7)
                )
                await session_manager._cache.zadd(
                    f"user_sessions:{user_id}", {session_id: now}
                )
        except HTTPException:
            raise
        except Exception as error:
            logger.warning("Could not verify conversation ownership: {}", type(error).__name__)
            raise HTTPException(status_code=503, detail="Conversation history is temporarily unavailable.") from error
    else:
        # New session: created by SessionManager and return ID
        try:
            session_id = await session_manager.create_session(
                user_id=user_id,
                agent_type=_FRONTEND_AGENT_MAP.get(request.agent, "chat"),
                title="New Session",
            )
        except Exception:
            session_id = str(uuid.uuid4())

    # Honor the Agent selected by the frontend, including ChatAgent. This avoids
    # an unnecessary LLM classification call for every explicit chat request.
    agent_hint = _resolve_agent_hint(request.agent)

    try:
        result = await workflow.run(
            message=request.message,
            session_id=session_id,
            user_id=user_id,
            agent_hint=agent_hint,
            history=request.history,
            metadata={**(request.context or {}), "chat_attachments": attachments or []},
            web_search_enabled=request.web_search_enabled and not attachments,
        )
        return result
    except HTTPException:
        # Re-raise HTTPException from workflow (e.g., AWS auth errors)
        raise
    except LLMError as e:
        mapped_error = http_exception_for_llm_error(e)
        if mapped_error:
            raise mapped_error
        raise HTTPException(status_code=503, detail="The configured LLM provider failed")
