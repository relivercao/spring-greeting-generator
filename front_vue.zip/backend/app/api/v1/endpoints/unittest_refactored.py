"""
@file unittest_refactored.py
@brief Refactored unit test generation API endpoints using service layer.

This is a simplified version that demonstrates how to use the new service layer
and workflow orchestration. It maintains the same API contract as the original
unittest.py but with much cleaner architecture.

@version 3.4
@date 2026-07-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""

import asyncio
import json
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, Request, Query
from fastapi.responses import FileResponse
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_optional_user_from_request
from app.models.task import Task
from app.services.unittest import (
    TaskService,
    ValidationService,
    FileService,
    LogParserService,
)
from app.services.deps import (
    get_owned_unittest_task,
    get_task_service,
    get_validation_service,
    get_file_service,
    get_log_parser_service,
)
from app.orchestration.unittest_workflow import (
    UnitTestWorkflow,
    UnitTestWorkflowContext,
)
from app.orchestration.deps import get_unittest_workflow
from app.services.base import ResourceNotFoundError, ValidationError as ServiceValidationError, AuthorizationError


router = APIRouter()


def _get_optional_user(request: Request) -> dict:
    """Get current user or return anonymous user."""
    return get_optional_user_from_request(request, "anonymous")


# Global state for background tasks
#
# Current implementation: Tasks are tracked in a module-level dictionary for cancellation support.
# This works for single-server deployments but has limitations:
#
# Limitations:
# 1. Not shared across multiple server instances (horizontal scaling)
# 2. Lost on server restart (no persistence)
# 3. Memory leak potential if tasks aren't cleaned up
#
# Future improvement: Move to TaskService with Redis/Database backing
# Benefits of moving to TaskService:
# - Centralized task lifecycle management
# - Persistence across restarts
# - Support for distributed deployments
# - Better cleanup and monitoring
# - Audit trail of all task state changes
#
# Migration path:
# 1. Add `running_task_ref` field to Task model (store asyncio.Task reference)
# 2. Add `TaskService.register_background_task(task_id, asyncio_task)` method
# 3. Add `TaskService.cancel_background_task(task_id)` method
# 4. Add `TaskService.cleanup_completed_tasks()` periodic cleanup
# 5. Migrate cancellation endpoints to use TaskService methods
#
# For now, keeping this simple implementation for compatibility with existing cancel endpoint.
_running_tasks: dict[str, asyncio.Task] = {}


# ==================== ROUTES ====================


@router.post("/generate-tests")
async def generate_tests(
    request: Request,
    file: list[UploadFile] = File(..., description="Source file list"),
    layer: str = Form(default="auto", description="Layer: auto/hal/driver/controller/app"),
    framework: str = Form(default="gtest", description="Test framework: gtest/unity"),
    target_coverage: float = Form(default=90.0, ge=0, le=100, description="Target coverage"),
    max_iterations: int = Form(default=5, ge=1, le=10, description="Maximum iterations"),
    output_dir: Optional[str] = Form(default=None, description="Custom output directory"),
    source_full_path: Optional[str] = Form(default=None, description="Full path to source file"),
    task_title: Optional[str] = Form(default=None, description="Task title"),
    source_filename: Optional[str] = Form(default=None, description="Source filename"),
    # Services
    task_service: TaskService = Depends(get_task_service),
    validation_service: ValidationService = Depends(get_validation_service),
    file_service: FileService = Depends(get_file_service),
    workflow: UnitTestWorkflow = Depends(get_unittest_workflow),
):
    """
    Generate unit tests using service layer and workflow orchestration.

    This is a refactored version that:
    - Uses ValidationService for input validation
    - Uses TaskService for task management
    - Uses FileService for file operations
    - Uses UnitTestWorkflow for orchestration

    Returns task_id immediately and executes in background.
    """

    # 1. Get user
    user = _get_optional_user(request)
    user_id = user.get("id", "anonymous")

    # 2. Validate inputs
    if not file:
        raise HTTPException(status_code=400, detail="No files uploaded")

    try:
        # Validate first file upload
        first_file_content = await file[0].read()
        await file[0].seek(0)  # Reset for later use

        validation_service.validate_file_upload(
            file_content=first_file_content,
            filename=file[0].filename or "unknown.c",
            max_size_mb=10,
        )

        # Validate parameters
        params = validation_service.validate_test_generation_params(
            layer=layer if layer != "auto" else "hal",
            framework=framework,
            target_coverage=str(target_coverage / 100),  # Convert to 0.0-1.0
            max_iterations=str(max_iterations),
        )

    except ServiceValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # 3. Create task
    try:
        task_metadata = {
            "task_title": task_title or (file[0].filename if file else "Unnamed Task"),
            "source_filename": source_filename or (file[0].filename if file else ""),
            "source_full_path": source_full_path or "",
            "output_dir": output_dir or "",
            "layer": params["layer"],
            "framework": params["framework"],
            "target_coverage": params["target_coverage"],
            "max_iterations": params["max_iterations"],
        }

        task = await task_service.create_task(
            user_id=user_id,
            agent_type="unittest",
            input_data=task_metadata,
        )

    except Exception as e:
        logger.exception("Failed to create task")
        raise HTTPException(status_code=500, detail=f"Failed to create task: {e}")

    # 4. Save uploaded files
    try:
        saved_file_paths = []
        for uploaded_file in file:
            content = await uploaded_file.read()
            saved_path = await file_service.save_uploaded_file(
                file_content=content,
                filename=uploaded_file.filename or "unknown.c",
                task_id=task.id,
            )
            saved_file_paths.append(saved_path)

        task_metadata["source_files"] = saved_file_paths
        await task_service.store_input_data(task.id, task_metadata)

    except Exception as e:
        logger.exception(f"Failed to save uploaded files for task {task.id}")
        await task_service.mark_failed(
            task_id=task.id,
            error_message=f"Failed to save files: {e}",
        )
        raise HTTPException(status_code=500, detail=f"Failed to save files: {e}")

    # 5. Execute workflow in background
    background_task = asyncio.create_task(
        _run_workflow_background(
            workflow=workflow,
            task_id=task.id,
            source_files=saved_file_paths,
            params=params,
            output_dir=output_dir,
            user_id=user_id,
        )
    )

    # Store background task for cancellation support
    _running_tasks[task.id] = background_task

    # 6. Return immediately
    return {
        "task_id": task.id,
        "status": "running",
        "message": "Unit test generation started",
        "progress": 0,
    }


async def _run_workflow_background(
    workflow: UnitTestWorkflow,
    task_id: str,
    source_files: list[str],
    params: dict,
    output_dir: Optional[str] = None,
    user_id: str = "anonymous",
):
    """
    Run workflow in background and update task status.

    This function orchestrates the entire unittest generation process
    using the workflow and updates task status accordingly.

    The request-scoped services injected into the endpoint die with the
    HTTP response, so this coroutine opens its own DB session and builds
    fresh TaskService/FileService instances bound to it (same pattern as
    the driver endpoint's background runner).
    """
    from app.core.database import async_session_factory
    from app.services.unittest.file_service import FileService
    from app.services.unittest.task_service import TaskService

    try:
        async with async_session_factory() as db:
            task_service = TaskService(db)
            file_service = FileService(db)

            # Mark task as running
            await task_service.mark_running(
                task_id=task_id,
                message="Initializing unit test generation",
            )

            logger.info(f"Starting workflow for task {task_id}")

            # Get output directory
            if not output_dir:
                output_dir = await file_service.get_output_directory(task_id)

            # Create workflow context with actual user_id
            context = UnitTestWorkflowContext(
                workflow_id=task_id,
                user_id=user_id,
                source_file=source_files[0] if source_files else "",
                source_files=list(source_files),
                layer=params.get("layer", "hal"),
                framework=params.get("framework", "gtest"),
                target_coverage=params.get("target_coverage", 0.8),
                max_iterations=params.get("max_iterations", 5),
                output_dir=output_dir,
            )

            # Execute workflow
            logger.info(f"Executing workflow for task {task_id}")
            result = await workflow.execute(context)

            # Update task based on result
            if result.status.value == "completed":
                result_data = {
                    "generated_files": result.generated_files,
                    "coverage": result.coverage,
                    "test_results": result.test_results,
                }

                await task_service.mark_completed(
                    task_id=task_id,
                    message="Unit tests generated successfully",
                    result_data=result_data,
                )
                logger.info(f"Workflow completed for task {task_id}")

            else:
                error_message = result.message or "Workflow failed"
                # Preserve partial artifacts (generated files, coverage, test
                # output) from failed runs so users can inspect and resume.
                partial_data = {
                    key: value
                    for key, value in {
                        "generated_files": result.generated_files,
                        "coverage": result.coverage,
                        "test_results": result.test_results,
                    }.items()
                    if value
                }
                await task_service.mark_failed(
                    task_id=task_id,
                    error_message=error_message,
                    result_data=partial_data or None,
                )
                logger.error(f"Workflow failed for task {task_id}: {error_message}")

    except Exception as e:
        logger.exception(f"Workflow execution failed for task {task_id}")
        try:
            async with async_session_factory() as db:
                task_service = TaskService(db)
                await task_service.mark_failed(
                    task_id=task_id,
                    error_message=str(e),
                )
        except Exception as update_error:
            logger.exception(f"Failed to update task status: {update_error}")

    finally:
        # Cleanup background task reference
        _running_tasks.pop(task_id, None)


@router.get("/unittest/tasks/{task_id}")
async def get_unittest_task_status(
    task_id: str,
    task: Task = Depends(get_owned_unittest_task),
    task_service: TaskService = Depends(get_task_service),
):
    """
    Get task status and progress.

    Returns current task status, progress, and results.
    """
    try:
        # Parse result data
        result_data = task_service.get_result_data(task) or {}

        return {
            "task_id": task.id,
            "status": task.status,
            "progress": task.progress or 0,
            "message": task.message or "",
            "result": result_data,
            "error": task.error_message or "",
            "created_at": task.created_at.isoformat() if task.created_at else None,
            "updated_at": task.updated_at.isoformat() if task.updated_at else None,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Failed to get task status: {task_id}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/download/{task_id}/cli-log")
async def download_cli_log(
    task_id: str,
    download_token: Optional[str] = Query(default=None),
    request: Request = None,
    task_service: TaskService = Depends(get_task_service),
    validation_service: ValidationService = Depends(get_validation_service),
    file_service: FileService = Depends(get_file_service),
    log_parser_service: LogParserService = Depends(get_log_parser_service),
):
    """
    Download CLI log file for a task.

    Supports both authenticated access (task owner) and anonymous access
    (with download token).
    """
    try:
        # Get task
        task = await task_service.get_task_or_raise(task_id)

        # Check access permission
        user = _get_optional_user(request)
        try:
            validation_service.check_user_can_access_task(
                task=task,
                user_id=user.get("id", "anonymous"),
                download_token=download_token,
            )
        except AuthorizationError as e:
            raise HTTPException(status_code=403, detail=str(e))

        # Get log file path
        log_path = await file_service.get_cli_log_path(task_id)

        if not log_path:
            raise HTTPException(
                status_code=404,
                detail=f"CLI log not found for task {task_id}",
            )

        # Read and sanitize log content
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            log_content = f.read()

        sanitized_content = log_parser_service.sanitize_content(log_content)
        formatted_log = log_parser_service.format_log_for_download(
            output=sanitized_content,
            sanitize=False,  # Already sanitized
        )

        # Write to temporary file for download
        import tempfile
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".log",
            delete=False,
            encoding="utf-8",
        ) as tmp_file:
            tmp_file.write(formatted_log)
            tmp_path = tmp_file.name

        return FileResponse(
            path=tmp_path,
            media_type="text/plain",
            filename=f"unittest_{task_id}_cli.log",
        )

    except HTTPException:
        raise
    except ResourceNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception(f"Failed to download CLI log: {task_id}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/download/{task_id}/{file_type}")
async def download_file(
    task_id: str,
    file_type: str,
    download_token: Optional[str] = Query(default=None),
    request: Request = None,
    task_service: TaskService = Depends(get_task_service),
    validation_service: ValidationService = Depends(get_validation_service),
    file_service: FileService = Depends(get_file_service),
):
    """
    Download generated files (test, mock, etc.) for a task.

    Supported file_type: test, mock, report, header
    """
    try:
        # Get task
        task = await task_service.get_task_or_raise(task_id)

        # Check access permission
        user = _get_optional_user(request)
        try:
            validation_service.check_user_can_access_task(
                task=task,
                user_id=user.get("id", "anonymous"),
                download_token=download_token,
            )
        except AuthorizationError as e:
            raise HTTPException(status_code=403, detail=str(e))

        # Get file path
        file_path = await file_service.get_file_path(task_id, file_type)

        return FileResponse(
            path=file_path,
            media_type="application/octet-stream",
            filename=file_path.split("/")[-1],
        )

    except HTTPException:
        raise
    except ResourceNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception(f"Failed to download file: {task_id}/{file_type}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/unittest/tasks/{task_id}/cancel")
async def cancel_unittest_task(
    task_id: str,
    task: Task = Depends(get_owned_unittest_task),
    task_service: TaskService = Depends(get_task_service),
):
    """
    Cancel a running unittest task.
    """
    try:
        # Check if task is running
        if task.status != "running":
            raise HTTPException(
                status_code=400,
                detail=f"Task {task_id} is not running (status: {task.status})",
            )

        # Cancel background task if exists
        background_task = _running_tasks.get(task_id)
        if background_task and not background_task.done():
            background_task.cancel()
            _running_tasks.pop(task_id, None)

        # Mark task as cancelled
        await task_service.mark_cancelled(
            task_id=task_id,
            reason="Task cancelled by user",
        )

        return {
            "task_id": task_id,
            "status": "cancelled",
            "message": "Task cancelled successfully",
        }

    except HTTPException:
        raise
    except ResourceNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception(f"Failed to cancel task: {task_id}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/unittest/tasks/{task_id}/resume")
async def resume_unittest_task(
    task_id: str,
    task: Task = Depends(get_owned_unittest_task),
    task_service: TaskService = Depends(get_task_service),
    file_service: FileService = Depends(get_file_service),
    workflow: UnitTestWorkflow = Depends(get_unittest_workflow),
):
    """
    Resume a failed or cancelled unittest task.

    Note: This is a simplified implementation. Full resume logic may require
    storing more state about where the workflow stopped.
    """
    try:
        # Check if task can be resumed
        if task.status not in ("failed", "cancelled"):
            raise HTTPException(
                status_code=400,
                detail=f"Task {task_id} cannot be resumed (status: {task.status})",
            )

        # Restart from the original inputs, never from generated test files.
        try:
            metadata = json.loads(task.input_data or "{}")
        except (json.JSONDecodeError, TypeError):
            raise HTTPException(status_code=400, detail="Invalid saved task inputs")
        if not isinstance(metadata, dict):
            raise HTTPException(status_code=400, detail="Invalid saved task inputs")

        try:
            saved_files = await file_service.get_uploaded_source_files(
                task.id,
                source_files=metadata.get("source_files"),
                primary_filename=metadata.get("source_filename"),
            )
        except ServiceValidationError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        if not saved_files:
            raise HTTPException(
                status_code=400,
                detail="No source files found for resume",
            )

        # Resume by re-running workflow
        params = {
            "layer": metadata.get("layer", "hal"),
            "framework": metadata.get("framework", "gtest"),
            "target_coverage": metadata.get("target_coverage", 0.8),
            "max_iterations": metadata.get("max_iterations", 5),
        }

        # Commit before scheduling so a fast completion cannot be overwritten.
        await task_service.mark_running(task_id=task_id, message="Task resumed")

        # Execute workflow in background
        background_task = asyncio.create_task(
            _run_workflow_background(
                workflow=workflow,
                task_id=task.id,
                source_files=saved_files,
                params=params,
                output_dir=metadata.get("output_dir") or None,
                user_id=task.user_id,
            )
        )

        _running_tasks[task.id] = background_task

        return {
            "task_id": task_id,
            "status": "running",
            "message": "Task resumed successfully",
        }

    except HTTPException:
        raise
    except ResourceNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception(f"Failed to resume task: {task_id}")
        raise HTTPException(status_code=500, detail=str(e))
