"""Knowledge base ingestion and register-first query endpoints."""

import asyncio
import tempfile
from dataclasses import replace
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, File, Form, HTTPException, Query, Request, UploadFile

from app.schemas.knowledge_base import (
    KnowledgeAskRequest,
    KnowledgeAskResponse,
    KnowledgeChunkPreviewRequest,
    GitHubReferenceImportRequest,
    KnowledgeIngestResponse,
    KnowledgeRepositorySyncRequest,
    MkDocsBuildRequest,
    MarkdownIngestRequest,
    ObsidianVaultImportRequest,
    PdfConversionSummary,
    PdfIngestRequest,
)
from app.services.knowledge_base import KnowledgeBaseService
from app.services.knowledge_obsidian import KnowledgeObsidianImporter
from app.services.knowledge_publisher import KnowledgePublisher
from app.services.knowledge_reference import GitHubReferenceImporter
from app.services.knowledge_repository import KnowledgeRepository
from app.services.knowledge_answer import augment_knowledge_answer
from app.services.knowledge_context import (
    build_contextual_retrieval_question,
    normalize_knowledge_history,
)
from app.services.driver_docling_service import (
    DOCLING_SUPPORTED_EXTENSIONS,
    DriverDoclingService,
)
from app.services.pdf_knowledge import (
    DoclingNotAvailableError,
    DoclingPdfConverter,
    PdfConversionError,
    PdfConversionResult,
    PdfInputError,
)
from app.services.pdf_llm_ocr import PdfLlmOcrService
from app.services.lossless_reader import decode_bytes, from_text, read_path


router = APIRouter()
service = KnowledgeBaseService()
repository = KnowledgeRepository()
reference_importer = GitHubReferenceImporter(repository)
obsidian_importer = KnowledgeObsidianImporter(repository)
publisher = KnowledgePublisher(repository)
pdf_converter = DoclingPdfConverter()
_ALLOWED_TEXT_SUFFIXES = {".md", ".markdown", ".txt"}
_ALLOWED_UPLOAD_SUFFIXES = _ALLOWED_TEXT_SUFFIXES | DOCLING_SUPPORTED_EXTENSIONS
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024


@router.post("/knowledge/init")
@router.post("/admin/init")
async def initialize_knowledge_base() -> dict:
    """Initialize the derived SQLite index and rebuild it from canonical Markdown."""
    await asyncio.to_thread(service.initialize)
    try:
        totals = await asyncio.to_thread(repository.rebuild_index, service)
    except ValueError as error:
        raise HTTPException(
            status_code=422, detail=f"{error}. The previous knowledge index was preserved."
        ) from error
    publication = await asyncio.to_thread(_publish_repository)
    return {
        "ok": True,
        "db_path": str(service.db_path),
        "rebuild": totals,
        "publication": publication,
    }


def _read_source_path(source_path: str) -> str:
    """Read a local source path while rejecting missing or non-file inputs."""
    path = Path(source_path).expanduser()
    if not path.is_file():
        raise HTTPException(status_code=404, detail=f"Knowledge source file not found: {source_path}")
    try:
        # Read through the lossless line reader so CRLF/LF endings and blank
        # lines survive the conversion exactly as they appeared on disk.
        document = read_path(path)
        if not document.verify():
            raise HTTPException(status_code=422, detail="Knowledge source failed lossless line verification")
        return document.content
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=422, detail="Knowledge source must use UTF-8 encoding") from error


@router.post("/ingest/markdown", response_model=KnowledgeIngestResponse)
async def ingest_markdown_path(request: MarkdownIngestRequest) -> KnowledgeIngestResponse:
    """Ingest a Docling-generated Markdown file by local path."""
    markdown = await asyncio.to_thread(_read_source_path, request.path)
    result, repository_path, publication = await asyncio.to_thread(
        _persist_and_index,
        markdown,
        chip=request.chip.strip(),
        title=request.title.strip(),
        revision=request.revision.strip(),
        peripheral_hint=request.peripheral_hint.strip(),
        source_path=request.path,
        source_type="local-markdown",
        doc_type=request.doc_type.strip() or "reference",
        tags=request.tags,
    )
    return KnowledgeIngestResponse(
        document_id=result["document_id"],
        title=request.title,
        stats=result["stats"],
        repository_path=repository_path,
        publication=publication,
    )


def _ensure_lossless_conversion(conversion: PdfConversionResult) -> PdfConversionResult:
    """Attach line count and checksum even for legacy/custom converters."""
    lossless = from_text(conversion.markdown)
    if (
        conversion.source_lines == lossless.line_count
        and conversion.source_checksum == lossless.checksum
        and conversion.lossless_verified == lossless.verify()
    ):
        return conversion
    return replace(
        conversion,
        source_lines=lossless.line_count,
        source_checksum=lossless.checksum,
        lossless_verified=lossless.verify(),
    )


def _pdf_conversion_summary(conversion: PdfConversionResult) -> PdfConversionSummary:
    conversion = _ensure_lossless_conversion(conversion)
    return PdfConversionSummary(
        engine="docling+llm" if conversion.llm_ocr_pages else "docling",
        pages=conversion.pages,
        tables=conversion.tables,
        text_chars=conversion.text_chars,
        llm_ocr_pages=conversion.llm_ocr_pages,
        llm_ocr_chars=conversion.llm_ocr_chars,
        llm_ocr_provider=conversion.llm_ocr_provider,
        llm_ocr_model=conversion.llm_ocr_model,
        source_lines=conversion.source_lines,
        source_checksum=conversion.source_checksum,
        lossless_verified=conversion.lossless_verified,
        warnings=conversion.warnings,
        page_quality=conversion.page_quality,
    )


async def _apply_llm_ocr(
    request: Request,
    content: bytes,
    conversion: PdfConversionResult,
    *,
    enabled: bool,
) -> PdfConversionResult:
    """Enrich Docling output with the configured Knowledge Agent LLM."""
    if not enabled:
        return conversion
    bridge = getattr(request.app.state, "llm_bridge", None)
    enriched = await PdfLlmOcrService(bridge).enrich_bytes(
        content,
        conversion,
        enabled=True,
    )
    if enriched.text_chars == 0 and enriched.tables == 0:
        raise PdfConversionError(
            "Docling and LLM OCR did not extract searchable content from the PDF."
        )
    return enriched


def _persist_and_index(
    markdown: str,
    *,
    chip: str,
    title: str,
    revision: str,
    peripheral_hint: str,
    source_path: str,
    source_type: str,
    doc_type: str = "reference",
    tags: list[str] | None = None,
) -> tuple[dict[str, Any], str, dict[str, Any]]:
    """Write canonical Markdown first, then update the rebuildable SQLite index."""
    document = repository.upsert_document(
        markdown,
        chip=chip,
        title=title,
        revision=revision,
        peripheral_hint=peripheral_hint,
        source_type=source_type,
        source_path=source_path,
        doc_type=doc_type,
        tags=tags or [],
    )
    result = service.ingest_markdown(
        document.body,
        chip=chip,
        title=title,
        revision=revision,
        peripheral_hint=peripheral_hint,
        source_path=document.relative_path,
        replace_source=True,
        document_id=document.document_id,
    )
    return result, document.relative_path, _publish_repository()


def _publish_repository() -> dict[str, Any]:
    """Publish MkDocs after a canonical change and report failures explicitly."""
    local_url = f"http://127.0.0.1:{repository.settings.PORT}/knowledge-site/"
    if not repository.settings.KNOWLEDGE_AUTO_PUBLISH:
        return {
            "attempted": False,
            "ok": False,
            "local_url": local_url,
            "error": "",
        }
    try:
        result = publisher.build()
        return {
            "attempted": True,
            "ok": True,
            "local_url": str(result.get("local_url") or local_url),
            "error": "",
        }
    except RuntimeError as error:
        return {
            "attempted": True,
            "ok": False,
            "local_url": local_url,
            "error": str(error),
        }


def _ingest_pdf_conversion(
    conversion: PdfConversionResult,
    *,
    chip: str,
    title: str,
    revision: str,
    peripheral_hint: str,
    source_path: str,
    source_type: str,
    doc_type: str = "reference",
    tags: list[str] | None = None,
) -> KnowledgeIngestResponse:
    conversion = _ensure_lossless_conversion(conversion)
    result, repository_path, publication = _persist_and_index(
        conversion.markdown,
        chip=chip,
        title=title,
        revision=revision,
        peripheral_hint=peripheral_hint,
        source_path=source_path,
        source_type=source_type,
        doc_type=doc_type,
        tags=tags,
    )
    stats = {
        **result["stats"],
        "pages": conversion.pages,
        "tables": conversion.tables,
        "text_chars": conversion.text_chars,
        "source_lines": conversion.source_lines,
        "source_checksum": conversion.source_checksum,
        "lossless_verified": conversion.lossless_verified,
    }
    return KnowledgeIngestResponse(
        document_id=result["document_id"],
        title=title,
        stats=stats,
        conversion=_pdf_conversion_summary(conversion),
        repository_path=repository_path,
        publication=publication,
    )


def _convert_generic_docling_document(content: bytes, filename: str) -> tuple[str, dict[str, Any]]:
    """Convert one non-PDF Docling-supported upload in an isolated workspace."""
    with tempfile.TemporaryDirectory(prefix="knowledge-docling-") as temporary_dir:
        root = Path(temporary_dir)
        source_path = root / filename
        source_path.write_bytes(content)
        artifact_dir = root / "artifacts"
        result = asyncio.run(
            DriverDoclingService(upload_dir=root).parse_file(
                str(source_path),
                image_output_dir=artifact_dir,
            )
        )
    if result.get("error"):
        raise PdfConversionError(
            str(result.get("summary") or result.get("error") or "Docling conversion failed")
        )
    markdown = str(result.get("content") or "")
    if not markdown.strip():
        raise PdfConversionError("Docling did not extract searchable content from the document.")
    return markdown, dict(result.get("metadata") or {})


def _ingest_generic_docling_document(
    content: bytes,
    *,
    filename: str,
    chip: str,
    title: str,
    revision: str,
    peripheral_hint: str,
    doc_type: str,
    tags: list[str],
) -> KnowledgeIngestResponse:
    """Convert and index a DOCX/PPTX/XLSX/HTML/image knowledge document."""
    markdown, metadata = _convert_generic_docling_document(content, filename)
    lossless = from_text(markdown)
    result, repository_path, publication = _persist_and_index(
        markdown,
        chip=chip,
        title=title,
        revision=revision,
        peripheral_hint=peripheral_hint,
        source_path=filename,
        source_type="upload-docling",
        doc_type=doc_type,
        tags=tags,
    )
    stats = {
        **result["stats"],
        "pages": int(metadata.get("page_count") or 0),
        "tables": int(metadata.get("table_count") or 0),
        "text_chars": len(markdown),
        "source_lines": lossless.line_count,
        "source_checksum": lossless.checksum,
        "lossless_verified": lossless.verify(),
    }
    conversion = PdfConversionSummary(
        engine="docling",
        pages=stats["pages"],
        tables=stats["tables"],
        text_chars=stats["text_chars"],
        source_lines=stats["source_lines"],
        source_checksum=stats["source_checksum"],
        lossless_verified=stats["lossless_verified"],
    )
    return KnowledgeIngestResponse(
        document_id=result["document_id"],
        title=title,
        stats=stats,
        conversion=conversion,
        repository_path=repository_path,
        publication=publication,
    )


def _raise_pdf_http_error(error: Exception) -> None:
    if isinstance(error, DoclingNotAvailableError):
        raise HTTPException(status_code=424, detail=str(error)) from error
    if isinstance(error, (PdfInputError, PdfConversionError)):
        raise HTTPException(status_code=422, detail=str(error)) from error
    raise error


@router.post("/ingest/pdf")
async def ingest_pdf_path(request: PdfIngestRequest, http_request: Request) -> dict:
    """Convert a local PDF with Docling and ingest it into the knowledge base."""
    path = Path(request.path).expanduser()
    if not path.is_file():
        raise HTTPException(status_code=404, detail=f"PDF source file not found: {request.path}")
    if path.suffix.lower() != ".pdf":
        raise HTTPException(status_code=415, detail="The source path must reference a PDF file.")
    try:
        conversion = await asyncio.to_thread(
            pdf_converter.convert_path,
            path,
            no_ocr=request.no_ocr,
            allow_empty=request.llm_ocr,
        )
        if request.llm_ocr:
            content = await asyncio.to_thread(path.read_bytes)
            conversion = await _apply_llm_ocr(
                http_request,
                content,
                conversion,
                enabled=True,
            )
    except Exception as error:
        _raise_pdf_http_error(error)

    conversion_summary = _pdf_conversion_summary(conversion)
    if request.skip_extract:
        conversion = _ensure_lossless_conversion(conversion)
        return {
            "ok": True,
            "title": request.title.strip(),
            "stats": {
                "pages": conversion.pages,
                "tables": conversion.tables,
                "text_chars": conversion.text_chars,
                "source_lines": conversion.source_lines,
                "source_checksum": conversion.source_checksum,
                "lossless_verified": conversion.lossless_verified,
            },
            "conversion": conversion_summary.model_dump(),
        }

    response = await asyncio.to_thread(
        _ingest_pdf_conversion,
        conversion,
        chip=request.chip.strip(),
        title=request.title.strip(),
        revision=request.revision.strip(),
        peripheral_hint=request.peripheral_hint.strip(),
        source_path=str(path.resolve()),
        source_type="local-pdf",
        doc_type=request.doc_type.strip() or "reference",
        tags=request.tags,
    )
    return response.model_dump()


@router.post(
    "/knowledge/documents",
    response_model=KnowledgeIngestResponse,
)
async def ingest_knowledge_document(
    request: Request,
    file: UploadFile = File(...),
    chip: str = Form("GENERAL"),
    title: str = Form(""),
    revision: str = Form(""),
    peripheral_hint: str = Form(""),
    doc_type: str = Form("reference"),
    tags: Optional[list[str]] = Form(None),
    llm_ocr: bool = Form(True),
) -> KnowledgeIngestResponse:
    """Ingest PDF, Markdown, or text content into the knowledge base."""
    filename = Path(file.filename or "knowledge.md").name
    suffix = Path(filename).suffix.lower()
    if suffix not in _ALLOWED_UPLOAD_SUFFIXES:
        raise HTTPException(
            status_code=415,
            detail="Supported upload formats are PDF, DOCX, PPTX, XLSX, HTML, CSV, images, Markdown, and plain text.",
        )
    content = await file.read(_MAX_UPLOAD_BYTES + 1)
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Knowledge document exceeds 50 MB")
    normalized_chip = chip.strip() or "GENERAL"
    normalized_title = title.strip() or filename
    normalized_doc_type = doc_type.strip() or "reference"
    normalized_tags = tags or []

    if suffix == ".pdf":
        try:
            conversion = await asyncio.to_thread(
                pdf_converter.convert_bytes,
                content,
                filename=filename,
                allow_empty=llm_ocr,
            )
            conversion = await _apply_llm_ocr(
                request,
                content,
                conversion,
                enabled=llm_ocr,
            )
        except Exception as error:
            _raise_pdf_http_error(error)
        return await asyncio.to_thread(
            _ingest_pdf_conversion,
            conversion,
            chip=normalized_chip,
            title=normalized_title,
            revision=revision.strip(),
            peripheral_hint=peripheral_hint.strip(),
            source_path=filename,
            source_type="upload-pdf",
            doc_type=normalized_doc_type,
            tags=normalized_tags,
        )

    if suffix not in _ALLOWED_TEXT_SUFFIXES:
        try:
            return await asyncio.to_thread(
                _ingest_generic_docling_document,
                content,
                filename=filename,
                chip=normalized_chip,
                title=normalized_title,
                revision=revision.strip(),
                peripheral_hint=peripheral_hint.strip(),
                doc_type=normalized_doc_type,
                tags=normalized_tags,
            )
        except Exception as error:
            _raise_pdf_http_error(error)

    try:
        document = decode_bytes(content)
        if not document.verify():
            raise HTTPException(status_code=422, detail="Knowledge document failed lossless line verification")
        markdown = document.content
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=422, detail="Knowledge document must use UTF-8 encoding") from error

    result, repository_path, publication = await asyncio.to_thread(
        _persist_and_index,
        markdown,
        chip=normalized_chip,
        title=normalized_title,
        revision=revision.strip(),
        peripheral_hint=peripheral_hint.strip(),
        source_path=filename,
        source_type="upload-markdown",
        doc_type=normalized_doc_type,
        tags=normalized_tags,
    )
    return KnowledgeIngestResponse(
        document_id=result["document_id"],
        title=normalized_title,
        stats=result["stats"],
        repository_path=repository_path,
        publication=publication,
    )


@router.get("/knowledge/documents")
async def list_knowledge_documents() -> dict:
    """List canonical documents with derived SQLite index statistics."""
    indexed = {
        item["id"]: item
        for item in await asyncio.to_thread(service.list_documents)
    }
    documents = []
    for document in await asyncio.to_thread(repository.list_documents):
        item = document.to_dict()
        index_item = indexed.get(document.document_id, {})
        item.update(
            {
                "register_count": int(index_item.get("register_count", 0)),
                "bitfield_count": int(index_item.get("bitfield_count", 0)),
                "chunk_count": int(index_item.get("chunk_count", 0)),
                "source_lines": int(index_item.get("source_line_count", 0)),
                "lossless_verified": bool(index_item.get("lossless_verified", False)),
                "quality": index_item.get("quality", {}),
                "index_status": "ready" if document.document_id in indexed else "missing",
            }
        )
        documents.append(item)
    return {"documents": documents, "total": len(documents)}


@router.delete("/knowledge/documents/{document_id}")
async def delete_knowledge_document(document_id: str) -> dict:
    """Delete the canonical Markdown document and its derived index rows."""
    deleted = await asyncio.to_thread(repository.delete_document, document_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Knowledge document not found")
    await asyncio.to_thread(service.delete_document, document_id)
    publication = await asyncio.to_thread(_publish_repository)
    return {
        "ok": True,
        "document_id": document_id,
        "publication": publication,
    }


@router.get("/knowledge/repository/status")
async def knowledge_repository_status() -> dict:
    """Return canonical repository, Git, MkDocs, and Wiki.js status."""
    result = await asyncio.to_thread(repository.status)
    result["publisher"] = await asyncio.to_thread(publisher.status)
    result["local_preview_url"] = (
        f"http://127.0.0.1:{repository.settings.PORT}/knowledge-site/"
    )
    result["obsidian_default_path"] = repository.settings.KNOWLEDGE_OBSIDIAN_VAULT_DIR
    return result


@router.post("/knowledge/repository/sync")
async def sync_knowledge_repository(request: KnowledgeRepositorySyncRequest) -> dict:
    """Pull or push canonical Markdown and rebuild the derived index."""
    try:
        result = await asyncio.to_thread(
            repository.sync,
            pull=request.pull,
            push=request.push,
        )
        if request.rebuild_index:
            result["rebuild"] = await asyncio.to_thread(repository.rebuild_index, service)
        result["publication"] = await asyncio.to_thread(_publish_repository)
        return result
    except RuntimeError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error


@router.post("/knowledge/references/github")
async def import_github_reference(request: GitHubReferenceImportRequest) -> dict:
    """Clone a public GitHub project and import its Markdown docs as references."""
    try:
        result = await asyncio.to_thread(
            reference_importer.import_repository,
            request.repository,
            ref=request.ref,
            chip=request.chip.strip(),
            revision=request.revision.strip(),
            doc_type=request.doc_type.strip(),
            tags=request.tags,
            max_documents=request.max_documents,
        )
        result["rebuild"] = await asyncio.to_thread(repository.rebuild_index, service)
        result["publication"] = await asyncio.to_thread(_publish_repository)
        return result
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    except RuntimeError as error:
        raise HTTPException(status_code=502, detail=str(error)) from error


@router.post("/knowledge/obsidian/import")
async def import_obsidian_vault(request: ObsidianVaultImportRequest) -> dict:
    """Import Markdown notes from a local Obsidian vault."""
    try:
        result = await asyncio.to_thread(
            obsidian_importer.import_vault,
            request.path,
            chip=request.chip.strip(),
            revision=request.revision.strip(),
            doc_type=request.doc_type.strip(),
            tags=request.tags,
            include_globs=request.include_globs,
            exclude_globs=request.exclude_globs,
            max_documents=request.max_documents,
        )
        if request.rebuild_index:
            result["rebuild"] = await asyncio.to_thread(
                repository.rebuild_index,
                service,
            )
        result["publication"] = await asyncio.to_thread(_publish_repository)
        return result
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error


@router.post("/knowledge/publish/mkdocs")
async def publish_knowledge_mkdocs(request: MkDocsBuildRequest) -> dict:
    """Build the static MkDocs human-readable interface."""
    try:
        return await asyncio.to_thread(
            publisher.build,
            strict=request.strict,
            clean=request.clean,
        )
    except RuntimeError as error:
        raise HTTPException(status_code=424, detail=str(error)) from error


@router.get("/knowledge/registers/search")
@router.get("/registers/search")
async def search_knowledge_registers(
    chip: Optional[str] = None,
    peripheral: Optional[str] = None,
    register: Optional[str] = None,
    address: Optional[str] = None,
    bit: Optional[int] = None,
    field: Optional[str] = None,
    document_id: Optional[str] = None,
    limit: int = Query(default=20, ge=1, le=100),
) -> dict:
    """Search structured register and bitfield facts."""
    results = await asyncio.to_thread(
        service.search_registers,
        chip=chip,
        peripheral=peripheral,
        register=register,
        address=address,
        bit=bit,
        field=field,
        document_id=document_id,
        limit=limit,
    )
    return {"count": len(results), "results": results}


@router.post("/knowledge/chunks/preview")
async def preview_knowledge_chunks(request: KnowledgeChunkPreviewRequest) -> dict[str, Any]:
    """Preview structure-aware chunks without writing documents or embeddings."""
    return await asyncio.to_thread(
        service.preview_chunks,
        request.text,
        max_chars=request.max_chars,
    )


@router.get("/knowledge/registers/{register_id}")
@router.get("/registers/{register_id}")
async def get_knowledge_register(register_id: str) -> dict:
    """Return one register and its bitfields."""
    result = await asyncio.to_thread(service.get_register, register_id)
    if not result:
        raise HTTPException(status_code=404, detail="Register not found")
    return result


@router.post("/knowledge/ask", response_model=KnowledgeAskResponse)
@router.post("/ask", response_model=KnowledgeAskResponse)
async def ask_knowledge_base(
    request: KnowledgeAskRequest,
    http_request: Request,
) -> KnowledgeAskResponse:
    """Retrieve with recent conversation context and answer from canonical knowledge."""
    history = normalize_knowledge_history(
        [item.model_dump() for item in request.history]
    )
    retrieval_question = build_contextual_retrieval_question(
        request.question,
        history,
    )
    retrieval = await asyncio.to_thread(
        service.ask,
        retrieval_question,
        chip=request.chip,
        document_id=request.document_id,
        limit=request.limit,
        retrieval_mode=request.retrieval_mode,
    )
    result = await augment_knowledge_answer(
        request.question,
        retrieval,
        getattr(http_request.app.state, "llm_bridge", None),
        use_llm=request.use_llm,
        document_id=request.document_id,
        repository=repository,
        conversation_history=history,
    )
    return KnowledgeAskResponse(**result)
