"""
@file project_detection.py
@author zhangjian
@brief Project root detection API endpoints.
Detect project root by walking upward from a source file path.

@version 3.3
@date 2026-04-07

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""
from typing import Optional
from pydantic import BaseModel
from fastapi import APIRouter, HTTPException
from loguru import logger

from app.agents.impl.unittest.paths import find_project_root_for_source, detect_project_membership


router = APIRouter()


class DetectProjectRootRequest(BaseModel):
    """Request schema for project root detection."""
    source_path: str
    current_project_root: Optional[str] = None


class DetectProjectRootResponse(BaseModel):
    """Response schema for project root detection."""
    detected_root: Optional[str]
    success: bool
    message: str


class ProjectMembershipResponse(BaseModel):
    """Response schema for project membership detection."""
    status: str
    detected_root: Optional[str]
    markers: list[str]
    success: bool
    message: str


@router.post("/detect-project-root", response_model=DetectProjectRootResponse, summary="Detect project root from source path")
async def detect_project_root(request: DetectProjectRootRequest):
    """
    Detect the project root by walking upward from the given source file/directory path,
    looking for standard project root markers (.git, CMakeLists.txt, Makefile, etc.).

    Args:
        request: DetectProjectRootRequest containing source_path and optional current_project_root

    Returns:
        DetectProjectRootResponse with detected_root, success status, and message
    """
    if not request.source_path or not request.source_path.strip():
        raise HTTPException(status_code=400, detail="source_path cannot be empty")

    try:
        detected_root = find_project_root_for_source(request.source_path)

        if detected_root:
            return DetectProjectRootResponse(
                detected_root=detected_root,
                success=True,
                message=f"Project root detected successfully: {detected_root}"
            )
        else:
            return DetectProjectRootResponse(
                detected_root=None,
                success=False,
                message="No project root marker found. Please check the input path."
            )

    except Exception as e:
        logger.error(f"Failed to detect project root for path '{request.source_path}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error detecting project root: {str(e)}")


@router.post("/detect-project-membership", response_model=ProjectMembershipResponse, summary="Detect project membership for source path")
async def detect_project_membership_endpoint(request: DetectProjectRootRequest):
    """
    Determine whether the source_path belongs to the current project, an external project,
    or is a standalone file.

    Args:
        request: DetectProjectRootRequest containing source_path and optional current_project_root

    Returns:
        ProjectMembershipResponse with status, detected_root, markers found, etc.
    """
    if not request.source_path or not request.source_path.strip():
        raise HTTPException(status_code=400, detail="source_path cannot be empty")

    try:
        result = detect_project_membership(
            source_path=request.source_path,
            current_project_root=request.current_project_root
        )

        return ProjectMembershipResponse(
            status=result["status"],
            detected_root=result["detected_root"],
            markers=result["markers"],
            success=True,
            message=f"Project membership detected: {result['status']}"
        )

    except Exception as e:
        logger.error(f"Failed to detect project membership for path '{request.source_path}': {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error detecting project membership: {str(e)}")


@router.get("/health", summary="Health check for project detection endpoint")
async def health_check():
    """Health check endpoint."""
    return {"status": "ok", "service": "project_detection"}
