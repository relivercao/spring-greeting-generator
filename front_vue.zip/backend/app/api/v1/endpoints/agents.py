"""
@file agents.py
@author caoshwen
@brief Agent management API endpoints.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from fastapi import APIRouter
from app.agents.catalog import AGENT_REGISTRY

router = APIRouter()


@router.get("/")
async def list_agents():
    """List all available Agents"""
    return {"agents": AGENT_REGISTRY, "total": len(AGENT_REGISTRY)}


@router.get("/{agent_id}")
async def get_agent_info(agent_id: str):
    """Get detailed information of specified Agent"""
    for agent in AGENT_REGISTRY:
        if agent["id"] == agent_id:
            return agent
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail=f"Agent '{agent_id}' not found")
