"""
@file payment.py
@brief Authenticated user payment endpoints (checkout, orders, ledger).

Thin gateway: every route resolves the JWT subject back to a full User
row (401 when the account is gone) and delegates to the payment
service layer; no business logic lives here.

"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.repositories.user import UserRepository
from app.schemas.payment import (
    CheckoutInfoOut,
    OrderCreateRequest,
    OrderListOut,
    OrderOut,
    TransactionListOut,
)
from app.services.payment import payment_service

router = APIRouter()


async def _current_user_row(
    current_user: dict,
    db: AsyncSession,
) -> User:
    """Resolve the JWT identity to a live, active User row."""
    user = await UserRepository(db).get_by_id(str(current_user.get("id") or ""))
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=401,
            detail="User account is no longer active",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


@router.get("/plans", response_model=CheckoutInfoOut)
async def get_checkout_info(
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Recharge page payload: plans, personal limits, payment methods."""
    user = await _current_user_row(current_user, db)
    return await payment_service.checkout_info(db, user)


@router.post("/orders", response_model=OrderOut)
async def create_payment_order(
    request: Request,
    payload: OrderCreateRequest,
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a recharge order (preset plan or custom amount)."""
    user = await _current_user_row(current_user, db)
    client_ip = request.client.host if request.client else ""
    return await payment_service.create_order(db, user, payload, client_ip)


@router.get("/orders", response_model=OrderListOut)
async def list_my_orders(
    page: int = 1,
    page_size: int = 20,
    status: Optional[str] = None,
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Page the current user's order history (optional status filter)."""
    user = await _current_user_row(current_user, db)
    return await payment_service.my_orders(
        db, user, page=page, page_size=page_size, status=status
    )


@router.get("/orders/{order_id}", response_model=OrderOut)
async def get_order_detail(
    order_id: str,
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Poll one owned order; pending orders may query the gateway."""
    user = await _current_user_row(current_user, db)
    return await payment_service.order_detail(db, user, order_id)


@router.post("/orders/{order_id}/cancel", response_model=OrderOut)
async def cancel_my_order(
    order_id: str,
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Cancel one owned order (pending only)."""
    user = await _current_user_row(current_user, db)
    return await payment_service.cancel_order(db, user, order_id)


@router.get("/transactions", response_model=TransactionListOut)
async def list_my_transactions(
    page: int = 1,
    page_size: int = 20,
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Page the current user's balance ledger."""
    user = await _current_user_row(current_user, db)
    return await payment_service.my_transactions(
        db, user, page=page, page_size=page_size
    )
