"""
@file driver_docling.py
@brief Docling document parsing API endpoints for Driver Agent.

Provides endpoints for:
- Single file parsing with full Docling pipeline
- Batch file parsing (multiple documents)
- Chunked parsing (token-aware + structure-aware)
- Multi-format export (markdown, text, JSON, HTML)
- Supported formats listing

Strictly follows Docling architecture:
  DocumentConverter -> PipelineOptions -> ConversionResult -> DoclingDocument
  -> export_to_markdown/text/html/dict + HierarchicalChunker/HybridChunker

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from functools import lru_cache
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.services.driver_docling_formula_service import FORMULA_MIN_CONFIDENCE
from app.services.driver_docling_image_description_service import (
    IMAGE_DETAIL_FINAL_MIN_CONFIDENCE,
    IMAGE_DETAIL_OCR_MIN_CONFIDENCE,
    IMAGE_FACT_SELECTED_MIN_CONFIDENCE,
    MIN_IMAGE_DESCRIPTION_AREA_PX,
    MIN_IMAGE_DESCRIPTION_HEIGHT_PX,
    MIN_IMAGE_DESCRIPTION_WIDTH_PX,
)
from app.services.driver_docling_service import (
    DEFAULT_IMAGE_DESCRIPTION_BATCH_SIZE,
    DEFAULT_IMAGE_DESCRIPTION_CONCURRENCY,
    DEFAULT_IMAGE_DESCRIPTION_TIMEOUT_SECONDS,
    DEFAULT_TOC_MAX_ITEMS,
    DEFAULT_ENABLE_FORMULA_RECOGNITION,
    DEFAULT_ENABLE_IMAGE_DETAIL_VERIFICATION,
    DIRECT_TEXT_EXTENSIONS,
    DOCLING_SUPPORTED_EXTENSIONS,
    DoclingPathAccessError,
    DriverDoclingService,
    MAX_IMAGE_DESCRIPTION_CONCURRENCY,
    MAX_TOC_MAX_ITEMS,
    MIN_TOC_MAX_ITEMS,
    SUPPORTED_IMAGE_DESCRIPTION_MODES,
    SUPPORTED_OCR_ENGINES,
    SUPPORTED_TABLE_MODES,
)


router = APIRouter()

DoclingChunkerType = Literal["hierarchical", "hybrid"]
DoclingExportFormat = Literal["markdown", "text", "json", "html"]

MIN_BATCH_PARSE_FILES = 1
MAX_BATCH_PARSE_FILES = 50
DEFAULT_CHUNK_MAX_TOKENS = 1024
MIN_CHUNK_MAX_TOKENS = 128
MAX_CHUNK_MAX_TOKENS = 8192
DEFAULT_CHUNK_OVERLAP_TOKENS = 128
MIN_CHUNK_OVERLAP_TOKENS = 0
MAX_CHUNK_OVERLAP_TOKENS = 512
DEFAULT_CHUNKER_TYPE: DoclingChunkerType = "hierarchical"
DEFAULT_EXPORT_FORMAT: DoclingExportFormat = "markdown"
CHUNKER_TYPES: tuple[DoclingChunkerType, ...] = ("hierarchical", "hybrid")
EXPORT_FORMATS: tuple[DoclingExportFormat, ...] = ("markdown", "text", "json", "html")


@lru_cache(maxsize=1)
def get_docling_service() -> DriverDoclingService:
    """Return the shared Docling service so the heavy converter can be reused."""
    return DriverDoclingService()


def _error_status_code(error: str) -> int:
    error_status_codes = {
        "FILE_NOT_FOUND": status.HTTP_404_NOT_FOUND,
        "PATH_TRAVERSAL": status.HTTP_403_FORBIDDEN,
        "FILE_TOO_LARGE": status.HTTP_413_CONTENT_TOO_LARGE,
        "UNSUPPORTED": status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
        "BINARY_FORMAT_NO_PARSER": status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
        "READ_FAILED": status.HTTP_422_UNPROCESSABLE_CONTENT,
        "DOCLING_FAILED": status.HTTP_422_UNPROCESSABLE_CONTENT,
        "DOCLING_RESULT_MISMATCH": status.HTTP_422_UNPROCESSABLE_CONTENT,
        "CONVERSION_FAILED": status.HTTP_422_UNPROCESSABLE_CONTENT,
        "DOCLING_RUNTIME_UNAVAILABLE": status.HTTP_503_SERVICE_UNAVAILABLE,
        "CANCELLED": status.HTTP_409_CONFLICT,
    }
    return error_status_codes.get(error.upper(), status.HTTP_400_BAD_REQUEST)


def _raise_if_service_error(result: dict[str, Any]) -> None:
    error = result.get("error")
    if not error:
        return

    raise HTTPException(
        status_code=_error_status_code(str(error)),
        detail=result.get("summary", str(error)),
    )


# ==================== Request/Response Models ====================

class DoclingParseRequest(BaseModel):
    """Request to parse a single file."""
    file_path: str = Field(..., description="Path to the file to parse")


class DoclingBatchParseRequest(BaseModel):
    """Request to batch parse multiple files."""
    file_paths: list[str] = Field(
        ...,
        min_length=MIN_BATCH_PARSE_FILES,
        max_length=MAX_BATCH_PARSE_FILES,
    )


class DoclingChunkRequest(BaseModel):
    """Request to parse a file with chunking."""
    file_path: str = Field(..., description="Path to the file to parse")
    max_tokens: int = Field(default=DEFAULT_CHUNK_MAX_TOKENS, ge=MIN_CHUNK_MAX_TOKENS, le=MAX_CHUNK_MAX_TOKENS, description="Max tokens per chunk")
    overlap_tokens: int = Field(default=DEFAULT_CHUNK_OVERLAP_TOKENS, ge=MIN_CHUNK_OVERLAP_TOKENS, le=MAX_CHUNK_OVERLAP_TOKENS, description="Overlap between chunks")
    chunker_type: DoclingChunkerType = Field(default=DEFAULT_CHUNKER_TYPE, description="'hierarchical' or 'hybrid'")


class DoclingExportRequest(BaseModel):
    """Request to export a file in a specific format."""
    file_path: str = Field(..., description="Path to the file to export")
    format: DoclingExportFormat = Field(default=DEFAULT_EXPORT_FORMAT, description="Export format: markdown, text, json, html")


# ==================== Endpoints ====================

@router.post("/driver/docling/parse")
async def parse_document(
    request: DoclingParseRequest,
    service: DriverDoclingService = Depends(get_docling_service),
):
    """Parse a single document using the full Docling pipeline.

    Returns structured content including: markdown text, tables, figures,
    headings hierarchy, detected registers, and metadata.
    """
    result = await service.parse_file(request.file_path)

    # Remove internal-only fields
    result.pop("_docling_doc", None)

    _raise_if_service_error(result)

    return result


@router.post("/driver/docling/parse/batch")
async def batch_parse_documents(
    request: DoclingBatchParseRequest,
    service: DriverDoclingService = Depends(get_docling_service),
):
    """Batch parse multiple documents using Docling's convert_all.

    Efficiently processes multiple files in one call, leveraging
    Docling's internal threading and pipeline caching.
    """
    results = await service.batch_parse(request.file_paths)

    # Remove internal-only fields
    for r in results:
        r.pop("_docling_doc", None)

    succeeded = sum(1 for r in results if not r.get("error"))
    failed = sum(1 for r in results if r.get("error"))

    return {
        "total": len(results),
        "succeeded": succeeded,
        "failed": failed,
        "results": results,
    }


@router.post("/driver/docling/chunk")
async def parse_with_chunks(
    request: DoclingChunkRequest,
    service: DriverDoclingService = Depends(get_docling_service),
):
    """Parse a document and return token-aware chunks for LLM consumption.

    Uses Docling's chunking infrastructure:
    - HierarchicalChunker: structure-aware splitting by document headings
    - HybridChunker: token-aware + structure-aware (requires tokenizer)

    Each chunk includes metadata about its position in the document hierarchy.
    """
    result = await service.parse_file_with_chunks(
        file_path=request.file_path,
        max_tokens=request.max_tokens,
        overlap_tokens=request.overlap_tokens,
        chunker_type=request.chunker_type,
    )

    result.pop("_docling_doc", None)

    _raise_if_service_error(result)

    chunks = result.pop("chunks", [])
    return {
        "file": request.file_path,
        "chunker_type": request.chunker_type,
        "max_tokens": request.max_tokens,
        "chunk_count": len(chunks),
        "chunks": chunks,
        "summary": result.get("summary", ""),
        "metadata": result.get("metadata", {}),
    }


@router.post("/driver/docling/export")
async def export_document(
    request: DoclingExportRequest,
    service: DriverDoclingService = Depends(get_docling_service),
):
    """Export a document in a specific format using Docling's export methods.

    Supported formats:
    - markdown: Docling's export_to_markdown() (default)
    - text: Docling's export_to_text() (plain text)
    - json: Docling's export_to_dict() (structured JSON)
    - html: Docling's export_to_html() (full HTML)
    """
    fmt = request.format

    try:
        if fmt == "markdown":
            parse_result = await service.parse_file(request.file_path)
            parse_result.pop("_docling_doc", None)
            _raise_if_service_error(parse_result)
            content = parse_result.get("content", "")
            return {"format": "markdown", "content": content}

        validation = service.validate_input_file(request.file_path)
        _raise_if_service_error(validation)

        if fmt == "text":
            content = await service.export_as_text(request.file_path)
            if isinstance(content, dict) and content.get("error"):
                _raise_if_service_error(content)
            return {"format": "text", "content": content}
        elif fmt == "json":
            data = await service.export_as_json(request.file_path)
            if isinstance(data, dict) and data.get("error"):
                _raise_if_service_error(data)
            return {"format": "json", "data": data}
        elif fmt == "html":
            content = await service.export_as_html(request.file_path)
            if isinstance(content, dict) and content.get("error"):
                _raise_if_service_error(content)
            return {"format": "html", "content": content}

        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported export format: {fmt}",
        )
    except DoclingPathAccessError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        ) from None


@router.get("/driver/docling/formats")
async def list_supported_formats():
    """List all supported file formats for Docling parsing.

    Returns two categories:
    - docling_formats: Require Docling library (PDF, DOCX, images, etc.)
    - direct_text_formats: Parsed directly without Docling (source code, text)
    """
    return {
        "docling_formats": sorted(DOCLING_SUPPORTED_EXTENSIONS),
        "direct_text_formats": sorted(DIRECT_TEXT_EXTENSIONS),
        "all_supported": sorted(DOCLING_SUPPORTED_EXTENSIONS | DIRECT_TEXT_EXTENSIONS),
        "export_formats": list(EXPORT_FORMATS),
        "chunker_types": list(CHUNKER_TYPES),
        "ocr_engines": list(SUPPORTED_OCR_ENGINES),
        "table_modes": list(SUPPORTED_TABLE_MODES),
        "postprocess_policy": {
            "toc_max_items_env": "DRIVER_DOCLING_TOC_MAX_ITEMS",
            "default_toc_max_items": DEFAULT_TOC_MAX_ITEMS,
            "min_toc_max_items": MIN_TOC_MAX_ITEMS,
            "max_toc_max_items": MAX_TOC_MAX_ITEMS,
        },
        "image_description_modes": list(SUPPORTED_IMAGE_DESCRIPTION_MODES),
        "image_description_policy": {
            "mode_source": "service defaults and environment variables",
            "supported_modes": list(SUPPORTED_IMAGE_DESCRIPTION_MODES),
            "deprecated_modes": ["claude_cli"],
            "description_limit": None,
            "default_batch_size": DEFAULT_IMAGE_DESCRIPTION_BATCH_SIZE,
            "default_concurrency": DEFAULT_IMAGE_DESCRIPTION_CONCURRENCY,
            "max_concurrency": MAX_IMAGE_DESCRIPTION_CONCURRENCY,
            "default_image_description_timeout": DEFAULT_IMAGE_DESCRIPTION_TIMEOUT_SECONDS,
            "minimum_image_width_px": MIN_IMAGE_DESCRIPTION_WIDTH_PX,
            "minimum_image_height_px": MIN_IMAGE_DESCRIPTION_HEIGHT_PX,
            "minimum_image_area_px": MIN_IMAGE_DESCRIPTION_AREA_PX,
            "summary_fields": ["type", "title", "description", "detail_point_records"],
            "default_detail_verification": DEFAULT_ENABLE_IMAGE_DETAIL_VERIFICATION,
            "detail_ocr_min_confidence": IMAGE_DETAIL_OCR_MIN_CONFIDENCE,
            "detail_final_min_confidence": IMAGE_DETAIL_FINAL_MIN_CONFIDENCE,
            "detail_selected_min_confidence": IMAGE_FACT_SELECTED_MIN_CONFIDENCE,
            "summary_semantic_verification": "point_level_accept_correct_reject_then_context_or_visual_fallback",
            "detail_point_verification_statuses": ["accepted", "corrected", "rejected"],
            "empty_generic_description_allowed": False,
            "type_conflicts": "audit_warning_not_hard_failure",
            "precise_summary_values": "typed_document_grounded_candidate_selection",
            "precise_fact_statuses": ["verified", "confidence_selected"],
            "precise_fact_audit_statuses": [
                "verified",
                "canonicalized",
                "confidence_selected",
                "uncertain",
            ],
            "fact_conflict_policy": "rank_all_candidates_but_publish_only_candidates_passing_strict_gates",
            "ocr_independence_policy": "primary_and_local_easyocr_count_as_one_evidence_family",
            "document_vocabulary": "extracted_dynamically_from_current_document_metadata_and_tables",
            "only_independent_document_grounded_evidence_marked_as_verified": True,
        },
        "formula_recognition_policy": {
            "default_enabled": DEFAULT_ENABLE_FORMULA_RECOGNITION,
            "mode": "formula_crop_router_vision_with_verification_and_automatic_fallback",
            "minimum_final_confidence": FORMULA_MIN_CONFIDENCE,
            "deterministic_syntax_validation": True,
            "verification_disagreement": "repair_once_then_verify_again",
            "unverified_formula": "embed_source_crop_without_manual_review",
            "native_docling_model": "optional docling-project--CodeFormulaV2",
        },
    }
