"""Firmware code review Agent API endpoints."""

from __future__ import annotations

import asyncio
import json
import secrets
import uuid
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from loguru import logger
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.base import AgentStatus
from app.agents.impl import ReviewAgent
from app.agents.impl.review_agent import ReviewContext
from app.core.config import get_settings
from app.core.database import async_session_factory, get_db
from app.core.security import get_optional_user_from_request
from app.models.task import Task
from app.schemas.review import ReviewApprovalRequest, ReviewRequest
from app.services.agent_task_runtime import (
    complete_task,
    fail_task,
    mark_task_cancelled,
    serialize_task,
    update_task_progress,
)
from app.services.billing_service import enforce_billing
from app.services.firmware_file_service import FirmwareFileService
from app.services.human_approval import ApprovalNotification, HumanApprovalService, approval_public_api_base_url


router = APIRouter()

_ALLOWED_SOURCE_EXTENSIONS = {".c", ".cc", ".cpp", ".h", ".hh", ".hpp", ".s", ".asm"}
_MAX_REVIEW_FILES = 20
_MAX_TOTAL_BYTES = 20 * 1024 * 1024
_running_tasks: dict[str, asyncio.Task] = {}
_running_agents: dict[str, ReviewAgent] = {}
_review_approval_events: dict[str, asyncio.Event] = {}
_review_approval_tokens: dict[str, str] = {}
_review_approval_states: dict[str, dict] = {}
_REVIEW_WORKFLOW_NODES = [
    {"id": "collect", "label": "Collect source", "description": "Read uploads, local Git changes, remote pull requests, and configured Jira context.", "kind": "input"},
    {"id": "partition", "label": "Partition batches", "description": "Split large source sets into bounded review batches.", "kind": "prepare"},
    {"id": "review", "label": "Review code", "description": "Check correctness, safety, standards, and maintainability.", "kind": "review"},
    {"id": "aggregate", "label": "Aggregate findings", "description": "Normalize, deduplicate, score, and summarize findings.", "kind": "aggregate"},
    {"id": "approval", "label": "Human approval", "description": "Review the findings and code diff before the report is finalized.", "kind": "approval"},
    {"id": "report", "label": "Save report", "description": "Write Markdown and JSON artifacts for download and review.", "kind": "output"},
]


@router.get("/review/integrations")
async def get_review_integrations(raw_request: Request) -> dict[str, Any]:
    """Return safe availability flags for Code Review integrations."""
    mcp_client = getattr(raw_request.app.state, "mcp_client", None)
    settings = get_settings()
    tools = {str(item.get("name") or "") for item in (mcp_client.list_tools() if mcp_client else [])}
    return {
        "profile": settings.INTEGRATION_PROFILE,
        "jira": {
            "available": any(name.startswith("jira_") for name in tools),
            "deployment": settings.JIRA_DEPLOYMENT,
            "project": settings.JIRA_PROJECT_KEY or "",
            "issue_types": [item.strip() for item in settings.JIRA_ISSUE_TYPES.split(",") if item.strip()],
        },
        "git": {
            "available": "git_get_diff" in tools,
            "provider": settings.GIT_PROVIDER,
            "base_url": settings.GIT_BASE_URL or "",
            "repository_path": settings.GIT_REPOSITORY_PATH or "",
            "repository_url": settings.GIT_REPOSITORY_URL or "",
            "default_branch": settings.GIT_DEFAULT_BRANCH,
        },
        "bitbucket": {
            "available": "bb_get_diff" in tools,
            "deployment": settings.BITBUCKET_DEPLOYMENT,
            "workspace": settings.BITBUCKET_WORKSPACE or "",
        },
    }


def _public_approval_state(state: Optional[dict], *, include_token: bool = False) -> dict:
    """Remove internal approval credentials and draft payloads from API state."""
    if not state:
        return {}
    sanitized = {
        key: value
        for key, value in state.items()
        if key not in {"token", "draft_result"}
    }
    if include_token and state.get("token"):
        sanitized["token"] = state["token"]
    return sanitized


def _review_workflow_nodes(progress: int, status: str, require_approval: bool = False) -> list[dict]:
    """Map persisted review progress to stable visual workflow node states."""
    value = max(0, min(int(progress or 0), 100))
    templates = _REVIEW_WORKFLOW_NODES if require_approval else [
        node for node in _REVIEW_WORKFLOW_NODES if node["id"] != "approval"
    ]
    thresholds = [15, 24, 80, 88, 94, 99] if require_approval else [15, 24, 80, 90, 99]
    active = next((index for index, threshold in enumerate(thresholds) if value < threshold), len(thresholds) - 1)
    if status == AgentStatus.COMPLETED.value:
        active = len(thresholds)
    failed = status in {AgentStatus.FAILED.value, AgentStatus.CANCELLED.value, "rejected"}
    nodes = []
    for index, template in enumerate(templates):
        if failed and index == min(active, len(templates) - 1):
            node_status = "fail"
        elif index < active:
            node_status = "done"
        elif index == active and status in {AgentStatus.RUNNING.value, "awaiting_approval"}:
            node_status = "active"
        elif status == AgentStatus.COMPLETED.value:
            node_status = "done"
        else:
            node_status = "pending"
        nodes.append({**template, "status": node_status})
    return nodes


def _optional_user(request: Request) -> dict[str, str]:
    return get_optional_user_from_request(request, "anonymous")


async def _set_review_task_state(
    task_id: str,
    *,
    status: str,
    progress: int,
    message: str,
    result_data: Optional[dict] = None,
) -> None:
    """Persist a review approval state while its background task is paused."""
    async with async_session_factory() as session:
        result = await session.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task:
            task.status = status
            task.progress = progress
            task.message = message
            if result_data is not None:
                task.result_data = json.dumps(result_data, ensure_ascii=False)
            await session.commit()


async def _wait_for_review_approval(
    task_id: str,
    context: ReviewContext,
    result_data: dict,
) -> bool:
    """Notify reviewers and pause until the Code Review result is approved."""
    token = secrets.token_urlsafe(24)
    event = asyncio.Event()
    _review_approval_events[task_id] = event
    _review_approval_tokens[task_id] = token
    settings = get_settings()
    base_url = str(settings.APPROVAL_PUBLIC_API_BASE_URL or context.metadata.get("approval_public_api_base_url") or "").rstrip("/")
    approve_url = f"{base_url}/review/tasks/{task_id}/approval/approve?token={token}"
    reject_url = f"{base_url}/review/tasks/{task_id}/approval/reject?token={token}"
    channels = list(dict.fromkeys(str(item).strip().lower() for item in context.approval_channels if item))
    recipients = tuple(str(item).strip() for item in context.approval_recipients if str(item).strip())
    notification = ApprovalNotification(
        agent_name="Code Review Agent",
        task_id=task_id,
        node_label="Human approval",
        message=(
            f"{result_data.get('summary') or 'Code review completed'}\n"
            f"Score: {result_data.get('score', 0)}\n"
            f"Findings: {len(result_data.get('findings') or [])}\n\n"
            f"Code diff:\n{str(result_data.get('code_diff') or '')[:12000]}"
        ),
        approval_url=approve_url,
        rejection_url=reject_url,
        recipients=recipients,
    )
    delivery = await HumanApprovalService(settings).notify(channels, notification)
    approval = {
        "status": "pending",
        "channels": channels,
        "recipients": list(recipients),
        "delivery": delivery,
        "token": token,
        "approve_url": approve_url,
        "reject_url": reject_url,
        "code_diff": result_data.get("code_diff") or "",
        "draft_result": result_data,
    }
    _review_approval_states[task_id] = approval
    approval_payload = dict(result_data)
    approval_payload["approval"] = _public_approval_state(approval)
    await _set_review_task_state(
        task_id,
        status="awaiting_approval",
        progress=88,
        message="Waiting for human approval of the review findings and code diff",
        result_data=approval_payload,
    )
    await event.wait()
    state = _review_approval_states.get(task_id, {})
    if state.get("status") == "cancelled":
        return False
    decision = str(state.get("decision") or "reject")
    if decision == "approve":
        await _set_review_task_state(
            task_id,
            status=AgentStatus.RUNNING.value,
            progress=91,
            message="Human approval received; saving the review report",
        )
        return True
    persisted_approval = _public_approval_state(state)
    await _set_review_task_state(
        task_id,
        status="failed",
        progress=88,
        message=str(state.get("comment") or "Code review rejected by human reviewer"),
        result_data=result_data | {"approval": persisted_approval},
    )
    _review_approval_states[task_id] = state
    return False


async def _read_uploaded_sources(uploads: list[UploadFile]) -> dict[str, str]:
    if not uploads:
        return {}
    if len(uploads) > _MAX_REVIEW_FILES:
        raise HTTPException(status_code=400, detail=f"A maximum of {_MAX_REVIEW_FILES} files is allowed")

    settings = get_settings()
    total_bytes = 0
    source_contents: dict[str, str] = {}
    for index, upload in enumerate(uploads, start=1):
        filename = Path(upload.filename or f"source-{index}.c").name
        extension = Path(filename).suffix.lower()
        if extension not in _ALLOWED_SOURCE_EXTENSIONS:
            allowed = ", ".join(sorted(_ALLOWED_SOURCE_EXTENSIONS))
            raise HTTPException(status_code=400, detail=f"Unsupported source type. Allowed: {allowed}")
        try:
            data = await upload.read(settings.MAX_FILE_SIZE + 1)
        finally:
            await upload.close()
        if not data:
            raise HTTPException(status_code=400, detail=f"Uploaded source file is empty: {filename}")
        if len(data) > settings.MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail=f"Source file exceeds the size limit: {filename}")
        total_bytes += len(data)
        if total_bytes > _MAX_TOTAL_BYTES:
            raise HTTPException(status_code=413, detail="Combined source files exceed the size limit")
        unique_name = filename
        if unique_name in source_contents:
            path = Path(filename)
            unique_name = f"{path.stem}-{index}{path.suffix}"
        source_contents[unique_name] = data.decode("utf-8-sig", errors="replace")
    return source_contents


async def _run_review_task(task_id: str, agent: ReviewAgent, context: ReviewContext) -> None:
    file_service = FirmwareFileService(get_settings().OUTPUT_DIR)
    try:
        async for update in agent.stream_execute(
            f"Review {len(context.source_contents) or len(context.source_files)} firmware files",
            context,
        ):
            if update.stage not in {"completed", "failed", "cancelled"}:
                await update_task_progress(
                    task_id,
                    update.progress,
                    update.stage,
                    update.message,
                    update.details,
                )

        result = agent.get_status(task_id)
        if result is None:
            raise RuntimeError("Review task completed without an Agent result")
        result_data = dict(result.data or {})
        if result.status == AgentStatus.COMPLETED and context.require_approval:
            approved = await _wait_for_review_approval(task_id, context, result_data)
            if not approved:
                return
            result_data["approval"] = _public_approval_state(_review_approval_states.get(task_id))
        if result.status == AgentStatus.COMPLETED:
            await update_task_progress(task_id, 94, "store", "Saving the review report")
            report_json = json.dumps(
                {
                    "summary": result_data.get("summary"),
                    "score": result_data.get("score"),
                    "counts": result_data.get("counts"),
                    "findings": result_data.get("findings"),
                    "standards": result_data.get("standards"),
                    "review_type": result_data.get("review_type"),
                    "code_diff": result_data.get("code_diff"),
                    "git": result_data.get("git", {}),
                    "pull_request": result_data.get("pull_request", {}),
                    "jira_issues": result_data.get("jira_issues", []),
                    "jira_query": result_data.get("jira_query", {}),
                },
                ensure_ascii=False,
                indent=2,
            )
            artifacts = await file_service.save_text_artifacts(
                "review",
                task_id,
                {
                    "review-report.md": result_data.get("report_markdown", ""),
                    "review-findings.json": report_json,
                    "review-code-diff.diff": result_data.get("code_diff", ""),
                },
            )
            result_data["artifacts"] = [
                {
                    "filename": artifact.filename,
                    "media_type": artifact.media_type,
                    "size_bytes": artifact.size_bytes,
                    "download_url": f"/api/v1/review/tasks/{task_id}/artifacts/{artifact.filename}",
                }
                for artifact in artifacts
            ]
        await complete_task(result, result_data)
    except asyncio.CancelledError:
        await mark_task_cancelled(task_id, "Code review task cancelled")
    except Exception as exc:
        logger.error(f"Review task {task_id} failed: {exc}", exc_info=True)
        await fail_task(task_id, str(exc))
    finally:
        _running_tasks.pop(task_id, None)
        _running_agents.pop(task_id, None)
        _review_approval_events.pop(task_id, None)
        _review_approval_tokens.pop(task_id, None)
        _review_approval_states.pop(task_id, None)


async def _start_review_task(
    raw_request: Request,
    db: AsyncSession,
    current_user: dict[str, str],
    context: ReviewContext,
    input_data: dict,
) -> dict:
    context.metadata["approval_public_api_base_url"] = approval_public_api_base_url(
        get_settings(), str(raw_request.base_url),
    )
    task = Task(
        id=context.task_id,
        user_id=current_user["id"],
        agent_type="review",
        status=AgentStatus.RUNNING.value,
        progress=2,
        message="Code review task started",
        input_data=json.dumps(input_data, ensure_ascii=False),
    )
    db.add(task)
    await db.commit()

    agent = ReviewAgent(
        raw_request.app.state.llm_bridge,
        raw_request.app.state.mcp_client,
        skill_registry=getattr(raw_request.app.state, "skill_registry", None),
    )
    background_task = asyncio.create_task(_run_review_task(context.task_id, agent, context))
    _running_tasks[context.task_id] = background_task
    _running_agents[context.task_id] = agent
    return {
        "task_id": context.task_id,
        "status": AgentStatus.RUNNING.value,
        "message": "Code review task created",
    }


@router.post("/review/tasks", status_code=202)
async def create_review_task(
    raw_request: Request,
    files: Optional[list[UploadFile]] = File(None),
    review_type: str = Form("full", max_length=32),
    standards_json: Optional[str] = Form(None),
    focus: Optional[str] = Form(None, max_length=20_000),
    repo: Optional[str] = Form(None, max_length=256),
    pr_id: Optional[int] = Form(None, ge=1),
    git_repository_path: Optional[str] = Form(None, max_length=1000),
    git_base_ref: str = Form("HEAD~1", max_length=256),
    git_target_ref: str = Form("WORKTREE", max_length=256),
    git_include_untracked: bool = Form(True),
    jira_project: Optional[str] = Form(None, max_length=64),
    jira_jql: Optional[str] = Form(None, max_length=2000),
    jira_issue_keys_json: Optional[str] = Form(None),
    jira_status: Optional[str] = Form(None, max_length=128),
    jira_max_results: int = Form(20, ge=1, le=100),
    require_approval: bool = Form(False),
    approval_channels_json: Optional[str] = Form(None),
    approval_recipients_json: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_db),
):
    """Create an asynchronous review task from uploaded source files."""
    source_contents = await _read_uploaded_sources(files or [])
    if bool(repo) != bool(pr_id):
        raise HTTPException(status_code=422, detail="repo and pr_id must be provided together for a pull-request review")
    if pr_id:
        mcp_client = getattr(raw_request.app.state, "mcp_client", None)
        tools = {str(item.get("name") or "") for item in (mcp_client.list_tools() if mcp_client else [])}
        if "bb_get_diff" not in tools:
            raise HTTPException(status_code=503, detail="Bitbucket PR review is unavailable; configure the Bitbucket connection in System Settings")
    if not source_contents and not pr_id and not git_repository_path:
        raise HTTPException(status_code=400, detail="Upload source files, provide a Git repository, or provide a pull request")
    standards = ["MISRA-C:2012"]
    if standards_json:
        try:
            parsed = json.loads(standards_json)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=422, detail="standards_json must be valid JSON") from exc
        if not isinstance(parsed, list) or any(not isinstance(item, str) for item in parsed):
            raise HTTPException(status_code=422, detail="standards_json must be an array of strings")
        standards = [item.strip() for item in parsed if item.strip()] or standards
    approval_channels: list[str] = []
    if approval_channels_json:
        try:
            parsed_channels = json.loads(approval_channels_json)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=422, detail="approval_channels_json must be valid JSON") from exc
        if not isinstance(parsed_channels, list):
            raise HTTPException(status_code=422, detail="approval_channels_json must be an array")
        approval_channels = [
            str(item).strip().lower()
            for item in parsed_channels
            if str(item).strip().lower() in {"email", "feishu"}
        ]
    approval_recipients: list[str] = []
    if approval_recipients_json:
        try:
            parsed_recipients = json.loads(approval_recipients_json)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=422, detail="approval_recipients_json must be valid JSON") from exc
        if not isinstance(parsed_recipients, list):
            raise HTTPException(status_code=422, detail="approval_recipients_json must be an array")
        approval_recipients = [str(item).strip() for item in parsed_recipients if str(item).strip()]

    jira_issue_keys: list[str] = []
    if jira_issue_keys_json:
        try:
            parsed_issue_keys = json.loads(jira_issue_keys_json)
        except json.JSONDecodeError as exc:
            raise HTTPException(status_code=422, detail="jira_issue_keys_json must be valid JSON") from exc
        if not isinstance(parsed_issue_keys, list):
            raise HTTPException(status_code=422, detail="jira_issue_keys_json must be an array")
        jira_issue_keys = [str(item).strip().upper() for item in parsed_issue_keys if str(item).strip()][:100]

    current_user = _optional_user(raw_request)
    await enforce_billing(current_user)
    context = ReviewContext(
        task_id=str(uuid.uuid4()),
        user_id=current_user["id"],
        source_contents=source_contents,
        pr_id=pr_id,
        repo=repo.strip() if repo else None,
        review_type=review_type.strip().lower() or "full",
        standards=standards,
        focus=focus.strip() if focus else None,
        require_approval=require_approval,
        approval_channels=approval_channels,
        approval_recipients=approval_recipients,
        jira_project=jira_project.strip() if jira_project else None,
        jira_jql=jira_jql.strip() if jira_jql else None,
        jira_issue_keys=jira_issue_keys,
        jira_status=jira_status.strip() if jira_status else None,
        jira_max_results=jira_max_results,
        git_repository_path=git_repository_path.strip() if git_repository_path else None,
        git_base_ref=git_base_ref.strip(),
        git_target_ref=git_target_ref.strip(),
        git_include_untracked=git_include_untracked,
    )
    input_data = {
        "files": list(source_contents),
        "review_type": context.review_type,
        "standards": context.standards,
        "focus": context.focus,
        "repo": context.repo,
        "pr_id": context.pr_id,
        "require_approval": context.require_approval,
        "approval_channels": context.approval_channels,
        "approval_recipients": context.approval_recipients,
        "git": {
            "repository_path": context.git_repository_path,
            "base_ref": context.git_base_ref,
            "target_ref": context.git_target_ref,
            "include_untracked": context.git_include_untracked,
        },
        "jira": {
            "project": context.jira_project,
            "jql": context.jira_jql,
            "issue_keys": context.jira_issue_keys,
            "status": context.jira_status,
            "max_results": context.jira_max_results,
        },
    }
    return await _start_review_task(raw_request, db, current_user, context, input_data)


async def _read_local_review_sources(request: ReviewRequest) -> dict[str, str]:
    if not request.source_files:
        return {}
    if not request.project_root:
        if request.repo:
            return {}
        raise HTTPException(status_code=422, detail="project_root is required for local source files")
    root = Path(request.project_root).expanduser().resolve()
    if not await asyncio.to_thread(root.is_dir):
        raise HTTPException(status_code=422, detail="project_root must be an existing directory")

    source_contents: dict[str, str] = {}
    settings = get_settings()
    for source_file in request.source_files:
        raw_path = Path(source_file).expanduser()
        path = raw_path.resolve() if raw_path.is_absolute() else (root / raw_path).resolve()
        if not path.is_relative_to(root):
            raise HTTPException(status_code=403, detail="Source files must remain within project_root")
        if path.suffix.lower() not in _ALLOWED_SOURCE_EXTENSIONS:
            raise HTTPException(status_code=400, detail=f"Unsupported source type: {path.suffix}")
        if not await asyncio.to_thread(path.is_file):
            raise HTTPException(status_code=404, detail=f"Source file not found: {source_file}")
        size = await asyncio.to_thread(lambda: path.stat().st_size)
        if size > settings.MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail=f"Source file exceeds the size limit: {source_file}")
        content = await asyncio.to_thread(path.read_text, encoding="utf-8", errors="replace")
        source_contents[path.relative_to(root).as_posix()] = content
    return source_contents


@router.post("/review", status_code=202)
async def review_code_legacy(
    request: ReviewRequest,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Create a review task from local paths or a remote repository."""
    source_contents = await _read_local_review_sources(request)
    if request.pr_id and not request.repo:
        raise HTTPException(status_code=422, detail="repo is required for a pull-request review")
    if request.pr_id:
        mcp_client = getattr(raw_request.app.state, "mcp_client", None)
        tools = {str(item.get("name") or "") for item in (mcp_client.list_tools() if mcp_client else [])}
        if "bb_get_diff" not in tools:
            raise HTTPException(status_code=503, detail="Bitbucket PR review is unavailable; configure the Bitbucket connection in System Settings")
    current_user = _optional_user(raw_request)
    await enforce_billing(current_user)
    remote_files = request.source_files if request.repo and not source_contents else []
    context = ReviewContext(
        task_id=str(uuid.uuid4()),
        user_id=current_user["id"],
        project_root=request.project_root,
        source_files=remote_files,
        source_contents=source_contents,
        pr_id=request.pr_id,
        repo=request.repo,
        review_type=request.review_type,
        standards=request.standards or ["MISRA-C:2012"],
        focus=request.focus,
        require_approval=request.require_approval,
        approval_channels=request.approval_channels,
        approval_recipients=request.approval_recipients,
        jira_project=request.jira_project,
        jira_jql=request.jira_jql,
        jira_issue_keys=request.jira_issue_keys,
        jira_status=request.jira_status,
        jira_max_results=request.jira_max_results,
        git_repository_path=request.git_repository_path,
        git_base_ref=request.git_base_ref,
        git_target_ref=request.git_target_ref,
        git_include_untracked=request.git_include_untracked,
    )
    if not source_contents and not remote_files and not request.pr_id and not request.git_repository_path:
        raise HTTPException(status_code=400, detail="No source files, Git repository, or pull request were provided")
    return await _start_review_task(
        raw_request,
        db,
        current_user,
        context,
        {
            "files": list(source_contents) or remote_files,
            "review_type": context.review_type,
            "standards": context.standards,
            "repo": context.repo,
            "pr_id": context.pr_id,
            "require_approval": context.require_approval,
            "approval_channels": context.approval_channels,
            "approval_recipients": context.approval_recipients,
            "git": {
                "repository_path": context.git_repository_path,
                "base_ref": context.git_base_ref,
                "target_ref": context.git_target_ref,
                "include_untracked": context.git_include_untracked,
            },
            "jira": {
                "project": context.jira_project,
                "jql": context.jira_jql,
                "issue_keys": context.jira_issue_keys,
                "status": context.jira_status,
                "max_results": context.jira_max_results,
            },
        },
    )


async def _get_review_task(task_id: str, db: AsyncSession, current_user: dict[str, str]) -> Task:
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "review" or task.user_id != current_user["id"]:
        raise HTTPException(status_code=404, detail="Review task not found")
    return task


@router.get("/review/tasks/{task_id}")
async def get_review_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Return one review task for polling."""
    task = await _get_review_task(task_id, db, _optional_user(raw_request))
    payload = serialize_task(task)
    require_approval = bool(payload.get("input", {}).get("require_approval"))
    payload["workflow_nodes"] = _review_workflow_nodes(task.progress, task.status, require_approval)
    approval_state = _review_approval_states.get(task_id)
    if approval_state:
        payload["approval"] = _public_approval_state(approval_state, include_token=True)
        payload["result"] = approval_state.get("draft_result")
    elif isinstance(payload.get("result"), dict) and isinstance(payload["result"].get("approval"), dict):
        payload["approval"] = payload["result"]["approval"]
    return payload


async def _decide_review_approval(
    task_id: str,
    request: ReviewApprovalRequest,
    token: str = "",
) -> dict:
    """Apply an approval decision and wake the paused Code Review task."""
    state = _review_approval_states.get(task_id)
    expected = _review_approval_tokens.get(task_id)
    supplied = str(token or request.token or "").strip()
    if not state or not expected or not secrets.compare_digest(expected, supplied):
        raise HTTPException(status_code=403, detail="Invalid or expired review approval token")
    if state.get("status") != "pending":
        raise HTTPException(status_code=409, detail="Code Review is not awaiting approval")
    state.update(
        {
            "status": request.decision,
            "decision": request.decision,
            "comment": request.comment.strip(),
        }
    )
    event = _review_approval_events.get(task_id)
    if event:
        if request.decision == "reject":
            state["status"] = "rejected"
        event.set()
    return {"task_id": task_id, "status": "approval_received", "approval": _public_approval_state(state)}


@router.post("/review/tasks/{task_id}/approval")
async def decide_review_approval(task_id: str, request: ReviewApprovalRequest) -> dict:
    """Approve or reject a pending Code Review from the workspace."""
    return await _decide_review_approval(task_id, request)


@router.get("/review/tasks/{task_id}/approval/{decision}")
async def decide_review_approval_link(task_id: str, decision: str, token: str) -> dict:
    """Handle one-click approval links from email or Feishu."""
    if decision not in {"approve", "reject"}:
        raise HTTPException(status_code=400, detail="Approval decision must be approve or reject")
    return await _decide_review_approval(
        task_id,
        ReviewApprovalRequest(decision=decision, token=token),
        token=token,
    )


@router.post("/review/tasks/{task_id}/cancel")
async def cancel_review_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Cancel a running code review task."""
    task = await _get_review_task(task_id, db, _optional_user(raw_request))
    if task.status not in {AgentStatus.RUNNING.value, "awaiting_approval"}:
        return serialize_task(task)
    agent = _running_agents.get(task_id)
    if agent:
        await agent.cancel(task_id)
    running_task = _running_tasks.get(task_id)
    if running_task and not running_task.done():
        running_task.cancel()
    event = _review_approval_events.get(task_id)
    if event:
        _review_approval_states[task_id] = {"status": "cancelled", "decision": "reject", "comment": "Code review task cancelled"}
        event.set()
    task.status = AgentStatus.CANCELLED.value
    task.progress = 0
    task.message = "Code review task cancelled"
    task.error_message = task.message
    await db.commit()
    return serialize_task(task)


@router.get("/review/tasks/{task_id}/artifacts/{filename}")
async def download_review_artifact(
    task_id: str,
    filename: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Download one generated review report artifact."""
    task = await _get_review_task(task_id, db, _optional_user(raw_request))
    if task.status != AgentStatus.COMPLETED.value:
        raise HTTPException(status_code=409, detail="Review task is not complete")
    file_service = FirmwareFileService(get_settings().OUTPUT_DIR)
    try:
        path = file_service.resolve("review", task_id, filename)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="Review artifact not found") from exc
    if not await asyncio.to_thread(path.is_file):
        raise HTTPException(status_code=404, detail="Review artifact not found")
    return FileResponse(path, filename=filename)
