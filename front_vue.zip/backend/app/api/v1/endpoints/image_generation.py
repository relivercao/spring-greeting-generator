"""Image generation agent task endpoints."""

from __future__ import annotations

import asyncio
import io
import json
import mimetypes
import secrets
import uuid
import zipfile
from pathlib import Path
from typing import Literal, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from loguru import logger
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.base import AgentStatus
from app.agents.impl.image_generation_agent import (
    ImageGenerationAgent,
    ImageGenerationContext,
)
from app.core.config import get_settings
from app.core.database import async_session_factory, get_db
from app.core.security import get_optional_user_from_request
from app.core.ws_manager import ws_manager
from app.infrastructure.storage import ImageArtifactStore
from app.llm.image_provider import (
    ImageGenerationOptions,
    ImageInput,
    OpenAICompatibleImageProvider,
    resolve_image_provider_config,
)
from app.llm.image_processing import (
    normalize_image_size,
    optimize_reference_image,
    prepare_mask_image,
    prepare_mask_target_image,
)
from app.models.task import Task
from app.services.billing_service import enforce_billing
from app.services.knowledge_repository import KnowledgeRepository


router = APIRouter()
_running_image_tasks: dict[str, asyncio.Task] = {}
_running_image_agents: dict[str, ImageGenerationAgent] = {}
_ALLOWED_INPUT_TYPES = {"image/png", "image/jpeg", "image/webp"}
_MAX_KNOWLEDGE_DOCUMENT_CHARS = 16000
_MAX_KNOWLEDGE_CONTEXT_CHARS = 48000


def _optional_user(request: Request) -> dict[str, str]:
    return get_optional_user_from_request(request, "anonymous")


def _load_json(value: Optional[str]) -> dict:
    if not value:
        return {}
    try:
        parsed = json.loads(value)
        return parsed if isinstance(parsed, dict) else {}
    except (TypeError, json.JSONDecodeError):
        logger.warning("Ignoring malformed image task JSON payload")
        return {}


def _mark_workflow_terminal(result_data: dict, status: str) -> None:
    """Close the active and remaining graph nodes after failure or cancellation."""
    nodes = result_data.get("workflow_nodes")
    if not isinstance(nodes, list):
        return
    terminal = "cancelled" if status == AgentStatus.CANCELLED.value else "failed"
    active_seen = False
    for node in nodes:
        if not isinstance(node, dict):
            continue
        if node.get("status") == "in_progress":
            node["status"] = terminal
            active_seen = True
        elif active_seen and node.get("status") == "pending":
            node["status"] = "skipped"


def _load_knowledge_context(document_ids: Optional[list[str]]) -> tuple[list[dict], str]:
    """Resolve selected canonical documents and build bounded grounding context."""
    requested_ids = []
    for document_id in document_ids or []:
        normalized = str(document_id).strip()
        if normalized and normalized not in requested_ids:
            requested_ids.append(normalized)
    if not requested_ids:
        return [], ""

    repository = KnowledgeRepository()
    documents = {
        document.document_id: document
        for document in repository.list_documents()
    }
    missing_ids = [document_id for document_id in requested_ids if document_id not in documents]
    if missing_ids:
        raise HTTPException(
            status_code=404,
            detail=f"Knowledge document not found: {missing_ids[0]}",
        )
    sources: list[dict] = []
    context_parts: list[str] = []
    remaining = _MAX_KNOWLEDGE_CONTEXT_CHARS
    for document_id in requested_ids:
        document = documents.get(document_id)
        if not document or remaining <= 0:
            continue
        metadata = document.metadata
        sources.append({
            "id": document.document_id,
            "title": str(metadata.get("title") or document.path.stem),
            "chip": str(metadata.get("chip") or "GENERAL"),
            "repository_path": document.relative_path,
            "revision": str(metadata.get("revision") or ""),
        })
        body = document.body[:min(_MAX_KNOWLEDGE_DOCUMENT_CHARS, remaining)]
        if len(document.body) > len(body):
            body += "\n[Document excerpt truncated for image prompt grounding]"
        context_parts.append(
            f"Source ID: {document.document_id}\n"
            f"Title: {metadata.get('title') or document.path.stem}\n"
            f"Repository path: {document.relative_path}\n"
            f"Content:\n{body}"
        )
        remaining -= len(body)
    return sources, "\n\n---\n\n".join(context_parts)


def _can_access_task(
    task: Task,
    current_user: dict[str, str],
    download_token: Optional[str] = None,
) -> bool:
    if task.user_id == current_user.get("id"):
        return True
    if not download_token:
        return False
    expected = _load_json(task.result_data).get("download_token")
    return bool(
        expected
        and secrets.compare_digest(str(expected), str(download_token))
    )


def _decorate_result(task_id: str, result: dict) -> dict:
    safe_result = {key: value for key, value in result.items() if key != "download_token"}
    token = result.get("download_token")
    images = []
    for item in safe_result.get("images") or []:
        if not isinstance(item, dict) or not item.get("filename"):
            continue
        filename = item["filename"]
        base_url = f"/api/v1/image-generation/tasks/{task_id}/images/{filename}"
        query = f"?token={token}" if token else ""
        images.append({
            **item,
            "url": f"{base_url}{query}",
            "download_url": f"{base_url}{query}{'&' if query else '?'}download=true",
        })
    safe_result["images"] = images
    if images:
        base_url = f"/api/v1/image-generation/tasks/{task_id}/download"
        safe_result["download_all_url"] = f"{base_url}?token={token}" if token else base_url
    return safe_result


def _serialize_task(task: Task) -> dict:
    input_data = _load_json(task.input_data)
    result_data = _load_json(task.result_data)
    return {
        "task_id": task.id,
        "agent_type": task.agent_type,
        "status": task.status,
        "progress": task.progress,
        "message": task.message,
        "error": task.error_message,
        "input": input_data,
        "result": _decorate_result(task.id, result_data) if result_data else None,
        "duration_ms": task.duration_ms,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "updated_at": task.updated_at.isoformat() if task.updated_at else None,
    }


async def _read_image_upload(
    upload: UploadFile,
    max_bytes: int,
    optimize_reference: bool = True,
) -> ImageInput:
    media_type = (upload.content_type or "").lower()
    if media_type == "image/jpg":
        media_type = "image/jpeg"
    if not media_type:
        media_type = mimetypes.guess_type(upload.filename or "")[0] or ""
    if media_type not in _ALLOWED_INPUT_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Only PNG, JPEG, and WebP image inputs are supported",
        )
    try:
        data = await upload.read(max_bytes + 1)
    finally:
        await upload.close()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded image is empty")
    if len(data) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail="Uploaded image exceeds the configured size limit",
        )
    if optimize_reference:
        try:
            prepared = await asyncio.to_thread(
                optimize_reference_image,
                data,
                Path(upload.filename or "reference").name,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return ImageInput(
            filename=prepared.filename,
            media_type=prepared.media_type,
            data=prepared.data,
            width=prepared.width,
            height=prepared.height,
            optimized=prepared.optimized,
        )
    return ImageInput(
        filename=Path(upload.filename or "input.png").name,
        media_type=media_type,
        data=data,
    )


async def _update_task_progress(
    task_id: str,
    progress: int,
    stage: str,
    message: str,
    details: Optional[dict[str, Any]] = None,
) -> None:
    async with async_session_factory() as session:
        result = await session.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task and task.status == "running":
            task.progress = max(0, min(progress, 99))
            task.message = message
            workflow_nodes = (details or {}).get("workflow_nodes")
            if isinstance(workflow_nodes, list):
                result_data = _load_json(task.result_data)
                result_data["workflow_nodes"] = workflow_nodes
                result_data["workflow_stage"] = stage
                task.result_data = json.dumps(result_data, ensure_ascii=False)
            await session.commit()
    await ws_manager.send_progress(task_id, progress, stage, message)


async def _run_image_task(
    task_id: str,
    agent: ImageGenerationAgent,
    context: ImageGenerationContext,
) -> None:
    try:
        async for update in agent.stream_execute(context.prompt, context):
            if update.stage not in {"completed", "failed"}:
                await _update_task_progress(
                    task_id,
                    update.progress,
                    update.stage,
                    update.message,
                    update.details,
                )

        result = agent.get_status(task_id)
        if result is None:
            raise RuntimeError("Image generation task completed without a result")

        result_data = result.data or {}
        if result.status == AgentStatus.COMPLETED:
            result_data["download_token"] = secrets.token_urlsafe(24)

        async with async_session_factory() as session:
            db_result = await session.execute(select(Task).where(Task.id == task_id))
            task = db_result.scalar_one_or_none()
            if task:
                stored_result = _load_json(task.result_data)
                final_data = {**stored_result, **result_data}
                final_data.pop("workflow_stage", None)
                if result.status in {AgentStatus.FAILED, AgentStatus.CANCELLED}:
                    _mark_workflow_terminal(final_data, result.status.value)
                task.status = result.status.value
                task.progress = 100 if result.status == AgentStatus.COMPLETED else 0
                task.message = result.message
                task.result_data = (
                    json.dumps(final_data, ensure_ascii=False) if final_data else None
                )
                task.error_message = "\n".join(result.errors) if result.errors else None
                task.duration_ms = result.duration_ms
                await session.commit()

        if result.status == AgentStatus.COMPLETED:
            await ws_manager.send_complete(task_id, _decorate_result(task_id, result_data))
        else:
            await ws_manager.send_error(task_id, result.message)
    except asyncio.CancelledError:
        async with async_session_factory() as session:
            db_result = await session.execute(select(Task).where(Task.id == task_id))
            task = db_result.scalar_one_or_none()
            if task and task.status == "running":
                result_data = _load_json(task.result_data)
                _mark_workflow_terminal(result_data, AgentStatus.CANCELLED.value)
                task.status = "cancelled"
                task.progress = 0
                task.message = "Image generation task cancelled"
                task.error_message = "Image generation task cancelled"
                task.result_data = json.dumps(result_data, ensure_ascii=False) if result_data else None
                await session.commit()
        await ws_manager.send_error(task_id, "Image generation task cancelled")
    except Exception as exc:
        logger.error(f"Image generation task {task_id} failed: {exc}", exc_info=True)
        async with async_session_factory() as session:
            db_result = await session.execute(select(Task).where(Task.id == task_id))
            task = db_result.scalar_one_or_none()
            if task:
                result_data = _load_json(task.result_data)
                _mark_workflow_terminal(result_data, AgentStatus.FAILED.value)
                task.status = "failed"
                task.progress = 0
                task.message = "Image generation failed"
                task.error_message = str(exc)
                task.result_data = json.dumps(result_data, ensure_ascii=False) if result_data else None
                await session.commit()
        await ws_manager.send_error(task_id, str(exc))
    finally:
        _running_image_tasks.pop(task_id, None)
        _running_image_agents.pop(task_id, None)


@router.post("/image-generation/tasks", status_code=202)
async def create_image_generation_task(
    raw_request: Request,
    prompt: str = Form(..., min_length=1, max_length=32000),
    size: str = Form("auto", max_length=32),
    quality: Literal["auto", "low", "medium", "high"] = Form("auto"),
    output_format: Literal["png", "jpeg", "webp"] = Form("png"),
    output_compression: Optional[int] = Form(None, ge=0, le=100),
    moderation: Literal["auto", "low"] = Form("auto"),
    image_count: int = Form(1, ge=1, le=10),
    transparent_output: bool = Form(False),
    enhance_prompt: bool = Form(True),
    knowledge_document_ids: Optional[list[str]] = Form(None),
    reference_images: Optional[list[UploadFile]] = File(None),
    mask: Optional[UploadFile] = File(None),
    db: AsyncSession = Depends(get_db),
):
    """Create an asynchronous image generation or editing task."""
    settings = get_settings()
    current_user = _optional_user(raw_request)
    await enforce_billing(current_user)
    uploads = reference_images or []
    if len(uploads) > settings.IMAGE_MAX_REFERENCE_IMAGES:
        raise HTTPException(
            status_code=400,
            detail=f"A maximum of {settings.IMAGE_MAX_REFERENCE_IMAGES} reference images is allowed",
        )

    references = [
        await _read_image_upload(upload, settings.IMAGE_MAX_INPUT_BYTES)
        for upload in uploads
    ]
    mask_input = (
        await _read_image_upload(
            mask,
            settings.IMAGE_MAX_INPUT_BYTES,
            optimize_reference=False,
        )
        if mask else None
    )
    if mask_input and not references:
        raise HTTPException(
            status_code=400,
            detail="A mask requires at least one reference image",
        )

    if mask_input:
        try:
            target = await asyncio.to_thread(
                prepare_mask_target_image,
                references[0].data,
                references[0].filename,
            )
            prepared_mask = await asyncio.to_thread(
                prepare_mask_image,
                mask_input.data,
                target.data,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        references[0] = ImageInput(
            target.filename,
            target.media_type,
            target.data,
            width=target.width,
            height=target.height,
            optimized=True,
        )
        mask_input = ImageInput(
            prepared_mask.filename,
            prepared_mask.media_type,
            prepared_mask.data,
            width=prepared_mask.width,
            height=prepared_mask.height,
            optimized=prepared_mask.optimized,
        )

    total_input_bytes = sum(len(image.data) for image in references)
    total_input_bytes += len(mask_input.data) if mask_input else 0
    if total_input_bytes > settings.IMAGE_MAX_TOTAL_INPUT_BYTES:
        raise HTTPException(
            status_code=413,
            detail="The combined image input exceeds the configured size limit",
        )

    normalized_size = normalize_image_size(size)
    if normalized_size is None:
        raise HTTPException(
            status_code=422,
            detail="Image size must use safe dimensions divisible by 16",
        )

    options = ImageGenerationOptions(
        size=normalized_size,
        quality=quality,
        output_format=output_format,
        output_compression=output_compression,
        moderation=moderation,
        n=image_count,
        transparent_output=transparent_output,
    )
    knowledge_sources, knowledge_context = _load_knowledge_context(knowledge_document_ids)
    task_id = str(uuid.uuid4())
    input_data = {
        "prompt": prompt.strip(),
        "params": {
            "size": normalized_size,
            "quality": quality,
            "output_format": output_format,
            "output_compression": output_compression,
            "moderation": moderation,
            "image_count": image_count,
            "transparent_output": transparent_output,
            "enhance_prompt": enhance_prompt,
        },
        "reference_images": [
            {
                "filename": image.filename,
                "media_type": image.media_type,
                "size_bytes": len(image.data),
                "width": image.width,
                "height": image.height,
                "optimized": image.optimized,
            }
            for image in references
        ],
        "has_mask": bool(mask_input),
        "knowledge_document_ids": [item["id"] for item in knowledge_sources],
        "knowledge_sources": knowledge_sources,
    }
    db.add(Task(
        id=task_id,
        user_id=current_user["id"],
        agent_type="image_generation",
        status="running",
        progress=5,
        message="Image generation task started",
        input_data=json.dumps(input_data, ensure_ascii=False),
    ))
    await db.commit()

    provider = OpenAICompatibleImageProvider(resolve_image_provider_config(settings))
    artifact_store = ImageArtifactStore(settings.OUTPUT_DIR)
    agent = ImageGenerationAgent(
        provider,
        artifact_store,
        llm_bridge=getattr(raw_request.app.state, "llm_bridge", None),
        max_reference_images=settings.IMAGE_MAX_REFERENCE_IMAGES,
        max_total_input_bytes=settings.IMAGE_MAX_TOTAL_INPUT_BYTES,
        skill_registry=getattr(raw_request.app.state, "skill_registry", None),
    )
    context = ImageGenerationContext(
        task_id=task_id,
        user_id=current_user["id"],
        prompt=prompt.strip(),
        options=options,
        reference_images=references,
        mask=mask_input,
        enhance_prompt=enhance_prompt,
        knowledge_documents=knowledge_sources,
        knowledge_context=knowledge_context,
    )
    background_task = asyncio.create_task(_run_image_task(task_id, agent, context))
    _running_image_tasks[task_id] = background_task
    _running_image_agents[task_id] = agent

    return {
        "task_id": task_id,
        "status": "running",
        "message": "Image generation task created",
    }


@router.get("/image-generation/tasks")
async def list_image_generation_tasks(
    raw_request: Request,
    status: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """List image generation task history for the current local user."""
    current_user = _optional_user(raw_request)
    filters = [
        Task.user_id == current_user["id"],
        Task.agent_type == "image_generation",
    ]
    if status:
        filters.append(Task.status == status)
    query = select(Task).where(*filters).order_by(Task.created_at.desc()).offset(offset).limit(limit)
    count_query = select(func.count()).select_from(Task).where(*filters)
    result = await db.execute(query)
    tasks = result.scalars().all()
    total = (await db.execute(count_query)).scalar() or 0
    return {
        "tasks": [_serialize_task(task) for task in tasks],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@router.get("/image-generation/tasks/{task_id}")
async def get_image_generation_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Return one image generation task with its normalized result."""
    current_user = _optional_user(raw_request)
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "image_generation" or not _can_access_task(task, current_user):
        raise HTTPException(status_code=404, detail="Image generation task not found")
    return _serialize_task(task)


@router.post("/image-generation/tasks/{task_id}/cancel")
async def cancel_image_generation_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Cancel a currently running image generation task."""
    current_user = _optional_user(raw_request)
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "image_generation" or not _can_access_task(task, current_user):
        raise HTTPException(status_code=404, detail="Image generation task not found")
    if task.status != "running":
        return _serialize_task(task)

    agent = _running_image_agents.get(task_id)
    if agent:
        await agent.cancel(task_id)
    running_task = _running_image_tasks.get(task_id)
    if running_task and not running_task.done():
        running_task.cancel()
    task.status = "cancelled"
    task.progress = 0
    task.message = "Image generation task cancelled"
    task.error_message = "Image generation task cancelled"
    await db.commit()
    return _serialize_task(task)


@router.delete("/image-generation/tasks/{task_id}", status_code=204)
async def delete_image_generation_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Delete an image generation task and all of its stored images."""
    current_user = _optional_user(raw_request)
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "image_generation" or not _can_access_task(task, current_user):
        raise HTTPException(status_code=404, detail="Image generation task not found")
    if task.status == "running":
        raise HTTPException(status_code=409, detail="Cancel the running task before deleting it")

    settings = get_settings()
    await db.delete(task)
    await db.commit()
    await ImageArtifactStore(settings.OUTPUT_DIR).delete_task(task_id)


@router.get("/image-generation/tasks/{task_id}/download")
async def download_generated_images(
    task_id: str,
    raw_request: Request,
    token: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
):
    """Download every stored result image for one task as a ZIP archive."""
    current_user = _optional_user(raw_request)
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "image_generation" or not _can_access_task(task, current_user, token):
        raise HTTPException(status_code=404, detail="Image generation task not found")

    store = ImageArtifactStore(get_settings().OUTPUT_DIR)
    filenames = [
        item.get("filename")
        for item in (_load_json(task.result_data).get("images") or [])
        if isinstance(item, dict) and item.get("filename")
    ]
    if not filenames:
        raise HTTPException(status_code=404, detail="Generated images not found")

    def build_archive() -> io.BytesIO:
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as output:
            for filename in filenames:
                path = store.resolve(task_id, filename)
                if path.is_file():
                    output.write(path, arcname=filename)
        archive.seek(0)
        return archive

    archive = await asyncio.to_thread(build_archive)
    return StreamingResponse(
        archive,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="image-task-{task_id[:8]}.zip"',
        },
    )


@router.get("/image-generation/tasks/{task_id}/images/{filename}")
async def get_generated_image(
    task_id: str,
    filename: str,
    raw_request: Request,
    token: Optional[str] = Query(None),
    download: bool = Query(False),
    db: AsyncSession = Depends(get_db),
):
    """Serve one generated image after owner or task-token validation."""
    current_user = _optional_user(raw_request)
    result = await db.execute(select(Task).where(Task.id == task_id))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "image_generation" or not _can_access_task(task, current_user, token):
        raise HTTPException(status_code=404, detail="Generated image not found")

    store = ImageArtifactStore(get_settings().OUTPUT_DIR)
    try:
        path = store.resolve(task_id, filename)
    except ValueError:
        raise HTTPException(status_code=404, detail="Generated image not found")
    if not await store.exists(task_id, filename):
        raise HTTPException(status_code=404, detail="Generated image not found")

    artifact = next(
        (
            item for item in (_load_json(task.result_data).get("images") or [])
            if isinstance(item, dict) and item.get("filename") == filename
        ),
        None,
    )
    if not artifact:
        raise HTTPException(status_code=404, detail="Generated image not found")
    media_type = artifact.get("media_type") or "application/octet-stream"
    if download:
        return FileResponse(path, media_type=media_type, filename=filename)
    return FileResponse(path, media_type=media_type)
