"""
@file unittest.py
@author zhangjian
@brief Unit test generation Agent API endpoints.

@version 3.3
@date 2026-03-10

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
import re
import secrets
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional, Any

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, Request
from fastapi.responses import FileResponse, Response
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_active_user, get_optional_user_from_request
from app.models.task import Task
from app.models.user import User
from app.agents.impl import UnitTestAgent
from app.agents.impl.unittest import UnitTestContext
from app.agents.base import AgentStatus, ProgressUpdate
from app.infrastructure.observability.logger import LoggerService
from app.services.billing_service import enforce_billing
from app.services.deps import get_owned_unittest_task
from app.services.unittest_runner import UnitTestRunner, WorkspaceLeaseManager
from app.services.unittest_uploads import normalize_source_name, persist_uploaded_sources

import os


router = APIRouter()

_BEIJING_TZ = timezone(timedelta(hours=8))
_CLI_SUMMARY_BEGIN = "=== UNITTEST_CLI_SUMMARY_BEGIN ==="
_CLI_SUMMARY_END = "=== UNITTEST_CLI_SUMMARY_END ==="
_BACKEND_OUTPUT_DIR = Path(__file__).resolve().parents[4] / "data" / "outputs"
_BACKEND_LOG_DIR = Path(__file__).resolve().parents[4] / "logs"


def _get_optional_user(request: Request) -> dict:
    return get_optional_user_from_request(request, "anonymous")


def _user_can_access_task(task: Task, current_user: dict, download_token: Optional[str] = None) -> bool:
    if task.user_id == current_user.get("id"):
        return True
    if task.user_id != "anonymous":
        return False
    if not download_token or not task.result_data:
        return False
    try:
        result_data = json.loads(task.result_data)
    except (TypeError, json.JSONDecodeError):
        return False
    artifact = result_data.get("cli_log_artifact") or {}
    expected_token = artifact.get("download_token")
    return bool(expected_token and secrets.compare_digest(str(expected_token), str(download_token)))


_GUEST_USER_ID = "anonymous"
_GUEST_USERNAME = "anonymous"
_GUEST_EMAIL = "anonymous@guest.local"


async def _ensure_guest_user(db: AsyncSession) -> None:
    """Create the guest user row before inserting tasks that reference it."""
    from sqlalchemy import select

    existing = await db.execute(select(User).where(User.id == _GUEST_USER_ID))
    if existing.scalar_one_or_none() is not None:
        return
    db.add(User(
        id=_GUEST_USER_ID,
        username=_GUEST_USERNAME,
        email=_GUEST_EMAIL,
        hashed_password="!guest-no-login",
        is_active=True,
    ))
    try:
        await db.flush()
    except Exception:
        await db.rollback()
        existing = await db.execute(select(User).where(User.id == _GUEST_USER_ID))
        if existing.scalar_one_or_none() is None:
            raise


def _build_frontend_test_files(agent_tests: list[Any], saved_files: list[Any]) -> list[dict[str, str]]:
    """Build the generated-file payload from canonical disk artifacts when available."""
    test_files: list[dict[str, str]] = []
    seen_filenames: set[str] = set()

    for saved_path_value in saved_files or []:
        if not saved_path_value:
            continue
        try:
            saved_path = os.fspath(saved_path_value)
        except TypeError:
            logger.warning(f"Ignoring invalid saved file path: {saved_path_value!r}")
            continue

        filename = os.path.basename(saved_path)
        if not filename or filename in seen_filenames:
            continue

        content = ""
        try:
            if os.path.isfile(saved_path):
                with open(saved_path, "r", encoding="utf-8") as saved_file:
                    content = saved_file.read()
            else:
                logger.warning(f"Saved test artifact is missing from disk: {saved_path}")
        except (OSError, UnicodeError) as exc:
            logger.warning(f"Could not read saved test artifact {saved_path}: {exc}")

        test_files.append({"filename": filename, "content": content})
        seen_filenames.add(filename)

    # If saved paths are stale (for example after a cleanup or a moved output
    # directory), do not hide usable in-memory generated content behind a list
    # of empty file entries.  Fall through to the GeneratedTest payload when
    # at least one generated test is available and nothing was readable.
    if test_files and (any(item.get("content") for item in test_files) or not agent_tests):
        return test_files

    def add_fallback(filename: str, content: str) -> None:
        if not filename:
            return
        if filename in seen_filenames:
            for item in test_files:
                if item["filename"] == filename and not item.get("content") and content:
                    item["content"] = content
                    break
            return
        test_files.append({"filename": filename, "content": content or ""})
        seen_filenames.add(filename)

    for generated_test in agent_tests or []:
        source_stem = os.path.splitext(os.path.basename(generated_test.source_file))[0]
        test_impl_filename = (
            os.path.basename(generated_test.test_file)
            if generated_test.test_file
            else f"tc-{source_stem}.cpp"
        )
        test_header_filename = f"{os.path.splitext(test_impl_filename)[0]}.h"
        add_fallback(test_impl_filename, generated_test.test_content or "")
        add_fallback(
            test_header_filename,
            getattr(generated_test, "test_header_content", "") or "",
        )
        add_fallback(f"mock-stm32-{source_stem}.cpp", generated_test.mock_content or "")
        add_fallback(
            f"mock-stm32-{source_stem}.h",
            getattr(generated_test, "mock_header_content", "") or "",
        )

    return test_files


# ---------- CLI log / summary helpers ----------

_SENSITIVE_PATTERNS = [
    (re.compile(r'(Authorization:\s*Bearer\s+)\S+',    re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(api[-_]?key\s*[:=]\s*)["\']?\S+',  re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(token\s*[:=]\s*)["\']?\S+',         re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'(password\s*[:=]\s*)["\']?\S+',      re.IGNORECASE), r'\1[REDACTED]'),
    (re.compile(r'sk-[A-Za-z0-9\-_]{20,}'),                            '[REDACTED-KEY]'),
]


def _sanitize_content(text: str) -> str:
    """Replace sensitive values (API keys, tokens, passwords) with [REDACTED]."""
    for pattern, replacement in _SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text



def _resolve_cli_log_output_dir(frontend_result: dict) -> str:
    saved_files = frontend_result.get("saved_files") or []
    for saved_path in saved_files:
        if not saved_path:
            continue
        filename = os.path.basename(saved_path)
        if filename.startswith("tc-"):
            return os.path.dirname(os.path.abspath(saved_path))
    for saved_path in saved_files:
        if saved_path:
            return os.path.dirname(os.path.abspath(saved_path))
    return str(_BACKEND_OUTPUT_DIR)


def _extract_cli_generated_summary(output: str) -> str:
    if not output:
        return ""
    pattern = re.escape(_CLI_SUMMARY_BEGIN) + r"(.*?)" + re.escape(_CLI_SUMMARY_END)
    matches = list(re.finditer(pattern, output, re.DOTALL))
    if matches:
        return matches[-1].group(1).strip()
    return ""


def _clean_cli_generated_summary(summary_text: str) -> str:
    cleaned = summary_text.replace("\r\n", "\n").replace("\r", "\n")
    cleaned = cleaned.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n")
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def _ensure_cli_summary_sections(summary_text: str, cli_summary: dict, frontend_result: dict) -> str:
    required_sections = [
        "Conclusion",
        "Generated artifacts status",
        "Quality / risk signal",
        "Recommendation",
    ]
    text = (summary_text or "").strip()
    if not text:
        return ""

    for section in required_sections:
        text = re.sub(
            rf"(?im)^\s*{re.escape(section)}\s*:\s*$",
            f"### {section}",
            text,
        )

    present_sections = {
        match.group(1).strip().lower()
        for match in re.finditer(r"^###\s+(.+?)\s*$", text, re.MULTILINE)
    }
    if all(section.lower() in present_sections for section in required_sections):
        return text

    logger.warning("CLI summary did not include all required sections; preserving generated text unchanged")
    return text


def _build_deterministic_summary_text(cli_summary: dict, frontend_result: dict) -> str:
    """Build a deterministic summary from the canonical machine result.

    Summary generation used to start a second Claude CLI request.  That made a
    failed workflow consume more quota and allowed free-form prose to disagree
    with the recorded compile, test, and coverage results.
    """
    quality_gate = frontend_result.get("quality_gate") or {}
    compile_ok = bool(frontend_result.get("compile_success"))
    test_total = int(frontend_result.get("test_count") or 0)
    passed_count = int(frontend_result.get("passed_count") or 0)
    failed_cases = list(frontend_result.get("failed_cases") or [])
    test_failures = max(len(failed_cases), test_total - passed_count)
    tests_executed = bool(quality_gate.get("tests_executed") or test_total or failed_cases)
    tests_ok = tests_executed and test_failures == 0
    coverage_available = quality_gate.get("coverage_available")
    if coverage_available is None:
        coverage_available = bool(cli_summary.get("result", {}).get("coverage_available"))
    coverage_met = quality_gate.get("coverage_targets_met")
    if coverage_met is None:
        coverage_met = bool(cli_summary.get("result", {}).get("coverage_met"))
    coverage_pending = bool(frontend_result.get("coverage_pending"))
    if (
        not coverage_pending
        and frontend_result.get("workflow_status") == "completed"
        and tests_ok
        and coverage_met is False
    ):
        coverage_pending = True
    saved_files = frontend_result.get("saved_files") or []
    generated_files = frontend_result.get("test_files") or []
    issues = cli_summary.get("issues") or []

    blockers: list[str] = []
    if not compile_ok:
        blockers.append("compilation failed")
    if not tests_executed:
        blockers.append("test results are unavailable")
    elif not tests_ok:
        blockers.append(f"{test_failures} test{'s' if test_failures != 1 else ''} failed")
    if not coverage_pending and not coverage_available:
        blockers.append("coverage data is unavailable")
    elif not coverage_pending and not coverage_met:
        blockers.append("coverage targets were not met")

    if blockers:
        conclusion = (
            "The workflow failed with " + ", ".join(blockers) + ". "
            "Generated artifacts are partial and must not be treated as validated."
        )
        risk = "The quality gate is blocked by " + ", ".join(blockers) + "."
        recommendation = (
            "Inspect the first compiler or test failure in the execution log, fix the generated code or QBS setup, "
            "then rerun the workflow."
        )
    elif coverage_pending:
        conclusion = (
            f"The workflow completed successfully with {passed_count}/{test_total} tests passing. "
            "Coverage optimization is pending and can be resumed without regenerating the passing tests."
        )
        risk = (
            "The unit-test quality gate passed; coverage targets remain below target "
            "and should be improved before release."
        )
        recommendation = (
            "Resume coverage optimization, then review the generated tests and mocks "
            "against the firmware contract."
        )
    else:
        conclusion = (
            f"The workflow completed successfully with {passed_count}/{test_total} tests passing and coverage targets met. "
            "The generated artifacts are available for review."
        )
        risk = "The automated quality gate passed; firmware behavior and mock assumptions still require manual review."
        recommendation = "Review the generated tests and mocks against the firmware contract, then commit the approved artifacts."

    artifact_count = len(saved_files) or len(generated_files)
    artifact_status = (
        f"{artifact_count} generated artifact{'s' if artifact_count != 1 else ''} "
        f"{'are' if artifact_count != 1 else 'is'} available on disk for inspection."
        if artifact_count
        else "No artifact paths were recorded; files already written to the project may still be available for inspection."
    )
    if issues and blockers:
        risk += " Recorded issue: " + str(issues[0])[:240]
    elif issues and coverage_pending:
        risk += " Recorded issue: " + str(issues[0])[:240]

    return (
        f"### Conclusion\n{conclusion}\n\n"
        f"### Generated artifacts status\n{artifact_status}\n\n"
        f"### Quality / risk signal\n{risk}\n\n"
        f"### Recommendation\n{recommendation}\n"
    )


async def _generate_cli_summary_text(cli_summary: dict, frontend_result: dict, context: "UnitTestContext") -> str:
    """Return the local deterministic summary without another provider call."""
    del context
    return _build_deterministic_summary_text(cli_summary, frontend_result)


def _build_failed_cli_summary_text(frontend_result: dict) -> str:
    """Build a deterministic failure summary without starting another CLI call."""
    errors = [str(item).strip() for item in frontend_result.get("errors") or [] if str(item).strip()]
    blocker = errors[0] if errors else "The unit test workflow terminated before completion."
    if len(blocker) > 320:
        blocker = f"{blocker[:317]}..."
    return (
        "### Conclusion\n"
        "The workflow failed and the generated artifacts must be treated as partial until the blocker is resolved.\n\n"
        "### Generated artifacts status\n"
        "Any files already written to disk remain available for inspection, but no completeness guarantee is provided.\n\n"
        "### Quality / risk signal\n"
        f"The blocking error was: {blocker}\n\n"
        "### Recommendation\n"
        "Inspect the task execution log, resolve the first blocking error, and rerun the workflow before using the generated tests."
    )


def _build_cli_summary(frontend_result: dict, context: "UnitTestContext") -> dict:
    """Build structured Claude CLI summary from task result fields."""
    cr = frontend_result.get("coverage_report") or {}
    branch_cov = cr.get("branch_coverage")
    func_cov   = cr.get("function_coverage")
    line_cov   = cr.get("line_coverage", 0.0) or 0.0
    target_cov = context.coverage_target * 100
    branch_target = context.branch_coverage_target * 100
    function_target = context.function_coverage_target * 100

    # Prefer the agent's quality gate, which knows whether branch/function
    # metrics are applicable.  The fallback keeps older task records honest by
    # requiring every metric that is present to meet its configured target.
    quality_gate = frontend_result.get("quality_gate") or {}
    quality_gate_coverage = quality_gate.get("coverage_targets_met")
    if quality_gate_coverage is None:
        coverage_met = (
            line_cov >= target_cov
            and (branch_cov is None or branch_cov >= branch_target)
            and (func_cov is None or func_cov >= function_target)
        )
    else:
        coverage_met = bool(quality_gate_coverage)

    coverage_available = quality_gate.get("coverage_available")
    if coverage_available is None:
        coverage_available = bool(
            cr.get("lines_total") or frontend_result.get("lines_total") or line_cov > 0
        )
    tests_executed = bool(
        quality_gate.get("tests_executed") or frontend_result.get("test_count")
        or frontend_result.get("test_passes") or frontend_result.get("failed_cases")
    )
    coverage_met = bool(coverage_available and coverage_met)
    what_done = []
    if frontend_result.get("test_files"):
        what_done.append("Generate GoogleTest test cases")
        if any("mock" in (f.get("filename") or "") for f in frontend_result["test_files"]):
            what_done.append("Generate mock files")
    if frontend_result.get("saved_files"):
        what_done.append("Save test files to project")
    if frontend_result.get("qbs_file") or frontend_result.get("qbs_updated"):
        what_done.append("Update QBS project configuration")
    compile_output = frontend_result.get("compile_output") or ""
    if frontend_result.get("compile_success") or compile_output.strip() not in ("", "(no output)"):
        what_done.append("Execute QBS compile verification")
    if tests_executed:
        what_done.append("Run unit test executable")
    if coverage_available:
        what_done.append("Collect coverage data")

    issues: list[str] = []
    if not frontend_result.get("compile_success"):
        issues.append("Compilation errors occurred")
    test_total = int(frontend_result.get("test_count") or 0)
    test_passed = int(frontend_result.get("passed_count") or 0)
    failed_cases = frontend_result.get("failed_cases") or []
    failed_count = len(failed_cases)
    if test_total > 0:
        # Prefer explicit failed-case details, while retaining a reliable
        # aggregate fallback for older records that only stored counts.
        failed_count = max(failed_count, test_total - test_passed)
    if failed_count:
        issues.append(f"{failed_count} test{'s' if failed_count != 1 else ''} failed")
    if not tests_executed:
        issues.append("Test results are unavailable")
    for err in (frontend_result.get("errors") or [])[:3]:
        issues.append(str(err))
    if coverage_available and line_cov < target_cov:
        issues.append(f"Line coverage {line_cov:.1f}% below target {target_cov:.1f}%")
    if not coverage_available:
        issues.append("Coverage data is unavailable")
    if coverage_available and branch_cov is not None and branch_cov < branch_target:
        issues.append(f"Branch coverage {branch_cov:.1f}% below target {branch_target:.1f}%")
    if coverage_available and func_cov is not None and func_cov < function_target:
        issues.append(f"Function coverage {func_cov:.1f}% below target {function_target:.1f}%")

    tool_failure_summary = frontend_result.get("tool_failure_summary") or {}
    if isinstance(tool_failure_summary, dict) and tool_failure_summary.get("total"):
        last_failure = tool_failure_summary.get("last") or {}
        category = str(last_failure.get("category") or "other").replace("_", " ")
        issues.append(
            f"CLI tool failures: {tool_failure_summary.get('total')} "
            f"(last category: {category})"
        )

    next_steps: list[str] = []
    if not frontend_result.get("compile_success"):
        next_steps.extend([
            "Review the compile output and task execution log for the first failing error",
            "Fix generated test or mock code before rerunning the workflow",
            "Verify QBS project configuration and linked test dependencies",
        ])
        if coverage_available and line_cov < target_cov:
            next_steps.append("After compilation is fixed, add tests for uncovered branches and functions")
    else:
        next_steps.append("Manually inspect generated test cases and mocks")
        if failed_count:
            next_steps.append(
                "Inspect the failed test cases and mock expectations before treating the generated suite as production-ready"
            )
        if coverage_available and line_cov < target_cov:
            next_steps.append("Add test cases for uncovered branches and functions")
        if tests_executed and not failed_count and coverage_met:
            next_steps.append("Commit generated files after review")
    if not coverage_available:
        next_steps.append("Run the test executable with coverage instrumentation and collect coverage before assessing targets")

    return {
        "what_was_done": what_done,
        "result": {
            "compile":      "passed" if frontend_result.get("compile_success") else "failed",
            "coverage_met": coverage_met,
            "coverage_available": bool(coverage_available),
        },
        "coverage": {
            "line_target":     round(target_cov, 1),
            "branch_target":   round(branch_target, 1),
            "function_target": round(function_target, 1),
            "line":            round(line_cov, 1),
            "branch":          round(branch_cov, 1) if branch_cov is not None else None,
            "function":        round(func_cov, 1)   if func_cov is not None else None,
        },
        "issues":     issues,
        "next_steps": next_steps,
        "tool_failure_summary": tool_failure_summary,
    }


def _build_diagnostic_failure_result(
    task_id: str,
    context: "UnitTestContext",
    error_message: str,
    *,
    error_code: str = "RUNNER_FAILED",
    started_at: Optional[str] = None,
    finished_at: Optional[str] = None,
) -> tuple[dict, dict]:
    """Create and persist a sanitized local diagnostic for early failures."""
    finished_at = finished_at or datetime.now(timezone.utc).isoformat()
    safe_error = _sanitize_content(error_message or "Unit-Test execution failed")[:20000]
    safe_code = _sanitize_content(error_code or "RUNNER_FAILED")[:200]
    frontend_result = {
        "workflow_status": "failed",
        "compile_success": False,
        "compile_output": safe_error,
        "errors": [safe_error],
        "error": safe_error,
        "error_code": safe_code,
        "final_coverage": 0.0,
        "coverage_measured": False,
        "coverage_unavailable": True,
        "iteration_count": 0,
        "layer": context.layer,
        "functions_tested": [],
        "output_dir": context.output_dir,
        "saved_files": [],
        "coverage_report": {
            "line_coverage": 0.0,
            "branch_coverage": 0.0,
            "branch_coverage_applicable": False,
            "function_coverage": 0.0,
            "lines_executed": 0,
            "lines_total": 0,
            "branches_executed": 0,
            "branches_total": 0,
            "calls_executed": 0,
            "calls_total": 0,
            "functions_executed": 0,
            "functions_total": 0,
        },
        "test_files": [],
        "test_passes": [],
        "test_count": 0,
        "passed_count": 0,
    }
    cli_summary = _build_cli_summary(frontend_result, context)
    cli_summary["summary"] = (
        "### Conclusion\n"
        f"The Unit-Test workflow stopped before a usable result was produced ({safe_code}).\n\n"
        "### Generated artifacts status\n"
        "No generated test artifacts are available; this diagnostic report records the failure.\n\n"
        "### Quality / risk signal\n"
        "The source was not validated by generated, compiled, and executed tests.\n\n"
        "### Recommendation\n"
        "Review the error and provider configuration below, then rerun or resume the task."
    )
    cli_log_path = _save_cli_log(
        task_id,
        cli_summary,
        frontend_result,
        context,
        started_at=started_at,
        finished_at=finished_at,
    )
    artifact = _build_cli_log_artifact(
        task_id,
        cli_log_path,
        finished_at,
        secrets.token_urlsafe(32),
    )
    frontend_result["cli_summary"] = cli_summary
    frontend_result["cli_log_artifact"] = artifact
    pending_log_args = {
        "cli_summary": cli_summary,
        "frontend_result": frontend_result,
        "context": context,
        "finished_at": finished_at,
        "started_at": started_at,
    }
    return frontend_result, pending_log_args


def _save_cli_log(
    task_id: str,
    cli_summary: dict,
    frontend_result: dict,
    context: "UnitTestContext",
    started_at: Optional[str] = None,
    finished_at: Optional[str] = None,
) -> Optional[str]:
    """Write a Markdown CLI log alongside generated test files.

    The summary section appears at the top; full execution details follow.
    All content is sanitized before writing.
    Returns the absolute log file path, or None on failure.
    """
    try:
        output_dir = _resolve_cli_log_output_dir(frontend_result)
        os.makedirs(output_dir, exist_ok=True)

        # Extract source file name from context
        source_name = "unknown"
        if context.source_files and len(context.source_files) > 0:
            source_file = context.source_files[0]
            source_name = os.path.splitext(os.path.basename(source_file))[0]

        # Generate timestamp (YYYYMMDD-HHMMSS format)
        timestamp = datetime.now(_BEIJING_TZ).strftime("%Y%m%d-%H%M%S")

        existing_artifact = frontend_result.get("cli_log_artifact") or {}
        log_filename = existing_artifact.get("filename")
        if log_filename:
            log_filename = os.path.basename(log_filename)
        if not log_filename:
            log_filename = f"{source_name}-unittest-report-{timestamp}.md"
        log_path = os.path.join(output_dir, log_filename)

        lines: list[str] = []

        from app.core.config import resolve_claude_cli_model, get_settings
        status_str = str(frontend_result.get("workflow_status") or "").lower()
        if status_str not in {"completed", "failed", "cancelled", "paused"}:
            test_total = int(frontend_result.get("test_count") or 0)
            passed_count = int(frontend_result.get("passed_count") or 0)
            failed_cases = frontend_result.get("failed_cases") or []
            tests_failed = bool(failed_cases) or (test_total > 0 and passed_count < test_total)
            status_str = "completed" if frontend_result.get("compile_success") and not tests_failed else "failed"
        model_str  = resolve_claude_cli_model(get_settings())

        # ── Summary section ─────────────────────────────────────────
        lines.append(f"# {log_filename}")
        lines.append("")
        lines.append("## Metadata")
        lines.append("")
        lines.append("| Key | Value |")
        lines.append("|-----|-------|")
        lines.append(f"| task_id | `{task_id}` |")
        lines.append(f"| status | {status_str} |")
        lines.append(f"| started_at | {started_at or finished_at or datetime.now(timezone.utc).isoformat()} |")
        lines.append(f"| finished_at | {finished_at or datetime.now(timezone.utc).isoformat()} |")
        lines.append(f"| model | {model_str} |")
        lines.append(f"| layer | {context.layer} |")
        lines.append("")

        lines.append("## What Was Done")
        lines.append("")
        for item in cli_summary.get("what_was_done", []):
            lines.append(f"- ✓ {item}")
        lines.append("")

        r = cli_summary.get("result", {})
        compile_ok   = r.get("compile", "unknown")
        coverage_met = r.get("coverage_met", False)
        test_total   = frontend_result.get("test_count") or 0
        test_passed  = frontend_result.get("passed_count") or 0
        test_rate    = round((test_passed / test_total) * 100) if test_total else 0
        compile_label = "Passed" if compile_ok == "passed" else str(compile_ok).capitalize()
        coverage_label = "Met" if coverage_met else "Not met"
        lines.append("## Result")
        lines.append("")
        lines.append(f"- **Compile**: {compile_label}")
        lines.append(f"- **Coverage target**: {coverage_label}")
        test_label = f"{test_rate}%({test_passed} / {test_total})" if test_total else "Unavailable (no test results recorded)"
        lines.append(f"- **Test result**: {test_label}")
        lines.append("")

        cov    = cli_summary.get("coverage", {})
        branch = cov.get("branch")
        func   = cov.get("function")
        line_target = cov.get("line_target", 90)
        branch_target = cov.get("branch_target", 80)
        function_target = cov.get("function_target", 80)
        branch_result = f"{branch}%" if branch is not None else "N/A"
        function_result = f"{func}%" if func is not None else "N/A"
        line_result = f"{cov.get('line', 0)}%"
        if r.get("coverage_available") is False:
            line_result = branch_result = function_result = "N/A"
        lines.append("## Coverage")
        lines.append("")
        lines.append("| Coverage | Target | Result |")
        lines.append("|----------|--------|--------|")
        lines.append(f"| Line coverage | {line_target}% | {line_result} |")
        lines.append(f"| Branch coverage | {branch_target}% | {branch_result} |")
        lines.append(f"| Function coverage | {function_target}% | {function_result} |")
        lines.append("")

        issues = cli_summary.get("issues", [])
        lines.append("## Issues")
        lines.append("")
        if issues:
            for issue in issues:
                lines.append(f"- ⚠ {issue}")
        else:
            lines.append("_(none)_")
        lines.append("")

        lines.append("## Summary")
        lines.append("")
        summary_text = (cli_summary.get("summary") or "").strip()
        summary_text = _ensure_cli_summary_sections(summary_text, cli_summary, frontend_result)
        lines.extend(summary_text.splitlines())
        lines.append("")

        # ── Full execution log ───────────────────────────────────────
        lines.append("---")
        lines.append("")
        lines.append("# Full Execution Log")
        lines.append("")

        token_usage = frontend_result.get("token_usage") or {}
        lines.append("## Token Usage")
        lines.append("")
        lines.append("| Key | Value |")
        lines.append("|-----|-------|")
        lines.append(f"| input_tokens | {token_usage.get('input_tokens', 0)} |")
        lines.append(f"| output_tokens | {token_usage.get('output_tokens', 0)} |")
        lines.append(f"| cache_creation_input_tokens | {token_usage.get('cache_creation_input_tokens', 0)} |")
        lines.append(f"| cache_read_input_tokens | {token_usage.get('cache_read_input_tokens', 0)} |")
        lines.append(f"| total_tokens | {token_usage.get('total_tokens', 0)} |")
        lines.append("")

        compile_output = frontend_result.get("compile_output") or "(no output)"
        lines.append("## Compile Output")
        lines.append("")
        lines.append("```")
        lines.append(_sanitize_content(compile_output))
        lines.append("```")
        lines.append("")

        saved_files = frontend_result.get("saved_files") or []
        lines.append("## Saved Files")
        lines.append("")
        if saved_files:
            for sf in saved_files:
                lines.append(f"- `{sf}`")
        else:
            lines.append("_(none)_")
        lines.append("")

        # ── Append raw task execution log (logs/task_{task_id}.log) ──
        task_log_path = str(_BACKEND_LOG_DIR / f"task_{task_id}.log")
        if os.path.isfile(task_log_path):
            lines.append("## Task Execution Log")
            lines.append("")
            lines.append("```")
            try:
                with open(task_log_path, "r", encoding="utf-8", errors="replace") as f:
                    raw_log = f.read()
                lines.append(_sanitize_content(raw_log))
            except Exception as read_err:
                lines.append(f"(failed to read task log: {read_err})")
            lines.append("```")
            lines.append("")

        content = "\n".join(lines)
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(content)

        logger.info(f"CLI log saved: {log_path} (filename: {log_filename})")
        return log_path
    except Exception as e:
        logger.warning(f"Failed to save CLI log for task {task_id}: {e}")
        return None


def _build_cli_log_artifact(task_id: str, cli_log_path: Optional[str], finished_at: str, download_token: Optional[str] = None) -> dict:
    """Build frontend metadata for the generated CLI log artifact."""
    download_url = f"/api/v1/download/{task_id}/cli-log"
    if download_token:
        download_url = f"{download_url}?token={download_token}"
    return {
        "available":    bool(cli_log_path),
        "filename":     os.path.basename(cli_log_path) if cli_log_path else "claude-cli.md",
        "download_url": download_url,
        "size_bytes":   os.path.getsize(cli_log_path) if cli_log_path and os.path.isfile(cli_log_path) else 0,
        "created_at":   finished_at,
        "download_token": download_token or "",
    }


def _get_cli_log_artifact_path(result_data: dict) -> Optional[str]:
    artifact = result_data.get("cli_log_artifact") or {}
    artifact_path = artifact.get("path")
    if artifact_path:
        return artifact_path

    filename = artifact.get("filename")
    saved_files = result_data.get("saved_files") or []
    if filename:
        if saved_files:
            log_dir = _resolve_cli_log_output_dir(result_data)
            return os.path.join(log_dir, filename)
        return str(_BACKEND_OUTPUT_DIR / filename)
    return None


def _build_persisted_task_diagnostic(task: Task, result_data: Optional[dict]) -> str:
    """Render a downloadable diagnostic from persisted task state only."""
    result_data = result_data if isinstance(result_data, dict) else {}
    error_code = _sanitize_content(str(result_data.get("error_code") or "TASK_FAILED"))[:200]
    error_message = _sanitize_content(
        str(
            result_data.get("error")
            or task.error_message
            or task.message
            or "No additional error detail was persisted."
        )
    )[:20000]
    return "\n".join(
        [
            f"# Unit-Test diagnostic - {task.id}",
            "",
            "## Metadata",
            "",
            "| Key | Value |",
            "|-----|-------|",
            f"| task_id | `{task.id}` |",
            f"| status | {_sanitize_content(str(task.status or 'unknown'))} |",
            f"| error_code | {error_code} |",
            "",
            "## Error",
            "",
            "```text",
            error_message,
            "```",
            "",
            "## Recommendation",
            "",
            "Configure or renew the selected provider credentials, then rerun or resume the task.",
            "",
            "_This diagnostic was reconstructed from persisted task state because the original task ended before a full CLI report artifact was created._",
            "",
        ]
    )


def _is_safe_cli_log_path(log_path: str, task: Task) -> bool:
    candidate = os.path.abspath(log_path)
    allowed_roots = [os.path.abspath(str(_BACKEND_OUTPUT_DIR))]

    if task.result_data:
        try:
            result_data = json.loads(task.result_data)
            output_dir = result_data.get("output_dir")
            if output_dir:
                allowed_roots.append(os.path.abspath(output_dir))
            for saved_path in result_data.get("saved_files") or []:
                if saved_path:
                    allowed_roots.append(os.path.dirname(os.path.abspath(saved_path)))
        except (TypeError, json.JSONDecodeError):
            pass

    for allowed_root in allowed_roots:
        try:
            if os.path.commonpath([candidate, allowed_root]) == allowed_root:
                return True
        except ValueError:
            continue
    return False


def _is_using_bedrock() -> bool:
    """Check if the current LLM provider is AWS Bedrock."""
    from app.core.config import resolve_agent_llm_selection
    return resolve_agent_llm_selection("unittest").provider == "bedrock"


def _check_aws_auth_error(error_msg: str) -> bool:
    """Check if an error message indicates an AWS authentication issue."""
    import re
    msg_lower = error_msg.lower()
    patterns = [
        r"aws_auth_required",
        r"expiredtoken",
        r"token\s+is\s+expired",
        r"token\s+has\s+expired",
        r"sso\s*token.*(?:expired|invalid|missing)",
        r"the\s+sso\s+session\s+.*has\s+expired",
        r"aws\s+sso\s+login",
        r"credentials?\s+(?:expired|missing|invalid|not\s+found)",
        r"unable\s+to\s+locate\s+credentials",
        r"not\s+logged\s+in",
        r"no\s+valid\s+credential\s+sources",
        r"security\s+token.*(?:expired|invalid)",
        r"unrecogni[sz]edclientexception",
    ]
    return any(re.search(p, msg_lower) for p in patterns)


def _check_provider_auth_error(error_msg: str) -> bool:
    """Recognize recoverable authentication failures from non-AWS providers."""
    msg_lower = (error_msg or "").lower()
    quota_patterns = (
        r"quota_exceeded",
        r"insufficient_user_quota",
        r"\bquota(?:\s+|_)?(?:exceeded|insufficient|exhausted)\b",
        r"\binsufficient\s+(?:user\s+)?quota\b",
    )
    if any(re.search(pattern, msg_lower) for pattern in quota_patterns):
        return True
    patterns = (
        r"provider_auth_required",
        r"invalid\s+api\s*key",
        r"api\s+key\s+not\s+valid",
        r"authentication_error",
        r'"error"\s*:\s*"authentication_failed"',
        r"(?:api|router|upstream|provider|anthropic|openrouter|turing)[^\n]{0,120}\b(?:401|403)\b",
        r"(?:http\s+status|status(?:\s+code)?|response\s+status)\s*[:=]?\s*(?:401|403)\b",
        r'"status"\s*:\s*(?:401|403)\b',
        r"(?:api|router|upstream|provider)[^\n]{0,120}\b(?:unauthorized|forbidden)\b",
    )
    return any(re.search(pattern, msg_lower) for pattern in patterns)


def _classify_auth_error(error_msg: str) -> Optional[str]:
    """Classify auth errors so recoverable failures retain their task context."""
    error_msg = error_msg or ""
    if "AWS_PROFILE_NOT_FOUND" in error_msg:
        return "profile"
    if _check_aws_auth_error(error_msg):
        return "aws"
    if _check_provider_auth_error(error_msg):
        return "provider"
    return None


def _latest_compact_context_path(task_id: str) -> Path:
    safe_task_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(task_id)) or "unknown"
    return _BACKEND_OUTPUT_DIR / f"compact_context_latest_{safe_task_id}.txt"


def _load_latest_compact_context(task_id: str) -> str:
    try:
        path = _latest_compact_context_path(task_id)
        if path.is_file():
            return path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("Failed to load compact context for task %s: %s", task_id, exc)
    return ""


def _remove_latest_compact_context(task_id: str) -> None:
    try:
        _latest_compact_context_path(task_id).unlink(missing_ok=True)
    except OSError as exc:
        logger.warning("Failed to remove compact context for task %s: %s", task_id, exc)


def _auto_trigger_sso_login() -> None:
    """Best-effort trigger of AWS SSO re-login (non-blocking)."""
    try:
        from app.core.aws_sso_cache import AWSSSOCache
        from app.core.config import get_settings
        settings = get_settings()
        profile = getattr(settings, "AWS_PROFILE", None) or "default"
        region = getattr(settings, "AWS_REGION", None) or "eu-west-1"
        cache = AWSSSOCache(profile_name=profile, region=region)
        result = cache.trigger_sso_login(clear_cache=False)
        logger.info(f"Auto SSO re-login trigger result: {result}")
    except Exception as e:
        logger.warning(f"Failed to auto-trigger SSO re-login: {e}")


# ---------- Stage mapping ----------

# Backend agent.py _report_progress(stage=...) → Frontend PIPELINE_NODE key
STAGE_TO_NODE = {
    "fetch":            "init_project_context",
    "ast":              "detect_layer",
    "layer":            "detect_layer",
    "framework":        "generate_paths",
    "prompt":           "build_prompt",
    "generate":         "generate_tests",
    "mock":             "generate_tests",
    "parse":            "parse_output",
    "qbs_config":       "update_qbs_config",
    "compile":          "qbs_build",
    "handle_errors":    "qbs_build",
    "autonomous_fix":   "qbs_build",
    "save":             "save_files",
    "run":              "run_tests",
    "coverage":         "analyze_coverage",
    "coverage_improve": "analyze_coverage",
    "report":           "finalize",
}
# Ordered list of frontend nodes
FRONTEND_NODES = [
    "init_project_context", "detect_layer", "generate_paths",
    "build_prompt", "generate_tests", "parse_output", "update_qbs_config",
    "qbs_build", "run_tests", "analyze_coverage", "save_files", "finalize",
]
TASK_START_COMPLETED_NODES = frozenset({
    "detect_layer",
    "generate_paths",
    "build_prompt",
})

_WORKFLOW_STATE_KEY = "_workflow_state"
_WORKFLOW_NODE_STAGES = {
    "init_project_context": "fetch",
    "detect_layer": "layer",
    "generate_paths": "framework",
    "build_prompt": "prompt",
    "generate_tests": "generate",
    "parse_output": "parse",
    "update_qbs_config": "qbs_config",
    "qbs_build": "compile",
    "run_tests": "run",
    "analyze_coverage": "coverage",
    "save_files": "save",
    "finalize": "report",
}
_LEGACY_PROGRESS_NODES = (
    (5, "init_project_context"),
    (8, "detect_layer"),
    (12, "generate_paths"),
    (15, "build_prompt"),
    (20, "generate_tests"),
    (50, "parse_output"),
    (55, "update_qbs_config"),
    (60, "qbs_build"),
    (75, "run_tests"),
    (85, "analyze_coverage"),
    (98, "save_files"),
    (99, "finalize"),
)
_VALID_NODE_STATUSES = {"pending", "in_progress", "completed", "failed", "skipped", "cancelled"}

# A build can only be started after the generated output has been parsed and
# the QBS configuration has been prepared.  CLI-driven tasks may not emit
# callbacks for those short phases, so the build event is authoritative proof
# that both prerequisites ran successfully.  Keep this invariant in the API
# snapshot so live polling and restored tasks expose the same state.
_BUILD_REQUIRED_NODES = ("parse_output", "update_qbs_config")


def _enforce_workflow_order(node_map: dict[str, str]) -> dict[str, str]:
    """Apply non-regressing workflow prerequisites to a canonical node map."""
    qbs_config_status = node_map.get("update_qbs_config")
    if qbs_config_status in {"in_progress", "completed", "failed"}:
        if node_map.get("parse_output") not in {"failed", "cancelled"}:
            node_map["parse_output"] = "completed"

    build_status = node_map.get("qbs_build")
    if build_status in {"in_progress", "completed", "failed"}:
        for node_name in _BUILD_REQUIRED_NODES:
            if node_map.get(node_name) not in {"failed", "cancelled"}:
                node_map[node_name] = "completed"

    # Coverage collection is performed after executing the test binary. CLI
    # activity may skip the short run callback, so entering coverage is already
    # authoritative evidence that Run Tests completed successfully.
    if node_map.get("analyze_coverage") in {"in_progress", "completed"}:
        if node_map.get("run_tests") not in {"failed", "cancelled"}:
            node_map["run_tests"] = "completed"
    return node_map


def _new_workflow_nodes() -> dict[str, str]:
    """Return the canonical task-start workflow state."""
    return {
        node_name: (
            "completed"
            if node_name in TASK_START_COMPLETED_NODES
            else "pending"
        )
        for node_name in FRONTEND_NODES
    }


def _coerce_workflow_node_map(nodes: Any) -> dict[str, str]:
    """Return valid workflow node states keyed by canonical node name."""
    if isinstance(nodes, list):
        node_map = {
            str(item.get("node_name")): str(item.get("status"))
            for item in nodes
            if isinstance(item, dict) and item.get("node_name")
        }
    elif isinstance(nodes, dict):
        node_map = {str(name): str(status) for name, status in nodes.items()}
    else:
        node_map = {}

    return {
        node_name: status
        for node_name, status in node_map.items()
        if node_name in FRONTEND_NODES and status in _VALID_NODE_STATUSES
    }


def _normalize_workflow_nodes(
    nodes: Any,
    *,
    task_status: Optional[str] = None,
    current_stage: Optional[str] = None,
) -> dict[str, str]:
    """Normalize workflow state into one authoritative backend representation.

    The preparation nodes are a product contract: once a task is accepted they
    are complete, even when an older task record omitted their telemetry.  For
    later nodes we only infer the currently reported node and completion of an
    already active predecessor.  We deliberately do not mark unseen nodes as
    skipped during progress callbacks; skipped is reserved for terminal
    workflows where the backend can prove a node was not executed.
    """
    status = str(task_status or "").lower()
    normalized = _new_workflow_nodes() if status in {
        "running", "paused", "completed", "failed", "cancelled"
    } else {node_name: "pending" for node_name in FRONTEND_NODES}
    normalized.update(_coerce_workflow_node_map(nodes))

    if status in {"running", "paused", "completed", "failed", "cancelled"}:
        for node_name in TASK_START_COMPLETED_NODES:
            # Preserve an explicit terminal failure/cancellation.  All other
            # legacy/intermediate values are normalized to the startup state.
            if normalized.get(node_name) not in {"failed", "cancelled"}:
                normalized[node_name] = "completed"

    current_node = STAGE_TO_NODE.get(str(current_stage or ""))
    if current_node and status in {"running", "paused"}:
        if current_node in TASK_START_COMPLETED_NODES:
            normalized[current_node] = "completed"
        elif normalized.get(current_node) not in {"completed", "failed", "cancelled"}:
            normalized[current_node] = "in_progress"

        current_index = FRONTEND_NODES.index(current_node)
        for node_name in FRONTEND_NODES[:current_index]:
            if normalized.get(node_name) == "in_progress":
                normalized[node_name] = "completed"

    normalized = _enforce_workflow_order(normalized)
    return {node_name: normalized.get(node_name, "pending") for node_name in FRONTEND_NODES}


def _workflow_nodes_as_list(
    nodes: Any,
    *,
    task_status: Optional[str] = None,
    current_stage: Optional[str] = None,
) -> list[dict[str, str]]:
    node_map = _normalize_workflow_nodes(
        nodes,
        task_status=task_status,
        current_stage=current_stage,
    )

    return [
        {
            "node_name": node_name,
            "status": node_map[node_name],
        }
        for node_name in FRONTEND_NODES
    ]


def _build_workflow_snapshot(entry: Optional[dict]) -> dict:
    entry = entry or {}
    current_stage = str(entry.get("current_stage") or "")
    task_status = str(entry.get("status") or "running")
    normalized_nodes = _normalize_workflow_nodes(
        entry.get("nodes"),
        task_status=task_status,
        current_stage=current_stage,
    )
    # Keep the in-memory entry canonical so every subsequent poll sees the
    # same state that was persisted in the workflow snapshot.
    if isinstance(entry, dict) and entry.get("nodes") is not None:
        entry["nodes"] = normalized_nodes
    return {
        "current_stage": current_stage,
        "nodes": _workflow_nodes_as_list(
            normalized_nodes,
            task_status=task_status,
            current_stage=current_stage,
        ),
        "details": dict(entry.get("details") or {}),
        "cli_activity": dict(entry.get("cli_activity") or {}),
        "cli_activity_sequence": int(entry.get("cli_activity_sequence") or 0),
        "token_usage": dict(entry.get("token_usage") or {}),
        "started_at": entry.get("started_at"),
        "last_activity_at": entry.get("last_activity_at"),
        "last_business_progress_at": entry.get("last_business_progress_at"),
        "business_progress_sequence": int(entry.get("business_progress_sequence") or 0),
        "tool_failure_summary": dict(entry.get("tool_failure_summary") or {}),
    }


def _mark_workflow_terminal(entry: Optional[dict], status: str) -> None:
    if not entry or not isinstance(entry.get("nodes"), dict):
        return

    entry["status"] = status
    entry["nodes"] = _normalize_workflow_nodes(
        entry["nodes"],
        task_status=status,
        current_stage=entry.get("current_stage"),
    )
    nodes = entry["nodes"]
    current_node = STAGE_TO_NODE.get(str(entry.get("current_stage") or ""))
    if status == "completed":
        for node_name in FRONTEND_NODES:
            node_status = nodes.get(node_name, "pending")
            if node_status == "in_progress":
                nodes[node_name] = "completed"
            elif node_status == "pending":
                nodes[node_name] = "skipped"
        return

    terminal_node_status = "cancelled" if status == "cancelled" else "failed"
    if current_node and current_node in nodes:
        nodes[current_node] = terminal_node_status
        return

    for node_name in reversed(FRONTEND_NODES):
        if nodes.get(node_name) == "in_progress":
            nodes[node_name] = terminal_node_status
            return


def _authoritative_completed_workflow_nodes(nodes: Any) -> dict[str, str]:
    """Return a terminal node map reconciled from passing build and test evidence."""
    normalized = _normalize_workflow_nodes(
        nodes,
        task_status="completed",
        current_stage="report",
    )
    for node_name, node_status in normalized.items():
        if node_status in {"failed", "cancelled", "in_progress"}:
            normalized[node_name] = "completed"
        elif node_status == "pending":
            normalized[node_name] = "skipped"
    normalized["finalize"] = "completed"
    return normalized


def _result_payload_with_workflow(result_payload: Optional[dict], entry: Optional[dict]) -> dict:
    payload = dict(result_payload or {})
    payload[_WORKFLOW_STATE_KEY] = _build_workflow_snapshot(entry)
    return payload


def _load_persisted_result(task: Task) -> dict:
    if not task.result_data:
        return {}
    try:
        payload = json.loads(task.result_data)
    except (TypeError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _seconds_since_timestamp(value: Any, now: Optional[datetime] = None) -> int:
    """Return elapsed seconds for an ISO timestamp or datetime value."""
    if not value:
        return 0
    try:
        parsed = value if isinstance(value, datetime) else datetime.fromisoformat(str(value))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        reference = now or datetime.now(timezone.utc)
        return max(0, int((reference - parsed).total_seconds()))
    except (TypeError, ValueError):
        return 0


def _infer_legacy_workflow_node(task: Task, result_payload: dict) -> Optional[str]:
    message = str(task.error_message or task.message or "").lower()
    if result_payload.get("coverage_build_failed") or "coverage" in message or "gcov" in message:
        return "analyze_coverage"
    if (
        result_payload.get("build_failed")
        or result_payload.get("compile_success") is False
        or "qbs" in message
        or "compil" in message
    ):
        return "qbs_build"
    if result_payload.get("save_failures"):
        return "save_files"
    if result_payload.get("failed_cases"):
        return "run_tests"
    if "static quality" in message:
        return "finalize"

    progress = max(0, int(task.progress or 0))
    current_node = None
    for threshold, node_name in _LEGACY_PROGRESS_NODES:
        if progress < threshold:
            break
        current_node = node_name
    return current_node


def _legacy_workflow_snapshot(task: Task, result_payload: dict) -> dict:
    if task.status == "completed":
        nodes = _workflow_nodes_as_list(
            {name: "completed" for name in FRONTEND_NODES},
            task_status="completed",
            current_stage="report",
        )
        return {"current_stage": "report", "nodes": nodes}

    current_node = _infer_legacy_workflow_node(task, result_payload)
    terminal_status = (
        "failed"
        if task.status == "failed"
        else "cancelled"
        if task.status == "cancelled"
        else "in_progress"
    )
    nodes = []
    reached_current = False
    for node_name in FRONTEND_NODES:
        if current_node and node_name == current_node:
            nodes.append({"node_name": node_name, "status": terminal_status})
            reached_current = True
        elif current_node and not reached_current:
            nodes.append({"node_name": node_name, "status": "completed"})
        else:
            nodes.append({"node_name": node_name, "status": "pending"})
    current_stage = _WORKFLOW_NODE_STAGES.get(current_node or "", "")
    return {
        "current_stage": current_stage,
        "nodes": _workflow_nodes_as_list(
            nodes,
            task_status=task.status,
            current_stage=current_stage,
        ),
    }


def _workflow_snapshot_from_task(task: Task, result_payload: dict) -> dict:
    stored = result_payload.get(_WORKFLOW_STATE_KEY)
    if isinstance(stored, dict) and stored.get("nodes"):
        snapshot = dict(stored)
        snapshot["nodes"] = _workflow_nodes_as_list(
            stored.get("nodes"),
            task_status=task.status,
            current_stage=stored.get("current_stage"),
        )
        return snapshot
    return _legacy_workflow_snapshot(task, result_payload)


def _cleanup_terminal_cli(task_id: str, status: str) -> None:
    """Stop any CLI work that outlived the task's terminal status."""
    if status not in {"completed", "failed", "cancelled"}:
        return
    from app.utils.claude_cli_monitor import cleanup_task_cli, is_cli_cancelled

    # Keep the cancellation flag until the worker's finally block has run so
    # a race cannot start a prodding/recovery request after cancellation.
    cleanup_task_cli(
        task_id,
        preserve_cancel_flag=status == "cancelled" or is_cli_cancelled(task_id),
    )

# In-memory progress storage: task_id -> progress dict
_task_progress: dict[str, dict] = {}
_progress_cleanup_tasks: dict[str, asyncio.Task] = {}

# Task cancellation flag: task_id -> bool
_task_cancelled: dict[str, bool] = {}

# Running tasks: task_id -> asyncio.Task
_running_tasks: dict[str, asyncio.Task] = {}

_workspace_lease_manager = WorkspaceLeaseManager()
_workspace_pending = _workspace_lease_manager.pending
_WORKSPACE_TERMINAL_STATES = {"completed", "failed", "cancelled", "paused"}


def _workspace_key(output_dir: str) -> str:
    """Return the normalized key used for a UnitTest project workspace."""
    return WorkspaceLeaseManager.key(output_dir)


async def _reserve_workspace(task_id: str, output_dir: str) -> Optional[str]:
    """Reserve a project workspace, returning the current owner on conflict."""
    return await _workspace_lease_manager.reserve(
        task_id,
        output_dir,
        owner_is_dead=_is_workspace_owner_dead,
    )


def _is_workspace_owner_dead(owner_task_id: str) -> bool:
    """Reclaim a process-local lease only after its task is known to be terminal."""
    running = _running_tasks.get(owner_task_id)
    if running is not None and not running.done():
        return False

    entry = _task_progress.get(owner_task_id)
    if entry is not None:
        return entry.get("status") in _WORKSPACE_TERMINAL_STATES
    if owner_task_id in _workspace_pending:
        return False
    return True


async def _release_workspace(task_id: str) -> None:
    """Release every workspace reservation held by a task."""
    await _workspace_lease_manager.release(task_id)


def _mark_workspace_active(task_id: str) -> None:
    """Mark a reservation active after the task row and progress are initialized."""
    _workspace_lease_manager.mark_active(task_id)


async def _execute_agent_without_deadline(
    agent: UnitTestAgent,
    task_desc: str,
    context: UnitTestContext,
):
    """Execute a Unit Test task without a total runtime deadline."""
    return await agent.execute(task_desc, context)

# Token usage trackers: task_id -> ClaudeCliMonitor instance
_task_monitors: dict[str, Any] = {}


def _init_progress(task_id: str, meta: Optional[dict] = None) -> dict:
    """Initialize task progress entry."""
    meta = meta or {}
    now = datetime.now(timezone.utc).isoformat()
    entry = {
        "task_id": task_id,
        "status": "running",
        "progress": 0,
        "current_stage": "",
        "message": "Task started",
        "nodes": _new_workflow_nodes(),
        "result": None,
        "error": None,
        "aws_auth_required": False,
        "generic_auth_required": False,
        "started_at": now,
        "last_activity_at": now,
        "last_business_progress_at": now,
        "business_progress_sequence": 0,
        "details": {},
        "cli_activity": {},
        "cli_activity_sequence": 0,
        "tool_failure_summary": {},
        "meta": {
            "title": meta.get("title") or "",
            "source_filename": meta.get("source_filename") or "",
            "source_full_path": meta.get("source_full_path") or "",
            "output_dir": "",
        },
        "token_usage": {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        },
    }
    _task_progress[task_id] = entry
    return entry


def _schedule_progress_cleanup(task_id: str, delay: float = 60.0) -> None:
    """Drop terminal in-memory state after a short polling compatibility window."""
    previous = _progress_cleanup_tasks.pop(task_id, None)
    if previous is not None and not previous.done():
        previous.cancel()

    async def cleanup() -> None:
        try:
            await asyncio.sleep(delay)
            entry = _task_progress.get(task_id)
            if entry is not None and entry.get("status") in _WORKSPACE_TERMINAL_STATES:
                _task_progress.pop(task_id, None)
                _task_cancelled.pop(task_id, None)
        except asyncio.CancelledError:
            return
        finally:
            current = _progress_cleanup_tasks.get(task_id)
            if current is asyncio.current_task():
                _progress_cleanup_tasks.pop(task_id, None)

    _progress_cleanup_tasks[task_id] = asyncio.create_task(
        cleanup(), name=f"unittest-progress-cleanup:{task_id}"
    )


def _update_token_activity(entry: dict, token_usage: dict) -> bool:
    """Update token counters and activity time only when usage advances."""
    latest_usage = {
        "input_tokens": token_usage.get("input_tokens", 0),
        "output_tokens": token_usage.get("output_tokens", 0),
        "total_tokens": token_usage.get("total_tokens", 0),
        "cache_creation_input_tokens": token_usage.get("cache_creation_input_tokens", 0),
        "cache_read_input_tokens": token_usage.get("cache_read_input_tokens", 0),
    }
    if latest_usage == entry["token_usage"]:
        return False

    entry["token_usage"].update(latest_usage)
    entry["last_activity_at"] = datetime.now(timezone.utc).isoformat()
    return True


def _apply_cli_activity(task_id: str, activity: dict) -> bool:
    """Map a Claude CLI activity snapshot to UnitTest workflow progress."""
    entry = _task_progress.get(task_id)
    if not entry or not activity:
        return False

    sequence = int(activity.get("sequence") or 0)
    if sequence <= int(entry.get("cli_activity_sequence") or 0):
        return False

    message = str(activity.get("message") or "Claude CLI is working")[:240]
    detail = str(activity.get("detail") or "")
    kind = str(activity.get("kind") or "analysis")
    metadata = activity.get("metadata") if isinstance(activity.get("metadata"), dict) else {}
    runtime = activity.get("runtime") if isinstance(activity.get("runtime"), dict) else {}
    if runtime:
        entry["tool_failure_summary"] = dict(runtime.get("tool_failure_summary") or runtime)
    searchable = f"{message} {detail}".lower()

    # Do not infer a workflow stage from arbitrary tool detail text. A source
    # file, symbol, or compiler diagnostic may contain words such as
    # ``coverage``/``compile`` while the CLI is still reading or generating.
    # Only explicit coverage commands/messages advance the coverage node.
    coverage_signal = (
        any(term in message.lower() for term in ("gcov", "lcov", "coverage report", "collect coverage", "running coverage"))
        or any(term in detail.lower() for term in ("gcov -", "lcov ", "gcovr "))
    )
    if coverage_signal:
        stage, progress = "coverage", 85
    elif any(term in message.lower() for term in ("qbs build", "cmake --build", "ninja", "make ", "compiling", "compile command")):
        stage, progress = "compile", 60
    elif any(term in message.lower() for term in ("ctest", "run test", "test executable", "running tests")):
        stage, progress = "run", 75
    elif kind == "write":
        stage, progress = "generate", 35
    else:
        stage, progress = "generate", 20

    current_progress = int(entry.get("progress") or 0)
    if progress < current_progress:
        stage = str(entry.get("current_stage") or stage)
        progress = current_progress

    entry["cli_activity_sequence"] = sequence
    entry["cli_activity"] = {
        "kind": kind,
        "message": message,
        "detail": detail[:500],
        "updated_at": activity.get("updated_at"),
    }
    if metadata.get("tool_failure"):
        entry["tool_failure_summary"] = {
            **(entry.get("tool_failure_summary") or {}),
            "last": dict(metadata["tool_failure"]),
        }
    _on_stage_progress(
        task_id,
        ProgressUpdate(
            task_id=task_id,
            progress=progress,
            stage=stage,
            message=message,
            details={
                "cli_activity": entry["cli_activity"],
                "tool_failure_summary": entry.get("tool_failure_summary") or {},
                "business_progress": bool(metadata.get("business_progress")),
            },
        ),
    )
    return True



def _on_stage_progress(task_id: str, update) -> None:
    """
    Progress callback: maps ProgressUpdate emitted from agent._report_progress
    to in-memory progress _task_progress, drives frontend pipeline node state.

    update is ProgressUpdate(task_id, progress, stage, message, details)
    """
    entry = _task_progress.get(task_id)
    if entry is None:
        return

    stage = getattr(update, "stage", "") or ""
    if stage == "skill_runtime":
        # Skill preparation is telemetry, not a compile/test workflow gate.
        entry["details"] = {
            **(entry.get("details") or {}),
            **dict(getattr(update, "details", None) or {}),
        }
        entry["last_activity_at"] = datetime.now(timezone.utc).isoformat()
        return
    # Progress is a percentage and must remain bounded even when a coverage
    # loop has more than four iterations. This keeps API and UI indicators
    # monotonic and prevents values such as 102% from being emitted.
    reported_progress = min(100, max(0, int(getattr(update, "progress", 0) or 0)))
    progress = reported_progress
    message = getattr(update, "message", "") or ""
    details = dict(getattr(update, "details", None) or {})

    # Progress events can arrive out of order when CLI telemetry and agent
    # callbacks are merged.  Keep the task timeline monotonic so an older
    # event cannot move the UI back to an earlier stage or percentage.
    previous_progress = int(entry.get("progress") or 0)
    previous_stage = str(entry.get("current_stage") or "")
    previous_node = STAGE_TO_NODE.get(previous_stage)
    incoming_node = STAGE_TO_NODE.get(stage)
    if progress < previous_progress:
        progress = previous_progress
    if (
        incoming_node
        and previous_node
        and incoming_node != previous_node
        and reported_progress <= previous_progress
        and FRONTEND_NODES.index(incoming_node) < FRONTEND_NODES.index(previous_node)
    ):
        # Retain the latest stage while still accepting token/details updates.
        stage = previous_stage
        incoming_node = previous_node

    now_iso = datetime.now(timezone.utc).isoformat()
    business_progress = bool(details.get("business_progress")) or (
        stage != previous_stage
        or progress > previous_progress
        or incoming_node != previous_node
    )

    # Update basic fields
    entry["current_stage"] = stage
    entry["progress"] = progress
    entry["message"] = message
    entry["details"] = {**(entry.get("details") or {}), **details}
    entry["last_activity_at"] = now_iso
    if business_progress:
        entry["business_progress_sequence"] = int(
            entry.get("business_progress_sequence") or 0
        ) + 1
        entry["last_business_progress_at"] = now_iso

    # Update token usage if present in details
    if "token_usage" in details:
        token_data = details["token_usage"]
        if isinstance(token_data, dict):
            entry["token_usage"]["input_tokens"] = token_data.get("input_tokens", 0)
            entry["token_usage"]["output_tokens"] = token_data.get("output_tokens", 0)
            entry["token_usage"]["total_tokens"] = token_data.get("total_tokens", 0)
            entry["token_usage"]["cache_creation_input_tokens"] = token_data.get("cache_creation_input_tokens", 0)
            entry["token_usage"]["cache_read_input_tokens"] = token_data.get("cache_read_input_tokens", 0)

    # Map stage to frontend node key
    frontend_node = incoming_node or STAGE_TO_NODE.get(stage)
    if not frontend_node:
        return

    nodes = entry.get("nodes")
    if not nodes:
        return

    # Product-defined preparation nodes are complete as soon as the task is
    # accepted. Their later telemetry may update the message and details, but
    # must not regress their visual state back to in-progress.
    if frontend_node in TASK_START_COMPLETED_NODES:
        nodes[frontend_node] = "completed"
    elif nodes.get(frontend_node) not in {"completed", "failed", "cancelled"}:
        nodes[frontend_node] = "in_progress"

    # Only an already-entered predecessor can be completed implicitly. A
    # pending node has no execution evidence yet and remains pending until an
    # event arrives or terminal handling marks it skipped.
    for n in FRONTEND_NODES:
        if n == frontend_node:
            break
        if nodes.get(n) == "in_progress":
            nodes[n] = "completed"

    # A compile event is authoritative evidence that its preparation phases
    # completed, even when their callbacks were omitted by a CLI session.
    _enforce_workflow_order(nodes)

    logger.debug(
        f"[Progress] task={task_id} stage={stage} -> node={frontend_node} "
        f"progress={progress}% msg={message}"
    )


def _load_task_meta(task: Task | None) -> dict:
    """Extract task metadata needed by frontend from task input_data."""
    if not task or not task.input_data:
        return {
            "title": "",
            "source_filename": "",
            "source_full_path": "",
            "output_dir": "",
        }

    try:
        input_data = json.loads(task.input_data)
    except (TypeError, json.JSONDecodeError):
        input_data = {}

    files = input_data.get("files") or []
    source_filename = input_data.get("source_filename") or (files[0] if files else "")
    title = input_data.get("task_title") or source_filename
    source_path_map = input_data.get("source_path_map") or {}
    if not isinstance(source_path_map, dict):
        source_path_map = {}
    resolved_source_path = (
        input_data.get("source_full_path")
        or source_path_map.get(source_filename)
        or (source_path_map.get(files[0]) if files else None)
        or ""
    )

    return {
        "title": title,
        "source_filename": source_filename,
        "source_full_path": resolved_source_path,
        "output_dir": "",
    }


def _normalize_unittest_result_for_display(result: Optional[dict]) -> Optional[dict]:
    """Normalize legacy task records before returning them to the frontend.

    Older tasks stored a line-only coverage flag and omitted failed cases from
    the coverage rerun.  Recompute the display fields from the quality gate and
    detailed test cases so reopening a historical task is not misleading.
    """
    if not isinstance(result, dict):
        return result

    result["output_dir"] = ""
    workflow_state = result.get(_WORKFLOW_STATE_KEY)
    if isinstance(workflow_state, dict):
        workflow_meta = workflow_state.get("meta")
        if isinstance(workflow_meta, dict):
            workflow_meta["output_dir"] = ""

    canonical_test_files = _build_frontend_test_files([], result.get("saved_files") or [])
    if canonical_test_files and (
        any(item.get("content") for item in canonical_test_files)
        or not result.get("test_files")
    ):
        result["test_files"] = canonical_test_files

    quality_gate = result.get("quality_gate") or {}
    summary = result.get("cli_summary") or {}
    summary_result = summary.get("result") or {}
    coverage_met = quality_gate.get("coverage_targets_met")
    if coverage_met is not None:
        summary_result["coverage_met"] = bool(coverage_met)
        summary["result"] = summary_result
        result["cli_summary"] = summary

    # Recompute the display gate from the persisted line/branch/function
    # metrics. This corrects historical records created before all applicable
    # coverage dimensions were enforced (for example line coverage passed while
    # branch or function coverage remained below target).
    coverage = summary.get("coverage") or {}
    if not isinstance(coverage, dict):
        coverage = {}
    # A few early records did not persist the structured CLI coverage table.
    # Rehydrate it from the canonical coverage report so the same gate and
    # warnings are shown after a restart.
    coverage_report = result.get("coverage_report") or {}
    if "line" not in coverage:
        line_value = coverage_report.get("line_coverage", result.get("final_coverage"))
        if line_value is not None:
            coverage["line"] = line_value
    if "branch" not in coverage and "branch_coverage" in coverage_report:
        coverage["branch"] = coverage_report.get("branch_coverage")
    if "function" not in coverage and "function_coverage" in coverage_report:
        coverage["function"] = coverage_report.get("function_coverage")
    coverage.setdefault("line_target", 90.0)
    coverage.setdefault("branch_target", 80.0)
    coverage.setdefault("function_target", 80.0)
    summary["coverage"] = coverage
    if isinstance(coverage, dict) and "line" in coverage:
        checks = []
        try:
            line_value = float(coverage.get("line"))
            line_target = float(coverage.get("line_target", 90.0))
            checks.append(line_value >= line_target)
        except (TypeError, ValueError):
            pass
        for metric in ("branch", "function"):
            value = coverage.get(metric)
            target = coverage.get(f"{metric}_target")
            # A null metric means it is not applicable to this source.
            if value is None or target is None:
                continue
            try:
                checks.append(float(value) >= float(target))
            except (TypeError, ValueError):
                continue
        if checks:
            summary_result["coverage_met"] = all(checks)
            summary["result"] = summary_result
            result["cli_summary"] = summary

    test_cases = result.get("test_cases") or []
    if not result.get("failed_cases") and test_cases:
        failed_cases = []
        for case in test_cases:
            if isinstance(case, dict) and case.get("passed") is False:
                suite = str(case.get("suite") or "")
                name = str(case.get("name") or "Unknown")
                failed_cases.append(f"{suite}.{name}" if suite else name)
        if failed_cases:
            result["failed_cases"] = failed_cases
            result["passed_count"] = max(
                0, int(result.get("test_count") or len(test_cases)) - len(failed_cases)
            )
    # Legacy records may only contain aggregate counts.  Preserve the true
    # pass rate with synthetic labels when individual failure names are absent.
    if not result.get("failed_cases"):
        total = int(result.get("test_count") or 0)
        passed = int(result.get("passed_count") or result.get("passed") or 0)
        missing = max(0, total - passed)
        if missing:
            result["failed_cases"] = [f"unknown_failed_{index}" for index in range(1, missing + 1)]

    # Reconcile the legacy quality gate with the normalized test outcome. Some
    # persisted records reported tests_passed=True even though aggregate counts
    # or parsed failures prove that one or more cases failed.
    failed_cases = result.get("failed_cases") or []
    quality_gate = result.get("quality_gate")
    if isinstance(quality_gate, dict):
        total = int(result.get("test_count") or 0)
        passed = int(result.get("passed_count") or result.get("passed") or 0)
        tests_executed = bool(quality_gate.get("tests_executed") or total or failed_cases)
        if tests_executed:
            quality_gate["tests_executed"] = True
            quality_gate["tests_passed"] = not bool(failed_cases) and (not total or passed >= total)
        result["quality_gate"] = quality_gate

    # Refresh issue signals for records created before structured failures and
    # all coverage dimensions were persisted. Keep generated LLM prose intact,
    # but make the machine-readable issue list truthful and deduplicated.
    issues = list(summary.get("issues") or [])

    def add_issue(message: str) -> None:
        if message and message not in issues:
            issues.append(message)

    if not result.get("compile_success", True):
        add_issue("Compilation errors occurred")
    if failed_cases:
        failed_count = len(failed_cases)
        suffix = "s" if failed_count != 1 else ""
        add_issue(f"{failed_count} test{suffix} failed")
    try:
        line_value = float(coverage.get("line"))
        line_target = float(coverage.get("line_target", 90.0))
        if line_value < line_target:
            add_issue(f"Line coverage {line_value:.1f}% below target {line_target:.1f}%")
    except (TypeError, ValueError):
        pass
    for metric, label in (("branch", "Branch"), ("function", "Function")):
        value = coverage.get(metric)
        target = coverage.get(f"{metric}_target")
        if value is None or target is None:
            continue
        try:
            value_float = float(value)
            target_float = float(target)
        except (TypeError, ValueError):
            continue
        if value_float < target_float:
            add_issue(f"{label} coverage {value_float:.1f}% below target {target_float:.1f}%")
    summary["issues"] = issues
    result["cli_summary"] = summary
    # Reconcile the overall status for records created before the canonical
    # workflow_status field existed.  A compile-success flag alone is not
    # sufficient when tests or coverage failed.
    if not result.get("workflow_status"):
        compile_ok = bool(result.get("compile_success", True))
        tests_failed = bool(failed_cases)
        if not tests_failed:
            total = int(result.get("test_count") or 0)
            passed = int(result.get("passed_count") or result.get("passed") or 0)
            tests_failed = total > 0 and passed < total
        gate_failed = isinstance(quality_gate, dict) and any(
            quality_gate.get(key) is False
            for key in ("coverage_targets_met", "static_quality_passed")
        )
        coverage_unavailable = isinstance(quality_gate, dict) and quality_gate.get("coverage_available") is False
        result["workflow_status"] = "failed" if (
            not compile_ok or tests_failed or gate_failed or coverage_unavailable
        ) else "completed"

    # A passing compile and GTest run is the authoritative business result.
    # Coverage improvement remains resumable and must not leave an old failure
    # summary attached to an otherwise completed task.
    if _has_authoritative_passing_tests(result):
        result["workflow_status"] = "completed"
        if coverage.get("line") is not None and not summary_result.get("coverage_met", False):
            result["coverage_pending"] = True
        summary["summary"] = _build_deterministic_summary_text(summary, result)
        result["cli_summary"] = summary
    return result


def _has_authoritative_passing_tests(result: Optional[dict]) -> bool:
    """Return true only when persisted build and GTest evidence both pass."""
    if not isinstance(result, dict) or result.get("compile_success") is not True:
        return False
    try:
        total = int(result.get("test_count") or result.get("total") or 0)
        passed = int(result.get("passed_count") or result.get("passed") or 0)
    except (TypeError, ValueError):
        return False
    return total > 0 and passed == total and not (result.get("failed_cases") or [])

def _infer_platform_from_paths(paths: list[str]) -> Optional[str]:
    """Infer target platform from source path hints."""
    for raw in paths:
        if not raw:
            continue
        path_lower = str(raw).replace("\\", "/").lower()
        if "stm32u5" in path_lower:
            return "stm32u5"
        if "stm32u3" in path_lower:
            return "stm32u3"
        if "rtl8722fam" in path_lower or "rtl8722" in path_lower:
            return "rtl8722fam"
        if "nrf52" in path_lower or "nrf53" in path_lower:
            return "nrf52"
    return None

async def _run_unittest_task(
    task_id: str,
    agent: UnitTestAgent,
    task_desc: str,
    context: UnitTestContext,
    context_config: dict = None,
    agent_config: dict = None,
):
    """Run unit test generation task in background, update progress via callback."""
    from app.core.database import async_session_factory

    # Store agent's monitor for token tracking
    if hasattr(agent, '_monitor'):
        _task_monitors[task_id] = agent._monitor

    # Save configs in task progress for potential resume
    entry = _task_progress.get(task_id)
    if entry and context_config and agent_config:
        entry["context_config"] = context_config
        entry["agent_config"] = agent_config

    # Create independent log file for this task: logs/task_{task_id}.log
    LoggerService.add_task_sink(task_id)

    # Register progress callback
    agent._progress_callbacks.setdefault(task_id, []).append(
        lambda update: _on_stage_progress(task_id, update)
    )

    cancel_task = None
    token_update_task = None
    result = None
    _pending_log_args: Optional[dict] = None  # deferred cli log write (after sink flush)

    try:
        task_started_at = datetime.now(timezone.utc).isoformat()
        # Periodically check cancellation flag
        async def check_cancellation():
            while not _task_cancelled.get(task_id):
                await asyncio.sleep(0.5)
            # Task cancelled, notify Agent
            agent._cancelled.add(task_id)
            logger.info(f"Task {task_id} cancellation signal sent to agent")

        # Periodically update token usage from monitor
        async def update_token_usage():
            last_persisted_at = 0.0
            last_persisted_state: tuple[int, str, str, tuple[str, ...]] | None = None
            while not _task_cancelled.get(task_id):
                await asyncio.sleep(2)  # Update every 2 seconds
                entry = _task_progress.get(task_id)
                if not entry:
                    continue

                changed = False
                monitor = _task_monitors.get(task_id)
                if monitor:
                    token_usage = monitor.get_token_usage()
                    changed = bool(entry and token_usage and _update_token_activity(entry, token_usage))
                    get_activity = getattr(monitor, "get_activity_snapshot", None)
                    activity = get_activity() if callable(get_activity) else None
                    if activity:
                        changed = _apply_cli_activity(task_id, activity) or changed
                    get_runtime = getattr(monitor, "get_runtime_snapshot", None)
                    runtime = get_runtime() if callable(get_runtime) else None
                    if isinstance(runtime, dict):
                        previous_summary = entry.get("tool_failure_summary") or {}
                        entry["tool_failure_summary"] = dict(runtime)
                        if runtime != previous_summary:
                            changed = True
                        runtime_sequence = int(
                            runtime.get("business_progress_sequence") or 0
                        )
                        if runtime_sequence > int(
                            entry.get("business_progress_sequence") or 0
                        ):
                            entry["business_progress_sequence"] = runtime_sequence
                            business_timestamp = runtime.get("last_business_progress_at")
                            if business_timestamp:
                                entry["last_business_progress_at"] = (
                                    datetime.fromtimestamp(
                                        float(business_timestamp), tz=timezone.utc
                                    ).isoformat()
                                )

                # Persist the skill-driven large-file checkpoints alongside
                # telemetry so a resumed task can continue at the first
                # incomplete chunk instead of rebuilding the whole source.
                if context.large_file_checkpoints:
                    checkpoint_payload = list(context.large_file_checkpoints)
                    details = entry.setdefault("details", {})
                    if (
                        details.get("large_file_checkpoints") != checkpoint_payload
                        or details.get("large_file_active_chunk_id")
                        != context.large_file_active_chunk_id
                    ):
                        details["large_file_checkpoints"] = checkpoint_payload
                        details["large_file_active_chunk_id"] = (
                            context.large_file_active_chunk_id
                        )
                        changed = True
                    if context_config is not None:
                        if context_config.get("large_file_checkpoints") != checkpoint_payload:
                            context_config["large_file_checkpoints"] = checkpoint_payload
                            context_config["large_file_diagnostics"] = list(
                                context.large_file_diagnostics
                            )
                            context_config["large_file_active_chunk_id"] = (
                                context.large_file_active_chunk_id
                            )
                            changed = True

                current_state = (
                    int(entry.get("progress") or 0),
                    str(entry.get("message") or "")[:500],
                    str(entry.get("current_stage") or ""),
                    int(entry.get("business_progress_sequence") or 0),
                    str((entry.get("tool_failure_summary") or {}).get("last") or ""),
                    tuple(
                        str(entry.get("nodes", {}).get(node_name, "pending"))
                        for node_name in FRONTEND_NODES
                    ),
                )
                loop_now = asyncio.get_running_loop().time()
                progress_changed = last_persisted_state is None or current_state != last_persisted_state
                if not changed and not progress_changed and loop_now - last_persisted_at < 15:
                    continue

                async with async_session_factory() as progress_session:
                    task = await progress_session.get(Task, task_id)
                    if task and task.status == "running":
                        task.progress = current_state[0]
                        task.message = current_state[1]
                        persisted_result = _load_persisted_result(task)
                        persisted_result[_WORKFLOW_STATE_KEY] = _build_workflow_snapshot(entry)
                        task.result_data = json.dumps(persisted_result, ensure_ascii=False)
                        await progress_session.commit()
                        last_persisted_at = loop_now
                        last_persisted_state = current_state

        # Start cancellation check task
        cancel_task = asyncio.create_task(check_cancellation())

        # Start token update task
        token_update_task = asyncio.create_task(update_token_usage())

        # Check if task has already been cancelled
        if _task_cancelled.get(task_id):
            agent._cancelled.add(task_id)
            raise asyncio.CancelledError("Task cancelled by user")

        result = await _execute_agent_without_deadline(agent, task_desc, context)

        # A cooperative cancellation may be returned as an AgentResult rather
        # than raising asyncio.CancelledError. Route it through the dedicated
        # cancellation handler so partial progress and workflow nodes remain
        # intact and the result is never converted into a synthetic failure.
        if result is not None and result.status == AgentStatus.CANCELLED:
            raise asyncio.CancelledError("Task cancelled by user")

        # ---- Convert agent raw result.data to format expected by frontend ----
        raw_data = result.data or {}

        if result.status == AgentStatus.FAILED:
            auth_parts = [str(getattr(result, "message", "") or "")]
            auth_parts.extend(str(error) for error in (getattr(result, "errors", None) or []))
            auth_parts.extend(
                str(raw_data.get(key) or "")
                for key in ("error", "errors", "message")
            )
            auth_error = "\n".join(part for part in auth_parts if part)
            auth_kind = _classify_auth_error(auth_error)
            if auth_kind:
                error_codes = {
                    "profile": "AWS_PROFILE_INVALID",
                    "aws": "AWS_AUTH_REQUIRED",
                    "provider": "PROVIDER_AUTH_REQUIRED",
                }
                diagnostic, _pending_log_args = _build_diagnostic_failure_result(
                    task_id,
                    context,
                    auth_error,
                    error_code=error_codes[auth_kind],
                    started_at=task_started_at,
                )
                entry = _task_progress.get(task_id)
                if entry is not None:
                    paused = auth_kind in {"aws", "provider"}
                    entry["status"] = "paused" if paused else "failed"
                    entry["aws_auth_required"] = auth_kind == "aws"
                    entry["generic_auth_required"] = auth_kind == "provider"
                    entry["profile_error"] = auth_kind == "profile"
                    entry["error_code"] = error_codes[auth_kind]
                    entry["message"] = (
                        "AWS Profile configuration error. Please check server settings."
                        if auth_kind == "profile"
                        else "Authentication required. Check provider settings, then resume."
                    )
                    entry["error"] = auth_error
                    entry["result"] = diagnostic
                    if auth_kind == "profile":
                        _mark_workflow_terminal(entry, "failed")

                async with async_session_factory() as session:
                    from sqlalchemy import select

                    task = await session.scalar(select(Task).where(Task.id == task_id))
                    if task is not None:
                        task.status = "failed" if auth_kind == "profile" else "paused"
                        task.error_message = {
                            "profile": "AWS Profile configuration error",
                            "aws": "AWS authentication required",
                            "provider": "Upstream authentication/permission error",
                        }[auth_kind]
                        diagnostic = _result_payload_with_workflow(diagnostic, entry)
                        task.result_data = json.dumps(diagnostic, ensure_ascii=False)
                        await session.commit()
                return

        # Extract token usage from result if available
        token_usage_from_result = raw_data.get("token_usage")
        if token_usage_from_result and isinstance(token_usage_from_result, dict):
            entry = _task_progress.get(task_id)
            if entry:
                entry["token_usage"]["input_tokens"] = token_usage_from_result.get("input_tokens", 0)
                entry["token_usage"]["output_tokens"] = token_usage_from_result.get("output_tokens", 0)
                entry["token_usage"]["total_tokens"] = token_usage_from_result.get("total_tokens", 0)
                entry["token_usage"]["cache_creation_input_tokens"] = token_usage_from_result.get("cache_creation_input_tokens", 0)
                entry["token_usage"]["cache_read_input_tokens"] = token_usage_from_result.get("cache_read_input_tokens", 0)

        agent_tests = getattr(result, "generated_tests", [])
        total_coverage = getattr(result, "total_coverage", raw_data.get("coverage", 0.0))
        iterations_used = getattr(result, "iterations_used", 1)

        compile_lines = []
        # Change from ANY semantics to ALL semantics to match compilation_summary.all_compiled
        # Only report success if ALL tests compiled successfully, not just any one
        all_compile_ok = all(t.compile_success for t in agent_tests) if agent_tests else False
        for t in agent_tests:
            compile_lines.append(
                f"[{t.source_file}] compile={'OK' if t.compile_success else 'FAIL'}, "
                f"coverage={t.coverage:.1f}%"
            )

        # Extract list of tested functions from source files
        functions_tested = []
        try:
            from app.agents.impl.unittest.parsers import parse_functions_regex
            for _fname, _content in context.source_contents.items():
                fns = parse_functions_regex(_content)
                functions_tested.extend(
                    fn.get("name", "") for fn in fns if fn.get("name")
                )
        except Exception:
            pass  # Parsing failure does not affect main flow

        saved_files_list = raw_data.get("saved_files", [])
        test_files = _build_frontend_test_files(agent_tests, saved_files_list)

        # Extract test pass/fail information from test_cases or test_count/failed_cases
        test_passes = []
        test_cases = raw_data.get("test_cases", [])
        test_count = raw_data.get("test_count", 0)
        failed_cases = raw_data.get("failed_cases", [])

        logger.info(f"[DEBUG] Extracting test_passes: test_cases count={len(test_cases)}, test_count={test_count}, failed_cases={len(failed_cases)}")

        if test_cases and isinstance(test_cases, list):
            # Method 1: Use detailed test_cases data if available
            for tc in test_cases:
                if isinstance(tc, dict):
                    suite_name = tc.get("suite", "")
                    test_name = tc.get("name", "")
                    full_name = f"{suite_name}.{test_name}" if suite_name else test_name
                    test_passes.append({
                        "test_name": full_name,
                        "passed": tc.get("passed", False)
                    })
            logger.info(f"[DEBUG] Extracted {len(test_passes)} test_passes from test_cases")
        elif test_count > 0:
            # Method 2: Fallback to test_count and failed_cases
            logger.info(f"[DEBUG] Using fallback method: test_count={test_count}, failed_cases={failed_cases}")
            passed_count = test_count - len(failed_cases)
            # Create synthetic test passes when individual test names are unavailable
            for i in range(passed_count):
                test_passes.append({
                    "test_name": f"test_{i+1}",
                    "passed": True
                })
            for i, failed in enumerate(failed_cases):
                test_passes.append({
                    "test_name": failed if isinstance(failed, str) else f"test_failed_{i+1}",
                    "passed": False
                })
            logger.info(f"[DEBUG] Created {len(test_passes)} synthetic test_passes entries")
        else:
            logger.warning(f"[DEBUG] No test data available. raw_data keys: {list(raw_data.keys())}")

        # Extract test_count and passed_count from raw_data, falling back to parsed test_passes
        test_total = test_count or raw_data.get("total") or len(test_passes)
        test_passed = (
            test_count - len(failed_cases)
            if test_count > 0
            else raw_data.get("passed", sum(1 for item in test_passes if item.get("passed")))
        )
        logger.info(f"[DEBUG] Final: test_total={test_total}, test_passed={test_passed}, test_passes count={len(test_passes)}")

        # Build frontend-friendly result dict
        frontend_result = {
            **raw_data,
            # Keep the terminal workflow status independent from the compiler
            # flag: compile can pass while tests or coverage fail.
            "workflow_status": result.status.value,
            "final_coverage": total_coverage,
            "compile_success": all_compile_ok,
            "compile_output": (
                raw_data.get("build_error")
                or ("\n".join(compile_lines) if compile_lines else "(no output)")
            ),
            "iteration_count": iterations_used,
            "layer": context.layer,
            "functions_tested": functions_tested,
            "output_dir": raw_data.get("output_dir") or context.output_dir,
            "saved_files": saved_files_list,
            "coverage_report": {
                "line_coverage": total_coverage,
                "branch_coverage": raw_data.get("branch_coverage", 0.0),
                "function_coverage": raw_data.get("function_coverage", 0.0),
                "lines_executed": raw_data.get("lines_executed", 0),
                "lines_total": raw_data.get("lines_total", 0),
                "branches_executed": raw_data.get("branches_executed", 0),
                "branches_total": raw_data.get("branches_total", 0),
                "functions_executed": raw_data.get("functions_executed", 0),
                "functions_total": raw_data.get("functions_total", 0),
            },
            "test_files": test_files,
            "test_passes": test_passes,
            "test_count": test_total,
            "passed_count": test_passed,
        }

        # Normalize legacy terminal records: coverage optimization may fail or
        # remain pending after all GTests pass. The API must expose the
        # business result (unit tests passed) instead of a misleading workflow
        # failure caused only by the optional coverage phase.
        tests_passed_authoritatively = (
            test_total > 0
            and test_passed == test_total
            and not failed_cases
        )
        api_status = result.status
        if api_status == AgentStatus.FAILED and tests_passed_authoritatively:
            api_status = AgentStatus.COMPLETED
            frontend_result["workflow_status"] = api_status.value
            frontend_result["coverage_pending"] = bool(
                frontend_result.get("coverage_stop_reason")
                or frontend_result.get("coverage_target_met") is False
            )
            frontend_result["message"] = (
                "Unit tests passed; coverage optimization is pending"
            )

        # Build the summary only after the canonical terminal status and the
        # coverage-pending flag are known. This prevents a passing test run
        # from retaining a stale "workflow failed" summary.
        cli_summary = _build_cli_summary(frontend_result, context)
        cli_summary["summary"] = _build_deterministic_summary_text(cli_summary, frontend_result)
        finished_at = datetime.now(timezone.utc).isoformat()
        cli_log_path = _save_cli_log(
            task_id,
            cli_summary,
            frontend_result,
            context,
            started_at=task_started_at,
            finished_at=finished_at,
        )
        download_token = secrets.token_urlsafe(32)
        cli_log_artifact = _build_cli_log_artifact(task_id, cli_log_path, finished_at, download_token)
        frontend_result["cli_summary"] = cli_summary
        frontend_result["cli_log_artifact"] = cli_log_artifact
        _pending_log_args = {
            "cli_summary": cli_summary,
            "frontend_result": frontend_result,
            "context": context,
            "finished_at": finished_at,
            "started_at": task_started_at,
        }

        # Update in-memory progress
        entry = _task_progress.get(task_id)
        if entry is not None:
            entry["status"] = "completed" if api_status == AgentStatus.COMPLETED else "failed"
            entry["progress"] = 100 if api_status == AgentStatus.COMPLETED else -1
            entry["message"] = (
                "Unit tests passed; coverage optimization is pending"
                if api_status == AgentStatus.COMPLETED and result.status == AgentStatus.FAILED
                else result.message
            )
            if api_status != AgentStatus.COMPLETED:
                entry["error"] = result.message
            else:
                entry["error"] = None
            _mark_workflow_terminal(entry, api_status.value)
            frontend_result = _result_payload_with_workflow(frontend_result, entry)
            entry["result"] = frontend_result

        # Write to DB
        async with async_session_factory() as session:
            from sqlalchemy import select
            stmt = select(Task).where(Task.id == task_id)
            db_result = await session.execute(stmt)
            task = db_result.scalar_one_or_none()
            if task:
                task.status = api_status.value
                task.progress = 100 if api_status == AgentStatus.COMPLETED else -1
                task.message = (
                    "Unit tests passed; coverage optimization is pending"
                    if api_status == AgentStatus.COMPLETED and result.status == AgentStatus.FAILED
                    else result.message
                )
                task.result_data = json.dumps(frontend_result, ensure_ascii=False) if frontend_result else None
                task.error_message = (
                    "\n".join(result.errors)
                    if result.errors
                    else (result.message if api_status != AgentStatus.COMPLETED else None)
                )
                task.duration_ms = result.duration_ms
                await session.commit()

    except asyncio.CancelledError:
        # Task was cancelled
        logger.info(f"Task {task_id} was cancelled")
        from app.utils.claude_cli_monitor import cleanup_task_cli
        cleanup_task_cli(task_id, preserve_cancel_flag=True)
        entry = _task_progress.get(task_id)
        if entry is not None:
            entry["status"] = "cancelled"
            entry["message"] = "Task cancelled by user"
            entry["error"] = "Task cancelled by user"
            _mark_workflow_terminal(entry, "cancelled")

        async with async_session_factory() as session:
            from sqlalchemy import select
            stmt = select(Task).where(Task.id == task_id)
            db_result = await session.execute(stmt)
            task = db_result.scalar_one_or_none()
            if task:
                task.status = "cancelled"
                task.progress = entry.get("progress", task.progress) if entry else task.progress
                task.message = "Task cancelled by user"
                task.error_message = "Task cancelled by user"
                persisted_result = _load_persisted_result(task)
                if entry:
                    persisted_result[_WORKFLOW_STATE_KEY] = _build_workflow_snapshot(entry)
                task.result_data = json.dumps(persisted_result, ensure_ascii=False) if persisted_result else task.result_data
                await session.commit()

    except Exception as e:
        logger.error(f"UnitTest task {task_id} failed: {e}", exc_info=True)
        from app.utils.claude_cli_monitor import cleanup_task_cli
        cleanup_task_cli(task_id)
        error_msg = str(e)

        auth_kind = _classify_auth_error(error_msg)
        is_profile_error = auth_kind == "profile"
        is_aws_auth_error = auth_kind == "aws"
        is_generic_auth_error = auth_kind == "provider"

        # Auto-trigger SSO login for auth errors (but not for profile errors)
        if is_aws_auth_error and not is_profile_error:
            _auto_trigger_sso_login()

        error_codes = {
            "profile": "AWS_PROFILE_INVALID",
            "aws": "AWS_AUTH_REQUIRED",
            "provider": "PROVIDER_AUTH_REQUIRED",
        }
        fallback_result, _pending_log_args = _build_diagnostic_failure_result(
            task_id,
            context,
            error_msg,
            error_code=error_codes.get(auth_kind, "RUNNER_FAILED"),
            started_at=task_started_at,
        )

        entry = _task_progress.get(task_id)
        if entry is not None:
            if is_profile_error:
                # AWS Profile configuration error
                entry["status"] = "failed"
                entry["profile_error"] = True
                entry["error"] = error_msg
                entry["message"] = "AWS Profile configuration error. Please check server settings."
                logger.error(f"Task {task_id} failed due to AWS Profile configuration error")
            elif is_aws_auth_error:
                # For AWS auth errors, pause the task instead of failing it
                entry["status"] = "paused"
                entry["aws_auth_required"] = True
                entry["message"] = "AWS authentication required. Please login to continue."
                entry["error"] = error_msg
                entry["result"] = fallback_result
                entry["error_code"] = "AWS_AUTH_REQUIRED"
                logger.warning(f"Task {task_id} paused due to AWS auth error")
            elif is_generic_auth_error:
                entry["status"] = "paused"
                entry["generic_auth_required"] = True
                entry["message"] = "Upstream authentication/permission error. Check provider settings, then resume."
                entry["error"] = error_msg
                entry["result"] = fallback_result
                entry["error_code"] = "PROVIDER_AUTH_REQUIRED"
                logger.warning("Task %s paused after provider authentication failure", task_id)
            else:
                entry["status"] = "failed"
                entry["error"] = error_msg
                entry["message"] = error_msg
                entry["result"] = fallback_result
                # Mark current node as failed
                current = entry.get("current_stage", "")
                fn = STAGE_TO_NODE.get(current)
                nodes = entry.get("nodes")
                if fn and nodes and fn in nodes:
                    nodes[fn] = "failed"
                _mark_workflow_terminal(entry, "failed")

        async with async_session_factory() as session:
            from sqlalchemy import select
            stmt = select(Task).where(Task.id == task_id)
            db_result = await session.execute(stmt)
            task = db_result.scalar_one_or_none()
            if task:
                if is_profile_error:
                    # AWS Profile configuration error
                    task.status = "failed"
                    task.error_message = "AWS Profile configuration error"
                    task.result_data = json.dumps(
                        _result_payload_with_workflow(fallback_result, entry),
                        ensure_ascii=False,
                    )
                elif is_aws_auth_error:
                    # For AWS auth errors, pause instead of fail
                    task.status = "paused"
                    task.error_message = "AWS authentication required"
                    task.result_data = json.dumps(
                        _result_payload_with_workflow(fallback_result, entry),
                        ensure_ascii=False,
                    )
                elif is_generic_auth_error:
                    task.status = "paused"
                    task.error_message = "Upstream authentication/permission error"
                    task.result_data = json.dumps(
                        _result_payload_with_workflow(fallback_result, entry),
                        ensure_ascii=False,
                    )
                else:
                    task.status = "failed"
                    task.error_message = error_msg
                    fallback_result = _result_payload_with_workflow(fallback_result, entry)
                    task.result_data = json.dumps(fallback_result, ensure_ascii=False) if fallback_result else None
                await session.commit()

    finally:
        # Cancel check task
        if cancel_task and not cancel_task.done():
            cancel_task.cancel()
            try:
                await cancel_task
            except asyncio.CancelledError:
                pass

        # Cancel token update task
        if token_update_task and not token_update_task.done():
            token_update_task.cancel()
            try:
                await token_update_task
            except asyncio.CancelledError:
                pass

        # Clean up Agent's cancellation flag
        agent._cancelled.discard(task_id)

        # Remove from running task list
        _running_tasks.pop(task_id, None)

        # Release the project workspace before retaining terminal progress for polling.
        await _release_workspace(task_id)

        # Remove monitor from global registry
        _task_monitors.pop(task_id, None)

        from app.utils.claude_cli_monitor import cleanup_task_cli

        task_was_cancelled = bool(_task_cancelled.get(task_id))
        cleanup_task_cli(
            task_id,
            preserve_cancel_flag=task_was_cancelled,
        )

        LoggerService.remove_task_sink(task_id)

        # Write CLI log file now — task log sink is closed, file is fully flushed
        if _pending_log_args:
            pla = _pending_log_args
            cli_log_path = _save_cli_log(
                task_id,
                pla["cli_summary"],
                pla["frontend_result"],
                pla["context"],
                started_at=pla.get("started_at"),
                finished_at=pla["finished_at"],
            )
            if cli_log_path and os.path.isfile(cli_log_path):
                artifact = pla["frontend_result"].get("cli_log_artifact") or {}
                artifact["size_bytes"] = os.path.getsize(cli_log_path)
                pla["frontend_result"]["cli_log_artifact"] = artifact
                # Sync size into in-memory progress result
                entry = _task_progress.get(task_id)
                if entry and entry.get("result") is pla["frontend_result"]:
                    pass  # already the same reference
                elif entry and entry.get("result"):
                    entry["result"]["cli_log_artifact"] = artifact

        # Check if task is paused (waiting for AWS auth)
        entry = _task_progress.get(task_id)
        is_paused = entry and entry.get("status") == "paused"

        if is_paused:
            # Don't clean up paused tasks - they need to be resumed
            logger.info(f"Task {task_id} is paused, keeping context for resume")
        else:
            # Clean up memory after 60s for completed/failed/cancelled tasks
            _remove_latest_compact_context(task_id)
            await asyncio.sleep(60)
            _task_progress.pop(task_id, None)
            _task_cancelled.pop(task_id, None)
            cleanup_task_cli(task_id)


# ---------- Routes ----------

@router.post("/generate-tests")
async def generate_tests(
    raw_request: Request,
    file: list[UploadFile] = File(..., description="Source file list"),
    layer: str = Form(default="auto", description="Layer: auto/hal/driver/controller/app"),
    framework: str = Form(default="gtest", description="Test framework: gtest/unity"),
    target_coverage: float = Form(default=90.0, ge=0, le=100, description="Target coverage"),
    max_iterations: int = Form(default=5, ge=1, le=10, description="Maximum iterations"),
    output_dir: Optional[str] = Form(default=None, description="Custom output directory"),
    source_paths_json: Optional[str] = Form(
        default=None,
        description=(
            "JSON array of real source paths on the user's machine, "
            "ordered to match the uploaded file[] list. "
            "Example: [\"D:/fw/ALPHA/bsp/hal/stm32u3/hal-usb.c\"]"
        ),
    ),
    enable_mock: bool = Form(default=True, description="Enable mock generation"),
    compile_verify: bool = Form(default=True, description="Enable QBS compile verification"),
    build_profile: str = Form(default="auto", description="QBS profile, or auto for the server default"),
    platform: str = Form(default="stm32u3", description="Target platform: stm32u3/rtl8722fam/nrf52"),
    auto_update_qbs: bool = Form(default=True, description="Auto-update QBS configuration"),
    task_title: Optional[str] = Form(default=None, description="Task title (provided by frontend, usually filename)"),
    source_filename: Optional[str] = Form(default=None, description="Source filename"),
    source_full_path: Optional[str] = Form(default=None, description="Full path to source file"),
    db: AsyncSession = Depends(get_db),
):
    """Generate unit tests, return task_id immediately, execute asynchronously in background."""
    if not file:
        raise HTTPException(status_code=400, detail="No files uploaded")

    current_user = _get_optional_user(raw_request)
    await enforce_billing(current_user)

    # Only validate AWS SSO if using Bedrock provider
    # Other providers (Turing, OpenRouter, Anthropic, Zhipu) don't need AWS credentials
    if _is_using_bedrock():
        # Fast authentication check: only verify SSO token file exists (~0.1s)
        # This provides immediate feedback to user without waiting for aws sts call
        # Real credential verification happens during task execution (in Agent/LLM layer)
        from app.core.aws_sso_cache import AWSSSOCache
        from app.core.config import get_settings

        settings = get_settings()
        profile = settings.AWS_PROFILE
        region = settings.AWS_REGION

        if not profile:
            logger.error("AWS_PROFILE not configured")
            raise HTTPException(
                status_code=500,
                detail="AWS Profile is not configured. Please configure a valid AWS_PROFILE in Provider Settings and try again."
            )

        cache = AWSSSOCache(profile_name=profile, region=region)

        # Validate that the Profile exists
        sso_start_url = cache._get_sso_start_url()
        if not sso_start_url:
            logger.error(f"AWS Profile '{profile}' not found in ~/.aws/config")
            raise HTTPException(
                status_code=500,
                detail=f"AWS_PROFILE_INVALID: AWS Profile '{profile}' does not exist. Please enter a valid AWS_PROFILE in Provider Settings and try again."
            )

        # Fast check: only verify SSO token file exists and not expired (~0.1s)
        # Don't call aws sts here to avoid blocking user (5-10s delay)
        # Real credential verification happens when Agent calls LLM
        if not cache.is_token_valid(verify_credentials=False):
            logger.warning("Unit test generation blocked: AWS SSO token not valid or missing")
            raise HTTPException(
                status_code=401,
                detail="AWS_AUTH_REQUIRED: AWS credentials expired or missing. Please login again."
            )
    else:
        logger.info("Skipping AWS SSO validation - not using Bedrock provider")

    # Validate file extensions
    ALLOWED_EXTENSIONS = {".c", ".h", ".app", ".cpp"}
    for f in file:
        ext = os.path.splitext(f.filename or "")[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type '{ext}'. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
            )

    llm_bridge = raw_request.app.state.llm_bridge
    mcp_client = raw_request.app.state.mcp_client
    task_id = str(uuid.uuid4())

    # Parse optional source_paths_json: maps upload index -> real path
    real_paths: list[str] = []
    if source_paths_json:
        try:
            real_paths = json.loads(source_paths_json)
            if not isinstance(real_paths, list):
                real_paths = []
        except (json.JSONDecodeError, ValueError):
            logger.warning("source_paths_json is not valid JSON, ignoring")
            real_paths = []

    # Read uploaded files; generated artifacts are not valid production input.
    # Browsers may retain prior outputs in a multi-file selection, so filter
    # test/mocks paths before creating the task and keep source_path indexes
    # aligned with the accepted files.
    def _is_generated_test_artifact(filename: str, real_path: str = "") -> bool:
        value = f"{filename}/{real_path}".replace("\\", "/").lower()
        basename = os.path.basename(filename).lower()
        return (
            "/tests/unit/" in value
            or "/tests/mocks/" in value
            or basename.startswith(("tc-", "mock-"))
            or basename.endswith(("_test_access.c", "_test_access.h"))
        )

    source_contents: dict[str, str] = {}
    filenames: list[str] = []
    source_path_map: dict[str, str] = {}
    for idx, f in enumerate(file):
        content = await f.read()
        try:
            filename = normalize_source_name(f.filename or f"file_{len(filenames)}.c")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        candidate_real_path = real_paths[idx] if idx < len(real_paths) else ""
        if _is_generated_test_artifact(filename, candidate_real_path):
            logger.info("Ignoring generated test artifact from unit-test input: %s", filename)
            continue
        if filename.casefold() in {name.casefold() for name in filenames}:
            raise HTTPException(status_code=400, detail="Duplicate source filenames are not supported")
        filenames.append(filename)
        source_contents[filename] = content.decode("utf-8", errors="replace")
        # Map bare filename -> real path if provided
        if candidate_real_path:
            source_path_map[filename] = candidate_real_path

    if not filenames:
        raise HTTPException(
            status_code=400,
            detail="No production source files were provided; test and mock artifacts are not accepted.",
        )

    if source_full_path and len(filenames) == 1:
        source_path_map.setdefault(filenames[0], source_full_path)

    # Use real source path hints to auto-correct default platform.
    # Keep user explicitly specified non-default input unchanged.
    platform_candidates: list[str] = list(source_path_map.values())
    if source_full_path:
        platform_candidates.append(source_full_path)
    inferred_platform = _infer_platform_from_paths(platform_candidates)
    platform_normalized = (platform or "").strip().lower()
    effective_platform = platform
    if inferred_platform and platform_normalized in ("", "auto", "stm32u3"):
        if inferred_platform != platform_normalized:
            logger.info(
                f"[platform] Auto-corrected from '{platform or 'empty'}' "
                f"to '{inferred_platform}' using source path hints"
            )
        effective_platform = inferred_platform

    # Parse output_dir:
    # 1. If explicitly provided by client, use directly (respect user's manual input).
    # 2. Otherwise, try to auto-derive from source_path_map (phase 1 design).
    # 3. If no project path is available, create a task-scoped output directory.
    from app.agents.impl.unittest.paths import find_project_root_for_source
    if output_dir:
        if os.path.isabs(output_dir):
            # If input is a file path (has extension), take its parent directory
            _p = os.path.splitext(output_dir)
            if _p[1]:
                # It's a file path, extract directory
                _file_dir = os.path.dirname(output_dir)
                # Only auto-detect if it looks like a source file path (not a manually set project root)
                # Check if the directory name suggests it's a source directory (e.g., contains platform names)
                dir_lower = _file_dir.lower()
                if any(platform in dir_lower for platform in ['stm32u3', 'stm32u5', 'rtl8722', 'nrf52']):
                    # Looks like a source directory, try to find project root
                    detected_root = find_project_root_for_source(output_dir)
                    resolved_output_dir = detected_root or _file_dir
                    if detected_root:
                        logger.info(f"[output_dir] Auto-detected project root from file path: {resolved_output_dir}")
                else:
                    # User likely provided a custom directory, use parent of file
                    resolved_output_dir = _file_dir
                    logger.info(f"[output_dir] Using file directory as-is: {resolved_output_dir}")
            else:
                # It's already a directory path - respect user's choice directly
                resolved_output_dir = output_dir
                logger.info(f"[output_dir] Using user-provided directory: {resolved_output_dir}")
        else:
            _agent_root = os.path.abspath(
                os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "..")
            )
            resolved_output_dir = os.path.abspath(os.path.join(_agent_root, output_dir))
    elif source_path_map:
        # Auto-derive project root from first real source path
        first_real = next(iter(source_path_map.values()))
        detected_root = find_project_root_for_source(first_real)
        if detected_root:
            resolved_output_dir = detected_root
            logger.info(
                f"[output_dir] Auto-derived project root from source path: {resolved_output_dir}"
            )
        else:
            resolved_output_dir = os.path.dirname(os.path.abspath(first_real))
            logger.info(
                f"[output_dir] Using source file directory as project root: {resolved_output_dir}"
            )
    else:
        task_output_dir = (_BACKEND_OUTPUT_DIR / task_id).resolve()
        if not task_output_dir.is_relative_to(_BACKEND_OUTPUT_DIR.resolve()):
            raise HTTPException(status_code=400, detail="Could not create an isolated output directory")
        await asyncio.to_thread(task_output_dir.mkdir, parents=True, exist_ok=False)
        resolved_output_dir = str(task_output_dir)
        logger.info("[output_dir] Using task-scoped output directory for uploaded source files")

    effective_compile_verify = bool(compile_verify)
    from app.core.config import get_settings
    if not build_profile or build_profile.strip().lower() == "auto":
        build_profile = get_settings().QBS_DEFAULT_PROFILE
    # Note: resolved_output_dir has already been correctly parsed above.
    # Do NOT overwrite here — the previous code block already handles absolute and
    # relative output_dir cases.

    resolved_title = task_title or (filenames[0] if filenames else "Unnamed Task")
    resolved_source_filename = source_filename or (filenames[0] if filenames else "")
    resolved_source_full_path = (
        source_full_path
        or source_path_map.get(resolved_source_filename)
        or (source_path_map.get(filenames[0]) if filenames else None)
        or ""
    )
    task_meta = {
        "task_title": resolved_title,
        "source_filename": resolved_source_filename,
        "source_full_path": resolved_source_full_path,
        "output_dir": resolved_output_dir,
    }
    task = Task(
        id=task_id,
        user_id=current_user["id"],
        agent_type="unittest",
        status="running",
        progress=0,
        message="Unit test generation task started",
        input_data=json.dumps({
            "files": filenames, "layer": layer,
            "source_path_map": source_path_map,
            "framework": framework, "target_coverage": target_coverage,
            "max_iterations": max_iterations,
            "enable_mock": enable_mock, "compile_verify": effective_compile_verify,
            "build_profile": build_profile, "platform": effective_platform,
            "auto_update_qbs": auto_update_qbs,
            **task_meta,
        }, ensure_ascii=False),
    )
    # Instantiate Agent — pass complete parameters consistent with test_real_pipeline.py
    # Pass skill_registry to inject backend/skills/ SKILL.md rules
    # to generate prompts (e.g. unittest-app skill for application layer).
    skill_registry = getattr(raw_request.app.state, "skill_registry", None)
    agent = UnitTestAgent(llm_bridge, mcp_client, skill_registry)
    context = UnitTestContext(
        task_id=task_id,
        user_id=current_user["id"],
        source_files=filenames,
        source_contents=source_contents,
        source_path_map=source_path_map,
        layer=layer,
        test_framework=framework,
        coverage_target=target_coverage / 100.0,
        max_iterations=max_iterations,
        output_dir=resolved_output_dir,
        enable_mock=enable_mock,
        compile_verify=effective_compile_verify,
        build_profile=build_profile,
        platform=effective_platform,
        auto_update_qbs=auto_update_qbs,
        generation_method="cli",
        coverage_max_iterations=max_iterations,
    )
    task_desc = f"Generate {framework} unit tests for {len(filenames)} files"

    # Save context configuration for potential resume
    context_config = {
        "task_id": task_id,
        "user_id": current_user["id"],
        "source_files": filenames,
        "source_contents": source_contents,
        "source_path_map": source_path_map,
        "layer": layer,
        "test_framework": framework,
        "coverage_target": target_coverage / 100.0,
        "max_iterations": max_iterations,
        "output_dir": resolved_output_dir,
        "enable_mock": enable_mock,
        "compile_verify": effective_compile_verify,
        "build_profile": build_profile,
        "platform": effective_platform,
        "auto_update_qbs": auto_update_qbs,
        "generation_method": "cli",
        "coverage_max_iterations": max_iterations,
    }

    # Save agent dependencies for resume
    agent_config = {
        "llm_bridge": llm_bridge,
        "mcp_client": mcp_client,
        "skill_registry": skill_registry,
    }

    runner = UnitTestRunner(running_tasks=_running_tasks)
    if current_user["id"] == _GUEST_USER_ID:
        await _ensure_guest_user(db)
        # The durable lease uses its own transaction. Release the guest insert's
        # SQLite write lock before that transaction requests BEGIN IMMEDIATE.
        await db.commit()

    conflicting_task_id = await _reserve_workspace(task_id, resolved_output_dir)
    if conflicting_task_id:
        raise HTTPException(
            status_code=409,
            detail=(
                "UNITTEST_WORKSPACE_BUSY: Another UnitTest task is already "
                f"running for this project (task {conflicting_task_id})."
            ),
        )

    try:
        source_path_map = await asyncio.to_thread(
            persist_uploaded_sources, resolved_output_dir, task_id,
            source_contents, source_path_map,
        )
        context.source_path_map = source_path_map
        context_config["source_path_map"] = source_path_map
        task_input = json.loads(task.input_data)
        task_input["source_path_map"] = source_path_map
        task.input_data = json.dumps(task_input, ensure_ascii=False)
    except Exception:
        await _release_workspace(task_id)
        raise

    progress_entry = _init_progress(task_id, meta={
        "title": resolved_title,
        "source_filename": resolved_source_filename,
        "source_full_path": resolved_source_full_path,
        "output_dir": resolved_output_dir,
    })
    task.result_data = json.dumps(
        {_WORKFLOW_STATE_KEY: _build_workflow_snapshot(progress_entry)},
        ensure_ascii=False,
    )
    try:
        db.add(task)
        # Workers and lease updates open separate sessions. They must observe
        # the task before they start, rather than depend on request cleanup.
        await db.commit()
    except Exception:
        await db.rollback()
        _task_progress.pop(task_id, None)
        await _release_workspace(task_id)
        raise

    try:
        _mark_workspace_active(task_id)
        runner.run_existing(
            task_id,
            agent,
            task_desc,
            context,
            context_config,
            agent_config,
            run_callable=_run_unittest_task,
        )
    except Exception:
        try:
            task.status = "failed"
            task.message = "Unit test worker could not be started"
            task.error_message = task.message
            await db.commit()
        finally:
            await db.rollback()
            _task_progress.pop(task_id, None)
            await _release_workspace(task_id)
        raise

    return {
        "task_id": task_id,
        "status": "running",
        "message": "Unit test generation task created and started",
        "files_received": filenames,
        "current_stage": progress_entry["current_stage"],
        "nodes": _workflow_nodes_as_list(
            progress_entry["nodes"],
            task_status=progress_entry.get("status"),
            current_stage=progress_entry.get("current_stage"),
        ),
        "meta": {
            "title": resolved_title,
            "source_filename": resolved_source_filename,
            "source_full_path": resolved_source_full_path,
            "output_dir": output_dir or "",
        },
    }


@router.get("/unittest/tasks/{task_id}")
async def get_unittest_task_progress(
    task_id: str,
    task: Task = Depends(get_owned_unittest_task),
    db: AsyncSession = Depends(get_db),
):
    """Authorize the persisted owner before reading cached or stored progress."""
    # Real-time progress available in memory
    entry = _task_progress.get(task_id)
    if entry:
        entry_status = str(entry.get("status") or "")
        authoritative_terminal_pass = (
            entry_status in {"failed", "completed"}
            and _has_authoritative_passing_tests(entry.get("result"))
        )
        if authoritative_terminal_pass:
            if entry_status == "failed":
                entry["status"] = "completed"
                entry["progress"] = 100
                entry["message"] = "Unit tests passed; coverage optimization is pending"
                entry["error"] = None
            entry["current_stage"] = "report"
            entry["nodes"] = _authoritative_completed_workflow_nodes(entry.get("nodes"))
        # Normalize on every read as a last line of defense against stale
        # in-memory entries restored from older server versions.
        entry["nodes"] = _normalize_workflow_nodes(
            entry.get("nodes"),
            task_status=entry.get("status"),
            current_stage=entry.get("current_stage"),
        )
        _cleanup_terminal_cli(task_id, str(entry.get("status") or ""))
        now = datetime.now(timezone.utc)
        started_at = entry.get("started_at")
        last_activity_at = entry.get("last_activity_at")
        try:
            elapsed_seconds = max(
                0,
                int((now - datetime.fromisoformat(started_at)).total_seconds()),
            )
        except (TypeError, ValueError):
            elapsed_seconds = 0
        try:
            activity_age_seconds = max(
                0,
                int((now - datetime.fromisoformat(last_activity_at)).total_seconds()),
            )
        except (TypeError, ValueError):
            activity_age_seconds = 0
        last_business_progress_at = entry.get("last_business_progress_at")
        public_meta = dict(entry.get("meta") or {})
        public_meta["output_dir"] = ""
        response = {
            "task_id": task_id,
            "status": entry["status"],
            "progress": min(100, max(0, int(entry.get("progress") or 0))),
            "current_stage": entry["current_stage"],
            "message": entry["message"],
            "nodes": _workflow_nodes_as_list(
                entry["nodes"],
                task_status=entry.get("status"),
                current_stage=entry.get("current_stage"),
            ),
            "result": _normalize_unittest_result_for_display(entry.get("result")),
            "error": entry.get("error"),
            "aws_auth_required": bool(entry.get("aws_auth_required")),
            "generic_auth_required": bool(entry.get("generic_auth_required")),
            "started_at": started_at,
            "elapsed_seconds": elapsed_seconds,
            "last_activity_at": last_activity_at,
            "activity_age_seconds": activity_age_seconds,
            "last_business_progress_at": last_business_progress_at,
            "business_progress_age_seconds": _seconds_since_timestamp(
                last_business_progress_at, now
            ),
            "business_progress_sequence": int(
                entry.get("business_progress_sequence") or 0
            ),
            "meta": public_meta,
            "details": entry.get("details") or {},
            "cli_activity": entry.get("cli_activity") or {},
            "cli_activity_sequence": entry.get("cli_activity_sequence", 0),
            "tool_failure_summary": entry.get("tool_failure_summary") or {},
            "token_usage": entry.get("token_usage") or {
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
        }
        # If this is a Profile configuration error, add profile_error flag
        if entry.get("profile_error"):
            response["profile_error"] = True
            from app.core.config import get_settings
            response["profile_name"] = get_settings().AWS_PROFILE

        # If AWS auth is required, raise HTTP 401 to trigger frontend auto-login
        if entry.get("aws_auth_required"):
            error_msg = entry.get("error", "AWS authentication required")
            logger.warning(f"AWS authentication required for task {task_id}, raising HTTP 401")
            raise HTTPException(
                status_code=401,
                detail=f"AWS_AUTH_REQUIRED: {error_msg}",
            )
        return response

    # Use the authorized persisted row when the progress cache was cleaned up.
    runtime_task = _running_tasks.get(task_id)
    # Tasks launched through the /unittest-v2 endpoint live in that module's
    # registry; consult it before declaring this task orphaned, or every v2
    # status poll would kill a healthy CLI process.
    if runtime_task is None:
        from app.api.v1.endpoints.unittest_refactored import (
            _running_tasks as v2_running_tasks,
        )
        runtime_task = v2_running_tasks.get(task_id)
    # A DB row can remain ``running`` after its asyncio wrapper has already
    # exited (worker exception, process restart, or an unhandled cancellation).
    # Treat a completed wrapper as orphaned too; otherwise the UI can poll a
    # permanently running task while no CLI process is doing useful work.
    worker_missing = runtime_task is None or runtime_task.done()
    if task.status in {"pending", "running"} and worker_missing:
        # The database can outlive the asyncio wrapper (for example after a
        # frontend error or a worker cancellation).  Stop any CLI process that
        # is still registered before marking the task as interrupted.
        from app.utils.claude_cli_monitor import kill_cli_by_task_id
        kill_cli_by_task_id(task_id)
        task.status = "failed"
        task.progress = -1
        task.message = "Task execution was interrupted and cannot be resumed"
        task.error_message = task.message
        stored_result = _load_persisted_result(task)
        snapshot = _workflow_snapshot_from_task(task, stored_result)
        node_map = {
            item["node_name"]: item["status"]
            for item in snapshot.get("nodes") or []
            if isinstance(item, dict) and item.get("node_name")
        }
        terminal_entry = {
            "current_stage": snapshot.get("current_stage") or "",
            "nodes": node_map,
            "details": snapshot.get("details") or {},
            "cli_activity": snapshot.get("cli_activity") or {},
            "cli_activity_sequence": snapshot.get("cli_activity_sequence", 0),
            "token_usage": snapshot.get("token_usage") or {},
            "started_at": snapshot.get("started_at"),
            "last_activity_at": snapshot.get("last_activity_at"),
            "last_business_progress_at": snapshot.get("last_business_progress_at"),
            "business_progress_sequence": snapshot.get("business_progress_sequence", 0),
            "tool_failure_summary": snapshot.get("tool_failure_summary") or {},
        }
        _mark_workflow_terminal(terminal_entry, "failed")
        snapshot["nodes"] = _workflow_nodes_as_list(
            terminal_entry["nodes"],
            task_status="failed",
            current_stage=terminal_entry.get("current_stage"),
        )
        stored_result[_WORKFLOW_STATE_KEY] = snapshot
        task.result_data = json.dumps(stored_result, ensure_ascii=False)
        await db.commit()

    _cleanup_terminal_cli(task_id, str(task.status or ""))

    result_payload = _load_persisted_result(task)
    authoritative_terminal_pass = (
        task.status in {"failed", "completed"}
        and _has_authoritative_passing_tests(result_payload)
    )
    if authoritative_terminal_pass:
        reconciliation_changed = False
        if task.status == "failed":
            task.status = "completed"
            task.progress = 100
            task.message = "Unit tests passed; coverage optimization is pending"
            task.error_message = None
            reconciliation_changed = True
        result_payload["workflow_status"] = "completed"
        result_payload["coverage_pending"] = bool(
            result_payload.get("coverage_stop_reason")
            or result_payload.get("coverage_target_met") is False
        )
        workflow_snapshot = _workflow_snapshot_from_task(task, result_payload)
        workflow_snapshot["current_stage"] = "report"
        workflow_snapshot["nodes"] = _workflow_nodes_as_list(
            _authoritative_completed_workflow_nodes(workflow_snapshot.get("nodes")),
            task_status="completed",
            current_stage="report",
        )
        result_payload[_WORKFLOW_STATE_KEY] = workflow_snapshot
        serialized_result = json.dumps(result_payload, ensure_ascii=False)
        if task.result_data != serialized_result:
            task.result_data = serialized_result
            reconciliation_changed = True
        if reconciliation_changed:
            await db.commit()
    workflow_snapshot = _workflow_snapshot_from_task(task, result_payload)
    started_at = workflow_snapshot.get("started_at")
    if not started_at and task.created_at:
        started_at = task.created_at.isoformat()
    last_activity_at = workflow_snapshot.get("last_activity_at") or started_at
    last_business_progress_at = workflow_snapshot.get("last_business_progress_at") or last_activity_at
    now = datetime.now(timezone.utc)
    return {
        "task_id": task_id,
        "status": task.status,
        "progress": task.progress or 0,
        "current_stage": workflow_snapshot.get("current_stage", ""),
        "message": task.message or "",
        "nodes": workflow_snapshot.get(
            "nodes",
            _workflow_nodes_as_list(
                None,
                task_status=task.status,
                current_stage=workflow_snapshot.get("current_stage"),
            ),
        ),
        "result": _normalize_unittest_result_for_display(result_payload or None),
        "error": task.error_message,
        "aws_auth_required": task.status == "paused" and _check_aws_auth_error(task.error_message or ""),
        "generic_auth_required": task.status == "paused" and _check_provider_auth_error(task.error_message or ""),
        "meta": _load_task_meta(task),
        "details": workflow_snapshot.get("details", {}),
        "cli_activity": workflow_snapshot.get("cli_activity", {}),
        "cli_activity_sequence": workflow_snapshot.get("cli_activity_sequence", 0),
        "token_usage": workflow_snapshot.get("token_usage") or result_payload.get("token_usage") or {},
        "started_at": started_at,
        "elapsed_seconds": _seconds_since_timestamp(started_at, now),
        "last_activity_at": last_activity_at,
        "activity_age_seconds": _seconds_since_timestamp(last_activity_at, now),
        "last_business_progress_at": last_business_progress_at,
        "business_progress_age_seconds": _seconds_since_timestamp(
            last_business_progress_at, now
        ),
        "business_progress_sequence": workflow_snapshot.get("business_progress_sequence", 0),
        "tool_failure_summary": workflow_snapshot.get("tool_failure_summary") or {},
    }


@router.get("/download/{task_id}/cli-log")
async def download_cli_log(
    task_id: str,
    raw_request: Request,
    token: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Download Claude CLI execution log for a unittest task (available for all statuses)."""
    # Validate task_id is a UUID to prevent path traversal
    try:
        uuid.UUID(task_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid task_id")

    from sqlalchemy import select
    current_user = _get_optional_user(raw_request)
    stmt = select(Task).where(Task.id == task_id)
    db_result = await db.execute(stmt)
    task = db_result.scalar_one_or_none()
    if not task or not _user_can_access_task(task, current_user, token):
        raise HTTPException(status_code=404, detail="Task not found")

    result_data = None
    if task.result_data:
        try:
            result_data = json.loads(task.result_data)
        except json.JSONDecodeError:
            result_data = None

    log_path = None
    artifact_path = _get_cli_log_artifact_path(result_data or {})
    if artifact_path and os.path.isfile(artifact_path):
        log_path = os.path.abspath(artifact_path)

    # Fallback: find the actual log file in outputs directory (legacy behavior)
    if not log_path:
        allowed_dir = os.path.abspath(str(_BACKEND_OUTPUT_DIR))
        import glob
        pattern = os.path.join(allowed_dir, f"*-unittest-report-*.md")
        matching_files = glob.glob(pattern)

        for candidate in sorted(matching_files, key=os.path.getmtime, reverse=True):
            try:
                with open(candidate, 'r', encoding='utf-8') as f:
                    content = f.read(500)
                    if f"task_id | `{task_id}`" in content:
                        log_path = os.path.abspath(candidate)
                        break
            except Exception:
                continue

    if not log_path:
        old_path = str(_BACKEND_OUTPUT_DIR / f"cli_log_{task_id}.md")
        if os.path.isfile(old_path):
            log_path = old_path

    if not log_path or not os.path.isfile(log_path):
        if task.status in {"completed", "failed", "cancelled", "paused"}:
            diagnostic = _build_persisted_task_diagnostic(task, result_data)
            return Response(
                content=diagnostic,
                media_type="text/markdown; charset=utf-8",
                headers={
                    "Content-Disposition": f'attachment; filename="unittest-{task_id}-diagnostic.md"',
                    "X-Content-Type-Options": "nosniff",
                },
            )
        raise HTTPException(status_code=404, detail="CLI log not available for this task")

    if not _is_safe_cli_log_path(log_path, task):
        raise HTTPException(status_code=403, detail="Access denied")

    download_filename = os.path.basename(log_path)

    return FileResponse(
        path=log_path,
        filename=download_filename,
        media_type="text/markdown; charset=utf-8",
    )


@router.get("/download/{task_id}/{file_type}")
async def download_file(
    task_id: str,
    file_type: str,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Download test files or coverage report"""
    from sqlalchemy import select
    stmt = select(Task).where(Task.id == task_id, Task.user_id == current_user["id"])
    result = await db.execute(stmt)
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status != "completed" or not task.result_data:
        raise HTTPException(status_code=404, detail="Task result not available")
    raise HTTPException(status_code=501, detail="File download not yet implemented for this task")


@router.post("/unittest/tasks/{task_id}/cancel")
async def cancel_unittest_task(
    task_id: str,
    task: Task = Depends(get_owned_unittest_task),
    db: AsyncSession = Depends(get_db),
):
    """Cancel an active task without overwriting a concurrent terminal result."""
    from sqlalchemy import update

    terminal_statuses = ("completed", "failed", "cancelled")
    entry = _task_progress.get(task_id)

    def sync_terminal_progress(row: Task) -> None:
        if entry is None:
            return
        entry["status"] = row.status
        entry["progress"] = row.progress or (100 if row.status == "completed" else entry.get("progress", 0))
        entry["message"] = row.message or "Task already finished"
        entry["error"] = row.error_message

    if task.status in terminal_statuses:
        sync_terminal_progress(task)
        _task_cancelled.pop(task_id, None)
        return {"message": "Task already finished", "status": task.status}

    _task_cancelled[task_id] = True
    from app.utils.claude_cli_monitor import kill_cli_by_task_id

    if kill_cli_by_task_id(task_id):
        logger.info("CLI process terminated for task %s", task_id)

    running_task = _running_tasks.get(task_id)
    # v2-launched tasks are tracked in the refactored module's registry
    if running_task is None:
        from app.api.v1.endpoints.unittest_refactored import (
            _running_tasks as v2_running_tasks,
        )
        running_task = v2_running_tasks.get(task_id)
    if running_task and not running_task.done():
        running_task.cancel()
        await asyncio.sleep(0.5)

    await db.execute(
        update(Task)
        .where(Task.id == task_id, Task.status.not_in(terminal_statuses))
        .values(
            status="cancelled",
            message="Task cancelled by user",
            error_message="Task cancelled by user",
        )
    )
    await db.commit()
    await db.refresh(task, attribute_names=["status", "progress", "message", "error_message"])

    if task.status != "cancelled":
        sync_terminal_progress(task)
        _task_cancelled.pop(task_id, None)
        return {"message": "Task already finished", "status": task.status}

    if entry is not None:
        entry["status"] = "cancelled"
        entry["message"] = "Task cancelled by user"
        entry["error"] = "Task cancelled by user"
        _mark_workflow_terminal(entry, "cancelled")
    await _release_workspace(task_id)
    _remove_latest_compact_context(task_id)
    logger.info("Task %s cancelled by user", task_id)
    return {
        "task_id": task_id,
        "status": "cancelled",
        "message": "Task has been cancelled successfully",
    }


@router.post("/unittest/tasks/{task_id}/resume")
async def resume_unittest_task(
    task_id: str,
    task: Task = Depends(get_owned_unittest_task),
    db: AsyncSession = Depends(get_db),
):
    """Resume a paused unit test task (e.g., after AWS SSO login)"""
    # Check if task exists and is paused
    entry = _task_progress.get(task_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Task not found")

    if entry.get("status") != "paused":
        return {
            "message": f"Task is not paused (current status: {entry.get('status')})",
            "status": entry.get("status")
        }

    context_config = entry.get("context_config")
    agent_config = entry.get("agent_config")
    if not context_config or not agent_config:
        logger.error(f"Cannot resume task {task_id}: context or agent config not found")
        raise HTTPException(status_code=500, detail="Task context lost, cannot resume")

    # Verify AWS SSO token is valid before resuming
    if entry.get("aws_auth_required"):
        from app.core.aws_sso_cache import AWSSSOCache
        from app.core.config import get_settings

        settings = get_settings()
        profile = settings.AWS_PROFILE
        region = settings.AWS_REGION

        if not profile:
            logger.error("AWS_PROFILE not configured, cannot verify SSO token")
            raise HTTPException(
                status_code=500,
                detail="AWS Profile is not configured. Please configure a valid AWS_PROFILE in Provider Settings and try again."
            )

        cache = AWSSSOCache(profile_name=profile, region=region)

        # First, validate that the Profile exists
        sso_start_url = cache._get_sso_start_url()
        if not sso_start_url:
            logger.error(f"AWS Profile '{profile}' not found in ~/.aws/config")
            raise HTTPException(
                status_code=500,
                detail=f"AWS_PROFILE_INVALID: AWS Profile '{profile}' does not exist. Please enter a valid AWS_PROFILE in Provider Settings and try again."
            )

        # Then, validate token
        if not cache.is_token_valid(verify_credentials=True):
            logger.warning(f"Resume failed: AWS SSO token still invalid for task {task_id}")
            raise HTTPException(
                status_code=401,
                detail="AWS_SSO_NOT_COMPLETED: Please complete the browser SSO login first."
            )

        logger.info(f"AWS SSO token validated successfully for task {task_id}")

    output_dir = context_config.get("output_dir")
    if output_dir:
        conflicting_task_id = await _reserve_workspace(task_id, output_dir)
        if conflicting_task_id:
            raise HTTPException(
                status_code=409,
                detail=(
                    "UNITTEST_WORKSPACE_BUSY: Another UnitTest task is already "
                    f"running for this project (task {conflicting_task_id})."
                ),
            )

    context_config = UnitTestRunner.restore_context_config(
        task_id,
        context_config,
        compact_context_loader=_load_latest_compact_context,
    )

    # Clear auth flags and resume the existing task with its latest context.
    entry["aws_auth_required"] = False
    entry["generic_auth_required"] = False
    entry["status"] = "running"
    entry["message"] = "Task resumed after authentication"
    entry["error"] = None

    # Update database
    task.status = "running"
    task.error_message = None
    await db.commit()

    if output_dir:
        _mark_workspace_active(task_id)

    try:
        runner = UnitTestRunner(running_tasks=_running_tasks)
        logger.info("Resuming task %s after authentication", task_id)
        runner.resume_from_config(
            task_id,
            context_config,
            agent_config,
            compact_context_loader=_load_latest_compact_context,
            run_callable=_run_unittest_task,
        )
    except Exception as e:
        await _release_workspace(task_id)
        logger.error(f"Failed to resume task {task_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to resume task: {str(e)}")

    return {
        "task_id": task_id,
        "status": "running",
        "message": "Task resumed successfully"
    }
