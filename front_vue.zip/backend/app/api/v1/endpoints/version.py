"""Public version checks and administrator release management endpoints."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path
from pydantic import AnyHttpUrl, BaseModel, Field, field_validator

from app.core.security import get_current_admin_user
from app.repositories.app_setting import AppSettingRepository
from app.repositories.deps import get_app_setting_repo
from app.services.version_service import (
    build_version_status,
    get_releases,
    parse_version,
    save_releases,
)


router = APIRouter()


class ReleaseIn(BaseModel):
    """Release metadata entered by an administrator."""

    version: str = Field(..., min_length=5, max_length=64)
    title: str = Field(..., min_length=1, max_length=200)
    release_notes: str = Field(default="", max_length=20_000)
    download_url: AnyHttpUrl
    sha256: str = Field(..., min_length=64, max_length=64, pattern=r"^[0-9a-fA-F]{64}$")
    mandatory: bool = False

    @field_validator("version")
    @classmethod
    def validate_version(cls, value: str) -> str:
        normalized = value.strip().lstrip("v")
        parse_version(normalized)
        return normalized

    @field_validator("download_url")
    @classmethod
    def require_https_download(cls, value: AnyHttpUrl) -> AnyHttpUrl:
        if value.scheme != "https":
            raise ValueError("Installer download URL must use HTTPS")
        return value

    @field_validator("sha256")
    @classmethod
    def validate_sha256(cls, value: str) -> str:
        value = value.strip().lower()
        return value


class ReleaseOut(ReleaseIn):
    """Release metadata returned to the frontend."""

    published_at: datetime


def _serialize_release(payload: ReleaseIn) -> dict[str, Any]:
    result = payload.model_dump(mode="json")
    result["published_at"] = datetime.now(timezone.utc).isoformat()
    return result


@router.get("/version", summary="Check for an available application update")
async def check_version(
    repository: AppSettingRepository = Depends(get_app_setting_repo),
) -> dict[str, Any]:
    """Return the newest published version above the running version."""

    status = build_version_status(await get_releases(repository))
    status["checked_at"] = datetime.now(timezone.utc).isoformat()
    return status


@router.get(
    "/admin/version",
    summary="List published application versions",
    dependencies=[Depends(get_current_admin_user)],
)
async def list_versions(
    repository: AppSettingRepository = Depends(get_app_setting_repo),
) -> dict[str, Any]:
    releases = await get_releases(repository)
    return {
        "current_version": build_version_status(releases)["current_version"],
        "releases": releases,
    }


@router.post(
    "/admin/version/releases",
    response_model=ReleaseOut,
    summary="Publish or replace an application version",
    dependencies=[Depends(get_current_admin_user)],
)
async def publish_version(
    payload: ReleaseIn,
    repository: AppSettingRepository = Depends(get_app_setting_repo),
) -> dict[str, Any]:
    releases = await get_releases(repository)
    next_release = _serialize_release(payload)
    releases = [
        release for release in releases
        if str(release.get("version")) != next_release["version"]
    ]
    releases.append(next_release)
    await save_releases(repository, releases)
    return next_release


@router.delete(
    "/admin/version/releases/{version}",
    summary="Remove a published application version",
    dependencies=[Depends(get_current_admin_user)],
)
async def remove_version(
    version: str = Path(..., min_length=5, max_length=64),
    repository: AppSettingRepository = Depends(get_app_setting_repo),
) -> dict[str, bool]:
    try:
        normalized = version.strip().lstrip("v")
        parse_version(normalized)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    releases = await get_releases(repository)
    remaining = [release for release in releases if release.get("version") != normalized]
    if len(remaining) == len(releases):
        raise HTTPException(status_code=404, detail="Version release not found")
    await save_releases(repository, remaining)
    return {"deleted": True}


__all__ = ["router", "ReleaseIn", "ReleaseOut"]
