"""HTTP contract for Batch Unit-Test orchestration.

The batch API deliberately lives beside (rather than inside) the legacy
``unittest`` endpoint.  It reuses the existing optional-auth helper and the
shared input/runner services, while keeping the response projection small:
absolute source paths and uploaded contents never leave the backend.

The resume endpoint breaks the decorator pattern deliberately:
``resume_batch_task`` is mounted at import time via ``router.add_api_route``
behind ``BATCH_RESUME_ENABLED`` so a disabled deployment never registers the
path.  The flag is evaluated once when this module is imported; changing it at
runtime requires a process restart (or a fresh module import in tests).  Never
add a ``@router.post`` decorator to it; the decorator would
re-register the path unconditionally and break the frozen Stage 0 contract.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, File, HTTPException, Path as ApiPath
from fastapi import Query, Request, UploadFile
from fastapi.security import HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, WithJsonSchema
from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.api.v1.endpoints.unittest import (
    _GUEST_USER_ID,
    _ensure_guest_user,
    _get_optional_user,
)
from app.core.batch_contract import (
    BATCH_ID_PATTERN,
    BATCH_RESUME_DEFAULT_ENABLED,
    BatchItemStatus,
    BatchTaskStatus,
)
from app.core.config import get_settings
from app.core.database import get_db
from app.models.batch import BatchItem, BatchQueueEntry, BatchTask
from app.models.user import User
from app.repositories.batch import BatchRepository
from app.services.batch_input_store import BatchInputError, BatchInputStore


# This no-op optional dependency exists to publish the same bearerAuth scheme
# as the rest of the application.  Authentication/anonymous-user semantics
# remain owned by the existing ``_get_optional_user`` helper below.
_optional_bearer = HTTPBearer(
    bearerFormat="JWT",
    scheme_name="bearerAuth",
    description=(
        "Optional access token. Omit Authorization to use the fixed "
        "anonymous identity in the single-user first release."
    ),
    auto_error=False,
)
router = APIRouter(dependencies=[Depends(_optional_bearer)])


# The batch contract uses UUID-v4 resource identifiers on the wire.  Keep the
# runtime representation as ``str`` (the existing Task API does the same), but
# expose the format and lowercase-v4 pattern in the generated OpenAPI schema.
def _uuid_field(*, example: str | None = None) -> Any:
    extra: dict[str, Any] = {"format": "uuid"}
    if example is not None:
        extra["example"] = example
    return Field(pattern=BATCH_ID_PATTERN, json_schema_extra=extra)


_BATCH_ID_EXAMPLE = "7d1f0b6e-6f54-4b40-9d4c-6f2de8e4a101"
_ITEM_ID_EXAMPLE = "6c4b8a11-4c1b-4f32-a62e-71c9c8e3f201"
_CHILD_ID_EXAMPLE = "4f4a7c2e-8b51-4c6f-9d20-7e8a3b1c5f90"

# UploadFile's default Pydantic schema is ``contentMediaType`` in OpenAPI 3.1.
# WithJsonSchema retains UploadFile validation while documenting the frozen
# binary/size contract required by the batch multipart endpoint.
_BatchUploadFile = Annotated[
    UploadFile,
    WithJsonSchema(
        {
            "type": "string",
            "format": "binary",
            "x-max-bytes": 10 * 1024 * 1024,
        },
        mode="validation",
    ),
]


# ---------------------------------------------------------------------------
# Request/response DTOs
# ---------------------------------------------------------------------------


class BatchCreateRequest(BaseModel):
    """The named multipart DTO used by the public create operation.

    FastAPI can parse a Pydantic model annotated with ``File`` directly.  This
    keeps the generated requestBody schema stable (``BatchCreateRequest``)
    while retaining repeated wire fields named exactly ``file`` and
    ``source_paths_json``.
    """

    model_config = ConfigDict(extra="forbid")

    file: list[_BatchUploadFile] = Field(
        min_length=1,
        max_length=100,
        description=(
            "Repeated multipart field named file (never file[]); execution "
            "order is array order. Each file is at most 10485760 bytes and "
            "the aggregate request is at most 104857600 bytes."
        ),
        json_schema_extra={
            "x-max-total-bytes": 100 * 1024 * 1024,
            "example": ["<binary uart.c>", "<binary spi.cpp>"],
        },
    )
    source_paths_json: str = Field(
        description=(
            "JSON array of source paths in file order. Project mode requires "
            "existing absolute paths in one server project. Upload mode accepts "
            "safe relative paths and creates an isolated server workspace. "
            "Paths must match each uploaded filename and be unique."
        ),
        json_schema_extra={
            "example": (
                '["D:/firmware/product/drivers/uart.c",'
                '"D:/firmware/product/services/spi.cpp"]'
            )
        },
    )
    source_mode: Literal["project", "upload"] = Field(
        default="project",
        description="Use upload for browser files, or project for existing server source paths.",
    )


class FastAPIError(BaseModel):
    """Business-error envelope shared by batch error responses."""

    detail: str | list[dict[str, Any]]
    trace_id: str | None = None

    # Existing middleware may append diagnostic keys.  Do not reject those in
    # generated clients or when validating a documented error example.
    model_config = ConfigDict(extra="allow")


class BatchCounts(BaseModel):
    total: int = Field(ge=1, le=100)
    queued: int = Field(ge=0)
    running: int = Field(ge=0)
    pass_: int = Field(alias="pass", ge=0)
    fail: int = Field(ge=0)

    model_config = ConfigDict(populate_by_name=True, serialize_by_alias=True)


class BatchCurrentItem(BaseModel):
    item_id: str = _uuid_field(example=_ITEM_ID_EXAMPLE)
    filename: str = Field(min_length=1, max_length=255)
    status: Literal["running"] = Field(
        json_schema_extra={"enum": ["running"]}
    )
    progress: int = Field(ge=0, le=100)


class BatchItemSummary(BaseModel):
    item_id: str = _uuid_field(example=_ITEM_ID_EXAMPLE)
    sequence: int = Field(ge=0, le=99)
    filename: str = Field(
        min_length=1,
        max_length=255,
        description="Basename only; no path separator or NUL.",
    )
    relative_path: str = Field(
        min_length=1,
        description=(
            "Normalized project-root-relative display path using forward "
            "slashes; never an absolute path."
        ),
    )
    status: Literal["queued", "running", "pass", "fail"]
    # This is deliberately required-but-nullable: a queued Item has no child
    # Task yet, but every response includes the field explicitly.
    unittest_task_id: str | None = _uuid_field(example=_CHILD_ID_EXAMPLE)


class BatchResultSummary(BaseModel):
    compile_success: bool | None = None
    test_count: int | None = Field(
        default=None,
        ge=0,
        json_schema_extra={"minimum": 0},
    )
    passed_count: int | None = Field(
        default=None,
        ge=0,
        json_schema_extra={"minimum": 0},
    )
    line_coverage: float | None = Field(
        default=None,
        ge=0,
        le=100,
        json_schema_extra={"minimum": 0, "maximum": 100},
    )
    coverage_available: bool = False

    model_config = ConfigDict(extra="forbid")


class BatchItemDetail(BatchItemSummary):
    progress: int = Field(ge=0, le=100)
    current_stage: str | None = None
    message: str | None = None
    report_url: str | None = Field(
        default=None, json_schema_extra={"format": "uri-reference"}
    )
    cli_log_url: str | None = Field(
        default=None, json_schema_extra={"format": "uri-reference"}
    )
    result_summary: BatchResultSummary | None = None
    terminal_reason: str | None
    error_code: str | None
    error_message: str | None
    blocked_reason: str | None = None
    resume_required: bool = False


class BatchTaskSummary(BaseModel):
    batch_task_id: str = _uuid_field(example=_BATCH_ID_EXAMPLE)
    status: Literal["queued", "running", "done"]
    progress: int = Field(ge=0, le=100)
    counts: BatchCounts
    current_item: BatchCurrentItem | None = None
    cancel_requested: bool = False
    blocked_reason: str | None = None
    resume_required: bool = False
    created_at: str = Field(
        description="RFC3339 timestamp in UTC; the server emits a trailing Z.",
        json_schema_extra={
            "format": "date-time",
            "example": "2026-09-15T09:30:00Z",
        },
    )
    started_at: str | None = Field(
        default=None,
        description="RFC3339 UTC timestamp, or null before the batch starts.",
        json_schema_extra={
            "format": "date-time",
            "example": "2026-09-15T09:31:00Z",
        },
    )
    finished_at: str | None = Field(
        default=None,
        description="RFC3339 UTC timestamp, or null before the batch finishes.",
        json_schema_extra={"format": "date-time", "example": None},
    )
    # Required-but-nullable distinguishes a normal unfinished/finished batch
    # (null) from an omitted field and matches the frozen DTO contract.
    terminal_reason: str | None = Field(
        description=(
            "Null for normal batch completion; batch-level reasons are "
            "CANCELLED or system-level cleanup only."
        )
    )
    error_code: str | None = None
    error_message: str | None = None
    # ``include_items`` adds this optional, lightweight expansion.  Keeping it
    # optional preserves the small default history response.
    items: list[BatchItemSummary] | None = None


class BatchTaskDetail(BatchTaskSummary):
    # Detail responses always carry these state projections, including nulls.
    cancel_requested: bool
    blocked_reason: str | None
    resume_required: bool
    error_code: str | None
    error_message: str | None
    item_total: int = Field(ge=1, le=100)
    item_limit: int = Field(ge=1, le=500)
    item_offset: int = Field(ge=0)
    has_more: bool
    items: list[BatchItemDetail] = Field(description="Ordered by sequence ASC.")
    poll_after_ms: int = Field(ge=0)


class BatchCreateResponse(BaseModel):
    batch_task_id: str = _uuid_field(example=_BATCH_ID_EXAMPLE)
    status: Literal["queued", "running"]
    progress: int = Field(ge=0, le=100)
    counts: BatchCounts
    items: list[BatchItemSummary] = Field(max_length=100)
    poll_url: str = Field(
        json_schema_extra={"format": "uri-reference"},
    )


class BatchTaskListResponse(BaseModel):
    tasks: list[BatchTaskSummary]
    total: int = Field(ge=0)
    limit: int = Field(ge=1, le=100)
    offset: int = Field(ge=0)


class BatchQueueItem(BaseModel):
    batch_task_id: str = _uuid_field(example=_BATCH_ID_EXAMPLE)
    status: Literal["queued", "running"]
    current_item: BatchCurrentItem | None
    progress: int = Field(ge=0, le=100)
    blocked_reason: str | None
    resume_required: bool


class BatchQueueResponse(BaseModel):
    items: list[BatchQueueItem]
    total: int = Field(ge=0)
    limit: int = Field(ge=1, le=100)
    offset: int = Field(ge=0)


class BatchCancelResponse(BaseModel):
    batch_task_id: str = _uuid_field(example=_BATCH_ID_EXAMPLE)
    status: Literal["queued", "running", "done"]
    cancel_requested: bool
    message: str


class BatchResumeResponse(BaseModel):
    batch_task_id: str = _uuid_field(example=_BATCH_ID_EXAMPLE)
    status: Literal["running"] = Field(
        json_schema_extra={"enum": ["running"]}
    )
    unittest_task_id: str = _uuid_field(example=_CHILD_ID_EXAMPLE)
    batch_poll_url: str = Field(json_schema_extra={"format": "uri-reference"})
    child_poll_url: str = Field(json_schema_extra={"format": "uri-reference"})
    message: str


# ---------------------------------------------------------------------------
# Projection helpers
# ---------------------------------------------------------------------------


def _iso_utc(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _clamp_progress(value: Any) -> int:
    try:
        return max(0, min(100, int(value)))
    except (TypeError, ValueError):
        return 0


def _counts(items: list[BatchItem]) -> BatchCounts:
    values = {status: 0 for status in ("queued", "running", "pass", "fail")}
    for item in items:
        if item.status in values:
            values[item.status] += 1
        else:
            # Corrupt/unknown persisted state is represented as a failure in
            # the public aggregate instead of violating the counts invariant.
            values["fail"] += 1
    return BatchCounts(
        total=max(1, len(items)),
        queued=values["queued"],
        running=values["running"],
        **{"pass": values["pass"], "fail": values["fail"]},
    )


def _progress(batch: BatchTask, counts: BatchCounts, items: list[BatchItem]) -> int:
    if batch.status == BatchTaskStatus.DONE.value:
        return 100
    if not items:
        return 0
    current = next((item for item in items if item.status == BatchItemStatus.RUNNING.value), None)
    completed = counts.pass_ + counts.fail
    current_progress = _clamp_progress(current.progress if current else 0)
    if current is None and completed == 0:
        return 0
    return _clamp_progress((completed * 100 + current_progress) // max(1, counts.total))


def _current_item(items: list[BatchItem]) -> BatchItem | None:
    return next((item for item in items if item.status == BatchItemStatus.RUNNING.value), None)


def _result_summary(task: Any) -> BatchResultSummary | None:
    if task is None or not getattr(task, "result_data", None):
        return None
    try:
        data = json.loads(task.result_data)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(data, Mapping):
        return None
    coverage = data.get("coverage_report") or {}
    if not isinstance(coverage, Mapping):
        coverage = {}
    coverage_available = not bool(data.get("coverage_unavailable"))
    line = coverage.get("line_coverage")
    try:
        line = float(line) if line is not None else None
    except (TypeError, ValueError):
        line = None
    return BatchResultSummary(
        compile_success=data.get("compile_success"),
        test_count=_safe_int(data.get("test_count")),
        passed_count=_safe_int(data.get("passed_count")),
        line_coverage=line,
        coverage_available=coverage_available,
    )


def _safe_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return None


# Error text originates in provider SDKs, local toolchains and arbitrary
# subprocesses.  Batch detail/list responses are public API surfaces, so do
# not expose credentials or host filesystem paths that happen to be included
# in an exception string.  Keep the useful human-readable context while
# replacing only high-confidence secret/path patterns.
_PUBLIC_ERROR_REDACTIONS: tuple[tuple[re.Pattern[str], str], ...] = (
    (
        re.compile(r"(?i)\b(?:authorization|bearer)\s*[:=]?\s*[^\s,;]+"),
        "authorization: [REDACTED]",
    ),
    (
        re.compile(
            r"(?i)\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|secret)\s*[:=]\s*[^\s,;]+"
        ),
        "credential: [REDACTED]",
    ),
    (re.compile(r"\bsk-[A-Za-z0-9][A-Za-z0-9_-]{8,}\b"), "[REDACTED_KEY]"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[REDACTED_KEY]"),
    (
        re.compile(r"(?<![\w])(?:[A-Za-z]:[\\/]|\\\\)[^\s,;()\[\]{}<>]+"),
        "[REDACTED_PATH]",
    ),
    (
        re.compile(r"(?<![\w])/(?:[^\s,;()\[\]{}<>]+/)+[^\s,;()\[\]{}<>]*"),
        "[REDACTED_PATH]",
    ),
    (
        re.compile(r"(?i)([?&](?:api[_-]?key|token|access_token|secret)=)[^&\s]+"),
        r"\1[REDACTED]",
    ),
)


def _safe_public_error(value: Any, *, limit: int = 2000) -> str | None:
    """Return bounded, credential/path-redacted error text for batch DTOs."""

    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    for pattern, replacement in _PUBLIC_ERROR_REDACTIONS:
        text = pattern.sub(replacement, text)
    return text[:limit]


def _cli_log_url(task: Any) -> str | None:
    if task is None:
        return None
    task_status = getattr(task, "status", None)
    terminal_statuses = {"completed", "failed", "cancelled", "paused"}
    if getattr(task, "result_data", None):
        try:
            data = json.loads(task.result_data)
        except (TypeError, ValueError, json.JSONDecodeError):
            data = None
        if isinstance(data, Mapping):
            artifact = data.get("cli_log_artifact") or {}
            if isinstance(artifact, Mapping):
                value = artifact.get("download_url")
                # A producer may persist an artifact before its file is
                # flushed.  Do not expose a dead action for a still-running
                # child when it explicitly reports ``available: false``.
                # Missing ``available`` is treated as available for backwards
                # compatibility with artifacts written before that field was
                # introduced; terminal children still receive the diagnostic
                # endpoint fallback below.
                if value and (
                    artifact.get("available", True) is not False
                    or task_status in terminal_statuses
                ):
                    # Preserve the child artifact contract exactly, including
                    # anonymous-task download tokens.  Never replace a real
                    # artifact URL with a reconstructed one.
                    return str(value)

    # Older/early-failure children may have reached a terminal or resumable
    # state before a CLI artifact was published.  The existing download
    # endpoint can render a sanitized diagnostic from their persisted Task
    # error, so expose that endpoint instead of leaving a dead download action.
    if task_status in terminal_statuses:
        task_id = getattr(task, "id", None)
        return f"/api/v1/download/{task_id}/cli-log" if task_id else None
    return None


def _item_summary(item: BatchItem) -> BatchItemSummary:
    return BatchItemSummary(
        item_id=item.id,
        sequence=item.sequence,
        filename=item.filename,
        relative_path=item.relative_path,
        status=item.status,
        unittest_task_id=item.unittest_task_id,
    )


def _item_detail(item: BatchItem) -> BatchItemDetail:
    task = getattr(item, "unittest_task", None)
    return BatchItemDetail(
        **_item_summary(item).model_dump(),
        progress=_clamp_progress(item.progress),
        current_stage=item.current_stage,
        message=_safe_public_error(item.message, limit=500),
        report_url=(f"/api/v1/unittest/tasks/{item.unittest_task_id}" if item.unittest_task_id else None),
        cli_log_url=_cli_log_url(task),
        result_summary=_result_summary(task) or _result_summary_from_item(item),
        terminal_reason=item.terminal_reason,
        error_code=item.error_code,
        error_message=_safe_public_error(item.error_message),
        blocked_reason=item.blocked_reason,
        resume_required=bool(item.resume_required),
    )


def _result_summary_from_item(item: BatchItem) -> BatchResultSummary | None:
    if not item.result_summary:
        return None
    try:
        value = json.loads(item.result_summary) if isinstance(item.result_summary, str) else item.result_summary
        return BatchResultSummary.model_validate(value)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None


def _summary(batch: BatchTask, items: list[BatchItem], *, include_items: bool = False) -> BatchTaskSummary:
    counts = _counts(items)
    current = _current_item(items)
    values: dict[str, Any] = dict(
        batch_task_id=batch.id,
        status=batch.status,
        progress=_progress(batch, counts, items),
        counts=counts,
        current_item=(
            BatchCurrentItem(
                item_id=current.id,
                filename=current.filename,
                status="running",
                progress=_clamp_progress(current.progress),
            )
            if current
            else None
        ),
        cancel_requested=bool(batch.cancel_requested),
        blocked_reason=current.blocked_reason if current else None,
        resume_required=bool(current.resume_required) if current else False,
        created_at=_iso_utc(batch.created_at) or "",
        started_at=_iso_utc(batch.started_at),
        finished_at=_iso_utc(batch.finished_at),
        terminal_reason=batch.terminal_reason,
        error_code=batch.error_code or (current.error_code if current else None),
        error_message=_safe_public_error(
            batch.error_message or (current.error_message if current else None)
        ),
    )
    if include_items:
        values["items"] = [_item_summary(item) for item in items]
    return BatchTaskSummary(**values)


def _detail(
    batch: BatchTask,
    items: list[BatchItem],
    *,
    item_limit: int,
    item_offset: int,
) -> BatchTaskDetail:
    summary = _summary(batch, items)
    page = items[item_offset : item_offset + item_limit]
    return BatchTaskDetail(
        **summary.model_dump(exclude={"items"}),
        item_total=len(items),
        item_limit=item_limit,
        item_offset=item_offset,
        has_more=item_offset + item_limit < len(items),
        items=[_item_detail(item) for item in page],
        poll_after_ms=2000 if batch.status != BatchTaskStatus.DONE.value else 0,
    )


def _queue_item(batch: BatchTask, items: list[BatchItem]) -> BatchQueueItem:
    current = _current_item(items)
    counts = _counts(items)
    summary = _summary(batch, items)
    return BatchQueueItem(
        batch_task_id=batch.id,
        status=batch.status,
        current_item=summary.current_item,
        progress=_progress(batch, counts, items),
        blocked_reason=current.blocked_reason if current else None,
        resume_required=bool(current.resume_required) if current else False,
    )


def _batch_not_found() -> HTTPException:
    return HTTPException(status_code=404, detail="BATCH_TASK_NOT_FOUND: Batch task was not found")


def _map_input_error(exc: BatchInputError) -> HTTPException:
    return HTTPException(status_code=exc.http_status, detail=exc.detail)


async def _wake_dispatcher(request: Request) -> None:
    dispatcher = getattr(request.app.state, "batch_dispatcher", None)
    if dispatcher is None:
        return
    wake = getattr(dispatcher, "wake", None) or getattr(dispatcher, "notify", None)
    if not callable(wake):
        return
    try:
        result = wake()
        if hasattr(result, "__await__"):
            await result
    except Exception:
        # Queue durability is database-backed; a missed wake is recovered by
        # the dispatcher's periodic poll loop.
        return


async def _load_batch(db: AsyncSession, batch_task_id: str) -> BatchTask | None:
    result = await db.execute(
        select(BatchTask)
        .options(
            selectinload(BatchTask.items).selectinload(BatchItem.unittest_task),
            selectinload(BatchTask.queue_entry),
        )
        .where(BatchTask.id == batch_task_id)
    )
    return result.scalar_one_or_none()


async def _ensure_batch_user(db: AsyncSession, user_id: str) -> None:
    """Ensure the non-null Task/BatchTask FK can be written.

    Anonymous mode is intentionally lazy, matching the existing single-file
    endpoint.  A token whose subject no longer exists is rejected before any
    snapshot is published rather than leaving a half-created batch.
    """
    if user_id == _GUEST_USER_ID:
        await _ensure_guest_user(db)
        await db.commit()
        return
    result = await db.execute(select(User.id).where(User.id == user_id))
    if result.scalar_one_or_none() is None:
        await db.rollback()
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    # The lookup starts a SQLAlchemy transaction.  BatchRepository deliberately
    # requires a clean session so its SQLite ``BEGIN IMMEDIATE`` can be the
    # first write statement; close this read transaction before publishing the
    # snapshot/queue rows.
    await db.commit()


async def _create_persisted_batch(
    db: AsyncSession,
    files: list[UploadFile],
    source_paths_json: str,
    user_id: str,
    source_mode: str = "project",
) -> tuple[BatchTask, BatchInputStore]:
    store = BatchInputStore()
    try:
        snapshot = await store.validate_and_stage(files, source_paths_json, source_mode=source_mode)
    except BatchInputError as exc:
        raise _map_input_error(exc) from exc

    try:
        await _ensure_batch_user(db, user_id)
    except BaseException:
        # The repository takes ownership of cleanup once invoked.  Until then,
        # a rejected/deleted authenticated user or request cancellation must
        # not leave a finalized snapshot behind.
        store.cleanup_snapshot(snapshot)
        raise

    repository = BatchRepository(db, store)
    try:
        batch = await repository.create_from_snapshot(snapshot, user_id=user_id)
    except BatchInputError as exc:
        raise _map_input_error(exc) from exc
    return batch, store


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


_VALIDATION_RESPONSE = {
    "description": "FastAPI parameter validation failed",
    "content": {
        "application/json": {
            "schema": {"$ref": "#/components/schemas/HTTPValidationError"}
        }
    },
}

# Batch creation has two distinct 422 paths: FastAPI can reject malformed
# multipart/query input before the handler runs, while the handler can reject
# a parsed path/project semantic error with a BATCH_* detail string.  Publish
# both shapes so generated clients do not have to guess which error envelope
# is valid for a rejected upload.
_CREATE_VALIDATION_RESPONSE = {
    "description": (
        "Required multipart parsing errors use HTTPValidationError; parsed "
        "path/project semantics use a BATCH_* business error."
    ),
    "content": {
        "application/json": {
            "schema": {
                "oneOf": [
                    {"$ref": "#/components/schemas/HTTPValidationError"},
                    {"$ref": "#/components/schemas/FastAPIError"},
                ]
            }
        }
    },
}


def _error_response(description: str) -> dict[str, Any]:
    return {"description": description, "model": FastAPIError}


# ``HTTPBearer`` is installed as a router dependency above, so FastAPI adds
# the ``{"bearerAuth": []}`` requirement automatically.  Keep only the
# anonymous alternative here; listing bearerAuth a second time would produce
# duplicate security entries in the generated OpenAPI operation.
_OPTIONAL_AUTH_OPENAPI = {
    "security": [{}],
}


@router.post(
    "/unittest/batch-tasks",
    response_model=BatchCreateResponse,
    status_code=202,
    operation_id="createBatchTask",
    summary="Create a batch task and enqueue it",
    description=(
        "Upload repeated multipart fields named file and an ordered "
        "source_paths_json array. The service persists the input snapshot "
        "and returns before provider execution starts. The file array is "
        "limited to 100 items, each file is limited to 10 MiB, and the "
        "aggregate upload is limited to 100 MiB."
    ),
    responses={
        202: {
            "description": (
                "Input persisted and batch accepted by the FIFO scheduler"
            ),
            "model": BatchCreateResponse,
        },
        400: _error_response("Batch input is empty, malformed or unsupported"),
        401: _error_response("Invalid optional Authorization header"),
        413: _error_response("Single-file or total upload limit exceeded"),
        422: _CREATE_VALIDATION_RESPONSE,
        500: _error_response("Upload snapshot or batch transaction failed"),
    },
    openapi_extra={
        **_OPTIONAL_AUTH_OPENAPI,
        "x-sorting": (
            "New batches are assigned an internal queue_seq in insertion "
            "order; queue_seq is not exposed."
        ),
    },
)
async def create_batch_task(
    request: Request,
    payload: Annotated[BatchCreateRequest, File(...)],
    db: AsyncSession = Depends(get_db),
) -> BatchCreateResponse:
    current_user = _get_optional_user(request)
    batch, _store = await _create_persisted_batch(
        db, list(payload.file), payload.source_paths_json, str(current_user["id"]), payload.source_mode,
    )
    # The repository returns the committed graph; use it for the immediate
    # acknowledgement so all fields come from one persistence snapshot.
    items = sorted(list(batch.items), key=lambda item: item.sequence)
    counts = _counts(items)
    response = BatchCreateResponse(
        batch_task_id=batch.id,
        status=batch.status,
        progress=_progress(batch, counts, items),
        counts=counts,
        items=[_item_summary(item) for item in items],
        poll_url=f"/api/v1/unittest/batch-tasks/{batch.id}",
    )
    await _wake_dispatcher(request)
    return response


@router.get(
    "/unittest/batch-tasks",
    response_model=BatchTaskListResponse,
    response_model_exclude_unset=True,
    operation_id="listBatchTasks",
    summary="List batch task history",
    description=(
        "Returns history ordered by created_at descending. Equal timestamps "
        "are resolved by batch_task_id descending for deterministic pagination."
    ),
    responses={
        200: {"description": "Batch history page", "model": BatchTaskListResponse},
        401: _error_response("Invalid optional Authorization header"),
        422: _VALIDATION_RESPONSE,
    },
    openapi_extra=_OPTIONAL_AUTH_OPENAPI,
)
async def list_batch_tasks(
    request: Request,
    status: Literal["queued", "running", "done"] | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    include_items: bool = Query(default=False),
    db: AsyncSession = Depends(get_db),
) -> BatchTaskListResponse:
    _get_optional_user(request)
    predicate = [BatchTask.status == status] if status else []
    total = int(await db.scalar(select(func.count(BatchTask.id)).where(*predicate)) or 0)
    stmt = (
        select(BatchTask)
        .options(selectinload(BatchTask.items).selectinload(BatchItem.unittest_task))
        .where(*predicate)
        .order_by(BatchTask.created_at.desc(), BatchTask.id.desc())
        .offset(offset)
        .limit(limit)
    )
    result = await db.execute(stmt)
    tasks = result.scalars().unique().all()
    return BatchTaskListResponse(
        tasks=[_summary(task, sorted(list(task.items), key=lambda item: item.sequence), include_items=include_items) for task in tasks],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/unittest/batch-queue",
    response_model=BatchQueueResponse,
    operation_id="getBatchQueue",
    summary="Get the active FIFO queue",
    description=(
        "Returns only queued and running batches in queue_seq ascending order."
    ),
    responses={
        200: {
            "description": "Active queue in execution order",
            "model": BatchQueueResponse,
        },
        401: _error_response("Invalid optional Authorization header"),
        422: _VALIDATION_RESPONSE,
    },
    openapi_extra=_OPTIONAL_AUTH_OPENAPI,
)
async def get_batch_queue(
    request: Request,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
) -> BatchQueueResponse:
    _get_optional_user(request)
    active_predicate = [
        BatchQueueEntry.state.in_(("queued", "claimed")),
        BatchTask.status.in_((BatchTaskStatus.QUEUED.value, BatchTaskStatus.RUNNING.value)),
    ]
    total = int(
        await db.scalar(
            select(func.count(BatchQueueEntry.id))
            .join(BatchTask, BatchTask.id == BatchQueueEntry.batch_task_id)
            .where(*active_predicate)
        )
        or 0
    )
    stmt = (
        select(BatchTask)
        .join(BatchQueueEntry, BatchQueueEntry.batch_task_id == BatchTask.id)
        .options(selectinload(BatchTask.items))
        .where(*active_predicate)
        .order_by(BatchQueueEntry.queue_seq.asc())
        .offset(offset)
        .limit(limit)
    )
    result = await db.execute(stmt)
    batches = result.scalars().unique().all()
    return BatchQueueResponse(
        items=[_queue_item(batch, sorted(list(batch.items), key=lambda item: item.sequence)) for batch in batches],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/unittest/batch-tasks/{batch_task_id}",
    response_model=BatchTaskDetail,
    operation_id="getBatchTask",
    summary="Get a batch task and its ordered items",
    description=(
        "Items are always returned in sequence ascending order. Timestamps "
        "are RFC3339 UTC values with a trailing Z."
    ),
    responses={
        200: {"description": "Batch task detail", "model": BatchTaskDetail},
        401: _error_response("Invalid optional Authorization header"),
        404: _error_response("Batch task was not found"),
        422: _VALIDATION_RESPONSE,
    },
    openapi_extra=_OPTIONAL_AUTH_OPENAPI,
)
async def get_batch_task(
    request: Request,
    batch_task_id: str = ApiPath(
        ..., pattern=BATCH_ID_PATTERN, json_schema_extra={"format": "uuid"}
    ),
    item_limit: int = Query(default=100, ge=1, le=500),
    item_offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
) -> BatchTaskDetail:
    _get_optional_user(request)
    batch = await _load_batch(db, batch_task_id)
    if batch is None:
        raise _batch_not_found()
    items = sorted(list(batch.items), key=lambda item: item.sequence)
    return _detail(batch, items, item_limit=item_limit, item_offset=item_offset)


@router.post(
    "/unittest/batch-tasks/{batch_task_id}/cancel",
    response_model=BatchCancelResponse,
    operation_id="cancelBatchTask",
    summary="Request cancellation of a batch task",
    responses={
        200: {
            "description": (
                "Cancellation request accepted; final state is observed by "
                "polling detail"
            ),
            "model": BatchCancelResponse,
        },
        401: _error_response("Invalid optional Authorization header"),
        404: _error_response("Batch task was not found"),
        422: _VALIDATION_RESPONSE,
    },
    openapi_extra=_OPTIONAL_AUTH_OPENAPI,
)
async def cancel_batch_task(
    request: Request,
    batch_task_id: str = ApiPath(
        ..., pattern=BATCH_ID_PATTERN, json_schema_extra={"format": "uuid"}
    ),
    db: AsyncSession = Depends(get_db),
) -> BatchCancelResponse:
    _get_optional_user(request)
    batch = await _load_batch(db, batch_task_id)
    if batch is None:
        raise _batch_not_found()

    # ``BatchTask`` uses optimistic versioning.  Mutating an ORM instance
    # loaded before the dispatcher updates it can raise ``StaleDataError`` and
    # turn an otherwise idempotent cancel request into HTTP 500.  Publish the
    # cancellation intent with a fenced conditional UPDATE, retrying against
    # the latest version when a worker wins the race.  The fallback update is
    # intentionally still status-guarded: a concurrently terminal batch must
    # never be changed back to a live state.
    message = "Batch task already finished"
    updated = False
    for _attempt in range(3):
        if batch.status == BatchTaskStatus.DONE.value:
            break
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        result = await db.execute(
            update(BatchTask)
            .where(
                BatchTask.id == batch_task_id,
                BatchTask.status != BatchTaskStatus.DONE.value,
                BatchTask.version == batch.version,
            )
            .values(
                cancel_requested=True,
                updated_at=now,
                version=BatchTask.version + 1,
            )
        )
        if int(result.rowcount or 0) == 1:
            await db.commit()
            # Core UPDATE bypasses the ORM identity map; refresh before
            # serializing so the response reflects the committed row.
            try:
                await db.refresh(batch)
            except (LookupError, RuntimeError):
                # The row can only disappear through an unrelated cascade;
                # retain the just-accepted response in that exceptional case.
                batch.cancel_requested = True
            updated = True
            message = "Batch cancellation requested"
            break

        await db.rollback()
        batch = await _load_batch(db, batch_task_id)
        if batch is None:
            raise _batch_not_found()

    if not updated and batch.status != BatchTaskStatus.DONE.value:
        # A hot dispatcher can legitimately consume all optimistic retries.
        # Set the intent atomically without a stale version predicate; this
        # remains safe because the status predicate is retained.
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        result = await db.execute(
            update(BatchTask)
            .where(
                BatchTask.id == batch_task_id,
                BatchTask.status != BatchTaskStatus.DONE.value,
            )
            .values(
                cancel_requested=True,
                updated_at=now,
                version=BatchTask.version + 1,
            )
        )
        if int(result.rowcount or 0) == 1:
            await db.commit()
            try:
                await db.refresh(batch)
            except (LookupError, RuntimeError):
                batch.cancel_requested = True
            message = "Batch cancellation requested"
        else:
            await db.rollback()
            batch = await _load_batch(db, batch_task_id)
            if batch is None:
                raise _batch_not_found()
    await _wake_dispatcher(request)
    return BatchCancelResponse(
        batch_task_id=batch.id,
        status=batch.status,
        cancel_requested=bool(batch.cancel_requested),
        message=message,
    )


async def resume_batch_task(
    request: Request,
    batch_task_id: str = ApiPath(
        ..., pattern=BATCH_ID_PATTERN, json_schema_extra={"format": "uuid"}
    ),
    db: AsyncSession = Depends(get_db),
) -> BatchResumeResponse:
    """Resume the currently blocked child through the dispatcher service."""
    _get_optional_user(request)
    batch = await _load_batch(db, batch_task_id)
    if batch is None:
        raise _batch_not_found()
    items = sorted(list(batch.items), key=lambda item: item.sequence)
    current = _current_item(items)
    if (
        batch.status != BatchTaskStatus.RUNNING.value
        or current is None
        or not current.resume_required
        or not current.unittest_task_id
        or current.unittest_task is None
        or current.unittest_task.status != "paused"
    ):
        raise HTTPException(
            status_code=409,
            detail="BATCH_TASK_NOT_RESUMABLE: Batch task is not waiting for authentication resume",
        )

    dispatcher = getattr(request.app.state, "batch_dispatcher", None)
    resume = getattr(dispatcher, "resume_batch", None) if dispatcher is not None else None
    if not callable(resume):
        raise HTTPException(
            status_code=409,
            detail="BATCH_TASK_NOT_RESUMABLE: Batch resume service is unavailable",
        )
    resumed = resume(batch.id)
    if hasattr(resumed, "__await__"):
        resumed = await resumed
    if resumed is not True:
        raise HTTPException(
            status_code=409,
            detail="BATCH_TASK_NOT_RESUMABLE: Batch task could not be resumed",
        )
    return BatchResumeResponse(
        batch_task_id=batch.id,
        status="running",
        unittest_task_id=current.unittest_task_id,
        batch_poll_url=f"/api/v1/unittest/batch-tasks/{batch.id}",
        child_poll_url=f"/api/v1/unittest/tasks/{current.unittest_task_id}",
        message="Batch resume requested",
    )


# The route is intentionally absent from the default OpenAPI schema.  This is
# a runtime feature flag, not a 404 handler: when disabled FastAPI never
# registers the path, matching the frozen Stage 0 contract.
if bool(getattr(get_settings(), "BATCH_RESUME_ENABLED", BATCH_RESUME_DEFAULT_ENABLED)):
    router.add_api_route(
        "/unittest/batch-tasks/{batch_task_id}/resume",
        resume_batch_task,
        methods=["POST"],
        response_model=BatchResumeResponse,
        operation_id="resumeBatchTask",
        summary="Resume the authentication-blocked child item",
        description=(
            "Resume the currently authentication-blocked child using the "
            "original unittest_task_id. A second child task is never created."
        ),
        deprecated=True,
        responses={
            200: {
                "description": "Resume request accepted",
                "model": BatchResumeResponse,
            },
            401: _error_response("Application or provider authentication is incomplete"),
            404: _error_response("Batch task was not found"),
            409: _error_response("Batch is not resumable"),
            422: _VALIDATION_RESPONSE,
        },
        openapi_extra={
            **_OPTIONAL_AUTH_OPENAPI,
            "x-feature-flag": "BATCH_RESUME_ENABLED",
            "x-stage0-enabled": False,
            "x-disabled-behavior": (
                "When BATCH_RESUME_ENABLED=false the route is omitted from "
                "the running application and a request receives HTTP 404."
            ),
        },
    )


__all__ = [
    "BatchCreateRequest",
    "FastAPIError",
    "BatchCounts",
    "BatchCurrentItem",
    "BatchItemSummary",
    "BatchItemDetail",
    "BatchResultSummary",
    "BatchTaskSummary",
    "BatchTaskDetail",
    "BatchCreateResponse",
    "BatchTaskListResponse",
    "BatchQueueItem",
    "BatchQueueResponse",
    "BatchCancelResponse",
    "BatchResumeResponse",
    "create_batch_task",
    "list_batch_tasks",
    "get_batch_queue",
    "get_batch_task",
    "cancel_batch_task",
    "resume_batch_task",
    "router",
]
