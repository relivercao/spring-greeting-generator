"""Image generation provider settings endpoints."""

import asyncio
import os
from pathlib import Path

from fastapi import APIRouter

from app.core.config import get_settings
from app.llm.image_provider import resolve_image_provider_config
from app.schemas.image_generation import (
    ImageGenerationSettingsResponse,
    ImageGenerationSettingsUpdate,
)


router = APIRouter()
_ENV_FILE = Path(__file__).parent.parent.parent.parent.parent / ".env"


def _mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 8:
        return "***"
    return f"{value[:8]}***"


def _write_env_sync(updates: dict[str, str]) -> None:
    _ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    content = _ENV_FILE.read_text(encoding="utf-8") if _ENV_FILE.exists() else ""
    lines = content.splitlines()
    written: set[str] = set()
    output: list[str] = []

    for line in lines:
        stripped = line.strip()
        key = stripped.partition("=")[0].strip() if "=" in stripped else ""
        if key in updates and not stripped.startswith("#"):
            output.append(f"{key}={updates[key]}")
            written.add(key)
        else:
            output.append(line)
    for key, value in updates.items():
        if key not in written:
            output.append(f"{key}={value}")
    _ENV_FILE.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")


def _settings_response() -> ImageGenerationSettingsResponse:
    settings = get_settings()
    resolved = resolve_image_provider_config(settings)
    return ImageGenerationSettingsResponse(
        provider=resolved.provider,
        api_base=resolved.base_url,
        api_key=_mask_secret(resolved.api_key),
        model=resolved.model,
        mode=resolved.mode if resolved.mode in {"images", "responses"} else "images",
        timeout_seconds=resolved.timeout_seconds,
        retry_attempts=resolved.retry_attempts,
        stream_images=resolved.stream_images,
        partial_images=resolved.partial_images,
        allow_prompt_rewrite=resolved.allow_prompt_rewrite,
        configured=bool(resolved.base_url and resolved.api_key and resolved.model),
        using_turing_fallback=bool(
            not settings.IMAGE_API_BASE
            and not settings.IMAGE_API_KEY
            and (settings.TURING_API_BASE or settings.TURING_API_KEY)
        ),
    )


@router.get(
    "/settings/image-generation",
    response_model=ImageGenerationSettingsResponse,
)
async def get_image_generation_settings() -> ImageGenerationSettingsResponse:
    """Return the effective image provider configuration with a masked key."""
    return _settings_response()


@router.put(
    "/settings/image-generation",
    response_model=ImageGenerationSettingsResponse,
)
async def update_image_generation_settings(
    request: ImageGenerationSettingsUpdate,
) -> ImageGenerationSettingsResponse:
    """Persist image provider settings without exposing or overwriting masked keys."""
    updates = {
        "IMAGE_API_PROVIDER": request.provider,
        "IMAGE_API_BASE": request.api_base,
        "IMAGE_API_MODEL": request.model,
        "IMAGE_API_MODE": request.mode,
        "IMAGE_API_TIMEOUT": str(request.timeout_seconds),
        "IMAGE_API_RETRIES": str(request.retry_attempts),
        "IMAGE_API_STREAM": str(request.stream_images).lower(),
        "IMAGE_API_PARTIAL_IMAGES": str(request.partial_images),
        "IMAGE_API_ALLOW_PROMPT_REWRITE": str(request.allow_prompt_rewrite).lower(),
    }
    if request.api_key is not None and "***" not in request.api_key:
        updates["IMAGE_API_KEY"] = request.api_key.strip()

    await asyncio.to_thread(_write_env_sync, updates)
    for key, value in updates.items():
        if value:
            os.environ[key] = value
        else:
            os.environ.pop(key, None)
    get_settings.cache_clear()
    return _settings_response()
