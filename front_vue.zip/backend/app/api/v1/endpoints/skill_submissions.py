"""User package submission, administrator review, and deployment-portable exports."""

import asyncio
from typing import Literal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_admin_user, get_current_user
from app.models.skill_submission import SkillSubmission
from app.models.user import User
from app.services import skill_submissions as service
from app.services.skill_integration import AGENT_RUNTIME_STAGES, runtime_integration
from app.services.skill_market import MAX_PACKAGE_BYTES, SkillMarketError
from app.services.user_skill_packages import map_agent, read_upload

router = APIRouter()


async def active_user(identity=Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    user = await db.get(User, identity['id'])
    if user is None or not user.is_active:
        raise HTTPException(401, 'An active account is required')
    return user


def current_market():
    from app.api.v1.endpoints.skill_market import market
    return market


@router.get('/submission-targets')
async def submission_targets():
    return {'items':[{'agent':name, 'stages':sorted(stages)} for name,stages in AGENT_RUNTIME_STAGES.items()]}


@router.post('/submissions', status_code=201)
async def submit_skill(file: UploadFile = File(...), agent: str = Form(''), stage: str = Form(''),
                       user: User = Depends(active_user), db: AsyncSession = Depends(get_db)):
    try:
        content = await file.read(MAX_PACKAGE_BYTES + 1)
        entry, files = await asyncio.to_thread(read_upload, file.filename, content)
        if agent or stage:
            if stage not in AGENT_RUNTIME_STAGES.get(agent, set()):
                raise HTTPException(422, 'Choose a supported Agent and workflow stage')
            entry, files = map_agent(files, agent, stage)
        row = await service.save_submission(db, user, entry, files)
        return service.serialize_submission(row)
    except SkillMarketError as error:
        raise HTTPException(error.status_code, str(error)) from error
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, 'This package was submitted concurrently. Refresh your submissions')
    finally:
        await file.close()


@router.get('/submissions')
async def submissions(user: User = Depends(active_user), db: AsyncSession = Depends(get_db),
        review_queue: bool = False, status: Literal['pending','published','rejected'] | None = None,
        page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    if review_queue and not user.is_admin:
        raise HTTPException(403, 'Administrator privileges required')
    conditions = [] if review_queue else [SkillSubmission.user_id == user.id]
    if status:
        conditions.append(SkillSubmission.status == status)
    total = await db.scalar(select(func.count()).select_from(SkillSubmission).where(*conditions))
    rows = (await db.scalars(select(SkillSubmission).where(*conditions).order_by(
        SkillSubmission.created_at.desc(), SkillSubmission.id).offset((page-1)*page_size).limit(page_size))).all()
    return {'items':[service.serialize_submission(row) for row in rows], 'total':total, 'page':page, 'page_size':page_size}


@router.get('/submissions/{submission_id}')
async def submission(submission_id: str, user: User = Depends(active_user), db: AsyncSession = Depends(get_db)):
    import json
    row = await service.find_submission(db, submission_id, user)
    return {**service.serialize_submission(row), 'files':json.loads(row.files_json)}


@router.post('/submissions/{submission_id}/publish')
async def publish(submission_id: str, request: Request, admin: User = Depends(get_current_admin_user),
                   db: AsyncSession = Depends(get_db)):
    row = await service.find_submission(db, submission_id, admin)
    market = current_market()
    try:
        row = await service.publish_submission(db, row, admin, market)
    except SkillMarketError as error:
        raise HTTPException(error.status_code, str(error)) from error
    from app.skills.loader import SkillLoader
    registry = getattr(request.app.state, 'skill_registry', None)
    if registry is not None:
        registry.register(await asyncio.to_thread(SkillLoader().load_all))
    return {**service.serialize_submission(row), 'integration':runtime_integration(row.name, registry)}


class ReviewNote(BaseModel):
    note: str = Field(min_length=1, max_length=500)


@router.post('/submissions/{submission_id}/reject')
async def reject(submission_id: str, body: ReviewNote, admin: User = Depends(get_current_admin_user),
                  db: AsyncSession = Depends(get_db)):
    from datetime import datetime, timezone
    row = await service.find_submission(db, submission_id, admin)
    async with current_market()._install_lock:
        await db.refresh(row)
        if row.status != 'pending':
            raise HTTPException(409, 'Only pending submissions can be rejected')
        row.status, row.review_note = 'rejected', body.note.strip()
        if not row.review_note:
            raise HTTPException(422, 'Provide a review note')
        row.reviewed_at, row.reviewed_by = datetime.now(timezone.utc), admin.id
        await db.commit()
    return service.serialize_submission(row)


@router.get('/packages/{package_id}')
async def package(package_id: str):
    try:
        entry, files = await asyncio.to_thread(service.installed_files, current_market(), package_id)
        return {'name':entry.name, 'files':files}
    except SkillMarketError as error:
        raise HTTPException(error.status_code, str(error)) from error


@router.get('/packages/{package_id}/download')
async def download_package(package_id: str):
    from app.services.user_skill_packages import export_zip
    try:
        entry, files = await asyncio.to_thread(service.installed_files, current_market(), package_id)
        data = await asyncio.to_thread(export_zip, files)
        return Response(data, media_type='application/zip', headers={
            'Content-Disposition':f'attachment; filename="{entry.name}.zip"',
            'X-Content-Type-Options':'nosniff',
        })
    except SkillMarketError as error:
        raise HTTPException(error.status_code, str(error)) from error
