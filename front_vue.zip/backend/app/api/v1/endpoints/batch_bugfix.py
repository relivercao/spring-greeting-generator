"""Authenticated endpoints for ordered, server-owned BugFix queues."""

import asyncio

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.models.task import Task
from app.schemas.bugfix import BugFixBatchRequest
from app.services.agent_task_runtime import agent_task_registry, mark_task_cancelled
from app.services.billing_service import enforce_billing
from app.services.bugfix_batch import (
    BATCH_AGENT_TYPE, BugFixBatchRunner, batch_snapshot, make_batch_task,
)

router = APIRouter(prefix="/bugfix/batch-tasks")


async def _owned_batch(task_id: str, user: dict, db: AsyncSession) -> Task:
    batch = (await db.execute(select(Task).where(
        Task.id == task_id, Task.user_id == user["id"], Task.agent_type == BATCH_AGENT_TYPE,
    ))).scalar_one_or_none()
    if batch is None:
        raise HTTPException(status_code=404, detail="Bug-fix batch not found")
    return batch


@router.post("", status_code=201)
async def create_bugfix_batch(
    payload: BugFixBatchRequest, request: Request,
    user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db),
):
    await enforce_billing(user)
    runner = BugFixBatchRunner(
        request.app.state.llm_bridge, request.app.state.mcp_client,
        getattr(request.app.state, "skill_registry", None),
    )
    batch = make_batch_task(payload, user["id"])
    db.add(batch)
    await db.commit()
    worker = asyncio.create_task(runner.run(batch.id), name=batch.id)
    agent_task_registry.register(batch.id, worker, runner)
    return await batch_snapshot(batch, db)


@router.get("")
async def list_bugfix_batches(
    limit: int = Query(default=20, ge=1, le=100),
    user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db),
):
    batches = (await db.execute(select(Task).where(
        Task.user_id == user["id"], Task.agent_type == BATCH_AGENT_TYPE,
    ).order_by(Task.created_at.desc()).limit(limit))).scalars().all()
    return {"batches": [{
        "task_id": batch.id, "status": batch.status, "message": batch.message,
        "created_at": batch.created_at.isoformat(),
    } for batch in batches]}


@router.get("/{task_id}")
async def get_bugfix_batch(
    task_id: str, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db),
):
    return await batch_snapshot(await _owned_batch(task_id, user, db), db)


@router.post("/{task_id}/cancel")
async def cancel_bugfix_batch(
    task_id: str, user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db),
):
    batch = await _owned_batch(task_id, user, db)
    if batch.status == "running":
        worker = agent_task_registry.get_task(task_id)
        await agent_task_registry.cancel(task_id)
        if worker:
            try:
                await worker
            except asyncio.CancelledError:
                # A queue cancelled before its coroutine starts cannot run cleanup.
                agent_task_registry.remove(task_id)
        await mark_task_cancelled(task_id, "Bug-fix batch cancelled")
        await db.refresh(batch)
    return await batch_snapshot(batch, db)
