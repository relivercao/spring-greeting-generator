"""Admin console API endpoints for user management.

User listing with keyword search and pagination, manual balance
adjustments recorded in the ledger as ``admin_adjust``, account
enable/disable, admin role grant/revoke, and per-user balance
transaction history. All routes require the admin role.
"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_admin_user
from app.models.user import User
from app.repositories import (
    BalanceTransactionRepository,
    UserRepository,
    get_balance_transaction_repo,
    get_user_repo,
)
from app.schemas.admin import (
    AdminListOut,
    AdminUserOut,
    BalanceAdjustIn,
    UserAdminIn,
    UserLevelIn,
    UserStatusIn,
)
from app.schemas.payment import TransactionListOut, TransactionOut
from app.services.payment import payment_config_service

router = APIRouter(dependencies=[Depends(get_current_admin_user)])


@router.get("", response_model=AdminListOut[AdminUserOut])
async def list_users(
    keyword: Optional[str] = Query(None, description="Matches username or email"),
    status: Optional[str] = Query(
        None, description="Filter: active | disabled | admin (default all)"
    ),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user_repo: UserRepository = Depends(get_user_repo),
):
    """List users (keyword matches username or email), newest first."""
    filters = []
    if keyword:
        pattern = f"%{keyword}%"
        filters.append(or_(User.username.like(pattern), User.email.like(pattern)))
    status_key = (status or "").strip().lower()
    if status_key in ("active", "disabled"):
        filters.append(User.is_active.is_(status_key == "active"))
    elif status_key == "admin":
        filters.append(User.is_admin.is_(True))
    total = await user_repo.count(filters=filters)
    users = await user_repo.get_all(
        filters=filters,
        order_by=User.created_at.desc(),
        limit=page_size,
        offset=(page - 1) * page_size,
    )
    return AdminListOut[AdminUserOut](
        items=[AdminUserOut.model_validate(user) for user in users],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.post("/{user_id}/balance", response_model=AdminUserOut)
async def adjust_user_balance(
    user_id: str,
    payload: BalanceAdjustIn,
    user_repo: UserRepository = Depends(get_user_repo),
    transaction_repo: BalanceTransactionRepository = Depends(
        get_balance_transaction_repo
    ),
):
    """Apply a signed manual balance adjustment and ledger it as admin_adjust."""
    user = await user_repo.add_balance(user_id, payload.amount)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    await transaction_repo.create_row(
        user_id=user_id,
        amount=payload.amount,
        balance_after=user.balance,
        type="admin_adjust",
        description=payload.reason,
    )
    return user


@router.post("/{user_id}/status", response_model=AdminUserOut)
async def set_user_status(
    user_id: str,
    payload: UserStatusIn,
    user_repo: UserRepository = Depends(get_user_repo),
):
    """Enable or disable a user account."""
    user = await user_repo.update(user_id, {"is_active": payload.is_active})
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.post("/{user_id}/admin", response_model=AdminUserOut)
async def set_user_admin(
    user_id: str,
    payload: UserAdminIn,
    user_repo: UserRepository = Depends(get_user_repo),
):
    """Grant or revoke the administrator role."""
    user = await user_repo.set_admin(user_id, payload.is_admin)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.post("/{user_id}/level", response_model=AdminUserOut)
async def set_user_level(
    user_id: str,
    payload: UserLevelIn,
    db: AsyncSession = Depends(get_db),
    user_repo: UserRepository = Depends(get_user_repo),
):
    """
    Set a user's membership level.

    An empty ``level`` clears any manual override and recomputes the
    tier from the user's cumulative recharge.
    """
    user = await user_repo.get_by_id(user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    requested = (payload.level or "").strip()
    if requested:
        levels = (await payment_config_service.get_levels(db))["levels"]
        if payment_config_service.level_for_key(levels, requested) is None:
            raise HTTPException(
                status_code=400, detail="Unknown membership level"
            )
        updated = await user_repo.set_level(user_id, requested, payload.manual)
    else:
        levels = (await payment_config_service.get_levels(db))["levels"]
        target = payment_config_service.level_for_total(
            levels, float(user.total_recharged or 0.0)
        )
        updated = await user_repo.set_level(
            user_id, target["key"], manual=False
        )
    if updated is None:
        raise HTTPException(status_code=404, detail="User not found")
    return updated


@router.get("/{user_id}/transactions", response_model=TransactionListOut)
async def list_user_transactions(
    user_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    transaction_repo: BalanceTransactionRepository = Depends(
        get_balance_transaction_repo
    ),
):
    """Page one user's balance ledger, newest first."""
    items, total = await transaction_repo.list_paged(
        user_id=user_id, page=page, page_size=page_size
    )
    return TransactionListOut(
        items=[TransactionOut.model_validate(tx) for tx in items],
        total=total,
        page=page,
        page_size=page_size,
    )
