"""Admin console API endpoints for payment configuration and orders.

Payment settings from ``app_settings`` (limits, pricing), order
administration (list / detail / cancel / refund / retry), recharge
plan CRUD, and gateway provider CRUD. Merchant keys (``pkey``) are
masked on every read; submitting an empty or masked key on update
keeps the stored secret.
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_admin_user
from app.models.payment_order import OrderStatus, PaymentOrder
from app.repositories import PaymentOrderRepository, get_payment_order_repo
from app.schemas.admin import (
    AdminConfigIn,
    AdminConfigOut,
    AdminListOut,
    AdminOrderOut,
    PlanIn,
    PlanOut,
    ProviderIn,
    ProviderOut,
)
from app.services.payment import payment_config_service, payment_fulfillment
from app.services.payment.easypay import EasyPayError

router = APIRouter(dependencies=[Depends(get_current_admin_user)])


class RefundRequest(BaseModel):
    """Refund request body; the reason is recorded on the order."""

    reason: str = Field(..., min_length=1, max_length=255)


# Service contract: every function takes ``db`` first; provider/plan
# payloads are passed as dicts and the services raise HTTPException
# (400/404/409) themselves. Provider dicts are already pkey-masked;
# ProviderOut masks again, so no read path can leak the secret.


@router.get("/config", response_model=AdminConfigOut)
async def get_payment_config(db: AsyncSession = Depends(get_db)):
    """Return the combined payment limits, pricing, and level settings."""
    general = await payment_config_service.get_general(db)
    pricing = await payment_config_service.get_pricing(db)
    levels = await payment_config_service.get_levels(db)
    return AdminConfigOut(general=general, pricing=pricing, levels=levels)


@router.put("/config", response_model=AdminConfigOut)
async def update_payment_config(
    payload: AdminConfigIn, db: AsyncSession = Depends(get_db)
):
    """Persist the combined payment limits, pricing, and level settings."""
    general = await payment_config_service.update_general(
        db, payload.general.model_dump()
    )
    pricing = await payment_config_service.update_pricing(
        db, payload.pricing.model_dump()
    )
    levels = await payment_config_service.get_levels(db)
    if payload.levels is not None:
        levels = await payment_config_service.update_levels(
            db, payload.levels.model_dump()
        )
    return AdminConfigOut(general=general, pricing=pricing, levels=levels)


async def _get_order_or_404(
    order_id: str, order_repo: PaymentOrderRepository
) -> PaymentOrder:
    """Fetch one order or raise the standard 404."""
    order = await order_repo.get_by_id(order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


async def _refreshed_order(
    order_id: str, order_repo: PaymentOrderRepository, fallback: PaymentOrder
) -> PaymentOrder:
    """Re-read one order after a service mutation (stale fallback)."""
    refreshed = await order_repo.get_by_id(order_id)
    return refreshed if refreshed is not None else fallback


@router.get("/orders", response_model=AdminListOut[AdminOrderOut])
async def list_orders(
    status: Optional[str] = Query(None, description="Filter by order status"),
    keyword: Optional[str] = Query(None, description="Match trade number or username"),
    date_from: Optional[datetime] = Query(None),
    date_to: Optional[datetime] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    order_repo: PaymentOrderRepository = Depends(get_payment_order_repo),
):
    """List orders with status / keyword / date filters, newest first."""
    items, total = await order_repo.list_paged(
        status=status,
        keyword=keyword,
        date_from=date_from,
        date_to=date_to,
        page=page,
        page_size=page_size,
    )
    return AdminListOut[AdminOrderOut](
        items=[AdminOrderOut.model_validate(order) for order in items],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/orders/{order_id}", response_model=AdminOrderOut)
async def get_order(
    order_id: str,
    order_repo: PaymentOrderRepository = Depends(get_payment_order_repo),
):
    """Return one order with its gateway and refund snapshots."""
    return await _get_order_or_404(order_id, order_repo)


@router.post("/orders/{order_id}/cancel", response_model=AdminOrderOut)
async def cancel_order(
    order_id: str,
    order_repo: PaymentOrderRepository = Depends(get_payment_order_repo),
):
    """Cancel a pending order (non-pending orders are rejected)."""
    order = await _get_order_or_404(order_id, order_repo)
    if order.status != OrderStatus.PENDING:
        detail = f"Only pending orders can be cancelled (current: {order.status})"
        raise HTTPException(status_code=409, detail=detail)
    return await order_repo.update(order_id, {"status": OrderStatus.CANCELLED})


@router.post("/orders/{order_id}/refund", response_model=AdminOrderOut)
async def refund_order(
    order_id: str,
    payload: RefundRequest,
    db: AsyncSession = Depends(get_db),
    order_repo: PaymentOrderRepository = Depends(get_payment_order_repo),
):
    """Refund a paid order through the gateway and reverse the credit."""
    order = await _get_order_or_404(order_id, order_repo)
    try:
        await payment_fulfillment.refund_order(db, order, payload.reason)
    except EasyPayError as exc:
        raise HTTPException(502, f"Gateway refund failed: {exc}") from exc
    return await _refreshed_order(order_id, order_repo, order)


@router.post("/orders/{order_id}/retry", response_model=AdminOrderOut)
async def retry_order(
    order_id: str,
    db: AsyncSession = Depends(get_db),
    order_repo: PaymentOrderRepository = Depends(get_payment_order_repo),
):
    """Retry fulfillment of a failed order."""
    order = await _get_order_or_404(order_id, order_repo)
    try:
        await payment_fulfillment.retry_fulfillment(db, order)
    except EasyPayError as exc:
        raise HTTPException(502, f"Gateway retry failed: {exc}") from exc
    return await _refreshed_order(order_id, order_repo, order)


@router.get("/plans", response_model=List[PlanOut])
async def list_plans(db: AsyncSession = Depends(get_db)):
    """List all recharge plans, including ones hidden from the storefront."""
    plans = await payment_config_service.list_plans(db)
    return [PlanOut.model_validate(plan) for plan in plans]


@router.post("/plans", response_model=PlanOut, status_code=201)
async def create_plan(payload: PlanIn, db: AsyncSession = Depends(get_db)):
    """Create a preset recharge plan."""
    plan = await payment_config_service.create_plan(db, payload.model_dump())
    return PlanOut.model_validate(plan)


@router.put("/plans/{plan_id}", response_model=PlanOut)
async def update_plan(
    plan_id: str, payload: PlanIn, db: AsyncSession = Depends(get_db)
):
    """Update a preset recharge plan."""
    return await payment_config_service.update_plan(db, plan_id, payload.model_dump())


@router.delete("/plans/{plan_id}")
async def delete_plan(plan_id: str, db: AsyncSession = Depends(get_db)):
    """Delete a preset recharge plan."""
    await payment_config_service.delete_plan(db, plan_id)
    return {"success": True}


@router.get("/providers", response_model=List[ProviderOut])
async def list_providers(db: AsyncSession = Depends(get_db)):
    """List gateway credential sets (merchant keys masked)."""
    providers = await payment_config_service.list_providers(db)
    return [ProviderOut.model_validate(provider) for provider in providers]


@router.post("/providers", response_model=ProviderOut, status_code=201)
async def create_provider(payload: ProviderIn, db: AsyncSession = Depends(get_db)):
    """Create a gateway credential set."""
    provider = await payment_config_service.create_provider(db, payload.model_dump())
    return ProviderOut.model_validate(provider)


@router.put("/providers/{provider_id}", response_model=ProviderOut)
async def update_provider(
    provider_id: str, payload: ProviderIn, db: AsyncSession = Depends(get_db)
):
    """Update a credential set (empty or masked pkey keeps the stored secret)."""
    return await payment_config_service.update_provider(
        db, provider_id, payload.model_dump()
    )


@router.delete("/providers/{provider_id}")
async def delete_provider(provider_id: str, db: AsyncSession = Depends(get_db)):
    """Delete a gateway credential set."""
    await payment_config_service.delete_provider(db, provider_id)
    return {"success": True}


@router.post("/providers/{provider_id}/test")
async def test_provider(provider_id: str, db: AsyncSession = Depends(get_db)):
    """Run a gateway connectivity test for one credential set."""
    return await payment_config_service.test_provider(db, provider_id)
