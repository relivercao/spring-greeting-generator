"""
@file payment_webhook.py
@brief Public EasyPay gateway notification endpoint (no authentication).

The gateway calls back with signed notification parameters, either as a
query string (GET) or a form body (POST).  The endpoint answers with
the literal protocol bodies: ``success`` to stop retries (including the
unknown-order case) and ``fail`` with the rejection status otherwise.

"""
from typing import Dict

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import PlainTextResponse
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.services.payment.payment_fulfillment import handle_easypay_notification

router = APIRouter()


async def _collect_params(request: Request) -> Dict[str, str]:
    """Decode notification parameters from the query string or form body."""
    if request.method == "GET":
        return {str(key): str(value) for key, value in request.query_params.items()}
    form = await request.form()
    return {str(key): str(value) for key, value in form.items()}


async def _respond(instance_id: str, request: Request, db: AsyncSession) -> PlainTextResponse:
    """Shared handler for both HTTP methods of the webhook."""
    params = await _collect_params(request)
    try:
        await handle_easypay_notification(db, instance_id, params)
    except HTTPException as exc:
        logger.warning(
            "EasyPay webhook rejected for instance {}: {} ({})",
            instance_id,
            exc.detail,
            exc.status_code,
        )
        return PlainTextResponse("fail", status_code=exc.status_code or 400)
    except Exception as exc:
        logger.error(
            "EasyPay webhook crashed for instance {}: {}", instance_id, exc
        )
        return PlainTextResponse("fail", status_code=500)
    return PlainTextResponse("success")


@router.get("/payment/webhook/easypay/{instance_id}")
async def easypay_notify_get(
    instance_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> PlainTextResponse:
    """EasyPay notification via GET query parameters."""
    return await _respond(instance_id, request, db)


@router.post("/payment/webhook/easypay/{instance_id}")
async def easypay_notify_post(
    instance_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> PlainTextResponse:
    """EasyPay notification via POST form body."""
    return await _respond(instance_id, request, db)
