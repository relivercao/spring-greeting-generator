"""Account-isolated usage reports and administrator-wide reporting."""

from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_admin_user, get_current_user
from app.models.user import User
from app.repositories.usage_reporting import report, usage_filters
from app.services.usage_detail import usage_detail

router = APIRouter()


def filters(
    date_from: datetime | None = None, date_to: datetime | None = None,
    provider: str | None = Query(None, max_length=50),
    model: str | None = Query(None, max_length=200),
    agent_name: str | None = Query(None, max_length=50),
    status: Literal["completed", "failed"] | None = None,
    workflow_id: str | None = Query(None, max_length=100),
    session_id: str | None = Query(None, max_length=100),
):
    return dict(date_from=date_from, date_to=date_to, provider=provider, model=model,
                agent_name=agent_name, status=status, workflow_id=workflow_id, session_id=session_id)


async def active_user(current_user: dict = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    user = await db.get(User, current_user['id'])
    if user is None or not user.is_active:
        raise HTTPException(401, 'An active account is required')
    return user


@router.get("/usage")
async def own_usage(
    query: dict = Depends(filters), user: User = Depends(active_user),
    db: AsyncSession = Depends(get_db), page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    group_by: Literal["model", "agent", "provider", "day"] = "model",
):
    return await report(db, usage_filters(user_id=user.id, **query),
                        page=page, page_size=page_size, group_by=group_by)


@router.get("/admin/usage")
async def admin_usage(
    query: dict = Depends(filters), admin=Depends(get_current_admin_user),
    db: AsyncSession = Depends(get_db), user_id: str | None = Query(None, max_length=100),
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    group_by: Literal["model", "agent", "provider", "day"] = "model",
):
    return await report(db, usage_filters(user_id=user_id, **query),
                        page=page, page_size=page_size, group_by=group_by)


@router.get('/usage/{usage_id}')
async def own_usage_detail(usage_id: str, user: User = Depends(active_user),
                           db: AsyncSession = Depends(get_db)):
    return await usage_detail(db, usage_id, user_id=user.id)


@router.get('/admin/usage/{usage_id}')
async def admin_usage_detail(usage_id: str, admin=Depends(get_current_admin_user),
                             db: AsyncSession = Depends(get_db)):
    return await usage_detail(db, usage_id)
