"""
@file auth.py
@author caoshwen
@brief Authentication API endpoints (login, register, token refresh).

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    verify_password,
    get_current_active_user,
    get_optional_user,
)
from app.models.user import User
from app.repositories.user import UserRepository
from app.schemas.auth import (
    LogoutRequest,
    RefreshTokenRequest,
    TokenResponse,
    UserLoginRequest,
    UserRegisterRequest,
    UserResponse,
)
from app.services import auth_service, email_service

router = APIRouter()
settings = get_settings()


class SendEmailCodeRequest(BaseModel):
    """Request body for the verification-code delivery endpoint."""

    email: EmailStr = Field(..., description="Email address to receive the code")


@router.get("/session")
@router.get("/guest", include_in_schema=False)
async def get_guest_session(request: Request, response: Response):
    """Initialize or reuse the signed browser-scoped guest identity."""
    current_user = get_optional_user(request, response)
    response.headers["Cache-Control"] = "no-store"
    return {"id": current_user["id"], "username": current_user["username"]}


@router.get("/registration-options")
async def get_registration_options(db: AsyncSession = Depends(get_db)):
    """Public registration switches so the signup form can adapt."""
    toggles = await auth_service.get_registration_settings(db)
    return {
        "registration_enabled": bool(toggles.get("enabled", True)),
        "email_verify_enabled": bool(toggles.get("email_verify_enabled", False)),
        "invite_required": bool(toggles.get("invite_required", False)),
    }


@router.post("/email/send-code")
async def send_email_verification_code(request: SendEmailCodeRequest):
    """Send a 6-digit registration verification code to an email address."""
    await email_service.send_verification_code(request.email)
    return {"message": "Verification code sent if the address is valid"}


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(
    request: UserRegisterRequest,
    db: AsyncSession = Depends(get_db),
):
    """User registration (toggle-aware enhanced flow, see auth_service)"""
    user = await auth_service.register_user(request, db)
    return UserResponse.model_validate(user)


@router.post("/login", response_model=TokenResponse)
async def login(
    request: UserLoginRequest,
    db: AsyncSession = Depends(get_db),
):
    """User login by username or email, get access token"""
    user = await auth_service.resolve_by_login(db, request.username)

    if not user or not verify_password(request.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
        )

    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    user = await auth_service.bootstrap_admin(user, db)

    access_token = create_access_token(data={"sub": user.username, "user_id": user.id})
    refresh_token = create_refresh_token(data={"sub": user.username, "user_id": user.id})

    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        refresh_token=refresh_token,
        user=UserResponse.model_validate(user),
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    request: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Refresh access token using refresh token.

    Validates that the refresh token:
    - Is properly formatted and not expired
    - Has not been blacklisted (logged out)
    - Belongs to an active user
    """
    payload = decode_token(request.refresh_token)

    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    username = payload.get("sub")
    if not username:
        raise HTTPException(status_code=401, detail="Invalid token payload")

    # Check if refresh token has been blacklisted (user logged out)
    try:
        from app.infrastructure.cache import get_cache_client
        cache = get_cache_client()
        blacklist_key = f"blacklist:refresh_token:{request.refresh_token}"
        if await cache.exists(blacklist_key):
            raise HTTPException(
                status_code=401,
                detail="Token has been revoked. Please login again."
            )
    except HTTPException:
        raise
    except Exception as e:
        # Cache failure shouldn't block refresh
        from loguru import logger
        logger.warning(f"Failed to check token blacklist: {e}")

    # Verify user still exists and is active
    result = await db.execute(select(User).where(User.username == username))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found or inactive")

    new_access_token = create_access_token(data={"sub": username, "user_id": user.id})

    return TokenResponse(
        access_token=new_access_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Get current user information (profile, balance and role flags)"""
    user = await UserRepository(db).get_by_username(current_user["username"])
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return UserResponse.model_validate(user)


@router.post("/logout")
async def logout(
    request: LogoutRequest,
    current_user=Depends(get_current_active_user),
):
    """
    User logout - invalidate refresh token by adding to blacklist.

    The refresh token is added to Redis with TTL matching its expiration.
    Future refresh attempts with this token will be rejected.
    """
    from datetime import timedelta
    from app.infrastructure.cache import get_cache_client

    # Decode the refresh token to get its expiration
    try:
        payload = decode_token(request.refresh_token)

        # Verify it's actually a refresh token
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=400, detail="Invalid token type")

        # Calculate remaining TTL from token expiration
        exp_timestamp = payload.get("exp")
        if exp_timestamp:
            from datetime import datetime, timezone
            exp_time = datetime.fromtimestamp(exp_timestamp, tz=timezone.utc)
            now = datetime.now(timezone.utc)
            ttl_seconds = int((exp_time - now).total_seconds())

            # Only blacklist if token hasn't expired yet
            if ttl_seconds > 0:
                cache = get_cache_client()
                blacklist_key = f"blacklist:refresh_token:{request.refresh_token}"
                await cache.set(
                    blacklist_key,
                    current_user["username"],
                    ttl=timedelta(seconds=ttl_seconds)
                )

                return {
                    "success": True,
                    "message": "Successfully logged out, refresh token invalidated"
                }
    except HTTPException:
        # Token decode failed, but we still return success for logout
        pass
    except Exception as e:
        # Cache failure shouldn't block logout
        from loguru import logger
        logger.warning(f"Failed to blacklist refresh token: {e}")

    return {"success": True, "message": "Successfully logged out"}
