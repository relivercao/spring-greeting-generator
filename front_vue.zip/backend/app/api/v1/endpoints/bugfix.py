"""
@file bugfix.py
@author caoshwen
@brief Bug fix Agent API endpoint.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
import uuid
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import get_settings
from app.core.security import get_current_active_user
from app.models.task import Task
from app.schemas.bugfix import BugFixRequest
from app.agents.impl import BugFixAgent
from app.agents.impl.bugfix_agent import BugFixContext
from app.agents.base import AgentStatus
from app.services.bugfix_jira import JiraContextError, list_jira_bugs, load_jira_bug
from app.services.agent_task_runtime import (
    agent_task_registry,
    mark_task_cancelled,
    serialize_task,
)
from app.services.billing_service import enforce_billing
from app.services.bugfix_execution import run_bugfix_task as _run_bugfix_task
from app.api.v1.endpoints.batch_bugfix import router as batch_bugfix_router

router = APIRouter()
router.include_router(batch_bugfix_router)
_running_tasks = agent_task_registry
_BUGFIX_WORKFLOW = (
    ("fetch_issue", "Bug Context", 10, "fetch"),
    ("read_sources", "Read Source", 20, "read_code"),
    ("analyze_root_cause", "Root Cause", 40, "analyze"),
    ("module_expert_review", "Module Experts", 50, "module_expert"),
    ("generate_patch", "Generate Patch", 65, "fix"),
    ("validate_patch", "Validate", 90, "report"),
)


def _bugfix_workflow_nodes(
    progress: int,
    status: str,
    current_stage: str | None = None,
) -> list[dict[str, str]]:
    """Map persisted task progress to the BugFix LangGraph node sequence."""
    normalized_status = str(status or "").lower()
    if normalized_status == AgentStatus.COMPLETED.value:
        states = ["completed"] * len(_BUGFIX_WORKFLOW)
    elif (
        normalized_status in {AgentStatus.FAILED.value, AgentStatus.CANCELLED.value}
        and current_stage is None
        and progress < _BUGFIX_WORKFLOW[0][2]
    ):
        states = ["skipped"] * len(_BUGFIX_WORKFLOW)
    else:
        stage_index = next(
            (
                index
                for index, (_, _, _, stage) in enumerate(_BUGFIX_WORKFLOW)
                if stage == current_stage
            ),
            None,
        )
        if stage_index is None:
            stage_index = max(
                (
                    index
                    for index, (_, _, threshold, _) in enumerate(_BUGFIX_WORKFLOW)
                    if progress >= threshold
                ),
                default=0,
            )

        if normalized_status == AgentStatus.FAILED.value:
            terminal_node_status = "failed"
        elif normalized_status == AgentStatus.CANCELLED.value:
            terminal_node_status = "cancelled"
        else:
            terminal_node_status = "in_progress"

        states = [
            "completed" if index < stage_index
            else terminal_node_status if index == stage_index
            else "skipped" if normalized_status in {
                AgentStatus.FAILED.value,
                AgentStatus.CANCELLED.value,
            }
            else "pending"
            for index in range(len(_BUGFIX_WORKFLOW))
        ]

    return [
        {"node_name": name, "label": label, "status": node_status}
        for (name, label, _, _), node_status in zip(_BUGFIX_WORKFLOW, states)
    ]


def _serialize_bugfix_task(task: Task) -> dict[str, Any]:
    """Include current LangGraph node states in a pollable task response."""
    payload = serialize_task(task)
    result = payload.get("result")
    current_stage = None
    if isinstance(result, dict):
        current_stage = result.pop("_workflow_stage", None)
    payload["workflow_nodes"] = _bugfix_workflow_nodes(
        task.progress or 0,
        task.status,
        current_stage,
    )
    return payload


@router.get("/bugfix/integrations")
async def get_bugfix_integrations(raw_request: Request) -> dict[str, Any]:
    """Return connection availability without exposing integration credentials."""
    mcp_client = getattr(raw_request.app.state, "mcp_client", None)
    settings = get_settings()
    tools = {str(item.get("name") or "") for item in (mcp_client.list_tools() if mcp_client else [])}
    jira_available = any(name.startswith("jira_") for name in tools)
    bitbucket_available = any(name.startswith("bb_") for name in tools)
    git_available = any(name.startswith("git_") for name in tools)
    # Keep the original compact response for unconfigured installations. This
    # is consumed by older clients that compare the response shape exactly.
    payload: dict[str, Any] = {
        "jira": {"available": jira_available},
        "bitbucket": {"available": bitbucket_available},
    }
    configured = any(
        (
            settings.INTEGRATION_PROFILE != "general",
            settings.JIRA_BASE_URL,
            settings.JIRA_EMAIL,
            settings.JIRA_API_TOKEN,
            settings.JIRA_PROJECT_KEY,
            settings.JIRA_ISSUE_TYPES != "Bug",
            settings.JIRA_DEPLOYMENT != "cloud",
            settings.BITBUCKET_BASE_URL,
            settings.BITBUCKET_USERNAME,
            settings.BITBUCKET_APP_PASSWORD,
            settings.BITBUCKET_WORKSPACE,
            settings.BITBUCKET_DEPLOYMENT != "cloud",
            settings.GIT_PROVIDER != "local",
            settings.GIT_BASE_URL,
            settings.GIT_REPOSITORY_PATH,
            settings.GIT_REPOSITORY_URL,
            settings.GIT_USERNAME,
            settings.GIT_TOKEN,
            settings.GIT_DEFAULT_BRANCH != "main",
        )
    )
    if configured:
        payload.update(
            {
                "profile": settings.INTEGRATION_PROFILE,
                "jira": {
                    "available": jira_available,
                    "deployment": settings.JIRA_DEPLOYMENT,
                    "project": settings.JIRA_PROJECT_KEY or "",
                    "issue_types": [item.strip() for item in settings.JIRA_ISSUE_TYPES.split(",") if item.strip()],
                },
                "bitbucket": {
                    "available": bitbucket_available,
                    "deployment": settings.BITBUCKET_DEPLOYMENT,
                    "workspace": settings.BITBUCKET_WORKSPACE or "",
                },
                "git": {
                    "available": git_available,
                    "provider": settings.GIT_PROVIDER,
                    "base_url": settings.GIT_BASE_URL or "",
                    "repository_path": settings.GIT_REPOSITORY_PATH or "",
                    "repository_url": settings.GIT_REPOSITORY_URL or "",
                    "default_branch": settings.GIT_DEFAULT_BRANCH,
                },
            }
        )
    return payload


@router.get("/bugfix/jira/bugs")
async def get_bugfix_jira_bugs(
    raw_request: Request,
    project: str = Query(default="", max_length=64),
    max_results: int = Query(default=20, ge=1, le=50),
    current_user=Depends(get_current_active_user),
):
    """List Jira Bugs available as task inputs for the current user."""
    try:
        return await list_jira_bugs(
            getattr(raw_request.app.state, "mcp_client", None), project, max_results
        )
    except JiraContextError as error:
        raise HTTPException(status_code=error.status_code, detail=str(error)) from error


@router.get("/bugfix/jira/issues/{issue_key}")
async def get_bugfix_jira_issue(
    issue_key: str,
    raw_request: Request,
    current_user=Depends(get_current_active_user),
):
    """Preview a Jira Bug before starting a repair task."""
    try:
        return await load_jira_bug(
            getattr(raw_request.app.state, "mcp_client", None), issue_key
        )
    except JiraContextError as error:
        raise HTTPException(status_code=error.status_code, detail=str(error)) from error


@router.post("/bugfix")
async def fix_bug(
    request: BugFixRequest,
    raw_request: Request,
    current_user=Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Analyze and fix code bugs"""
    await enforce_billing(current_user)
    llm_bridge = raw_request.app.state.llm_bridge
    mcp_client = raw_request.app.state.mcp_client

    task_id = str(uuid.uuid4())

    # Create database task record
    task = Task(
        id=task_id,
        user_id=current_user["id"],
        agent_type="bugfix",
        status="running",
        progress=0,
        message="Bug fix task started",
        input_data=json.dumps(request.model_dump(), ensure_ascii=False),
    )
    db.add(task)
    await db.flush()

    # Instantiate Agent and build context
    agent = BugFixAgent(llm_bridge, mcp_client, getattr(raw_request.app.state, "skill_registry", None))
    context = BugFixContext(
        task_id=task_id,
        user_id=current_user["id"],
        project_root=request.project_root,
        bug_description=request.bug_description,
        issue_id=request.issue_id,
        repo=request.repo,
        branch=request.branch,
        source_files=request.source_files,
        source_contents=request.source_contents,
        max_attempts=request.max_attempts,
    )

    task_label = request.issue_id or request.bug_description[:100]
    task_desc = f"Fix bug: {task_label}"

    # Make the task visible to the worker's independent database sessions.
    await db.commit()

    # Execute in background
    background_task = asyncio.create_task(_run_bugfix_task(task_id, agent, task_desc, context), name=task_id)
    _running_tasks.register(task_id, background_task, agent)

    return {
        "task_id": task_id,
        "status": "running",
        "message": "Bug fix task created and started",
    }


async def _get_bugfix_task(task_id: str, current_user: dict, db: AsyncSession) -> Task:
    """Load a bug-fix task belonging to the current user."""
    from sqlalchemy import select
    result = await db.execute(select(Task).where(Task.id == task_id, Task.user_id == current_user["id"]))
    task = result.scalar_one_or_none()
    if not task or task.agent_type != "bugfix":
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Bug-fix task not found")
    return task


@router.get("/bugfix/tasks/{task_id}")
async def get_bugfix_task(task_id: str, current_user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    """Return the current bug-fix task state."""
    task = await _get_bugfix_task(task_id, current_user, db)
    return _serialize_bugfix_task(task)


@router.post("/bugfix/tasks/{task_id}/cancel")
async def cancel_bugfix_task(task_id: str, current_user=Depends(get_current_active_user), db: AsyncSession = Depends(get_db)):
    """Cancel a running bug-fix task."""
    task = await _get_bugfix_task(task_id, current_user, db)
    if task.status == AgentStatus.RUNNING.value:
        await _running_tasks.cancel(task_id)
        await mark_task_cancelled(task_id, "Bug-fix task cancelled")
        await db.refresh(task)
    return _serialize_bugfix_task(task)
