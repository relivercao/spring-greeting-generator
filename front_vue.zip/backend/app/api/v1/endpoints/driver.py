"""
@file driver.py
@author zhangjian
@brief Driver code generation Agent API endpoint with multi-turn conversation support.

Implements:
- POST /generate-driver          - Create driver generation task
- POST /driver/sources/upload    - Upload knowledge base / reference files
- GET  /driver/sources/{id}      - Get source status
- DELETE /driver/sources/{id}    - Delete source
- POST /driver/repository/fetch  - Fetch remote repository
- GET  /driver/repository/{id}   - Get repository status
- GET  /driver/tasks/{id}/artifacts - Get task artifacts
- POST /driver/chat              - Multi-turn chat
- GET  /driver/sessions/{id}     - Get session
- GET  /driver/sessions/{id}/messages - Get session messages
- GET  /driver/tasks/{id}        - Get task state
- GET  /driver/tasks/{id}/tool-results - Get tool results
- POST /driver/tasks/{id}/cancel - Cancel task

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, Response, UploadFile
from loguru import logger
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_optional_user
from app.core.config import get_settings
from app.core.security import get_current_active_user, decode_token
from app.core.ws_manager import ws_manager
from app.models.task import Task
from app.models.driver_agent import (
    DriverAgentTask,
    DriverSourceType,
    VALID_DRIVER_SOURCE_TYPES,
)
from app.schemas.driver import DriverGenerationRequest
from app.schemas.driver_agent import (
    DriverChatRequest,
    DriverAgentChatResponse,
    DriverAgentMessagesResponse,
    DriverAgentSessionResponse,
    DriverAgentTaskStateResponse,
    DriverAgentToolResultsResponse,
    DriverArtifactResponse,
    DriverArtifactsResponse,
    DriverGenerateRequest,
    DriverRepositoryFetchRequest,
    DriverRepositorySourceResponse,
    DriverSourceResponse,
    DriverSourcesUploadResponse,
)
from app.agents.impl import DriverAgent
from app.agents.impl.driver import DriverContext
from app.agents.impl.driver.cli_tools import check_driver_mcp
from app.agents.base import AgentStatus
from app.repositories.driver_conversation import DriverConversationRepository
from app.services.billing_service import enforce_billing
from app.services.driver_context_builder import DriverContextBuilder
from app.services.driver_docling_service import DriverDoclingService
from app.services.driver_source_service import MAX_FILES_PER_UPLOAD, DriverSourceService
from app.services.driver_repository_service import DriverRepositoryService
from app.infrastructure.observability.logger import LoggerService
from app.core.driver_build_defaults import DEFAULT_DRIVER_BUILD_PLATFORM
from app.utils.token_usage import (
    TOKEN_USAGE_STATUS_AVAILABLE,
    TOKEN_USAGE_STATUS_PENDING,
    TOKEN_USAGE_STATUS_UNAVAILABLE,
    TokenUsageAccumulator,
)
from app.agents.impl.driver.build import (
    build_executor_registry,
    normalize_build_platform as normalize_driver_build_platform,
)
from app.agents.impl.driver.build.stm32.discovery import discover_stm32cubeide

router = APIRouter()

# Process-local task registry. Driver runtime control assumes one worker; task
# status and ownership are still persisted through the conversation repository.
_active_tasks: dict[str, asyncio.Task] = {}
_active_agents: dict[str, DriverAgent] = {}
_task_owners: dict[str, str] = {}
_active_task_progress: dict[str, dict[str, Any]] = {}

# Runtime build configuration is machine-specific and must stay outside version control.
from pathlib import Path
_BACKEND_DIR = Path(__file__).resolve().parents[4]
_BUILD_CONFIG_PATH = _BACKEND_DIR / "data" / "config" / "driver_build_config.json"
_DEFAULT_BUILD_PLATFORM = DEFAULT_DRIVER_BUILD_PLATFORM
_BEIJING_TZ = timezone(timedelta(hours=8))
DRIVER_BUILD_LOG_FILENAME = "driver-build.log"
DRIVER_EXECUTION_REPORT_TYPE = "driver_execution_report"
DRIVER_REPORT_TIMESTAMP_FORMAT = "%Y%m%d-%H%M%S"
MAX_DRIVER_REPORT_DEVICE_SLUG_CHARS = 80
MAX_DRIVER_REPORT_TASK_LOG_CHARS = 120_000
MAX_DRIVER_ACTIVITY_EVENTS = 40
_DRIVER_REPORT_SENSITIVE_PATTERNS = (
    (re.compile(r"(Authorization:\s*Bearer\s+)\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(api[-_]?key\s*[:=]\s*)[\"']?\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(token\s*[:=]\s*)[\"']?\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"(password\s*[:=]\s*)[\"']?\S+", re.IGNORECASE), r"\1[REDACTED]"),
    (re.compile(r"sk-[A-Za-z0-9_-]{20,}"), "[REDACTED-KEY]"),
)


def _normalize_build_platform(platform: str | None) -> str:
    """Normalize user-facing platform names into stable config keys."""
    return normalize_driver_build_platform(platform or _DEFAULT_BUILD_PLATFORM)


def _empty_driver_build_config() -> dict:
    """Create the default driver build config payload."""
    return {
        "selected_platform": _DEFAULT_BUILD_PLATFORM,
        "platform_configs": {},
        "stm32cubeide_path": "",
        "project_path": "",
        "updated_at": None,
    }


def _normalize_driver_build_config(raw_config: dict | None) -> dict:
    """Normalize legacy and platform-based driver build config formats."""
    config = raw_config if isinstance(raw_config, dict) else {}
    normalized = _empty_driver_build_config()
    platform_configs = config.get("platform_configs")
    if not isinstance(platform_configs, dict):
        platform_configs = {}

    copied_configs = {}
    for platform, platform_config in platform_configs.items():
        platform_key = _normalize_build_platform(platform)
        if isinstance(platform_config, dict):
            editor_path = platform_config.get("editor_path") or platform_config.get("stm32cubeide_path") or ""
            copied_configs[platform_key] = {
                "editor_path": editor_path,
                "stm32cubeide_path": platform_config.get("stm32cubeide_path") or editor_path,
                "project_path": platform_config.get("project_path", ""),
                "updated_at": platform_config.get("updated_at") or config.get("updated_at"),
            }

    legacy_editor_path = config.get("editor_path") or config.get("stm32cubeide_path") or ""
    legacy_project_path = config.get("project_path", "")
    if legacy_editor_path or legacy_project_path:
        copied_configs.setdefault(
            _DEFAULT_BUILD_PLATFORM,
            {
                "editor_path": legacy_editor_path,
                "stm32cubeide_path": legacy_editor_path,
                "project_path": legacy_project_path,
                "updated_at": config.get("updated_at"),
            },
        )

    selected_platform = _normalize_build_platform(
        config.get("selected_platform") or config.get("platform") or _DEFAULT_BUILD_PLATFORM
    )
    normalized["selected_platform"] = selected_platform
    normalized["platform_configs"] = copied_configs
    normalized["updated_at"] = config.get("updated_at")

    stm32_config = copied_configs.get(_DEFAULT_BUILD_PLATFORM, {})
    normalized["stm32cubeide_path"] = (
        stm32_config.get("stm32cubeide_path") or stm32_config.get("editor_path") or ""
    )
    normalized["project_path"] = stm32_config.get("project_path", "")
    return normalized


def _get_selected_driver_build_config(config: dict, platform: str | None = None) -> tuple[str, dict]:
    """Return the selected platform key and its saved build config."""
    selected_platform = _normalize_build_platform(platform or config.get("selected_platform"))
    platform_configs = config.get("platform_configs", {})
    selected_config = platform_configs.get(selected_platform, {})
    return selected_platform, selected_config if isinstance(selected_config, dict) else {}


def _get_build_tool_resolution(platform: str, platform_config: dict) -> dict[str, Any]:
    """Return machine-local STM32CubeIDE discovery metadata without persisting it."""
    if _normalize_build_platform(platform) != _DEFAULT_BUILD_PLATFORM:
        return {
            "resolved_stm32cubeide_path": None,
            "stm32cubeide_executable": None,
            "path_source": None,
            "auto_detected": False,
        }

    configured_path = (
        platform_config.get("build_tool_path")
        or platform_config.get("stm32cubeide_path")
        or platform_config.get("editor_path")
        or None
    )
    discovery = discover_stm32cubeide(configured_path)
    return {
        "resolved_stm32cubeide_path": str(discovery.install_dir) if discovery else None,
        "stm32cubeide_executable": str(discovery.executable) if discovery else None,
        "path_source": discovery.source if discovery else None,
        "auto_detected": discovery.auto_detected if discovery else False,
    }


def _get_driver_repo(
    db: AsyncSession, user_id: str | None = None
) -> DriverConversationRepository:
    return DriverConversationRepository(db, user_id=user_id)


def _is_driver_unittest_requested(context: "DriverContext") -> bool:
    """Return whether the driver request asked for UnitTestAgent execution."""
    value = (context.output_options or {}).get("include_tests")
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


def _normalize_unittest_platform(context: "DriverContext") -> str:
    """Map driver UI platform values to UnitTestAgent platform values."""
    module_config = context.module_config or {}
    candidates = [
        context.platform,
        module_config.get("platform"),
        module_config.get("mcu_family"),
        context.mcu_family,
    ]
    haystack = " ".join(str(item).lower() for item in candidates if item)
    if "stm32u5" in haystack:
        return "stm32u5"
    if "stm32u3" in haystack:
        return "stm32u3"
    if "rtl8722fam" in haystack or "rtl8722" in haystack:
        return "rtl8722fam"
    if "nrf52" in haystack or "nrf53" in haystack or "nordic" in haystack:
        return "nrf52"
    if "stm32" in haystack:
        return "stm32u3"
    return "stm32u3"


def _resolve_driver_output_dir(task_id: str, result_data: dict[str, Any]) -> Path:
    """Resolve the directory where DriverAgent wrote generated driver files."""
    output_dir = result_data.get("output_dir")
    if output_dir:
        return Path(str(output_dir)).resolve()
    return (Path("data") / "outputs" / "driver" / task_id).resolve()


def _resolve_driver_project_path(context: "DriverContext") -> str:
    """Return the project path that can host generated unit tests, when available."""
    module_config = context.module_config or {}
    for value in (module_config.get("project_path"), context.project_root):
        if value and str(value).strip():
            return str(value).strip()
    return ""


def _has_unittest_qbs_environment(project_path: str, platform: str) -> bool:
    """Return whether a project path looks capable of QBS unittest verification."""
    if not project_path:
        return False
    try:
        from app.agents.impl.unittest.qbs import resolve_qbs_project_path

        root = Path(project_path)
        if not root.is_dir():
            return False
        qbs_dir = Path(resolve_qbs_project_path(str(root), "driver", platform))
        return qbs_dir.is_dir()
    except Exception as exc:
        logger.debug(f"[DriverUnitTest] QBS environment check failed: {exc}")
        return False


def _build_unittest_state_patch(
    unittest_task_id: str,
    unittest_result: Any,
    compile_verify: bool,
    error_message: str | None = None,
) -> dict[str, Any]:
    """Build a compact Driver task state patch from UnitTestAgent output."""
    result_data = unittest_result.data or {}
    generated_tests = getattr(unittest_result, "generated_tests", []) or []
    failed_cases = result_data.get("failed_cases") or []
    test_count = result_data.get("test_count") or result_data.get("total") or 0
    passed_count = result_data.get("passed")
    if passed_count is None and test_count:
        passed_count = max(int(test_count) - len(failed_cases), 0)

    compilation = result_data.get("compilation_summary") or {}
    compile_success = compilation.get("all_compiled")
    if compile_success is None and generated_tests:
        compile_success = all(getattr(test, "compile_success", False) for test in generated_tests)
    if not compile_verify:
        compile_success = None

    coverage = getattr(unittest_result, "total_coverage", None)
    if coverage is None:
        coverage = result_data.get("coverage", 0.0)

    status_value = getattr(unittest_result.status, "value", str(unittest_result.status))
    test_files = [
        {
            "source_file": getattr(test, "source_file", ""),
            "test_file": getattr(test, "test_file", ""),
            "coverage": getattr(test, "coverage", 0.0),
            "compile_success": getattr(test, "compile_success", False),
        }
        for test in generated_tests
    ]

    compact_result = {
        "status": status_value,
        "message": unittest_result.message,
        "compile_success": compile_success,
        "compile_verified": compile_verify,
        "coverage": coverage or 0.0,
        "branch_coverage": result_data.get("branch_coverage"),
        "function_coverage": result_data.get("function_coverage"),
        "test_count": test_count,
        "passed_count": passed_count or 0,
        "failed_cases": failed_cases,
        "test_files": test_files,
        "saved_files": result_data.get("saved_files") or [],
        "output_dir": result_data.get("output_dir"),
        "token_usage": result_data.get("token_usage") or {},
        "errors": list(getattr(unittest_result, "errors", []) or []),
    }

    return {
        "unittest_status": "failed" if error_message else status_value,
        "unittest_task_id": unittest_task_id,
        "unittest_compile_success": compile_success,
        "unittest_compile_verified": compile_verify,
        "unittest_coverage": coverage or 0.0,
        "unittest_branch_coverage": result_data.get("branch_coverage"),
        "unittest_function_coverage": result_data.get("function_coverage"),
        "unittest_tests_generated": len(generated_tests) or result_data.get("tests_generated", 0),
        "unittest_iterations_used": getattr(unittest_result, "iterations_used", 0),
        "unittest_saved_files": result_data.get("saved_files") or [],
        "unittest_error_message": error_message,
        "unittest_result": compact_result,
    }


def _build_unittest_failure_patch(
    unittest_task_id: str,
    error_message: str,
) -> dict[str, Any]:
    """Build a Driver task state patch for UnitTestAgent execution failures."""
    return {
        "unittest_status": "failed",
        "unittest_task_id": unittest_task_id,
        "unittest_compile_success": False,
        "unittest_compile_verified": False,
        "unittest_coverage": 0.0,
        "unittest_branch_coverage": None,
        "unittest_function_coverage": None,
        "unittest_tests_generated": 0,
        "unittest_iterations_used": 0,
        "unittest_saved_files": [],
        "unittest_error_message": error_message,
        "unittest_result": {
            "status": "failed",
            "message": "Unit test generation failed",
            "compile_success": False,
            "compile_verified": False,
            "coverage": 0.0,
            "branch_coverage": None,
            "function_coverage": None,
            "test_count": 0,
            "passed_count": 0,
            "failed_cases": [],
            "test_files": [],
            "saved_files": [],
            "output_dir": None,
            "token_usage": {},
            "errors": [error_message],
        },
    }


def _classify_unittest_artifact(name: str) -> str:
    """Classify generated unittest artifact names for Driver artifact rendering."""
    lower_name = name.lower()
    if lower_name.endswith(".md"):
        return "unit_test_report"
    if "mock" in lower_name:
        return "unit_test_mock"
    if lower_name.endswith((".h", ".hpp")):
        return "unit_test_header"
    return "unit_test"


def _build_unittest_report_artifact(
    source_file: str,
    state_patch: dict[str, Any],
) -> dict[str, Any]:
    """Create a compact markdown report artifact for the Driver result view."""
    module_name = Path(source_file).stem or "driver"
    status = state_patch.get("unittest_status", "unknown")
    coverage = state_patch.get("unittest_coverage", 0.0)
    compile_verified = state_patch.get("unittest_compile_verified")
    compile_success = state_patch.get("unittest_compile_success")
    error_message = state_patch.get("unittest_error_message")

    lines = [
        f"# {module_name} UnitTest Report",
        "",
        "## Summary",
        f"- Status: {status}",
        f"- Line coverage: {float(coverage or 0.0):.1f}%",
        f"- Compile verified: {bool(compile_verified)}",
        f"- Compile success: {compile_success if compile_success is not None else 'N/A'}",
        "",
        "## Recommendation",
    ]
    if error_message:
        lines.append(f"- Fix the UnitTestAgent failure first: {error_message}")
    elif compile_verified and compile_success is False:
        lines.append("- Inspect generated test code and QBS compile output before integration.")
    else:
        lines.append("- Review generated tests and integrate them into the firmware test project.")

    content = "\n".join(lines) + "\n"
    return {
        "name": f"{module_name}-unittest-report.md",
        "artifact_type": "unit_test_report",
        "language": "markdown",
        "content": content,
        "size": len(content.encode("utf-8")),
    }


def _build_unittest_artifacts(
    unittest_result: Any,
    state_patch: dict[str, Any],
    source_file: str,
) -> list[dict[str, Any]]:
    """Build Driver artifacts from UnitTestAgent saved files or in-memory tests."""
    artifacts: list[dict[str, Any]] = []
    seen_names: set[str] = set()
    saved_files = state_patch.get("unittest_saved_files") or []

    for saved_path in saved_files:
        path = Path(str(saved_path))
        if not path.is_file() or path.name in seen_names:
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning(f"[DriverUnitTest] Could not read saved unittest artifact {path}: {exc}")
            continue
        seen_names.add(path.name)
        artifacts.append({
            "name": path.name,
            "artifact_type": _classify_unittest_artifact(path.name),
            "language": "markdown" if path.suffix.lower() == ".md" else "c",
            "content": content,
            "size": len(content.encode("utf-8")),
        })

    if not artifacts:
        for test in getattr(unittest_result, "generated_tests", []) or []:
            name = getattr(test, "test_file", "") or f"tc-{Path(source_file).stem}.c"
            content = getattr(test, "test_content", "") or ""
            if not content or name in seen_names:
                continue
            seen_names.add(name)
            artifacts.append({
                "name": name,
                "artifact_type": "unit_test",
                "language": "c",
                "content": content,
                "size": len(content.encode("utf-8")),
            })

    report_artifact = _build_unittest_report_artifact(source_file, state_patch)
    if report_artifact["name"] not in seen_names:
        artifacts.append(report_artifact)
    return artifacts


def _artifact_type(artifact: dict[str, Any]) -> str:
    """Normalize DriverAgent and UnitTestAgent artifact type fields."""
    return str(artifact.get("artifact_type") or artifact.get("type") or "artifact")


def _driver_artifact_summary(artifact: dict[str, Any]) -> dict[str, Any]:
    """Keep task state and WebSocket payloads free of full artifact content."""
    return {
        "name": artifact.get("name"),
        "type": _artifact_type(artifact),
        "language": artifact.get("language"),
        "size": artifact.get("size"),
    }


def _is_safe_artifact_name(name: str) -> bool:
    """Allow only single-file artifact names for persisted Driver downloads."""
    path = Path(name)
    return bool(name) and not path.is_absolute() and path.name == name and "\x00" not in name


def _read_output_artifact_content(output_dir: str | None, name: str) -> str | None:
    """Read a text artifact from the Driver output directory without allowing path escape."""
    if not output_dir or not _is_safe_artifact_name(name):
        return None
    root = Path(output_dir).resolve()
    candidate = (root / name).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        logger.warning("[DriverArtifact] Refusing to read artifact outside output dir: {}", name)
        return None
    if not candidate.is_file():
        return None
    try:
        return candidate.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.warning("[DriverArtifact] Could not read artifact {}: {}", candidate, exc)
        return None


def _driver_artifact_content(
    drv: Any,
    result_data: dict[str, Any],
    artifact: dict[str, Any],
) -> str | None:
    """Resolve artifact content from GeneratedDriver fields or output files."""
    name = artifact.get("name")
    if not name:
        return None

    driver_content_by_name: dict[str, str | None] = {}
    if drv is not None:
        for file_attr, content_attr in (
            ("header_file", "header_content"),
            ("source_file", "source_content"),
            ("config_file", "config_content"),
            ("test_file", "test_content"),
            ("doc_file", "doc_content"),
        ):
            file_name = getattr(drv, file_attr, None)
            if file_name:
                driver_content_by_name[file_name] = getattr(drv, content_attr, None)

    content = driver_content_by_name.get(name)
    if content is not None:
        return content
    return _read_output_artifact_content(result_data.get("output_dir"), name)


def _artifact_field(artifact: Any, field: str) -> Any:
    if isinstance(artifact, dict):
        return artifact.get(field)
    return getattr(artifact, field, None)


def _is_hidden_driver_artifact(artifact: Any) -> bool:
    """Keep the internal build log out of user-facing Driver artifacts."""
    name = str(_artifact_field(artifact, "name") or "").lower()
    artifact_type = str(
        _artifact_field(artifact, "artifact_type")
        or _artifact_field(artifact, "type")
        or ""
    ).lower()
    return name == DRIVER_BUILD_LOG_FILENAME or artifact_type == "build_log"


def _sanitize_driver_report_content(value: Any) -> str:
    text = str(value or "").replace("\x00", "")
    for pattern, replacement in _DRIVER_REPORT_SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def _driver_report_code_block(value: Any, language: str = "") -> str:
    content = _sanitize_driver_report_content(value).replace("```", "` ` `")
    return f"```{language}\n{content or '(no output)'}\n```"


def _driver_report_slug(value: Any) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", str(value or "driver").lower()).strip("-")
    return (slug or "driver")[:MAX_DRIVER_REPORT_DEVICE_SLUG_CHARS].rstrip("-")


def _format_driver_report_datetime(value: Any) -> str:
    if not isinstance(value, datetime):
        return str(value or "unknown")
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat()


def _read_driver_task_execution_log(task_id: str) -> str:
    if not task_id or Path(task_id).name != task_id:
        return "(task log unavailable: invalid task id)"
    task_log_path = Path("logs") / f"task_{task_id}.log"
    try:
        return task_log_path.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return "(task execution log was not found)"
    except OSError as exc:
        return f"(failed to read task execution log: {exc})"


def _truncate_driver_report_log(value: Any) -> str:
    """Keep reports readable while retaining the raw task log on disk."""
    text = str(value or "")
    if len(text) <= MAX_DRIVER_REPORT_TASK_LOG_CHARS:
        return text
    marker = (
        "\n\n[task log excerpt: omitted "
        f"{len(text) - MAX_DRIVER_REPORT_TASK_LOG_CHARS:,} characters; "
        "the complete log remains in the task log file]\n\n"
    )
    available = max(0, MAX_DRIVER_REPORT_TASK_LOG_CHARS - len(marker))
    head_length = available // 2
    tail_length = available - head_length
    return text[:head_length] + marker + text[-tail_length:]


def _driver_report_input_lines(context: "DriverContext") -> list[str]:
    lines: list[str] = []
    source_contents = context.source_contents or []
    if source_contents:
        for source in source_contents:
            if isinstance(source, dict):
                name = source.get("name") or "unnamed source"
                source_type = source.get("source_type") or "source"
                size = len(str(source.get("content") or ""))
                lines.append(
                    f"- `{_sanitize_driver_report_content(name)}` "
                    f"({_sanitize_driver_report_content(source_type)}, {size} characters)"
                )
    repo_files = context.repo_files or []
    if repo_files:
        for repo_file in repo_files:
            if isinstance(repo_file, dict):
                name = repo_file.get("path") or repo_file.get("name") or "repository file"
            else:
                name = str(repo_file)
            lines.append(f"- Repository: `{_sanitize_driver_report_content(name)}`")
    return lines or ["- No source or repository files were recorded."]


def _build_driver_execution_report(
    task_id: str,
    context: "DriverContext",
    result_data: dict[str, Any],
    status: str,
    message: str,
    started_at: datetime | None,
) -> dict[str, Any] | None:
    """Write the user-facing Driver report with build and backend task logs."""
    try:
        finished_at = datetime.now(timezone.utc)
        timestamp = finished_at.astimezone(_BEIJING_TZ).strftime(
            DRIVER_REPORT_TIMESTAMP_FORMAT
        )
        device_name = (
            context.device_name
            or (context.module_config or {}).get("module_name")
            or "driver"
        )
        report_name = f"{_driver_report_slug(device_name)}-driver-report-{timestamp}.md"
        output_dir = _resolve_driver_output_dir(task_id, result_data)
        output_dir.mkdir(parents=True, exist_ok=True)

        build_log = result_data.get("build_log")
        if not build_log:
            build_log = _read_output_artifact_content(
                str(output_dir),
                DRIVER_BUILD_LOG_FILENAME,
            )
        task_log = _truncate_driver_report_log(_read_driver_task_execution_log(task_id))
        visible_artifacts = [
            artifact
            for artifact in result_data.get("artifacts", [])
            if not _is_hidden_driver_artifact(artifact)
            and _artifact_type(artifact) != DRIVER_EXECUTION_REPORT_TYPE
        ]
        generated_file_lines = [
            f"- `{artifact.get('name')}` ({_artifact_type(artifact)})"
            for artifact in visible_artifacts
            if artifact.get("name")
        ] or ["- No generated files were recorded."]
        token_usage = result_data.get("token_usage") or {}

        lines = [
            f"# {report_name}",
            "",
            "## Metadata",
            "",
            "| Key | Value |",
            "|-----|-------|",
            f"| task_id | `{task_id}` |",
            f"| status | {status} |",
            f"| device | {_sanitize_driver_report_content(device_name)} |",
            f"| interface | {_sanitize_driver_report_content(context.interface)} |",
            f"| started_at | {_format_driver_report_datetime(started_at)} |",
            f"| finished_at | {_format_driver_report_datetime(finished_at)} |",
            "",
            "## Summary",
            "",
            _sanitize_driver_report_content(message) or "No summary was returned.",
            "",
            "## Input Sources",
            "",
            *_driver_report_input_lines(context),
            "",
            "## Docling And Driver Generation",
            "",
            (
                "Detailed source parsing and generation events are included in the bounded "
                "Task Execution Log excerpt below; the complete raw log remains on disk."
            ),
            "",
            "## Validation",
            "",
            _driver_report_code_block(
                json.dumps(result_data.get("validation") or {}, ensure_ascii=False, indent=2, default=str),
                "json",
            ),
            "",
            "## Build Result",
            "",
            f"- Compile success: `{result_data.get('compile_success')}`",
            f"- Build attempts: `{result_data.get('build_attempts', 0)}`",
            f"- Firmware: `{result_data.get('firmware_path') or 'not generated'}`",
            "",
            "## Driver Build Log",
            "",
            _driver_report_code_block(build_log or "Compilation was not executed or produced no build log."),
            "",
            "## Generated Files",
            "",
            *generated_file_lines,
            "",
            "## Token Usage",
            "",
            _driver_report_code_block(
                json.dumps(token_usage, ensure_ascii=False, indent=2, default=str),
                "json",
            ),
            "",
            "## Task Execution Log",
            "",
            _driver_report_code_block(task_log),
            "",
        ]
        content = "\n".join(lines)
        report_path = (output_dir / report_name).resolve()
        report_path.write_text(content, encoding="utf-8")
        return {
            "name": report_name,
            "type": DRIVER_EXECUTION_REPORT_TYPE,
            "language": "markdown",
            "size": len(content.encode("utf-8")),
            "content": content,
            "path": report_name,
            "output_dir": str(output_dir),
        }
    except Exception as exc:
        logger.warning("Failed to create Driver execution report for {}: {}", task_id, exc)
        return None


def _attach_driver_execution_report(
    result_data: dict[str, Any],
    report_artifact: dict[str, Any] | None,
) -> None:
    visible_artifacts = [
        artifact
        for artifact in result_data.get("artifacts", [])
        if not _is_hidden_driver_artifact(artifact)
        and _artifact_type(artifact) != DRIVER_EXECUTION_REPORT_TYPE
    ]
    if report_artifact:
        visible_artifacts.append(report_artifact)
    result_data["artifacts"] = visible_artifacts

    visible_files = [
        str(name)
        for name in result_data.get("files", [])
        if str(name).lower() != DRIVER_BUILD_LOG_FILENAME
    ]
    if report_artifact and report_artifact["name"] not in visible_files:
        visible_files.append(report_artifact["name"])
    result_data["files"] = visible_files


async def _persist_driver_result_artifacts(
    repo: DriverConversationRepository,
    task_id: str,
    session_id: str,
    drv: Any,
    result_data: dict[str, Any],
    unittest_artifacts: list[dict[str, Any]],
) -> None:
    """Persist every artifact advertised in task state, including generated reports."""
    seen_names: set[str] = set()

    for artifact in list(result_data.get("artifacts", [])) + list(unittest_artifacts):
        if _is_hidden_driver_artifact(artifact):
            continue
        name = artifact.get("name")
        if not name or name in seen_names:
            continue
        if not _is_safe_artifact_name(str(name)):
            logger.warning("[DriverArtifact] Skipping unsafe artifact name: {}", name)
            continue
        seen_names.add(str(name))

        content = artifact.get("content")
        if content is None:
            content = _driver_artifact_content(drv, result_data, artifact)

        size = len(content.encode("utf-8")) if content is not None else artifact.get("size")
        await repo.add_artifact(
            task_id=task_id,
            session_id=session_id,
            artifact_type=_artifact_type(artifact),
            name=str(name),
            path=str(artifact.get("path") or name),
            language=artifact.get("language"),
            content=content,
            size=size,
        )


async def _run_unittest_after_driver_generation(
    task_id: str,
    context: "DriverContext",
    driver_agent: "DriverAgent",
    driver_result: Any,
    result_data: dict[str, Any],
    async_session_factory,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Run UnitTestAgent after successful DriverAgent generation and return Driver patches."""
    from app.agents.impl import UnitTestAgent
    from app.agents.impl.unittest import UnitTestContext

    drv = driver_result.generated_driver
    unittest_task_id = f"{task_id}_unittest"
    driver_output_dir = _resolve_driver_output_dir(task_id, result_data)
    source_path = (driver_output_dir / drv.source_file).resolve()
    project_path = _resolve_driver_project_path(context)
    unittest_platform = _normalize_unittest_platform(context)
    compile_verify = _has_unittest_qbs_environment(project_path, unittest_platform)
    unittest_output_dir = (
        project_path
        if compile_verify and project_path and Path(project_path).is_dir()
        else str(driver_output_dir)
    )

    async with async_session_factory() as db_session:
        repo = DriverConversationRepository(db_session, user_id=context.user_id)
        await repo.update_task_state(
            task_id,
            status="running",
            current_step="run_unittest",
            patch={
                "progress": 92,
                "message": "Generating unit tests for generated driver",
                "unittest_status": "running",
                "unittest_task_id": unittest_task_id,
                "unittest_compile_verified": compile_verify,
                "unittest_error_message": None,
            },
        )
        await db_session.commit()

    await ws_manager.send_progress(
        task_id,
        92,
        "run_unittest",
        "Generating unit tests for generated driver",
        details={
            "unittest_status": "running",
            "unittest_task_id": unittest_task_id,
            "compile_verify": compile_verify,
        },
    )

    unittest_agent = UnitTestAgent(
        driver_agent._llm,
        driver_agent._mcp,
        getattr(driver_agent, "_skill_registry", None),
    )
    unittest_progress_tasks: set[asyncio.Task] = set()
    unittest_progress_lock = asyncio.Lock()

    async def _persist_unittest_progress(update: Any) -> None:
        async with unittest_progress_lock:
            await _persist_nested_agent_progress(
                task_id,
                context,
                update,
                async_session_factory,
                "UnitTestAgent",
            )

    def _observe_unittest_progress_task(progress_task: asyncio.Task) -> None:
        unittest_progress_tasks.discard(progress_task)
        if progress_task.cancelled():
            return
        error = progress_task.exception()
        if error:
            logger.warning("UnitTestAgent progress persistence failed: {}", error)

    def _publish_unittest_progress(update: Any) -> None:
        progress_task = asyncio.create_task(_persist_unittest_progress(update))
        unittest_progress_tasks.add(progress_task)
        progress_task.add_done_callback(_observe_unittest_progress_task)

    unittest_callbacks = unittest_agent._progress_callbacks.setdefault(unittest_task_id, [])
    unittest_callbacks.append(_publish_unittest_progress)
    unittest_context = UnitTestContext(
        task_id=unittest_task_id,
        session_id=context.session_id,
        user_id=context.user_id,
        source_files=[drv.source_file],
        source_contents={drv.source_file: drv.source_content},
        source_path_map={drv.source_file: str(source_path)},
        layer="driver",
        test_framework="gtest",
        coverage_target=0.9,
        max_iterations=5,
        output_dir=unittest_output_dir,
        enable_mock=True,
        compile_verify=compile_verify,
        build_profile="mingw",
        platform=unittest_platform,
        auto_update_qbs=compile_verify,
        generation_method="cli",
        metadata={
            "driver_task_id": task_id,
            "driver_header_file": drv.header_file,
            "driver_config_file": drv.config_file,
            "driver_output_dir": str(driver_output_dir),
        },
    )

    try:
        try:
            unittest_result = await unittest_agent.execute(
                f"Generate gtest unit tests for generated driver {drv.source_file}",
                unittest_context,
            )
        except Exception as exc:
            logger.opt(exception=True).error(
                "[DriverUnitTest] UnitTestAgent failed for driver task {}: {}",
                task_id,
                exc,
            )
            failure_patch = _build_unittest_failure_patch(unittest_task_id, str(exc))
            return failure_patch, [_build_unittest_report_artifact(drv.source_file, failure_patch)]
    finally:
        if unittest_progress_tasks:
            await asyncio.gather(*list(unittest_progress_tasks), return_exceptions=True)
        try:
            unittest_callbacks.remove(_publish_unittest_progress)
        except ValueError:
            pass

    error_message = None
    if unittest_result.status != AgentStatus.COMPLETED:
        errors = list(getattr(unittest_result, "errors", []) or [])
        error_message = "\n".join(errors) or unittest_result.message or "UnitTestAgent failed"

    state_patch = _build_unittest_state_patch(
        unittest_task_id,
        unittest_result,
        compile_verify=compile_verify,
        error_message=error_message,
    )
    artifacts = _build_unittest_artifacts(unittest_result, state_patch, drv.source_file)
    return state_patch, artifacts


async def _run_driver_task(
    task_id: str,
    agent: DriverAgent,
    task_desc: str,
    context: DriverContext,
):
    """Execute driver generation task in background and update database."""
    from app.core.database import async_session_factory

    try:
        result = await agent.execute(task_desc, context)

        async with async_session_factory() as session:
            from sqlalchemy import select
            stmt = select(Task).where(Task.id == task_id)
            db_result = await session.execute(stmt)
            task = db_result.scalar_one_or_none()
            if task:
                task.status = result.status.value
                task.progress = 100 if result.status == AgentStatus.COMPLETED else -1
                task.message = result.message
                task.result_data = json.dumps(result.data, ensure_ascii=False) if result.data else None
                task.error_message = "\n".join(result.errors) if result.errors else None
                task.duration_ms = result.duration_ms
                await session.commit()

        await ws_manager.send_complete(task_id, result.data)

    except Exception as e:
        logger.opt(exception=True).error("Driver task {} failed: {}", task_id, e)
        async with async_session_factory() as session:
            from sqlalchemy import select
            stmt = select(Task).where(Task.id == task_id)
            db_result = await session.execute(stmt)
            task = db_result.scalar_one_or_none()
            if task:
                task.status = "failed"
                task.error_message = str(e)
                await session.commit()
        await ws_manager.send_error(task_id, str(e))


_DRIVER_TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled"})
_DRIVER_CANCEL_IGNORE_STATUSES = frozenset({"completed", "failed"})
_DRIVER_CLIENT_TASK_ID_PATTERN = re.compile(r"^task_[A-Za-z0-9_-]{8,}$")
_DRIVER_PROGRESS_STAGE_ORDER = {
    "ingest_sources": 0,
    "compile_knowledge_base": 0,
    "build_context": 1,
    "build_prompt": 1,
    "review_requirements": 1,
    "analyze": 1,
    "generating_driver": 2,
    "code_gen": 2,
    "generate": 2,
    "static_validation": 2,
    "compile": 3,
    "compile_start": 3,
    "compile_success": 3,
    "compile_failed": 3,
    "compile_error": 3,
    "compile_skipped": 3,
    "compile_unsupported": 3,
    "export_artifacts": 4,
    "run_unittest": 5,
    "unit_test": 5,
    "code_review": 6,
}


def _driver_cancel_protection_reason(task: Any) -> str | None:
    """Explain why a Driver task should ignore a cancellation request."""
    status = str(getattr(task, "status", "") or "")
    if status in _DRIVER_CANCEL_IGNORE_STATUSES:
        return f"task already {status}"
    return None


def _driver_progress_rank(stage: str | None, progress: Any = None) -> tuple[int, float]:
    """Return a comparable rank for Driver progress updates."""
    stage_order = _DRIVER_PROGRESS_STAGE_ORDER.get(str(stage or ""), -1)
    try:
        progress_value = float(progress)
    except (TypeError, ValueError):
        progress_value = -1.0
    return stage_order, progress_value


def _should_accept_driver_progress(
    current_stage: str | None,
    current_progress: Any,
    next_stage: str | None,
    next_progress: Any,
) -> bool:
    """Accept forward Driver stages and reject stale progress callbacks."""
    current_stage_order, current_progress_value = _driver_progress_rank(
        current_stage,
        current_progress,
    )
    next_stage_order, next_progress_value = _driver_progress_rank(
        next_stage,
        next_progress,
    )
    return (
        current_stage_order < 0
        or next_stage_order > current_stage_order
        or (
            next_stage_order == current_stage_order
            and next_progress_value >= current_progress_value
        )
    )


def _driver_activity_event(update: Any, agent_name: str) -> dict[str, Any]:
    """Build a bounded, content-free runtime event for Driver task monitoring."""
    details = getattr(update, "details", None)
    details = details if isinstance(details, dict) else {}
    runtime = details.get("cli_runtime")
    runtime_summary = None
    if isinstance(runtime, dict):
        runtime_summary = {
            key: runtime.get(key)
            for key in (
                "elapsed_seconds",
                "silence_seconds",
                "tool_calls",
                "tool_results",
                "tool_errors",
                "last_tool",
                "driver_mcp_status",
                "result_subtype",
                "result_is_error",
                "permission_denials",
                "heartbeat_at",
            )
            if key in runtime
        }
        runtime_summary["active_tools"] = [
            {
                "name": str(tool.get("name") or "unknown")[:100],
                "elapsed_seconds": tool.get("elapsed_seconds"),
            }
            for tool in runtime.get("active_tools", [])
            if isinstance(tool, dict)
        ]

    timestamp = getattr(update, "timestamp", None)
    message = str(getattr(update, "message", "") or "")
    if runtime_summary is not None:
        message = "Claude CLI activity"
    return {
        "agent": agent_name,
        "task_id": str(getattr(update, "task_id", "") or "")[:64],
        "stage": str(getattr(update, "stage", "") or "")[:80],
        "progress": getattr(update, "progress", None),
        "message": _sanitize_driver_report_content(message)[:400],
        "timestamp": _format_driver_report_datetime(timestamp),
        "runtime": runtime_summary,
    }


def _record_driver_activity(
    state_data: dict[str, Any],
    event: dict[str, Any],
    status: str = "running",
) -> dict[str, Any]:
    """Merge one agent snapshot and append meaningful changes to a bounded timeline."""
    events = list(state_data.get("activity_events") or [])
    previous = events[-1] if events else None
    signature_keys = ("agent", "task_id", "stage", "progress", "message", "runtime")
    if not isinstance(previous, dict) or any(
        previous.get(key) != event.get(key) for key in signature_keys
    ):
        events.append(event)

    runs = list(state_data.get("agent_runs") or [])
    run_index = next(
        (
            index for index, run in enumerate(runs)
            if isinstance(run, dict)
            and run.get("agent") == event["agent"]
            and run.get("task_id") == event["task_id"]
        ),
        None,
    )
    run = {
        "agent": event["agent"],
        "task_id": event["task_id"],
        "status": status,
        "stage": event["stage"],
        "progress": event["progress"],
        "message": event["message"],
        "updated_at": event["timestamp"],
    }
    if run_index is None:
        runs.append(run)
    else:
        runs[run_index] = {**runs[run_index], **run}

    return {
        "activity_events": events[-MAX_DRIVER_ACTIVITY_EVENTS:],
        "agent_runs": runs[-8:],
    }


def _set_driver_agent_status(
    state_data: dict[str, Any],
    agent_name: str,
    status: str,
    task_id: str | None = None,
) -> list[dict[str, Any]]:
    """Set an agent run's terminal state while preserving its last observed stage."""
    runs = list(state_data.get("agent_runs") or [])
    now = datetime.now(timezone.utc).isoformat()
    for index, run in enumerate(runs):
        if (
            isinstance(run, dict)
            and run.get("agent") == agent_name
            and (task_id is None or run.get("task_id") == task_id)
        ):
            runs[index] = {**run, "status": status, "updated_at": now}
            return runs
    runs.append({
        "agent": agent_name,
        "task_id": task_id or "",
        "status": status,
        "stage": "",
        "progress": None,
        "message": "",
        "updated_at": now,
    })
    return runs[-8:]


def _driver_progress_patch(update: Any) -> dict[str, Any]:
    """Build state_data fields proving the Driver stage came from backend progress."""
    timestamp = getattr(update, "timestamp", None)
    return {
        "progress": update.progress,
        "message": update.message,
        "backend_stage": update.stage,
        "stage_confirmed": True,
        "stage_source": "driver_agent_progress",
        "stage_updated_at": (
            timestamp.isoformat()
            if timestamp
            else datetime.now(timezone.utc).isoformat()
        ),
    }


def _remember_active_driver_progress(task_id: str, update: Any) -> None:
    """Expose the latest backend stage to polling before slower DB writes finish."""
    existing = _active_task_progress.get(task_id, {})
    state_data = dict(existing.get("state_data") or {})
    event = _driver_activity_event(update, "DriverAgent")
    state_data.update(_record_driver_activity(state_data, event))
    current_stage = existing.get("current_step")
    current_progress = state_data.get("progress")

    if not _should_accept_driver_progress(
        current_stage,
        current_progress,
        update.stage,
        update.progress,
    ):
        _active_task_progress[task_id] = {
            "current_step": current_stage,
            "state_data": state_data,
        }
        return

    stage_patch = _driver_progress_patch(update)
    if getattr(update, "details", None):
        stage_patch["details"] = update.details
    state_data.update(stage_patch)
    _active_task_progress[task_id] = {
        "current_step": update.stage,
        "state_data": state_data,
    }


def _merge_active_driver_progress(
    task_id: str,
    task: Any,
    state_data: dict[str, Any] | None,
) -> tuple[str | None, dict[str, Any] | None]:
    """Overlay process-local active progress onto persisted task state."""
    if str(getattr(task, "status", "") or "") in _DRIVER_TERMINAL_STATUSES:
        return getattr(task, "current_step", None), state_data

    active_progress = _active_task_progress.get(task_id)
    if not active_progress:
        return getattr(task, "current_step", None), state_data

    persisted_state = dict(state_data or {})
    active_state = dict(active_progress.get("state_data") or {})
    persisted_step = getattr(task, "current_step", None)
    active_step = active_progress.get("current_step")
    active_is_newer = _driver_progress_rank(
        active_step,
        active_state.get("progress"),
    ) >= _driver_progress_rank(
        persisted_step,
        persisted_state.get("progress"),
    )

    merged_state = dict(persisted_state)
    if active_is_newer:
        for key in (
            "progress",
            "message",
            "backend_stage",
            "stage_confirmed",
            "stage_source",
            "stage_updated_at",
            "details",
        ):
            if key in active_state:
                merged_state[key] = active_state[key]
        current_step = active_step or persisted_step
    else:
        current_step = persisted_step or active_step

    for key in ("activity_events", "agent_runs"):
        records = [
            item
            for source in (persisted_state.get(key), active_state.get(key))
            for item in (source or [])
            if isinstance(item, dict)
        ]
        if key == "agent_runs":
            latest_records: dict[tuple[str, str], dict[str, Any]] = {}
            for item in records:
                identity = (str(item.get("agent") or ""), str(item.get("task_id") or ""))
                previous = latest_records.get(identity)
                if previous is None or str(item.get("updated_at") or "") >= str(previous.get("updated_at") or ""):
                    latest_records[identity] = item
            records = sorted(latest_records.values(), key=lambda item: str(item.get("updated_at") or ""))[-8:]
        else:
            unique_records: dict[tuple[str, ...], dict[str, Any]] = {}
            for item in records:
                identity = tuple(
                    str(item.get(field) or "")
                    for field in ("agent", "task_id", "stage", "progress", "message", "timestamp")
                )
                unique_records[identity] = item
            records = sorted(unique_records.values(), key=lambda item: str(item.get("timestamp") or ""))[-MAX_DRIVER_ACTIVITY_EVENTS:]
        if records:
            merged_state[key] = records

    return current_step, merged_state


def _driver_state_data(task: Any) -> dict[str, Any]:
    """Return parsed task state data, tolerating legacy malformed state JSON."""
    raw_state = getattr(task, "state_data", None)
    if isinstance(raw_state, dict):
        state_data = dict(raw_state)
    elif not raw_state:
        state_data = {}
    else:
        try:
            parsed = json.loads(raw_state)
            state_data = parsed if isinstance(parsed, dict) else {}
        except (TypeError, json.JSONDecodeError):
            state_data = {}

    token_usage = TokenUsageAccumulator.merge(state_data.get("token_usage"))
    state_data["token_usage"] = token_usage
    token_status = state_data.get("token_usage_status")
    if TokenUsageAccumulator.has_usage(token_usage):
        token_status = TOKEN_USAGE_STATUS_AVAILABLE
    elif token_status not in {
        TOKEN_USAGE_STATUS_PENDING,
        TOKEN_USAGE_STATUS_AVAILABLE,
        TOKEN_USAGE_STATUS_UNAVAILABLE,
    }:
        token_status = (
            TOKEN_USAGE_STATUS_UNAVAILABLE
            if getattr(task, "status", None) in _DRIVER_TERMINAL_STATUSES
            else TOKEN_USAGE_STATUS_PENDING
        )
    state_data["token_usage_status"] = token_status
    state_data.setdefault(
        "token_usage_message",
        "Token usage reported by the provider."
        if token_status == TOKEN_USAGE_STATUS_AVAILABLE
        else (
            "The provider did not report token usage before the CLI run ended."
            if token_status == TOKEN_USAGE_STATUS_UNAVAILABLE
            else "Waiting for the provider to report token usage."
        ),
    )
    return state_data


def _driver_task_token_usage(task: Any) -> dict[str, int]:
    """Extract normalized token usage from a persisted Driver task."""
    return TokenUsageAccumulator.merge(_driver_state_data(task).get("token_usage"))


def _driver_token_usage_state(
    agent: Any,
    base_token_usage: dict[str, Any] | None = None,
    *,
    terminal: bool = False,
    reported_token_usage: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the task-facing token usage snapshot and reporting state."""
    monitor = getattr(agent, "_monitor", None)
    monitor_usage = monitor.get_token_usage() if monitor else None
    if TokenUsageAccumulator.has_usage(monitor_usage):
        token_usage = TokenUsageAccumulator.merge(base_token_usage, monitor_usage)
    else:
        token_usage = TokenUsageAccumulator.merge(base_token_usage, reported_token_usage)
    monitor_state = (
        monitor.get_token_usage_state(terminal=terminal)
        if monitor and hasattr(monitor, "get_token_usage_state")
        else {}
    )
    if TokenUsageAccumulator.has_usage(token_usage):
        status = TOKEN_USAGE_STATUS_AVAILABLE
        message = "Token usage reported by the provider."
    elif terminal:
        status = TOKEN_USAGE_STATUS_UNAVAILABLE
        message = "The provider did not report token usage before the CLI run ended."
    else:
        status = TOKEN_USAGE_STATUS_PENDING
        message = "Waiting for the provider to report token usage."
    return {
        "token_usage": token_usage,
        "token_usage_status": status,
        "token_usage_source": monitor_state.get("source") if isinstance(monitor_state, dict) else None,
        "token_usage_message": message,
    }


def _is_newer_driver_token_snapshot(
    current_usage: dict[str, Any] | None,
    incoming_usage: dict[str, Any] | None,
) -> bool:
    """Return whether a token snapshot contains any new cumulative count."""
    current = TokenUsageAccumulator.merge(current_usage)
    incoming = TokenUsageAccumulator.merge(incoming_usage)
    return any(incoming[field] > current[field] for field in TokenUsageAccumulator.FIELDS)


async def _load_driver_task_token_usage(
    repo: DriverConversationRepository,
    task_id: str,
) -> dict[str, int]:
    """Load the latest persisted token usage for one Driver task."""
    task = await repo.get_task(task_id)
    if task is not None:
        try:
            await repo.db.refresh(task, attribute_names=["state_data"])
        except Exception as exc:
            logger.warning("Failed to refresh Driver task token usage for {}: {}", task_id, exc)
    return _driver_task_token_usage(task) if task else TokenUsageAccumulator.merge()


def _is_client_generated_driver_task_id(task_id: str) -> bool:
    """Return true for Driver task ids generated by the frontend before POST completes."""
    return bool(_DRIVER_CLIENT_TASK_ID_PATTERN.fullmatch(str(task_id or "")))


def _pending_driver_task_response(task_id: str) -> DriverAgentTaskStateResponse:
    """Return a bounded-polling placeholder for a task being created by POST /driver/generate."""
    now = datetime.now(timezone.utc)
    return DriverAgentTaskStateResponse(
        id=task_id,
        session_id="",
        status="pending",
        current_step="ingest_sources",
        target_file=None,
        test_file=None,
        project_root=None,
        build_command=None,
        retry_count=0,
        max_retries=0,
        last_error=None,
        state_data={
            "progress": 0,
            "message": "Driver task is being registered",
            "backend_stage": "ingest_sources",
            "task_registration_pending": True,
            "token_usage": TokenUsageAccumulator.merge(),
            "token_usage_status": TOKEN_USAGE_STATUS_PENDING,
            "token_usage_message": "Waiting for the provider to report token usage.",
        },
        created_at=now,
        updated_at=now,
    )


async def _persist_progress_update(
    task_id: str,
    context: "DriverContext",
    agent: "DriverAgent",
    update: Any,
    async_session_factory: Any,
    base_token_usage: dict[str, Any] | None = None,
) -> None:
    """Persist one agent progress update and forward it to the task WebSocket."""
    patch = _driver_progress_patch(update)
    token_state = _driver_token_usage_state(agent, base_token_usage)
    patch.update({
        "token_usage": token_state["token_usage"],
        "token_usage_status": token_state["token_usage_status"],
        "token_usage_message": token_state["token_usage_message"],
    })
    if token_state.get("token_usage_source"):
        patch["token_usage_source"] = token_state["token_usage_source"]
    if update.details:
        patch["details"] = update.details

    async with async_session_factory() as db_session:
        repo = DriverConversationRepository(db_session, user_id=context.user_id)
        existing = await repo.get_task(task_id)
        if existing and existing.status in _DRIVER_TERMINAL_STATUSES:
            return
        existing_state = _driver_state_data(existing) if existing else {}
        if existing and not _should_accept_driver_progress(
            existing.current_step,
            existing_state.get("progress"),
            update.stage,
            update.progress,
        ):
            return
        patch.update(
            _record_driver_activity(
                existing_state,
                _driver_activity_event(update, "DriverAgent"),
            )
        )
        await repo.update_task_state(
            task_id,
            status="running",
            current_step=update.stage,
            patch=patch,
        )
        await db_session.commit()

    await ws_manager.send_progress(
        task_id,
        update.progress,
        update.stage,
        update.message,
        details=update.details,
    )


async def _persist_nested_agent_progress(
    parent_task_id: str,
    context: "DriverContext",
    update: Any,
    async_session_factory: Any,
    agent_name: str,
) -> None:
    """Persist nested agent progress without replacing the parent workflow stage."""
    event = _driver_activity_event(update, agent_name)
    async with async_session_factory() as db_session:
        repo = DriverConversationRepository(db_session, user_id=context.user_id)
        existing = await repo.get_task(parent_task_id)
        if existing is None or existing.status in _DRIVER_TERMINAL_STATUSES:
            return
        state_data = _driver_state_data(existing)
        await repo.update_task_state(
            parent_task_id,
            status="running",
            current_step=existing.current_step or "run_unittest",
            patch=_record_driver_activity(state_data, event),
        )
        await db_session.commit()

    await ws_manager.send_progress(
        parent_task_id,
        int(state_data.get("progress", 92)),
        existing.current_step or "run_unittest",
        update.message,
        details={"agent": agent_name, "agent_stage": update.stage},
    )


def _start_token_usage_tracker(
    task_id: str,
    context: "DriverContext",
    agent: "DriverAgent",
    async_session_factory: Any,
    base_token_usage: dict[str, Any] | None = None,
) -> asyncio.Task:
    """Track token usage until the Driver task reaches a terminal state."""
    async def _update_token_usage() -> None:
        last_persisted_usage: dict[str, int] | None = None
        last_persisted_status: str | None = None
        while True:
            await asyncio.sleep(2)
            if not hasattr(agent, "_monitor"):
                continue
            token_state = _driver_token_usage_state(agent, base_token_usage)
            token_usage = token_state["token_usage"]
            token_status = token_state["token_usage_status"]
            if (
                token_usage == last_persisted_usage
                and token_status == last_persisted_status
            ):
                continue
            patch = {
                "token_usage": token_usage,
                "token_usage_status": token_status,
                "token_usage_message": token_state["token_usage_message"],
            }
            if token_state.get("token_usage_source"):
                patch["token_usage_source"] = token_state["token_usage_source"]
            async with async_session_factory() as db_session:
                repo = DriverConversationRepository(db_session, user_id=context.user_id)
                existing = await repo.get_task(task_id)
                if existing and existing.status in _DRIVER_TERMINAL_STATUSES:
                    return
                existing_state = _driver_state_data(existing) if existing else {}
                if existing and (
                    not _is_newer_driver_token_snapshot(
                        existing_state.get("token_usage"),
                        token_usage,
                    )
                    and existing_state.get("token_usage_status") == token_status
                ):
                    last_persisted_usage = token_usage
                    last_persisted_status = token_status
                    continue
                await repo.update_task_state(
                    task_id,
                    status="running",
                    patch=patch,
                )
                await db_session.commit()
            last_persisted_usage = token_usage
            last_persisted_status = token_status

    return asyncio.create_task(_update_token_usage())


async def _run_optional_unittest(
    task_id: str,
    context: "DriverContext",
    agent: "DriverAgent",
    result: Any,
    async_session_factory: Any,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Run UnitTestAgent only for successful Driver results that request tests."""
    from app.agents.impl.driver import DriverResult

    if (
        result.status != AgentStatus.COMPLETED
        or not isinstance(result, DriverResult)
        or not result.generated_driver
        or not _is_driver_unittest_requested(context)
    ):
        return {}, []
    return await _run_unittest_after_driver_generation(
        task_id,
        context,
        agent,
        result,
        result.data or {},
        async_session_factory,
    )


async def _persist_successful_driver_result(
    task_id: str,
    session_id: str,
    context: "DriverContext",
    result: Any,
    unittest_state_patch: dict[str, Any],
    unittest_artifacts: list[dict[str, Any]],
    async_session_factory: Any,
) -> None:
    """Persist generated Driver files, reports, and task metadata."""
    result_data = result.data or {}
    artifact_summaries = [
        _driver_artifact_summary(artifact)
        for artifact in result_data.get("artifacts", [])
        if not _is_hidden_driver_artifact(artifact)
    ]
    artifact_summaries.extend(
        {
            "name": item["name"],
            "type": item["artifact_type"],
            "language": item.get("language"),
            "size": item.get("size"),
        }
        for item in unittest_artifacts
    )
    token_usage = TokenUsageAccumulator.merge(result_data.get("token_usage"))
    async with async_session_factory() as db_session:
        repo = DriverConversationRepository(db_session, user_id=context.user_id)
        existing = await repo.get_task(task_id)
        existing_state = _driver_state_data(existing) if existing else {}
        agent_runs = _set_driver_agent_status(
            existing_state, "DriverAgent", "completed", task_id,
        )
        if unittest_state_patch.get("unittest_task_id"):
            unittest_status = (
                "failed"
                if unittest_state_patch.get("unittest_status") == "failed"
                else "completed"
            )
            agent_runs = _set_driver_agent_status(
                {"agent_runs": agent_runs},
                "UnitTestAgent",
                unittest_status,
                str(unittest_state_patch["unittest_task_id"]),
            )
        await repo.update_task_state(
            task_id,
            status="completed",
            current_step="export_artifacts",
            patch={
                "progress": 100,
                "output_dir": result_data.get("output_dir"),
                "artifacts": artifact_summaries,
                "files": [
                    name
                    for name in result_data.get("files", [])
                    if str(name).lower() != DRIVER_BUILD_LOG_FILENAME
                ]
                + [item["name"] for item in unittest_artifacts],
                "token_usage": token_usage,
                "token_usage_status": (
                    TOKEN_USAGE_STATUS_AVAILABLE
                    if TokenUsageAccumulator.has_usage(token_usage)
                    else TOKEN_USAGE_STATUS_UNAVAILABLE
                ),
                "token_usage_message": (
                    "Token usage reported by the provider."
                    if TokenUsageAccumulator.has_usage(token_usage)
                    else "The provider did not report token usage before the CLI run ended."
                ),
                "source_count": result_data.get("source_count", 0),
                "repo_file_count": result_data.get("repo_file_count", 0),
                "agent_runs": agent_runs,
                **unittest_state_patch,
            },
        )
        await _persist_driver_result_artifacts(
            repo,
            task_id,
            session_id,
            result.generated_driver,
            result_data,
            unittest_artifacts,
        )
        await db_session.commit()


async def _persist_failed_driver_result(
    task_id: str,
    session_id: str,
    context: "DriverContext",
    error_message: str,
    async_session_factory: Any,
    token_usage: dict[str, Any] | None = None,
    report_artifact: dict[str, Any] | None = None,
) -> None:
    """Persist the terminal failure state for a Driver task."""
    patch: dict[str, Any] = {}
    normalized_usage = TokenUsageAccumulator.merge(token_usage)
    patch["token_usage"] = normalized_usage
    patch["token_usage_status"] = (
        TOKEN_USAGE_STATUS_AVAILABLE
        if TokenUsageAccumulator.has_usage(normalized_usage)
        else TOKEN_USAGE_STATUS_UNAVAILABLE
    )
    patch["token_usage_message"] = (
        "Token usage reported by the provider."
        if TokenUsageAccumulator.has_usage(normalized_usage)
        else "The provider did not report token usage before the CLI run ended."
    )
    if report_artifact:
        patch.update({
            "output_dir": report_artifact.get("output_dir"),
            "artifacts": [{
                "name": report_artifact["name"],
                "type": DRIVER_EXECUTION_REPORT_TYPE,
                "language": "markdown",
                "size": report_artifact.get("size"),
            }],
            "files": [report_artifact["name"]],
        })
    async with async_session_factory() as db_session:
        repo = DriverConversationRepository(db_session, user_id=context.user_id)
        existing = await repo.get_task(task_id)
        existing_state = _driver_state_data(existing) if existing else {}
        patch["agent_runs"] = _set_driver_agent_status(
            existing_state, "DriverAgent", "failed", task_id,
        )
        await repo.update_task_state(
            task_id,
            status="failed",
            current_step=None,
            patch=patch or None,
            last_error=error_message,
        )
        if report_artifact:
            await repo.add_artifact(
                task_id=task_id,
                session_id=session_id,
                artifact_type=DRIVER_EXECUTION_REPORT_TYPE,
                name=report_artifact["name"],
                path=report_artifact["name"],
                language="markdown",
                content=report_artifact.get("content"),
                size=report_artifact.get("size"),
            )
        await db_session.commit()


async def _handle_driver_task_cancelled(
    task_id: str,
    session_id: str,
    context: "DriverContext",
    async_session_factory: Any,
    report_artifact: dict[str, Any] | None = None,
) -> None:
    """Persist and publish a cancellation requested by the task owner."""
    logger.warning("Driver generation task {} was cancelled by user", task_id)
    async with async_session_factory() as db_session:
        repo = DriverConversationRepository(db_session, user_id=context.user_id)
        existing = await repo.get_task(task_id)
        existing_state = _driver_state_data(existing) if existing else {}
        agent_runs = [
            {**run, "status": "cancelled", "updated_at": datetime.now(timezone.utc).isoformat()}
            if isinstance(run, dict) and run.get("status") == "running"
            else run
            for run in existing_state.get("agent_runs", [])
        ]
        patch = {"agent_runs": agent_runs}
        if report_artifact:
            patch = {
                "output_dir": report_artifact.get("output_dir"),
                "artifacts": [{
                    "name": report_artifact["name"],
                    "type": DRIVER_EXECUTION_REPORT_TYPE,
                    "language": "markdown",
                    "size": report_artifact.get("size"),
                }],
                "files": [report_artifact["name"]],
            }
        await repo.update_task_state(
            task_id,
            status="cancelled",
            current_step=None,
            patch=patch,
            last_error="Task cancelled by user",
        )
        if report_artifact:
            await repo.add_artifact(
                task_id=task_id,
                session_id=session_id,
                artifact_type=DRIVER_EXECUTION_REPORT_TYPE,
                name=report_artifact["name"],
                path=report_artifact["name"],
                language="markdown",
                content=report_artifact.get("content"),
                size=report_artifact.get("size"),
            )
        await db_session.commit()
    await ws_manager.send_error(task_id, "Task cancelled by user")


async def _cleanup_driver_runtime_state(
    task_id: str,
    callbacks: list[Any],
    progress_callback: Any,
    token_task: asyncio.Task,
    progress_tasks: set[asyncio.Task],
) -> None:
    """Stop runtime helpers and clear the process-local task registry."""
    token_task.cancel()
    try:
        await token_task
    except asyncio.CancelledError:
        pass
    if progress_tasks:
        await asyncio.gather(*progress_tasks, return_exceptions=True)
    try:
        callbacks.remove(progress_callback)
    except ValueError:
        pass
    _active_tasks.pop(task_id, None)
    _active_agents.pop(task_id, None)
    _task_owners.pop(task_id, None)
    _active_task_progress.pop(task_id, None)
    LoggerService.remove_task_sink(task_id)


async def _run_driver_generation_task(
    task_id: str,
    session_id: str,
    agent: "DriverAgent",
    task_desc: str,
    context: "DriverContext",
    base_token_usage: dict[str, Any] | None = None,
    started_at: datetime | None = None,
):
    """Execute driver generation pipeline, persist results to conversation repo."""
    from app.core.database import async_session_factory
    from app.agents.impl.driver import DriverResult
    from app.services.driver_progress import DriverProgressWriter

    result_data: dict[str, Any] = {}
    runtime_cleaned = False

    async def _persist_latest_progress(update: Any) -> None:
        await _persist_progress_update(
            task_id, context, agent, update, async_session_factory, base_token_usage,
        )

    progress_writer = DriverProgressWriter(_persist_latest_progress)
    progress_tasks = progress_writer.tasks

    def _schedule_progress_persist(update: Any) -> None:
        _remember_active_driver_progress(task_id, update)
        progress_writer.submit(update)

    callbacks = agent._progress_callbacks.setdefault(task_id, [])
    callbacks.append(_schedule_progress_persist)

    token_task = _start_token_usage_tracker(
        task_id,
        context,
        agent,
        async_session_factory,
        base_token_usage,
    )

    try:
        result = await agent.execute(task_desc, context)
        if progress_tasks:
            await asyncio.gather(*list(progress_tasks), return_exceptions=True)
            progress_tasks.clear()
        if not isinstance(result.data, dict):
            result.data = {}
        result_data = result.data
        token_state = _driver_token_usage_state(
            agent,
            base_token_usage,
            terminal=True,
            reported_token_usage=result_data.get("token_usage"),
        )
        result_data.update(token_state)

        unittest_state_patch, unittest_artifacts = await _run_optional_unittest(
            task_id,
            context,
            agent,
            result,
            async_session_factory,
        )
        error_msg = "\n".join(result.errors) if result.errors else (
            result.message or "Agent execution failed"
        )
        logger.info("Driver task {} finished; finalizing execution report", task_id)
        await _cleanup_driver_runtime_state(
            task_id,
            callbacks,
            _schedule_progress_persist,
            token_task,
            progress_tasks,
        )
        runtime_cleaned = True
        report_artifact = _build_driver_execution_report(
            task_id=task_id,
            context=context,
            result_data=result_data,
            status=result.status.value,
            message=result.message or error_msg,
            started_at=started_at,
        )
        _attach_driver_execution_report(result_data, report_artifact)

        if result.status == AgentStatus.COMPLETED and isinstance(result, DriverResult):
            await _persist_successful_driver_result(
                task_id,
                session_id,
                context,
                result,
                unittest_state_patch,
                unittest_artifacts,
                async_session_factory,
            )
        else:
            await _persist_failed_driver_result(
                task_id,
                session_id,
                context,
                error_msg,
                async_session_factory,
                result_data.get("token_usage"),
                report_artifact,
            )

        completion_payload = dict(result_data)
        completion_payload["artifacts"] = [
            _driver_artifact_summary(artifact)
            for artifact in result_data.get("artifacts", [])
            if not _is_hidden_driver_artifact(artifact)
        ]
        completion_payload.pop("build_log", None)
        if unittest_state_patch:
            completion_payload.update(unittest_state_patch)
        await ws_manager.send_complete(task_id, completion_payload)

    except asyncio.CancelledError:
        logger.warning("Driver task {} cancelled; finalizing execution report", task_id)
        if not runtime_cleaned:
            await _cleanup_driver_runtime_state(
                task_id,
                callbacks,
                _schedule_progress_persist,
                token_task,
                progress_tasks,
            )
            runtime_cleaned = True
        report_artifact = _build_driver_execution_report(
            task_id=task_id,
            context=context,
            result_data=result_data,
            status="cancelled",
            message="Task cancelled by user",
            started_at=started_at,
        )
        await _handle_driver_task_cancelled(
            task_id,
            session_id,
            context,
            async_session_factory,
            report_artifact,
        )
        raise

    except Exception as exc:
        logger.opt(exception=True).error("Driver generation task {} failed: {}", task_id, exc)
        token_state = _driver_token_usage_state(
            agent,
            base_token_usage,
            terminal=True,
            reported_token_usage=result_data.get("token_usage"),
        )
        result_data.update(token_state)
        if not runtime_cleaned:
            await _cleanup_driver_runtime_state(
                task_id,
                callbacks,
                _schedule_progress_persist,
                token_task,
                progress_tasks,
            )
            runtime_cleaned = True
        report_artifact = _build_driver_execution_report(
            task_id=task_id,
            context=context,
            result_data=result_data,
            status="failed",
            message=str(exc),
            started_at=started_at,
        )
        await _persist_failed_driver_result(
            task_id,
            session_id,
            context,
            str(exc),
            async_session_factory,
            token_state["token_usage"],
            report_artifact,
        )
        await ws_manager.send_error(task_id, str(exc))
    finally:
        if not runtime_cleaned:
            await _cleanup_driver_runtime_state(
                task_id,
                callbacks,
                _schedule_progress_persist,
                token_task,
                progress_tasks,
            )




async def _check_driver_mcp_before_ingestion(task_id: str) -> dict[str, Any]:
    try:
        diagnostics = await asyncio.to_thread(check_driver_mcp)
    except Exception as exc:
        logger.exception("Driver MCP pre-ingestion check could not run")
        diagnostics = {
            "preflight": {"status": "failed", "error": f"{type(exc).__name__}: {exc}"},
            "stderr": "",
        }
    if diagnostics["preflight"]["status"] != "connected":
        logger.error("Driver MCP pre-ingestion check failed: {}", diagnostics)
        record = {
            "attempt": 0, "stage": "runtime_preflight", "status": "error",
            "failure_category": "cli_mcp_unavailable",
            "mcp_startup_diagnostics": diagnostics,
        }
        try:
            output_dir = _resolve_driver_output_dir(task_id, {})
            output_dir.mkdir(parents=True, exist_ok=True)
            (output_dir / "cli-diagnostics.json").write_text(
                json.dumps([record], ensure_ascii=False, indent=2), encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Cannot save pre-ingestion MCP diagnostics: {}", exc)
    return diagnostics


@router.post("/driver/generate", status_code=201)
async def generate_driver_full(
    request: DriverGenerateRequest,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Full driver generation pipeline: source context + module config → code artifacts."""
    current_user = get_optional_user(raw_request, response)
    await enforce_billing(current_user)
    llm_bridge = raw_request.app.state.llm_bridge
    mcp_client = raw_request.app.state.mcp_client

    # Map module config to DriverContext fields
    module = request.module_config
    _interface_map = {
        "usb": "usb", "gpio": "gpio", "uart": "uart", "spi": "spi",
        "i2c": "i2c", "can": "can", "pwm": "pwm", "adc": "adc",
        "led": "gpio", "other": "gpio",
    }
    interface = _interface_map.get((module.interface or module.module_type or "gpio").lower(), "gpio")
    device_name = (module.device_name or module.module_name or "Device").strip()
    device_type = module.device_type or "peripheral"
    # ``platform`` and ``mcu_family`` were optional in the original request
    # contract.  Keep accepting replayed/stored legacy requests while making
    # the new build default explicit for callers that omit the platform.  A
    # caller that supplies either value still gets the same validation and
    # normalization semantics as before.
    requested_platform = (module.platform or "").strip()
    platform = requested_platform or DEFAULT_DRIVER_BUILD_PLATFORM
    mcu_family = (module.mcu_family or "").strip()
    if not requested_platform or not mcu_family:
        logger.warning(
            "[driver.generate] Legacy module_config omitted platform/mcu_family; "
            "using platform={} and an empty MCU family",
            platform,
        )

    # Create conversation session + task for polling
    repo = _get_driver_repo(db, current_user["id"])
    client_task_id = getattr(request, "task_id", None)
    if client_task_id:
        existing_task = await repo.get_task(client_task_id)
        if existing_task is not None:
            if response is not None:
                response.status_code = 200
            return {
                "task_id": existing_task.id,
                "session_id": existing_task.session_id,
                "status": existing_task.status,
                "message": "Driver task already exists",
            }
        if await db.get(DriverAgentTask, client_task_id) is not None:
            raise HTTPException(status_code=409, detail="Driver task ID is already in use")

    session = await repo.create_session(
        user_id=current_user["id"],
        title=f"Driver: {device_name} ({interface})",
    )
    try:
        drv_task = await repo.create_task(
            session_id=session.id,
            target_file=f"drv_{device_name.lower().replace(' ', '_')}.h",
            task_id=client_task_id,
        )
    except IntegrityError:
        # Two browser retries can pass the pre-check concurrently. Roll back
        # the new session, then resolve the winner without returning SQLite's
        # primary-key exception as a 500 response.
        await db.rollback()
        if client_task_id:
            existing_task = await repo.get_task(client_task_id)
            if existing_task is not None:
                if response is not None:
                    response.status_code = 200
                return {
                    "task_id": existing_task.id,
                    "session_id": existing_task.session_id,
                    "status": existing_task.status,
                    "message": "Driver task already exists",
                }
            if await db.get(DriverAgentTask, client_task_id) is not None:
                raise HTTPException(status_code=409, detail="Driver task ID is already in use")
        raise
    _task_owners[drv_task.id] = current_user["id"]

    # Enable task logging before source ingestion so Docling parse logs are
    # included in logs/task_{task_id}.log, not only the later agent phase.
    LoggerService.add_task_sink(drv_task.id)
    logger.info(f"[driver.generate] Task log enabled before source ingestion: {drv_task.id}")

    def _remove_task_log_sink_before_background() -> None:
        """Remove early task log sink when generation aborts before background task starts."""
        _task_owners.pop(drv_task.id, None)
        LoggerService.remove_task_sink(drv_task.id)

    await repo.update_task_state(
        drv_task.id,
        status="running",
        current_step="runtime_preflight",
        patch={
            "progress": 0,
            "token_usage": TokenUsageAccumulator.merge(),
            "token_usage_status": TOKEN_USAGE_STATUS_PENDING,
            "token_usage_message": "Waiting for the provider to report token usage.",
        },
    )

    # Publish the task before source ingestion starts. Docling parsing
    # can take minutes; polling requests use independent database sessions and
    # cannot see rows that have only been flushed in this transaction.
    await db.commit()

    try:
        await ws_manager.send_progress(
            drv_task.id, progress=0, stage="runtime_preflight",
            message="Checking driver file tools before source ingestion",
        )
        diagnostics = await _check_driver_mcp_before_ingestion(drv_task.id)
        from app.utils.claude_cli_monitor import is_task_cancelled

        if is_task_cancelled(drv_task.id):
            raise asyncio.CancelledError()
    except asyncio.CancelledError:
        await repo.update_task_state(
            drv_task.id, status="cancelled", current_step="cancelled",
        )
        await db.commit()
        _remove_task_log_sink_before_background()
        raise HTTPException(status_code=499, detail=f"Task {drv_task.id} cancelled by user")

    if diagnostics["preflight"]["status"] != "connected":
        message = (
            "Driver file tools are unavailable. No documents or model requests "
            "were processed. Check cli-diagnostics.json and the MCP runtime."
        )
        await repo.update_task_state(
            drv_task.id, status="failed", current_step="runtime_preflight",
            last_error=message, patch={"failure_category": "cli_mcp_unavailable"},
        )
        await db.commit()
        _remove_task_log_sink_before_background()
        raise HTTPException(status_code=503, detail={
            "error_code": "DRIVER_MCP_UNAVAILABLE", "message": message,
            "task_id": drv_task.id,
        })

    await repo.update_task_state(drv_task.id, status="running", current_step="ingest_sources")
    await db.commit()

    # Immediately notify frontend of the real task_id via WebSocket
    await ws_manager.send_progress(
        drv_task.id,
        progress=0,
        stage="ingest_sources",
        message="Task created, starting source ingestion"
    )

    # Fetch uploaded source content from DB
    source_contents: list[dict[str, Any]] = []
    source_ids = list((request.source_ids or [])[:MAX_FILES_PER_UPLOAD])
    source_total = len(source_ids)

    async def _publish_ingestion_progress(
        source_index: int,
        source_name: str,
        message: str,
        docling_progress: dict | None = None,
    ) -> None:
        """Publish observable progress while a source may be in Docling."""
        if not source_total:
            return
        progress = min(10, max(1, round(source_index / source_total * 10)))
        details = {
            "source_index": source_index,
            "source_total": source_total,
            "source_name": source_name,
        }
        if docling_progress is not None:
            details["docling_runtime"] = docling_progress
        await repo.update_task_state(
            drv_task.id,
            status="running",
            current_step="ingest_sources",
            patch={
                "progress": progress,
                "message": message,
                "backend_stage": "ingest_sources",
                "stage_confirmed": True,
                "stage_source": "driver_source_ingestion",
                "details": details,
            },
        )
        await db.commit()
        await ws_manager.send_progress(
            drv_task.id,
            progress=progress,
            stage="ingest_sources",
            message=message,
            details=details,
        )

    missing_source_ids: list[str] = []
    unavailable_source_ids: list[str] = []
    failed_source_ids: list[str] = []
    docling_runtime_unavailable = False
    docling_model_artifacts_missing = False
    knowledge_base_source_count = 0
    reference_source_count = 0
    request_output_options = request.output_options.model_dump(exclude_none=True) if request.output_options else {}
    driver_output_options = request_output_options
    logger.info(f"[driver.generate] Received source_ids: {request.source_ids}")
    if request.source_ids:
        async def _publish_docling_progress(snapshot: dict) -> None:
            await _publish_ingestion_progress(
                source_index, src_record.name,
                f"{snapshot['message']} ({snapshot['elapsed_seconds']:.0f}s)",
                docling_progress=snapshot,
            )

        docling_service = DriverDoclingService()
        source_service = DriverSourceService(
            repo,
            docling_service,
            progress_callback=_publish_docling_progress,
        )
        logger.info(f"[driver.generate] Fetching content for {source_total} source(s)")
        for source_index, sid in enumerate(source_ids, start=1):
            # Browser refreshes disconnect the original HTTP request. The task
            # is already persisted with a frontend-provided id, so refresh must
            # resume by polling instead of being treated as cancellation.

            # Check cancellation before processing each source
            from app.utils.claude_cli_monitor import is_task_cancelled
            if is_task_cancelled(drv_task.id):
                logger.warning(f"🛑 [driver.generate] Task {drv_task.id} cancelled during source loading, aborting")
                await repo.update_task_state(
                    drv_task.id,
                    status="cancelled",
                    current_step="cancelled",
                    patch={"progress": 0},
                )
                await db.commit()  # Commit before raising to persist cancelled status
                _remove_task_log_sink_before_background()
                raise HTTPException(status_code=499, detail=f"Task {drv_task.id} cancelled by user")

            try:
                await _publish_ingestion_progress(
                    source_index,
                    sid,
                    f"Parsing source {source_index}/{source_total}",
                )
                src_record = await repo.get_source(sid)
                if src_record is None:
                    missing_source_ids.append(sid)
                    logger.warning(f"[driver.generate] Source {sid} not found for current user")
                    await _publish_ingestion_progress(
                        source_index,
                        sid,
                        f"Source {source_index}/{source_total} unavailable",
                    )
                    continue

                is_knowledge_base_source = src_record.source_type == DriverSourceType.KNOWLEDGE_BASE.value
                if is_knowledge_base_source:
                    knowledge_base_source_count += 1
                elif src_record.source_type == DriverSourceType.REFERENCE.value:
                    reference_source_count += 1

                content = await source_service.get_source_content(
                    sid,
                    task_id=drv_task.id,
                    force_reparse=False,
                )
                try:
                    source_metadata = json.loads(src_record.extra_metadata or "{}")
                except (TypeError, ValueError):
                    source_metadata = {}
                knowledge_index = (
                    source_metadata.get("knowledge_index")
                    if isinstance(source_metadata, dict)
                    else None
                )
                source_file_path = await source_service.get_source_file_path(src_record)
                if content:
                    source_entry = {
                        "name": src_record.name,
                        "content": content,
                        "source_type": src_record.source_type,
                    }
                    if source_file_path is not None:
                        source_entry["saved_path"] = str(source_file_path)
                    parsed_path = source_service.find_knowledge_base_markdown(
                        src_record.id, src_record.name,
                    )
                    if parsed_path is not None:
                        source_entry["parsed_path"] = str(parsed_path.resolve())
                    if isinstance(knowledge_index, dict):
                        document_id = str(knowledge_index.get("document_id") or "").strip()
                        if document_id:
                            source_entry["knowledge_document_id"] = document_id
                        source_entry["knowledge_index"] = knowledge_index
                    source_contents.append(source_entry)
                    logger.info(f"[driver.generate] Loaded source {sid}: {src_record.name} ({len(content)} chars)")
                elif source_file_path is None:
                    unavailable_source_ids.append(sid)
                    logger.warning(f"[driver.generate] Source file {sid} is unavailable")
                else:
                    failed_source_ids.append(sid)
                    if isinstance(source_metadata, dict):
                        parse_error = str(source_metadata.get("parse_error") or "")
                        docling_runtime_unavailable |= (
                            parse_error == "DOCLING_RUNTIME_UNAVAILABLE"
                        )
                        docling_model_artifacts_missing |= (
                            "Docling local model artifacts are incomplete" in parse_error
                        )
                    logger.warning(f"[driver.generate] Source {sid} is empty or failed to parse")
                await _publish_ingestion_progress(
                    source_index,
                    src_record.name,
                    f"Source {source_index}/{source_total} loaded",
                )
            except asyncio.CancelledError as cancel_err:
                # Parsing was cancelled by user, stop entire pipeline
                logger.warning(f"🛑 [driver.generate] {cancel_err}, stopping source loading and aborting task")
                await repo.update_task_state(
                    drv_task.id,
                    status="cancelled",
                    current_step="cancelled",
                    patch={"progress": 0},
                )
                await db.commit()  # Commit before raising to persist cancelled status
                _remove_task_log_sink_before_background()
                raise HTTPException(status_code=499, detail=f"Task {drv_task.id} cancelled by user")
            except Exception as exc:
                unavailable_source_ids.append(sid)
                logger.warning(f"Could not load source {sid}: {exc}")

    logger.info(
        f"[driver.generate] Total source_contents loaded: {len(source_contents)} "
        f"(knowledge_base={knowledge_base_source_count}, reference={reference_source_count})"
    )
    if missing_source_ids or unavailable_source_ids or failed_source_ids:
        error_parts = []
        if missing_source_ids:
            error_parts.append(
                "not found for the current browser session: "
                + ", ".join(missing_source_ids)
            )
        if unavailable_source_ids:
            error_parts.append(
                "file is missing from the active installation: "
                + ", ".join(unavailable_source_ids)
            )
        if failed_source_ids:
            error_parts.append(
                "failed to parse: " + ", ".join(failed_source_ids)
            )
        error_detail = "Unable to load driver source files; " + "; ".join(error_parts)
        if docling_runtime_unavailable:
            error_detail += (
                ". Docling/OCR runtime dependencies do not match this release. "
                "Check /health and synchronize the backend runtime requirements; "
                "PDF generation is disabled until the dependency check passes."
            )
        if docling_model_artifacts_missing:
            error_detail += (
                ". Local Docling model files are missing. Restore the models directory "
                "or configure DRIVER_DOCLING_ARTIFACTS_PATH to the installed model bundle."
            )
        # Mark task as failed and commit before raising so frontend can query the error
        await repo.update_task_state(
            drv_task.id,
            status="failed",
            current_step="ingest_sources",
            last_error=error_detail,
            patch={"failure_category": (
                "docling_runtime_unavailable" if docling_runtime_unavailable
                else "docling_model_artifacts_missing" if docling_model_artifacts_missing
                else "driver_source_unavailable"
            )},
        )
        await db.commit()
        _remove_task_log_sink_before_background()
        if missing_source_ids:
            raise HTTPException(
                status_code=400,
                detail={
                    "error_code": "DRIVER_SOURCE_SESSION_MISMATCH",
                    "message": error_detail,
                },
            )
        if docling_runtime_unavailable:
            raise HTTPException(status_code=503, detail={
                "error_code": "DOCLING_RUNTIME_UNAVAILABLE", "message": error_detail,
                "task_id": drv_task.id,
            })
        if docling_model_artifacts_missing:
            raise HTTPException(status_code=503, detail={
                "error_code": "DOCLING_MODEL_ARTIFACTS_MISSING", "message": error_detail,
                "task_id": drv_task.id,
            })
        raise HTTPException(status_code=400, detail=error_detail)

    if source_contents:
        try:
            await repo.update_task_state(
                drv_task.id,
                status="running",
                current_step="build_context",
                patch={"progress": 12, "source_count": len(source_contents)},
            )
            await db.commit()
        except asyncio.CancelledError as cancel_err:
            logger.warning(f"🛑 [driver.generate] {cancel_err}, stopping context preparation and aborting task")
            await repo.update_task_state(
                drv_task.id,
                status="cancelled",
                current_step="cancelled",
                patch={"progress": 0},
            )
            await db.commit()
            _remove_task_log_sink_before_background()
            raise HTTPException(status_code=499, detail=f"Task {drv_task.id} cancelled by user")
        except Exception as exc:
            logger.error(f"[driver.generate] Context preparation failed: {exc}")
            await db.refresh(drv_task)
            current_token_usage = await _load_driver_task_token_usage(repo, drv_task.id)
            await repo.update_task_state(
                drv_task.id,
                status="failed",
                current_step="build_context",
                patch=(
                    {"token_usage": current_token_usage}
                    if TokenUsageAccumulator.has_usage(current_token_usage)
                    else None
                ),
                last_error=str(exc),
            )
            await db.commit()
            _remove_task_log_sink_before_background()
            raise HTTPException(status_code=500, detail=f"Context preparation failed: {exc}")

        await db.refresh(drv_task)

    repo_files: list[dict[str, str]] = []
    project_root = None
    logger.info(f"[driver.generate] Received repository_source_id: {request.repository_source_id}")
    if request.repository_source_id:
        repo_service = DriverRepositoryService(repo)
        try:
            repo_source = await repo.get_repository_source(request.repository_source_id)
            repo_files = await repo_service.get_repository_files(request.repository_source_id)
            project_root = repo_source.workspace_path if repo_source else None
            logger.info(
                f"[driver.generate] Loaded repository {request.repository_source_id}: "
                f"{len(repo_files)} file(s), root={project_root}"
            )
        except Exception as exc:
            logger.warning(f"[driver.generate] Could not load repository source {request.repository_source_id}: {exc}")

    pre_agent_token_usage = await _load_driver_task_token_usage(repo, drv_task.id)
    if TokenUsageAccumulator.has_usage(pre_agent_token_usage):
        logger.info(
            "[driver.generate] Pre-agent token usage baseline: "
            "task_id={}, input={}, output={}, cache_write={}, cache_read={}, total={}",
            drv_task.id,
            pre_agent_token_usage["input_tokens"],
            pre_agent_token_usage["output_tokens"],
            pre_agent_token_usage["cache_creation_input_tokens"],
            pre_agent_token_usage["cache_read_input_tokens"],
            pre_agent_token_usage["total_tokens"],
        )

    registers = [r.model_dump() for r in (request.registers or [])]
    context = DriverContext(
        task_id=drv_task.id,
        session_id=session.id,
        user_id=current_user["id"],
        device_name=device_name,
        device_type=device_type,
        interface=interface,
        mcu_family=mcu_family,
        platform=platform,
        registers=registers,
        prompt=request.prompt,
        source_ids=request.source_ids or [],
        source_contents=source_contents,
        repository_source_id=request.repository_source_id,
        repo_files=repo_files,
        output_options=driver_output_options,
        module_config=module.model_dump(),
        project_root=project_root,
    )
    logger.info(
        f"[driver.generate] DriverContext created with "
        f"{len(source_contents)} source docs and {len(repo_files)} repo files"
    )

    task_desc = f"Generate {interface} driver for {device_name}: {request.prompt}"
    agent = DriverAgent(
        llm_bridge,
        mcp_client,
        skill_registry=getattr(raw_request.app.state, "skill_registry", None),
    )
    logger.info(f"[driver.generate] Starting background task for {device_name} ({interface})")

    # Make the session/task/source updates visible to the background task's
    # independent DB sessions before it starts emitting progress.
    await db.commit()

    # Final check: if user cancelled during PDF parsing or context building, abort here
    from app.utils.claude_cli_monitor import is_task_cancelled
    if is_task_cancelled(drv_task.id):
        logger.warning(f"🛑 [driver.generate] Task {drv_task.id} was cancelled before starting background task, aborting")
        await repo.update_task_state(
            drv_task.id,
            status="cancelled",
            current_step="cancelled",
            patch={"progress": 0},
        )
        _remove_task_log_sink_before_background()
        return {
            "task_id": drv_task.id,
            "session_id": session.id,
            "status": "cancelled",
            "message": f"Task cancelled by user before execution started",
        }

    # Create and register the background task
    background_task = asyncio.create_task(
        _run_driver_generation_task(
            drv_task.id,
            session.id,
            agent,
            task_desc,
            context,
            base_token_usage=pre_agent_token_usage,
            started_at=drv_task.created_at,
        )
    )
    _active_tasks[drv_task.id] = background_task
    _active_agents[drv_task.id] = agent

    return {
        "task_id": drv_task.id,
        "session_id": session.id,
        "status": "running",
        "message": f"Driver generation started for {device_name} ({interface})",
    }


# ==================== Source Upload ====================


@router.post("/driver/sources/upload", status_code=201)
async def upload_driver_sources(
    raw_request: Request,
    files: list[UploadFile] = File(...),
    source_type: str = Form(...),
    task_id: str | None = Form(default=None),
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Upload knowledge base or reference files for driver generation."""
    current_user = get_optional_user(raw_request, response)
    if source_type not in VALID_DRIVER_SOURCE_TYPES:
        raise HTTPException(status_code=422, detail="source_type must be knowledge_base or reference")

    if len(files) > MAX_FILES_PER_UPLOAD:
        raise HTTPException(
            status_code=400,
            detail=f"Maximum {MAX_FILES_PER_UPLOAD} files per upload",
        )

    repo = _get_driver_repo(db, current_user["id"])
    docling_service = DriverDoclingService()
    source_service = DriverSourceService(repo, docling_service)

    sources = []
    for upload_file in files:
        file_content = await upload_file.read()
        try:
            result = await source_service.upload_and_parse(
                user_id=current_user["id"],
                source_type=source_type,
                filename=upload_file.filename or "unknown",
                file_content=file_content,
            )
            sources.append(DriverSourceResponse(
                source_id=result["source_id"],
                source_type=result["source_type"],
                name=result["name"],
                size=result["size"],
                extension=result["extension"],
                mime_type=result.get("mime_type"),
                upload_status=result["upload_status"],
                parse_status=result["parse_status"],
                parsed_summary=result.get("parsed_summary"),
                extra_metadata=result.get("extra_metadata"),
                created_at=result["created_at"],
            ))
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    await db.commit()
    return DriverSourcesUploadResponse(sources=sources)


@router.get("/driver/sources/{source_id}")
async def get_driver_source(
    source_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get driver source file status."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    source = await repo.get_source(source_id)
    if source is None:
        raise HTTPException(status_code=404, detail="Driver source not found")

    source_metadata = None
    if source.extra_metadata:
        try:
            source_metadata = json.loads(source.extra_metadata)
        except json.JSONDecodeError:
            source_metadata = {"raw": source.extra_metadata}

    return DriverSourceResponse(
        source_id=source.id,
        source_type=source.source_type,
        name=source.name,
        size=source.size,
        extension=source.extension,
        mime_type=source.mime_type,
        upload_status=source.upload_status,
        parse_status=source.parse_status,
        parsed_summary=source.parsed_summary,
        extra_metadata=source_metadata,
        created_at=source.created_at,
    )


@router.delete("/driver/sources/{source_id}")
async def delete_driver_source(
    source_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Delete a driver source file."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    docling_service = DriverDoclingService()
    source_service = DriverSourceService(repo, docling_service)

    deleted = await source_service.delete_source(source_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Driver source not found")

    return {"source_id": source_id, "deleted": True}


# ==================== Repository Fetch ====================


@router.post("/driver/repository/fetch", status_code=202)
async def fetch_driver_repository(
    request: DriverRepositoryFetchRequest,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Fetch a remote git repository for driver context."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    repo_service = DriverRepositoryService(repo)

    # Extract auth token (runtime only, not persisted)
    auth_token = None
    if request.auth and request.auth.get("method") == "token":
        auth_token = request.auth.get("token")

    try:
        result = await repo_service.fetch_repository(
            user_id=current_user["id"],
            repository_url=request.repository_url,
            branch=request.branch,
            selected_paths=request.selected_paths,
            auth_token=auth_token,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return DriverRepositorySourceResponse(
        repository_source_id=result["repository_source_id"],
        repository_url=result["repository_url"],
        branch=result.get("branch"),
        included_paths=result.get("included_paths"),
        file_count=result.get("file_count", 0),
        status=result["status"],
        created_at=result["created_at"],
    )


@router.get("/driver/repository/{source_id}")
async def get_driver_repository(
    source_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get repository source status."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    repo_source = await repo.get_repository_source(source_id)
    if repo_source is None:
        raise HTTPException(status_code=404, detail="Repository source not found")

    included_paths = json.loads(repo_source.selected_paths) if repo_source.selected_paths else None

    return DriverRepositorySourceResponse(
        repository_source_id=repo_source.id,
        repository_url=repo_source.repository_url,
        branch=repo_source.branch,
        included_paths=included_paths,
        file_count=repo_source.file_count,
        status=repo_source.fetch_status,
        created_at=repo_source.created_at,
    )


# ==================== Artifacts ====================


@router.get("/driver/tasks/{task_id}/artifacts")
async def get_driver_artifacts(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get generated artifacts for a driver task."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    task = await repo.get_readable_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    artifacts = await repo.list_artifacts(task_id)
    visible_artifacts = [
        artifact for artifact in artifacts if not _is_hidden_driver_artifact(artifact)
    ]

    # Get task to extract output_dir from state_data
    output_dir = None
    if task and task.state_data:
        try:
            state_data = json.loads(task.state_data) if isinstance(task.state_data, str) else task.state_data
            output_dir = state_data.get("output_dir") if isinstance(state_data, dict) else None
        except json.JSONDecodeError:
            output_dir = None

    return DriverArtifactsResponse(
        task_id=task_id,
        artifacts=[
            DriverArtifactResponse(
                artifact_id=a.id,
                task_id=a.task_id,
                name=a.name,
                artifact_type=a.artifact_type,
                language=a.language,
                content=a.content,
                size=a.size,
                created_at=a.created_at,
            )
            for a in visible_artifacts
        ],
        output_dir=output_dir,
    )


# ==================== Multi-Turn Chat ====================


@router.post("/driver/chat")
async def driver_chat(
    request: DriverChatRequest,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Multi-turn conversation with the driver agent."""
    current_user = get_optional_user(raw_request, response)
    llm_bridge = raw_request.app.state.llm_bridge
    mcp_client = raw_request.app.state.mcp_client

    repo = _get_driver_repo(db, current_user["id"])
    context_builder = DriverContextBuilder(repo)

    # Get or create session
    if request.session_id:
        session = await repo.get_session(request.session_id)
        if session is None:
            raise HTTPException(status_code=404, detail="Session not found")
    else:
        session = await repo.create_session(
            user_id=current_user["id"],
            title=request.message[:50],
        )

    # Save user message
    await repo.append_message(session.id, "user", request.message)

    # Get or create task
    task = None
    if request.task_id:
        task = await repo.get_task(request.task_id)
        if task is not None and task.session_id != session.id:
            raise HTTPException(status_code=404, detail="Task not found in session")
    if task is None:
        task = await repo.get_active_task(session.id)
    if task is None:
        task = await repo.create_task(
            session_id=session.id,
            target_file=request.target_file,
            project_root=request.project_root,
        )

    # Build context and generate response
    context_messages = await context_builder.build_context(session.id, task.id)

    agent = DriverAgent(
        llm_bridge,
        mcp_client,
        skill_registry=getattr(raw_request.app.state, "skill_registry", None),
    )
    reply = await agent.chat(
        messages=[{"role": m["role"], "content": m["content"]} for m in context_messages[1:]],  # skip system
        task_context=context_messages[0]["content"] if context_messages else "",
    )

    # Save assistant message
    await repo.append_message(session.id, "assistant", reply)

    # Build task state response
    state_data = _driver_state_data(task)
    task_state = DriverAgentTaskStateResponse(
        id=task.id,
        session_id=task.session_id,
        status=task.status,
        current_step=task.current_step,
        target_file=task.target_file,
        test_file=task.test_file,
        project_root=task.project_root,
        build_command=task.build_command,
        retry_count=task.retry_count,
        max_retries=task.max_retries,
        last_error=task.last_error,
        state_data=state_data,
        created_at=task.created_at,
        updated_at=task.updated_at,
    )

    return DriverAgentChatResponse(
        session_id=session.id,
        task_id=task.id,
        reply=reply,
        task_state=task_state,
    )


@router.get("/driver/sessions/{session_id}")
async def get_driver_session(
    session_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get driver agent session details."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    session = await repo.get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    return DriverAgentSessionResponse(
        id=session.id,
        user_id=session.user_id,
        title=session.title,
        agent_type=session.agent_type,
        status=session.status,
        created_at=session.created_at,
        updated_at=session.updated_at,
    )


@router.get("/driver/sessions/{session_id}/messages")
async def get_driver_session_messages(
    session_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get messages for a driver agent session."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    session = await repo.get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    messages = await repo.list_messages(session_id)

    return DriverAgentMessagesResponse(
        session_id=session_id,
        messages=[
            {
                "id": m.id,
                "session_id": m.session_id,
                "role": m.role,
                "content": m.content,
                "message_metadata": json.loads(m.message_metadata) if m.message_metadata else None,
                "created_at": m.created_at,
            }
            for m in messages
        ],
    )


@router.get("/driver/tasks/{task_id}")
async def get_driver_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get driver agent task state."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    task = await repo.get_readable_task(task_id)
    if task is None:
        if (
            _is_client_generated_driver_task_id(task_id)
            and _task_owners.get(task_id) == current_user["id"]
        ):
            return _pending_driver_task_response(task_id)
        raise HTTPException(status_code=404, detail="Task not found")

    state_data = _driver_state_data(task)
    current_step, state_data = _merge_active_driver_progress(task_id, task, state_data)

    return DriverAgentTaskStateResponse(
        id=task.id,
        session_id=task.session_id,
        status=task.status,
        current_step=current_step,
        target_file=task.target_file,
        test_file=task.test_file,
        project_root=task.project_root,
        build_command=task.build_command,
        retry_count=task.retry_count,
        max_retries=task.max_retries,
        last_error=task.last_error,
        state_data=state_data,
        created_at=task.created_at,
        updated_at=task.updated_at,
    )


@router.get("/driver/tasks/{task_id}/tool-results")
async def get_driver_tool_results(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Get tool execution results for a driver task."""
    current_user = get_optional_user(raw_request, response)
    repo = _get_driver_repo(db, current_user["id"])
    task = await repo.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    tool_results = await repo.list_tool_results(task_id)

    return DriverAgentToolResultsResponse(
        task_id=task_id,
        tool_results=[
            {
                "id": tr.id,
                "task_id": tr.task_id,
                "session_id": tr.session_id,
                "tool_name": tr.tool_name,
                "input_data": json.loads(tr.input_data) if tr.input_data else None,
                "output_data": json.loads(tr.output_data) if tr.output_data else None,
                "status": tr.status,
                "error_message": tr.error_message,
                "created_at": tr.created_at,
            }
            for tr in tool_results
        ],
    )


@router.post("/driver/tasks/{task_id}/cancel")
async def cancel_driver_task(
    task_id: str,
    raw_request: Request,
    db: AsyncSession = Depends(get_db),
    response: Response = None,
):
    """Cancel a running driver task without overwriting terminal or finalizing work."""
    from app.utils.claude_cli_monitor import (
        force_kill_task_processes,
        kill_cli_by_task_id,
        register_task_cancellation,
    )

    db_update_error = None
    repo = None
    task = None
    current_user = None
    try:
        current_user = get_optional_user(raw_request, response)
        repo = _get_driver_repo(db, current_user["id"])
        task = await repo.get_task(task_id)
    except SQLAlchemyError as exc:
        db_update_error = str(exc)
        logger.warning(
            "Driver task {} cancellation could not read task state before kill: {}",
            task_id,
            exc,
        )
        try:
            await db.rollback()
        except Exception as rollback_exc:
            logger.warning("Rollback before cancelling task {} failed: {}", task_id, rollback_exc)

    if task:
        protection_reason = _driver_cancel_protection_reason(task)
        if protection_reason:
            logger.info(
                "Ignoring cancellation for Driver task {} because {}",
                task_id,
                protection_reason,
            )
            return {
                "task_id": task_id,
                "status": task.status,
                "cancelled": False,
                "ignored": True,
                "reason": protection_reason,
                "killed_processes": 0,
                "cli_killed": False,
                "unittest_cli_killed": False,
                "db_update_error": db_update_error,
            }

    if task is None and (
        current_user is None or _task_owners.get(task_id) != current_user["id"]
    ):
        raise HTTPException(status_code=404, detail="Task not found")

    # Set cancel flags immediately
    register_task_cancellation(task_id)
    register_task_cancellation(f"{task_id}_unittest")

    # Kill registered Claude CLI processes by task PID first. The fallback scan
    # matches an exact task token or inherited task env value
    # so an unrelated process with a coincidental substring is never killed.
    cli_killed = kill_cli_by_task_id(task_id)
    unittest_cli_killed = kill_cli_by_task_id(f"{task_id}_unittest")

    # Force kill ALL related Python processes (docling, retries, etc.).
    kill_result = force_kill_task_processes(task_id)
    unittest_kill = force_kill_task_processes(f"{task_id}_unittest")
    total_killed = (
        kill_result["killed_count"]
        + unittest_kill["killed_count"]
        + int(cli_killed)
        + int(unittest_cli_killed)
    )
    
    # Cancel background task
    background_task = _active_tasks.get(task_id)
    if background_task and not background_task.done():
        background_task.cancel()

    try:
        if task and repo:
            await repo.update_task_state(
                task_id,
                status="cancelled",
                current_step=None,
                last_error="Force killed by user",
            )
            await db.commit()
    except SQLAlchemyError as exc:
        db_update_error = str(exc)
        logger.warning(
            "Driver task {} was cancelled, but persisting cancelled status failed: {}",
            task_id,
            exc,
        )
        try:
            await db.rollback()
        except Exception as rollback_exc:
            logger.warning("Rollback after cancelling task {} failed: {}", task_id, rollback_exc)
    
    return {
        "task_id": task_id,
        "status": "cancelled",
        "cancelled": True,
        "ignored": False,
        "killed_processes": total_killed,
        "cli_killed": cli_killed,
        "unittest_cli_killed": unittest_cli_killed,
        "db_update_error": db_update_error,
    }


# ==================== Build Config ====================


@router.get("/driver/build-platforms")
async def get_driver_build_platforms():
    """Return registered build platforms and implementation availability."""
    return {
        "platforms": [
            {
                "platform": capability.platform,
                "aliases": list(capability.aliases),
                "available": capability.available,
                "executor": capability.executor,
                "build_system": capability.build_system,
                "reason": capability.reason or None,
            }
            for capability in build_executor_registry.capabilities()
        ]
    }


@router.get("/driver/build-config")
async def get_driver_build_config(platform: str | None = None):
    """Get saved driver build configuration."""
    try:
        if _BUILD_CONFIG_PATH.exists():
            with open(_BUILD_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = _normalize_driver_build_config(json.load(f))
        else:
            config = _empty_driver_build_config()

        selected_platform, selected_config = _get_selected_driver_build_config(config, platform)
        editor_path = selected_config.get("editor_path") or selected_config.get("stm32cubeide_path") or ""
        tool_resolution = _get_build_tool_resolution(selected_platform, selected_config)
        return {
            **tool_resolution,
            "platform": selected_platform,
            "selected_platform": selected_platform,
            "editor_path": editor_path,
            "stm32cubeide_path": selected_config.get("stm32cubeide_path") or editor_path,
            "project_path": selected_config.get("project_path", ""),
            "platform_configs": config.get("platform_configs", {}),
            "updated_at": selected_config.get("updated_at") or config.get("updated_at"),
        }
    except Exception as e:
        logger.error(f"Failed to read driver build config: {e}")
        raise HTTPException(status_code=500, detail="Failed to read build config")


@router.post("/driver/build-config")
async def save_driver_build_config(
    platform: str = Form(_DEFAULT_BUILD_PLATFORM),
    editor_path: str = Form(""),
    stm32cubeide_path: str = Form(""),
    project_path: str = Form(""),
):
    """Save driver build configuration."""
    try:
        from datetime import datetime, timezone

        if _BUILD_CONFIG_PATH.exists():
            with open(_BUILD_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = _normalize_driver_build_config(json.load(f))
        else:
            config = _empty_driver_build_config()

        now = datetime.now(timezone.utc).isoformat()
        platform_key = _normalize_build_platform(platform)
        selected_editor_path = editor_path or stm32cubeide_path
        platform_configs = config.setdefault("platform_configs", {})
        platform_configs[platform_key] = {
            "editor_path": selected_editor_path,
            "stm32cubeide_path": stm32cubeide_path or selected_editor_path,
            "project_path": project_path,
            "updated_at": now,
        }
        config["selected_platform"] = platform_key
        config["updated_at"] = now

        stm32_config = platform_configs.get(_DEFAULT_BUILD_PLATFORM, {})
        config["stm32cubeide_path"] = (
            stm32_config.get("stm32cubeide_path") or stm32_config.get("editor_path") or ""
        )
        config["project_path"] = stm32_config.get("project_path", "")

        _BUILD_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(_BUILD_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
        logger.info(f"Saved driver build config for platform: {platform_key}")
        selected_config = platform_configs[platform_key]
        tool_resolution = _get_build_tool_resolution(platform_key, selected_config)
        return {
            **tool_resolution,
            "platform": platform_key,
            "selected_platform": platform_key,
            "editor_path": selected_config["editor_path"],
            "stm32cubeide_path": selected_config["stm32cubeide_path"],
            "project_path": selected_config["project_path"],
            "platform_configs": platform_configs,
            "updated_at": selected_config["updated_at"],
        }
    except Exception as e:
        logger.error(f"Failed to save driver build config: {e}")
        raise HTTPException(status_code=500, detail="Failed to save build config")
