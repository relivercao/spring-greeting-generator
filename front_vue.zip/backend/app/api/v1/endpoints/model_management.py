"""Model catalog management; mutations require an active administrator."""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_admin_user
from app.models.model_catalog import ModelCatalogEntry
from app.schemas.model_management import ModelEntryIn, ModelImportIn
from app.schemas.admin import ModelPricing
from app.services.payment import payment_config_service
from app.services import model_catalog_service as service

router = APIRouter()


@router.get("/models")
async def available_models(db: AsyncSession = Depends(get_db)):
    """Expose only picker metadata; public guest interfaces need no prices."""
    rows = (await db.scalars(select(ModelCatalogEntry).where(
        ModelCatalogEntry.enabled.is_(True),
    ).order_by(ModelCatalogEntry.provider, ModelCatalogEntry.model))).all()
    return {"items": [{key: getattr(row, key) for key in (
        "provider", "model", "display_name", "context_window", "max_output_tokens",
    )} for row in rows]}


admin_router = APIRouter(prefix="/admin/models", dependencies=[Depends(get_current_admin_user)])


@admin_router.get("/defaults")
async def default_pricing(db: AsyncSession = Depends(get_db)):
    return await payment_config_service.get_pricing(db)


@admin_router.put("/defaults")
async def update_default_pricing(body: ModelPricing, db: AsyncSession = Depends(get_db)):
    result = await payment_config_service.update_pricing(db, {"default": body.model_dump()})
    await db.commit()
    return result


@admin_router.post("/discover")
async def discover_models(db: AsyncSession = Depends(get_db)):
    """Add configured model identities without changing their selected models or prices."""
    from app.core.config import AGENT_LLM_IDS, get_settings, resolve_agent_llm_selection
    settings = get_settings()
    pairs = {(selection.provider, selection.model) for selection in (
        resolve_agent_llm_selection(agent, settings) for agent in AGENT_LLM_IDS
    ) if selection.model}
    entries = [ModelEntryIn(provider=provider, model=model, display_name=model,
                            source="Configured model").model_dump() for provider, model in sorted(pairs)]
    result = await service.import_models(db, ModelImportIn(format="catalog", entries=entries))
    await db.commit()
    return result


@admin_router.get("")
async def list_models(keyword: str = Query("", max_length=200), db: AsyncSession = Depends(get_db)):
    query = select(ModelCatalogEntry).order_by(ModelCatalogEntry.provider, ModelCatalogEntry.model)
    if keyword:
        query = query.where(or_(ModelCatalogEntry.model.contains(keyword),
                                ModelCatalogEntry.display_name.contains(keyword),
                                ModelCatalogEntry.provider.contains(keyword)))
    rows = (await db.scalars(query)).all()
    return {"items": [service.serialize_model(row) for row in rows]}


@admin_router.post("", status_code=201)
async def create_model(body: ModelEntryIn, db: AsyncSession = Depends(get_db)):
    try:
        row = await service.save_model(db, body)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, "This provider/model pair already exists")
    return service.serialize_model(row)


@admin_router.post("/import")
async def import_models(body: ModelImportIn, db: AsyncSession = Depends(get_db)):
    try:
        result = await service.import_models(db, body)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, "Catalog changed during import. Refresh and retry")
    return result


@admin_router.put("/{entry_id}")
async def update_model(entry_id: str, body: ModelEntryIn, db: AsyncSession = Depends(get_db)):
    entry = await db.get(ModelCatalogEntry, entry_id)
    if entry is None:
        raise HTTPException(404, "Model not found")
    try:
        row = await service.save_model(db, body, entry)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(409, "This provider/model pair already exists")
    return service.serialize_model(row)


@admin_router.delete("/{entry_id}", status_code=204)
async def delete_model(entry_id: str, db: AsyncSession = Depends(get_db)):
    entry = await db.get(ModelCatalogEntry, entry_id)
    if entry is None:
        raise HTTPException(404, "Model not found")
    await db.delete(entry)
    await db.commit()
