"""Explicit adapters from normalized event data into existing Agent contexts."""

import json
import re
from dataclasses import dataclass

from app.agents.base import AgentContext
from app.agents.catalog import AGENT_REGISTRY
from app.schemas.agent_event import EventInput


DIRECT_AGENTS = {"chat", "knowledge", "debug", "review", "bugfix", "cad", "agent_generator"}
WORKSPACE_ROUTES = {"chat": "/chat", "knowledge": "/knowledge", "review": "/mcu-review", "bugfix": "/bugfix",
                    "cad": "/cad", "agent_generator": "/agent-generator", "unittest": "/unittest",
                    "driver": "/driver", "build": "/chat", "debug": "/chat", "image_generation": "/image-generation"}
WORKSPACE_REQUIREMENTS = {
    "unittest": "Open UnitTest to supply source files and configure the isolated build and coverage target.",
    "driver": "Open Driver to bind device evidence, target project, and build configuration.",
    "build": "Open the build workflow to authorize a project and toolchain. Events cannot supply server filesystem paths.",
    "image_generation": "Open Image Generation to choose provider options and confirm image generation inputs.",
}


def catalog() -> list[dict]:
    return [{**agent, "event_execution": "direct" if agent["id"] in DIRECT_AGENTS else "workspace",
             "workspace": WORKSPACE_ROUTES[agent["id"]],
             "requirements": WORKSPACE_REQUIREMENTS.get(agent["id"], "Inline source content is required." if agent["id"] in {"review", "bugfix"} else "Text input is supported.")}
            for agent in AGENT_REGISTRY]


def inline_sources(event: EventInput) -> dict[str, str]:
    if event.data.source_contents:
        return event.data.source_contents
    # Feishu private text can carry inline code; never treat fenced filenames as server paths.
    blocks = re.findall(r"```(?:c|cpp|c\+\+|h|python|py|javascript|js)?[^\S\n]*\n(.*?)```", event.text, re.DOTALL | re.IGNORECASE)
    return {f"snippet_{index + 1}.c": code for index, code in enumerate(blocks[:20]) if code.strip()}


def missing_inputs(agent: str, event: EventInput) -> list[str]:
    if agent not in DIRECT_AGENTS:
        return [WORKSPACE_REQUIREMENTS.get(agent, "No event execution adapter is registered for this Agent.")]
    if agent in {"review", "bugfix"} and not inline_sources(event):
        return ["Provide data.source_contents or a fenced code block. Filesystem paths and repository names alone are insufficient."]
    if agent == "cad" and len(event.text) > 12000:
        return ["CAD model descriptions must not exceed 12000 characters."]
    return []


@dataclass
class PreparedAgent:
    agent: object
    context: AgentContext


def prepare_agent(app, user_id, event: EventInput, agent: str, task_id: str, session_id: str, history, sessions) -> PreparedAgent:
    from app.agents.impl import ChatAgent, DebugAgent, ReviewAgent, BugFixAgent, CadAgent, KnowledgeBaseAgent, AgentGeneratorAgent
    from app.agents.impl.chat.types import ChatContext
    from app.agents.impl.debug.types import DebugContext
    from app.agents.impl.review.types import ReviewContext
    from app.agents.impl.bugfix.types import BugFixContext
    from app.agents.impl.cad.types import CadContext
    from app.agents.impl.agent_generator.types import AgentGeneratorContext
    from app.mcp.servers.connected_apps_server import ConnectedAppsMCPServer
    from app.services.feishu_tools import FeishuBotTools

    llm, mcp, skills = app.state.llm_bridge, app.state.mcp_client, getattr(app.state, "skill_registry", None)
    common = {"task_id": task_id, "session_id": session_id, "user_id": user_id}
    if agent == "chat":
        server = ConnectedAppsMCPServer(user_id, feishu_tools=FeishuBotTools(user_id, sessions))
        return PreparedAgent(ChatAgent(llm, mcp, skills, connected_apps=server),
                             ChatContext(**common, message=event.text, history=history, enable_web_search=False))
    if agent == "debug":
        return PreparedAgent(DebugAgent(llm, mcp, skills), DebugContext(**common,
            crash_description=event.text, crash_log=event.data.crash_log or None,
            stack_trace=event.data.stack_trace or None, register_dump=event.data.register_dump or None))
    if agent == "review":
        return PreparedAgent(ReviewAgent(llm, mcp, skills), ReviewContext(**common,
            source_contents=inline_sources(event), focus=event.text))
    if agent == "bugfix":
        return PreparedAgent(BugFixAgent(llm, mcp, skills), BugFixContext(**common,
            bug_description=event.text, source_contents=inline_sources(event)))
    if agent == "cad":
        return PreparedAgent(CadAgent(llm, skills), CadContext(**common, prompt=event.text, auto_build=False))
    if agent == "knowledge":
        return PreparedAgent(KnowledgeBaseAgent(llm_bridge=llm, skill_registry=skills),
                             AgentContext(**common, metadata={"chip": event.data.chip or None}))
    if agent == "agent_generator":
        return PreparedAgent(AgentGeneratorAgent(llm, skills), AgentGeneratorContext(**common, prompt=event.text))
    raise ValueError("No event execution adapter is registered for this Agent.")


def response_text(result) -> str:
    data = result.data or {}
    for key in ("response", "report_markdown", "evidence_summary", "system_prompt"):
        value = data.get(key) or getattr(result, key, None)
        if isinstance(value, str) and value.strip():
            return value
    if data.get("model_code"):
        return f"{result.message}\n\n```python\n{data['model_code']}\n```\n\nCAD script generated. Build and export require confirmation in the CAD workspace."
    from app.services.agent_task_runtime import serialize_agent_result
    return result.message + "\n\n" + json.dumps(serialize_agent_result(result), ensure_ascii=True, indent=2)
