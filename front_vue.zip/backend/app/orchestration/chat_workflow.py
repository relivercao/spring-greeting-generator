"""
@file chat_workflow.py
@author caoshwen
@brief ChatOrchestratorWorkflow - 4-node pipeline: route, execute, format, persist.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Optional

from fastapi import HTTPException
from loguru import logger

from app.agents.base import (
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ProgressUpdate,
)
from app.agents.impl.chat_agent import ChatContext
from app.core.config import resolve_agent_llm_selection
from app.core.ws_manager import ws_manager
from app.infrastructure.cache.session_manager import SessionManager
from app.llm.bridge import LLMBridge
from app.services.chat_attachments import attachment_message, persisted_attachment_message
from app.llm.error_mapping import (
    http_exception_for_agent_result,
    http_exception_for_llm_error,
)
from app.orchestration.chat_router import ChatRouter, RouteResult


@dataclass
class WorkflowState:
    """Workflow state"""
    # Input
    message: str = ""
    session_id: str = ""
    user_id: str = ""
    agent_hint: Optional[str] = None  # Agent type specified by frontend
    history: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)  # Additional context (files, etc.)
    web_search_enabled: bool = True

    # Routing stage
    route_result: Optional[RouteResult] = None

    # Execution stage
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_result: Optional[AgentResult] = None

    # Formatting stage
    formatted_response: str = ""
    response_metadata: dict[str, Any] = field(default_factory=dict)

    # Error
    error: Optional[str] = None


class ChatOrchestratorWorkflow:
    """
    Chat orchestration workflow - first layer orchestration.

    Responsibilities:
    - Receive user messages
    - Route to appropriate Agent via ChatRouter
    - Execute simple tasks directly, escalate complex tasks to MasterAgent
    - Format responses and persist

    Usage:
        workflow = ChatOrchestratorWorkflow(
            llm_bridge=llm_bridge,
            session_manager=session_manager,
            agents={"chat": chat_agent, "unittest": unittest_agent, ...},
        )
        result = await workflow.run(message="Generate GPIO driver", session_id="xxx", user_id="yyy")
    """

    def __init__(
        self,
        llm_bridge: LLMBridge,
        session_manager: SessionManager,
        agents: dict[str, BaseAgent],
        master_agent: Optional["MasterAgent"] = None,
    ):
        self._llm = llm_bridge
        self._session_mgr = session_manager
        self._agents = agents
        self._master_agent = master_agent
        self._router = ChatRouter(llm_bridge)

    @staticmethod
    def _llm_options(agent_type: str) -> dict[str, str]:
        selection = resolve_agent_llm_selection(agent_type)
        return {
            "provider": selection.runtime_provider,
            "model": selection.model,
            "upstream_provider": selection.provider,
        }

    # ========== Main Entry Point ==========

    async def run(
        self,
        message: str,
        session_id: str,
        user_id: str,
        agent_hint: Optional[str] = None,
        history: Optional[list[dict[str, Any]]] = None,
        metadata: Optional[dict[str, Any]] = None,
        web_search_enabled: bool = True,
    ) -> dict[str, Any]:
        """
        Execute complete workflow: route -> execute -> format -> persist

        Args:
            message: User message
            session_id: Session ID
            user_id: User ID
            agent_hint: Agent type specified by frontend (optional)
            history: History messages (optional)

        Returns:
            dict: Contains task_id, agent_type, response, metadata
        """
        state = WorkflowState(
            message=message,
            session_id=session_id,
            user_id=user_id,
            agent_hint=agent_hint,
            history=history or [],
            metadata=metadata or {},
            web_search_enabled=web_search_enabled,
        )

        try:
            # 1. Route
            state = await self._node_route(state)

            # 2. Execute
            state = await self._node_execute(state)

            # 3. Format
            state = await self._node_format(state)

            # 4. Persist
            state = await self._node_persist(state)

        except Exception as e:
            logger.error(f"Workflow error: {e}", exc_info=True)
            if isinstance(e, HTTPException):
                raise

            mapped_error = http_exception_for_llm_error(e)
            if mapped_error:
                raise mapped_error

            error_msg = str(e)

            # Check if this is an AWS authentication error
            if "AWS_AUTH_REQUIRED" in error_msg:
                logger.warning(f"AWS authentication required, raising HTTP 401: {error_msg}")
                raise HTTPException(
                    status_code=401,
                    detail=error_msg,
                )

            state.error = error_msg

        return self._build_response(state)

    async def run_stream(
        self,
        message: str,
        session_id: str,
        user_id: str,
        agent_hint: Optional[str] = None,
        history: Optional[list[dict[str, Any]]] = None,
        metadata: Optional[dict[str, Any]] = None,
        web_search_enabled: bool = True,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream workflow execution, pushing progress and content step by step.

        Yields:
            dict: Contains type (progress/stream/complete/error) and related data
        """
        state = WorkflowState(
            message=message,
            session_id=session_id,
            user_id=user_id,
            agent_hint=agent_hint,
            history=history or [],
            metadata=metadata or {},
            web_search_enabled=web_search_enabled,
        )

        try:
            # 1. Route
            yield {"type": "progress", "stage": "routing", "message": "Analyzing request..."}
            state = await self._node_route(state)
            yield {
                "type": "progress",
                "stage": "routed",
                "message": f"Routed to {state.route_result.agent_type.value} Agent",
                "agent_type": state.route_result.agent_type.value,
            }

            # 2. Execute (streaming)
            yield {"type": "progress", "stage": "executing", "message": "Executing task..."}

            agent_type = self._execution_agent_type(state)
            agent = self._agents.get(agent_type.value)

            if agent:
                # Read Redis history from SessionManager (backend authoritative source)
                redis_history: list[dict] = []
                if state.session_id and self._session_mgr:
                    try:
                        redis_history = await self._session_mgr.get_context_messages(
                            state.session_id, max_messages=20
                        )
                    except Exception as e:
                        logger.warning(f"Failed to load session history (stream): {e}")

                effective_history = redis_history if redis_history else (state.history or [])

                if agent_type == AgentType.CHAT:
                    context = ChatContext(
                        task_id=state.task_id,
                        session_id=state.session_id,
                        user_id=state.user_id,
                        message=state.message,
                        history=effective_history,
                        enable_web_search=state.web_search_enabled,
                        attachments=state.metadata.get("chat_attachments", []),
                    )
                else:
                    context = AgentContext(
                        task_id=state.task_id,
                        session_id=state.session_id,
                        user_id=state.user_id,
                        metadata={"message": state.message, "history": effective_history, **state.metadata},
                    )

                async for update in agent.stream_execute(state.message, context):
                    yield {
                        "type": "stream",
                        "content": update.message,
                        "progress": update.progress,
                        "stage": update.stage,
                    }

                result = agent.get_status(state.task_id)
                state.agent_result = result
                mapped_error = http_exception_for_agent_result(result)
                if mapped_error:
                    raise mapped_error
            else:
                # Fallback: direct LLM chat
                async for chunk in self._llm_chat_stream(state):
                    yield chunk

            # 3. Format
            state = await self._node_format(state)

            # 4. Persist
            state = await self._node_persist(state)

            # Complete
            yield {
                "type": "complete",
                "task_id": state.task_id,
                "response": state.formatted_response,
                "metadata": state.response_metadata,
            }

        except Exception as e:
            logger.error(f"Stream workflow error: {e}", exc_info=True)
            if isinstance(e, HTTPException):
                raise

            mapped_error = http_exception_for_llm_error(e)
            if mapped_error:
                raise mapped_error

            error_msg = str(e)

            # Check if this is an AWS authentication error
            if "AWS_AUTH_REQUIRED" in error_msg:
                logger.warning(f"AWS authentication required in stream, raising HTTP 401: {error_msg}")
                raise HTTPException(
                    status_code=401,
                    detail=error_msg,
                )

            yield {"type": "error", "error": error_msg}

    # ========== Workflow nodes ==========

    @staticmethod
    def _execution_agent_type(state: WorkflowState) -> AgentType:
        """Use Chat for conversational requests without specialist input."""
        agent_type = state.route_result.agent_type
        if agent_type not in {AgentType.CHAT, AgentType.KNOWLEDGE}:
            if not (state.metadata.get("source_files") or state.metadata.get("files")):
                return AgentType.CHAT
        return agent_type

    async def _node_route(self, state: WorkflowState) -> WorkflowState:
        """Node 1: Routing - determine target Agent"""
        # If frontend specified an Agent, use it directly
        if state.agent_hint:
            try:
                agent_type = AgentType(state.agent_hint)
                state.route_result = RouteResult(
                    agent_type=agent_type,
                    confidence=1.0,
                    method="hint",
                    is_complex=False,
                    reasoning="Specified by frontend",
                )
                logger.info(f"Route by hint: {agent_type.value}")
                return state
            except ValueError:
                logger.warning(f"Invalid agent hint: {state.agent_hint}")

        # Intelligent routing
        state.route_result = await self._router.route(state.message)
        return state

    async def _node_execute(self, state: WorkflowState) -> WorkflowState:
        """Node 2: Execution - dispatch to Agent or MasterAgent"""
        route = state.route_result
        if not route:
            state.error = "Routing result is empty"
            return state

        # Complex task -> MasterAgent
        if route.is_complex and self._master_agent:
            logger.info(f"Complex task, delegating to MasterAgent")
            result = await self._master_agent.execute(state.message, AgentContext(
                task_id=state.task_id,
                session_id=state.session_id,
                user_id=state.user_id,
                metadata={"route": route, "history": state.history},
            ))
            state.agent_result = result
            mapped_error = http_exception_for_agent_result(result)
            if mapped_error:
                raise mapped_error
            return state

        # Simple task -> dispatch directly to specialist Agent
        # Messages from /chat endpoint only build ChatContext;
        # specialist Agents (driver/unittest/...) are called via their respective endpoints
        # and require file content in metadata.
        # When /chat request is routed to a specialist Agent, fallback to ChatAgent for conversational response.
        effective_agent_type = self._execution_agent_type(state)

        agent = self._agents.get(effective_agent_type.value)
        if agent:
            # Read Redis history from SessionManager (backend authoritative source)
            redis_history: list[dict] = []
            if state.session_id and self._session_mgr:
                try:
                    redis_history = await self._session_mgr.get_context_messages(
                        state.session_id, max_messages=20
                    )
                except Exception as e:
                    logger.warning(f"Failed to load session history: {e}")

            # Backend Redis history takes priority; if Redis is empty, use frontend history as fallback
            effective_history = redis_history if redis_history else (state.history or [])

            if effective_agent_type == AgentType.CHAT:
                context = ChatContext(
                    task_id=state.task_id,
                    session_id=state.session_id,
                    user_id=state.user_id,
                    message=state.message,
                    history=effective_history,
                    enable_web_search=state.web_search_enabled,
                    attachments=state.metadata.get("chat_attachments", []),
                )
            else:
                context = AgentContext(
                    task_id=state.task_id,
                    session_id=state.session_id,
                    user_id=state.user_id,
                    metadata={
                        "history": effective_history,
                        **(state.metadata or {}),
                    },
                )
            state.agent_result = await agent.execute(state.message, context)
            mapped_error = http_exception_for_agent_result(state.agent_result)
            if mapped_error:
                raise mapped_error
        else:
            # No corresponding Agent, fallback to direct LLM chat
            state.agent_result = await self._llm_chat(state)
            mapped_error = http_exception_for_agent_result(state.agent_result)
            if mapped_error:
                raise mapped_error

        return state

    async def _node_format(self, state: WorkflowState) -> WorkflowState:
        """Node 3: Formatting - convert Agent result to user-friendly format"""
        result = state.agent_result
        if not result:
            state.formatted_response = state.error or "Processing failed. Please try again later."
            return state

        if result.status == AgentStatus.COMPLETED:
            # ChatResult stores the actual text in data["response"]
            if result.data and "response" in result.data:
                state.formatted_response = result.data["response"]
            else:
                state.formatted_response = result.message
            state.response_metadata = {
                "task_id": result.task_id,
                "status": result.status.value,
                "duration_ms": result.duration_ms,
                "data": result.data,
            }
        elif result.status == AgentStatus.FAILED:
            state.formatted_response = f"Task execution failed: {result.message}"
            state.response_metadata = {
                "task_id": result.task_id,
                "status": result.status.value,
                "errors": result.errors,
            }
        else:
            state.formatted_response = result.message

        return state

    async def _node_persist(self, state: WorkflowState) -> WorkflowState:
        """Node 4: Persistence - save messages to session"""
        try:
            if state.session_id:
                # Save user message
                await self._session_mgr.add_message(
                    session_id=state.session_id,
                    role="user",
                    content=persisted_attachment_message(
                        state.message, state.metadata.get("chat_attachments", [])
                    ),
                )
                # Save Assistant response
                result = await self._session_mgr.add_message(
                    session_id=state.session_id,
                    role="assistant",
                    content=state.formatted_response,
                )
                # Set the session title after the first conversation round.
                if result.get("message_count", 0) == 2:
                    await self._save_initial_title(state)
        except Exception as e:
            logger.warning(f"Failed to persist messages: {e}")

        return state

    async def _save_initial_title(self, state: WorkflowState) -> None:
        """Save a deterministic first-message title without another LLM request."""
        try:
            title = " ".join(state.message.split()).strip('"\'')[:50]
            if not title:
                title = "New Session"
            await self._session_mgr.update_title(state.session_id, title)
            logger.info(f"Session title saved: {title!r} for {state.session_id}")
        except Exception as e:
            logger.warning(f"Failed to save session title: {e}")

    # ========== Internal helper methods ==========

    async def _llm_chat(self, state: WorkflowState) -> AgentResult:
        """Direct LLM chat (fallback when no specialist Agent)"""
        try:
            # Build message context
            messages: list[dict[str, Any]] = []
            if state.session_id:
                context_msgs = await self._session_mgr.get_context_messages(
                    state.session_id
                )
                messages.extend(context_msgs)
            messages.append({"role": "user", "content": state.message})

            response = await self._llm.generate(
                prompt=messages,
                **self._llm_options(
                    state.route_result.agent_type.value if state.route_result else "chat"
                ),
            )

            return AgentResult(
                task_id=state.task_id,
                status=AgentStatus.COMPLETED,
                message=response.content,
                data={
                    "model": response.model,
                    "provider": response.provider,
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                    },
                },
            )
        except Exception as e:
            return AgentResult(
                task_id=state.task_id,
                status=AgentStatus.FAILED,
                message=f"LLM call failed: {e}",
                errors=[str(e)],
            )

    async def _llm_chat_stream(
        self, state: WorkflowState
    ) -> AsyncIterator[dict[str, Any]]:
        """Direct LLM streaming chat"""
        try:
            messages: list[dict[str, Any]] = []
            if state.session_id:
                context_msgs = await self._session_mgr.get_context_messages(
                    state.session_id
                )
                messages.extend(context_msgs)
            messages.append({"role": "user", "content": state.message})

            full_content = ""
            async for chunk in self._llm.generate_stream(
                prompt=messages,
                **self._llm_options(
                    state.route_result.agent_type.value if state.route_result else "chat"
                ),
            ):
                full_content += chunk.content
                yield {
                    "type": "stream",
                    "content": chunk.content,
                    "is_final": chunk.is_final,
                }

            # Save full response to state
            state.agent_result = AgentResult(
                task_id=state.task_id,
                status=AgentStatus.COMPLETED,
                message=full_content,
            )

        except Exception as e:
            yield {"type": "error", "error": str(e)}

    def _build_response(self, state: WorkflowState) -> dict[str, Any]:
        """Build final response"""
        response: dict[str, Any] = {
            "task_id": state.task_id,
            "session_id": state.session_id,
            "agent_type": (
                state.route_result.agent_type.value if state.route_result else "chat"
            ),
            "response": state.formatted_response,
            "metadata": state.response_metadata,
        }
        if state.error:
            response["error"] = state.error
        return response
