"""Opt-in unified event routing for authorized Feishu private messages."""

from app.orchestration.feishu_chat import FeishuChat
from app.schemas.agent_event import EventInput
from app.services.event_policy import load_policy
from app.services.app_connections import AppConnectionError


class FeishuEventResponder:
    def __init__(self, app, sessions, dispatcher):
        self.sessions = sessions
        self.dispatcher = dispatcher
        self.chat = FeishuChat(app, sessions)

    async def respond(self, connection, message: dict) -> tuple[str, str]:
        async with self.sessions() as db:
            policy = await load_policy(db, connection.user_id)
        if not policy.enabled:
            return await self.chat.respond(connection, message)
        event = EventInput(event_id=message["message_id"], event_type="im.message.receive_v1",
                           text=message["content"], actor_id=message["sender_id"], subject_id=message["chat_id"])
        record = await self.dispatcher.respond(connection.user_id, "feishu", connection.app_id, event)
        if record["status"] in {"failed", "interrupted", "cancelled"}:
            raise AppConnectionError("Event execution did not complete. Review the Event Center in the platform.", 502)
        result = record.get("result") or {}
        response = result.get("response") or record.get("error") or record["route"]["reason"]
        if record["status"] == "needs_input":
            response += "\n\nOpen the selected Agent workspace in the platform to provide the required inputs."
        return response, record.get("session_id") or ""
