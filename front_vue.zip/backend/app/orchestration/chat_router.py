"""
@file chat_router.py
@author caoshwen
@brief ChatRouter - intelligent message routing to appropriate agent.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import re
from dataclasses import dataclass
from typing import Optional

from loguru import logger

from app.agents.base import AgentType
from app.core.config import resolve_agent_llm_selection
from app.llm.bridge import LLMBridge


@dataclass
class RouteResult:
    """Routing result"""
    agent_type: AgentType
    confidence: float  # 0.0 ~ 1.0
    method: str  # "regex" | "llm"
    is_complex: bool = False  # When True, use MasterAgent
    reasoning: str = ""


# ========== Regex Routing Rules ==========

_REGEX_RULES: list[tuple[re.Pattern, AgentType, float]] = [
    (re.compile(
        r"(register|bitfield|bit\s*\d+|datasheet|reference\s*manual|\u5bc4\u5b58\u5668|\u4f4d\u57df)",
        re.IGNORECASE,
    ), AgentType.KNOWLEDGE, 0.92),
    # UnitTest Agent
    (re.compile(
        r"(generate|write|create|add).*(unit\s*test|test\s*case)",
        re.IGNORECASE,
    ), AgentType.UNITTEST, 0.9),
    (re.compile(
        r"(unit\s*test).*(generate|coverage)",
        re.IGNORECASE,
    ), AgentType.UNITTEST, 0.9),

    # Driver Agent
    (re.compile(
        r"(generate|write|create|develop).*(driver|peripheral|HAL)",
        re.IGNORECASE,
    ), AgentType.DRIVER, 0.9),
    (re.compile(
        r"(driver).*(develop|generate|template)",
        re.IGNORECASE,
    ), AgentType.DRIVER, 0.9),
    (re.compile(
        r"(GPIO|SPI|I2C|UART|CAN|ADC|DMA|TIM|USART).*(driver|init|config)",
        re.IGNORECASE,
    ), AgentType.DRIVER, 0.85),

    # Build Agent
    (re.compile(
        r"(compile|build|make|cmake|qbs).*(project|code|firmware)",
        re.IGNORECASE,
    ), AgentType.BUILD, 0.9),
    (re.compile(
        r"(compile\s*error|build\s*error|link\s*error)",
        re.IGNORECASE,
    ), AgentType.BUILD, 0.85),

    # BugFix Agent
    (re.compile(
        r"(fix|modify|resolve).*(bug|defect|issue|fault|crash)",
        re.IGNORECASE,
    ), AgentType.BUGFIX, 0.9),
    (re.compile(
        r"(bug|defect|issue).*(fix|analyze|troubleshoot)",
        re.IGNORECASE,
    ), AgentType.BUGFIX, 0.9),

    # Debug Agent
    (re.compile(
        r"(debug|breakpoint|GDB|J-Link|ST-Link|trace)",
        re.IGNORECASE,
    ), AgentType.DEBUG, 0.85),
    (re.compile(
        r"(analyze|troubleshoot).*(crash|deadlock|memory\s*leak)",
        re.IGNORECASE,
    ), AgentType.DEBUG, 0.85),

    # Review Agent
    (re.compile(
        r"(code\s*review|review).*(code|PR|pull\s*request|MR)",
        re.IGNORECASE,
    ), AgentType.REVIEW, 0.9),
    (re.compile(
        r"(MISRA|static\s*analysis|coding\s*standard)",
        re.IGNORECASE,
    ), AgentType.REVIEW, 0.85),
]

# Complex task keywords (require MasterAgent intervention)
_COMPLEX_PATTERNS = [
    re.compile(r"(simultaneously|parallel|together).*(generate|create|develop|test)", re.IGNORECASE),
    re.compile(r"(complete|full|end.to.end).*(develop|workflow|pipeline)", re.IGNORECASE),
    re.compile(r"(from\s*scratch).*(develop|build|create)", re.IGNORECASE),
    re.compile(r"(first.*then.*finally|step\s*1.*step\s*2)", re.IGNORECASE),
    re.compile(r"(multiple|batch).*(driver|module|test|agent)", re.IGNORECASE),
]

# LLM routing Prompt
_ROUTE_SYSTEM_PROMPT = """You are the routing classifier for the Macode platform. Based on the user message, determine which Agent the request should be routed to.

Available Agents:
- unittest: Unit test generation (test cases for C/C++ embedded code)
- driver: Driver development (STM32 peripheral driver code generation)
- build: Build compilation (project compilation, build error troubleshooting)
- bugfix: Bug fixing (code defect localization and repair)
- debug: Debug analysis (runtime debugging, crash analysis)
- review: Code review (MISRA compliance check, PR review)
- chat: General conversation (technical Q&A, architecture consultation, and anything not in the categories above)

Also determine task complexity:
- simple: Can be completed independently by a single Agent
- complex: Requires multiple Agents collaboration or multi-step execution

Please reply strictly in the following JSON format, do not output anything else:
{"agent": "agent_type", "complexity": "simple|complex", "reason": "brief explanation"}"""


class ChatRouter:
    """
    Intelligent router.

    Routing strategy:
    1. Regex matching: zero cost, millisecond latency, covers common patterns
    2. LLM classification: high accuracy, used when regex doesn't match
    """

    def __init__(self, llm_bridge: LLMBridge):
        self._llm = llm_bridge

    async def route(self, message: str) -> RouteResult:
        """
        Route user message to the appropriate Agent.

        Args:
            message: User input message

        Returns:
            RouteResult: Routing result
        """
        # Step 1: Regex matching
        result = self._regex_route(message)
        if result and result.confidence >= 0.85:
            # Check complexity
            result.is_complex = self._check_complexity(message)
            logger.info(
                f"Regex route: {result.agent_type.value} "
                f"(confidence={result.confidence}, complex={result.is_complex})"
            )
            return result

        # Step 2: LLM classification
        llm_result = await self._llm_route(message)
        if llm_result:
            logger.info(
                f"LLM route: {llm_result.agent_type.value} "
                f"(confidence={llm_result.confidence}, complex={llm_result.is_complex})"
            )
            return llm_result

        # Fallback: Chat Agent
        logger.info("Fallback route: chat")
        return RouteResult(
            agent_type=AgentType.CHAT,
            confidence=0.5,
            method="fallback",
            is_complex=False,
            reasoning="No rules matched, defaulting to Chat Agent",
        )

    def _regex_route(self, message: str) -> Optional[RouteResult]:
        """Regex pattern matching route"""
        best_match: Optional[RouteResult] = None
        best_confidence = 0.0

        for pattern, agent_type, confidence in _REGEX_RULES:
            if pattern.search(message):
                if confidence > best_confidence:
                    best_confidence = confidence
                    best_match = RouteResult(
                        agent_type=agent_type,
                        confidence=confidence,
                        method="regex",
                        reasoning=f"Regex match: {pattern.pattern[:50]}",
                    )

        return best_match

    def _check_complexity(self, message: str) -> bool:
        """Detect if message describes a complex task"""
        return any(p.search(message) for p in _COMPLEX_PATTERNS)

    async def _llm_route(self, message: str) -> Optional[RouteResult]:
        """LLM intelligent classification route"""
        import json

        try:
            selection = resolve_agent_llm_selection("chat")
            response = await self._llm.generate(
                prompt=[
                    {"role": "system", "content": _ROUTE_SYSTEM_PROMPT},
                    {"role": "user", "content": message},
                ],
                temperature=0.0,
                max_tokens=200,
                provider=selection.runtime_provider,
                model=selection.model,
                upstream_provider=selection.provider,
            )

            # Parse JSON response
            content = response.content.strip()
            # Handle possible markdown code block wrapping
            if content.startswith("```"):
                content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

            data = json.loads(content)
            agent_str = data.get("agent", "chat")
            complexity = data.get("complexity", "simple")
            reason = data.get("reason", "")

            # Map to AgentType
            try:
                agent_type = AgentType(agent_str)
            except ValueError:
                agent_type = AgentType.CHAT

            return RouteResult(
                agent_type=agent_type,
                confidence=0.8,
                method="llm",
                is_complex=(complexity == "complex"),
                reasoning=reason,
            )

        except Exception as e:
            error_msg = str(e)
            logger.warning(f"LLM routing failed: {error_msg}")

            # Re-raise AWS authentication errors
            if "AWS_AUTH_REQUIRED" in error_msg or "ExpiredToken" in error_msg:
                logger.error(f"AWS authentication error detected in routing, re-raising: {error_msg}")
                raise

            return None
