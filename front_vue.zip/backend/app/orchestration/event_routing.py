"""Pure first-match event routing; preview and execution share this function."""

from app.schemas.agent_event import EventInput, RoutingPolicyInput


def route_event(event: EventInput, source: str, source_id: str, policy: RoutingPolicyInput) -> dict:
    if not policy.enabled:
        return {"agent": None, "rule_id": None, "reason": "Event routing is disabled.", "revision": policy.revision}
    for _, rule in sorted(enumerate(policy.rules), key=lambda item: (-item[1].priority, item[0])):
        if not rule.enabled or rule.source not in {"*", source}:
            continue
        if rule.source_id and rule.source_id != source_id:
            continue
        pattern = rule.event_type
        if pattern != "*" and not (event.event_type.startswith(pattern[:-1]) if pattern.endswith("*") else event.event_type == pattern):
            continue
        text, value = event.text.strip().casefold(), rule.value.strip().casefold()
        if rule.match == "contains" and value not in text:
            continue
        if rule.match == "command" and text.split(maxsplit=1)[0] != value:
            continue
        return {"agent": rule.agent.value, "rule_id": rule.id, "rule_name": rule.name,
                "reason": "Matched the highest-priority enabled rule; ties use the saved order.",
                "revision": policy.revision, "match": rule.match, "value": rule.value}
    return {"agent": policy.fallback_agent.value if policy.fallback_agent else None, "rule_id": None,
            "reason": "No rule matched; using the configured fallback." if policy.fallback_agent else "No rule matched; event ignored.",
            "revision": policy.revision}
