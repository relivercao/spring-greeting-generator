"""
@file deps.py
@brief FastAPI dependency injection functions for workflows.

@version 3.2
@date 2026-07-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""

from typing import Optional
from fastapi import Depends, Request

from app.orchestration.unittest_workflow import UnitTestWorkflow
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient
from app.skills.registry import SkillRegistry


async def get_unittest_workflow(
    request: Request,
) -> UnitTestWorkflow:
    """
    Get UnitTestWorkflow instance with injected dependencies.

    Args:
        request: FastAPI request (for accessing app.state)

    Returns:
        UnitTestWorkflow instance
    """
    llm_bridge: LLMBridge = request.app.state.llm_bridge
    mcp_client: Optional[MCPClient] = getattr(request.app.state, "mcp_client", None)
    skill_registry: Optional[SkillRegistry] = getattr(request.app.state, "skill_registry", None)

    return UnitTestWorkflow(
        llm_bridge=llm_bridge,
        mcp_client=mcp_client,
        skill_registry=skill_registry,
    )
