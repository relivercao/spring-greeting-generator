"""Route authorized Feishu direct messages through the existing Chat workflow."""

import hashlib

from app.agents.impl.chat.agent import ChatAgent
from app.core.billing_context import reset_billing_user_id, set_billing_user_id
from app.mcp.servers.connected_apps_server import ConnectedAppsMCPServer
from app.models.feishu import FeishuConversation
from app.orchestration.chat_workflow import ChatOrchestratorWorkflow
from app.services.app_connections import AppConnectionError
from app.services.billing_service import enforce_billing
from app.services.feishu_tools import FeishuBotTools


class FeishuChat:
    def __init__(self, app, session_factory):
        self.app = app
        self.sessions = session_factory

    async def respond(self, connection, event: dict) -> tuple[str, str]:
        from app.models.user import User

        async with self.sessions() as db:
            user = await db.get(User, connection.user_id)
            if user is None or not user.is_active:
                raise AppConnectionError("The linked platform account is inactive.", 403)
        token = set_billing_user_id(user.id)
        try:
            await enforce_billing({"id": user.id, "username": user.username})
            manager = self.app.state.session_manager
            scope = hashlib.sha256(
                ":".join([user.id, connection.app_id, event["sender_id"], event["chat_id"]]).encode(),
            ).hexdigest()
            async with self.sessions() as db:
                conversation = await db.get(FeishuConversation, scope)
                session = await manager.get_session(conversation.session_id) if conversation else None
                if session and session["user_id"] != user.id:
                    raise AppConnectionError("Conversation ownership could not be verified.", 403)
                if not session:
                    session_id = await manager.create_session(user.id, "chat", "Feishu conversation")
                    if conversation is None:
                        conversation = FeishuConversation(id=scope, user_id=user.id, session_id=session_id)
                        db.add(conversation)
                    else:
                        conversation.session_id = session_id
                    await db.commit()
                session_id = conversation.session_id
            agent = ChatAgent(
                self.app.state.llm_bridge, self.app.state.mcp_client,
                getattr(self.app.state, "skill_registry", None),
                connected_apps=ConnectedAppsMCPServer(user.id, feishu_tools=FeishuBotTools(user.id, self.sessions)),
            )
            workflow = ChatOrchestratorWorkflow(
                self.app.state.llm_bridge, manager, {"chat": agent},
            )
            result = await workflow.run(
                message=event["content"], session_id=session_id, user_id=user.id,
                agent_hint="chat", web_search_enabled=False,
            )
            if result.get("error") or result.get("metadata", {}).get("status") == "failed":
                raise AppConnectionError("Agent execution failed. Review the platform task details.", 502)
            return result.get("response") or "The Agent returned no response.", session_id
        finally:
            reset_billing_user_id(token)
