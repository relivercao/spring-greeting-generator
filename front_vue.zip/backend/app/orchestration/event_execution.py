"""Execute the selected specialist with billing, session, and task evidence."""

import hashlib
import json

from sqlalchemy import update

from app.agents.base import AgentStatus
from app.core.billing_context import reset_billing_user_id, set_billing_user_id
from app.models.agent_event import AgentEvent, EventConversation, EventWebhookSource
from app.models.task import Task
from app.models.user import User
from app.orchestration.event_agents import WORKSPACE_ROUTES, missing_inputs, prepare_agent, response_text
from app.schemas.agent_event import EventInput
from app.services.agent_task_runtime import agent_task_registry, serialize_agent_result
from app.services.billing_service import enforce_billing
from app.services.event_policy import load_policy


class EventExecutor:
    def __init__(self, app, sessions):
        self.app, self.sessions = app, sessions

    async def execute(self, record):
        event = EventInput.model_validate_json(record.input_json)
        async with self.sessions() as db:
            user = await db.get(User, record.user_id)
            policy = await load_policy(db, record.user_id)
            if user is None or not user.is_active:
                return "failed", {"response": "The linked platform account is inactive."}, None, None
            if not policy.enabled:
                return "ignored", {"response": "Event routing was disabled before execution."}, None, None
            if record.source == "webhook":
                source = await db.get(EventWebhookSource, record.source_id)
                if source is None or not source.enabled or source.user_id != record.user_id:
                    return "ignored", {"response": "The webhook source was disabled or removed before execution."}, None, None
            if record.source == "feishu":
                from app.services.feishu_connections import get_connection
                connection = await get_connection(db, record.user_id)
                if (connection is None or not connection.enabled or connection.app_id != record.source_id
                        or record.actor_id not in json.loads(connection.allowed_sender_ids)):
                    return "ignored", {"response": "The Feishu sender or connection is no longer authorized."}, None, None
        requirements = missing_inputs(record.selected_agent, event)
        if requirements:
            return "needs_input", {"response": "\n".join(requirements), "requirements": requirements,
                "workspace": WORKSPACE_ROUTES[record.selected_agent]}, None, None
        token = set_billing_user_id(record.user_id)
        try:
            await enforce_billing({"id": user.id, "username": user.username})
            session_id = await self._session(record)
            manager = self.app.state.session_manager
            history = await manager.get_context_messages(session_id, max_messages=20)
            prepared = prepare_agent(self.app, record.user_id, event, record.selected_agent,
                                     record.id, session_id, history, self.sessions)
            async with self.sessions() as db:
                db.add(Task(id=record.id, user_id=record.user_id, agent_type=record.selected_agent,
                            status="running", input_data=json.dumps({"event_id": record.id, "source": record.source})))
                await db.execute(update(AgentEvent).where(AgentEvent.id == record.id).values(task_id=record.id, session_id=session_id))
                await db.commit()
            import asyncio
            agent_task_registry.register(record.id, asyncio.current_task(), prepared.agent)
            try:
                async for info in prepared.agent.stream_execute(event.text, prepared.context):
                    async with self.sessions() as db:
                        await db.execute(update(Task).where(Task.id == record.id, Task.status == "running").values(
                            progress=max(0, min(info.progress, 99)), message=info.message[:500]))
                        await db.commit()
                result = prepared.agent.get_status(record.id)
            finally:
                agent_task_registry.remove(record.id)
            encoded = serialize_agent_result(result)
            text = response_text(result)
            if result.status != AgentStatus.COMPLETED:
                text = f"{record.selected_agent} Agent did not complete this event. Review the event result in the platform."
            encoded["response"] = text
            async with self.sessions() as db:
                await db.execute(update(Task).where(Task.id == record.id).values(status=result.status.value,
                    progress=100 if result.status == AgentStatus.COMPLETED else 0,
                    message=result.message[:500], result_data=json.dumps(encoded),
                    duration_ms=result.duration_ms))
                await db.commit()
            await manager.add_message(session_id=session_id, role="user", content=event.text)
            await manager.add_message(session_id=session_id, role="assistant", content=text)
            return result.status.value, encoded, record.id, session_id
        finally:
            reset_billing_user_id(token)

    async def _session(self, record):
        # A distinct external event has no implicit access to another event's history.
        scope_key = record.subject_id if record.source == "feishu" else record.external_id
        scope = hashlib.sha256(json.dumps([record.user_id, record.source_key, record.actor_id,
                                          scope_key, record.selected_agent], separators=(",", ":")).encode()).hexdigest()
        manager = self.app.state.session_manager
        async with self.sessions() as db:
            conversation = await db.get(EventConversation, scope)
            session = await manager.get_session(conversation.session_id) if conversation else None
            if session and session.get("user_id") != record.user_id:
                raise ValueError("Event conversation ownership could not be verified.")
            if not session:
                session_id = await manager.create_session(record.user_id, record.selected_agent, f"Event: {record.event_type}")
                if conversation is None:
                    conversation = EventConversation(id=scope, user_id=record.user_id, session_id=session_id)
                    db.add(conversation)
                else:
                    conversation.session_id = session_id
                await db.commit()
            return conversation.session_id
