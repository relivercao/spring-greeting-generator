"""
@file unittest_workflow.py
@brief Unit test generation orchestration workflow.

@version 3.2
@date 2026-07-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from pathlib import Path
import fnmatch
import os

from app.orchestration.base_workflow import (
    BaseWorkflow,
    WorkflowContext,
    WorkflowResult,
    WorkflowStatus,
    WorkflowValidationError,
)
from app.agents.impl import UnitTestAgent
from app.agents.impl.unittest import UnitTestContext
from app.agents.base import AgentStatus
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient


@dataclass
class UnitTestWorkflowContext(WorkflowContext):
    """
    Unit test generation workflow context.

    Extends base context with unittest-specific parameters.
    """
    # Required fields (no defaults)
    source_file: str = ""  # Path to source file (primary/first upload)

    # Optional fields (with defaults)
    # All uploaded source files. Headers uploaded alongside the primary
    # .c/.cpp must reach the agent and the scaffold step, or generated
    # sources cannot resolve their own #include lines at build time.
    source_files: list[str] = field(default_factory=list)
    layer: str = "hal"  # Code layer (hal, app, etc.)
    framework: str = "gtest"  # Test framework
    target_coverage: float = 0.8  # Target coverage (0.0-1.0)
    max_iterations: int = 3  # Max compilation fix iterations
    output_dir: Optional[str] = None  # Output directory for generated files


@dataclass
class UnitTestWorkflowResult(WorkflowResult):
    """
    Unit test generation workflow result.

    Extends base result with unittest-specific data.
    """
    generated_files: list[str] = field(default_factory=list)
    coverage: Optional[Dict[str, float]] = None
    test_results: Optional[Dict[str, Any]] = None
    cli_log_path: Optional[str] = None


class UnitTestWorkflow(BaseWorkflow):
    """
    Unit test generation orchestration workflow.

    Multi-phase workflow:
    1. Validation: Validate input files and parameters
    2. Analysis: Parse source code structure (QBS/libclang)
    3. Generation: Generate test cases via LLM
    4. Compilation: Iterative compilation and error fixing
    5. Execution: Run tests and collect coverage
    6. Reporting: Generate summary report

    This workflow coordinates the UnitTestAgent and provides
    progress tracking, error recovery, and result aggregation.
    """

    def __init__(
        self,
        llm_bridge: LLMBridge,
        mcp_client: Optional[MCPClient] = None,
        skill_registry: Optional[Any] = None,
    ):
        """
        Initialize unittest workflow.

        Args:
            llm_bridge: LLM bridge for AI interactions
            mcp_client: Optional MCP client for tool access
            skill_registry: Optional skill registry for agent
        """
        super().__init__(llm_bridge, mcp_client)

        # Create unittest agent (constructor takes the bridge/client directly;
        # the agent applies its own AgentConfig internally)
        self._unittest_agent = UnitTestAgent(
            llm_bridge,
            mcp_client,
            skill_registry=skill_registry,
        )

    async def execute(self, context: UnitTestWorkflowContext) -> UnitTestWorkflowResult:
        """
        Execute unit test generation workflow.

        Args:
            context: Workflow context with unittest parameters

        Returns:
            UnitTestWorkflowResult: Execution result with generated files
        """
        from datetime import datetime, timezone

        started_at = datetime.now(timezone.utc)
        workflow_id = context.workflow_id

        result = UnitTestWorkflowResult(
            workflow_id=workflow_id,
            status=WorkflowStatus.RUNNING,
            message="Workflow started",
            started_at=started_at,
        )

        try:
            # Phase 1: Validation
            await self._report_progress(
                workflow_id, "validation", 10, "Validating input parameters"
            )
            await self._validate_context(context)

            # Phase 2: Execute unittest agent
            await self._report_progress(
                workflow_id, "generation", 30, "Generating unit tests"
            )

            agent_context = self._create_agent_context(context)
            agent_result = await self._execute_agent(
                self._unittest_agent,
                f"Generate unit tests for {context.source_file}",
                agent_context,
            )

            # Phase 3: Process agent result
            await self._report_progress(
                workflow_id, "processing", 80, "Processing results"
            )
            result = self._process_agent_result(
                result, agent_result, context
            )

            # Propagate agent failures instead of overwriting them below
            if result.status == WorkflowStatus.FAILED:
                await self._report_progress(
                    workflow_id, "failed", 100, result.message
                )
                return result

            # Phase 4: Completion
            await self._report_progress(
                workflow_id, "completed", 100, "Workflow completed"
            )

            result.status = WorkflowStatus.COMPLETED
            result.message = "Unit tests generated successfully"

        except WorkflowValidationError as e:
            result.status = WorkflowStatus.FAILED
            result.message = f"Validation failed: {e}"
            result.errors = [str(e)]

        except Exception as e:
            result.status = WorkflowStatus.FAILED
            result.message = f"Workflow failed: {e}"
            result.errors = [str(e)]

        finally:
            result.completed_at = datetime.now(timezone.utc)
            if result.started_at and result.completed_at:
                result.duration_ms = (
                    result.completed_at - result.started_at
                ).total_seconds() * 1000

        return result

    async def _validate_context(self, context: UnitTestWorkflowContext) -> None:
        """
        Validate workflow context.

        Args:
            context: Workflow context

        Raises:
            WorkflowValidationError: If validation fails
        """
        # Validate source file exists
        source_path = Path(context.source_file)
        if not source_path.exists():
            raise WorkflowValidationError(
                f"Source file not found: {context.source_file}"
            )

        if not source_path.is_file():
            raise WorkflowValidationError(
                f"Source file is not a file: {context.source_file}"
            )

        # Validate layer
        valid_layers = {"hal", "app", "driver", "middleware", "bsp"}
        if context.layer not in valid_layers:
            raise WorkflowValidationError(
                f"Invalid layer: {context.layer} (allowed: {', '.join(valid_layers)})"
            )

        # Validate framework
        valid_frameworks = {"gtest", "unity", "catch2", "cppunit"}
        if context.framework not in valid_frameworks:
            raise WorkflowValidationError(
                f"Invalid framework: {context.framework} (allowed: {', '.join(valid_frameworks)})"
            )

        # Validate coverage
        if not 0.0 <= context.target_coverage <= 1.0:
            raise WorkflowValidationError(
                f"Invalid target_coverage: {context.target_coverage} (must be 0.0-1.0)"
            )

        # Validate iterations
        if not 1 <= context.max_iterations <= 10:
            raise WorkflowValidationError(
                f"Invalid max_iterations: {context.max_iterations} (must be 1-10)"
            )

    def _create_agent_context(
        self, workflow_context: UnitTestWorkflowContext
    ) -> UnitTestContext:
        """
        Create agent context from workflow context.

        Args:
            workflow_context: Workflow context

        Returns:
            UnitTestContext: Agent execution context
        """
        source_files = list(workflow_context.source_files or [])
        if not source_files and workflow_context.source_file:
            source_files = [workflow_context.source_file]

        # The endpoint does not expose build_profile, so pick the QBS profile
        # that matches the host: mingw on Windows, host gcc on Linux servers.
        import sys as _sys
        default_build_profile = (
            "host_gcc" if _sys.platform.startswith("linux") else "mingw"
        )

        # Uploaded files already live on local disk; read them here so the
        # agent does not try to fetch them through the BitBucket MCP tool
        # (which only applies to repo-based flows). Paths that cannot be
        # read locally are left for the agent's own fetch step.
        source_contents: dict[str, str] = {}
        for path in source_files:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    source_contents[path] = f.read()
            except OSError:
                continue

        # Uploaded-file tasks have no firmware repository behind them. The
        # agent resolves project_root itself (repo marker walk-up, falling
        # back to output_dir); when no repo is detected, scaffold the minimal
        # platformkit QBS tree into output_dir so the compile-verify pipeline
        # has a project to build. Repo-based tasks keep their real tree.
        if workflow_context.layer == "hal" and workflow_context.output_dir:
            from app.agents.impl.unittest.paths import find_project_root_for_source
            from app.agents.impl.unittest.qbs import ensure_uploaded_project_skeleton

            repo_root = (
                find_project_root_for_source(source_files[0])
                if source_files
                else None
            )
            if repo_root is None:
                ensure_uploaded_project_skeleton(
                    workflow_context.output_dir,
                    source_files,
                    layer="hal",
                )

        return UnitTestContext(
            task_id=workflow_context.workflow_id,
            user_id=workflow_context.user_id,
            session_id=workflow_context.session_id,
            project_root=workflow_context.project_root,
            source_files=source_files,
            source_contents=source_contents,
            layer=workflow_context.layer,
            test_framework=workflow_context.framework,
            coverage_target=workflow_context.target_coverage,
            max_iterations=workflow_context.max_iterations,
            output_dir=workflow_context.output_dir,
            build_profile=default_build_profile,
        )

    def _process_agent_result(
        self,
        workflow_result: UnitTestWorkflowResult,
        agent_result,
        context: UnitTestWorkflowContext,
    ) -> UnitTestWorkflowResult:
        """
        Process agent result into workflow result.

        Args:
            workflow_result: Workflow result to populate
            agent_result: Agent execution result
            context: Workflow context

        Returns:
            Updated workflow result
        """
        if agent_result.status == AgentStatus.FAILED:
            workflow_result.status = WorkflowStatus.FAILED
            workflow_result.message = agent_result.message
            workflow_result.errors = agent_result.errors
            # Tasks that fail after generation (e.g. at the compile or run
            # stage) still leave artifacts on disk; surface them so users can
            # retrieve whatever was produced.
            partial_files = (agent_result.data or {}).get("saved_files", [])
            if not partial_files:
                partial_files = self._collect_generated_artifacts(context.output_dir)
            if partial_files:
                workflow_result.generated_files = partial_files
                workflow_result.data = dict(workflow_result.data or {})
                workflow_result.data["generated_files"] = partial_files
            return workflow_result

        # Extract generated files from agent result
        if agent_result.data:
            workflow_result.generated_files = agent_result.data.get("saved_files", [])
            workflow_result.coverage = agent_result.data.get("coverage")
            workflow_result.test_results = agent_result.data.get("test_results")
            workflow_result.data = agent_result.data

        return workflow_result

    @staticmethod
    def _collect_generated_artifacts(output_dir: Optional[str]) -> list[str]:
        """List generated test/mock artifacts under a task output directory.

        Matches the canonical generated-file naming (``tc-*`` test cases,
        ``mock-*`` mocks and stubs) and returns absolute paths, mirroring the
        format of ``saved_files`` on successful runs. Build output directories
        are skipped.
        """
        if not output_dir or not os.path.isdir(output_dir):
            return []
        skip_dirs = {"default", "release", ".qbs", "node_modules", "__pycache__"}
        artifacts: list[str] = []
        for root, dirs, files in os.walk(output_dir):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for name in files:
                if not fnmatch.fnmatch(name, "tc-*") and not fnmatch.fnmatch(name, "mock-*"):
                    continue
                if os.path.splitext(name)[1] not in (".cpp", ".cc", ".c", ".h"):
                    continue
                artifacts.append(os.path.join(root, name))
        artifacts.sort()
        return artifacts
