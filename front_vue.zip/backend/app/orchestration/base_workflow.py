"""
@file base_workflow.py
@brief Base workflow class for orchestration layer.

@version 3.2
@date 2026-07-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, Dict, Any, AsyncIterator
from enum import Enum

from app.agents.base import BaseAgent, AgentContext, AgentResult
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient


class WorkflowStatus(str, Enum):
    """Workflow execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class WorkflowContext:
    """
    Workflow execution context.

    Extended by specific workflow implementations.
    """
    workflow_id: str
    user_id: str
    session_id: Optional[str] = None
    project_root: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowResult:
    """
    Workflow execution result.

    Extended by specific workflow implementations.
    """
    workflow_id: str
    status: WorkflowStatus
    message: str
    data: Optional[Dict[str, Any]] = None
    errors: list[str] = field(default_factory=list)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: Optional[float] = None


@dataclass
class WorkflowProgress:
    """Workflow progress update"""
    workflow_id: str
    phase: str
    progress: int  # 0-100
    message: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class BaseWorkflow(ABC):
    """
    Base class for orchestration workflows.

    Workflows coordinate multiple agents, tools, and steps to accomplish
    complex tasks that require multi-phase processing.

    Design Principles:
    - Each workflow represents one complete business process
    - Workflows can call multiple agents in sequence or parallel
    - Workflows handle coordination, error recovery, and state management
    - Workflows emit progress updates for long-running operations

    Subclasses must implement:
    - execute(): Main workflow execution logic
    - _validate_context(): Input validation
    """

    def __init__(
        self,
        llm_bridge: LLMBridge,
        mcp_client: Optional[MCPClient] = None,
    ):
        """
        Initialize base workflow.

        Args:
            llm_bridge: LLM bridge for AI interactions
            mcp_client: Optional MCP client for tool access
        """
        self._llm = llm_bridge
        self._mcp = mcp_client
        self._progress_callbacks: list = []
        self._cancelled = False

    @abstractmethod
    async def execute(self, context: WorkflowContext) -> WorkflowResult:
        """
        Execute workflow.

        Args:
            context: Workflow execution context

        Returns:
            WorkflowResult: Execution result
        """
        pass

    @abstractmethod
    async def _validate_context(self, context: WorkflowContext) -> None:
        """
        Validate workflow context.

        Args:
            context: Workflow execution context

        Raises:
            ValidationError: If context is invalid
        """
        pass

    async def stream_execute(
        self,
        context: WorkflowContext,
    ) -> AsyncIterator[WorkflowProgress]:
        """
        Execute workflow with progress streaming.

        Args:
            context: Workflow execution context

        Yields:
            WorkflowProgress: Progress updates
        """
        progress_queue: list[WorkflowProgress] = []

        # Register progress callback
        def on_progress(update: WorkflowProgress):
            progress_queue.append(update)

        self._progress_callbacks.append(on_progress)

        # Start execution
        import asyncio
        exec_task = asyncio.create_task(self.execute(context))

        # Poll and push progress
        while not exec_task.done():
            while progress_queue:
                yield progress_queue.pop(0)
            await asyncio.sleep(0.1)

        # Push remaining progress
        while progress_queue:
            yield progress_queue.pop(0)

        # Get final result
        result = exec_task.result()

        # Push final status
        yield WorkflowProgress(
            workflow_id=context.workflow_id,
            phase="completed" if result.status == WorkflowStatus.COMPLETED else "failed",
            progress=100 if result.status == WorkflowStatus.COMPLETED else -1,
            message=result.message,
        )

        # Clean up callbacks
        self._progress_callbacks.clear()

    async def cancel(self) -> None:
        """Cancel workflow execution."""
        self._cancelled = True

    def _check_cancelled(self) -> None:
        """Check if workflow was cancelled."""
        if self._cancelled:
            raise WorkflowCancelledException("Workflow was cancelled")

    async def _report_progress(
        self,
        workflow_id: str,
        phase: str,
        progress: int,
        message: str,
    ) -> None:
        """
        Report workflow progress.

        Args:
            workflow_id: Workflow ID
            phase: Current phase name
            progress: Progress percentage (0-100)
            message: Progress message
        """
        update = WorkflowProgress(
            workflow_id=workflow_id,
            phase=phase,
            progress=progress,
            message=message,
        )
        for callback in self._progress_callbacks:
            callback(update)

    async def _execute_agent(
        self,
        agent: BaseAgent,
        task: str,
        context: AgentContext,
    ) -> AgentResult:
        """
        Execute an agent as part of workflow.

        Args:
            agent: Agent instance
            task: Task description
            context: Agent execution context

        Returns:
            AgentResult: Agent execution result
        """
        self._check_cancelled()
        return await agent.execute(task, context)


class WorkflowError(Exception):
    """Base exception for workflow errors."""
    pass


class WorkflowValidationError(WorkflowError):
    """Raised when workflow validation fails."""
    pass


class WorkflowCancelledException(WorkflowError):
    """Raised when workflow is cancelled."""
    pass
