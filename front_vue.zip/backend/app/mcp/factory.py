"""
@file factory.py
@author caoshwen
@brief MCP server factory for registration and initialization.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from loguru import logger

from app.core.config import Settings
from app.mcp.client import MCPClient
from app.mcp.servers.jira_server import JiraMCPServer
from app.mcp.servers.bitbucket_server import BitbucketMCPServer
from app.mcp.servers.stm32_server import STM32MCPServer
from app.mcp.servers.qbs_server import QBSMCPServer
from app.mcp.servers.external_search_server import ExternalSearchMCPServer
from app.mcp.servers.local_git_server import LocalGitMCPServer
from app.services.git_review import GitReviewService


def create_mcp_client(settings: Settings) -> MCPClient:
    """
    Create MCPClient from configuration and register all available MCP Servers.

    Only Servers with configured connection credentials will be registered.
    STM32 and QBS are always registered as local tools.

    Args:
        settings: Application configuration

    Returns:
        MCPClient: Initialized MCPClient instance
    """
    client = MCPClient()

    # 1. Jira (requires base_url + email + api_token)
    if settings.JIRA_BASE_URL and settings.JIRA_EMAIL and settings.JIRA_API_TOKEN:
        client.register(JiraMCPServer(
            base_url=settings.JIRA_BASE_URL,
            email=settings.JIRA_EMAIL,
            api_token=settings.JIRA_API_TOKEN,
        ))
        logger.info("Registered Jira MCP server")

    # 2. Bitbucket (requires base_url + username + app_password)
    if settings.BITBUCKET_BASE_URL and settings.BITBUCKET_USERNAME and settings.BITBUCKET_APP_PASSWORD:
        client.register(BitbucketMCPServer(
            base_url=settings.BITBUCKET_BASE_URL,
            username=settings.BITBUCKET_USERNAME,
            app_password=settings.BITBUCKET_APP_PASSWORD,
            workspace=settings.BITBUCKET_WORKSPACE or "",
        ))
        logger.info("Registered Bitbucket MCP server")

    # 3. STM32 (local toolchain, always registered)
    client.register(STM32MCPServer())
    logger.info("Registered STM32 MCP server")

    # 4. QBS (local build tool, always registered)
    client.register(QBSMCPServer(
        qbs_path=settings.QBS_PATH,
        timeout=settings.QBS_TIMEOUT,
    ))
    logger.info("Registered QBS MCP server")

    # 5. External public web search and page retrieval tools
    client.register(ExternalSearchMCPServer())
    logger.info("Registered external search MCP server")

    # Local Git is a read-only tool used by Code Review agents.
    client.register(LocalGitMCPServer(GitReviewService(settings.GIT_REPOSITORY_PATH)))
    logger.info("Registered local Git MCP server")

    tools = client.list_tools()
    logger.info(f"MCPClient ready with {len(tools)} tools")

    return client
