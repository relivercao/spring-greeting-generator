"""
@file client.py
@author caoshwen
@brief MCPClient - unified tool facade with parallel execution.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
from typing import Any

from loguru import logger

from app.mcp.base import (
    BaseMCPServer,
    ToolDefinition,
    ToolResult,
    ToolNotFoundError,
    ToolExecutionError,
)


class MCPClient:
    """
    MCP unified invocation facade.

    Responsibilities:
    - Register MCP Servers
    - Tool discovery (list_tools)
    - Automatic routed invocation (call_tool)
    - Parallel batch invocation (call_tools_parallel)
    - Health checking

    Usage example:
        client = MCPClient()
        client.register(JiraMCPServer(config))
        client.register(BitbucketMCPServer(config))

        bugs = await client.call_tool("jira_get_bugs", project="PROJ")
        diff = await client.call_tool("bb_get_diff", repo="firmware", pr_id=42)
    """

    def __init__(self):
        self._servers: dict[str, BaseMCPServer] = {}
        self._tool_registry: dict[str, tuple[BaseMCPServer, str]] = {}
        # tool_registry: {"jira_get_bugs": (JiraMCPServer, "get_bugs"), ...}

    # ========== Server Management ==========

    def register(self, server: BaseMCPServer) -> None:
        """
        Register an MCP Server and index all its tools.
        Tool names are automatically prefixed with server name: server_name + "_" + tool_name
        """
        self._servers[server.server_name] = server
        for tool in server.tools:
            full_name = f"{server.server_name}_{tool.name}"
            self._tool_registry[full_name] = (server, tool.name)

        logger.info(
            f"Registered MCP server: {server.server_name} "
            f"({len(server.tools)} tools)"
        )

    def list_tools(self) -> list[dict[str, Any]]:
        """List all available tools with their JSON Schema (for LLM function calling)"""
        result = []
        for server in self._servers.values():
            for tool in server.tools:
                result.append({
                    "name": f"{server.server_name}_{tool.name}",
                    "description": tool.description,
                    "input_schema": tool.input_schema,
                    "server": server.server_name,
                })
        return result

    # ========== Tool Invocation ==========

    async def call_tool(self, tool_name: str, **kwargs) -> ToolResult:
        """
        Call the specified tool (automatically routes to corresponding MCP Server).

        Args:
            tool_name: Full tool name, e.g. "jira_get_bugs"
            **kwargs: Tool parameters

        Returns:
            ToolResult: Unified result

        Raises:
            ToolNotFoundError: Tool name does not exist
        """
        if tool_name not in self._tool_registry:
            raise ToolNotFoundError(f"Tool {tool_name} not registered")

        server, local_name = self._tool_registry[tool_name]

        try:
            return await server.call_tool(local_name, kwargs)
        except ToolNotFoundError:
            raise
        except Exception as e:
            logger.error(f"Tool execution failed: {tool_name} - {e}")
            raise ToolExecutionError(
                f"Tool {tool_name} execution failed: {e}",
                tool_name=tool_name,
                details=str(e),
            )

    # ========== Parallel Batch Invocation ==========

    async def call_tools_parallel(
        self,
        calls: list[dict[str, Any]],
    ) -> list[ToolResult]:
        """
        Call multiple tools in parallel.

        Args:
            calls: [{"name": "jira_get_bugs", "args": {...}}, ...]

        Returns:
            Result list of same length as calls
        """
        tasks = [
            self.call_tool(c["name"], **c.get("args", {}))
            for c in calls
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Wrap exceptions as ToolResult
        wrapped = []
        for i, r in enumerate(results):
            if isinstance(r, Exception):
                wrapped.append(ToolResult(
                    success=False,
                    error=str(r),
                    metadata={"tool_name": calls[i]["name"]},
                ))
            else:
                wrapped.append(r)
        return wrapped

    # ========== Health Check ==========

    async def check_all_health(self) -> dict[str, bool]:
        """Check health status of all MCP Servers in parallel"""
        results = {}
        for name, server in self._servers.items():
            try:
                results[name] = await asyncio.wait_for(
                    server.health_check(), timeout=10.0
                )
            except Exception:
                results[name] = False
        return results

    # ========== Initialization & Shutdown ==========

    async def initialize_all(self) -> None:
        """Initialize all registered MCP Servers"""
        for server in self._servers.values():
            try:
                await server.initialize()
                logger.info(f"Initialized MCP server: {server.server_name}")
            except Exception as e:
                logger.error(f"Failed to initialize {server.server_name}: {e}")

    async def shutdown_all(self) -> None:
        """Shutdown all MCP Servers"""
        for server in self._servers.values():
            try:
                await server.shutdown()
            except Exception as e:
                logger.warning(f"Error shutting down {server.server_name}: {e}")
