"""
@file utils.py
@author caoshwen
@brief Common utilities for MCP servers - retry logic, validation, caching.

@version 3.2
@date 2026-08-01

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""

import asyncio
from datetime import datetime, timedelta
from functools import wraps
from typing import Any, Callable, Optional

import httpx
from loguru import logger

from app.mcp.base import ToolResult


# ==================== HTTP Retry Logic ====================


async def http_request_with_retry(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    max_retries: int = 3,
    backoff_factor: float = 2.0,
    **kwargs
) -> httpx.Response:
    """
    Execute HTTP request with exponential backoff retry.

    Args:
        client: AsyncClient instance
        method: HTTP method (GET, POST, etc.)
        url: Request URL
        max_retries: Maximum retry attempts (default: 3)
        backoff_factor: Exponential backoff multiplier (default: 2.0)
        **kwargs: Additional request parameters

    Returns:
        httpx.Response: Successful response

    Raises:
        httpx.HTTPStatusError: After max retries for server errors
        httpx.RequestError: After max retries for connection errors
    """
    last_exception = None

    for attempt in range(max_retries):
        try:
            response = await client.request(method, url, **kwargs)
            response.raise_for_status()
            return response

        except httpx.HTTPStatusError as e:
            last_exception = e
            # Don't retry client errors (4xx)
            if 400 <= e.response.status_code < 500:
                logger.warning(f"HTTP {e.response.status_code} (client error), not retrying")
                raise

            # Retry server errors (5xx)
            if attempt < max_retries - 1:
                wait_time = backoff_factor ** attempt
                logger.warning(
                    f"HTTP {e.response.status_code} (server error), "
                    f"retrying in {wait_time}s (attempt {attempt + 1}/{max_retries})"
                )
                await asyncio.sleep(wait_time)
            else:
                logger.error(f"Max retries reached for {method} {url}")
                raise

        except httpx.RequestError as e:
            last_exception = e
            if attempt < max_retries - 1:
                wait_time = backoff_factor ** attempt
                logger.warning(
                    f"Request error ({type(e).__name__}), "
                    f"retrying in {wait_time}s (attempt {attempt + 1}/{max_retries})"
                )
                await asyncio.sleep(wait_time)
            else:
                logger.error(f"Max retries reached for {method} {url}: {e}")
                raise

    # Should never reach here, but just in case
    if last_exception:
        raise last_exception


async def safe_http_call(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    timeout: float = 30.0,
    **kwargs
) -> ToolResult:
    """
    Wrap HTTP call with timeout and unified error handling.

    Args:
        client: AsyncClient instance
        method: HTTP method
        url: Request URL
        timeout: Timeout in seconds
        **kwargs: Additional request parameters

    Returns:
        ToolResult: Success with data or failure with error message
    """
    try:
        response = await asyncio.wait_for(
            http_request_with_retry(client, method, url, **kwargs),
            timeout=timeout
        )

        # Try to parse JSON, fallback to text
        try:
            data = response.json()
        except Exception:
            data = {"text": response.text}

        return ToolResult(
            success=True,
            data=data,
            metadata={"status_code": response.status_code}
        )

    except asyncio.TimeoutError:
        logger.error(f"Request timed out after {timeout}s: {method} {url}")
        return ToolResult(
            success=False,
            error=f"Request timed out after {timeout}s"
        )

    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code} - {e.response.text[:200]}")
        return ToolResult(
            success=False,
            error=f"HTTP {e.response.status_code}: {e.response.text[:200]}",
            metadata={"status_code": e.response.status_code}
        )

    except httpx.RequestError as e:
        logger.error(f"Request error: {type(e).__name__} - {str(e)}")
        return ToolResult(
            success=False,
            error=f"Request failed: {type(e).__name__} - {str(e)}"
        )

    except Exception as e:
        logger.exception(f"Unexpected error in HTTP call: {e}")
        return ToolResult(
            success=False,
            error=f"Unexpected error: {type(e).__name__} - {str(e)}"
        )


# ==================== Input Validation ====================


def validate_required_fields(*required_fields: str) -> Callable:
    """
    Decorator to validate required fields in tool arguments.

    Args:
        *required_fields: Field names that must be present and non-empty

    Returns:
        Decorated function that returns error ToolResult if validation fails

    Example:
        @validate_required_fields("repo", "path")
        async def _get_file(self, args: dict[str, Any]) -> ToolResult:
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(self, args: dict[str, Any]) -> ToolResult:
            missing = []
            for field in required_fields:
                value = args.get(field)
                if value is None or (isinstance(value, str) and not value.strip()):
                    missing.append(field)

            if missing:
                error_msg = f"Missing or empty required fields: {', '.join(missing)}"
                logger.warning(f"{func.__name__}: {error_msg}")
                return ToolResult(
                    success=False,
                    error=error_msg,
                    metadata={"missing_fields": missing}
                )

            return await func(self, args)
        return wrapper
    return decorator


def validate_field_type(field: str, expected_type: type) -> Callable:
    """
    Decorator to validate field type in tool arguments.

    Args:
        field: Field name to validate
        expected_type: Expected Python type

    Returns:
        Decorated function that returns error ToolResult if validation fails
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(self, args: dict[str, Any]) -> ToolResult:
            value = args.get(field)
            if value is not None and not isinstance(value, expected_type):
                error_msg = (
                    f"Field '{field}' must be {expected_type.__name__}, "
                    f"got {type(value).__name__}"
                )
                logger.warning(f"{func.__name__}: {error_msg}")
                return ToolResult(
                    success=False,
                    error=error_msg
                )

            return await func(self, args)
        return wrapper
    return decorator


# ==================== Response Caching ====================


class SimpleCache:
    """
    Simple TTL-based in-memory cache for MCP server responses.

    Thread-safe for asyncio operations.
    """

    def __init__(self, default_ttl: int = 300):
        """
        Initialize cache.

        Args:
            default_ttl: Default time-to-live in seconds (default: 5 minutes)
        """
        self._cache: dict[str, tuple[Any, datetime]] = {}
        self._default_ttl = timedelta(seconds=default_ttl)

    def get(self, key: str, ttl: Optional[timedelta] = None) -> Optional[Any]:
        """
        Get cached value if not expired.

        Args:
            key: Cache key
            ttl: Optional custom TTL (uses default if None)

        Returns:
            Cached value or None if expired/not found
        """
        if key not in self._cache:
            return None

        value, timestamp = self._cache[key]
        max_age = ttl or self._default_ttl

        if datetime.now() - timestamp < max_age:
            logger.debug(f"Cache hit: {key}")
            return value

        # Expired, remove it
        logger.debug(f"Cache expired: {key}")
        del self._cache[key]
        return None

    def set(self, key: str, value: Any) -> None:
        """
        Set cached value with current timestamp.

        Args:
            key: Cache key
            value: Value to cache
        """
        self._cache[key] = (value, datetime.now())
        logger.debug(f"Cache set: {key}")

    def delete(self, key: str) -> bool:
        """
        Delete cached value.

        Args:
            key: Cache key

        Returns:
            True if key existed, False otherwise
        """
        if key in self._cache:
            del self._cache[key]
            logger.debug(f"Cache deleted: {key}")
            return True
        return False

    def clear(self) -> None:
        """Clear all cached values."""
        count = len(self._cache)
        self._cache.clear()
        logger.info(f"Cache cleared: {count} entries removed")

    def size(self) -> int:
        """Get current cache size."""
        return len(self._cache)

    def cleanup_expired(self) -> int:
        """
        Remove expired entries from cache.

        Returns:
            Number of entries removed
        """
        now = datetime.now()
        expired_keys = [
            key for key, (_, timestamp) in self._cache.items()
            if now - timestamp >= self._default_ttl
        ]

        for key in expired_keys:
            del self._cache[key]

        if expired_keys:
            logger.info(f"Cache cleanup: removed {len(expired_keys)} expired entries")

        return len(expired_keys)


def cached(cache_key_func: Callable[[dict[str, Any]], str], ttl: int = 300) -> Callable:
    """
    Decorator to cache tool results.

    Args:
        cache_key_func: Function to generate cache key from arguments
        ttl: Time-to-live in seconds

    Returns:
        Decorated function with caching

    Example:
        @cached(lambda args: f"file:{args['repo']}:{args['path']}", ttl=600)
        async def _get_file(self, args: dict[str, Any]) -> ToolResult:
            ...
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(self, args: dict[str, Any]) -> ToolResult:
            # Check if server has cache attribute
            if not hasattr(self, '_cache'):
                self._cache = SimpleCache(default_ttl=ttl)

            # Generate cache key
            try:
                cache_key = cache_key_func(args)
            except Exception as e:
                logger.warning(f"Failed to generate cache key: {e}")
                # Proceed without caching
                return await func(self, args)

            # Try to get from cache
            cached_result = self._cache.get(cache_key, timedelta(seconds=ttl))
            if cached_result is not None:
                return cached_result

            # Execute function
            result = await func(self, args)

            # Cache successful results only
            if result.success:
                self._cache.set(cache_key, result)

            return result

        return wrapper
    return decorator


# ==================== Error Result Builders ====================


def error_result(error_message: str, **metadata) -> ToolResult:
    """
    Build error ToolResult with consistent format.

    Args:
        error_message: Error description
        **metadata: Additional metadata fields

    Returns:
        ToolResult with success=False
    """
    return ToolResult(
        success=False,
        error=error_message,
        metadata=metadata
    )


def success_result(data: Any, **metadata) -> ToolResult:
    """
    Build success ToolResult with consistent format.

    Args:
        data: Result data
        **metadata: Additional metadata fields

    Returns:
        ToolResult with success=True
    """
    return ToolResult(
        success=True,
        data=data,
        metadata=metadata
    )
