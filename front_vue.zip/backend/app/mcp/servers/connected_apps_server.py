"""Request-scoped tools for the authenticated user's connected applications."""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import quote

from jsonschema import Draft7Validator, SchemaError

from app.mcp.base import BaseMCPServer, ToolDefinition, ToolNotFoundError, ToolResult
from app.services.app_connections import AppConnectionError, AppConnectionsService
from app.services.connection_catalog import oauth_catalog


_TOOLKITS = {"google-drive": "googledrive", "google-calendar": "googlecalendar"}


def _input_schema(raw: Any) -> dict:
    if not isinstance(raw, dict):
        raise AppConnectionError("The application tool has an invalid input schema.")
    if raw.get("type") == "object" or "properties" in raw:
        return raw
    return {
        "type": "object", "properties": {
            name: {key: value for key, value in definition.items() if key != "required" or not isinstance(value, bool)}
            if isinstance(definition, dict) else definition for name, definition in raw.items()
        },
        "required": [name for name, value in raw.items() if isinstance(value, dict) and value.get("required") is True],
    }


class ConnectedAppsMCPServer(BaseMCPServer):
    """Bind account ownership to a trusted request identity, never model arguments."""

    def __init__(self, user_id: str, service: AppConnectionsService | None = None, *, feishu_tools=None):
        if not user_id or user_id in {"guest", "anonymous", "unknown"} or user_id.startswith("g-"):
            raise ValueError("Application tools require an authenticated user")
        self.user_id = user_id
        self._service = service or AppConnectionsService()
        self._discovered: dict[tuple[str, str], dict] = {}
        self._executions: dict[str, ToolResult] = {}
        from app.services.feishu_tools import FeishuBotTools
        self._feishu = feishu_tools or (FeishuBotTools(user_id) if service is None else None)

    @property
    def server_name(self) -> str:
        return "connected_apps"

    @property
    def description(self) -> str:
        return "Use the current user's authorized app accounts to complete requested work."

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition("list_apps", "List the current user's active connected apps.", {"type": "object", "properties": {}, "additionalProperties": False}),
            ToolDefinition("search_tools", "Discover tools and their input schemas for an active app.", {
                "type": "object", "properties": {"app": {"type": "string"}, "query": {"type": "string"}},
                "required": ["app"], "additionalProperties": False,
            }),
            ToolDefinition("execute_tool", "Execute a previously discovered app tool for the user's explicit request.", {
                "type": "object", "properties": {
                    "app": {"type": "string"}, "tool": {"type": "string"}, "arguments": {"type": "object"},
                }, "required": ["app", "tool", "arguments"], "additionalProperties": False,
            }),
        ]

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        definition = next((tool for tool in self.tools if tool.name == tool_name), None)
        if definition is None:
            raise ToolNotFoundError(f"Unknown connected application tool: {tool_name}")
        if not Draft7Validator(definition.input_schema).is_valid(arguments):
            return ToolResult(success=False, error="Invalid connected application tool arguments")
        try:
            if tool_name == "list_apps":
                catalog = await oauth_catalog(self._service, self.user_id)
                if self._feishu is not None:
                    catalog["apps"].append(await self._feishu.catalog_entry())
                data = {"apps": [
                    {"slug": app["slug"], "name": app["name"]}
                    for app in catalog["apps"] if app["connected"]
                ]}
                if catalog.get("warning"):
                    data["warning"] = catalog["warning"]
                return ToolResult(success=True, data=data)
            app = arguments["app"]
            if app == "feishu" and self._feishu is not None:
                if tool_name == "search_tools":
                    return ToolResult(success=True, data=await self._feishu.search())
                result = await self._feishu.execute(arguments["tool"], arguments["arguments"])
                return ToolResult(**result, metadata={"app": app, "tool": arguments["tool"]})
            account = await self._active_account(app)
            if tool_name == "search_tools":
                return await self._search(app, arguments.get("query", ""))
            return await self._execute(app, arguments["tool"], arguments["arguments"], account)
        except AppConnectionError as error:
            return ToolResult(success=False, error=str(error))

    async def _active_account(self, app: str) -> dict:
        configs = self._service._require_provider(app)
        if app not in configs:
            raise AppConnectionError("This application is not configured for connections yet.", 503)
        accounts = await self._service._list_accounts(self.user_id)
        active = [account for account in accounts if (
            self._service._account_auth_config_id(account) == configs[app]
            and str(account.get("status", "")).upper() == "ACTIVE" and account.get("id")
        )]
        if not active:
            raise AppConnectionError("Connect this application in Settings before using its tools.", 409)
        if len(active) > 1:
            raise AppConnectionError("Multiple active accounts were found. Disconnect and reconnect the account to use.", 409)
        return active[0]

    async def _search(self, app: str, query: str) -> ToolResult:
        toolkit = _TOOLKITS.get(app, app)
        response = await self._service._request("GET", "/tools", params={
            "toolkit_slug": toolkit, "query": query[:250], "limit": "12",
            "toolkit_versions": "latest", "include_deprecated": "false",
        })
        items = response.get("items")
        if not isinstance(items, list):
            raise AppConnectionError("The application provider returned an invalid tool list.")
        tools = []
        for item in items:
            if not isinstance(item, dict) or not isinstance(item.get("toolkit"), dict):
                continue
            slug = str(item.get("slug", ""))
            if item["toolkit"].get("slug") != toolkit or not re.fullmatch(r"[A-Za-z0-9_]+", slug):
                continue
            if item.get("is_deprecated") or not item.get("version"):
                continue
            schema = _input_schema(item.get("input_parameters"))
            try:
                Draft7Validator.check_schema(schema)
            except SchemaError as error:
                raise AppConnectionError("The application tool has an invalid input schema.") from error
            self._discovered[(app, slug)] = {"schema": schema, "version": item["version"]}
            tools.append({"tool": slug, "description": str(item.get("description", ""))[:1800], "input_schema": schema})
        return ToolResult(success=True, data={"app": app, "tools": tools})

    async def _execute(self, app: str, tool: str, arguments: dict, account: dict) -> ToolResult:
        discovered = self._discovered.get((app, tool))
        if discovered is None:
            raise AppConnectionError("Discover the application tool before executing it.", 422)
        if not Draft7Validator(discovered["schema"]).is_valid(arguments):
            raise AppConnectionError("The tool arguments do not match its input schema.", 422)
        signature = json.dumps([app, tool, account["id"], arguments], sort_keys=True, ensure_ascii=True)
        if signature in self._executions:
            return self._executions[signature]
        # No automatic retries: a timeout may occur after a remote write succeeds.
        result = ToolResult(success=False, error="Execution was attempted; its outcome is unknown. Do not repeat it automatically.")
        self._executions[signature] = result
        try:
            response = await self._service._request("POST", f"/tools/execute/{quote(tool, safe='')}", payload={
                "connected_account_id": account["id"], "user_id": self._service._user_id(self.user_id),
                "version": discovered["version"], "arguments": arguments,
            })
        except AppConnectionError as error:
            raise AppConnectionError(result.error) from error
        result = ToolResult(
            success=response.get("successful") is True,
            data=response.get("data"),
            error=None if response.get("successful") is True else "The application reported that the operation failed.",
            metadata={"app": app, "tool": tool},
        )
        self._executions[signature] = result
        return result
