"""
@file qbs_server.py
@author caoshwen
@brief QBSMCPServer - QBS build system tool server.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
import os
import shutil
from pathlib import Path
from typing import Any, Optional

from loguru import logger

from app.mcp.base import (
    BaseMCPServer,
    ToolDefinition,
    ToolResult,
    ToolNotFoundError,
    ToolExecutionError,
)


class QBSMCPServer(BaseMCPServer):
    """
    QBS (Qt Build System) MCP Server.

    Provides project building, cleaning, test execution and dependency resolution
    capabilities through qbs CLI.
    Used for firmware projects using the QBS build system.
    """

    @staticmethod
    def _is_stale_build_graph_error(stderr: str) -> bool:
        stderr_lower = (stderr or "").lower()
        return (
            "cannot use stored build graph" in stderr_lower
            or "stored build graph" in stderr_lower and "cannot be found" in stderr_lower
            or "build graph" in stderr_lower and "cannot be found" in stderr_lower
            or "build graph does not yet exist" in stderr_lower
            or "stored build graph" in stderr_lower and "incompatible" in stderr_lower
            or "build graph" in stderr_lower and "incompatible" in stderr_lower
            or "build graph restore" in stderr_lower and "failed" in stderr_lower
            or "stored build graph" in stderr_lower and "project file" in stderr_lower and "input file" in stderr_lower
            or "restoring build graph from disk" in stderr_lower and "input file is" in stderr_lower
        )

    def __init__(
        self,
        qbs_path: str = "qbs",
        timeout: float = 300.0,
    ):
        self._qbs_path = qbs_path
        self._timeout = timeout

    @staticmethod
    def _validate_project_paths(
        project_path: str,
        project_file: Optional[str] = None,
    ) -> Optional[ToolResult]:
        qbs_dir = Path(project_path)
        if not qbs_dir.is_dir():
            error = f"QBS project directory not found: {qbs_dir}"
            return ToolResult(
                success=False,
                data={
                    "returncode": None,
                    "stdout": "",
                    "stderr": error,
                    "error_code": "qbs_project_directory_missing",
                    "retryable": False,
                },
                error=error,
            )
        if project_file and not Path(project_file).is_file():
            error = f"QBS project file not found: {project_file}"
            return ToolResult(
                success=False,
                data={
                    "returncode": None,
                    "stdout": "",
                    "stderr": error,
                    "error_code": "qbs_project_file_missing",
                    "retryable": False,
                },
                error=error,
            )
        return None

    # ---------- Metadata ----------

    @property
    def server_name(self) -> str:
        return "qbs"

    @property
    def description(self) -> str:
        return (
            "QBS build system tools. Provides project building, cleaning, test running, "
            "build artifact inspection and dependency resolution functionality. "
            "For firmware projects using the QBS build system."
        )

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="build",
                description="Build QBS project",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project_path": {"type": "string", "description": "Project directory path"},
                        "profile": {"type": "string", "description": "Build profile (e.g. arm-gcc)"},
                        "configuration": {"type": "string", "default": "debug", "description": "Configuration: debug/release"},
                        "products": {"type": "array", "items": {"type": "string"}, "description": "Specify list of products to build"},
                        "jobs": {"type": "integer", "description": "Number of parallel jobs"},
                        "project_file": {"type": "string", "description": "Specify .qbs project file path (qbs build -f)"},
                    },
                    "required": ["project_path"],
                },
            ),
            ToolDefinition(
                name="clean",
                description="Clean QBS build artifacts",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project_path": {"type": "string", "description": "Project directory path"},
                        "all_artifacts": {"type": "boolean", "default": False, "description": "Whether to clean all artifacts"},
                    },
                    "required": ["project_path"],
                },
            ),
            ToolDefinition(
                name="run_tests",
                description="Run tests for QBS project",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project_path": {"type": "string", "description": "Project directory path"},
                        "filter": {"type": "string", "description": "Test filter (product name or wildcard)"},
                        "profile": {"type": "string", "description": "Build profile"},
                    },
                    "required": ["project_path"],
                },
            ),
            ToolDefinition(
                name="get_products",
                description="Get list of project build products",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project_path": {"type": "string", "description": "Project directory path"},
                    },
                    "required": ["project_path"],
                },
            ),
            ToolDefinition(
                name="resolve",
                description="Resolve project dependencies",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project_path": {"type": "string", "description": "Project directory path"},
                        "profile": {"type": "string", "description": "Build profile"},
                    },
                    "required": ["project_path"],
                },
            ),
        ]

    # ---------- Lifecycle ----------

    async def initialize(self) -> None:
        # Automatically detect the path
        from app.core.config import (
            get_resolved_qbs_path, get_qbs_settings_dir,
            get_qbs_bin_dir, get_mingw_bin_dir,
        )
        resolved = get_resolved_qbs_path()
        if resolved != self._qbs_path:
            logger.info(f"QBS path resolved: {self._qbs_path!r} -> {resolved!r}")
            self._qbs_path = resolved

        # Cache settings-dir, bin-dir, and mingw-dir for later use
        self._settings_dir = get_qbs_settings_dir()
        self._bin_dir = get_qbs_bin_dir()
        self._mingw_bin_dir = get_mingw_bin_dir()

        available = await self._check_tool()
        if not available:
            logger.warning("QBS CLI not found, qbs tools may fail")
            return

        # Get version information
        stdout, _, rc = await self._run_cmd([self._qbs_path, "--version"], timeout=5.0)
        if rc == 0:
            logger.info(f"QBS MCP server initialized, version: {stdout.strip()}")

        # Initial toolchain detection + profile setup
        await self._setup_toolchain()

    async def shutdown(self) -> None:
        pass

    # ---------- Core Methods ----------

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        dispatch = {
            "build": self._build,
            "clean": self._clean,
            "run_tests": self._run_tests,
            "get_products": self._get_products,
            "resolve": self._resolve,
        }

        handler = dispatch.get(tool_name)
        if handler is None:
            raise ToolNotFoundError(f"QBS tool '{tool_name}' not found")

        try:
            return await handler(arguments)
        except ToolNotFoundError:
            raise
        except Exception as e:
            raise ToolExecutionError(
                f"QBS tool '{tool_name}' failed: {e}",
                tool_name=tool_name,
                details=str(e),
            )

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        return await self._check_tool()

    # ---------- Tool Implementation ----------

    async def _build(self, args: dict[str, Any]) -> ToolResult:
        project_path = args["project_path"]
        profile = args.get("profile")
        configuration = args.get("configuration", "debug")
        products = args.get("products", [])
        jobs = args.get("jobs")
        project_file = args.get("project_file")

        preflight_error = self._validate_project_paths(project_path, project_file)
        if preflight_error:
            return preflight_error

        cmd = self._build_cmd(project_path, profile, configuration, products, jobs, project_file)

        # Builds can legitimately run for many hours for large firmware
        # projects.  Task cancellation remains available through the owning
        # asyncio task; the QBS subprocess itself must not be killed by a
        # short fixed wall-clock timeout.
        stdout, stderr, returncode = await self._run_cmd(cmd, unbounded=True)
        attempts = [{"command": list(cmd), "returncode": returncode, "stdout": stdout, "stderr": stderr}]

        # Fallback 1: corrupted/stale build graph → clean and retry
        if returncode != 0 and self._is_stale_build_graph_error(stderr):
            logger.warning("QBS build graph corrupted, cleaning entire build directory and retrying")
            # Clean all potential build directories
            dirs_to_clean = ["default", "debug", "release", ".qbs"]
            for dir_name in dirs_to_clean:
                dir_path = os.path.join(project_path, dir_name)
                if os.path.isdir(dir_path):
                    try:
                        shutil.rmtree(dir_path)
                        logger.info(f"[QBS] Cleaned: {dir_path}")
                    except OSError as exc:
                        logger.warning(f"QBS could not clean {dir_path}: {exc}")
            # The bundled QBS 3.3 does not support --clean-build.  Removing
            # the stale build graph above is sufficient; rerun the original
            # command so QBS creates a fresh graph for this project file.
            stdout, stderr, returncode = await self._run_cmd(
                list(cmd), unbounded=True
            )
            attempts.append({"command": list(cmd), "returncode": returncode, "stdout": stdout, "stderr": stderr})

        # Fallback 2: unknown/no product → retry without -p
        if returncode != 0 and products and (
            "unknown product" in stderr.lower()
            or "no product" in stderr.lower()
        ):
            logger.warning("QBS unknown product, retrying without -p filter")
            cmd = self._build_cmd(project_path, profile, configuration, [], jobs, project_file)
            stdout, stderr, returncode = await self._run_cmd(cmd, unbounded=True)
            attempts.append({"command": list(cmd), "returncode": returncode, "stdout": stdout, "stderr": stderr})

        return ToolResult(
            success=returncode == 0,
            data={
                "returncode": returncode,
                "stdout": stdout,
                "stderr": stderr,
                "configuration": configuration,
                "attempts": attempts,
                "error_code": "qbs_execution_failed" if returncode == -1 else "qbs_build_failed" if returncode != 0 else None,
                "retryable": returncode not in (0, -1),
            },
            error=stderr if returncode != 0 else None,
        )

    def _build_cmd(
        self,
        project_path: str,
        profile: Optional[str],
        configuration: str,
        products: list[str],
        jobs: Optional[int],
        project_file: Optional[str] = None,
    ) -> list[str]:
        """Assemble the qbs build command list."""
        cmd = [self._qbs_path, "build", "-d", project_path]

        if project_file:
            cmd.extend(["-f", project_file])

        # Required: pass --settings-dir, otherwise QBS cannot find the profile
        cmd.extend(["--settings-dir", self._settings_dir])

        if profile:
            cmd.extend(["profile:" + profile])
        cmd.extend(["config:" + configuration])

        for product in products:
            cmd.extend(["-p", product])

        if jobs:
            cmd.extend(["-j", str(jobs)])

        return cmd

    async def _clean(self, args: dict[str, Any]) -> ToolResult:
        project_path = args["project_path"]
        all_artifacts = args.get("all_artifacts", False)

        preflight_error = self._validate_project_paths(project_path)
        if preflight_error:
            return preflight_error

        cmd = [self._qbs_path, "clean", "-d", project_path, "--settings-dir", self._settings_dir]
        if all_artifacts:
            cmd.append("--all-artifacts")

        stdout, stderr, returncode = await self._run_cmd(cmd, unbounded=True)

        return ToolResult(
            success=returncode == 0,
            data={"returncode": returncode, "stdout": stdout},
            error=stderr if returncode != 0 else None,
        )

    async def _run_tests(self, args: dict[str, Any]) -> ToolResult:
        project_path = args["project_path"]
        test_filter = args.get("filter")
        profile = args.get("profile")

        preflight_error = self._validate_project_paths(project_path)
        if preflight_error:
            return preflight_error

        # Run tests (assuming the project has already been built via qbs_build)
        run_cmd = [self._qbs_path, "run", "-d", project_path, "--settings-dir", self._settings_dir]
        if test_filter:
            run_cmd.extend(["-p", test_filter])
        if profile:
            run_cmd.extend(["profile:" + profile])

        # Test binaries may include integration or hardware-simulation loops
        # that intentionally run longer than the historical five-minute MCP
        # default.  Leave lifetime control to task cancellation.
        stdout_r, stderr_r, rc_r = await self._run_cmd(run_cmd, unbounded=True)

        # `qbs run` can fail on transient wrapper issues (e.g. the build
        # graph is still locked by a build that just finished) while the
        # test binary itself is healthy; that failure carries no GTest
        # output on stdout.  Retry once so the real results are not lost.
        if rc_r != 0 and not stdout_r.strip() and rc_r != -1:
            logger.warning(
                "qbs run failed without test output (rc={}), retrying once: {}",
                rc_r,
                (stderr_r or "").strip()[:200],
            )
            await asyncio.sleep(2.0)
            stdout_r, stderr_r, rc_r = await self._run_cmd(run_cmd, unbounded=True)

        return ToolResult(
            success=rc_r == 0,
            data={
                "returncode": rc_r,
                "stdout": stdout_r,
                "stderr": stderr_r,
            },
            error=stderr_r if rc_r != 0 else None,
        )

    async def _get_products(self, args: dict[str, Any]) -> ToolResult:
        project_path = args["project_path"]

        preflight_error = self._validate_project_paths(project_path)
        if preflight_error:
            return preflight_error

        cmd = [self._qbs_path, "dump-nodes-tree", "-d", project_path, "--settings-dir", self._settings_dir]
        stdout, stderr, returncode = await self._run_cmd(cmd, unbounded=True)

        if returncode != 0:
            return ToolResult(
                success=False,
                error=f"Failed to get products: {stderr}",
            )

        # Try to parse JSON output
        try:
            tree = json.loads(stdout)
            products = self._extract_products(tree)
        except json.JSONDecodeError:
            products = [{"raw_output": stdout}]

        return ToolResult(success=True, data={"products": products})

    async def _resolve(self, args: dict[str, Any]) -> ToolResult:
        project_path = args["project_path"]
        profile = args.get("profile")

        preflight_error = self._validate_project_paths(project_path)
        if preflight_error:
            return preflight_error

        cmd = [self._qbs_path, "resolve", "-d", project_path, "--settings-dir", self._settings_dir]
        if profile:
            cmd.extend(["profile:" + profile])

        stdout, stderr, returncode = await self._run_cmd(cmd, unbounded=True)

        return ToolResult(
            success=returncode == 0,
            data={
                "returncode": returncode,
                "stdout": stdout,
                "stderr": stderr,
                "error_code": "qbs_resolve_failed" if returncode != 0 else None,
                "retryable": returncode != 0,
            },
            error=stderr if returncode != 0 else None,
        )

    # ---------- Internal Helpers ----------

    async def _setup_toolchain(self) -> None:
        """Register the toolchain on first run to ensure the profile is available.

        Directly register the bundled qbs-setup-toolchains (bin/qbs/bin/)
        with the bundled mingw gcc (bin/mingw/bin/) for the target profile.
        All operations use --settings-dir to point to the project-local settings directory,
        ensuring out-of-the-box behavior without relying on global QBS config or gcc from system PATH.
        """
        import os
        import platform as _plat
        from app.core.config import get_settings
        default_profile = get_settings().QBS_DEFAULT_PROFILE

        is_win = _plat.system() == "Windows"
        ext = ".exe" if is_win else ""
        config_cmd = os.path.join(self._bin_dir, f"qbs-config{ext}")
        setup_cmd = os.path.join(self._bin_dir, f"qbs-setup-toolchains{ext}")

        if not os.path.isfile(config_cmd):
            # No bundled qbs tooling (typical for Linux servers using a
            # system-wide qbs install). Fall back to the system qbs binary and
            # the system compiler so the project-local settings directory still
            # receives usable build profiles.
            await self._setup_system_toolchain_fallback(default_profile)
            return

        # Locate the bundled mingw gcc
        gcc_name = f"x86_64-w64-mingw32-gcc{ext}"
        gpp_name = f"x86_64-w64-mingw32-g++{ext}"
        gcc_path = os.path.join(self._mingw_bin_dir, gcc_name)
        gpp_path = os.path.join(self._mingw_bin_dir, gpp_name)

        # Check whether the profile already exists and whether its path is valid
        stdout, _, rc = await self._run_cmd(
            [config_cmd, "--list", "--settings-dir", self._settings_dir], timeout=10.0,
        )
        if rc == 0 and f"profiles.{default_profile}." in stdout:
            # The profile exists, but we still need to verify that toolchainInstallPath points to a valid location
            # QBS versions use either '=' or ':' between configuration keys and values.
            configured_path = None
            profile_key = f"profiles.{default_profile}.cpp.toolchainInstallPath"
            for line in stdout.splitlines():
                if not line.startswith(profile_key):
                    continue
                separator = "=" if "=" in line else ":" if ":" in line else None
                if separator:
                    configured_path = line.split(separator, 1)[1].strip().strip('"')
                    break

            if configured_path:
                # Check whether the configured compiler exists
                expected_gpp = os.path.join(configured_path, gpp_name)
                if os.path.isfile(expected_gpp):
                    logger.info(f"QBS profile '{default_profile}' already configured and valid in {self._settings_dir}")
                    return
                else:
                    # The path is stale (for example, after moving/copying the project), so it must be registered again
                    logger.warning(
                        f"QBS profile '{default_profile}' has stale toolchain path: "
                        f"configured={configured_path}, expected g++ not found. Re-registering..."
                    )
            else:
                logger.warning(f"QBS profile '{default_profile}' exists but toolchainInstallPath not found, re-registering...")

        # Temporary Windows-only strategy: support only the bundled MinGW to avoid depending on a system-installed toolchain
        if is_win:
            # Ensure the bundled mingw gcc exists
            if not os.path.isfile(gcc_path):
                logger.warning(
                    f"Bundled mingw gcc not found at {gcc_path}. "
                    "Windows mode requires bundled toolchain; skipping auto-detect."
                )
                return

        if not os.path.isfile(setup_cmd):
            logger.warning(f"Bundled qbs-setup-toolchains not found at {setup_cmd}")
            return

        # Register directly: qbs-setup-toolchains --settings-dir <dir> <compiler> <profile>
        logger.info(f"Registering bundled mingw gcc as profile '{default_profile}'")
        _, stderr, rc = await self._run_cmd(
            [setup_cmd, "--settings-dir", self._settings_dir, gcc_path, default_profile],
            timeout=30.0,
        )
        if rc == 0:
            logger.info(f"QBS profile '{default_profile}' created from bundled mingw at {gcc_path}")
        else:
            logger.warning(f"QBS profile registration failed: {stderr}")

    async def _setup_system_toolchain_fallback(self, default_profile: str) -> None:
        """Register system-compiler profiles via the system qbs binary.

        Used when the bundled qbs tools (bin/qbs/bin/) are unavailable, e.g. on
        Linux servers with a system-wide qbs install. Every qbs command this
        server issues carries ``--settings-dir``, so the detected system
        compiler must be registered into that project-local directory under the
        names build requests actually use: the configured default profile and,
        on non-Windows hosts, the ``host_gcc`` profile name used by host build
        requests.
        """
        import platform as _plat
        import shutil

        try:
            os.makedirs(self._settings_dir, exist_ok=True)
        except OSError as exc:
            logger.warning(f"Cannot create QBS settings dir {self._settings_dir}: {exc}")
            return

        compiler = next(
            (
                path
                for path in (
                    shutil.which(name) for name in ("g++", "c++", "clang++", "gcc")
                )
                if path and os.path.isfile(path)
            ),
            None,
        )
        if not compiler:
            logger.warning(
                "No system compiler found (g++/c++/clang++/gcc); skipping toolchain setup"
            )
            return

        profiles = {default_profile}
        if _plat.system() != "Windows":
            profiles.add("host_gcc")

        for profile in sorted(profiles):
            stdout, _, rc = await self._run_cmd(
                [self._qbs_path, "config", "--list", "--settings-dir", self._settings_dir],
                timeout=10.0,
            )
            if rc == 0 and f"profiles.{profile}." in stdout:
                logger.debug(f"QBS profile '{profile}' already registered in {self._settings_dir}")
                continue

            logger.info(f"Registering system compiler {compiler} as QBS profile '{profile}'")
            _, stderr, rc = await self._run_cmd(
                [
                    self._qbs_path, "setup-toolchains",
                    "--settings-dir", self._settings_dir,
                    compiler, profile,
                ],
                timeout=60.0,
            )
            if rc == 0:
                logger.info(f"QBS profile '{profile}' created from {compiler}")
            else:
                logger.warning(f"QBS profile '{profile}' registration failed: {stderr}")

        # Point defaultProfile at the registered toolchain so profile-less
        # commands (clean / dump-nodes-tree / run) resolve a toolchain too.
        _, stderr, rc = await self._run_cmd(
            [
                self._qbs_path, "config",
                "--settings-dir", self._settings_dir,
                "defaultProfile", default_profile,
            ],
            timeout=10.0,
        )
        if rc == 0:
            logger.info(f"QBS defaultProfile set to '{default_profile}' in {self._settings_dir}")
        else:
            logger.warning(f"QBS defaultProfile setup failed: {stderr}")

    async def _run_cmd(
        self,
        cmd: list[str],
        timeout: Optional[float] = None,
        unbounded: bool = False,
    ) -> tuple[str, str, int]:
        """Run a subprocess command with local QBS settings and bundled MinGW PATH injected."""
        timeout = timeout or self._timeout
        env = self._build_subprocess_env()
        proc = None
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            if unbounded:
                stdout, stderr = await proc.communicate()
            else:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            if len(cmd) > 1 and cmd[1] == "build" and "-d" in cmd:
                output_dir = Path(cmd[cmd.index("-d") + 1])
                try:
                    await asyncio.to_thread(self._save_build_output, output_dir, stdout, stderr)
                except OSError as exc:
                    logger.warning(f"QBS could not save raw build output: {exc}")
            return (
                self._decode_output(stdout, "stdout"),
                self._decode_output(stderr, "stderr"),
                proc.returncode,
            )
        except asyncio.TimeoutError:
            await self._stop_process(proc)
            return "", f"Command timed out after {timeout}s", -1
        except asyncio.CancelledError:
            await self._stop_process(proc)
            raise
        except FileNotFoundError:
            return "", f"Command not found: {cmd[0]}", -1
        except Exception as e:
            return "", str(e), -1

    @staticmethod
    def _save_build_output(directory: Path, stdout: bytes, stderr: bytes) -> None:
        """Keep the last build's original bytes for diagnostics after decoding."""
        (directory / "qbs-build.stdout.log").write_bytes(stdout)
        (directory / "qbs-build.stderr.log").write_bytes(stderr)

    @staticmethod
    async def _stop_process(proc) -> None:
        if proc is not None and proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass  # The process exited between the status check and kill.
            await proc.wait()

    @staticmethod
    def _decode_output(payload: bytes, stream_name: str) -> str:
        """Decode tool output without hiding the original process result."""
        if not payload:
            return ""
        text = payload.decode("utf-8", errors="replace")
        if "\ufffd" in text:
            logger.warning(
                f"QBS {stream_name} contained non-UTF-8 bytes; replaced invalid bytes"
            )
        return text

    def _build_subprocess_env(self) -> dict[str, str]:
        """Build a subprocess environment that prefers bundled toolchain paths."""
        import os

        env = os.environ.copy()

        if hasattr(self, "_settings_dir"):
            env["QBS_SETTINGS_DIR"] = self._settings_dir

        # Collect paths to prepend (bundled toolchain paths come first)
        prepend_paths = []
        
        # Ensure qbs run can load its own Qt5 DLLs (qbs.exe depends on Qt5*.dll in the same directory)
        if hasattr(self, "_bin_dir") and os.path.isdir(self._bin_dir):
            prepend_paths.append(self._bin_dir)

        # Ensure qbs run can load MinGW runtime DLLs; also avoid relying on gcc from system PATH.
        if hasattr(self, "_mingw_bin_dir") and os.path.isdir(self._mingw_bin_dir):
            prepend_paths.append(self._mingw_bin_dir)

        # Prepend all bundled paths at once (so bundled toolchain takes precedence over system versions)
        if prepend_paths:
            current_path = env.get("PATH", "")
            path_items = current_path.split(os.pathsep) if current_path else []
            # Add only if not already present to avoid duplicates
            new_paths = [p for p in prepend_paths if p not in path_items]
            if new_paths:
                new_path = os.pathsep.join(new_paths)
                if current_path:
                    new_path += os.pathsep + current_path
                env["PATH"] = new_path

        return env

    async def _check_tool(self) -> bool:
        """Check if QBS CLI is available."""
        _, _, returncode = await self._run_cmd([self._qbs_path, "--version"], timeout=5.0)
        return returncode == 0

    @staticmethod
    def _extract_products(tree: Any) -> list[dict[str, Any]]:
        """Extract product information from QBS nodes tree."""
        products = []
        if isinstance(tree, dict):
            if tree.get("type") == "product":
                products.append({
                    "name": tree.get("name", ""),
                    "type": tree.get("product-type", []),
                    "target_artifact": tree.get("target-artifact", ""),
                })
            for child in tree.get("children", []):
                products.extend(QBSMCPServer._extract_products(child))
        elif isinstance(tree, list):
            for item in tree:
                products.extend(QBSMCPServer._extract_products(item))
        return products
