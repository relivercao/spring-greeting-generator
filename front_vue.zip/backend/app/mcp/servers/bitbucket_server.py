"""
@file bitbucket_server.py
@author caoshwen
@brief BitbucketMCPServer - Bitbucket REST API tool server.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import Any, Optional
from urllib.parse import quote, urlsplit

import httpx
from loguru import logger

from app.mcp.base import (
    BaseMCPServer,
    ToolDefinition,
    ToolResult,
    ToolNotFoundError,
    ToolExecutionError,
)


class BitbucketMCPServer(BaseMCPServer):
    """
    Bitbucket MCP Server.

    Provides code repository operations through Bitbucket REST API:
    file reading, branch management, PR management, Diff viewing, etc.
    """

    def __init__(
        self,
        base_url: str,
        username: str,
        app_password: str,
        workspace: str = "",
        timeout: float = 30.0,
    ):
        self._base_url = base_url.rstrip("/")
        self._is_cloud = (
            urlsplit(self._base_url).hostname == "api.bitbucket.org"
            or self._base_url.endswith("/2.0")
        )
        for suffix in ("/2.0", "/rest/api/1.0", "/rest/api/latest"):
            if self._base_url.endswith(suffix):
                self._base_url = self._base_url[:-len(suffix)]
                break
        self._username = username
        self._app_password = app_password
        self._workspace = workspace
        self._timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    # ---------- Metadata ----------

    @property
    def server_name(self) -> str:
        return "bb"

    @property
    def description(self) -> str:
        return (
            "Bitbucket code repository tools. Provides file reading, branch creation, PR management, "
            "Diff viewing and file commit functionality. For code review and version control operations."
        )

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="get_file",
                description="Get content of specified file in repository",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "path": {"type": "string", "description": "File path"},
                        "ref": {"type": "string", "default": "main", "description": "Branch or commit ref"},
                    },
                    "required": ["repo", "path"],
                },
            ),
            ToolDefinition(
                name="create_branch",
                description="Create new branch from specified source",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "name": {"type": "string", "description": "New branch name"},
                        "target": {"type": "string", "default": "main", "description": "Source branch or commit hash"},
                    },
                    "required": ["repo", "name"],
                },
            ),
            ToolDefinition(
                name="create_pr",
                description="Create Pull Request",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "title": {"type": "string", "description": "PR title"},
                        "source_branch": {"type": "string", "description": "Source branch"},
                        "dest_branch": {"type": "string", "default": "main", "description": "Destination branch"},
                        "description": {"type": "string", "description": "PR description"},
                    },
                    "required": ["repo", "title", "source_branch"],
                },
            ),
            ToolDefinition(
                name="get_diff",
                description="Get Diff between PR or two commits",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "pr_id": {"type": "integer", "description": "PR ID"},
                        "spec": {"type": "string", "description": "Diff spec, e.g. 'main..feature'"},
                    },
                    "required": ["repo"],
                },
            ),
            ToolDefinition(
                name="merge_pr",
                description="Merge Pull Request",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "pr_id": {"type": "integer", "description": "PR ID"},
                        "merge_strategy": {"type": "string", "default": "merge_commit", "description": "Merge strategy: merge_commit/squash/fast_forward"},
                    },
                    "required": ["repo", "pr_id"],
                },
            ),
            ToolDefinition(
                name="get_tree",
                description="Get file tree of repository directory",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "path": {"type": "string", "default": "", "description": "Directory path"},
                        "ref": {"type": "string", "default": "main", "description": "Branch or commit ref"},
                    },
                    "required": ["repo"],
                },
            ),
            ToolDefinition(
                name="commit_file",
                description="Commit file to repository",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "path": {"type": "string", "description": "File path"},
                        "content": {"type": "string", "description": "File content"},
                        "message": {"type": "string", "description": "Commit message"},
                        "branch": {"type": "string", "default": "main", "description": "Destination branch"},
                    },
                    "required": ["repo", "path", "content", "message"],
                },
            ),
            ToolDefinition(
                name="list_prs",
                description="List Pull Requests of repository",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo": {"type": "string", "description": "Repository slug"},
                        "state": {"type": "string", "default": "OPEN", "description": "State: OPEN/MERGED/DECLINED"},
                    },
                    "required": ["repo"],
                },
            ),
            ToolDefinition(
                name="list_my_prs",
                description="List pull requests authored by the configured Bitbucket user",
                input_schema={
                    "type": "object",
                    "properties": {
                        "state": {"type": "string", "default": "OPEN", "description": "State: OPEN/MERGED/DECLINED"},
                        "max_results": {"type": "integer", "default": 20},
                    },
                },
            ),
        ]

    # ---------- Lifecycle ----------

    async def initialize(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            auth=(self._username, self._app_password),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=httpx.Timeout(self._timeout),
        )
        logger.info(f"Initialized Bitbucket MCP server (url={self._base_url})")

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    # ---------- Core Methods ----------

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        dispatch = {
            "get_file": self._get_file,
            "create_branch": self._create_branch,
            "create_pr": self._create_pr,
            "get_diff": self._get_diff,
            "merge_pr": self._merge_pr,
            "get_tree": self._get_tree,
            "commit_file": self._commit_file,
            "list_prs": self._list_prs,
            "list_my_prs": self._list_my_prs,
        }

        handler = dispatch.get(tool_name)
        if handler is None:
            raise ToolNotFoundError(f"Bitbucket tool '{tool_name}' not found")

        try:
            return await handler(arguments)
        except ToolNotFoundError:
            raise
        except Exception as e:
            raise ToolExecutionError(
                f"Bitbucket tool '{tool_name}' failed: {e}",
                tool_name=tool_name,
                details=str(e),
            )

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        try:
            if self._client is None:
                return False
            path = "/2.0/user" if self._is_cloud else "/rest/api/1.0/application-properties"
            resp = await self._client.get(path)
            return resp.status_code == 200
        except Exception as e:
            logger.debug(f"Bitbucket health check failed: {e}")
            return False

    # ---------- API Path Helpers ----------

    def _repo_path(self, repo: str) -> str:
        """Resolve a qualified workspace/project repository without losing its owner."""
        parts = str(repo).strip().split("/")
        if len(parts) == 1:
            owner = self._workspace if self._is_cloud else f"~{self._username}"
            parts = [owner, parts[0]]
        if len(parts) != 2 or any(not part or part in {".", ".."} for part in parts):
            raise ValueError("Use workspace/repository or project/repository")
        owner, slug = (quote(part, safe="") for part in parts)
        if self._is_cloud:
            return f"/2.0/repositories/{owner}/{slug}"
        return f"/rest/api/1.0/projects/{owner}/repos/{slug}"

    def _pr_path(self, repo: str) -> str:
        segment = "pullrequests" if self._is_cloud else "pull-requests"
        return f"{self._repo_path(repo)}/{segment}"

    @staticmethod
    def _file_path(path: str) -> str:
        parts = str(path).strip("/").split("/")
        if any(part in {".", ".."} for part in parts) or "\\" in str(path):
            raise ValueError("File path must remain inside the repository")
        return "/".join(quote(part, safe="") for part in parts)

    # ---------- Tool Implementation ----------

    async def _get_file(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        path = args["path"]
        ref = args.get("ref", "main")

        if self._is_cloud:
            url = f"{self._repo_path(repo)}/src/{quote(ref, safe='')}/{self._file_path(path)}"
            params = None
        else:
            url = f"{self._repo_path(repo)}/raw/{self._file_path(path)}"
            params = {"at": ref}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()

        content_type = resp.headers.get("content-type", "")
        if "application/json" in content_type:
            return ToolResult(success=True, data=resp.json())
        return ToolResult(success=True, data={"content": resp.text, "path": path, "ref": ref})

    async def _create_branch(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        name = args["name"]
        target = args.get("target", "main")

        resp = await self._client.post(
            f"{self._repo_path(repo)}/refs/branches",
            json={"name": name, "target": {"hash": target}},
        )
        resp.raise_for_status()
        return ToolResult(success=True, data={"branch": name, "created": True})

    async def _create_pr(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        payload = {
            "title": args["title"],
            "source": {"branch": {"name": args["source_branch"]}},
            "destination": {"branch": {"name": args.get("dest_branch", "main")}},
        }
        if args.get("description"):
            payload["description"] = args["description"]

        resp = await self._client.post(
            f"{self._pr_path(repo)}",
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
        return ToolResult(
            success=True,
            data={"id": data.get("id"), "title": data.get("title"), "state": data.get("state")},
        )

    async def _get_diff(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]

        if args.get("pr_id"):
            pr_id = int(args["pr_id"])
            if pr_id < 1:
                raise ValueError("Pull request ID must be positive")
            suffix = "/diff" if self._is_cloud else ".diff"
            resp = await self._client.get(f"{self._pr_path(repo)}/{pr_id}{suffix}")
        elif args.get("spec"):
            spec = str(args["spec"])
            if self._is_cloud:
                resp = await self._client.get(f"{self._repo_path(repo)}/diff/{quote(spec, safe='')}")
            else:
                revisions = spec.split("..", 1)
                if len(revisions) != 2 or not all(revisions):
                    raise ValueError("Diff spec must contain two revisions separated by '..'")
                resp = await self._client.get(
                    f"{self._repo_path(repo)}/diff", params={"from": revisions[0], "to": revisions[1]},
                    headers={"Accept": "text/plain"},
                )
        else:
            return ToolResult(success=False, error="Must provide pr_id or spec")

        resp.raise_for_status()
        return ToolResult(success=True, data={"diff": resp.text})

    async def _merge_pr(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        pr_id = args["pr_id"]
        strategy = args.get("merge_strategy", "merge_commit")

        resp = await self._client.post(
            f"{self._pr_path(repo)}/{pr_id}/merge",
            json={"merge_strategy": strategy},
        )
        resp.raise_for_status()
        return ToolResult(success=True, data={"pr_id": pr_id, "merged": True})

    async def _get_tree(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        path = args.get("path", "")
        ref = args.get("ref", "main")

        if self._is_cloud:
            url = f"{self._repo_path(repo)}/src/{quote(ref, safe='')}/{self._file_path(path)}"
            params = {"format": "meta"}
        else:
            url = f"{self._repo_path(repo)}/browse/{self._file_path(path)}"
            params = {"at": ref}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()

        entries = []
        for entry in data.get("values", data.get("children", {}).get("values", [])):
            entries.append({
                "path": (
                    entry["path"].get("toString", "") if isinstance(entry.get("path"), dict)
                    else entry.get("path", entry.get("name", ""))
                ),
                "type": entry.get("type", ""),
                "size": entry.get("size"),
            })

        return ToolResult(success=True, data={"path": path, "entries": entries})

    async def _commit_file(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        path = args["path"]
        content = args["content"]
        message = args["message"]
        branch = args.get("branch", "main")

        resp = await self._client.post(
            f"{self._repo_path(repo)}/src",
            data={path: content, "message": message, "branch": branch},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        return ToolResult(success=True, data={"path": path, "committed": True, "branch": branch})

    async def _list_prs(self, args: dict[str, Any]) -> ToolResult:
        repo = args["repo"]
        state = args.get("state", "OPEN")

        resp = await self._client.get(
            self._pr_path(repo),
            params={"state": state},
        )
        resp.raise_for_status()
        data = resp.json()

        prs = []
        for pr in data.get("values", []):
            prs.append({
                "id": pr.get("id"),
                "title": pr.get("title"),
                "state": pr.get("state"),
                "author": pr.get("author", {}).get("display_name") or pr.get("author", {}).get("user", {}).get("displayName"),
                "source_branch": pr.get("source", {}).get("branch", {}).get("name") or pr.get("fromRef", {}).get("displayId"),
                "dest_branch": pr.get("destination", {}).get("branch", {}).get("name") or pr.get("toRef", {}).get("displayId"),
            })

        return ToolResult(success=True, data={"total": len(prs), "pull_requests": prs})

    async def _list_my_prs(self, args: dict[str, Any]) -> ToolResult:
        """List pull requests for the authenticated Bitbucket account."""
        state = str(args.get("state") or "OPEN").upper()
        max_results = max(1, min(int(args.get("max_results", 20)), 50))
        if self._is_cloud:
            user_response = await self._client.get("/2.0/user")
            user_response.raise_for_status()
            user_data = user_response.json()
            username = quote(str(user_data.get("uuid") or user_data.get("username") or user_data.get("nickname") or self._username), safe="")
            response = await self._client.get(
                f"/2.0/pullrequests/{username}",
                params={"state": state, "pagelen": max_results},
            )
        else:
            response = await self._client.get(
                "/rest/api/1.0/dashboard/pull-requests",
                params={"state": state, "role": "AUTHOR", "limit": max_results},
            )
        response.raise_for_status()
        data = response.json()
        values = data.get("values", [])
        pull_requests = []
        for pull_request in values if isinstance(values, list) else []:
            repository = (
                pull_request.get("destination", {}).get("repository")
                or pull_request.get("toRef", {}).get("repository")
                or pull_request.get("repository") or {}
            )
            slug = repository.get("slug") or repository.get("name")
            owner = repository.get("project", {}).get("key") or self._workspace
            repo = repository.get("full_name") or (f"{owner}/{slug}" if owner and slug else slug)
            pull_requests.append({
                "id": pull_request.get("id"),
                "repo": repo,
                "title": pull_request.get("title"),
                "state": pull_request.get("state"),
                "updated": pull_request.get("updated_on") or pull_request.get("updatedDate"),
                "author": (pull_request.get("author") or {}).get("display_name")
                or (pull_request.get("author") or {}).get("displayName"),
            })
        return ToolResult(success=True, data={"total": len(pull_requests), "pull_requests": pull_requests})
