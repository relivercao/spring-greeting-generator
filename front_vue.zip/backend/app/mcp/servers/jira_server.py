"""
@file jira_server.py
@author caoshwen
@brief JiraMCPServer - Jira REST API tool server.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import Any, Optional

import httpx
from loguru import logger

from app.mcp.base import (
    BaseMCPServer,
    ToolDefinition,
    ToolResult,
    ToolNotFoundError,
    ToolExecutionError,
)


class JiraMCPServer(BaseMCPServer):
    """
    Jira MCP Server.

    Interact with Jira through Jira REST API (Atlassian Cloud / Server).
    Provides capabilities for bug queries, ticket management, Sprint viewing, etc.
    """

    def __init__(
        self,
        base_url: str,
        email: str,
        api_token: str,
        timeout: float = 30.0,
    ):
        self._base_url = base_url.rstrip("/")
        self._email = email
        self._api_token = api_token
        self._timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None

    # ---------- Metadata ----------

    @property
    def server_name(self) -> str:
        return "jira"

    @property
    def description(self) -> str:
        return (
            "Jira project management tools. Provides bug queries, ticket CRUD, JQL search, "
            "Sprint management and commenting functionality. For tracking and managing development tasks."
        )

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="get_bugs",
                description="Get bug list for specified project",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project": {"type": "string", "description": "Project key, e.g. FW"},
                        "status": {"type": "string", "description": "Status filter: Open/In Progress/Resolved"},
                        "max_results": {"type": "integer", "default": 50},
                    },
                    "required": ["project"],
                },
            ),
            ToolDefinition(
                name="get_issue",
                description="Get detailed information for specified ticket",
                input_schema={
                    "type": "object",
                    "properties": {
                        "issue_key": {"type": "string", "description": "Ticket key, e.g. FW-123"},
                    },
                    "required": ["issue_key"],
                },
            ),
            ToolDefinition(
                name="search",
                description="Search tickets using JQL",
                input_schema={
                    "type": "object",
                    "properties": {
                        "jql": {"type": "string", "description": "JQL query statement"},
                        "max_results": {"type": "integer", "default": 50},
                        "fields": {"type": "array", "items": {"type": "string"}, "description": "List of fields to return"},
                    },
                    "required": ["jql"],
                },
            ),
            ToolDefinition(
                name="update_issue",
                description="Update ticket status or fields",
                input_schema={
                    "type": "object",
                    "properties": {
                        "issue_key": {"type": "string", "description": "Ticket key"},
                        "fields": {"type": "object", "description": "Key-value pairs of fields to update"},
                        "transition": {"type": "string", "description": "Transition name"},
                    },
                    "required": ["issue_key"],
                },
            ),
            ToolDefinition(
                name="create_issue",
                description="Create new Jira ticket",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project": {"type": "string", "description": "Project key"},
                        "summary": {"type": "string", "description": "Ticket title"},
                        "description": {"type": "string", "description": "Ticket description"},
                        "issue_type": {"type": "string", "default": "Bug", "description": "Ticket type"},
                        "priority": {"type": "string", "description": "Priority"},
                    },
                    "required": ["project", "summary"],
                },
            ),
            ToolDefinition(
                name="get_sprint",
                description="Get current Sprint information for project",
                input_schema={
                    "type": "object",
                    "properties": {
                        "board_id": {"type": "integer", "description": "Board ID"},
                        "state": {"type": "string", "default": "active", "description": "Sprint state: active/future/closed"},
                    },
                    "required": ["board_id"],
                },
            ),
            ToolDefinition(
                name="add_comment",
                description="Add comment to ticket",
                input_schema={
                    "type": "object",
                    "properties": {
                        "issue_key": {"type": "string", "description": "Ticket key"},
                        "body": {"type": "string", "description": "Comment content"},
                    },
                    "required": ["issue_key", "body"],
                },
            ),
        ]

    # ---------- Lifecycle ----------

    async def initialize(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            auth=(self._email, self._api_token),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=httpx.Timeout(self._timeout),
        )
        logger.info(f"Initialized Jira MCP server (url={self._base_url})")

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    # ---------- Core Methods ----------

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        dispatch = {
            "get_bugs": self._get_bugs,
            "get_issue": self._get_issue,
            "search": self._search,
            "update_issue": self._update_issue,
            "create_issue": self._create_issue,
            "get_sprint": self._get_sprint,
            "add_comment": self._add_comment,
        }

        handler = dispatch.get(tool_name)
        if handler is None:
            raise ToolNotFoundError(f"Jira tool '{tool_name}' not found")

        try:
            return await handler(arguments)
        except ToolNotFoundError:
            raise
        except Exception as e:
            raise ToolExecutionError(
                f"Jira tool '{tool_name}' failed: {e}",
                tool_name=tool_name,
                details=str(e),
            )

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        try:
            if self._client is None:
                return False
            resp = await self._client.get("/rest/api/2/myself")
            return resp.status_code == 200
        except Exception as e:
            logger.debug(f"Jira health check failed: {e}")
            return False

    # ---------- Tool Implementation ----------

    async def _get_bugs(self, args: dict[str, Any]) -> ToolResult:
        project = args["project"]
        status = args.get("status", "")
        max_results = args.get("max_results", 50)

        jql = f'project = "{project}" AND issuetype = Bug'
        if status:
            jql += f' AND status = "{status}"'
        jql += " ORDER BY created DESC"

        return await self._search({"jql": jql, "max_results": max_results})

    async def _get_issue(self, args: dict[str, Any]) -> ToolResult:
        issue_key = args["issue_key"]
        resp = await self._client.get(f"/rest/api/2/issue/{issue_key}")
        resp.raise_for_status()
        data = resp.json()
        return ToolResult(
            success=True,
            data={
                "key": data["key"],
                "summary": data["fields"]["summary"],
                "status": (data["fields"].get("status") or {}).get("name"),
                "priority": (data["fields"].get("priority") or {}).get("name"),
                "issue_type": (data["fields"].get("issuetype") or {}).get("name"),
                "assignee": (data["fields"].get("assignee") or {}).get("displayName"),
                "description": data["fields"].get("description"),
                "created": data["fields"]["created"],
                "updated": data["fields"]["updated"],
            },
        )

    async def _search(self, args: dict[str, Any]) -> ToolResult:
        jql = args["jql"]
        max_results = args.get("max_results", 50)
        fields = args.get("fields", ["summary", "description", "status", "priority", "assignee", "created", "updated", "issuetype"])

        resp = await self._client.get(
            "/rest/api/2/search",
            params={"jql": jql, "maxResults": max_results, "fields": ",".join(fields)},
        )
        resp.raise_for_status()
        data = resp.json()

        issues = []
        for issue in data.get("issues", []):
            issues.append({
                "key": issue["key"],
                "summary": issue["fields"].get("summary"),
                "description": issue["fields"].get("description"),
                "status": (issue["fields"].get("status") or {}).get("name"),
                "priority": (issue["fields"].get("priority") or {}).get("name"),
                "issue_type": (issue["fields"].get("issuetype") or {}).get("name"),
                "assignee": (issue["fields"].get("assignee") or {}).get("displayName"),
                "created": issue["fields"].get("created"),
                "updated": issue["fields"].get("updated"),
            })

        return ToolResult(
            success=True,
            data={"total": data.get("total", 0), "issues": issues},
        )

    async def _update_issue(self, args: dict[str, Any]) -> ToolResult:
        issue_key = args["issue_key"]
        fields = args.get("fields")
        transition = args.get("transition")

        if fields:
            resp = await self._client.put(
                f"/rest/api/2/issue/{issue_key}",
                json={"fields": fields},
            )
            resp.raise_for_status()

        if transition:
            transitions_resp = await self._client.get(
                f"/rest/api/2/issue/{issue_key}/transitions"
            )
            transitions_resp.raise_for_status()
            available = transitions_resp.json().get("transitions", [])
            target = next((t for t in available if t["name"].lower() == transition.lower()), None)
            if target:
                await self._client.post(
                    f"/rest/api/2/issue/{issue_key}/transitions",
                    json={"transition": {"id": target["id"]}},
                )

        return ToolResult(success=True, data={"issue_key": issue_key, "updated": True})

    async def _create_issue(self, args: dict[str, Any]) -> ToolResult:
        payload = {
            "fields": {
                "project": {"key": args["project"]},
                "summary": args["summary"],
                "issuetype": {"name": args.get("issue_type", "Bug")},
            }
        }
        if args.get("description"):
            payload["fields"]["description"] = args["description"]
        if args.get("priority"):
            payload["fields"]["priority"] = {"name": args["priority"]}

        resp = await self._client.post("/rest/api/2/issue", json=payload)
        resp.raise_for_status()
        data = resp.json()
        return ToolResult(
            success=True,
            data={"key": data["key"], "id": data["id"], "self": data["self"]},
        )

    async def _get_sprint(self, args: dict[str, Any]) -> ToolResult:
        board_id = args["board_id"]
        state = args.get("state", "active")
        resp = await self._client.get(
            f"/rest/agile/1.0/board/{board_id}/sprint",
            params={"state": state},
        )
        resp.raise_for_status()
        data = resp.json()
        sprints = [
            {
                "id": s["id"],
                "name": s["name"],
                "state": s["state"],
                "startDate": s.get("startDate"),
                "endDate": s.get("endDate"),
            }
            for s in data.get("values", [])
        ]
        return ToolResult(success=True, data={"sprints": sprints})

    async def _add_comment(self, args: dict[str, Any]) -> ToolResult:
        issue_key = args["issue_key"]
        body = args["body"]
        resp = await self._client.post(
            f"/rest/api/2/issue/{issue_key}/comment",
            json={"body": body},
        )
        resp.raise_for_status()
        data = resp.json()
        return ToolResult(
            success=True,
            data={"comment_id": data["id"], "created": data["created"]},
        )
