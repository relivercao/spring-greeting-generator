"""MCP server for read-only local Git review context."""

from __future__ import annotations

from typing import Any

from app.mcp.base import BaseMCPServer, ToolDefinition, ToolNotFoundError, ToolResult
from app.services.git_review import GitReviewError, GitReviewService


class LocalGitMCPServer(BaseMCPServer):
    """Expose safe, read-only Git diff collection to agents."""

    def __init__(self, service: GitReviewService | None = None):
        self._service = service or GitReviewService()

    @property
    def server_name(self) -> str:
        return "git"

    @property
    def description(self) -> str:
        return "Read-only local Git repository diff tools for code review agents."

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="get_diff",
                description="Read committed or working-tree changes from a local Git repository without mutating it.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repository_path": {"type": "string", "description": "Local Git repository directory"},
                        "base_ref": {"type": "string", "default": "HEAD~1"},
                        "target_ref": {"type": "string", "default": "WORKTREE"},
                        "include_untracked": {"type": "boolean", "default": True},
                    },
                    "required": [],
                },
            )
        ]

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        if tool_name != "get_diff":
            raise ToolNotFoundError(f"Git tool not found: {tool_name}")
        try:
            sources, metadata = await self._service.read_diff(
                str(arguments.get("repository_path") or ""),
                base_ref=str(arguments.get("base_ref") or "HEAD~1"),
                target_ref=str(arguments.get("target_ref") or "WORKTREE"),
                include_untracked=bool(arguments.get("include_untracked", True)),
            )
        except GitReviewError as exc:
            return ToolResult(success=False, error=str(exc))
        return ToolResult(success=True, data={"sources": sources, "metadata": metadata})

