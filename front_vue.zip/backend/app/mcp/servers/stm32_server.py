"""
@file stm32_server.py
@author caoshwen
@brief STM32MCPServer - STM32 toolchain and register tool server.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
from typing import Any, Optional

from loguru import logger

from app.mcp.base import (
    BaseMCPServer,
    ToolDefinition,
    ToolResult,
    ToolNotFoundError,
    ToolExecutionError,
)


class STM32MCPServer(BaseMCPServer):
    """
    STM32 MCP Server.

    Provides compilation, flashing, debugging, register reading capabilities
    through arm-none-eabi-gcc toolchain and STM32 related CLI tools.
    """

    def __init__(
        self,
        toolchain_path: str = "arm-none-eabi-gcc",
        openocd_path: str = "openocd",
        stm32_programmer_path: str = "STM32_Programmer_CLI",
        timeout: float = 120.0,
    ):
        self._toolchain_path = toolchain_path
        self._openocd_path = openocd_path
        self._programmer_path = stm32_programmer_path
        self._timeout = timeout

    # ---------- Metadata ----------

    @property
    def server_name(self) -> str:
        return "stm32"

    @property
    def description(self) -> str:
        return (
            "STM32 embedded development tools. Provides cross-compilation (arm-none-eabi-gcc), "
            "firmware flashing, debug connection, register reading and MCU pin query functionality."
        )

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="compile",
                description="Compile STM32 project using arm-none-eabi-gcc",
                input_schema={
                    "type": "object",
                    "properties": {
                        "project_path": {"type": "string", "description": "Project directory path"},
                        "target": {"type": "string", "description": "Build target (e.g. STM32F407)"},
                        "build_type": {"type": "string", "default": "debug", "description": "Build type: debug/release"},
                        "extra_flags": {"type": "array", "items": {"type": "string"}, "description": "Extra compilation flags"},
                    },
                    "required": ["project_path", "target"],
                },
            ),
            ToolDefinition(
                name="flash",
                description="Flash compiled firmware to STM32 chip",
                input_schema={
                    "type": "object",
                    "properties": {
                        "firmware_path": {"type": "string", "description": "Firmware file path (.bin/.hex/.elf)"},
                        "target": {"type": "string", "description": "Target MCU model"},
                        "address": {"type": "string", "default": "0x08000000", "description": "Flash address"},
                        "interface": {"type": "string", "default": "swd", "description": "Interface: swd/jtag"},
                    },
                    "required": ["firmware_path", "target"],
                },
            ),
            ToolDefinition(
                name="debug_connect",
                description="Establish debug connection (via OpenOCD)",
                input_schema={
                    "type": "object",
                    "properties": {
                        "target": {"type": "string", "description": "Target MCU model"},
                        "interface": {"type": "string", "default": "swd", "description": "Interface: swd/jtag"},
                        "reset": {"type": "boolean", "default": False, "description": "Whether to reset after connection"},
                    },
                    "required": ["target"],
                },
            ),
            ToolDefinition(
                name="read_register",
                description="Read MCU register value",
                input_schema={
                    "type": "object",
                    "properties": {
                        "address": {"type": "string", "description": "Register address (hexadecimal)"},
                        "size": {"type": "integer", "default": 4, "description": "Number of bytes to read: 1/2/4"},
                        "count": {"type": "integer", "default": 1, "description": "Number of registers to read"},
                    },
                    "required": ["address"],
                },
            ),
            ToolDefinition(
                name="get_mcu_targets",
                description="Get list of supported MCU targets",
                input_schema={
                    "type": "object",
                    "properties": {
                        "family": {"type": "string", "description": "MCU family filter, e.g. STM32F4"},
                    },
                },
            ),
            ToolDefinition(
                name="query_pin_map",
                description="Query MCU pin mapping (alternate functions)",
                input_schema={
                    "type": "object",
                    "properties": {
                        "mcu": {"type": "string", "description": "MCU model"},
                        "pin": {"type": "string", "description": "Pin name, e.g. PA0"},
                        "function": {"type": "string", "description": "Function filter, e.g. USART/SPI/I2C"},
                    },
                    "required": ["mcu"],
                },
            ),
        ]

    # ---------- Lifecycle ----------

    async def initialize(self) -> None:
        # Check if toolchain is available
        available = await self._check_tool(self._toolchain_path, "--version")
        if available:
            logger.info("STM32 MCP server initialized (toolchain available)")
        else:
            logger.warning("STM32 toolchain not found, some tools may fail")

    async def shutdown(self) -> None:
        pass

    # ---------- Core Methods ----------

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        dispatch = {
            "compile": self._compile,
            "flash": self._flash,
            "debug_connect": self._debug_connect,
            "read_register": self._read_register,
            "get_mcu_targets": self._get_mcu_targets,
            "query_pin_map": self._query_pin_map,
        }

        handler = dispatch.get(tool_name)
        if handler is None:
            raise ToolNotFoundError(f"STM32 tool '{tool_name}' not found")

        try:
            return await handler(arguments)
        except ToolNotFoundError:
            raise
        except Exception as e:
            raise ToolExecutionError(
                f"STM32 tool '{tool_name}' failed: {e}",
                tool_name=tool_name,
                details=str(e),
            )

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        return await self._check_tool(self._toolchain_path, "--version")

    # ---------- Tool Implementation ----------

    async def _compile(self, args: dict[str, Any]) -> ToolResult:
        project_path = args["project_path"]
        target = args["target"]
        build_type = args.get("build_type", "debug")
        extra_flags = args.get("extra_flags", [])

        optimization = "-Og" if build_type == "debug" else "-O2"
        mcu_flag = f"-mcpu={self._mcu_to_cpu(target)}"

        cmd = [
            self._toolchain_path,
            mcu_flag, "-mthumb",
            optimization,
            "-Wall", "-Wextra",
            f"-D{target}",
        ] + extra_flags

        # In actual implementation, the full compilation command would be constructed
        # based on project_path here. Currently returns the compilation command and
        # parameters for upper layer use.
        stdout, stderr, returncode = await self._run_cmd(
            ["make", "-C", project_path, f"BUILD_TYPE={build_type}", f"MCU={target}"]
        )

        return ToolResult(
            success=returncode == 0,
            data={
                "returncode": returncode,
                "stdout": stdout,
                "stderr": stderr,
                "target": target,
                "build_type": build_type,
            },
            error=stderr if returncode != 0 else None,
        )

    async def _flash(self, args: dict[str, Any]) -> ToolResult:
        firmware_path = args["firmware_path"]
        target = args["target"]
        address = args.get("address", "0x08000000")
        interface = args.get("interface", "swd")

        cmd = [
            self._programmer_path,
            "--connect", f"port={interface.upper()}",
            "--download", firmware_path,
            address,
            "--verify",
            "--start",
        ]

        stdout, stderr, returncode = await self._run_cmd(cmd)

        return ToolResult(
            success=returncode == 0,
            data={
                "returncode": returncode,
                "stdout": stdout,
                "firmware": firmware_path,
                "target": target,
            },
            error=stderr if returncode != 0 else None,
        )

    async def _debug_connect(self, args: dict[str, Any]) -> ToolResult:
        target = args["target"]
        interface = args.get("interface", "swd")
        reset = args.get("reset", False)

        cfg_file = f"target/{target.lower()}.cfg"
        cmd = [
            self._openocd_path,
            "-f", f"interface/{interface}.cfg",
            "-f", cfg_file,
        ]
        if reset:
            cmd.extend(["-c", "init", "-c", "reset halt"])

        stdout, stderr, returncode = await self._run_cmd(cmd, timeout=10.0)

        return ToolResult(
            success=returncode == 0,
            data={"connected": returncode == 0, "target": target, "interface": interface},
            error=stderr if returncode != 0 else None,
        )

    async def _read_register(self, args: dict[str, Any]) -> ToolResult:
        address = args["address"]
        size = args.get("size", 4)
        count = args.get("count", 1)

        size_suffix = {1: "b", 2: "h", 4: "w"}.get(size, "w")
        cmd = [
            self._openocd_path,
            "-c", f"mdw {address} {count}" if size == 4 else f"md{size_suffix} {address} {count}",
        ]

        stdout, stderr, returncode = await self._run_cmd(cmd, timeout=10.0)

        return ToolResult(
            success=returncode == 0,
            data={"address": address, "output": stdout},
            error=stderr if returncode != 0 else None,
        )

    async def _get_mcu_targets(self, args: dict[str, Any]) -> ToolResult:
        family = args.get("family", "")

        # Common STM32 MCU list (can be extended to load from file or database)
        targets = {
            "STM32F0": ["STM32F030", "STM32F042", "STM32F072", "STM32F091"],
            "STM32F1": ["STM32F103", "STM32F107"],
            "STM32F2": ["STM32F205", "STM32F207"],
            "STM32F3": ["STM32F303", "STM32F334"],
            "STM32F4": ["STM32F401", "STM32F407", "STM32F411", "STM32F429", "STM32F446"],
            "STM32F7": ["STM32F746", "STM32F767"],
            "STM32H7": ["STM32H743", "STM32H750", "STM32H753"],
            "STM32L0": ["STM32L011", "STM32L053"],
            "STM32L4": ["STM32L431", "STM32L476"],
            "STM32G0": ["STM32G030", "STM32G071"],
            "STM32G4": ["STM32G431", "STM32G474"],
        }

        if family:
            family_upper = family.upper()
            filtered = {k: v for k, v in targets.items() if family_upper in k}
        else:
            filtered = targets

        return ToolResult(success=True, data={"families": filtered})

    async def _query_pin_map(self, args: dict[str, Any]) -> ToolResult:
        mcu = args["mcu"]
        pin = args.get("pin")
        function = args.get("function")

        # Simplified pin mapping data (should actually be loaded from STM32CubeMX database)
        # Returns a placeholder structure here
        result = {
            "mcu": mcu,
            "message": "Pin map query executed. In production, this would query STM32CubeMX database.",
        }
        if pin:
            result["pin"] = pin
        if function:
            result["function_filter"] = function

        return ToolResult(success=True, data=result)

    # ---------- Internal Helpers ----------

    async def _run_cmd(
        self,
        cmd: list[str],
        timeout: Optional[float] = None,
    ) -> tuple[str, str, int]:
        """Execute subprocess command."""
        timeout = timeout or self._timeout
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            return stdout.decode(), stderr.decode(), proc.returncode
        except asyncio.TimeoutError:
            return "", f"Command timed out after {timeout}s", -1
        except FileNotFoundError:
            return "", f"Command not found: {cmd[0]}", -1
        except Exception as e:
            return "", str(e), -1

    async def _check_tool(self, tool: str, *args: str) -> bool:
        """Check if tool is available."""
        _, _, returncode = await self._run_cmd([tool, *args], timeout=5.0)
        return returncode == 0

    @staticmethod
    def _mcu_to_cpu(mcu: str) -> str:
        """Convert MCU model to CPU architecture flag."""
        mcu_upper = mcu.upper()
        if "STM32F0" in mcu_upper or "STM32L0" in mcu_upper:
            return "cortex-m0"
        if "STM32F1" in mcu_upper or "STM32F2" in mcu_upper or "STM32L1" in mcu_upper:
            return "cortex-m3"
        if "STM32F3" in mcu_upper or "STM32F4" in mcu_upper or "STM32L4" in mcu_upper or "STM32G4" in mcu_upper:
            return "cortex-m4"
        if "STM32F7" in mcu_upper or "STM32H7" in mcu_upper:
            return "cortex-m7"
        if "STM32G0" in mcu_upper:
            return "cortex-m0plus"
        return "cortex-m4"