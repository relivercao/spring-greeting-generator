"""Public web search and page retrieval MCP tools."""

from __future__ import annotations

import html
import re
import time
from xml.etree import ElementTree
from html.parser import HTMLParser
from typing import Any, Optional
from urllib.parse import parse_qs, unquote, urlparse

import httpx
from loguru import logger

from app.mcp.base import (
    BaseMCPServer,
    ToolDefinition,
    ToolExecutionError,
    ToolNotFoundError,
    ToolResult,
)


class _SearchResultParser(HTMLParser):
    """Extract DuckDuckGo HTML result links and snippets."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.results: list[dict[str, str]] = []
        self._current: Optional[dict[str, str]] = None
        self._capture_title = False
        self._capture_snippet = False
        self._title_parts: list[str] = []
        self._snippet_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attributes = dict(attrs)
        classes = set((attributes.get("class") or "").split())
        if tag == "a" and "result__a" in classes:
            href = html.unescape(attributes.get("href") or "")
            parsed = urlparse(href)
            query = parse_qs(parsed.query)
            target = query.get("uddg", [href])[0]
            self._current = {"url": unquote(target), "title": "", "snippet": ""}
            self._title_parts = []
            self._capture_title = True
        elif self._current is not None and "result__snippet" in classes:
            self._snippet_parts = []
            self._capture_snippet = True

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._capture_title:
            self._capture_title = False
            if self._current is not None:
                self._current["title"] = "".join(self._title_parts).strip()
        if self._capture_snippet and tag in {"a", "div"}:
            self._capture_snippet = False
            if self._current is not None:
                self._current["snippet"] = "".join(self._snippet_parts).strip()
                if self._current.get("title") and self._current.get("url"):
                    self.results.append(self._current)
                self._current = None

    def handle_data(self, data: str) -> None:
        if self._capture_title:
            self._title_parts.append(data)
        elif self._capture_snippet:
            self._snippet_parts.append(data)


class _PageTextParser(HTMLParser):
    """Convert an HTML document to readable text without script/style blocks."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript", "svg"}:
            self._ignored_depth += 1
        elif self._ignored_depth == 0 and tag in {"p", "div", "li", "br", "h1", "h2", "h3", "h4", "tr"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg"} and self._ignored_depth:
            self._ignored_depth -= 1
        elif self._ignored_depth == 0 and tag in {"p", "div", "li", "tr"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._ignored_depth == 0:
            self.parts.append(data)


class ExternalSearchMCPServer(BaseMCPServer):
    """Network tools for public web search and safe page retrieval."""

    def __init__(self, timeout: float = 15.0, user_agent: str = "Macode-Agent/1.0") -> None:
        self._timeout = timeout
        self._user_agent = user_agent
        self._client: Optional[httpx.AsyncClient] = None
        self._duckduckgo_retry_after = 0.0

    @property
    def server_name(self) -> str:
        return "external_search"

    @property
    def description(self) -> str:
        return "Public web search and page retrieval tools for research-grounded Agent answers."

    @property
    def tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="search_web",
                description="Search the public web and return ranked titles, URLs, and snippets.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Focused web search query"},
                        "max_results": {"type": "integer", "minimum": 1, "maximum": 10, "default": 5},
                    },
                    "required": ["query"],
                },
            ),
            ToolDefinition(
                name="fetch_url",
                description="Fetch a public HTTP(S) page and return cleaned readable text.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "Public HTTP or HTTPS URL"},
                        "max_chars": {"type": "integer", "minimum": 1000, "maximum": 20000, "default": 12000},
                    },
                    "required": ["url"],
                },
            ),
        ]

    async def initialize(self) -> None:
        self._client = httpx.AsyncClient(
            headers={
                "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9",
                "User-Agent": self._user_agent,
            },
            follow_redirects=True,
            timeout=httpx.Timeout(self._timeout),
        )

    async def shutdown(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def health_check(self) -> bool:
        return self._client is not None

    async def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> ToolResult:
        dispatch = {"search_web": self._search_web, "fetch_url": self._fetch_url}
        handler = dispatch.get(tool_name)
        if handler is None:
            raise ToolNotFoundError(f"External search tool '{tool_name}' not found")
        try:
            return await handler(arguments)
        except ToolNotFoundError:
            raise
        except Exception as error:
            raise ToolExecutionError(
                f"External search tool '{tool_name}' failed: {error}",
                tool_name=tool_name,
                details=str(error),
            ) from error

    async def _search_web(self, args: dict[str, Any]) -> ToolResult:
        query = str(args.get("query") or "").strip()
        if not query:
            return ToolResult(success=False, error="Search query is required")
        max_results = max(1, min(int(args.get("max_results", 5)), 10))
        if self._client is None:
            raise RuntimeError("External search client is not initialized")
        results = []
        source = "duckduckgo_html"
        if time.monotonic() >= self._duckduckgo_retry_after:
            try:
                response = await self._client.get(
                    "https://html.duckduckgo.com/html/", params={"q": query},
                    timeout=min(self._timeout, 5.0),
                )
                response.raise_for_status()
                parser = _SearchResultParser()
                parser.feed(response.text)
                results = parser.results[:max_results]
            except httpx.HTTPError as error:
                logger.warning("DuckDuckGo search unavailable: {}", type(error).__name__)
            if not results:
                self._duckduckgo_retry_after = time.monotonic() + 300
        if not results:
            source = "bing_rss"
            results = await self._search_bing(query, max_results)
        logger.info("External web search completed: source={}, query_length={}, results={}", source, len(query), len(results))
        return ToolResult(
            success=bool(results),
            data={"query": query, "results": results},
            error=None if results else "Public web search returned no usable results",
            metadata={"source": source},
        )

    async def _search_bing(self, query: str, max_results: int) -> list[dict[str, str]]:
        """Use the free RSS response when the primary search host is unreachable."""
        assert self._client is not None
        response = await self._client.get(
            "https://www.bing.com/search", params={"q": query, "format": "rss"},
        )
        response.raise_for_status()
        if len(response.content) > 2 * 1024 * 1024:
            raise ValueError("Search response exceeds the allowed size")
        document = ElementTree.fromstring(response.content)
        results = []
        for item in document.findall("./channel/item"):
            url = (item.findtext("link") or "").strip()
            parsed = urlparse(url)
            title = (item.findtext("title") or "").strip()
            if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password or not title:
                continue
            snippet = html.unescape(re.sub(r"<[^>]*>", " ", item.findtext("description") or ""))
            results.append({"title": title[:400], "url": url, "snippet": re.sub(r"\s+", " ", snippet).strip()[:1500]})
            if len(results) >= max_results:
                break
        return results

    async def _fetch_url(self, args: dict[str, Any]) -> ToolResult:
        url = str(args.get("url") or "").strip()
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return ToolResult(success=False, error="Only public HTTP(S) URLs are supported")
        max_chars = max(1000, min(int(args.get("max_chars", 12000)), 20000))
        if self._client is None:
            raise RuntimeError("External search client is not initialized")
        response = await self._client.get(url)
        response.raise_for_status()
        content_type = response.headers.get("content-type", "").lower()
        if "text" not in content_type and "html" not in content_type and "xml" not in content_type:
            return ToolResult(success=False, error="The URL did not return readable text or HTML")
        parser = _PageTextParser()
        parser.feed(response.text)
        text = re.sub(r"\s+", " ", " ".join(parser.parts)).strip()[:max_chars]
        return ToolResult(
            success=True,
            data={"url": url, "content": text, "truncated": len(text) >= max_chars},
            metadata={"content_type": content_type, "status_code": response.status_code},
        )
