"""
@file base.py
@author caoshwen
@brief BaseMCPServer abstract class and tool definition types.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ToolDefinition:
    """MCP tool definition"""
    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass
class ToolResult:
    """MCP tool execution result"""
    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


class ToolNotFoundError(Exception):
    """Tool not found"""
    pass


class ToolExecutionError(Exception):
    """Tool execution failed"""
    def __init__(self, message: str, tool_name: str = "", details: Any = None):
        self.tool_name = tool_name
        self.details = details
        super().__init__(message)


class BaseMCPServer(ABC):
    """
    MCP Server unified abstract base class.

    All tool services must implement:
    - server_name: unique identifier
    - description: functional description (for LLM understanding)
    - tools: tool list + JSON Schema
    - call_tool(): execute tool
    """

    # ---------- Metadata (required implementation) ----------

    @property
    @abstractmethod
    def server_name(self) -> str:
        """Server unique identifier, e.g. 'jira', 'bitbucket', 'stm32', 'qbs'"""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Server functional description (for LLM to understand tool purposes)"""
        ...

    @property
    @abstractmethod
    def tools(self) -> list[ToolDefinition]:
        """
        Declare all tools provided by this Server.
        Each tool contains: name, description, input_schema (JSON Schema)
        """
        ...

    # ---------- Core methods (required implementation) ----------

    @abstractmethod
    async def call_tool(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> ToolResult:
        """
        Execute specified tool.

        Args:
            tool_name: Tool name (without server_name prefix)
            arguments: Tool parameter dictionary

        Returns:
            ToolResult: Unified result object

        Raises:
            ToolNotFoundError: Tool name does not exist
            ToolExecutionError: Execution error
        """
        ...

    # ---------- Lifecycle (optional override) ----------

    async def initialize(self) -> None:
        """Initialize Server (establish HTTP client, validate connection, etc.)"""
        pass

    async def shutdown(self) -> None:
        """Shutdown Server (release resources)"""
        pass

    # ---------- Health check (optional override) ----------

    async def health_check(self) -> bool:
        """Check if Server connection is normal. Default returns True."""
        return True
