"""Translate provider failures into stable API errors for user-facing endpoints."""

from __future__ import annotations

from typing import Any, Iterable, Optional

from fastapi import HTTPException

from app.llm.base import (
    AllProvidersFailedError,
    LLMAuthError,
    LLMConnectionError,
    LLMError,
    LLMServerError,
    LLMTimeoutError,
    RateLimitError,
)


_RATE_LIMIT_MARKERS = (
    "429",
    "rate limit",
    "rate-limit",
    "too many requests",
    "cooling down",
    "cooldown",
    "temporarily throttled",
)
_AUTH_MARKERS = (
    "aws_auth_required",
    "authentication failed",
    "unauthorized",
    "invalid api key",
    "invalid_api_key",
    "access denied",
)
_TIMEOUT_MARKERS = ("timed out", "timeout", "deadline exceeded")
_UNAVAILABLE_MARKERS = (
    "503",
    "502",
    "500",
    "504",
    "overloaded",
    "service unavailable",
    "temporarily unavailable",
    "all providers failed",
    "no healthy provider",
)


def _error_text(error: Any) -> str:
    """Return exception text including provider-specific stderr when available."""
    values = [str(error or "")]
    stderr = getattr(error, "stderr", "")
    if stderr:
        values.append(str(stderr))
    return " ".join(values).strip()


def _contains_marker(text: str, markers: Iterable[str]) -> bool:
    lowered = text.lower()
    return any(marker in lowered for marker in markers)


def _status_code_for_error(error: Any, text: str) -> Optional[int]:
    """Resolve an HTTP status for a typed or subprocess-wrapped provider error."""
    explicit_status = getattr(error, "status_code", 0) or 0

    if isinstance(error, RateLimitError) or explicit_status == 429:
        return 429
    if isinstance(error, LLMAuthError) or explicit_status in {401, 403}:
        return int(explicit_status or 401)
    if isinstance(error, LLMTimeoutError) or explicit_status == 408:
        return 504
    if _contains_marker(text, _RATE_LIMIT_MARKERS):
        return 429
    if _contains_marker(text, _AUTH_MARKERS):
        return 401
    if _contains_marker(text, _TIMEOUT_MARKERS):
        return 504
    if isinstance(error, (LLMServerError, LLMConnectionError, AllProvidersFailedError)):
        return 503
    if _contains_marker(text, _UNAVAILABLE_MARKERS):
        return 503
    if isinstance(error, LLMError):
        return 503
    return None


def _detail_for_status(status_code: int) -> str:
    """Return a safe, actionable message without leaking upstream response bodies."""
    if status_code == 429:
        return (
            "The configured LLM provider is rate limited or all upstream accounts are "
            "cooling down. Please retry later or choose another configured provider."
        )
    if status_code in {401, 403}:
        return (
            "The configured LLM provider rejected authentication. Check provider "
            "credentials in Provider Settings."
        )
    if status_code == 504:
        return (
            "The configured LLM provider did not respond in time. Retry the task "
            "without changing your input."
        )
    return (
        "The configured LLM provider is temporarily unavailable. Check Provider "
        "Settings or choose another configured provider."
    )


def http_exception_for_llm_error(error: BaseException) -> Optional[HTTPException]:
    """Convert a direct LLM exception into an HTTP exception, if applicable."""
    text = _error_text(error)
    status_code = _status_code_for_error(error, text)
    if status_code is None:
        return None

    headers = {"Retry-After": "60"} if status_code == 429 else None
    return HTTPException(
        status_code=status_code,
        detail=_detail_for_status(status_code),
        headers=headers,
    )


def http_exception_for_agent_result(result: Any) -> Optional[HTTPException]:
    """Convert a failed agent result caused by an LLM call into an HTTP error."""
    if getattr(result, "status", None) is None or getattr(result.status, "value", result.status) != "failed":
        return None

    values: list[str] = [str(getattr(result, "message", "") or "")]
    values.extend(str(value) for value in (getattr(result, "errors", None) or []))
    data = getattr(result, "data", None) or {}
    values.extend(str(value) for value in data.values() if value is not None)
    text = " ".join(values)

    # Agent lifecycle converts provider exceptions to strings. Only classify a
    # failed result when it still carries an unmistakable LLM/provider marker.
    lowered = text.lower()
    if not any(
        marker in lowered
        for marker in (
            "llm",
            "provider",
            "claude cli",
            *_RATE_LIMIT_MARKERS,
            *_AUTH_MARKERS,
            *_TIMEOUT_MARKERS,
        )
    ):
        return None

    status_code = _status_code_for_error(text, text)
    if status_code is None:
        status_code = 503
    headers = {"Retry-After": "60"} if status_code == 429 else None
    return HTTPException(
        status_code=status_code,
        detail=_detail_for_status(status_code),
        headers=headers,
    )
