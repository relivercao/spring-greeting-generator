"""Image request normalization shared by the image gateway and provider."""

from __future__ import annotations

import io
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence
from urllib.parse import urlparse

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps, UnidentifiedImageError


MAX_IMAGE_PROMPT_CHARACTERS = 8000
MIN_REFERENCE_REQUEST_TIMEOUT_SECONDS = 600
REFERENCE_IMAGE_MAX_EDGE = 2048
REFERENCE_IMAGE_MIN_EDGE = 1280
REFERENCE_IMAGE_TARGET_BYTES = 5 * 1024 * 1024
MASK_WORKING_MAX_EDGE = 1920
IMAGE_SIZE_MULTIPLE = 16
IMAGE_MAX_EDGE = 3840
IMAGE_MAX_ASPECT_RATIO = 3
IMAGE_MIN_PIXELS = 655_360
IMAGE_MAX_PIXELS = 8_294_400
MACODE_REFERENCE_SHEET_PROMPT = (
    "The reference images are arranged left to right and top to bottom on one "
    "reference sheet. Treat each section as an independent reference and combine "
    "their useful details. Do not reproduce the sheet borders, spacing, or collage layout."
)
_TRANSPARENT_PROMPT = (
    "Use a solid #FF00FF background if the subject contains green hues; otherwise use "
    "a solid #00FF00 background. Fill the entire canvas with that exact flat color, "
    "without gradients, texture, shadows, floor, or environment. Keep the complete "
    "subject sharply separated from the background and do not use the selected key "
    "color in the subject, outline, glow, shadow, or reflection."
)
_SIZE_PATTERN = re.compile(r"^\s*(\d+)\s*[xX]\s*(\d+)\s*$")
_JPEG_QUALITY_STEPS = (92, 86, 78)
_REFERENCE_SHEET_GAP = 24


@dataclass(frozen=True)
class PreparedImage:
    """Normalized image bytes and metadata."""

    filename: str
    media_type: str
    data: bytes
    width: int
    height: int
    optimized: bool


def normalize_image_size(value: str) -> str | None:
    """Validate a provider-safe image size while preserving the auto mode."""
    normalized = value.strip().lower()
    if normalized == "auto":
        return normalized
    match = _SIZE_PATTERN.fullmatch(normalized)
    if not match:
        return None
    width, height = int(match.group(1)), int(match.group(2))
    if width % IMAGE_SIZE_MULTIPLE or height % IMAGE_SIZE_MULTIPLE:
        return None
    if max(width, height) > IMAGE_MAX_EDGE:
        return None
    if max(width / height, height / width) > IMAGE_MAX_ASPECT_RATIO:
        return None
    pixels = width * height
    if pixels < IMAGE_MIN_PIXELS or pixels > IMAGE_MAX_PIXELS:
        return None
    return f"{width}x{height}"


def constrain_image_prompt(prompt: str, max_characters: int = MAX_IMAGE_PROMPT_CHARACTERS) -> tuple[str, bool]:
    """Keep the most useful prompt head and tail within provider limits."""
    if len(prompt) <= max_characters:
        return prompt, False
    marker = "\n\n[Middle content omitted to fit the image API prompt limit]\n\n"
    content_budget = max(0, max_characters - len(marker))
    head_count = math.ceil(content_budget * 0.72)
    tail_count = content_budget - head_count
    tail = prompt[-tail_count:] if tail_count else ""
    return f"{prompt[:head_count]}{marker}{tail}", True


def get_reference_timeout(timeout_seconds: int, has_references: bool) -> int:
    """Use a longer minimum timeout for image upload and edit requests."""
    return max(timeout_seconds, MIN_REFERENCE_REQUEST_TIMEOUT_SECONDS) if has_references else timeout_seconds


def is_macode_image_endpoint(base_url: str, model: str, mode: str = "images") -> bool:
    """Return whether Macode's GPT Image 2 compatibility behavior applies."""
    if mode != "images" or model.strip().lower().split("/")[-1] != "gpt-image-2":
        return False
    hostname = (urlparse(base_url).hostname or "").lower()
    return hostname in {"macode.cloud", "macode.online"} or hostname.endswith(
        (".macode.cloud", ".macode.online")
    )


def optimize_reference_image(data: bytes, filename: str) -> PreparedImage:
    """Convert a reference image to a bounded JPEG suitable for long edit requests."""
    try:
        with Image.open(io.BytesIO(data)) as source:
            source.load()
            image = ImageOps.exif_transpose(source).convert("RGB")
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError("Uploaded image data is invalid") from exc

    original_size = image.size
    max_edge = REFERENCE_IMAGE_MAX_EDGE
    encoded = b""
    output_size = image.size
    while True:
        scale = min(1.0, max_edge / max(image.size))
        output_size = (
            max(1, round(image.width * scale)),
            max(1, round(image.height * scale)),
        )
        candidate = image.resize(output_size, Image.Resampling.LANCZOS) if output_size != image.size else image
        smallest = b""
        for quality in _JPEG_QUALITY_STEPS:
            output = io.BytesIO()
            candidate.save(output, format="JPEG", quality=quality, optimize=True)
            encoded = output.getvalue()
            if not smallest or len(encoded) < len(smallest):
                smallest = encoded
            if len(encoded) <= REFERENCE_IMAGE_TARGET_BYTES:
                break
        encoded = encoded if len(encoded) <= REFERENCE_IMAGE_TARGET_BYTES else smallest
        if len(encoded) <= REFERENCE_IMAGE_TARGET_BYTES or max_edge <= REFERENCE_IMAGE_MIN_EDGE:
            break
        max_edge = max(REFERENCE_IMAGE_MIN_EDGE, round(max_edge * 0.8))

    stem = Path(filename or "reference").stem or "reference"
    return PreparedImage(
        filename=f"{stem}.jpg",
        media_type="image/jpeg",
        data=encoded,
        width=output_size[0],
        height=output_size[1],
        optimized=original_size != output_size or encoded != data,
    )


def prepare_mask_image(data: bytes, target_data: bytes) -> PreparedImage:
    """Align a mask to its primary reference and ensure it has usable alpha."""
    try:
        with Image.open(io.BytesIO(target_data)) as target_source:
            target_source.load()
            target_size = target_source.size
        with Image.open(io.BytesIO(data)) as mask_source:
            mask_source.load()
            source_size = mask_source.size
            has_alpha = "A" in mask_source.getbands()
            if has_alpha:
                alpha = mask_source.getchannel("A")
            else:
                alpha = ImageOps.grayscale(mask_source)
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError("Uploaded mask data is invalid") from exc

    working_target = target_size
    longest_edge = max(target_size)
    if longest_edge > MASK_WORKING_MAX_EDGE:
        scale = MASK_WORKING_MAX_EDGE / longest_edge
        working_target = (
            max(IMAGE_SIZE_MULTIPLE, math.floor(target_size[0] * scale / IMAGE_SIZE_MULTIPLE) * IMAGE_SIZE_MULTIPLE),
            max(IMAGE_SIZE_MULTIPLE, math.floor(target_size[1] * scale / IMAGE_SIZE_MULTIPLE) * IMAGE_SIZE_MULTIPLE),
        )
    if alpha.size != working_target:
        alpha = alpha.resize(working_target, Image.Resampling.LANCZOS)
    if alpha.getextrema() == (255, 255):
        raise ValueError("The mask does not contain an editable region")

    mask = Image.new("RGBA", working_target, (255, 255, 255, 255))
    mask.putalpha(alpha)
    output = io.BytesIO()
    mask.save(output, format="PNG", optimize=True)
    return PreparedImage(
        filename="mask.png",
        media_type="image/png",
        data=output.getvalue(),
        width=working_target[0],
        height=working_target[1],
        optimized=source_size != working_target or not has_alpha,
    )


def prepare_mask_target_image(data: bytes, filename: str) -> PreparedImage:
    """Convert the primary edit image to the mask working size and PNG format."""
    try:
        with Image.open(io.BytesIO(data)) as source:
            source.load()
            image = ImageOps.exif_transpose(source).convert("RGBA")
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError("The primary mask image is invalid") from exc

    longest_edge = max(image.size)
    target_size = image.size
    if longest_edge > MASK_WORKING_MAX_EDGE:
        scale = MASK_WORKING_MAX_EDGE / longest_edge
        target_size = (
            max(IMAGE_SIZE_MULTIPLE, math.floor(image.width * scale / IMAGE_SIZE_MULTIPLE) * IMAGE_SIZE_MULTIPLE),
            max(IMAGE_SIZE_MULTIPLE, math.floor(image.height * scale / IMAGE_SIZE_MULTIPLE) * IMAGE_SIZE_MULTIPLE),
        )
        image = image.resize(target_size, Image.Resampling.LANCZOS)
    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    stem = Path(filename or "mask-target").stem or "mask-target"
    return PreparedImage(
        filename=f"{stem}.png",
        media_type="image/png",
        data=output.getvalue(),
        width=target_size[0],
        height=target_size[1],
        optimized=True,
    )


def compose_reference_sheet(images: Sequence[bytes]) -> bytes:
    """Compose two or three references for Macode GPT Image 2 edit requests."""
    if len(images) not in {2, 3}:
        raise ValueError("A reference sheet requires two or three images")
    loaded: list[Image.Image] = []
    for data in images:
        with Image.open(io.BytesIO(data)) as source:
            source.load()
            loaded.append(ImageOps.exif_transpose(source).convert("RGB"))

    width = REFERENCE_IMAGE_MAX_EDGE
    height = REFERENCE_IMAGE_MAX_EDGE // 2 if len(loaded) == 2 else REFERENCE_IMAGE_MAX_EDGE
    cell_size = (width - _REFERENCE_SHEET_GAP * 3) // 2
    cells = [
        (_REFERENCE_SHEET_GAP, _REFERENCE_SHEET_GAP, cell_size, height - _REFERENCE_SHEET_GAP * 2),
        (_REFERENCE_SHEET_GAP * 2 + cell_size, _REFERENCE_SHEET_GAP, cell_size, height - _REFERENCE_SHEET_GAP * 2),
    ]
    if len(loaded) == 3:
        cells[0] = (*cells[0][:2], cell_size, cell_size)
        cells[1] = (*cells[1][:2], cell_size, cell_size)
        cells.append(((width - cell_size) // 2, _REFERENCE_SHEET_GAP * 2 + cell_size, cell_size, cell_size))

    sheet = Image.new("RGB", (width, height), "#f3f4f6")
    draw = ImageDraw.Draw(sheet)
    for image, (left, top, cell_width, cell_height) in zip(loaded, cells):
        draw.rectangle((left, top, left + cell_width, top + cell_height), fill="#ffffff")
        contained = ImageOps.contain(image, (cell_width, cell_height), Image.Resampling.LANCZOS)
        x = left + (cell_width - contained.width) // 2
        y = top + (cell_height - contained.height) // 2
        sheet.paste(contained, (x, y))
        draw.rectangle((left, top, left + cell_width, top + cell_height), outline="#d1d5db", width=2)

    output = io.BytesIO()
    sheet.save(output, format="JPEG", quality=92, optimize=True)
    return output.getvalue()


def build_transparent_prompt(prompt: str) -> str:
    """Append keyed-background instructions for models without native alpha output."""
    return f"{prompt.strip()}\n\n{_TRANSPARENT_PROMPT}"


def remove_keyed_background(data: bytes) -> tuple[bytes, bool]:
    """Convert a model-generated green or magenta key background to alpha."""
    try:
        with Image.open(io.BytesIO(data)) as source:
            source.load()
            image = source.convert("RGBA")
    except (UnidentifiedImageError, OSError):
        return data, False

    alpha = image.getchannel("A")
    if alpha.getextrema()[0] < 250:
        return data, False

    sample = image.copy()
    sample.thumbnail((256, 256), Image.Resampling.BILINEAR)
    pixels = sample.load()
    border: list[tuple[int, int, int]] = []
    for x in range(sample.width):
        border.append(pixels[x, 0][:3])
        border.append(pixels[x, sample.height - 1][:3])
    for y in range(1, sample.height - 1):
        border.append(pixels[0, y][:3])
        border.append(pixels[sample.width - 1, y][:3])
    keys = ((0, 255, 0), (255, 0, 255))
    scores = [sum(max(abs(r - kr), abs(g - kg), abs(b - kb)) <= 100 for r, g, b in border) for kr, kg, kb in keys]
    best_index = 1 if scores[1] > scores[0] else 0
    if not border or scores[best_index] / len(border) < 0.18:
        return data, False

    key = keys[best_index]
    red, green, blue, _ = image.split()
    differences = [
        ImageChops.difference(channel, Image.new("L", image.size, key_value))
        for channel, key_value in zip((red, green, blue), key)
    ]
    max_difference = ImageChops.lighter(ImageChops.lighter(differences[0], differences[1]), differences[2])
    background_mask = max_difference.point(lambda value: 255 if value <= 105 else 0)
    feathered_mask = background_mask.filter(ImageFilter.GaussianBlur(radius=1.2))
    image.putalpha(ImageChops.subtract(alpha, feathered_mask))
    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    return output.getvalue(), True
