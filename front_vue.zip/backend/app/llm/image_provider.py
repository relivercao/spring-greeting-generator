"""OpenAI-compatible image generation provider."""

from __future__ import annotations

import asyncio
import base64
import binascii
import json
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, Optional
from urllib.parse import urlparse

import httpx

from app.core.config import Settings, normalize_api_base
from app.llm.image_processing import (
    MACODE_REFERENCE_SHEET_PROMPT,
    build_transparent_prompt,
    compose_reference_sheet,
    constrain_image_prompt,
    get_reference_timeout,
    is_macode_image_endpoint,
    remove_keyed_background,
)


MIME_TYPES = {
    "png": "image/png",
    "jpeg": "image/jpeg",
    "webp": "image/webp",
}
_RETRYABLE_STATUS_CODES = {408, 409, 425, 429, 500, 502, 503, 504}


class ImageProviderError(Exception):
    """Raised when the configured image provider cannot complete a request."""


@dataclass(frozen=True)
class ImageProviderConfig:
    """Resolved image provider configuration."""

    base_url: str
    api_key: str
    model: str
    provider: str = "macode"
    mode: str = "images"
    timeout_seconds: int = 600
    retry_attempts: int = 2
    max_output_bytes: int = 50 * 1024 * 1024
    stream_images: bool = False
    partial_images: int = 1
    allow_prompt_rewrite: bool = True


@dataclass(frozen=True)
class ImageInput:
    """In-memory image input uploaded by the user."""

    filename: str
    media_type: str
    data: bytes
    width: Optional[int] = None
    height: Optional[int] = None
    optimized: bool = False


@dataclass(frozen=True)
class ImageGenerationOptions:
    """Image generation and editing parameters."""

    size: str = "auto"
    quality: str = "auto"
    output_format: str = "png"
    output_compression: Optional[int] = None
    moderation: str = "auto"
    n: int = 1
    transparent_output: bool = False


@dataclass(frozen=True)
class GeneratedImage:
    """One decoded image returned by the provider."""

    data: bytes
    media_type: str
    revised_prompt: Optional[str] = None
    source_url: Optional[str] = None


@dataclass
class ImageProviderResult:
    """Normalized image provider response."""

    images: list[GeneratedImage]
    actual_params: dict[str, Any] = field(default_factory=dict)
    failed_requests: list[dict[str, Any]] = field(default_factory=list)


def resolve_image_provider_config(settings: Settings) -> ImageProviderConfig:
    """Resolve dedicated image settings with explicit Macode credential sharing."""
    provider = (getattr(settings, "IMAGE_API_PROVIDER", "macode") or "macode").lower()
    if provider not in {"macode", "custom"}:
        provider = "custom"
    if provider == "macode":
        base_url = normalize_api_base(
            settings.IMAGE_API_BASE or settings.TURING_API_BASE or "https://macode.cloud/v1"
        ) or ""
        api_key = settings.IMAGE_API_KEY or settings.TURING_API_KEY or ""
    else:
        base_url = normalize_api_base(settings.IMAGE_API_BASE) or ""
        api_key = settings.IMAGE_API_KEY or ""
    return ImageProviderConfig(
        base_url=base_url,
        api_key=api_key,
        model=settings.IMAGE_API_MODEL,
        provider=provider,
        mode=settings.IMAGE_API_MODE.lower(),
        timeout_seconds=settings.IMAGE_API_TIMEOUT,
        retry_attempts=getattr(settings, "IMAGE_API_RETRIES", 2),
        max_output_bytes=settings.IMAGE_MAX_OUTPUT_BYTES,
        stream_images=getattr(settings, "IMAGE_API_STREAM", False),
        partial_images=getattr(settings, "IMAGE_API_PARTIAL_IMAGES", 1),
        allow_prompt_rewrite=getattr(settings, "IMAGE_API_ALLOW_PROMPT_REWRITE", True),
    )


class OpenAICompatibleImageProvider:
    """Call OpenAI-compatible Images or Responses endpoints."""

    def __init__(
        self,
        config: ImageProviderConfig,
        client: Optional[httpx.AsyncClient] = None,
    ):
        self.config = config
        self._client = client

    async def generate(
        self,
        prompt: str,
        options: ImageGenerationOptions,
        reference_images: Optional[list[ImageInput]] = None,
        mask: Optional[ImageInput] = None,
        request_id: Optional[str] = None,
    ) -> ImageProviderResult:
        """Generate or edit images and normalize the provider response."""
        self._validate_config()
        references = reference_images or []
        if mask and not references:
            raise ImageProviderError("A mask requires at least one reference image")

        effective_prompt = prompt.strip()
        effective_options = options
        uses_macode_compatibility = is_macode_image_endpoint(
            self.config.base_url,
            self.config.model,
            self.config.mode,
        )
        reference_sheet_used = uses_macode_compatibility and not mask and len(references) in {2, 3}
        if reference_sheet_used:
            sheet_data = await asyncio.to_thread(
                compose_reference_sheet,
                [image.data for image in references],
            )
            references = [ImageInput(
                filename="reference-sheet.jpg",
                media_type="image/jpeg",
                data=sheet_data,
                width=2048,
                height=1024 if len(references) == 2 else 2048,
                optimized=True,
            )]
            effective_prompt = f"{effective_prompt}\n\n{MACODE_REFERENCE_SHEET_PROMPT}"

        keyed_transparency = options.transparent_output and uses_macode_compatibility
        if keyed_transparency:
            effective_prompt = build_transparent_prompt(effective_prompt)
            effective_options = replace(
                effective_options,
                output_format="png",
                output_compression=None,
            )
        if not self.config.allow_prompt_rewrite:
            effective_prompt = (
                "Use the following text as the complete prompt. Do not rewrite it:\n"
                f"{effective_prompt}"
            )
        effective_prompt, prompt_truncated = constrain_image_prompt(effective_prompt)

        try:
            if self._client is not None:
                result = await self._generate_with_client(
                    self._client,
                    effective_prompt,
                    effective_options,
                    references,
                    mask,
                    request_id,
                )
            else:
                timeout_seconds = get_reference_timeout(
                    self.config.timeout_seconds,
                    bool(references),
                )
                timeout = httpx.Timeout(timeout_seconds)
                async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                    result = await self._generate_with_client(
                        client,
                        effective_prompt,
                        effective_options,
                        references,
                        mask,
                        request_id,
                    )
        except (httpx.TimeoutException, TimeoutError) as exc:
            timeout_seconds = get_reference_timeout(
                self.config.timeout_seconds,
                bool(references),
            )
            raise ImageProviderError(
                "The image provider request timed out after "
                f"{timeout_seconds} seconds; try a smaller reference image "
                "or increase the image API timeout"
            ) from exc

        transparent_processed = False
        if keyed_transparency:
            processed_images: list[GeneratedImage] = []
            for image in result.images:
                processed_data, processed = await asyncio.to_thread(
                    remove_keyed_background,
                    image.data,
                )
                transparent_processed = transparent_processed or processed
                processed_images.append(GeneratedImage(
                    data=processed_data,
                    media_type="image/png" if processed else image.media_type,
                    revised_prompt=image.revised_prompt,
                    source_url=image.source_url,
                ))
            result.images = processed_images

        result.actual_params.update({
            "prompt_truncated": prompt_truncated,
            "reference_sheet": reference_sheet_used,
            "transparent_background_processed": transparent_processed,
        })
        return result

    async def _generate_with_client(
        self,
        client: httpx.AsyncClient,
        prompt: str,
        options: ImageGenerationOptions,
        references: list[ImageInput],
        mask: Optional[ImageInput],
        request_id: Optional[str],
    ) -> ImageProviderResult:
        if self.config.mode == "responses":
            return await self._call_responses_api(
                client, prompt, options, references, mask, request_id
            )
        return await self._call_images_api(
            client, prompt, options, references, mask, request_id
        )

    async def _call_images_api(
        self,
        client: httpx.AsyncClient,
        prompt: str,
        options: ImageGenerationOptions,
        references: list[ImageInput],
        mask: Optional[ImageInput],
        request_id: Optional[str],
    ) -> ImageProviderResult:
        headers = self._request_headers(request_id)
        fields = self._common_fields(prompt, options)

        if references:
            files: list[tuple[str, tuple[str, bytes, str]]] = [
                ("image[]", (image.filename, image.data, image.media_type))
                for image in references
            ]
            if mask:
                files.append(("mask", (mask.filename, mask.data, mask.media_type)))
            response = await self._post_with_retry(
                client,
                self._endpoint("images/edits"),
                headers=headers,
                data={key: str(value) for key, value in fields.items()},
                files=files,
            )
        else:
            response = await self._post_with_retry(
                client,
                self._endpoint("images/generations"),
                headers={**headers, "Content-Type": "application/json"},
                json=fields,
            )

        if self.config.stream_images and self._is_event_stream(response):
            return await self._normalize_images_stream(client, response, options)
        payload = self._parse_json_response(response)
        return await self._normalize_images_payload(client, payload, options)

    async def _call_responses_api(
        self,
        client: httpx.AsyncClient,
        prompt: str,
        options: ImageGenerationOptions,
        references: list[ImageInput],
        mask: Optional[ImageInput],
        request_id: Optional[str],
    ) -> ImageProviderResult:
        requests = [
            self._call_responses_api_once(
                client,
                prompt,
                options,
                references,
                mask,
                f"{request_id}:{index}" if request_id else None,
            )
            for index in range(options.n)
        ]
        results = await asyncio.gather(*requests, return_exceptions=True)
        images: list[GeneratedImage] = []
        failures: list[dict[str, Any]] = []
        actual_params: dict[str, Any] = {}

        for index, result in enumerate(results):
            if isinstance(result, Exception):
                failures.append({"request_index": index, "error": str(result)})
                continue
            images.extend(result.images)
            failures.extend(
                {
                    "request_index": index,
                    **failure,
                }
                for failure in result.failed_requests
            )
            if not actual_params:
                actual_params = result.actual_params

        if not images:
            message = failures[0]["error"] if failures else "The provider returned no images"
            raise ImageProviderError(message)
        actual_params["n"] = len(images)
        return ImageProviderResult(images, actual_params, failures)

    async def _call_responses_api_once(
        self,
        client: httpx.AsyncClient,
        prompt: str,
        options: ImageGenerationOptions,
        references: list[ImageInput],
        mask: Optional[ImageInput],
        request_id: Optional[str],
    ) -> ImageProviderResult:
        input_value: Any = prompt
        if references:
            input_value = [{
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    *[
                        {
                            "type": "input_image",
                            "image_url": self._to_data_url(image),
                        }
                        for image in references
                    ],
                ],
            }]

        tool: dict[str, Any] = {
            "type": "image_generation",
            "action": "edit" if references else "generate",
            "size": options.size,
            "quality": options.quality,
            "output_format": options.output_format,
            "moderation": options.moderation,
        }
        if self.config.stream_images:
            tool["partial_images"] = self.config.partial_images
        if options.output_format != "png" and options.output_compression is not None:
            tool["output_compression"] = options.output_compression
        if options.transparent_output and self._supports_native_transparency():
            tool["background"] = "transparent"
        if mask:
            tool["input_image_mask"] = {"image_url": self._to_data_url(mask)}

        response = await self._post_with_retry(
            client,
            self._endpoint("responses"),
            headers={**self._request_headers(request_id), "Content-Type": "application/json"},
            json={
                "model": self.config.model,
                "input": input_value,
                "tools": [tool],
                "tool_choice": "required",
                **({"stream": True} if self.config.stream_images else {}),
            },
        )
        if self.config.stream_images and self._is_event_stream(response):
            return await self._normalize_responses_stream(client, response, options)
        payload = self._parse_json_response(response)
        return await self._normalize_responses_payload(client, payload, options)

    def _common_fields(
        self,
        prompt: str,
        options: ImageGenerationOptions,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {
            "model": self.config.model,
            "prompt": prompt,
            "size": options.size,
            "quality": options.quality,
            "output_format": options.output_format,
            "moderation": options.moderation,
            "n": options.n,
            "response_format": "b64_json",
        }
        if options.output_format != "png" and options.output_compression is not None:
            fields["output_compression"] = options.output_compression
        if options.transparent_output and self._supports_native_transparency():
            fields["background"] = "transparent"
        if self.config.stream_images:
            fields["stream"] = True
            fields["partial_images"] = self.config.partial_images
        return fields

    async def _normalize_images_payload(
        self,
        client: httpx.AsyncClient,
        payload: dict[str, Any],
        options: ImageGenerationOptions,
    ) -> ImageProviderResult:
        candidates: list[tuple[str, Optional[str]]] = []
        data = payload.get("data")
        if isinstance(data, list):
            for item in data:
                if not isinstance(item, dict):
                    continue
                value = item.get("b64_json") or item.get("url")
                if isinstance(value, str) and value:
                    revised = item.get("revised_prompt")
                    candidates.append((value, revised if isinstance(revised, str) else None))

        if not candidates:
            fallback_values = self._extract_response_image_values(payload)
            candidates = [(value, None) for value in fallback_values]

        images, failures = await self._decode_candidates(
            client,
            candidates,
            MIME_TYPES[options.output_format],
        )

        if not images:
            detail = f": {failures[0]['error']}" if failures else ""
            raise ImageProviderError(
                "The image provider returned no recognizable image data" + detail
            )
        return ImageProviderResult(
            images=images,
            actual_params=self._pick_actual_params(payload, options, len(images)),
            failed_requests=failures,
        )

    async def _normalize_responses_payload(
        self,
        client: httpx.AsyncClient,
        payload: dict[str, Any],
        options: ImageGenerationOptions,
    ) -> ImageProviderResult:
        candidates: list[tuple[str, Optional[str]]] = []
        output = payload.get("output")
        if isinstance(output, list):
            for item in output:
                if not isinstance(item, dict):
                    continue
                revised = item.get("revised_prompt")
                revised_prompt = revised if isinstance(revised, str) else None
                candidates.extend(
                    (value, revised_prompt)
                    for value in self._extract_response_image_values(item)
                )
        if not candidates:
            candidates.extend(
                (value, None) for value in self._extract_response_image_values(payload)
            )

        images, failures = await self._decode_candidates(
            client,
            candidates,
            MIME_TYPES[options.output_format],
        )
        if not images:
            detail = f": {failures[0]['error']}" if failures else ""
            raise ImageProviderError(
                "The Responses API returned no recognizable image data" + detail
            )
        return ImageProviderResult(
            images=images,
            actual_params=self._pick_actual_params(payload, options, len(images)),
            failed_requests=failures,
        )

    async def _decode_candidates(
        self,
        client: httpx.AsyncClient,
        candidates: list[tuple[str, Optional[str]]],
        fallback_media_type: str,
    ) -> tuple[list[GeneratedImage], list[dict[str, Any]]]:
        """Decode every returned image independently so one bad item cannot hide valid outputs."""
        images: list[GeneratedImage] = []
        failures: list[dict[str, Any]] = []
        for index, (value, revised_prompt) in enumerate(candidates):
            try:
                images.append(await self._decode_image_value(
                    client,
                    value,
                    fallback_media_type,
                    revised_prompt,
                ))
            except ImageProviderError as exc:
                failures.append({"image_index": index, "error": str(exc)})
        return images, failures

    def _extract_response_image_values(self, item: dict[str, Any]) -> list[str]:
        image_keys = {
            "b64", "b64_json", "base64", "download_url", "file_url",
            "image", "image_url", "output_url", "source_url", "url", "uri",
        }
        container_keys = {
            "artifact", "artifacts", "attachment", "attachments", "choices",
            "content", "data", "file", "files", "image_urls", "images",
            "message", "messages", "output", "result", "results", "response", "urls",
        }

        def collect(value: Any, image_context: bool = False) -> list[str]:
            if isinstance(value, str):
                stripped = value.strip()
                return [stripped] if stripped and image_context else []
            if isinstance(value, list):
                values: list[str] = []
                for nested in value:
                    values.extend(collect(nested, image_context))
                return values
            if not isinstance(value, dict):
                return []
            values = []
            for key, nested in value.items():
                normalized_key = str(key).lower()
                if normalized_key in image_keys:
                    values.extend(collect(nested, True))
                elif normalized_key == "result" and value.get("type") == "image_generation_call":
                    values.extend(collect(nested, True))
                elif normalized_key in container_keys:
                    values.extend(collect(nested, image_context))
            return values

        return list(dict.fromkeys(collect(item)))

    async def _decode_image_value(
        self,
        client: httpx.AsyncClient,
        value: str,
        fallback_media_type: str,
        revised_prompt: Optional[str],
    ) -> GeneratedImage:
        if value.lower().startswith(("http://", "https://")):
            parsed = urlparse(value)
            if not parsed.hostname:
                raise ImageProviderError("The provider returned an invalid image URL")
            provider_origin = urlparse(self.config.base_url)
            same_origin = (
                parsed.scheme == provider_origin.scheme
                and parsed.hostname == provider_origin.hostname
                and parsed.port == provider_origin.port
            )
            try:
                response = await self._get_with_retry(client, value)
                if response.status_code in {401, 403} and same_origin:
                    response = await self._get_with_retry(
                        client,
                        value,
                        headers=self._request_headers(),
                    )
            except httpx.HTTPError as exc:
                raise ImageProviderError(
                    f"Generated image download failed for {parsed.hostname}: {exc}"
                ) from exc
            if not response.is_success:
                raise ImageProviderError(
                    f"Generated image download failed ({response.status_code}) from {parsed.hostname}"
                )
            data = response.content
            media_type = response.headers.get("Content-Type", fallback_media_type).split(";", 1)[0]
            self._validate_output(data)
            return GeneratedImage(data, media_type, revised_prompt, value)

        media_type = fallback_media_type
        encoded = value
        if value.lower().startswith("data:"):
            header, separator, encoded = value.partition(",")
            if not separator or ";base64" not in header:
                raise ImageProviderError("The provider returned an unsupported data URL")
            media_type = header[5:].split(";", 1)[0] or fallback_media_type
        try:
            normalized = "".join(encoded.split()).replace("-", "+").replace("_", "/")
            normalized += "=" * (-len(normalized) % 4)
            data = base64.b64decode(normalized, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ImageProviderError("The provider returned invalid base64 image data") from exc
        self._validate_output(data)
        return GeneratedImage(data, media_type, revised_prompt)

    def _validate_output(self, data: bytes) -> None:
        if not data:
            raise ImageProviderError("The provider returned an empty image")
        if len(data) > self.config.max_output_bytes:
            raise ImageProviderError("The generated image exceeds the configured size limit")

    def _parse_json_response(self, response: httpx.Response) -> dict[str, Any]:
        try:
            payload = response.json()
        except ValueError as exc:
            if response.is_success:
                raise ImageProviderError("The image provider returned invalid JSON") from exc
            raise ImageProviderError(
                f"Image API request failed ({response.status_code})"
            ) from exc

        if not response.is_success:
            message = self._extract_error_message(payload)
            request_id = (
                response.headers.get("x-oneapi-request-id")
                or response.headers.get("x-request-id")
                or response.headers.get("request-id")
            )
            trace_id = response.headers.get("x-turing-trace-id")
            diagnostics = ", ".join(
                value for value in (
                    f"Request ID: {request_id}" if request_id else "",
                    f"Trace ID: {trace_id}" if trace_id else "",
                ) if value
            )
            if diagnostics:
                message = f"{message} [{diagnostics}]"
            raise ImageProviderError(
                f"Image API request failed ({response.status_code}): {message}"
            )
        if isinstance(payload, list):
            payload = {"data": payload}
        if not isinstance(payload, dict):
            raise ImageProviderError("The image provider returned an invalid response")
        embedded_error = payload.get("error")
        if embedded_error:
            raise ImageProviderError(self._extract_error_message(payload))
        return payload

    @staticmethod
    def _is_event_stream(response: httpx.Response) -> bool:
        return "text/event-stream" in response.headers.get("Content-Type", "").lower()

    @staticmethod
    def _parse_sse_events(response: httpx.Response) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        normalized = response.text.replace("\r\n", "\n")
        for block in normalized.split("\n\n"):
            data = "\n".join(
                line[5:].lstrip()
                for line in block.splitlines()
                if line.startswith("data:")
            ).strip()
            if not data or data == "[DONE]":
                continue
            try:
                event = json.loads(data)
            except ValueError as exc:
                raise ImageProviderError(
                    "The provider returned an unsupported image stream; disable image streaming"
                ) from exc
            if isinstance(event, dict):
                embedded_error = event.get("error")
                if embedded_error:
                    raise ImageProviderError(OpenAICompatibleImageProvider._extract_error_message(event))
                events.append(event)
        if not events:
            raise ImageProviderError(
                "The provider returned an empty image stream; disable image streaming"
            )
        return events

    async def _normalize_images_stream(
        self,
        client: httpx.AsyncClient,
        response: httpx.Response,
        options: ImageGenerationOptions,
    ) -> ImageProviderResult:
        completed: list[dict[str, Any]] = []
        result_payload: Optional[dict[str, Any]] = None
        for event in self._parse_sse_events(response):
            event_type = event.get("type")
            event_object = event.get("object")
            if event_type in {"image_generation.partial_image", "image_edit.partial_image"}:
                continue
            if event_object in {"image.generation.result", "image.edit.result"}:
                result_payload = event
            elif event_type in {"image_generation.completed", "image_edit.completed"}:
                completed.append(event)
        payload = result_payload or ({"data": completed} if completed else None)
        if payload is None:
            raise ImageProviderError("The image stream did not contain a final image")
        return await self._normalize_images_payload(client, payload, options)

    async def _normalize_responses_stream(
        self,
        client: httpx.AsyncClient,
        response: httpx.Response,
        options: ImageGenerationOptions,
    ) -> ImageProviderResult:
        completed_payload: Optional[dict[str, Any]] = None
        output_items: list[dict[str, Any]] = []
        for event in self._parse_sse_events(response):
            event_type = event.get("type")
            if event_type == "response.image_generation_call.partial_image":
                continue
            event_response = event.get("response")
            if isinstance(event_response, dict):
                completed_payload = event_response
            item = event.get("item")
            if event_type == "response.output_item.done" and isinstance(item, dict):
                output_items.append(item)
        payload = completed_payload or ({"output": output_items} if output_items else None)
        if payload is None:
            raise ImageProviderError("The Responses stream did not contain a final image")
        return await self._normalize_responses_payload(client, payload, options)

    def _supports_native_transparency(self) -> bool:
        return not is_macode_image_endpoint(
            self.config.base_url,
            self.config.model,
            self.config.mode,
        )

    @staticmethod
    def _extract_error_message(payload: Any) -> str:
        if isinstance(payload, dict):
            error = payload.get("error")
            if isinstance(error, dict):
                message = error.get("message") or error.get("type")
                if isinstance(message, str):
                    return message[:1000]
            if isinstance(error, str):
                return error[:1000]
            message = payload.get("message") or payload.get("detail")
            if isinstance(message, str):
                return message[:1000]
        return "Unknown provider error"

    @staticmethod
    def _pick_actual_params(
        payload: dict[str, Any],
        options: ImageGenerationOptions,
        image_count: int,
    ) -> dict[str, Any]:
        params = {
            "size": options.size,
            "quality": options.quality,
            "output_format": options.output_format,
            "moderation": options.moderation,
            "n": image_count,
            "transparent_output": options.transparent_output,
        }
        for key in (
            "size", "quality", "output_format", "output_compression",
            "moderation", "background",
        ):
            if payload.get(key) is not None:
                params[key] = payload[key]
        return params

    def _request_headers(self, request_id: Optional[str] = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.config.api_key}"}
        if request_id:
            headers["Idempotency-Key"] = request_id
            headers["X-Request-Id"] = request_id
        return headers

    async def _post_with_retry(
        self,
        client: httpx.AsyncClient,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Retry transient image-provider POST failures with bounded backoff."""
        return await self._request_with_retry(client, "POST", url, **kwargs)

    async def _get_with_retry(
        self,
        client: httpx.AsyncClient,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Retry transient generated-image download failures with bounded backoff."""
        return await self._request_with_retry(client, "GET", url, **kwargs)

    async def _request_with_retry(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Retry transient image API and artifact download failures."""
        attempts = max(0, self.config.retry_attempts) + 1
        for attempt in range(attempts):
            try:
                response = await client.request(method, url, **kwargs)
            except (
                httpx.TimeoutException,
                httpx.NetworkError,
                httpx.RemoteProtocolError,
            ):
                if attempt + 1 >= attempts:
                    raise
                await asyncio.sleep(min(4.0, 2.0 ** attempt))
            else:
                if response.status_code not in _RETRYABLE_STATUS_CODES or attempt + 1 >= attempts:
                    return response
                await asyncio.sleep(self._retry_delay(response, attempt))
        raise ImageProviderError("The image provider retry loop ended unexpectedly")

    @staticmethod
    def _retry_delay(response: httpx.Response, attempt: int) -> float:
        """Honor either Retry-After format while keeping waits bounded."""
        retry_after = response.headers.get("Retry-After", "").strip()
        if retry_after:
            try:
                delay = float(retry_after)
            except ValueError:
                try:
                    retry_at = parsedate_to_datetime(retry_after)
                    if retry_at.tzinfo is None:
                        retry_at = retry_at.replace(tzinfo=timezone.utc)
                    delay = (retry_at - datetime.now(timezone.utc)).total_seconds()
                except (TypeError, ValueError, OverflowError):
                    delay = 2.0 ** attempt
        else:
            delay = 2.0 ** attempt
        return min(10.0, max(0.0, delay))

    def _endpoint(self, path: str) -> str:
        base_url = self.config.base_url.rstrip("/")
        api_path = path.lstrip("/")
        if not base_url.endswith("/v1"):
            base_url = f"{base_url}/v1"
        return f"{base_url}/{api_path}"

    def _validate_config(self) -> None:
        parsed = urlparse(self.config.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ImageProviderError("Image API base URL is not configured")
        if parsed.username or parsed.password:
            raise ImageProviderError("Image API base URL must not contain credentials")
        if not self.config.api_key:
            raise ImageProviderError("Image API key is not configured")
        if not self.config.model:
            raise ImageProviderError("Image model is not configured")
        if self.config.mode not in {"images", "responses"}:
            raise ImageProviderError("Image API mode must be images or responses")

    @staticmethod
    def _to_data_url(image: ImageInput) -> str:
        encoded = base64.b64encode(image.data).decode("ascii")
        return f"data:{image.media_type};base64,{encoded}"
