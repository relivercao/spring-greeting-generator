"""
@file factory.py
@author caoshwen
@brief LLM provider factory for registration and initialization.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from loguru import logger

from app.core.config import Settings, get_resolved_cli_path, resolve_claude_cli_model, resolve_bedrock_default_model
from app.llm.bridge import LLMBridge
from app.llm.providers.bedrock import BedrockProvider
from app.llm.providers.claude_cli import ClaudeCLIProvider


def create_llm_bridge(settings: Settings) -> LLMBridge:
    """
    Create LLMBridge and register all available providers based on configuration.

    Only providers with configured API Key will be registered.
    Claude CLI is always registered as fallback.

    Args:
        settings: Application configuration

    Returns:
        LLMBridge: Initialized LLMBridge instance
    """
    bridge = LLMBridge(rate_limit_per_minute=settings.LLM_RATE_LIMIT_PER_MINUTE)

    # 1. Bedrock (priority 1)
    if settings.AWS_PROFILE or (settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY):
        bridge.register_provider(BedrockProvider(
            region=settings.AWS_REGION,
            profile_name=settings.AWS_PROFILE,
            access_key_id=settings.AWS_ACCESS_KEY_ID,
            secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            default_model=resolve_bedrock_default_model(settings),
        ))
        logger.info("Registered Bedrock provider (priority=1)")

    # 2. Claude CLI (priority 2 - fallback, always registered)
    cli_model = resolve_claude_cli_model(settings)
    logger.info(f"Claude CLI model resolution: DEFAULT_PROVIDER={settings.DEFAULT_PROVIDER}, final={cli_model}")
    bridge.register_provider(ClaudeCLIProvider(
        cli_path=get_resolved_cli_path(),
        default_model=cli_model,
    ))
    logger.info("Registered Claude CLI provider (priority=2, fallback)")

    registered = bridge.list_providers()
    logger.info(f"LLMBridge ready with {len(registered)} providers")

    return bridge
