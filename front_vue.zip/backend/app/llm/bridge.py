"""
@file bridge.py
@author caoshwen
@brief LLMBridge - unified facade with rate limiting and provider failover.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import time
from dataclasses import asdict
from typing import Any, AsyncIterator, Callable, Optional

from loguru import logger

from app.core.task_context import get_current_task_id

from app.llm.base import (
    AllProvidersFailedError,
    BaseLLMProvider,
    LLMError,
    LLMResponse,
    LLMStreamChunk,
    TokenUsage,
)
from app.llm.adapter import APIFormatAdapter
from app.llm.retry import (
    RetryPolicy,
    TimeoutTier,
    RETRY_STANDARD,
    RETRY_CONSERVATIVE,
    classify_error,
    is_retryable_error,
    resolve_retry_policy,
    resolve_timeout_tier,
)


def _pricing_provider(provider_name, options):
    """Resolve the upstream identity independently of the CLI transport."""
    if options.get("upstream_provider"):
        return options["upstream_provider"]
    if provider_name == "claude_cli":
        from app.core.config import get_settings
        return get_settings().DEFAULT_PROVIDER or "macode"
    return provider_name


def _stream_terminal_usage(usage, provider, options, started, completed=False):
    """Keep reported usage when a stream closes before normal exhaustion."""
    data = asdict(usage) if usage is not None else {"usage_source": "unavailable"}
    return {**data, "status": "completed" if completed else "failed", "latency_ms": (time.time() - started) * 1000,
            "pricing_provider": _pricing_provider(provider, options)}


class UsageTracker:
    """Token usage tracker"""

    def __init__(self):
        self._records: list[dict[str, Any]] = []
        self._task_records: dict[str, list[dict[str, Any]]] = {}

    def record(self, provider: str, usage: TokenUsage, latency_ms: float = 0.0, task_id: Optional[str] = None):
        record = {
            "provider": provider,
            "prompt_tokens": usage.prompt_tokens,
            "completion_tokens": usage.completion_tokens,
            "total_tokens": usage.total_tokens,
            "cache_creation_input_tokens": usage.cache_creation_input_tokens,
            "cache_read_input_tokens": usage.cache_read_input_tokens,
            "latency_ms": latency_ms,
            "timestamp": time.time(),
        }
        self._records.append(record)
        if task_id:
            self._task_records.setdefault(str(task_id), []).append(record)

    def get_task_report(self, task_id: str) -> dict[str, Any]:
        """Return token usage accumulated by one durable task."""
        records = self._task_records.get(str(task_id), [])
        return {
            "input_tokens": sum(item["prompt_tokens"] for item in records),
            "output_tokens": sum(item["completion_tokens"] for item in records),
            "total_tokens": sum(item["total_tokens"] for item in records),
            "cache_creation_input_tokens": sum(item.get("cache_creation_input_tokens", 0) for item in records),
            "cache_read_input_tokens": sum(item.get("cache_read_input_tokens", 0) for item in records),
        }

    def get_report(self) -> dict[str, Any]:
        """Get usage statistics report"""
        total_tokens = sum(r["total_tokens"] for r in self._records)
        total_calls = len(self._records)
        by_provider: dict[str, int] = {}
        for r in self._records:
            by_provider[r["provider"]] = by_provider.get(r["provider"], 0) + r["total_tokens"]
        return {
            "total_tokens": total_tokens,
            "total_calls": total_calls,
            "by_provider": by_provider,
        }


class RateLimiter:
    """Simple rate limiter"""

    def __init__(self, max_per_minute: int = 60):
        self._max_per_minute = max_per_minute
        self._calls: dict[str, list[float]] = {}

    async def acquire(self, provider_name: str) -> None:
        """Acquire a call permit, wait if limit is exceeded"""
        now = time.time()
        calls = self._calls.setdefault(provider_name, [])
        # Clean up records older than 60 seconds
        self._calls[provider_name] = [t for t in calls if now - t < 60]
        calls = self._calls[provider_name]

        if len(calls) >= self._max_per_minute:
            wait_time = 60 - (now - calls[0])
            if wait_time > 0:
                logger.warning(
                    f"Rate limit reached for {provider_name}, waiting {wait_time:.1f}s"
                )
                await asyncio.sleep(wait_time)

        self._calls[provider_name].append(time.time())


class LLMBridge:
    """
    LLM unified facade - the only interaction entry point for the Agent layer.

    Responsibilities:
    - Unified entry: Agent layer only calls LLM through LLMBridge
    - Routing: Select a provider by specification or priority with controlled failover
    - Format conversion: Automatic message format conversion via APIFormatAdapter
    - Monitoring: Tracks Token usage, latency, and error rate
    """

    def __init__(self, rate_limit_per_minute: int = 60):
        self._providers: dict[str, BaseLLMProvider] = {}
        self._health_status: dict[str, bool] = {}
        self._usage_tracker = UsageTracker()
        self._rate_limiter = RateLimiter(rate_limit_per_minute)
        self._adapter = APIFormatAdapter()
        self._error_counts: dict[str, int] = {}  # provider -> consecutive error count
        # Fire-and-forget usage hook (e.g. balance billing), see
        # register_usage_hook below.  Scheduled tasks are referenced so the
        # event loop never garbage-collects a pending deduction.
        self._usage_hook: Optional[Callable] = None
        self._usage_hook_tasks: set[asyncio.Task] = set()

    # ========== Provider Management ==========

    def register_provider(self, provider: BaseLLMProvider) -> None:
        """Register an LLM provider"""
        self._providers[provider.provider_name] = provider
        self._health_status[provider.provider_name] = True
        logger.info(
            f"Registered LLM provider: {provider.provider_name} "
            f"(priority={provider.priority}, format={provider.api_format})"
        )

    def get_provider(self, name: str) -> BaseLLMProvider:
        """Get provider instance by name"""
        if name not in self._providers:
            raise KeyError(f"Provider '{name}' not registered")
        return self._providers[name]

    def list_providers(self) -> list[dict[str, Any]]:
        """List all registered providers and their status"""
        return [
            {
                "name": p.provider_name,
                "api_format": p.api_format.value,
                "priority": p.priority,
                "healthy": self._health_status.get(p.provider_name, False),
                "models": p.supported_models,
            }
            for p in sorted(self._providers.values(), key=lambda x: x.priority)
        ]

    # ========== Usage Hook ==========

    def register_usage_hook(self, callback: Callable) -> None:
        """Register a fire-and-forget usage callback (e.g. balance billing).

        The callback is invoked as ``await callback(provider_name, model,
        usage)`` after each completed provider call (both ``generate`` and
        ``generate_stream`` when the stream exposes usage).  It is scheduled
        as a detached task; exceptions are logged and never propagate into
        the generation path.
        """
        self._usage_hook = callback
        logger.info("Registered LLM usage hook")

    def _fire_usage_hook(
        self,
        provider_name: str,
        model: Optional[str],
        usage: Any,
    ) -> None:
        """Schedule the registered usage hook without blocking generation."""
        if self._usage_hook is None:
            return
        try:
            task = asyncio.create_task(
                self._run_usage_hook(self._usage_hook, provider_name, model, usage)
            )
            self._usage_hook_tasks.add(task)
            task.add_done_callback(self._usage_hook_tasks.discard)
        except Exception as error:
            # create_task itself failing (e.g. no running loop) must never
            # break the provider call that just succeeded.
            logger.error(f"[BILLING] Failed to schedule usage hook: {error}")

    async def _run_usage_hook(
        self,
        hook: Callable,
        provider_name: str,
        model: Optional[str],
        usage: Any,
    ) -> None:
        """Await the usage hook, swallowing and logging any failure."""
        try:
            await hook(provider_name, model, usage)
        except Exception as error:
            logger.exception(
                f"[BILLING] Usage hook failed for {provider_name}: {error}"
            )

    # ========== Core Call ==========

    async def generate(
        self,
        prompt: str | list[dict[str, Any]],
        model: Optional[str] = None,
        provider: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 131072,
        retry_policy: Optional[RetryPolicy] = None,
        timeout_tier: Optional[TimeoutTier] = None,
        unbounded_runtime: bool = False,
        **kwargs,
    ) -> LLMResponse:
        """
        Unified generation interface (non-streaming) with retry and timeout.

        Args:
            prompt: String or message list
            model: Specified model (optional)
            provider: Specified provider (optional, None auto-select by priority)
            temperature: Sampling temperature
            max_tokens: Maximum tokens
            retry_policy: Override retry policy (None = auto-resolve)
            timeout_tier: Override timeout tier (None = auto-resolve)
            unbounded_runtime: Disable the bridge wall-clock timeout for durable jobs

        Returns:
            LLMResponse: Unified response

        Raises:
            LLMError: Provider call failed (after retries exhausted)
            AllProvidersFailedError: No provider available
        """
        messages = self._normalize_prompt(prompt)
        task_id = kwargs.get("task_id") or get_current_task_id()
        providers = self._get_call_provider_chain(provider)
        last_error: Optional[Exception] = None

        for provider_index, p in enumerate(providers):
            if p.provider_name == "claude_cli" and not kwargs.get("task_id") and task_id:
                kwargs["task_id"] = task_id

            current_retry_policy = retry_policy or resolve_retry_policy(p.provider_name)
            current_timeout_tier = timeout_tier or resolve_timeout_tier(
                p.provider_name, is_streaming=False, max_tokens=max_tokens
            )

            for attempt in range(current_retry_policy.max_retries + 1):
                try:
                    await self._rate_limiter.acquire(p.provider_name)
                    adapted_messages = self._adapter.adapt(messages, target_format=p.api_format)
                    start_time = time.time()
                    provider_kwargs = dict(kwargs)
                    if p.provider_name == "claude_cli":
                        provider_kwargs["unbounded_runtime"] = unbounded_runtime
                    provider_call = p.generate(
                        adapted_messages,
                        model=model,
                        temperature=temperature,
                        max_tokens=max_tokens,
                        **provider_kwargs,
                    )
                    response = (
                        await provider_call
                        if unbounded_runtime
                        else await asyncio.wait_for(
                            provider_call,
                            timeout=current_timeout_tier.total_timeout,
                        )
                    )

                    latency_ms = (time.time() - start_time) * 1000
                    response.latency_ms = latency_ms
                    response.usage.latency_ms = latency_ms
                    response.usage.pricing_provider = _pricing_provider(p.provider_name, kwargs)
                    self._usage_tracker.record(p.provider_name, response.usage, latency_ms, task_id)
                    self._fire_usage_hook(p.provider_name, response.model, response.usage)
                    self._health_status[p.provider_name] = True
                    self._error_counts[p.provider_name] = 0
                    if attempt > 0:
                        logger.info(
                            f"[RETRY] {p.provider_name} generate succeeded on "
                            f"attempt {attempt + 1}/{current_retry_policy.max_retries + 1}"
                        )
                    return response

                except asyncio.CancelledError:
                    self._fire_usage_hook(p.provider_name, model, {
                        "status": "failed", "usage_source": "unavailable",
                        "pricing_provider": _pricing_provider(p.provider_name, kwargs),
                    })
                    raise
                except asyncio.TimeoutError:
                    last_error = LLMError(
                        f"{p.provider_name} timed out after {current_timeout_tier.total_timeout}s "
                        f"(tier={current_timeout_tier.label})",
                        provider=p.provider_name,
                        status_code=408,
                    )
                    error_info = classify_error(last_error)
                    self._record_error(p.provider_name, last_error)
                except Exception as error:
                    last_error = error
                    error_info = classify_error(error)
                    self._record_error(p.provider_name, error)

                if attempt < current_retry_policy.max_retries and is_retryable_error(
                    last_error, current_retry_policy
                ):
                    delay = current_retry_policy.get_delay(attempt)
                    logger.warning(
                        f"[RETRY] {p.provider_name} generate attempt {attempt + 1}/"
                        f"{current_retry_policy.max_retries + 1} failed "
                        f"[{error_info['category']}]: {last_error}. Retrying in {delay:.1f}s..."
                    )
                    await asyncio.sleep(delay)
                    continue

                logger.error(
                    f"[RETRY] {p.provider_name} generate failed after "
                    f"{attempt + 1} attempts [{error_info['category']}]: {last_error}"
                )
                break

            self._fire_usage_hook(p.provider_name, model or getattr(p, "_default_model", None), {
                "status": "failed", "usage_source": "unavailable",
                "pricing_provider": _pricing_provider(p.provider_name, kwargs),
            })
            if provider is not None:
                raise last_error  # type: ignore
            if provider_index < len(providers) - 1:
                logger.warning(
                    f"[FALLBACK] {p.provider_name} failed; trying "
                    f"{providers[provider_index + 1].provider_name}"
                )

        raise AllProvidersFailedError(
            f"All LLM providers failed; last error: {last_error}"
        ) from last_error

    async def generate_stream(
        self,
        prompt: str | list[dict[str, Any]],
        model: Optional[str] = None,
        provider: Optional[str] = None,
        retry_policy: Optional[RetryPolicy] = None,
        timeout_tier: Optional[TimeoutTier] = None,
        **kwargs,
    ) -> AsyncIterator[LLMStreamChunk]:
        """
        Unified streaming generation interface (SSE) with retry and timeout.

        Note: Retry for streaming only applies to the initial connection.
        Once streaming starts, errors are propagated immediately.

        Yields:
            LLMStreamChunk: Each token chunk
        """
        messages = self._normalize_prompt(prompt)
        max_tokens = kwargs.get("max_tokens", 4096)
        providers = self._get_call_provider_chain(provider)
        last_error: Optional[Exception] = None

        for provider_index, p in enumerate(providers):
            if p.provider_name == "claude_cli" and not kwargs.get("task_id"):
                task_id = get_current_task_id()
                if task_id:
                    kwargs["task_id"] = task_id
            current_retry_policy = retry_policy or resolve_retry_policy(p.provider_name)
            current_timeout_tier = timeout_tier or resolve_timeout_tier(
                p.provider_name, is_streaming=True, max_tokens=max_tokens
            )

            for attempt in range(current_retry_policy.max_retries + 1):
                stream_started = False
                # Providers that report usage attach it to the final chunk;
                # remember the last one seen so billing can fire at the end.
                stream_usage = None
                stream_completed = False
                stream_start = time.time()
                try:
                    await self._rate_limiter.acquire(p.provider_name)
                    adapted = self._adapter.adapt(messages, target_format=p.api_format)
                    async for chunk in p.generate_stream(adapted, model=model, **kwargs):
                        stream_started = True
                        if chunk.usage is not None:
                            stream_usage = chunk.usage
                        stream_completed = stream_completed or chunk.is_final
                        yield chunk

                    self._health_status[p.provider_name] = True
                    self._error_counts[p.provider_name] = 0
                    # Missing usage is recorded explicitly without inventing
                    # token counts or a billable consumption estimate.
                    if stream_usage is not None:
                        stream_usage.latency_ms = (time.time() - stream_start) * 1000
                        stream_usage.pricing_provider = _pricing_provider(p.provider_name, kwargs)
                    else:
                        stream_usage = {
                            "usage_source": "unavailable",
                            "pricing_provider": _pricing_provider(p.provider_name, kwargs),
                            "latency_ms": (time.time() - stream_start) * 1000,
                        }
                    self._fire_usage_hook(p.provider_name, model or getattr(p, "_default_model", None), stream_usage)
                    return

                except GeneratorExit:
                    self._fire_usage_hook(p.provider_name, model or getattr(p, "_default_model", None),
                                          _stream_terminal_usage(stream_usage, p.provider_name, kwargs, stream_start, completed=stream_completed))
                    raise
                except asyncio.CancelledError:
                    self._fire_usage_hook(p.provider_name, model or getattr(p, "_default_model", None),
                                          _stream_terminal_usage(stream_usage, p.provider_name, kwargs, stream_start))
                    raise
                except Exception as error:
                    last_error = error
                    error_info = classify_error(error)
                    self._record_error(p.provider_name, error)
                    if stream_started:
                        self._fire_usage_hook(p.provider_name, model or getattr(p, "_default_model", None),
                                              _stream_terminal_usage(stream_usage, p.provider_name, kwargs, stream_start))
                        logger.error(
                            f"[STREAM] {p.provider_name} failed after output started: {error}"
                        )
                        raise
                    if attempt < current_retry_policy.max_retries and is_retryable_error(
                        error, current_retry_policy
                    ):
                        delay = current_retry_policy.get_delay(attempt)
                        logger.warning(
                            f"[RETRY] {p.provider_name} stream attempt {attempt + 1}/"
                            f"{current_retry_policy.max_retries + 1} failed "
                            f"[{error_info['category']}]: {error}. Retrying in {delay:.1f}s..."
                        )
                        await asyncio.sleep(delay)
                        continue

                    logger.error(
                        f"[RETRY] {p.provider_name} stream failed after "
                        f"{attempt + 1} attempts [{error_info['category']}]: {error}"
                    )
                    break

            self._fire_usage_hook(p.provider_name, model or getattr(p, "_default_model", None), {
                "status": "failed", "usage_source": "unavailable",
                "pricing_provider": _pricing_provider(p.provider_name, kwargs),
            })
            if provider is not None:
                raise last_error  # type: ignore
            if provider_index < len(providers) - 1:
                logger.warning(
                    f"[FALLBACK] {p.provider_name} stream failed; trying "
                    f"{providers[provider_index + 1].provider_name}"
                )

        raise AllProvidersFailedError(
            f"All LLM providers failed; last error: {last_error}"
        ) from last_error

    # ========== Health Check ==========

    async def check_all_health(self) -> dict[str, bool]:
        """Check health status of all providers in parallel"""
        tasks = {
            name: asyncio.create_task(p.health_check())
            for name, p in self._providers.items()
        }
        for name, task in tasks.items():
            try:
                self._health_status[name] = await asyncio.wait_for(task, timeout=5.0)
            except (asyncio.TimeoutError, Exception):
                self._health_status[name] = False

        return self._health_status.copy()

    # ========== Usage Statistics ==========

    def get_usage_report(self) -> dict[str, Any]:
        """Get Token usage and cost statistics report"""
        return self._usage_tracker.get_report()

    def get_task_usage(self, task_id: str) -> dict[str, int]:
        """Return token usage accumulated for one task."""
        return self._usage_tracker.get_task_report(task_id)

    def get_error_stats(self) -> dict[str, Any]:
        """Get error statistics per provider.

        Returns:
            Dict with per-provider consecutive error count and health status.
        """
        return {
            name: {
                "healthy": self._health_status.get(name, False),
                "consecutive_errors": self._error_counts.get(name, 0),
            }
            for name in self._providers
        }

    # ========== Error Tracking ==========

    def _record_error(self, provider_name: str, error: Exception) -> None:
        """Record a provider error and update health status."""
        count = self._error_counts.get(provider_name, 0) + 1
        self._error_counts[provider_name] = count

        # Mark unhealthy after 3 consecutive errors
        if count >= 3:
            self._health_status[provider_name] = False
            logger.warning(
                f"[HEALTH] {provider_name} marked unhealthy after "
                f"{count} consecutive errors"
            )

        error_info = classify_error(error)
        logger.debug(
            f"[ERROR_TRACK] {provider_name}: error #{count} "
            f"[{error_info['category']}, status={error_info['status_code']}]"
        )

    # ========== Lifecycle ==========

    async def initialize_all(self) -> None:
        """Initialize all registered providers"""
        for p in self._providers.values():
            try:
                await p.initialize()
                logger.info(f"Initialized provider: {p.provider_name}")
            except Exception as e:
                logger.error(f"Failed to initialize {p.provider_name}: {e}")
                self._health_status[p.provider_name] = False

    async def shutdown_all(self) -> None:
        """Shutdown all providers"""
        if self._usage_hook_tasks:
            await asyncio.gather(*list(self._usage_hook_tasks), return_exceptions=True)
        for p in self._providers.values():
            try:
                await p.shutdown()
            except Exception as e:
                logger.warning(f"Error shutting down {p.provider_name}: {e}")

    # ========== Internal Methods ==========

    def _normalize_prompt(self, prompt: str | list) -> list[dict[str, Any]]:
        """Convert string prompt to unified message format"""
        if isinstance(prompt, str):
            return [{"role": "user", "content": prompt}]
        return prompt

    def _resolve_provider(self, preferred: Optional[str] = None) -> BaseLLMProvider:
        """
        Resolve the single Provider to use.

        - If preferred is specified, use that Provider directly (regardless of health status)
        - Otherwise, DEFAULT_PROVIDER is used first (read from Settings)
        - If DEFAULT_PROVIDER is unavailable, degrade by priority
        - Throws AllProvidersFailedError when no Provider is available
        """
        if preferred:
            if preferred not in self._providers:
                raise AllProvidersFailedError(
                    f"Specified provider '{preferred}' is not registered"
                )
            return self._providers[preferred]

        # Use DEFAULT_PROVIDER as the primary provider. Call-level failover is
        # handled by _get_call_provider_chain after this selection.
        from app.core.config import get_settings
        default_provider = get_settings().DEFAULT_PROVIDER.lower()
        if default_provider in self._providers:
            dp = self._providers[default_provider]
            # Use DEFAULT_PROVIDER directly, don't check health_status
            # If the call fails, let the error propagate to the user
            # don't secretly switch to another provider
            return dp

        # If DEFAULT_PROVIDER is not registered, select first healthy provider by priority
        sorted_providers = sorted(self._providers.values(), key=lambda p: p.priority)
        for p in sorted_providers:
            if self._health_status.get(p.provider_name, True):
                return p

        raise AllProvidersFailedError("No healthy provider available")

    def _get_provider_chain(self, preferred: Optional[str]) -> list[BaseLLMProvider]:
        """Return provider chain sorted by priority (healthy first)"""
        sorted_providers = sorted(self._providers.values(), key=lambda p: p.priority)

        if preferred and preferred in self._providers:
            target = self._providers[preferred]
            others = [p for p in sorted_providers if p.provider_name != preferred]
            return [target] + others

        # Healthy providers come first
        healthy = [
            p for p in sorted_providers
            if self._health_status.get(p.provider_name, True)
        ]
        unhealthy = [
            p for p in sorted_providers
            if not self._health_status.get(p.provider_name, True)
        ]
        return healthy + unhealthy

    def _get_call_provider_chain(self, preferred: Optional[str]) -> list[BaseLLMProvider]:
        """Return providers for one call, keeping explicit selections strict."""
        if preferred is not None:
            return [self._resolve_provider(preferred)]

        primary = self._resolve_provider()
        fallback_chain = self._get_provider_chain(None)
        return [
            primary,
            *[
                candidate
                for candidate in fallback_chain
                if candidate.provider_name != primary.provider_name
            ],
        ]
