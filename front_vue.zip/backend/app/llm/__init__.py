"""
@file __init__.py
@author caoshwen
@brief LLM layer module initialization.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from app.llm.base import (
    APIFormat,
    AllProvidersFailedError,
    BaseLLMProvider,
    LLMError,
    LLMAuthError,
    LLMConnectionError,
    LLMServerError,
    LLMTimeoutError,
    LLMResponse,
    LLMStreamChunk,
    RateLimitError,
    TokenUsage,
    # CLI-specific error types
    CLIActivityTimeoutError,
    CLICancelledError,
    CLIHardTimeoutError,
    CLINotFoundError,
    CLIProcessError,
    CLIStdinError,
)
from app.llm.bridge import LLMBridge
from app.llm.factory import create_llm_bridge
from app.llm.retry import (
    RetryPolicy,
    TimeoutTier,
    RETRY_STANDARD,
    RETRY_AGGRESSIVE,
    RETRY_CONSERVATIVE,
    RETRY_RATE_LIMITED,
    RETRY_CLI,
    RETRY_CLI_RATE_LIMITED,
    RETRY_NONE,
    classify_error,
    is_retryable_error,
    resolve_retry_policy,
    resolve_timeout_tier,
    retry_with_policy,
)

__all__ = [
    "APIFormat",
    "AllProvidersFailedError",
    "BaseLLMProvider",
    "LLMBridge",
    "LLMError",
    "LLMAuthError",
    "LLMConnectionError",
    "LLMServerError",
    "LLMTimeoutError",
    "LLMResponse",
    "LLMStreamChunk",
    "RateLimitError",
    "TokenUsage",
    # CLI-specific error types
    "CLIActivityTimeoutError",
    "CLICancelledError",
    "CLIHardTimeoutError",
    "CLINotFoundError",
    "CLIProcessError",
    "CLIStdinError",
    "create_llm_bridge",
    "RetryPolicy",
    "TimeoutTier",
    "RETRY_STANDARD",
    "RETRY_AGGRESSIVE",
    "RETRY_CONSERVATIVE",
    "RETRY_RATE_LIMITED",
    "RETRY_CLI",
    "RETRY_CLI_RATE_LIMITED",
    "RETRY_NONE",
    "classify_error",
    "is_retryable_error",
    "resolve_retry_policy",
    "resolve_timeout_tier",
    "retry_with_policy",
]
