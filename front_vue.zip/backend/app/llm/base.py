"""
@file base.py
@author caoshwen
@brief BaseLLMProvider abstract class and common LLM data types.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncIterator, Optional
import uuid


CLAUDE_CLI_PROVIDER_NAME = "claude_cli"


class APIFormat(str, Enum):
    """API format types"""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    BEDROCK = "bedrock"
    CLI = "cli"


@dataclass
class LLMResponse:
    """Unified LLM response object"""
    content: str
    model: str
    provider: str
    usage: "TokenUsage"
    finish_reason: Optional[str] = None
    response_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    latency_ms: float = 0.0
    raw_response: Optional[dict[str, Any]] = None


@dataclass
class LLMStreamChunk:
    """A single chunk in streaming output"""
    content: str
    is_final: bool = False
    finish_reason: Optional[str] = None
    usage: Optional["TokenUsage"] = None


@dataclass
class TokenUsage:
    """Token usage statistics"""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cache_read_input_tokens: int = 0
    prompt_includes_cache: bool = False
    usage_source: str = "reported"
    latency_ms: float = 0.0
    pricing_provider: Optional[str] = None

    @property
    def cost_estimate(self) -> float:
        """Estimate cost in USD. Subclasses can override for precise calculation"""
        return 0.0


class LLMError(Exception):
    """Base exception class for LLM call errors"""
    def __init__(self, message: str, provider: str = "", status_code: int = 0):
        self.provider = provider
        self.status_code = status_code
        super().__init__(message)


class AllProvidersFailedError(LLMError):
    """All LLM providers are unavailable"""
    def __init__(self, message: str = "All LLM providers are unavailable"):
        super().__init__(message)


class RateLimitError(LLMError):
    """Rate limit exceeded (HTTP 429)"""
    pass


class LLMTimeoutError(LLMError):
    """LLM call timed out (HTTP 408 or connection/read timeout)"""
    def __init__(self, message: str, provider: str = "", timeout_seconds: float = 0):
        self.timeout_seconds = timeout_seconds
        super().__init__(message, provider=provider, status_code=408)


class LLMConnectionError(LLMError):
    """Network connection failure (DNS, TCP, SSL errors)"""
    pass


class LLMAuthError(LLMError):
    """Authentication / authorization failure (HTTP 401/403)"""
    def __init__(self, message: str, provider: str = "", status_code: int = 401):
        super().__init__(message, provider=provider, status_code=status_code)


class LLMServerError(LLMError):
    """Server-side error (HTTP 500/502/503/504)"""
    pass


# ========== Claude CLI Specific Errors ==========

class CLINotFoundError(LLMError):
    """Claude CLI binary not found on disk or not in PATH."""
    def __init__(self, message: str, cli_path: str = ""):
        self.cli_path = cli_path
        super().__init__(message, provider="claude_cli")


class CLIActivityTimeoutError(LLMTimeoutError):
    """CLI process produced no output for the activity-timeout duration.

    This usually means the CLI is stuck (deadlock, network hang, etc.).
    Retryable because a fresh subprocess may succeed.
    """
    def __init__(self, message: str, timeout_seconds: float = 0, elapsed_seconds: float = 0):
        self.elapsed_seconds = elapsed_seconds
        super().__init__(message, provider="claude_cli", timeout_seconds=timeout_seconds)


class CLIHardTimeoutError(LLMTimeoutError):
    """CLI process exceeded the absolute maximum wall-clock limit.

    The hard-timeout ceiling fires even when the process still shows CPU
    activity, preventing a runaway or fake-active process from running forever.
    """
    def __init__(self, message: str, timeout_seconds: float = 0):
        super().__init__(message, provider="claude_cli", timeout_seconds=timeout_seconds)


class CLIProcessError(LLMError):
    """CLI subprocess exited with a non-zero exit code.

    Process output is inspected to decide retryability. Structured unsuccessful
    completions are terminal unless they identify a known transient failure:
    - Contains '429' / 'rate limit'  -> retryable (upstream rate limit)
    - Contains '503' / 'overloaded'  -> retryable (upstream overloaded)
    - Contains '401' / 'auth'        -> NOT retryable (bad credentials)
    - Contains 'SIGKILL' / 'cancel'  -> NOT retryable (user cancel)
    - Other                          -> retryable (transient process crash)
    """
    def __init__(
        self,
        message: str,
        exit_code: int = 1,
        stderr: str = "",
        stdout: str = "",
        structured_failure: bool = False,
    ):
        self.exit_code = exit_code
        self.stderr = stderr
        self.stdout = stdout
        self.structured_failure = structured_failure
        super().__init__(message, provider="claude_cli", status_code=exit_code)


class CLICancelledError(LLMError):
    """CLI process was cancelled by the user (never retryable)."""
    def __init__(self, message: str = "Task cancelled by user"):
        super().__init__(message, provider="claude_cli")


class CLIStdinError(LLMConnectionError):
    """Failed to write prompt to CLI subprocess stdin (pipe/IO error).

    Retryable because a fresh subprocess may succeed.
    """
    def __init__(self, message: str):
        super().__init__(message, provider="claude_cli")


class BaseLLMProvider(ABC):
    """
    Unified abstract base class for LLM providers.

    All providers must implement:
    - provider_name: unique identifier
    - api_format: API format type
    - supported_models: list of supported models
    - priority: fallback priority (smaller number = higher priority)
    - generate(): synchronous generation
    - generate_stream(): streaming generation
    - health_check(): health check
    """

    # ---------- Metadata (required) ----------

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Provider unique identifier name, e.g., 'turing', 'anthropic', 'bedrock'"""
        ...

    @property
    @abstractmethod
    def api_format(self) -> APIFormat:
        """API format type"""
        ...

    @property
    @abstractmethod
    def supported_models(self) -> list[str]:
        """List of models supported by this provider"""
        ...

    @property
    @abstractmethod
    def priority(self) -> int:
        """Fallback priority (smaller number = higher priority)"""
        ...

    # ---------- Core methods (required) ----------

    @abstractmethod
    async def generate(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stop: Optional[list[str]] = None,
        **kwargs,
    ) -> LLMResponse:
        """
        Synchronous generation (non-streaming).

        Args:
            messages: unified message format [{"role": "user", "content": "..."}]
            model: model name (None to use provider default model)
            temperature: sampling temperature (0.0 ~ 1.0)
            max_tokens: maximum number of tokens to generate
            stop: stop sequences

        Returns:
            LLMResponse: unified response object
        """
        ...

    @abstractmethod
    async def generate_stream(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> AsyncIterator[LLMStreamChunk]:
        """
        Streaming generation (SSE).

        Yields:
            LLMStreamChunk: each token chunk
        """
        ...

    # ---------- Health check (required) ----------

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if provider is available"""
        ...

    # ---------- Lifecycle (optional override) ----------

    async def initialize(self) -> None:
        """Initialize provider (establish connection pool, etc.)"""
        pass

    async def shutdown(self) -> None:
        """Shutdown provider (release resources)"""
        pass

    # ---------- Token calculation (optional override) ----------

    def count_tokens(self, text: str) -> int:
        """Estimate token count for text. Default: char_count / 4"""
        return len(text) // 4
