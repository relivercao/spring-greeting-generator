"""
@file adapter.py
@author caoshwen
@brief API format adapter for OpenAI/Anthropic/Bedrock message conversion.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import Any

from app.llm.base import APIFormat


class APIFormatAdapter:
    """
    Message format adapter.
    The Agent layer consistently uses OpenAI format, and the adapter automatically converts to the target provider format.
    """

    def adapt(
        self,
        messages: list[dict[str, Any]],
        target_format: APIFormat,
    ) -> list[dict[str, Any]]:
        """
        Convert the unified message format to the target provider format.

        Args:
            messages: OpenAI format messages [{"role": "user", "content": "..."}]
            target_format: Target API format

        Returns:
            List of converted messages
        """
        if target_format == APIFormat.OPENAI:
            return self._to_openai(messages)
        elif target_format == APIFormat.ANTHROPIC:
            return self._to_anthropic(messages)
        elif target_format == APIFormat.BEDROCK:
            return self._to_bedrock(messages)
        else:
            return messages

    def _to_openai(self, messages: list[dict]) -> list[dict]:
        """Convert to OpenAI Chat Completion format (pass-through)"""
        return messages

    def _to_anthropic(self, messages: list[dict]) -> list[dict]:
        """
        Convert to Anthropic Messages API format.
        Main difference: system message needs to be extracted separately.
        """
        converted = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                # In Anthropic, system messages are passed via the system parameter, not included in messages
                # We mark it here and let the provider implementation handle it
                converted.append({"role": "system", "content": content})
            elif role == "assistant":
                converted.append({"role": "assistant", "content": content})
            else:
                converted.append({"role": "user", "content": content})
        return converted

    def _to_bedrock(self, messages: list[dict]) -> list[dict]:
        """
        Convert to AWS Bedrock format.
        Bedrock uses Anthropic Messages API style, similar to Anthropic adaptation.
        """
        return self._to_anthropic(messages)

    @staticmethod
    def extract_system_message(messages: list[dict]) -> tuple[str, list[dict]]:
        """
        Extract system message (required by Anthropic/Bedrock).

        Returns:
            (system_text, remaining_messages)
        """
        system_parts = []
        remaining = []
        for msg in messages:
            if msg.get("role") == "system":
                system_parts.append(msg.get("content", ""))
            else:
                remaining.append(msg)
        return "\n".join(system_parts), remaining
