"""
@file retry.py
@author caoshwen
@brief LLM retry policy and 6-level timeout configuration for system stability.

Provides:
- RetryPolicy: configurable exponential-backoff retry with jitter
- TimeoutTier: 6-level timeout hierarchy (fast / normal / extended /
  long_generation / agent_workflow / cli_fallback)
- is_retryable_error(): classifier for transient vs permanent errors
- retry_with_policy(): async decorator / wrapper for LLM calls

@version 3.3
@date 2026-03-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import random
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional, TypeVar

import httpx
from loguru import logger

from app.llm.base import (
    LLMError,
    LLMAuthError,
    LLMConnectionError,
    LLMServerError,
    LLMTimeoutError,
    RateLimitError,
    # CLI-specific error types
    CLIActivityTimeoutError,
    CLICancelledError,
    CLIHardTimeoutError,
    CLINotFoundError,
    CLIProcessError,
    CLIStdinError,
)

T = TypeVar("T")

# ========== Retryable HTTP Status Codes ==========

# These HTTP status codes indicate transient failures that may succeed on retry.
RETRYABLE_STATUS_CODES: frozenset[int] = frozenset({
    408,  # Request Timeout
    429,  # Too Many Requests (Rate Limit)
    500,  # Internal Server Error
    502,  # Bad Gateway
    503,  # Service Unavailable
    504,  # Gateway Timeout
})

# Non-retryable status codes — client errors that won't change on retry.
NON_RETRYABLE_STATUS_CODES: frozenset[int] = frozenset({
    400,  # Bad Request
    401,  # Unauthorized (invalid API key)
    403,  # Forbidden (permission denied)
    404,  # Not Found (wrong endpoint/model)
    422,  # Validation Error (invalid payload)
})


# ========== 6-Level Timeout Tiers ==========

class TimeoutTier(Enum):
    """
    6-level timeout hierarchy for different LLM call scenarios.

    Each tier defines (connect_timeout, read_timeout, total_timeout) in seconds.

    Usage guideline:
        FAST            – health checks, ping, lightweight API meta queries
        NORMAL          – standard chat completions (short prompt/response)
        EXTENDED        – longer completions, RAG-augmented generation
        LONG_GENERATION – large code generation, multi-file output
        AGENT_WORKFLOW  – full agent pipeline (may include tool calls)
        CLI_FALLBACK    – local CLI subprocess, highest tolerance
    """
    FAST            = ("fast",            5,   15,   20)
    NORMAL          = ("normal",         10,   30,   45)
    EXTENDED        = ("extended",       10,   60,   90)
    LONG_GENERATION = ("long_generation", 10,  120,  180)
    AGENT_WORKFLOW  = ("agent_workflow",  15,  300,  360)
    CLI_FALLBACK    = ("cli_fallback",   15,  600,  660)

    def __init__(self, label: str, connect: int, read: int, total: int):
        self.label = label
        self.connect_timeout = connect
        self.read_timeout = read
        self.total_timeout = total

    def to_httpx_timeout(self) -> httpx.Timeout:
        """Convert to httpx.Timeout object for HTTP client usage."""
        return httpx.Timeout(
            connect=float(self.connect_timeout),
            read=float(self.read_timeout),
            write=30.0,
            pool=10.0,
        )

    def __repr__(self) -> str:
        return (
            f"TimeoutTier.{self.name}(connect={self.connect_timeout}s, "
            f"read={self.read_timeout}s, total={self.total_timeout}s)"
        )


# ========== Retry Policy ==========

@dataclass
class RetryPolicy:
    """
    Configurable retry policy with exponential backoff and jitter.

    Attributes:
        max_retries:        Maximum number of retry attempts (0 = no retry).
        base_delay:         Initial delay before first retry (seconds).
        max_delay:          Maximum delay cap (seconds).
        backoff_factor:     Multiplier applied to delay after each retry.
        jitter:             Random jitter range [0, jitter] added to delay.
        retry_on_timeout:   Whether to retry on timeout errors.
        retry_on_rate_limit: Whether to retry on 429 rate-limit errors.
        retry_on_server_error: Whether to retry on 5xx server errors.
        retry_on_connection_error: Whether to retry on network connection errors.
    """
    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    backoff_factor: float = 2.0
    jitter: float = 0.5
    retry_on_timeout: bool = True
    retry_on_rate_limit: bool = True
    retry_on_server_error: bool = True
    retry_on_connection_error: bool = True

    def get_delay(self, attempt: int) -> float:
        """Calculate delay for the given attempt number (0-indexed)."""
        delay = self.base_delay * (self.backoff_factor ** attempt)
        delay = min(delay, self.max_delay)
        delay += random.uniform(0, self.jitter)
        return delay


# ========== Pre-defined Retry Policies ==========

# Conservative policy for non-critical calls (health checks, pings)
RETRY_CONSERVATIVE = RetryPolicy(max_retries=1, base_delay=0.5, max_delay=2.0)

# Standard policy for normal LLM API calls
RETRY_STANDARD = RetryPolicy(max_retries=3, base_delay=1.0, max_delay=30.0)

# Aggressive policy for critical calls that must succeed
RETRY_AGGRESSIVE = RetryPolicy(max_retries=5, base_delay=2.0, max_delay=60.0, backoff_factor=2.0)

# Rate-limit specific policy with longer delays
RETRY_RATE_LIMITED = RetryPolicy(
    max_retries=5,
    base_delay=5.0,
    max_delay=120.0,
    backoff_factor=2.5,
    jitter=2.0,
    retry_on_timeout=False,
    retry_on_server_error=False,
    retry_on_connection_error=False,
    retry_on_rate_limit=True,
)

# No retry policy
RETRY_NONE = RetryPolicy(max_retries=0)


# ========== Pre-defined Retry Policies (CLI) ==========

# CLI-specific retry policy: low retry count (subprocess is heavy), longer base delay
RETRY_CLI = RetryPolicy(
    max_retries=2,
    base_delay=3.0,
    max_delay=30.0,
    backoff_factor=2.0,
    jitter=1.0,
    retry_on_timeout=True,
    retry_on_rate_limit=True,
    retry_on_server_error=True,
    retry_on_connection_error=True,
)

# CLI rate-limit policy: even longer delays for upstream 429
RETRY_CLI_RATE_LIMITED = RetryPolicy(
    max_retries=3,
    base_delay=10.0,
    max_delay=120.0,
    backoff_factor=3.0,
    jitter=3.0,
    retry_on_rate_limit=True,
    retry_on_timeout=False,
    retry_on_server_error=False,
    retry_on_connection_error=False,
)


# ========== Error Classification ==========

def is_retryable_error(error: Exception, policy: RetryPolicy) -> bool:
    """
    Determine whether an error is retryable based on the retry policy.

    Classification logic:
    1. RateLimitError (429): Retryable if policy.retry_on_rate_limit
    2. LLMError with status_code in RETRYABLE_STATUS_CODES: Retryable per policy flags
    3. LLMError with status_code in NON_RETRYABLE_STATUS_CODES: Never retryable
    4. httpx.TimeoutException: Retryable if policy.retry_on_timeout
    5. httpx.ConnectError / httpx.NetworkError: Retryable if policy.retry_on_connection_error
    6. ConnectionError / OSError: Retryable if policy.retry_on_connection_error
    7. asyncio.TimeoutError: Retryable if policy.retry_on_timeout
    8. Other exceptions: Not retryable (unknown errors should fail fast)

    Args:
        error: The exception to classify
        policy: The retry policy to consult

    Returns:
        bool: True if the error should be retried
    """
    # --- CLI-specific errors (check FIRST - most specific) ---
    if isinstance(error, CLICancelledError):
        return False  # User cancellation — never retry

    if isinstance(error, CLINotFoundError):
        return False  # Binary missing — retry won't help

    if isinstance(error, CLIActivityTimeoutError):
        return policy.retry_on_timeout  # Stuck process — fresh subprocess may work

    if isinstance(error, CLIHardTimeoutError):
        return policy.retry_on_timeout  # Wall-clock ceiling — may work next time

    if isinstance(error, CLIStdinError):
        return policy.retry_on_connection_error  # IO pipe error — transient

    if isinstance(error, CLIProcessError):
        return _is_retryable_cli_process_error(error, policy)

    # --- Rate Limit ---
    if isinstance(error, RateLimitError):
        return policy.retry_on_rate_limit

    # --- Custom LLM error subtypes (check BEFORE generic LLMError) ---
    if isinstance(error, LLMAuthError):
        return False  # Auth errors are never retryable

    if isinstance(error, LLMTimeoutError):
        return policy.retry_on_timeout

    if isinstance(error, LLMConnectionError):
        return policy.retry_on_connection_error

    if isinstance(error, LLMServerError):
        return policy.retry_on_server_error

    # --- LLMError with HTTP status code ---
    if isinstance(error, LLMError) and error.status_code:
        code = error.status_code
        if code in NON_RETRYABLE_STATUS_CODES:
            return False
        if code == 429:
            return policy.retry_on_rate_limit
        if code == 408:
            return policy.retry_on_timeout
        if code in (500, 502, 503, 504):
            return policy.retry_on_server_error
        # Unknown status code — don't retry
        return False

    # --- httpx timeout errors ---
    if isinstance(error, httpx.TimeoutException):
        return policy.retry_on_timeout

    # --- httpx connection/network errors ---
    if isinstance(error, (httpx.ConnectError, httpx.NetworkError)):
        return policy.retry_on_connection_error

    # --- httpx generic request errors (DNS, SSL, etc.) ---
    if isinstance(error, httpx.RequestError):
        return policy.retry_on_connection_error

    # --- Python built-in network errors ---
    if isinstance(error, (ConnectionError, OSError)):
        return policy.retry_on_connection_error

    # --- asyncio timeout ---
    if isinstance(error, asyncio.TimeoutError):
        return policy.retry_on_timeout

    # --- Subprocess timeout (Claude CLI) ---
    if isinstance(error, LLMError) and "timed out" in str(error).lower():
        return policy.retry_on_timeout

    # --- Default: don't retry unknown errors ---
    return False


def _is_retryable_cli_process_error(error: "CLIProcessError", policy: RetryPolicy) -> bool:
    """Inspect CLIProcessError stderr to decide retryability.

    Patterns in stderr:
    - rate limit / 429        -> retryable (upstream throttle)
    - overloaded / 503        -> retryable (upstream overloaded)
    - auth / 401 / 403        -> NOT retryable (bad credentials)
    - cancel / SIGKILL        -> NOT retryable (user abort)
    - empty prompt / invalid  -> NOT retryable (bad input)
    - other                   -> retryable (transient crash)
    """
    stderr = (error.stderr or "").lower()
    output = "\n".join((stderr, (getattr(error, "stdout", "") or "").lower()))

    # Non-retryable patterns
    for pattern in ("authentication", "unauthorized", "401", "403", "invalid api key"):
        if pattern in output:
            return False
    for pattern in ("cancel", "sigkill", "sigterm"):
        if pattern in output:
            return False
    for pattern in ("empty prompt", "invalid request", "validation error"):
        if pattern in output:
            return False

    # Retryable patterns
    for pattern in ("rate limit", "429", "too many requests"):
        if pattern in output:
            return policy.retry_on_rate_limit
    for pattern in ("overloaded", "503", "service unavailable", "502", "504"):
        if pattern in output:
            return policy.retry_on_server_error

    # A structured error result is a completed provider response, not a
    # transient subprocess crash. Replaying an identical request cannot repair
    # model/channel configuration or an unusable completion.
    if getattr(error, "structured_failure", False):
        return False

    # Default: treat unknown non-zero exit as transient (crash, OOM, etc.)
    return policy.retry_on_server_error


def _classify_cli_process_error(error: "CLIProcessError") -> str:
    """Classify a CLIProcessError by inspecting stderr content.

    Returns a category string for logging/monitoring.
    """
    stderr = "\n".join((
        (error.stderr or "").lower(),
        (getattr(error, "stdout", "") or "").lower(),
    ))
    if any(p in stderr for p in ("rate limit", "429", "too many requests")):
        return "cli_rate_limit"
    if any(p in stderr for p in ("overloaded", "503", "service unavailable")):
        return "cli_server_overloaded"
    if any(p in stderr for p in ("authentication", "unauthorized", "401", "403", "invalid api key")):
        return "cli_auth_error"
    if any(p in stderr for p in ("cancel", "sigkill", "sigterm")):
        return "cli_cancelled"
    if getattr(error, "structured_failure", False):
        return "cli_completion_error"
    return "cli_process_error"


def classify_error(error: Exception) -> dict[str, Any]:
    """
    Classify an error for logging and monitoring.

    Returns a dict with:
        category: 'rate_limit' | 'timeout' | 'server_error' | 'connection_error' |
                  'client_error' | 'auth_error' | 'cli_activity_timeout' |
                  'cli_hard_timeout' | 'cli_not_found' | 'cli_cancelled' |
                  'cli_stdin_error' | 'cli_process_error' | 'cli_rate_limit' |
                  'cli_server_overloaded' | 'cli_auth_error' | 'unknown'
        retryable: bool (using appropriate default policy)
        status_code: int or 0
        provider: str or ''
    """
    status_code = 0
    provider = ""
    category = "unknown"

    if isinstance(error, LLMError):
        status_code = error.status_code
        provider = error.provider

    # --- CLI-specific classification ---
    if isinstance(error, CLICancelledError):
        category = "cli_cancelled"
    elif isinstance(error, CLINotFoundError):
        category = "cli_not_found"
    elif isinstance(error, CLIActivityTimeoutError):
        category = "cli_activity_timeout"
    elif isinstance(error, CLIHardTimeoutError):
        category = "cli_hard_timeout"
    elif isinstance(error, CLIStdinError):
        category = "cli_stdin_error"
    elif isinstance(error, CLIProcessError):
        category = _classify_cli_process_error(error)
    # --- HTTP provider classification ---
    elif isinstance(error, RateLimitError):
        category = "rate_limit"
    elif isinstance(error, LLMError):
        code = error.status_code
        if code == 401 or code == 403:
            category = "auth_error"
        elif code in NON_RETRYABLE_STATUS_CODES:
            category = "client_error"
        elif code in (500, 502, 503, 504):
            category = "server_error"
        elif code == 408 or "timed out" in str(error).lower():
            category = "timeout"
        elif code == 0:
            # No status code — likely connection/execution error
            msg = str(error).lower()
            if "timeout" in msg or "timed out" in msg:
                category = "timeout"
            elif "connect" in msg or "network" in msg or "dns" in msg:
                category = "connection_error"
            else:
                category = "unknown"
    elif isinstance(error, (httpx.TimeoutException, asyncio.TimeoutError)):
        category = "timeout"
    elif isinstance(error, (httpx.ConnectError, httpx.NetworkError, httpx.RequestError)):
        category = "connection_error"
    elif isinstance(error, (ConnectionError, OSError)):
        category = "connection_error"

    # Use CLI retry policy for CLI errors, standard otherwise
    ref_policy = RETRY_CLI if provider == "claude_cli" else RETRY_STANDARD
    return {
        "category": category,
        "retryable": is_retryable_error(error, ref_policy),
        "status_code": status_code,
        "provider": provider,
    }


# ========== Retry Executor ==========

async def retry_with_policy(
    func: Callable,
    *args,
    policy: RetryPolicy = RETRY_STANDARD,
    timeout_tier: Optional[TimeoutTier] = None,
    operation_name: str = "LLM call",
    **kwargs,
) -> Any:
    """
    Execute an async function with retry policy and optional timeout.

    Args:
        func: Async callable to execute
        *args: Positional arguments for func
        policy: Retry policy to apply
        timeout_tier: Optional timeout tier; if set, wraps call with asyncio.wait_for
        operation_name: Name for logging
        **kwargs: Keyword arguments for func

    Returns:
        The return value of func

    Raises:
        The last exception if all retries are exhausted
    """
    last_error: Optional[Exception] = None

    for attempt in range(policy.max_retries + 1):
        try:
            if timeout_tier:
                result = await asyncio.wait_for(
                    func(*args, **kwargs),
                    timeout=timeout_tier.total_timeout,
                )
            else:
                result = await func(*args, **kwargs)

            # Success — log recovery if this wasn't the first attempt
            if attempt > 0:
                logger.info(
                    f"[RETRY] {operation_name} succeeded on attempt {attempt + 1}/{policy.max_retries + 1}"
                )
            return result

        except Exception as e:
            last_error = e
            error_info = classify_error(e)

            if attempt >= policy.max_retries:
                # Exhausted all retries
                logger.error(
                    f"[RETRY] {operation_name} failed after {attempt + 1} attempts. "
                    f"Last error: [{error_info['category']}] {e}"
                )
                raise

            if not is_retryable_error(e, policy):
                # Non-retryable error — fail immediately
                logger.warning(
                    f"[RETRY] {operation_name} hit non-retryable error "
                    f"[{error_info['category']}, status={error_info['status_code']}]: {e}"
                )
                raise

            delay = policy.get_delay(attempt)
            logger.warning(
                f"[RETRY] {operation_name} attempt {attempt + 1}/{policy.max_retries + 1} "
                f"failed [{error_info['category']}]: {e}. "
                f"Retrying in {delay:.1f}s..."
            )
            await asyncio.sleep(delay)

    # Should never reach here, but safety net
    raise last_error  # type: ignore


# ========== Timeout Resolver ==========

def resolve_timeout_tier(
    provider_name: str,
    is_streaming: bool = False,
    max_tokens: int = 4096,
) -> TimeoutTier:
    """
    Automatically resolve the appropriate timeout tier based on provider and call context.

    Heuristic:
    - CLI provider → CLI_FALLBACK (highest tolerance)
    - max_tokens > 16384 → LONG_GENERATION
    - max_tokens > 4096 → EXTENDED
    - Streaming → EXTENDED (long-lived connection)
    - Default → NORMAL

    Args:
        provider_name: LLM provider identifier
        is_streaming: Whether this is a streaming call
        max_tokens: Maximum token generation count

    Returns:
        TimeoutTier: Appropriate timeout tier
    """
    # CLI always gets highest tolerance
    if provider_name == "claude_cli":
        return TimeoutTier.CLI_FALLBACK

    # Large generation requests
    if max_tokens > 16384:
        return TimeoutTier.LONG_GENERATION

    # Extended for streaming or medium-large requests
    if is_streaming or max_tokens > 4096:
        return TimeoutTier.EXTENDED

    # Default
    return TimeoutTier.NORMAL


def resolve_retry_policy(
    provider_name: str,
    error: Optional[Exception] = None,
) -> RetryPolicy:
    """
    Resolve the appropriate retry policy based on provider and error context.

    - CLI: conservative (max 1 retry, subprocess is expensive)
    - Rate limit: use rate-limited policy (longer backoff)
    - Default: standard policy

    Args:
        provider_name: LLM provider identifier
        error: Optional error to check (for rate-limit detection)

    Returns:
        RetryPolicy: Appropriate retry policy
    """
    if provider_name == "claude_cli":
        # CLI with rate-limit upstream gets special long-delay policy
        if error and isinstance(error, (RateLimitError, CLIProcessError)):
            stderr = getattr(error, 'stderr', '') or ''
            if any(p in stderr.lower() for p in ('rate limit', '429', 'too many')):
                return RETRY_CLI_RATE_LIMITED
        return RETRY_CLI

    if error and isinstance(error, RateLimitError):
        return RETRY_RATE_LIMITED

    return RETRY_STANDARD
