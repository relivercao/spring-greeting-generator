"""
@file claude_cli.py
@author caoshwen
@brief ClaudeCLIProvider - local Claude CLI subprocess fallback.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
import time
from pathlib import Path
from typing import Any, AsyncIterator, Optional

from loguru import logger

from app.llm.base import (
    APIFormat,
    BaseLLMProvider,
    LLMError,
    LLMTimeoutError,
    LLMResponse,
    LLMStreamChunk,
    TokenUsage,
    # CLI-specific error types
    CLIActivityTimeoutError,
    CLICancelledError,
    CLIHardTimeoutError,
    CLINotFoundError,
    CLIProcessError,
    CLIStdinError,
)
from app.infrastructure.claude_session_registry import ClaudeSessionRegistry
from app.utils.claude_cli_result import read_cli_completion


def _get_router_config_api_key() -> str:
    """Read the Router key from generated metadata or runtime settings."""
    try:
        from app.core.config import _BACKEND_DIR
        config_file = _BACKEND_DIR / "config" / "claude_router_config.json"
        if config_file.exists():
            cfg = json.loads(config_file.read_text(encoding="utf-8"))
            providers = cfg.get("Providers", [])
            if providers:
                configured_key = providers[0].get("api_key", "")
                if configured_key:
                    return configured_key
    except Exception:
        pass
    from app.core.config import get_settings
    return get_settings().TURING_API_KEY or ""


def _hidden_subprocess_kwargs() -> dict[str, Any]:
    """Return Windows subprocess options that prevent console popups."""
    import subprocess as sp
    import sys

    if sys.platform != "win32":
        return {}

    startupinfo = sp.STARTUPINFO()
    startupinfo.dwFlags |= sp.STARTF_USESHOWWINDOW
    startupinfo.wShowWindow = 0
    return {
        "creationflags": getattr(sp, "CREATE_NO_WINDOW", 0),
        "startupinfo": startupinfo,
    }


class ClaudeCLIProvider(BaseLLMProvider):
    """
    Claude CLI Provider.

    Invokes Claude model via local `claude` CLI command.
    Serves as the lowest priority fallback provider to ensure the system
    can still provide basic LLM capabilities when all remote
    providers are unavailable.

    Supports bypass_permissions mode, where ClaudeCliMonitor is used
    for real-time output streaming with activity timeout functionality.

    Prerequisites: Requires locally installed and configured Claude CLI.
    """

    def __init__(
        self,
        cli_path: Optional[str] = None,
        default_model: str = "claude-sonnet-4-6",
        timeout: float = 600.0,
        working_dir: Optional[str] = None,
        bypass_permissions: bool = False,
        allowed_dirs: Optional[list[str]] = None,
        activity_timeout: Optional[int] = None,
        api_key: Optional[str] = None,
    ):
        self._cli_path = self._resolve_cli_path(cli_path)
        self._default_model = default_model
        self._timeout = timeout
        self._working_dir = Path(working_dir) if working_dir else None
        self._bypass_permissions = bypass_permissions
        self._allowed_dirs = allowed_dirs
        self._activity_timeout = activity_timeout
        self._api_key = api_key
        self._available = False
        self._availability_lock = asyncio.Lock()
        self._session_registry = ClaudeSessionRegistry()
        self._session_locks: dict[str, asyncio.Lock] = {}

    def _get_session_lock(self, session_id: str) -> asyncio.Lock:
        """Serialize turns that target the same persisted Claude session."""
        lock = self._session_locks.get(session_id)
        if lock is None:
            lock = asyncio.Lock()
            self._session_locks[session_id] = lock
        return lock

    @staticmethod
    def _resolve_cli_path(cli_path: Optional[str]) -> str:
        """Resolve CLI path, use project-configured path if None."""
        if cli_path is None:
            from app.core.config import get_resolved_cli_path
            return get_resolved_cli_path()
        import shutil
        import sys
        if Path(cli_path).exists():
            return cli_path
        resolved = shutil.which(cli_path)
        if resolved:
            return resolved
        if sys.platform == 'win32' and not cli_path.endswith(('.cmd', '.bat', '.exe')):
            resolved = shutil.which(f"{cli_path}.cmd")
            if resolved:
                return resolved
        return cli_path

    @staticmethod
    def _append_session_args(
        command: list[str],
        task_id: Optional[str],
        session_id: Optional[str],
        resume_session: bool,
    ) -> None:
        """Append deterministic session creation or resume arguments."""
        if not session_id:
            command.append("--no-session-persistence")
            return
        if resume_session:
            command.extend(["--resume", session_id])
            return
        command.extend(["--session-id", session_id])
        if task_id:
            command.extend(["--name", f"macode-task-{task_id}"[:80]])

    # ---------- Metadata ----------

    @property
    def provider_name(self) -> str:
        return "claude_cli"

    @property
    def api_format(self) -> APIFormat:
        return APIFormat.CLI

    @property
    def supported_models(self) -> list[str]:
        return [
            "claude-sonnet-4-5-20250929",
            "claude-sonnet-4-6",
        ]

    @property
    def priority(self) -> int:
        return 6

    # ---------- Lifecycle ----------

    @staticmethod
    def _build_cli_env(
        upstream_provider: Optional[str] = None,
        model: Optional[str] = None,
    ) -> dict[str, str]:
        """Build CLI subprocess environment variables to ensure consistent CLI invocation.

        Key settings:
        - CLAUDECODE: Removed, prevent nested session detection causing CLI hang
        - ANTHROPIC_API_KEY / ANTHROPIC_BASE_URL: Point to local Router (default mode)
        - CLAUDE_CODE_USE_BEDROCK / AWS_PROFILE / AWS_REGION: Bedrock direct mode
        - DISABLE_AUTOUPDATER: Disable auto-update check, avoid startup network requests hang
        - DISABLE_TELEMETRY: Disable telemetry, reduce startup network requests
        - PATH: Ensure Node.js in portable package can be found by claude.cmd

        Two connection modes:
        1. Router mode (default): CLI → local Router proxy → upstream provider
        2. Bedrock mode (CLAUDE_CODE_USE_BEDROCK=1): CLI → AWS Bedrock directly via profile
        """
        import os
        from app.core.config import (
            apply_claude_code_token_env,
            get_settings,
            get_resolved_claude_config_dir,
        )
        env = os.environ.copy()
        env.pop('CLAUDECODE', None)
        # A model selected for one Agent must not inherit a stale global model
        # from the parent backend process.  The command-line --model argument
        # remains the source of truth; this environment variable is only used
        # by Claude Code when no explicit argument is supplied.
        env.pop('ANTHROPIC_MODEL', None)
        _s = get_settings()
        effective_model = (model or "").strip() or None

        if upstream_provider is not None and upstream_provider not in {"macode", "bedrock"}:
            raise ValueError(f"Unsupported CLI upstream provider: {upstream_provider}")
        use_bedrock = (
            upstream_provider == "bedrock"
            if upstream_provider is not None
            else _s.CLAUDE_CODE_USE_BEDROCK.strip() in ("1", "true", "yes")
        )
        has_explicit_aws_profile = bool((_s.AWS_PROFILE or "").strip())
        has_static_aws_credentials = bool(
            (_s.AWS_ACCESS_KEY_ID or "").strip() and (_s.AWS_SECRET_ACCESS_KEY or "").strip()
        )

        if use_bedrock:
            # ---------- Bedrock Direct Mode ----------
            # CLI connects directly to AWS Bedrock.
            # Supports: default credential chain, explicit profile, or static keys.
            env.pop('ANTHROPIC_API_KEY', None)
            env.pop('ANTHROPIC_AUTH_TOKEN', None)
            env.pop('ANTHROPIC_BASE_URL', None)
            env['CLAUDE_CODE_USE_BEDROCK'] = '1'

            # Pass through AWS credentials based on what's configured
            if has_explicit_aws_profile:
                # Pre-resolve SSO credentials via boto3 — the Node.js AWS SDK
                # used by Claude CLI often fails to resolve SSO profiles.
                resolved = False
                try:
                    import boto3
                    session = boto3.Session(
                        profile_name=_s.AWS_PROFILE.strip(),
                        region_name=_s.AWS_REGION or None,
                    )
                    creds = session.get_credentials()
                    if creds:
                        frozen = creds.get_frozen_credentials()
                        if frozen.access_key and frozen.secret_key:
                            env['AWS_ACCESS_KEY_ID'] = frozen.access_key
                            env['AWS_SECRET_ACCESS_KEY'] = frozen.secret_key
                            if frozen.token:
                                env['AWS_SESSION_TOKEN'] = frozen.token
                            env.pop('AWS_PROFILE', None)
                            resolved = True
                            logger.info(
                                "Pre-resolved AWS SSO credentials for CLI "
                                f"(profile={_s.AWS_PROFILE.strip()}, "
                                f"key_prefix={frozen.access_key[:8]}...)"
                            )
                except Exception as e:
                    logger.warning(f"Could not pre-resolve AWS SSO credentials: {e}")
                if not resolved:
                    # Fallback: pass profile and let CLI try on its own
                    env['AWS_PROFILE'] = _s.AWS_PROFILE.strip()
                    env.pop('AWS_ACCESS_KEY_ID', None)
                    env.pop('AWS_SECRET_ACCESS_KEY', None)
            elif has_static_aws_credentials:
                env['AWS_ACCESS_KEY_ID'] = _s.AWS_ACCESS_KEY_ID.strip()
                env['AWS_SECRET_ACCESS_KEY'] = _s.AWS_SECRET_ACCESS_KEY.strip()
                env.pop('AWS_PROFILE', None)
            else:
                # Default credential chain
                env.pop('AWS_PROFILE', None)
                env.pop('AWS_ACCESS_KEY_ID', None)
                env.pop('AWS_SECRET_ACCESS_KEY', None)

            if _s.AWS_REGION:
                env['AWS_REGION'] = _s.AWS_REGION
            # Bedrock model name
            if effective_model:
                env['ANTHROPIC_MODEL'] = effective_model
            elif _s.BEDROCK_DEFAULT_MODEL:
                env['ANTHROPIC_MODEL'] = _s.BEDROCK_DEFAULT_MODEL

            # Model aliases for Claude Code CLI
            if _s.ANTHROPIC_DEFAULT_SONNET_MODEL:
                env['ANTHROPIC_DEFAULT_SONNET_MODEL'] = _s.ANTHROPIC_DEFAULT_SONNET_MODEL
            if _s.ANTHROPIC_DEFAULT_OPUS_MODEL:
                env['ANTHROPIC_DEFAULT_OPUS_MODEL'] = _s.ANTHROPIC_DEFAULT_OPUS_MODEL
            if _s.ANTHROPIC_DEFAULT_HAIKU_MODEL:
                env['ANTHROPIC_DEFAULT_HAIKU_MODEL'] = _s.ANTHROPIC_DEFAULT_HAIKU_MODEL

            cred_source = 'profile' if has_explicit_aws_profile else ('static_keys' if has_static_aws_credentials else 'default_chain')
            logger.info(
                f"CLI env: BEDROCK direct mode | "
                f"AWS credential source={cred_source}, "
                f"AWS_REGION={_s.AWS_REGION}, "
                f"model={effective_model or _s.BEDROCK_DEFAULT_MODEL}"
            )
        else:
            # ---------- Router Mode (default) ----------
            # CLI → local Router proxy → upstream provider
            # Bedrock uses direct AWS credentials, not the Router
            env.pop('CLAUDE_CODE_USE_BEDROCK', None)
            env.pop('ANTHROPIC_API_KEY', None)
            env.pop('ANTHROPIC_AUTH_TOKEN', None)
            env.pop('ANTHROPIC_BASE_URL', None)
            api_key = _get_router_config_api_key()

            if api_key:
                env['ANTHROPIC_API_KEY'] = api_key
                env['ANTHROPIC_BASE_URL'] = f"http://{_s.CLAUDE_ROUTER_HOST}:{_s.CLAUDE_ROUTER_PORT}"
                logger.info(
                    f"CLI env: Router mode | DEFAULT_PROVIDER={_s.DEFAULT_PROVIDER}, "
                    f"ANTHROPIC_BASE_URL=http://{_s.CLAUDE_ROUTER_HOST}:{_s.CLAUDE_ROUTER_PORT}, "
                    f"model={effective_model or getattr(_s, 'TURING_DEFAULT_MODEL', None) or 'unset'}"
                )

        # Disable auto-update and telemetry to prevent startup network requests from hanging
        env['DISABLE_AUTOUPDATER'] = '1'
        env['DISABLE_TELEMETRY'] = '1'
        # Portable package scenario: add packaged node/ directory to PATH so claude.cmd can find node
        _backend_dir = Path(__file__).parent.parent.parent.parent
        _portable_node = _backend_dir.parent / "node"
        if _portable_node.exists():
            env['PATH'] = str(_portable_node) + os.pathsep + env.get('PATH', '')
        _project_cfg = get_resolved_claude_config_dir()
        env['CLAUDE_CONFIG_DIR'] = _project_cfg
        apply_claude_code_token_env(env, _s, model=effective_model)
        _subprocess_cfg = env.get('CLAUDE_CONFIG_DIR')
        _using_project_cfg = bool(
            _subprocess_cfg and Path(_subprocess_cfg).resolve() == Path(_project_cfg).resolve()
        )
        logger.warning(
            f"[CLAUDE_CFG_CHECK][simple] using_project_cfg={_using_project_cfg} | "
            f"subprocess_env.CLAUDE_CONFIG_DIR={_subprocess_cfg} | project_cfg={_project_cfg}"
        )
        logger.warning(
            f"[CLI_DIAG][simple-env-build] os.environ.CLAUDE_CONFIG_DIR={os.environ.get('CLAUDE_CONFIG_DIR')} | "
            f"settings={_s.CLAUDE_CONFIG_DIR} | backend_dir={_backend_dir} | resolved={_project_cfg} | "
            f"subprocess_env={_subprocess_cfg}"
        )
        return env

    async def initialize(self) -> None:
        try:
            import subprocess as sp
            env = self._build_cli_env()
            result = await asyncio.to_thread(
                sp.run,
                [self._cli_path, "--version"],
                capture_output=True,
                timeout=15.0,
                env=env,
                **_hidden_subprocess_kwargs(),
            )
            self._available = result.returncode == 0
            if self._available:
                logger.info(f"Claude CLI available: {result.stdout.decode().strip()} (path={self._cli_path}, model={self._default_model})")
            else:
                stderr_text = result.stderr.decode().strip()[:200] if result.stderr else ""
                logger.warning(f"Claude CLI not available (exit code {result.returncode}): {stderr_text}")
        except FileNotFoundError:
            logger.warning(f"Claude CLI not found at: {self._cli_path}")
            self._available = False
        except sp.TimeoutExpired:
            logger.warning(f"Claude CLI check timed out (15s) at: {self._cli_path}")
            self._available = False
        except Exception as e:
            logger.warning(f"Claude CLI check failed: {type(e).__name__}: {e}")
            self._available = False

    async def _ensure_available(self) -> None:
        """Recover provider instances used before lifecycle initialization."""
        if self._available:
            return
        async with self._availability_lock:
            if not self._available:
                await self.initialize()
        if not self._available:
            raise LLMError(
                f"Claude CLI is not available at the configured path: {self._cli_path}",
                provider="claude_cli",
            )

    async def shutdown(self) -> None:
        pass

    # ---------- Core Methods ----------

    async def generate(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stop: Optional[list[str]] = None,
        **kwargs,
    ) -> LLMResponse:
        await self._ensure_available()

        prompt = self._messages_to_prompt(messages)
        model = model or self._default_model
        upstream_provider = kwargs.pop("upstream_provider", None)
        max_turns = kwargs.pop("max_turns", None)
        task_id = kwargs.pop("task_id", None)
        requested_allowed_dirs = kwargs.pop("allowed_dirs", None) or []
        if isinstance(requested_allowed_dirs, str):
            requested_allowed_dirs = [requested_allowed_dirs]
        allowed_dirs = list(dict.fromkeys([
            *(self._allowed_dirs or []),
            *(str(path) for path in requested_allowed_dirs),
        ]))
        requested_session_id = kwargs.pop("claude_session_id", None)
        unbounded_runtime = bool(kwargs.pop("unbounded_runtime", False))
        session_id = (
            self._session_registry.resolve(str(task_id), requested_session_id)
            if task_id
            else None
        )
        logger.info(
            f"Claude CLI generate: path={self._cli_path}, model={model}, "
            f"max_tokens={max_tokens}, task_id={task_id}, session_id={session_id}"
        )
        start = time.time()

        async def execute_turn(resume_session: bool):
            try:
                return await run_turn(resume_session)
            except asyncio.CancelledError:
                if task_id:
                    from app.utils.claude_cli_monitor import kill_cli_by_task_id
                    await asyncio.to_thread(kill_cli_by_task_id, task_id)
                raise

        async def run_turn(resume_session: bool):
            if self._bypass_permissions:
                return await asyncio.get_event_loop().run_in_executor(
                    None,
                    self._execute_with_monitor,
                    prompt,
                    model,
                    upstream_provider,
                    task_id,
                    session_id,
                    resume_session,
                    unbounded_runtime,
                    allowed_dirs,
                )
            return await self._execute_simple(
                prompt,
                model,
                max_tokens,
                upstream_provider,
                max_turns,
                task_id,
                session_id,
                resume_session,
                allowed_dirs,
            )

        execution_result: str | tuple[str, dict[str, Any]]
        if session_id:
            async with self._get_session_lock(session_id):
                resume_session = self._session_registry.has_session(session_id)
                logger.info(
                    f"Claude CLI session mode: task_id={task_id}, "
                    f"session_id={session_id}, resume={resume_session}"
                )
                execution_result = await execute_turn(resume_session)
        else:
            execution_result = await execute_turn(False)

        if isinstance(execution_result, tuple):
            content, raw_usage = execution_result
        else:
            content, raw_usage = execution_result, {}

        latency_ms = (time.time() - start) * 1000
        estimated_prompt_tokens = self.count_tokens(prompt)
        estimated_completion_tokens = self.count_tokens(content)
        usage = self._normalize_token_usage(
            raw_usage,
            estimated_prompt_tokens,
            estimated_completion_tokens,
        )

        return LLMResponse(
            content=content,
            model=model,
            provider="claude_cli",
            usage=usage,
            finish_reason="stop",
            latency_ms=latency_ms,
        )

    def _execute_with_monitor(
        self,
        prompt: str,
        model: str,
        upstream_provider: Optional[str] = None,
        task_id: Optional[str] = None,
        session_id: Optional[str] = None,
        resume_session: bool = False,
        unbounded_runtime: bool = False,
        allowed_dirs: Optional[list[str]] = None,
    ) -> tuple[str, dict[str, Any]]:
        """Execute via ClaudeCliMonitor (bypass_permissions path). Runs in a thread executor."""
        from app.utils.claude_cli_monitor import ClaudeCliMonitor
        monitor = ClaudeCliMonitor(enable_tools=True)
        result = monitor.execute_sync(
            cli_path=self._cli_path,
            prompt=prompt,
            model=model,
            working_dir=self._working_dir,
            timeout=int(self._timeout),
            activity_timeout=self._activity_timeout,
            bypass_permissions=True,
            allowed_dirs=allowed_dirs or self._allowed_dirs,
            task_id=task_id,
            upstream_provider=upstream_provider,
            claude_session_id=session_id,
            resume_session=resume_session,
            unbounded_runtime=unbounded_runtime,
        )
        if result['status'] != 'success':
            error_msg = result.get('error', 'unknown')
            exit_code = result.get('exit_code', 1)
            stderr_text = result.get('stderr', '') or ''
            stdout_text = result.get('output', '') or ''

            # If error message is empty or generic, include stdout for AWS auth errors
            if not error_msg or error_msg == f'exit code: {exit_code}':
                if stdout_text:
                    error_msg = f"{error_msg}\nstdout: {stdout_text[-500:]}"

            # Check failure classification from monitor
            failure_category = result.get('failure_category', '')

            # Provider quota failures are terminal and must not trigger a
            # retry loop or an unrelated AWS SSO login.
            if failure_category == 'quota':
                raise LLMError(
                    f"LLM_QUOTA_EXHAUSTED: {error_msg}",
                    provider="claude_cli",
                    status_code=403,
                )

            # Only Bedrock/AWS authentication failures should trigger SSO.
            # Macode/API provider failures must remain provider-specific.
            is_aws_auth_error = self._is_aws_auth_error(error_msg, stderr_text, stdout_text)
            if failure_category == 'auth' and (
                upstream_provider == 'bedrock' or is_aws_auth_error
            ):
                logger.warning(f"CLI AWS auth error detected: {error_msg[:200]}")
                self._try_trigger_sso_login()
                raise LLMError(
                    f"AWS_AUTH_REQUIRED: {error_msg}",
                    provider="claude_cli",
                    status_code=401,
                )
            if failure_category == 'auth':
                raise LLMError(
                    f"LLM_AUTH_REQUIRED: {error_msg}",
                    provider="claude_cli",
                    status_code=403,
                )

            # Classify monitor errors into specific CLI error types
            error_lower = error_msg.lower()

            if 'activity timeout' in error_lower or 'no output for' in error_lower:
                raise CLIActivityTimeoutError(
                    f"Claude CLI activity timeout: {error_msg}",
                    timeout_seconds=self._activity_timeout or 0,
                )
            elif 'hard timeout' in error_lower or 'exceeded' in error_lower:
                raise CLIHardTimeoutError(
                    f"Claude CLI hard timeout: {error_msg}",
                    timeout_seconds=self._timeout,
                )
            elif 'no progress' in error_lower:
                raise CLIActivityTimeoutError(
                    f"Claude CLI no progress: {error_msg}",
                    timeout_seconds=self._activity_timeout or 0,
                )
            elif 'cancel' in error_lower:
                raise CLICancelledError(f"Claude CLI cancelled: {error_msg}")
            elif 'stdin' in error_lower or 'pipe' in error_lower:
                raise CLIStdinError(f"Claude CLI stdin failure: {error_msg}")
            elif 'not found' in error_lower or 'filenotfound' in error_lower:
                raise CLINotFoundError(
                    f"Claude CLI binary not found: {error_msg}",
                    cli_path=self._cli_path,
                )
            elif exit_code != 0:
                raise CLIProcessError(
                    f"Claude CLI monitor error (exit {exit_code}): {error_msg}",
                    exit_code=exit_code,
                    stderr=stderr_text,
                    stdout=stdout_text,
                    structured_failure=bool(result.get("structured_failure")),
                )
            else:
                raise LLMError(
                    f"Claude CLI monitor error: {error_msg}",
                    provider="claude_cli",
                )
        # Parse stream-json output to extract the final text
        return self._extract_text_from_stream_json(result['output']), dict(
            result.get("token_usage") or {}
        )

    async def _execute_simple(
        self,
        prompt: str,
        model: str,
        max_tokens: int,
        upstream_provider: Optional[str] = None,
        max_turns: Optional[int] = None,
        task_id: Optional[str] = None,
        session_id: Optional[str] = None,
        resume_session: bool = False,
        allowed_dirs: Optional[list[str]] = None,
    ) -> tuple[str, dict[str, Any]]:
        """Execute via subprocess (standard path). Uses run_in_executor for Windows .cmd compatibility."""
        return await asyncio.get_event_loop().run_in_executor(
            None,
            self._execute_simple_sync,
            prompt,
            model,
            upstream_provider,
            max_turns,
            task_id,
            session_id,
            resume_session,
            allowed_dirs,
        )

    def _execute_simple_sync(
        self,
        prompt: str,
        model: str,
        upstream_provider: Optional[str] = None,
        max_turns: Optional[int] = None,
        task_id: Optional[str] = None,
        session_id: Optional[str] = None,
        resume_session: bool = False,
        allowed_dirs: Optional[list[str]] = None,
    ) -> tuple[str, dict[str, Any]]:
        """Synchronous subprocess call - safe for Windows .cmd files.

        Prompt is passed via stdin to avoid Windows command line length limit (8191 chars).
        """
        import subprocess as sp
        from app.core.config import resolve_claude_cli_transport_model

        cli_model = resolve_claude_cli_transport_model(model, upstream_provider)
        if cli_model != model:
            logger.info(
                "Claude CLI model transport alias: requested={}, cli={}",
                model,
                cli_model,
            )
        cmd = [
            self._cli_path,
            "--model", cli_model,
            "--output-format", "json",
            "--print",
            "--tools", "default",
            "--permission-mode", "bypassPermissions",
            "--dangerously-skip-permissions",
        ]
        if self._working_dir:
            cmd.extend(["--add-dir", str(self._working_dir.resolve())])
        for allowed_dir in allowed_dirs or self._allowed_dirs or []:
            cmd.extend(["--add-dir", str(Path(allowed_dir).resolve())])
        self._append_session_args(cmd, task_id, session_id, resume_session)
        if max_turns is not None:
            cmd.extend(["--max-turns", str(max(int(max_turns), 1))])
        env = self._build_cli_env(upstream_provider, model=cli_model)
        process = None
        try:
            process = sp.Popen(
                cmd,
                stdin=sp.PIPE,
                stdout=sp.PIPE,
                stderr=sp.PIPE,
                text=True,
                encoding='utf-8',
                errors='replace',
                env=env,
                **_hidden_subprocess_kwargs(),
            )
            if task_id:
                from app.utils.claude_cli_monitor import register_cli_process
                register_cli_process(task_id, process)
            stdout, stderr = process.communicate(input=prompt, timeout=self._timeout)
            result = type(
                "ClaudeCliCompletedProcess",
                (),
                {
                    "returncode": process.returncode,
                    "stdout": stdout,
                    "stderr": stderr,
                },
            )()
        except sp.TimeoutExpired:
            # Never leave a stuck subprocess hanging the request forever
            try:
                process.kill()
                process.communicate(timeout=5)
            except Exception:
                pass
            raise LLMTimeoutError(
                f"Claude CLI timed out after {self._timeout}s",
                provider="claude_cli",
                timeout_seconds=self._timeout,
            )
        except FileNotFoundError:
            raise CLINotFoundError(
                f"Claude CLI binary not found: {self._cli_path}",
                cli_path=self._cli_path,
            )
        except OSError as e:
            raise CLIStdinError(f"Claude CLI I/O error: {e}")
        except Exception as e:
            raise LLMError(f"Claude CLI execution failed: {e}", provider="claude_cli")
        finally:
            if task_id and process is not None:
                from app.utils.claude_cli_monitor import unregister_cli_process
                unregister_cli_process(task_id, process)

        if task_id:
            from app.utils.claude_cli_monitor import is_cli_cancelled
            if is_cli_cancelled(task_id):
                raise CLICancelledError(f"Claude CLI task {task_id} was cancelled")

        output = (result.stdout or "").strip()
        completion_data, completion_error = read_cli_completion(output)
        if not completion_data:
            completion_data = self._parse_json_completion(output)
            if not completion_data:
                completion_error = None
        structured_failure = bool(
            completion_data and completion_error
        )

        if result.returncode != 0 or structured_failure:
            stdout_text = result.stdout or ""
            stderr_text = result.stderr or ""
            error_details = completion_error or self._format_cli_failure(
                completion_data, stdout_text, stderr_text, result.returncode,
            )

            # Detect AWS authentication errors (non-retryable, requires re-login)
            if self._is_aws_auth_error(
                f"{error_details}\n{stdout_text}", stderr_text, stdout_text
            ):
                logger.warning(f"CLI (simple) AWS auth error detected: {error_details[:200]}")
                self._try_trigger_sso_login()
                raise LLMError(
                    f"AWS_AUTH_REQUIRED: {error_details}",
                    provider="claude_cli",
                    status_code=401,
                )

            raise CLIProcessError(
                f"Claude CLI error (exit {result.returncode}): {error_details}",
                exit_code=result.returncode,
                stderr=stderr_text,
                stdout=stdout_text,
                structured_failure=structured_failure,
            )

        usage_data: dict[str, Any] = {}
        if completion_data:
            data = completion_data
            content = data.get("result", data.get("content", output))
            usage_data = self._extract_usage_data(data)
            if isinstance(content, list):
                content = "".join(
                    block.get("text", "") for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )
        else:
            content = output

        if not content or len(content) < 50:
            logger.warning(f"CLI returned short/empty content ({len(content or '')} chars). stdout[:500]={output[:500]}")
        else:
            logger.info(f"CLI returned {len(content)} chars content")

        return str(content or ""), usage_data

    @staticmethod
    def _parse_json_completion(output: str) -> dict[str, Any]:
        """Parse the single-object JSON completion emitted by plain CLI calls."""
        try:
            data = json.loads(output)
        except (json.JSONDecodeError, TypeError):
            return {}
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _format_cli_failure(
        completion: dict[str, Any],
        stdout: str,
        stderr: str,
        exit_code: int,
    ) -> str:
        """Render a bounded diagnostic without echoing an entire CLI payload."""
        if completion:
            _parsed, diagnostic = read_cli_completion(json.dumps(completion))
            if diagnostic:
                return diagnostic
        if completion:
            detail = completion.get("errors") or completion.get("error")
            if not detail:
                detail = completion.get("result")
            if isinstance(detail, dict):
                detail = detail.get("message") or detail.get("error")
            if isinstance(detail, list):
                detail = "; ".join(str(item) for item in detail if item)
            detail = " ".join(str(detail or "").split())[:240]

            context = []
            stop_reason = completion.get("stop_reason")
            if stop_reason:
                context.append(f"stop_reason={str(stop_reason)[:64]}")
            usage = completion.get("usage")
            if isinstance(usage, dict):
                for key in ("input_tokens", "output_tokens"):
                    value = usage.get(key)
                    if value is None:
                        camel_key = "inputTokens" if key == "input_tokens" else "outputTokens"
                        value = usage.get(camel_key)
                    if value is not None:
                        context.append(f"{key}={value}")
            context_text = f" ({', '.join(context)})" if context else ""
            if detail:
                return f"Structured provider error: {detail}{context_text}"
            return (
                "The model provider returned an unsuccessful structured completion"
                f"{context_text}. Check the selected model/channel and Router logs."
            )

        fallback = stderr.strip() or stdout.strip()
        if fallback:
            return " ".join(fallback.split())[:300]
        return f"Claude CLI exited with code {exit_code} without a diagnostic"

    @staticmethod
    def _extract_usage_data(data: dict[str, Any]) -> dict[str, Any]:
        """Prefer aggregate per-model usage, which includes cache token fields."""
        raw_usage = data.get("usage")
        usage_data = dict(raw_usage) if isinstance(raw_usage, dict) else {}
        model_usage = data.get("modelUsage") or data.get("model_usage")
        if not isinstance(model_usage, dict):
            return usage_data

        aggregate = {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        }
        recognized = False
        aliases = {
            "input_tokens": ("inputTokens", "input_tokens"),
            "output_tokens": ("outputTokens", "output_tokens"),
            "cache_creation_input_tokens": (
                "cacheCreationInputTokens",
                "cache_creation_input_tokens",
            ),
            "cache_read_input_tokens": (
                "cacheReadInputTokens",
                "cache_read_input_tokens",
            ),
        }
        for model_data in model_usage.values():
            if not isinstance(model_data, dict):
                continue
            for normalized_key, candidate_keys in aliases.items():
                for candidate_key in candidate_keys:
                    if candidate_key in model_data:
                        aggregate[normalized_key] += max(
                            0,
                            int(model_data.get(candidate_key) or 0),
                        )
                        recognized = True
                        break

        return aggregate if recognized else usage_data

    @staticmethod
    def _normalize_token_usage(
        usage_data: dict[str, Any],
        estimated_prompt_tokens: int,
        estimated_completion_tokens: int,
    ) -> TokenUsage:
        """Normalize exact Claude CLI usage and fall back to local estimates."""
        prompt_tokens = int(
            usage_data.get("input_tokens")
            or usage_data.get("inputTokens")
            or usage_data.get("prompt_tokens")
            or 0
        )
        completion_tokens = int(
            usage_data.get("output_tokens")
            or usage_data.get("outputTokens")
            or usage_data.get("completion_tokens")
            or 0
        )
        cache_creation_tokens = int(
            usage_data.get("cache_creation_input_tokens")
            or usage_data.get("cacheWriteInputTokens")
            or 0
        )
        cache_read_tokens = int(
            usage_data.get("cache_read_input_tokens")
            or usage_data.get("cacheReadInputTokens")
            or 0
        )

        estimated = not any((prompt_tokens, completion_tokens, cache_creation_tokens, cache_read_tokens))
        if estimated:
            prompt_tokens = estimated_prompt_tokens
            completion_tokens = estimated_completion_tokens

        total_tokens = int(usage_data.get("total_tokens") or usage_data.get("totalTokens") or 0)
        if total_tokens <= 0:
            total_tokens = (
                prompt_tokens
                + completion_tokens
                + cache_creation_tokens
                + cache_read_tokens
            )

        return TokenUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            cache_creation_input_tokens=cache_creation_tokens,
            cache_read_input_tokens=cache_read_tokens,
            usage_source="estimated" if estimated else "reported",
        )

    # ---------- AWS Auth Helpers ----------

    @staticmethod
    def _is_aws_auth_error(error_msg: str, stderr: str, stdout: str) -> bool:
        """Check if CLI output indicates an AWS authentication error."""
        import re
        combined = f"{error_msg}\n{stderr}\n{stdout}".lower()
        auth_patterns = [
            r"sso\s*token.*(?:expired|invalid|missing)",
            r"the\s+sso\s+session\s+.*has\s+expired",
            r"token\s+is\s+expired",
            r"expiredtoken(?:exception)?",
            r"credentials?\s+(?:expired|missing|invalid|not\s+found)",
            r"unable\s+to\s+locate\s+credentials",
            r"not\s+logged\s+in",
            r"aws\s+sso\s+login",
            r"refreshing\s+.*token\s+failed",
            r"no\s+valid\s+credential\s+sources",
            r"could\s+not\s+connect\s+to\s+the\s+endpoint",
            r"security\s+token.*(?:expired|invalid)",
            r"unrecogni[sz]edclientexception",
            r"accessdenied(?:exception)?.*(?:token|credential|sso)",
        ]
        return any(re.search(p, combined) for p in auth_patterns)

    def _try_trigger_sso_login(self) -> None:
        """Best-effort trigger of AWS SSO re-login (non-blocking)."""
        try:
            from app.core.aws_sso_cache import AWSSSOCache
            from app.core.config import get_settings
            settings = get_settings()
            profile = getattr(settings, "AWS_PROFILE", None) or "default"
            region = getattr(settings, "AWS_REGION", None) or "eu-west-1"
            cache = AWSSSOCache(profile_name=profile, region=region)
            result = cache.trigger_sso_login(clear_cache=False)
            logger.info(f"SSO re-login trigger result: {result}")
        except Exception as e:
            logger.warning(f"Failed to trigger SSO re-login: {e}")

    @staticmethod
    def _extract_text_from_stream_json(raw_output: str) -> str:
        """Extract assistant text content from stream-json output."""
        text_parts = []
        for line in raw_output.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
                if msg.get('type') == 'assistant':
                    for item in msg.get('message', {}).get('content', []):
                        if isinstance(item, dict) and item.get('type') == 'text':
                            text_parts.append(item.get('text', ''))
            except (json.JSONDecodeError, AttributeError):
                continue
        return ''.join(text_parts) if text_parts else raw_output

    async def generate_stream(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> AsyncIterator[LLMStreamChunk]:
        await self._ensure_available()

        prompt = self._messages_to_prompt(messages)
        model = model or self._default_model
        upstream_provider = kwargs.pop("upstream_provider", None)
        task_id = kwargs.pop("task_id", None)
        requested_session_id = kwargs.pop("claude_session_id", None)
        session_id = (
            self._session_registry.resolve(str(task_id), requested_session_id)
            if task_id
            else None
        )
        session_lock = self._get_session_lock(session_id) if session_id else None
        if session_lock:
            await session_lock.acquire()
        resume_session = bool(
            session_id and self._session_registry.has_session(session_id)
        )

        from app.core.config import resolve_claude_cli_transport_model

        cli_model = resolve_claude_cli_transport_model(model, upstream_provider)
        if cli_model != model:
            logger.info(
                "Claude CLI stream model transport alias: requested={}, cli={}",
                model,
                cli_model,
            )
        cmd = [
            self._cli_path,
            "--model", cli_model,
            "--print",
            "--tools", "default",
            "--permission-mode", "bypassPermissions",
            "--dangerously-skip-permissions",
        ]
        if self._working_dir:
            cmd.extend(["--add-dir", str(self._working_dir.resolve())])
        for allowed_dir in self._allowed_dirs or []:
            cmd.extend(["--add-dir", str(Path(allowed_dir).resolve())])
        self._append_session_args(cmd, task_id, session_id, resume_session)
        cmd.append(prompt)
        logger.info(
            f"Claude CLI stream: task_id={task_id}, session_id={session_id}, "
            f"resume={resume_session}"
        )

        try:
            import subprocess as sp
            env = self._build_cli_env(upstream_provider, model=cli_model)
            proc = sp.Popen(
                cmd,
                stdout=sp.PIPE,
                stderr=sp.PIPE,
                env=env,
                **_hidden_subprocess_kwargs(),
            )

            buffer = ""
            while True:
                chunk = proc.stdout.read(256)
                if not chunk:
                    break
                text = chunk.decode()
                buffer += text
                yield LLMStreamChunk(content=text)

            proc.wait()

            estimated_tokens = self.count_tokens(buffer)
            yield LLMStreamChunk(
                content="",
                is_final=True,
                finish_reason="stop",
                usage=TokenUsage(
                    prompt_tokens=self.count_tokens(prompt),
                    completion_tokens=estimated_tokens,
                    total_tokens=self.count_tokens(prompt) + estimated_tokens,
                    usage_source="estimated",
                ),
            )

        except sp.TimeoutExpired:
            raise LLMTimeoutError(
                f"Claude CLI stream timed out after {self._timeout}s",
                provider="claude_cli",
                timeout_seconds=self._timeout,
            )
        except Exception as e:
            raise LLMError(f"Claude CLI stream failed: {e}", provider="claude_cli")
        finally:
            if session_lock and session_lock.locked():
                session_lock.release()

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        try:
            await self._ensure_available()
            return True
        except Exception:
            return False

    # ---------- Internal Methods ----------

    @staticmethod
    def _messages_to_prompt(messages: list[dict[str, Any]]) -> str:
        """Convert message list to CLI prompt text."""
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                parts.append(f"[System]\n{content}")
            elif role == "assistant":
                parts.append(f"[Assistant]\n{content}")
            else:
                parts.append(content)
        return "\n\n".join(parts)
