"""
@file bedrock.py
@author caoshwen
@brief BedrockProvider - AWS Bedrock API integration.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import time
from typing import Any, AsyncIterator, Optional

import httpx
from botocore.exceptions import ClientError
from loguru import logger

from app.llm.adapter import APIFormatAdapter
from app.llm.base import (
    APIFormat,
    BaseLLMProvider,
    LLMError,
    LLMConnectionError,
    LLMServerError,
    LLMResponse,
    LLMStreamChunk,
    RateLimitError,
    TokenUsage,
)


class BedrockProvider(BaseLLMProvider):
    """
    AWS Bedrock LLM Provider.

    Calls Anthropic Claude models via AWS Bedrock Runtime API.
    Uses httpx + AWS Signature V4 for authentication.

    Note: For production, use boto3 / aiobotocore for AWS signing.
    This implementation calls Bedrock Converse API directly via httpx.
    """

    def __init__(
        self,
        region: str = "us-east-1",
        profile_name: Optional[str] = None,
        access_key_id: Optional[str] = None,
        secret_access_key: Optional[str] = None,
        default_model: str = "claude-sonnet-4-6",
        timeout: float = 60.0,
    ):
        self._region = region
        self._profile_name = profile_name
        self._access_key_id = access_key_id
        self._secret_access_key = secret_access_key
        self._default_model = default_model
        self._timeout = timeout
        self._client: Optional[Any] = None  # boto3 client or httpx

    # ---------- Metadata ----------

    @property
    def provider_name(self) -> str:
        return "bedrock"

    @property
    def api_format(self) -> APIFormat:
        return APIFormat.BEDROCK

    @property
    def supported_models(self) -> list[str]:
        return [
            "anthropic.claude-sonnet-4-5-20250929-v1:0",
            "anthropic.claude-sonnet-4-6-v1:0",
        ]

    @property
    def priority(self) -> int:
        return 4

    # ---------- Lifecycle ----------

    async def initialize(self) -> None:
        try:
            import boto3

            # If using SSO Profile, validate cache before initializing boto3 client
            if self._profile_name and not (self._access_key_id and self._secret_access_key):
                from app.core.aws_sso_cache import AWSSSOCache
                cache_manager = AWSSSOCache(profile_name=self._profile_name, region=self._region)

                # Check if SSO token is valid (fast check, no aws sts call)
                if not cache_manager.is_token_valid(verify_credentials=False):
                    logger.warning(
                        f"AWS SSO token not found or expired for profile '{self._profile_name}'. "
                        f"Bedrock provider will not be initialized until user completes SSO login."
                    )
                    # Do NOT auto-trigger login here - let the user trigger it via chatbot
                    self._client = None
                    return

            session_kwargs: dict[str, Any] = {"region_name": self._region}
            if self._profile_name:
                session_kwargs["profile_name"] = self._profile_name
            elif self._access_key_id and self._secret_access_key:
                session_kwargs["aws_access_key_id"] = self._access_key_id
                session_kwargs["aws_secret_access_key"] = self._secret_access_key

            session = boto3.Session(**session_kwargs)
            self._client = session.client("bedrock-runtime")
            logger.info(f"Initialized Bedrock provider (region={self._region}, profile={self._profile_name or 'key-based'})")
        except ImportError:
            logger.warning(
                "boto3 not installed. Bedrock provider unavailable. "
                "Install with: pip install boto3"
            )
            self._client = None
        except Exception as e:
            logger.error(f"Failed to initialize Bedrock: {e}")
            self._client = None

    async def shutdown(self) -> None:
        self._client = None

    # ---------- Core Methods ----------

    async def generate(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stop: Optional[list[str]] = None,
        **kwargs,
    ) -> LLMResponse:
        if self._client is None:
            # Try to re-initialize in case user has completed SSO login
            await self.initialize()

            if self._client is None:
                # Check if this is a Profile configuration error
                try:
                    import boto3
                    session = boto3.Session(profile_name=self._profile_name, region_name=self._region)
                    # If session creation succeeds, it's not a Profile error
                except Exception as e:
                    error_msg = str(e).lower()
                    if "could not be found" in error_msg or ("profile" in error_msg and "not found" in error_msg):
                        # Profile configuration error
                        raise LLMError(
                            f"AWS_PROFILE_NOT_FOUND: Profile '{self._profile_name}' not found in ~/.aws/config. "
                            f"Please check server configuration.",
                            provider="bedrock"
                        )

                # Bedrock not initialized - let LLMBridge failover to other providers
                raise LLMError("Bedrock provider not initialized", provider="bedrock")

        model = model or self._default_model
        system_text, user_messages = APIFormatAdapter.extract_system_message(messages)

        # Convert to Bedrock Converse API format
        bedrock_messages = self._to_bedrock_messages(user_messages)

        converse_kwargs: dict[str, Any] = {
            "modelId": model,
            "messages": bedrock_messages,
            "inferenceConfig": {
                "temperature": temperature,
                "maxTokens": max_tokens,
            },
        }
        if system_text:
            converse_kwargs["system"] = [{"text": system_text}]
        if stop:
            converse_kwargs["inferenceConfig"]["stopSequences"] = stop

        start = time.time()
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self._client.converse(**converse_kwargs),
            )
        except self._client.exceptions.ThrottlingException:
            raise RateLimitError(
                "Bedrock rate limit",
                provider="bedrock",
                status_code=429,
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))

            # Handle AWS authentication errors (expired token, invalid credentials)
            if error_code in ["ExpiredToken", "ExpiredTokenException", "UnrecognizedClientException", "InvalidSignatureException"]:
                logger.warning(f"AWS authentication error ({error_code}): {error_msg}")
                raise LLMError(
                    f"AWS_AUTH_REQUIRED: {error_msg}",
                    provider="bedrock",
                    status_code=401,
                )

            # Handle other client errors
            raise LLMError(f"Bedrock client error ({error_code}): {error_msg}", provider="bedrock")
        except Exception as e:
            error_type = type(e).__name__
            error_msg = str(e)

            # Handle SSO token errors (cache missing or expired)
            if any(keyword in error_msg for keyword in [
                "SSO Token", "does not exist", "Token has expired",
                "refresh failed", "retrieving token from sso"
            ]):
                logger.warning(f"AWS SSO token error: {error_msg}")
                raise LLMError(
                    f"AWS_AUTH_REQUIRED: {error_msg}",
                    provider="bedrock",
                    status_code=401,
                )

            if "ServiceUnavailable" in error_type or "InternalServer" in error_type:
                raise LLMServerError(
                    f"Bedrock server error: {e}", provider="bedrock", status_code=503
                )
            raise LLMError(f"Bedrock request failed: {e}", provider="bedrock")

        latency_ms = (time.time() - start) * 1000

        output = response.get("output", {})
        content_blocks = output.get("message", {}).get("content", [])
        content = "".join(
            block.get("text", "") for block in content_blocks if "text" in block
        )

        usage_data = response.get("usage", {})

        return LLMResponse(
            content=content,
            model=model,
            provider="bedrock",
            usage=TokenUsage(
                prompt_tokens=usage_data.get("inputTokens", 0),
                completion_tokens=usage_data.get("outputTokens", 0),
                total_tokens=usage_data.get("totalTokens", 0),
                cache_read_input_tokens=usage_data.get("cacheReadInputTokens", 0),
                cache_creation_input_tokens=usage_data.get("cacheWriteInputTokens", 0),
            ),
            finish_reason=response.get("stopReason", "end_turn"),
            latency_ms=latency_ms,
            raw_response=response,
        )

    async def generate_stream(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> AsyncIterator[LLMStreamChunk]:
        if self._client is None:
            raise LLMError("Bedrock provider not initialized", provider="bedrock")

        model = model or self._default_model
        system_text, user_messages = APIFormatAdapter.extract_system_message(messages)
        bedrock_messages = self._to_bedrock_messages(user_messages)

        converse_kwargs: dict[str, Any] = {
            "modelId": model,
            "messages": bedrock_messages,
            "inferenceConfig": {
                "temperature": temperature,
                "maxTokens": max_tokens,
            },
        }
        if system_text:
            converse_kwargs["system"] = [{"text": system_text}]

        try:
            import asyncio
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self._client.converse_stream(**converse_kwargs),
            )
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))

            # Handle AWS authentication errors
            if error_code in ["ExpiredToken", "ExpiredTokenException", "UnrecognizedClientException", "InvalidSignatureException"]:
                logger.warning(f"AWS authentication error on stream ({error_code}): {error_msg}")
                raise LLMError(
                    f"AWS_AUTH_REQUIRED: {error_msg}",
                    provider="bedrock",
                    status_code=401,
                )

            # Handle throttling
            if error_code == "ThrottlingException":
                raise RateLimitError("Bedrock stream rate limit", provider="bedrock", status_code=429)

            # Handle other errors
            raise LLMError(f"Bedrock stream error ({error_code}): {error_msg}", provider="bedrock")
        except Exception as e:
            error_type = str(type(e))
            error_msg = str(e)

            # Handle SSO token errors (cache missing or expired)
            if any(keyword in error_msg for keyword in [
                "SSO Token", "does not exist", "Token has expired",
                "refresh failed", "retrieving token from sso"
            ]):
                logger.warning(f"AWS SSO token error on stream: {error_msg}")
                raise LLMError(
                    f"AWS_AUTH_REQUIRED: {error_msg}",
                    provider="bedrock",
                    status_code=401,
                )

            if "ThrottlingException" in error_type:
                raise RateLimitError("Bedrock stream rate limit", provider="bedrock", status_code=429)
            if "ServiceUnavailable" in error_type or "InternalServer" in error_type:
                raise LLMServerError(
                    f"Bedrock stream server error: {e}", provider="bedrock", status_code=503
                )
            raise LLMError(f"Bedrock stream error: {e}", provider="bedrock")

        stream = response.get("stream")
        if stream is None:
            raise LLMError("No stream in Bedrock response", provider="bedrock")

        input_tokens = 0
        output_tokens = 0
        stop_reason = None

        for event in stream:
            if "contentBlockDelta" in event:
                delta = event["contentBlockDelta"].get("delta", {})
                text = delta.get("text", "")
                if text:
                    yield LLMStreamChunk(content=text)

            elif "messageStop" in event:
                stop_reason = event["messageStop"].get("stopReason", "end_turn")

            elif "metadata" in event:
                usage = event["metadata"].get("usage", {})
                input_tokens = usage.get("inputTokens", 0)
                output_tokens = usage.get("outputTokens", 0)
                yield LLMStreamChunk(content="", usage=TokenUsage(
                    prompt_tokens=input_tokens, completion_tokens=output_tokens,
                    total_tokens=usage.get("totalTokens", input_tokens + output_tokens),
                    cache_read_input_tokens=usage.get("cacheReadInputTokens", 0),
                    cache_creation_input_tokens=usage.get("cacheWriteInputTokens", 0),
                ))
        yield LLMStreamChunk(content="", is_final=True, finish_reason=stop_reason)

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        try:
            if self._client is None:
                return False
            import asyncio
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self._client.converse(
                    modelId=self._default_model,
                    messages=[{
                        "role": "user",
                        "content": [{"text": "ping"}],
                    }],
                    inferenceConfig={"maxTokens": 1},
                ),
            )
            return True
        except Exception as e:
            logger.debug(f"Bedrock health check failed: {e}")
            return False

    # ---------- Internal Methods ----------

    @staticmethod
    def _to_bedrock_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert unified message format to Bedrock Converse API format."""
        result = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                continue  # system passed via converse() system parameter
            result.append({
                "role": role,
                "content": [{"text": content}] if isinstance(content, str) else content,
            })
        return result
