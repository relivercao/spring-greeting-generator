"""
@file openai_compat.py
@author caoshwen
@brief OpenAICompatibleProvider - base class for OpenAI-compatible APIs.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import time
from typing import Any, AsyncIterator, Optional

import httpx
from loguru import logger

from app.llm.base import (
    APIFormat,
    BaseLLMProvider,
    LLMError,
    LLMAuthError,
    LLMConnectionError,
    LLMServerError,
    LLMTimeoutError,
    LLMResponse,
    LLMStreamChunk,
    RateLimitError,
    TokenUsage,
)


def _reported_usage(data):
    return TokenUsage(
        prompt_tokens=data.get("prompt_tokens", 0),
        completion_tokens=data.get("completion_tokens", 0),
        total_tokens=data.get("total_tokens", 0),
        cache_read_input_tokens=(data.get("prompt_tokens_details") or {}).get("cached_tokens", 0),
        prompt_includes_cache=True,
        usage_source="reported" if data else "unavailable",
    )


class OpenAICompatibleProvider(BaseLLMProvider):
    """
    OpenAI Chat Completion compatible Provider base class.

    Subclasses must set:
    - _name: unique provider identifier
    - _base_url: API base URL
    - _api_key: API key
    - _default_model: default model name
    - _models: list of supported models
    - _priority_value: Fallback priority
    """

    def __init__(
        self,
        name: str,
        base_url: str,
        api_key: str,
        default_model: str,
        models: list[str],
        priority_value: int,
        extra_headers: Optional[dict[str, str]] = None,
        timeout: float = 30.0,
        enable_prompt_caching: bool = False,
    ):
        self._name = name
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._default_model = default_model
        self._models = models
        self._priority_value = priority_value
        self._extra_headers = extra_headers or {}
        self._timeout = timeout
        self._enable_prompt_caching = enable_prompt_caching
        self._client: Optional[httpx.AsyncClient] = None

    # ---------- Metadata ----------

    @property
    def provider_name(self) -> str:
        return self._name

    @property
    def api_format(self) -> APIFormat:
        return APIFormat.OPENAI

    @property
    def supported_models(self) -> list[str]:
        return self._models

    @property
    def priority(self) -> int:
        return self._priority_value

    # ---------- Lifecycle ----------

    async def initialize(self) -> None:
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            **self._extra_headers,
        }
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=headers,
            timeout=httpx.Timeout(self._timeout),
            verify=False,
        )
        logger.info(f"Initialized {self._name} provider (base_url={self._base_url})")

    async def shutdown(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise LLMError(f"{self._name} provider not initialized", provider=self._name)
        return self._client

    # ---------- Core Methods ----------

    @staticmethod
    def _is_anthropic_model(model: str) -> bool:
        """Check if the model is an Anthropic/Claude model."""
        model_lower = (model or "").lower()
        return "claude" in model_lower or "anthropic" in model_lower

    def _inject_prompt_caching(
        self, messages: list[dict[str, Any]], model: str
    ) -> list[dict[str, Any]]:
        """Inject cache_control markers for Anthropic models via OpenAI-compat API.

        Only active when enable_prompt_caching=True and the model is a Claude model.
        Adds cache_control to:
        - System message (identical across turns → stable cache)
        - Second-to-last user message (stable conversation prefix)
        - Last user message (caches full conversation for next call READ hit)
        """
        if not self._enable_prompt_caching:
            return messages
        if not self._is_anthropic_model(model):
            return messages

        result = []
        user_indices = [i for i, m in enumerate(messages) if m.get("role") == "user"]

        breakpoint_indices: set[int] = set()
        if len(user_indices) >= 2:
            breakpoint_indices.add(user_indices[-2])
        if user_indices:
            breakpoint_indices.add(user_indices[-1])

        for i, msg in enumerate(messages):
            new_msg = dict(msg)
            content = msg.get("content", "")
            should_cache = msg.get("role") == "system" or i in breakpoint_indices

            if should_cache and isinstance(content, str) and content:
                new_msg["content"] = [{
                    "type": "text",
                    "text": content,
                    "cache_control": {"type": "ephemeral"},
                }]
            elif should_cache and isinstance(content, list) and content:
                content = [dict(b) if isinstance(b, dict) else b for b in content]
                last_block = content[-1]
                if isinstance(last_block, dict) and "cache_control" not in last_block:
                    last_block = dict(last_block)
                    last_block["cache_control"] = {"type": "ephemeral"}
                    content[-1] = last_block
                new_msg["content"] = content

            result.append(new_msg)

        return result

    async def generate(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stop: Optional[list[str]] = None,
        **kwargs,
    ) -> LLMResponse:
        client = self._get_client()
        model = model or self._default_model

        # Apply prompt caching for Anthropic models (adds cache_control markers)
        messages = self._inject_prompt_caching(messages, model)

        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if stop:
            payload["stop"] = stop

        start = time.time()
        try:
            resp = await client.post("/chat/completions", json=payload)
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            body = e.response.text[:500]
            if status == 429:
                raise RateLimitError(
                    f"Rate limit from {self._name}",
                    provider=self._name,
                    status_code=429,
                )
            if status in (401, 403):
                raise LLMAuthError(
                    f"{self._name} authentication failed (HTTP {status}): {body}",
                    provider=self._name,
                    status_code=status,
                )
            if status in (500, 502, 503, 504):
                raise LLMServerError(
                    f"{self._name} server error (HTTP {status}): {body}",
                    provider=self._name,
                    status_code=status,
                )
            raise LLMError(
                f"{self._name} HTTP {status}: {body}",
                provider=self._name,
                status_code=status,
            )
        except httpx.TimeoutException as e:
            raise LLMTimeoutError(
                f"{self._name} request timed out: {e}",
                provider=self._name,
                timeout_seconds=self._timeout,
            )
        except httpx.ConnectError as e:
            raise LLMConnectionError(
                f"{self._name} connection failed: {e}",
                provider=self._name,
            )
        except httpx.RequestError as e:
            raise LLMConnectionError(
                f"{self._name} request failed: {e}",
                provider=self._name,
            )

        latency_ms = (time.time() - start) * 1000
        data = resp.json()

        choice = data["choices"][0]
        usage_data = data.get("usage", {})

        # MiniMax and some models may return None content with reasoning_content
        msg = choice.get("message", {})
        content = msg.get("content") or msg.get("reasoning_content") or ""

        return LLMResponse(
            content=content,
            model=data.get("model", model),
            provider=self._name,
            usage=_reported_usage(usage_data),
            finish_reason=choice.get("finish_reason"),
            latency_ms=latency_ms,
            raw_response=data,
        )

    async def generate_stream(
        self,
        messages: list[dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs,
    ) -> AsyncIterator[LLMStreamChunk]:
        client = self._get_client()
        model = model or self._default_model

        # Apply prompt caching for Anthropic models (adds cache_control markers)
        messages = self._inject_prompt_caching(messages, model)

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }

        try:
            async with client.stream("POST", "/chat/completions", json=payload) as resp:
                resp.raise_for_status()
                stream_finish_reason = None
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        yield LLMStreamChunk(content="", is_final=True, finish_reason=stream_finish_reason)
                        return

                    chunk_data = json.loads(data_str)
                    usage_data = chunk_data.get("usage")
                    if usage_data:
                        yield LLMStreamChunk(content="", usage=_reported_usage(usage_data))
                    choices = chunk_data.get("choices") or []
                    if not choices:
                        continue
                    delta = choices[0].get("delta", {})
                    content = delta.get("content", "")
                    finish_reason = chunk_data["choices"][0].get("finish_reason")

                    if content:
                        yield LLMStreamChunk(content=content)

                    if finish_reason:
                        stream_finish_reason = finish_reason
                yield LLMStreamChunk(content="", is_final=True, finish_reason=stream_finish_reason)

        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            if status == 429:
                raise RateLimitError(
                    f"Rate limit from {self._name}",
                    provider=self._name,
                    status_code=429,
                )
            if status in (401, 403):
                raise LLMAuthError(
                    f"{self._name} stream auth error (HTTP {status})",
                    provider=self._name,
                    status_code=status,
                )
            if status in (500, 502, 503, 504):
                raise LLMServerError(
                    f"{self._name} stream server error (HTTP {status})",
                    provider=self._name,
                    status_code=status,
                )
            raise LLMError(
                f"{self._name} stream error HTTP {status}",
                provider=self._name,
                status_code=status,
            )
        except httpx.TimeoutException as e:
            raise LLMTimeoutError(
                f"{self._name} stream timed out: {e}",
                provider=self._name,
                timeout_seconds=self._timeout,
            )
        except httpx.RequestError as e:
            raise LLMConnectionError(
                f"{self._name} stream request failed: {e}",
                provider=self._name,
            )

    # ---------- Health Check ----------

    async def health_check(self) -> bool:
        try:
            client = self._get_client()
            resp = await client.post(
                "/chat/completions",
                json={
                    "model": self._default_model,
                    "messages": [{"role": "user", "content": "ping"}],
                    "max_tokens": 1,
                },
            )
            return resp.status_code == 200
        except Exception as e:
            logger.debug(f"{self._name} health check failed: {e}")
            return False
