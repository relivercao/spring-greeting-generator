"""Shared encrypted SMTP transport for system and Agent email delivery."""

from __future__ import annotations

import smtplib
import ssl
from dataclasses import dataclass, field
from email.message import EmailMessage

from app.core.config import Settings


class MailDeliveryError(Exception):
    """A mail configuration or delivery error safe to return to the client."""


@dataclass(frozen=True)
class MailConfiguration:
    host: str
    port: int
    username: str
    password: str = field(repr=False)
    sender: str
    use_tls: bool
    use_ssl: bool

    @property
    def configured(self) -> bool:
        return bool(self.host and self.sender and (not self.username or self.password))

    def validate(self) -> None:
        if not self.host or not self.sender:
            raise MailDeliveryError("SMTP host/from settings are incomplete.")
        if not 1 <= self.port <= 65535:
            raise MailDeliveryError("SMTP port must be between 1 and 65535.")
        if self.use_ssl and self.use_tls:
            raise MailDeliveryError("Select either SSL/TLS or STARTTLS for SMTP.")
        if self.username and not self.password:
            raise MailDeliveryError("SMTP authentication requires a password or Gmail app password.")
        if (self.username or self.password) and not (self.use_ssl or self.use_tls):
            raise MailDeliveryError("SMTP authentication requires an encrypted connection.")


def mail_configuration(settings: Settings, *, approval: bool = False) -> MailConfiguration:
    """Use one complete credential set; keep an explicit legacy approval override."""
    if approval and settings.APPROVAL_SMTP_HOST:
        return MailConfiguration(
            host=str(settings.APPROVAL_SMTP_HOST).strip(),
            port=settings.APPROVAL_SMTP_PORT,
            username=str(settings.APPROVAL_SMTP_USERNAME or "").strip(),
            password=str(settings.APPROVAL_SMTP_PASSWORD or ""),
            sender=str(settings.APPROVAL_SMTP_FROM or settings.APPROVAL_SMTP_USERNAME or "").strip(),
            use_tls=settings.APPROVAL_SMTP_USE_TLS,
            use_ssl=settings.APPROVAL_SMTP_USE_SSL,
        )
    gmail = settings.SMTP_PROVIDER == "gmail"
    username = settings.SMTP_USERNAME.strip()
    return MailConfiguration(
        host="smtp.gmail.com" if gmail else settings.SMTP_HOST.strip(),
        port=settings.SMTP_PORT,
        username=username,
        password="".join(settings.SMTP_PASSWORD.split()) if gmail else settings.SMTP_PASSWORD,
        sender=settings.SMTP_FROM.strip() or username,
        use_tls=not settings.SMTP_USE_SSL if gmail else settings.SMTP_USE_TLS,
        use_ssl=settings.SMTP_USE_SSL,
    )


def smtp_operation(configuration: MailConfiguration, message: EmailMessage | None = None) -> None:
    """Authenticate and optionally send; callers run this blocking IO in a thread."""
    configuration.validate()
    context = ssl.create_default_context()
    try:
        if configuration.use_ssl:
            connection = smtplib.SMTP_SSL(configuration.host, configuration.port, timeout=20, context=context)
        else:
            connection = smtplib.SMTP(configuration.host, configuration.port, timeout=20)
        with connection as client:
            if configuration.use_tls:
                client.starttls(context=context)
            if configuration.username:
                client.login(configuration.username, configuration.password)
            if message is not None:
                message["From"] = configuration.sender
                client.send_message(message)
    except smtplib.SMTPAuthenticationError as error:
        raise MailDeliveryError("SMTP authentication failed. For Gmail, use a Google app password with 2-Step Verification enabled.") from error
    except smtplib.SMTPRecipientsRefused as error:
        raise MailDeliveryError("The email server rejected the recipient address.") from error
    except (smtplib.SMTPException, OSError) as error:
        raise MailDeliveryError("The email server could not complete the request. Check the SMTP host, port, and encryption settings.") from error
