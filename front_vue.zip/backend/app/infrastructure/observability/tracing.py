"""
@file tracing.py
@author caoshwen
@brief TracingService - request tracing with trace ID propagation.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field

from app.infrastructure.observability.logger import LoggerService

log = LoggerService.get_logger("tracing")


class TraceStatus(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Span(BaseModel):
    """A single step in the call chain"""

    span_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    parent_span_id: Optional[str] = None
    operation: str
    status: TraceStatus = TraceStatus.RUNNING
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: Optional[datetime] = None
    duration_ms: Optional[float] = None
    attributes: dict[str, Any] = Field(default_factory=dict)
    error_message: Optional[str] = None


class LLMCallTrace(BaseModel):
    """LLM call trace record"""

    trace_id: str
    workflow_id: Optional[str] = None
    agent_name: str
    provider: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    status: TraceStatus = TraceStatus.COMPLETED
    error_message: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class WorkflowTrace(BaseModel):
    """Workflow trace record"""

    workflow_id: str
    trace_id: str
    agent_name: str
    status: TraceStatus = TraceStatus.RUNNING
    steps: list[Span] = Field(default_factory=list)
    total_llm_calls: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: Optional[datetime] = None


class TracingService:
    """
    Request tracing service.

    Usage:
        tracing = TracingService()
        trace_id = tracing.start_trace("code_review_agent", session_id="abc")
        span_id = tracing.start_span(trace_id, "llm_call")
        tracing.finish_span(trace_id, span_id, attributes={"tokens": 1500})
        tracing.finish_trace(trace_id)
    """

    def __init__(self):
        # trace_id -> WorkflowTrace
        self._traces: dict[str, WorkflowTrace] = {}
        # trace_id -> {span_id -> start_time_monotonic}
        self._span_timers: dict[str, dict[str, float]] = {}

    @staticmethod
    def generate_trace_id() -> str:
        """Generate globally unique trace_id"""
        return uuid.uuid4().hex

    def start_trace(
        self,
        agent_name: str,
        session_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
    ) -> str:
        """
        Start a new trace chain.

        Returns:
            trace_id
        """
        trace_id = self.generate_trace_id()
        wf_id = workflow_id or f"wf-{trace_id[:12]}"

        trace = WorkflowTrace(
            workflow_id=wf_id,
            trace_id=trace_id,
            agent_name=agent_name,
        )
        self._traces[trace_id] = trace
        self._span_timers[trace_id] = {}

        log.info(
            "Trace started",
            trace_id=trace_id,
            agent_name=agent_name,
            session_id=session_id,
            workflow_id=wf_id,
        )
        return trace_id

    def start_span(
        self,
        trace_id: str,
        operation: str,
        parent_span_id: Optional[str] = None,
        attributes: Optional[dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        Record the start of a step in the trace chain.

        Returns:
            span_id, or None if trace_id does not exist
        """
        trace = self._traces.get(trace_id)
        if not trace:
            log.warning("start_span: trace_id not found", trace_id=trace_id)
            return None

        span = Span(
            operation=operation,
            parent_span_id=parent_span_id,
            attributes=attributes or {},
        )
        trace.steps.append(span)
        self._span_timers[trace_id][span.span_id] = time.monotonic()

        return span.span_id

    def finish_span(
        self,
        trace_id: str,
        span_id: str,
        status: TraceStatus = TraceStatus.COMPLETED,
        attributes: Optional[dict[str, Any]] = None,
        error_message: Optional[str] = None,
    ) -> None:
        """Finish a span"""
        trace = self._traces.get(trace_id)
        if not trace:
            return

        for span in trace.steps:
            if span.span_id == span_id:
                span.status = status
                span.finished_at = datetime.now(timezone.utc)
                if error_message:
                    span.error_message = error_message
                if attributes:
                    span.attributes.update(attributes)

                start_time = self._span_timers.get(trace_id, {}).pop(span_id, None)
                if start_time is not None:
                    span.duration_ms = round((time.monotonic() - start_time) * 1000, 2)
                break

    def record_llm_call(self, trace_id: str, llm_trace: LLMCallTrace) -> None:
        """Record an LLM call into the trace chain"""
        trace = self._traces.get(trace_id)
        if not trace:
            return

        trace.total_llm_calls += 1
        trace.total_tokens += llm_trace.total_tokens
        trace.total_cost_usd += llm_trace.cost_usd

        log.debug(
            "LLM call traced",
            trace_id=trace_id,
            provider=llm_trace.provider,
            model=llm_trace.model,
            tokens=llm_trace.total_tokens,
            latency_ms=llm_trace.latency_ms,
        )

    def finish_trace(
        self,
        trace_id: str,
        status: TraceStatus = TraceStatus.COMPLETED,
    ) -> Optional[WorkflowTrace]:
        """
        End the trace chain and return the complete record.

        Returns:
            WorkflowTrace, or None if trace_id does not exist
        """
        trace = self._traces.get(trace_id)
        if not trace:
            return None

        trace.status = status
        trace.finished_at = datetime.now(timezone.utc)

        duration_ms = (
            (trace.finished_at - trace.started_at).total_seconds() * 1000
        )

        log.info(
            "Trace finished",
            trace_id=trace_id,
            agent_name=trace.agent_name,
            status=status.value,
            total_llm_calls=trace.total_llm_calls,
            total_tokens=trace.total_tokens,
            duration_ms=round(duration_ms, 2),
        )

        # Cleanup timers
        self._span_timers.pop(trace_id, None)

        return trace

    def get_trace(self, trace_id: str) -> Optional[WorkflowTrace]:
        """Get trace record"""
        return self._traces.get(trace_id)

    def cleanup_completed(self, max_traces: int = 1000) -> int:
        """
        Clean up completed trace records to prevent memory leaks.

        Returns:
            Number of records cleaned
        """
        completed = [
            tid
            for tid, t in self._traces.items()
            if t.status in (TraceStatus.COMPLETED, TraceStatus.FAILED, TraceStatus.CANCELLED)
        ]
        if len(completed) <= max_traces:
            return 0

        # Sort by start time and delete oldest
        completed.sort(key=lambda tid: self._traces[tid].started_at)
        to_remove = completed[: len(completed) - max_traces]
        for tid in to_remove:
            del self._traces[tid]
            self._span_timers.pop(tid, None)
        return len(to_remove)
