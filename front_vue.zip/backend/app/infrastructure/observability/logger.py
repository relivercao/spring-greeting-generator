"""
@file logger.py
@author caoshwen
@brief LoggerService - loguru-based structured logging.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import sys
from pathlib import Path
from typing import Optional

from loguru import logger


class LoggerService:
    """Unified logging service"""

    _initialized = False
    _task_sinks: dict[str, int] = {}  # task_id -> loguru sink id

    def __init__(
        self,
        log_dir: str = "logs",
        level: str = "DEBUG",
        json_format: bool = True,
        rotation: str = "00:00",
        retention: str = "30 days",
        max_size: str = "50 MB",
    ):
        self.log_dir = Path(log_dir)
        self.level = level
        self.json_format = json_format
        self.rotation = rotation
        self.retention = retention
        self.max_size = max_size

    def setup(self):
        """Initialize logging system, call once at application startup"""
        if LoggerService._initialized:
            return

        self.log_dir.mkdir(parents=True, exist_ok=True)

        # Remove default handler
        logger.remove()

        # Console output with color
        def _console_format(record):
            agent = record["extra"].get("agent_name", "system")
            record["extra"]["agent_name"] = agent
            return (
                "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
                "<level>{level: <8}</level> | "
                f"<cyan>{agent:>12}</cyan> | "
                "{message}\n{exception}"
            )

        logger.add(
            sys.stderr,
            level="INFO",
            format=_console_format,
            colorize=True,
            catch=True,
        )

        # Full log file (JSON)
        logger.add(
            str(self.log_dir / "fw_agent_{time:YYYY-MM-DD}.log"),
            level=self.level,
            format="{message}",
            serialize=self.json_format,
            rotation=self.rotation,
            retention=self.retention,
            compression="gz",
            encoding="utf-8",
            catch=True,
        )

        # Error log (separate file)
        logger.add(
            str(self.log_dir / "error_{time:YYYY-MM-DD}.log"),
            level="ERROR",
            format="{message}",
            serialize=self.json_format,
            rotation=self.rotation,
            retention="90 days",
            compression="gz",
            encoding="utf-8",
            catch=True,
        )

        LoggerService._initialized = True

    @staticmethod
    def get_logger(
        agent_name: str = "system",
        session_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
    ):
        """
        Get a logger instance with context binding.

        Usage:
            log = LoggerService.get_logger("unittest_agent", session_id="abc-123")
            log.info("Starting unit test generation", file="main.c")
        """
        ctx = {"agent_name": agent_name}
        if session_id:
            ctx["session_id"] = session_id
        if workflow_id:
            ctx["workflow_id"] = workflow_id
        return logger.bind(**ctx)

    @staticmethod
    def add_task_sink(
        task_id: str,
        log_dir: str = "logs",
        level: str = "DEBUG",
    ) -> None:
        """Add an independent log file sink for a single task. File name: task_{task_id}.log"""
        if task_id in LoggerService._task_sinks:
            return
        log_path = Path(log_dir) / f"task_{task_id}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        sink_id = logger.add(
            str(log_path),
            level=level,
            format="{message}",
            serialize=True,
            rotation=None,
            encoding="utf-8",
            catch=True,
        )
        LoggerService._task_sinks[task_id] = sink_id

    @staticmethod
    def remove_task_sink(task_id: str) -> None:
        """Remove task-specific sink, call when task ends."""
        sink_id = LoggerService._task_sinks.pop(task_id, None)
        if sink_id is not None:
            try:
                logger.remove(sink_id)
            except ValueError:
                pass
