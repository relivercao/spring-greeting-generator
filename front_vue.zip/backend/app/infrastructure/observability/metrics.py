"""
@file metrics.py
@author caoshwen
@brief MetricsCollector - application metrics collection.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
from typing import Optional

from prometheus_client import (
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)


class MetricsCollector:
    """Prometheus-compatible metrics collector"""

    _instance: Optional["MetricsCollector"] = None

    def __init__(self, registry: Optional[CollectorRegistry] = None):
        self.registry = registry or CollectorRegistry()

        # --- HTTP request metrics ---
        self.http_requests_total = Counter(
            "fw_agent_http_requests_total",
            "Total HTTP requests",
            ["method", "endpoint", "status_code"],
            registry=self.registry,
        )

        self.http_request_duration_seconds = Histogram(
            "fw_agent_http_request_duration_seconds",
            "HTTP request latency in seconds",
            ["method", "endpoint"],
            buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
            registry=self.registry,
        )

        # --- LLM / Token metrics ---
        self.llm_tokens_total = Counter(
            "fw_agent_llm_tokens_total",
            "Total LLM tokens consumed",
            ["provider", "model", "token_type"],  # token_type: prompt | completion
            registry=self.registry,
        )

        self.llm_requests_total = Counter(
            "fw_agent_llm_requests_total",
            "Total LLM API calls",
            ["provider", "model", "status"],  # status: success | error
            registry=self.registry,
        )

        self.llm_request_duration_seconds = Histogram(
            "fw_agent_llm_request_duration_seconds",
            "LLM API call latency in seconds",
            ["provider", "model"],
            buckets=(0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0),
            registry=self.registry,
        )

        self.llm_cost_usd_total = Counter(
            "fw_agent_llm_cost_usd_total",
            "Total LLM cost in USD",
            ["provider", "model"],
            registry=self.registry,
        )

        # --- WebSocket / Connection metrics ---
        self.active_ws_connections = Gauge(
            "fw_agent_active_ws_connections",
            "Current active WebSocket connections",
            registry=self.registry,
        )

        self.active_sessions = Gauge(
            "fw_agent_active_sessions",
            "Current active sessions",
            registry=self.registry,
        )

        # --- Agent metrics ---
        self.agent_executions_total = Counter(
            "fw_agent_agent_executions_total",
            "Total agent task executions",
            ["agent_name", "status"],
            registry=self.registry,
        )

    # ---- Convenience methods ----

    def record_http_request(
        self,
        method: str,
        endpoint: str,
        status_code: int,
        duration: float,
    ) -> None:
        """Record a single HTTP request"""
        self.http_requests_total.labels(
            method=method, endpoint=endpoint, status_code=str(status_code)
        ).inc()
        self.http_request_duration_seconds.labels(
            method=method, endpoint=endpoint
        ).observe(duration)

    def record_llm_call(
        self,
        provider: str,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        duration: float,
        cost_usd: float = 0.0,
        success: bool = True,
    ) -> None:
        """Record a single LLM API call"""
        status = "success" if success else "error"
        self.llm_requests_total.labels(
            provider=provider, model=model, status=status
        ).inc()
        self.llm_tokens_total.labels(
            provider=provider, model=model, token_type="prompt"
        ).inc(prompt_tokens)
        self.llm_tokens_total.labels(
            provider=provider, model=model, token_type="completion"
        ).inc(completion_tokens)
        self.llm_request_duration_seconds.labels(
            provider=provider, model=model
        ).observe(duration)
        if cost_usd > 0:
            self.llm_cost_usd_total.labels(
                provider=provider, model=model
            ).inc(cost_usd)

    def ws_connect(self) -> None:
        self.active_ws_connections.inc()

    def ws_disconnect(self) -> None:
        self.active_ws_connections.dec()

    def record_agent_execution(self, agent_name: str, success: bool = True) -> None:
        status = "success" if success else "error"
        self.agent_executions_total.labels(agent_name=agent_name, status=status).inc()

    def export_metrics(self) -> bytes:
        """Export metrics in Prometheus format"""
        return generate_latest(self.registry)

    def get_summary(self) -> dict:
        """Return JSON summary (used by /metrics endpoint for Phase 1)"""
        return {
            "http_requests": self._counter_value(self.http_requests_total),
            "llm_requests": self._counter_value(self.llm_requests_total),
            "llm_tokens": self._counter_value(self.llm_tokens_total),
            "active_ws_connections": self.active_ws_connections._value.get(),
            "active_sessions": self.active_sessions._value.get(),
        }

    @staticmethod
    def _counter_value(counter: Counter) -> float:
        """Extract total value from Counter"""
        total = 0.0
        for metric in counter.collect():
            for sample in metric.samples:
                if sample.name.endswith("_total"):
                    total += sample.value
        return total

    # ---- Singleton ----

    @classmethod
    def get_instance(cls) -> "MetricsCollector":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
