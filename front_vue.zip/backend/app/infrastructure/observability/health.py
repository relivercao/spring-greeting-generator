"""
@file health.py
@author caoshwen
@brief HealthCheckAggregator - component health check aggregation.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Callable, Coroutine, Optional

from app.infrastructure.observability.logger import LoggerService

log = LoggerService.get_logger("health")


class HealthCheckAggregator:
    """
    Unified health check aggregator.

    Usage:
        aggregator = HealthCheckAggregator()
        aggregator.register("database", db_health_check_coroutine)
        aggregator.register("redis", redis_health_check_coroutine)
        result = await aggregator.check_all()
    """

    def __init__(self, timeout: float = 5.0):
        """
        Args:
            timeout: Single component health check timeout in seconds
        """
        self._checks: dict[str, Callable[[], Coroutine[Any, Any, dict[str, Any]]]] = {}
        self._timeout = timeout

    def register(
        self,
        name: str,
        check_fn: Callable[[], Coroutine[Any, Any, dict[str, Any]]],
    ) -> None:
        """
        Register a health check function.

        check_fn should return:
            {"healthy": True/False, ...additional information}
        """
        self._checks[name] = check_fn

    def unregister(self, name: str) -> None:
        """Remove a health check"""
        self._checks.pop(name, None)

    async def check_one(self, name: str) -> dict[str, Any]:
        """Execute health check for a single component"""
        check_fn = self._checks.get(name)
        if not check_fn:
            return {"healthy": False, "error": f"Unknown component: {name}"}

        start = time.monotonic()
        try:
            result = await asyncio.wait_for(check_fn(), timeout=self._timeout)
            result["latency_ms"] = round((time.monotonic() - start) * 1000, 2)
            return result
        except asyncio.TimeoutError:
            log.warning("Health check timeout", component=name, timeout=self._timeout)
            return {
                "healthy": False,
                "error": "timeout",
                "latency_ms": round(self._timeout * 1000, 2),
            }
        except Exception as e:
            log.error("Health check failed", component=name, error=str(e))
            return {
                "healthy": False,
                "error": str(e),
                "latency_ms": round((time.monotonic() - start) * 1000, 2),
            }

    async def check_all(self) -> dict[str, Any]:
        """
        Run all registered health checks concurrently.

        Returns:
            {
                "status": "healthy" | "degraded" | "unhealthy",
                "components": { "redis": {...}, "database": {...}, ... },
                "timestamp": "2026-02-28T10:00:00Z"
            }
        """
        if not self._checks:
            return {
                "status": "healthy",
                "components": {},
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        tasks = {
            name: asyncio.create_task(self.check_one(name))
            for name in self._checks
        }

        components: dict[str, Any] = {}
        for name, task in tasks.items():
            components[name] = await task

        # Determine overall status
        healthy_count = sum(
            1 for c in components.values() if c.get("healthy", False)
        )
        total = len(components)

        if healthy_count == total:
            status = "healthy"
        elif healthy_count > 0:
            status = "degraded"
        else:
            status = "unhealthy"

        return {
            "status": status,
            "components": components,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
