"""
@file memory_client.py
@author caoshwen
@brief InMemoryCacheClient - fallback in-memory cache implementation.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
from datetime import timedelta
from typing import Any, Optional

from app.infrastructure.cache.base import CacheClientBase


class InMemoryCacheClient(CacheClientBase):
    """Pure in-memory cache client, for testing and development environments"""

    def __init__(self):
        self._store: dict[str, Any] = {}
        self._expiry: dict[str, float] = {}
        self._hashes: dict[str, dict[str, str]] = {}
        self._sorted_sets: dict[str, dict[str, float]] = {}

    def _is_expired(self, key: str) -> bool:
        if key in self._expiry and time.time() > self._expiry[key]:
            self._store.pop(key, None)
            self._expiry.pop(key, None)
            return True
        return False

    async def initialize(self) -> None:
        pass

    async def get(self, key: str) -> Optional[str]:
        if self._is_expired(key):
            return None
        return self._store.get(key)

    async def set(self, key: str, value: str, ttl: Optional[timedelta] = None) -> bool:
        self._store[key] = value
        if ttl:
            self._expiry[key] = time.time() + ttl.total_seconds()
        return True

    async def delete(self, key: str) -> bool:
        existed = key in self._store or key in self._hashes or key in self._sorted_sets
        self._store.pop(key, None)
        self._expiry.pop(key, None)
        self._hashes.pop(key, None)
        self._sorted_sets.pop(key, None)
        return existed

    async def exists(self, key: str) -> bool:
        if self._is_expired(key):
            return False
        return key in self._store or key in self._hashes or key in self._sorted_sets

    async def expire(self, key: str, ttl: timedelta) -> bool:
        if key in self._store or key in self._hashes:
            self._expiry[key] = time.time() + ttl.total_seconds()
            return True
        return False

    async def ttl(self, key: str) -> int:
        if key not in self._store and key not in self._hashes and key not in self._sorted_sets:
            return -2
        if key not in self._expiry:
            return -1
        remaining = self._expiry[key] - time.time()
        if remaining <= 0:
            # Key has expired, clean up
            self._store.pop(key, None)
            self._expiry.pop(key, None)
            self._hashes.pop(key, None)
            return -2
        return int(remaining)

    async def hset(self, name: str, mapping: dict[str, str]) -> int:
        if name not in self._hashes:
            self._hashes[name] = {}
        self._hashes[name].update(mapping)
        return len(mapping)

    async def hget(self, name: str, key: str) -> Optional[str]:
        return self._hashes.get(name, {}).get(key)

    async def hgetall(self, name: str) -> dict[str, str]:
        return self._hashes.get(name, {}).copy()

    async def hdel(self, name: str, *keys: str) -> int:
        count = 0
        if name in self._hashes:
            for k in keys:
                if k in self._hashes[name]:
                    del self._hashes[name][k]
                    count += 1
        return count

    async def zadd(self, name: str, mapping: dict[str, float]) -> int:
        if name not in self._sorted_sets:
            self._sorted_sets[name] = {}
        self._sorted_sets[name].update(mapping)
        return len(mapping)

    async def zrange(self, name: str, start: int, end: int, desc: bool = True) -> list[str]:
        ss = self._sorted_sets.get(name, {})
        sorted_members = sorted(
            ss.items(),
            key=lambda item: (item[1], item[0]),
            reverse=desc,
        )
        if not sorted_members:
            return []

        # Redis uses inclusive indexes and resolves negative indexes from the
        # end of the result set. Python's ``items[start:end + 1]`` does not
        # preserve that behavior for the common ``end=-1`` case.
        size = len(sorted_members)
        normalized_start = start if start >= 0 else size + start
        normalized_end = end if end >= 0 else size + end
        normalized_start = max(0, normalized_start)
        if normalized_end < 0 or normalized_start >= size or normalized_start > normalized_end:
            return []
        normalized_end = min(size - 1, normalized_end)
        return [member for member, _score in sorted_members[normalized_start:normalized_end + 1]]

    async def zrem(self, name: str, *members: str) -> int:
        count = 0
        if name in self._sorted_sets:
            for m in members:
                if m in self._sorted_sets[name]:
                    del self._sorted_sets[name][m]
                    count += 1
        return count

    async def zcard(self, name: str) -> int:
        return len(self._sorted_sets.get(name, {}))

    async def incr(self, key: str) -> int:
        val = int(self._store.get(key, 0)) + 1
        self._store[key] = str(val)
        return val

    async def health_check(self) -> dict[str, Any]:
        return {
            "healthy": True,
            "latency_ms": 0.01,
            "backend": "in_memory",
            "keys_count": len(self._store) + len(self._hashes) + len(self._sorted_sets),
        }

    async def close(self) -> None:
        self._store.clear()
        self._expiry.clear()
        self._hashes.clear()
        self._sorted_sets.clear()
