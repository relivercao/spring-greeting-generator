"""
@file session_manager.py
@author caoshwen
@brief SessionManager - conversation history management with auto-compression.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import time
import uuid
from datetime import timedelta
from typing import Any, Optional

from app.infrastructure.cache.base import CacheClientBase


class SessionManager:
    """
    Session manager.

    Responsibilities:
    - Create session (UUID identifier)
    - Resume session (page loading restores history, GPT-like experience)
    - Append message (user/assistant/system)
    - Get context (for LLM calls)
    - Session list (all user sessions)
    - Token counting and automatic context compression
    """

    SESSION_TTL = timedelta(days=7)
    MEMORY_TTL = timedelta(days=30)
    RAG_CACHE_TTL = timedelta(hours=1)
    RATE_LIMIT_TTL = timedelta(minutes=2)

    # Context compression thresholds
    MAX_MESSAGES_BEFORE_COMPRESS = 20
    MAX_CONTEXT_TOKENS = 8000  # Compression triggered when exceeding this token count

    def __init__(self, cache: CacheClientBase):
        self._cache = cache

    # ========== Session CRUD ==========

    async def create_session(
        self,
        user_id: str,
        agent_type: str = "chat",
        title: str = "New Session",
    ) -> str:
        """Create new session, return session_id (UUID)"""
        session_id = str(uuid.uuid4())
        now = time.time()

        # Store session metadata in Redis Hash
        await self._cache.hset(f"session:{session_id}", {
            "user_id": user_id,
            "agent_type": agent_type,
            "title": title,
            "created_at": str(now),
            "updated_at": str(now),
            "message_count": "0",
            "messages": "[]",
            "summary": "",
        })
        await self._cache.expire(f"session:{session_id}", self.SESSION_TTL)

        # Add to user session list (Sorted Set, score = timestamp)
        await self._cache.zadd(f"user_sessions:{user_id}", {session_id: now})

        return session_id

    async def get_session(self, session_id: str) -> Optional[dict[str, Any]]:
        """Get session details"""
        data = await self._cache.hgetall(f"session:{session_id}")
        if not data:
            return None
        return {
            "session_id": session_id,
            "user_id": data.get("user_id", ""),
            "agent_type": data.get("agent_type", "chat"),
            "title": data.get("title", ""),
            "message_count": int(data.get("message_count", "0")),
            "total_tokens": int(data.get("total_tokens", "0")),
            "summary": data.get("summary", ""),
            "created_at": float(data.get("created_at", "0")),
            "updated_at": float(data.get("updated_at", "0")),
        }

    async def delete_session(self, session_id: str, user_id: str) -> bool:
        """Delete session"""
        await self._cache.delete(f"session:{session_id}")
        await self._cache.zrem(f"user_sessions:{user_id}", session_id)
        return True

    async def list_user_sessions(
        self,
        user_id: str,
        limit: int = 20,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List user sessions (sorted by update time descending)"""
        session_ids = await self._cache.zrange(
            f"user_sessions:{user_id}", offset, offset + limit - 1, desc=True
        )
        sessions = []
        for sid in session_ids:
            session = await self.get_session(sid)
            if session:
                sessions.append(session)
        return sessions

    # ========== Message Management ==========

    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        token_count: int = 0,
    ) -> dict[str, Any]:
        """
        Append message to session.

        Returns:
            {"needs_compression": bool, "message_count": int, "total_tokens": int}
        """
        key = f"session:{session_id}"

        # Get existing messages
        messages_json = await self._cache.hget(key, "messages")
        messages = json.loads(messages_json) if messages_json else []

        # Append new message
        messages.append({
            "role": role,
            "content": content,
            "model": model,
            "provider": provider,
            "token_count": token_count,
            "timestamp": time.time(),
        })

        # Calculate total tokens
        total_tokens = sum(m.get("token_count", 0) for m in messages)
        count = len(messages)
        needs_compression = (
            count >= self.MAX_MESSAGES_BEFORE_COMPRESS
            or total_tokens >= self.MAX_CONTEXT_TOKENS
        )

        # Update Redis
        await self._cache.hset(key, {
            "messages": json.dumps(messages, ensure_ascii=False),
            "message_count": str(count),
            "total_tokens": str(total_tokens),
            "updated_at": str(time.time()),
        })
        await self._cache.expire(key, self.SESSION_TTL)

        return {
            "needs_compression": needs_compression,
            "message_count": count,
            "total_tokens": total_tokens,
        }

    async def get_messages(self, session_id: str) -> list[dict[str, Any]]:
        """Get all messages in session"""
        messages_json = await self._cache.hget(f"session:{session_id}", "messages")
        if not messages_json:
            return []
        return json.loads(messages_json)

    async def get_context_messages(
        self,
        session_id: str,
        max_messages: int = 20,
    ) -> list[dict[str, str]]:
        """
        Get context messages for LLM call (OpenAI format).

        Returns the last N messages in format:
        [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]
        """
        messages = await self.get_messages(session_id)
        recent = messages[-max_messages:] if len(messages) > max_messages else messages

        # A generated history summary is conversation evidence, not system policy.
        summary = await self._cache.hget(f"session:{session_id}", "summary")
        context = []
        if summary:
            context.append({"role": "assistant", "content": f"Conversation history summary: {summary}"})

        for msg in recent:
            context.append({"role": msg["role"], "content": msg["content"]})

        return context

    # ========== Agent Memory ==========

    async def save_agent_memory(
        self,
        agent_type: str,
        session_id: str,
        memory: str,
    ) -> None:
        """Save Agent memory (compressed context summary)"""
        key = f"memory:{agent_type}:{session_id}"
        await self._cache.set(key, memory, ttl=self.MEMORY_TTL)

    async def get_agent_memory(
        self,
        agent_type: str,
        session_id: str,
    ) -> Optional[str]:
        """Get Agent memory"""
        return await self._cache.get(f"memory:{agent_type}:{session_id}")

    # ========== Session Summary ==========

    async def update_summary(self, session_id: str, summary: str) -> None:
        """Update session summary (result after context compression)"""
        await self._cache.hset(f"session:{session_id}", {"summary": summary})

    async def update_title(self, session_id: str, title: str) -> None:
        """Update session title"""
        await self._cache.hset(f"session:{session_id}", {
            "title": title,
            "updated_at": str(time.time()),
        })

    # ========== Context Compression ==========

    async def compress_context(
        self,
        session_id: str,
        summary: str,
        keep_recent: int = 6,
    ) -> None:
        """
        Compress session context: keep last N messages, replace old messages with summary.

        Args:
            session_id: Session ID
            summary: LLM-generated summary of old messages
            keep_recent: Number of recent messages to keep
        """
        key = f"session:{session_id}"
        messages_json = await self._cache.hget(key, "messages")
        if not messages_json:
            return

        messages = json.loads(messages_json)
        if len(messages) <= keep_recent:
            return

        # Keep last N messages
        recent = messages[-keep_recent:]
        total_tokens = sum(m.get("token_count", 0) for m in recent)

        await self._cache.hset(key, {
            "messages": json.dumps(recent, ensure_ascii=False),
            "message_count": str(len(recent)),
            "total_tokens": str(total_tokens),
            "summary": summary,
            "updated_at": str(time.time()),
        })

    # ========== Rate Limiting ==========

    async def check_rate_limit(self, provider: str, limit_per_minute: int = 60) -> bool:
        """
        Check LLM Provider rate limit.

        Returns:
            True means call allowed, False means limit exceeded.
        """
        import math
        minute_key = f"rate_limit:{provider}:{math.floor(time.time() / 60)}"
        count = await self._cache.incr(minute_key)
        if count == 1:
            await self._cache.expire(minute_key, self.RATE_LIMIT_TTL)
        return count <= limit_per_minute

    # ========== RAG Cache ==========

    async def get_rag_cache(self, query_hash: str) -> Optional[str]:
        """Get RAG query result cache"""
        return await self._cache.get(f"rag_cache:{query_hash}")

    async def set_rag_cache(self, query_hash: str, result: str) -> None:
        """Cache RAG query result (1 hour TTL)"""
        await self._cache.set(f"rag_cache:{query_hash}", result, ttl=self.RAG_CACHE_TTL)

    # ========== Workflow State ==========

    async def set_agent_state(self, workflow_id: str, state: dict[str, str]) -> None:
        """Save workflow real-time state"""
        key = f"agent_state:{workflow_id}"
        await self._cache.hset(key, state)
        await self._cache.expire(key, timedelta(hours=24))

    async def get_agent_state(self, workflow_id: str) -> dict[str, str]:
        """Get workflow real-time state"""
        return await self._cache.hgetall(f"agent_state:{workflow_id}")
