"""
@file base.py
@author caoshwen
@brief BaseCacheClient abstract class for cache operations.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from abc import ABC, abstractmethod
from datetime import timedelta
from typing import Any, Optional


class CacheClientBase(ABC):
    """Unified cache client abstraction"""

    # ────────── Basic Key-Value Operations ──────────

    @abstractmethod
    async def get(self, key: str) -> Optional[str]:
        """Get string value. Returns None if not found."""
        ...

    @abstractmethod
    async def set(self, key: str, value: str, ttl: Optional[timedelta] = None) -> bool:
        """Set string value with optional TTL expiration."""
        ...

    @abstractmethod
    async def delete(self, key: str) -> bool:
        """Delete Key."""
        ...

    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if Key exists."""
        ...

    @abstractmethod
    async def expire(self, key: str, ttl: timedelta) -> bool:
        """Set Key expiration time."""
        ...

    @abstractmethod
    async def ttl(self, key: str) -> int:
        """Get remaining TTL for Key (seconds). -1 means permanent, -2 means not found."""
        ...

    # ────────── Hash Operations (Session Data) ──────────

    @abstractmethod
    async def hset(self, name: str, mapping: dict[str, str]) -> int:
        """Set multiple fields in Hash."""
        ...

    @abstractmethod
    async def hget(self, name: str, key: str) -> Optional[str]:
        """Get a single field from Hash."""
        ...

    @abstractmethod
    async def hgetall(self, name: str) -> dict[str, str]:
        """Get all fields from Hash."""
        ...

    @abstractmethod
    async def hdel(self, name: str, *keys: str) -> int:
        """Delete Hash fields."""
        ...

    # ────────── Sorted Set Operations (Session List) ──────────

    @abstractmethod
    async def zadd(self, name: str, mapping: dict[str, float]) -> int:
        """Add members to sorted set {member: score}."""
        ...

    @abstractmethod
    async def zrange(self, name: str, start: int, end: int, desc: bool = True) -> list[str]:
        """Get sorted set members by score range."""
        ...

    @abstractmethod
    async def zrem(self, name: str, *members: str) -> int:
        """Remove members from sorted set."""
        ...

    @abstractmethod
    async def zcard(self, name: str) -> int:
        """Get sorted set member count."""
        ...

    # ────────── Atomic Counter (Rate Limiting) ──────────

    @abstractmethod
    async def incr(self, key: str) -> int:
        """Atomic increment."""
        ...

    # ────────── Lifecycle ──────────

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize connection pool."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Close connection pool."""
        ...

    @abstractmethod
    async def health_check(self) -> dict[str, Any]:
        """Health check."""
        ...
