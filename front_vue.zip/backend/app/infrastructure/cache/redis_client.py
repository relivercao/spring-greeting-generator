"""
@file redis_client.py
@author caoshwen
@brief RedisCacheClient - Redis-based cache implementation.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
from datetime import timedelta
from typing import Any, Optional

import redis.asyncio as aioredis

from app.infrastructure.cache.base import CacheClientBase


class RedisCacheClient(CacheClientBase):
    """
    Redis cache client.

    Args:
        url: Redis connection URL
            Phase 1: "redis://localhost:6379/0"
            Phase 2: "redis://fw-dev-agent-redis.xxx.cache.amazonaws.com:6379/0"
        max_connections: Maximum connections in connection pool
    """

    def __init__(self, url: str = "redis://localhost:6379/0", max_connections: int = 20):
        self.url = url
        self._max_connections = max_connections
        self._client: Optional[aioredis.Redis] = None

    async def initialize(self) -> None:
        self._client = aioredis.from_url(
            self.url,
            max_connections=self._max_connections,
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=10,
            retry_on_timeout=True,
        )
        await self._client.ping()

    async def get(self, key: str) -> Optional[str]:
        return await self._client.get(key)

    async def set(self, key: str, value: str, ttl: Optional[timedelta] = None) -> bool:
        if ttl:
            return await self._client.setex(key, ttl, value)
        return await self._client.set(key, value)

    async def delete(self, key: str) -> bool:
        return (await self._client.delete(key)) > 0

    async def exists(self, key: str) -> bool:
        return (await self._client.exists(key)) > 0

    async def expire(self, key: str, ttl: timedelta) -> bool:
        return await self._client.expire(key, ttl)

    async def ttl(self, key: str) -> int:
        return await self._client.ttl(key)

    async def hset(self, name: str, mapping: dict[str, str]) -> int:
        return await self._client.hset(name, mapping=mapping)

    async def hget(self, name: str, key: str) -> Optional[str]:
        return await self._client.hget(name, key)

    async def hgetall(self, name: str) -> dict[str, str]:
        return await self._client.hgetall(name)

    async def hdel(self, name: str, *keys: str) -> int:
        return await self._client.hdel(name, *keys)

    async def zadd(self, name: str, mapping: dict[str, float]) -> int:
        return await self._client.zadd(name, mapping)

    async def zrange(self, name: str, start: int, end: int, desc: bool = True) -> list[str]:
        if desc:
            return await self._client.zrevrange(name, start, end)
        return await self._client.zrange(name, start, end)

    async def zrem(self, name: str, *members: str) -> int:
        return await self._client.zrem(name, *members)

    async def zcard(self, name: str) -> int:
        return await self._client.zcard(name)

    async def incr(self, key: str) -> int:
        return await self._client.incr(key)

    async def health_check(self) -> dict[str, Any]:
        start = time.monotonic()
        pong = await self._client.ping()
        latency = (time.monotonic() - start) * 1000
        info = await self._client.info("memory")
        return {
            "healthy": pong,
            "latency_ms": round(latency, 2),
            "used_memory_human": info.get("used_memory_human", "N/A"),
            "connected_clients": info.get("connected_clients", 0),
        }

    async def close(self) -> None:
        if self._client:
            await self._client.close()
