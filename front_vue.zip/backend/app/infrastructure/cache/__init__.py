"""
@file __init__.py
@author caoshwen
@brief Cache module initialization and exports.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from app.infrastructure.cache.base import CacheClientBase
from app.infrastructure.cache.redis_client import RedisCacheClient
from app.infrastructure.cache.memory_client import InMemoryCacheClient
from app.infrastructure.cache.session_manager import SessionManager


def get_cache_client() -> CacheClientBase:
    """
    Get the global cache client instance from FastAPI app state.

    This function retrieves the cache client that was initialized during
    application startup. It provides access to Redis or InMemory cache.

    Returns:
        CacheClientBase: The initialized cache client instance

    Raises:
        RuntimeError: If cache client is not initialized
    """
    from starlette.requests import Request
    from contextvars import ContextVar

    # Try to get from request context first (if available)
    try:
        from fastapi import Request as FastAPIRequest
        # This will work inside request handlers
        import inspect
        for frame_info in inspect.stack():
            frame_locals = frame_info.frame.f_locals
            if 'request' in frame_locals:
                request = frame_locals['request']
                if hasattr(request, 'app') and hasattr(request.app.state, 'cache_client'):
                    return request.app.state.cache_client
    except Exception:
        pass

    # Fallback: get from global app instance
    try:
        from app.main import app
        if hasattr(app.state, 'cache_client'):
            return app.state.cache_client
    except Exception:
        pass

    raise RuntimeError(
        "Cache client not initialized. Ensure the application has started properly."
    )


__all__ = [
    "CacheClientBase",
    "RedisCacheClient",
    "InMemoryCacheClient",
    "SessionManager",
    "get_cache_client",
]
