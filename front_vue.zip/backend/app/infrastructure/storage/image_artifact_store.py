"""Filesystem storage for generated image artifacts."""

from __future__ import annotations

import asyncio
import io
import re
import shutil
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path

from PIL import Image


_SAFE_TASK_ID = re.compile(r"^[A-Za-z0-9-]{1,64}$")
_SAFE_FILENAME = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")
_FORMAT_METADATA = {
    "PNG": ("png", "image/png"),
    "JPEG": ("jpg", "image/jpeg"),
    "WEBP": ("webp", "image/webp"),
}


@dataclass(frozen=True)
class StoredImageArtifact:
    """Metadata for one stored image file."""

    filename: str
    media_type: str
    size_bytes: int
    width: int
    height: int


class ImageArtifactStore:
    """Persist and resolve generated images within a configured root."""

    def __init__(self, output_root: str):
        self.root = Path(output_root).resolve() / "image_generation"

    async def save(
        self,
        task_id: str,
        index: int,
        data: bytes,
    ) -> StoredImageArtifact:
        """Validate and atomically persist one generated image."""
        self._validate_task_id(task_id)
        save_task = asyncio.create_task(
            asyncio.to_thread(self._save_sync, task_id, index, data)
        )
        try:
            return await asyncio.shield(save_task)
        except asyncio.CancelledError:
            # A cancelled to_thread await does not stop the worker thread. Wait for
            # the atomic write to finish before the caller removes task artifacts.
            with suppress(asyncio.CancelledError):
                await save_task
            raise

    async def exists(self, task_id: str, filename: str) -> bool:
        """Return whether a task artifact exists."""
        path = self.resolve(task_id, filename)
        return await asyncio.to_thread(path.is_file)

    async def delete_task(self, task_id: str) -> None:
        """Delete every generated artifact belonging to a task."""
        self._validate_task_id(task_id)
        task_dir = (self.root / task_id).resolve()
        if task_dir.parent != self.root:
            raise ValueError("Invalid task artifact path")
        await asyncio.to_thread(shutil.rmtree, task_dir, True)

    def resolve(self, task_id: str, filename: str) -> Path:
        """Resolve an artifact path while enforcing root containment."""
        self._validate_task_id(task_id)
        if not _SAFE_FILENAME.fullmatch(filename):
            raise ValueError("Invalid image filename")
        task_dir = (self.root / task_id).resolve()
        path = (task_dir / filename).resolve()
        if path.parent != task_dir:
            raise ValueError("Invalid image artifact path")
        return path

    def _save_sync(
        self,
        task_id: str,
        index: int,
        data: bytes,
    ) -> StoredImageArtifact:
        try:
            with Image.open(io.BytesIO(data)) as image:
                image_format = image.format or ""
                width, height = image.size
                image.verify()
        except Exception as exc:
            raise ValueError("The provider returned an invalid image file") from exc

        metadata = _FORMAT_METADATA.get(image_format.upper())
        if not metadata:
            raise ValueError(f"Unsupported generated image format: {image_format or 'unknown'}")
        extension, media_type = metadata
        filename = f"image-{index + 1}.{extension}"
        task_dir = (self.root / task_id).resolve()
        if task_dir.parent != self.root:
            raise ValueError("Invalid task artifact path")
        task_dir.mkdir(parents=True, exist_ok=True)

        destination = task_dir / filename
        temporary = task_dir / f".{filename}.tmp"
        temporary.write_bytes(data)
        temporary.replace(destination)
        return StoredImageArtifact(
            filename=filename,
            media_type=media_type,
            size_bytes=len(data),
            width=width,
            height=height,
        )

    @staticmethod
    def _validate_task_id(task_id: str) -> None:
        if not _SAFE_TASK_ID.fullmatch(task_id):
            raise ValueError("Invalid image task ID")
