"""Persistent task-to-Claude-session mapping for resumable agent workflows."""

from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from loguru import logger

from app.core.config import get_resolved_claude_config_dir


_SESSION_NAMESPACE = uuid.UUID("f9578bf4-07d7-4b2d-9448-5da8bda40be8")
_REGISTRY_LOCK = threading.RLock()


class ClaudeSessionRegistry:
    """Record stable Claude CLI session IDs for application task IDs."""

    def __init__(self, config_dir: Optional[str] = None) -> None:
        self._config_dir = Path(config_dir or get_resolved_claude_config_dir())
        self._registry_path = self._config_dir / "task_sessions.json"
        self._lock = _REGISTRY_LOCK

    def resolve(
        self,
        task_id: str,
        requested_session_id: Optional[str] = None,
        working_dir: Optional[str] = None,
        session_scope: Optional[str] = None,
    ) -> str:
        """Return a stable session ID bound to the task's working directory.

        Claude sessions retain their original cwd. Reusing a session after the
        caller changed from a temporary worktree to the real project root can
        make every Read/Edit target resolve against the stale worktree. Bind
        the mapping to the canonical root and fork a deterministic new session
        when the root changes.
        """
        normalized_task_id = str(task_id).strip()
        if not normalized_task_id:
            raise ValueError("Task ID cannot be empty when resolving a Claude session")
        registry_key = self._registry_key(normalized_task_id, session_scope)

        with self._lock:
            payload = self._read()
            tasks = payload.setdefault("tasks", {})
            existing = tasks.get(registry_key, {})
            normalized_dir = self._normalize_working_dir(working_dir)
            existing_dir = self._normalize_working_dir(existing.get("working_dir"))
            session_id = self._validated_uuid(requested_session_id)
            workspace_changed = bool(
                normalized_dir and existing
                and normalized_dir != existing_dir
            )
            if workspace_changed:
                # Never fall back to the stale mapping after rejecting its cwd.
                session_id = None
            elif session_id is None:
                session_id = self._validated_uuid(existing.get("session_id"))
            if session_id is None:
                seed = f"macode-agent-task:{registry_key}"
                if normalized_dir:
                    seed += f":{normalized_dir.casefold()}"
                session_id = str(uuid.uuid5(_SESSION_NAMESPACE, seed))

            now = datetime.now(timezone.utc).isoformat()
            tasks[registry_key] = {
                "task_id": normalized_task_id,
                "session_scope": session_scope,
                "session_id": session_id,
                "created_at": existing.get("created_at") or now,
                "updated_at": now,
                "working_dir": normalized_dir,
            }
            self._write(payload)
            return session_id

    def has_session(self, session_id: str) -> bool:
        """Return whether Claude CLI has persisted the requested session."""
        projects_dir = self._config_dir / "projects"
        if not projects_dir.exists():
            return False
        return any(projects_dir.rglob(f"{session_id}.jsonl"))

    def get(self, task_id: str, session_scope: Optional[str] = None) -> Optional[dict[str, Any]]:
        """Return the persisted mapping for a task, if present."""
        with self._lock:
            record = self._read().get("tasks", {}).get(self._registry_key(task_id, session_scope))
            return dict(record) if isinstance(record, dict) else None

    @staticmethod
    def _registry_key(task_id: str, session_scope: Optional[str]) -> str:
        task_id = str(task_id).strip()
        return json.dumps([task_id, session_scope]) if session_scope else task_id

    def _read(self) -> dict[str, Any]:
        if not self._registry_path.exists():
            return {"version": 1, "tasks": {}}
        try:
            payload = json.loads(self._registry_path.read_text(encoding="utf-8"))
            if isinstance(payload, dict) and isinstance(payload.get("tasks"), dict):
                return payload
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning(f"Failed to read Claude task session registry: {exc}")
        return {"version": 1, "tasks": {}}

    def _write(self, payload: dict[str, Any]) -> None:
        self._config_dir.mkdir(parents=True, exist_ok=True)
        temporary_path = self._registry_path.with_suffix(".json.tmp")
        temporary_path.write_text(
            json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        temporary_path.replace(self._registry_path)

    @staticmethod
    def _validated_uuid(value: Any) -> Optional[str]:
        if not value:
            return None
        try:
            return str(uuid.UUID(str(value)))
        except (ValueError, TypeError, AttributeError):
            return None

    @staticmethod
    def _normalize_working_dir(value: Any) -> Optional[str]:
        if not value:
            return None
        try:
            return str(Path(str(value)).expanduser().resolve())
        except (OSError, RuntimeError, TypeError, ValueError):
            return str(value).strip() or None
