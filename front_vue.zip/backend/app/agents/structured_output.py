"""Helpers for parsing structured LLM responses."""

from __future__ import annotations

import json
import re
from typing import Any


class StructuredOutputError(ValueError):
    """Raised when an LLM response does not match the required structure."""


def parse_json_object(content: str) -> dict[str, Any]:
    """Parse the first complete JSON object from plain or fenced text."""
    candidate = content.strip()
    fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", candidate, re.DOTALL | re.IGNORECASE)
    if fenced:
        candidate = fenced.group(1).strip()

    try:
        parsed = json.loads(candidate)
    except json.JSONDecodeError:
        candidate = _extract_balanced_object(candidate)
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError as exc:
            raise StructuredOutputError(f"The model returned invalid JSON: {exc.msg}") from exc

    if not isinstance(parsed, dict):
        raise StructuredOutputError("The model response must be a JSON object")
    return parsed


def parse_tagged_sections(content: str, required_sections: set[str]) -> dict[str, str]:
    """Parse named sections delimited by exact triple-angle markers."""
    pattern = re.compile(
        r"^<<<([A-Z_]+)>>>\s*\n(.*?)(?=^<<<[A-Z_]+>>>\s*$|\Z)",
        re.MULTILINE | re.DOTALL,
    )
    sections = {
        match.group(1): match.group(2).strip()
        for match in pattern.finditer(content.strip())
    }
    missing = sorted(section for section in required_sections if not sections.get(section))
    if missing:
        raise StructuredOutputError(
            f"The model response is missing required sections: {', '.join(missing)}"
        )
    return sections


def _extract_balanced_object(content: str) -> str:
    start = content.find("{")
    if start < 0:
        raise StructuredOutputError("The model response does not contain a JSON object")

    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(content)):
        char = content[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return content[start:index + 1]
    raise StructuredOutputError("The model response contains an incomplete JSON object")
