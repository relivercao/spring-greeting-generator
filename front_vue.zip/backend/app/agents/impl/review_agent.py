"""Compatibility shim - the ReviewAgent implementation moved to `app.agents.impl.review`.

The monolithic review agent was split into a staged package (collection,
batching, findings, report, validation, agent). This module re-exports the
previous public symbols so existing imports keep working.
"""

from app.agents.impl.review import (
    ReviewAgent,
    ReviewContext,
    ReviewFinding,
    ReviewResult,
)

__all__ = [
    "ReviewAgent",
    "ReviewContext",
    "ReviewFinding",
    "ReviewResult",
]
