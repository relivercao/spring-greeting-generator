"""LangGraph workflow for planning and generating images."""

from __future__ import annotations

from typing import Any, TypedDict

from loguru import logger

from app.agents.base import AgentStatus, CancelledException
from .prompts import append_knowledge_context, preserve_user_requirements
from .types import ImageGenerationContext


class ImageGenerationState(TypedDict, total=False):
    """State shared by the image-generation graph nodes."""

    context: ImageGenerationContext
    action: str
    original_prompt: str
    effective_prompt: str
    skill_prompt: str
    enhancement_attempted: bool
    enhancement_error: str
    visual_plan: dict[str, Any]
    provider_result: Any
    stored_images: list[dict[str, Any]]
    node_outputs: dict[str, dict[str, str]]
    skipped_nodes: list[str]
    warning_nodes: list[str]
    workflow_nodes: list[dict[str, str]]


_NODES = (
    ("understand_request", "Understand request", "prepare", 10),
    ("plan_visuals", "Plan visuals", "plan", 22),
    ("compose_prompt", "Compose prompt", "compose_prompt", 35),
    ("generate_image", "Generate image", "provider", 60),
    ("save_outputs", "Save outputs", "store", 86),
)


def build_workflow_nodes(
    state: ImageGenerationState,
    active_node: str | None = None,
    terminal_status: str | None = None,
) -> list[dict[str, str]]:
    """Return a serializable graph snapshot, including click-through details."""
    active_index = next(
        (index for index, (node_id, _, _, _) in enumerate(_NODES) if node_id == active_node),
        None,
    )
    skipped = set(state.get("skipped_nodes", []))
    warnings = set(state.get("warning_nodes", []))
    outputs = state.get("node_outputs", {})
    workflow_nodes = []

    for index, (node_id, label, _, _) in enumerate(_NODES):
        if node_id in skipped:
            status = "skipped"
        elif node_id in warnings:
            status = "warning"
        elif terminal_status == AgentStatus.COMPLETED.value:
            status = "completed"
        elif terminal_status == AgentStatus.FAILED.value and active_index == index:
            status = "failed"
        elif terminal_status == AgentStatus.CANCELLED.value and active_index == index:
            status = "cancelled"
        elif active_index is not None and index < active_index:
            status = "completed"
        elif active_index == index:
            status = "in_progress"
        elif terminal_status:
            status = "skipped"
        else:
            status = "pending"

        details = outputs.get(node_id, {})
        workflow_nodes.append({
            "id": node_id,
            "label": label,
            "status": status,
            "input": str(details.get("input", "")),
            "output": str(details.get("output", "")),
        })
    return workflow_nodes


class ImageGenerationWorkflow:
    """Run visual planning and provider generation as an observable LangGraph."""

    def __init__(self, agent):
        self._agent = agent

    def build(self):
        """Compile LangGraph, returning None when the optional runtime is absent."""
        try:
            from langgraph.graph import END, START, StateGraph
        except ImportError:
            logger.warning("langgraph not installed; using ordered image-generation fallback")
            return None

        graph = StateGraph(ImageGenerationState)
        graph.add_node("understand_request", self._understand_request)
        graph.add_node("plan_visuals", self._plan_visuals)
        graph.add_node("compose_prompt", self._compose_prompt)
        graph.add_node("generate_image", self._generate_image)
        graph.add_node("save_outputs", self._save_outputs)
        graph.add_edge(START, "understand_request")
        graph.add_edge("understand_request", "plan_visuals")
        graph.add_edge("plan_visuals", "compose_prompt")
        graph.add_edge("compose_prompt", "generate_image")
        graph.add_edge("generate_image", "save_outputs")
        graph.add_edge("save_outputs", END)
        return graph.compile()

    async def execute(self, context: ImageGenerationContext) -> ImageGenerationState:
        """Execute the graph, with the same node functions as a linear fallback."""
        original_prompt = context.prompt.strip()
        state: ImageGenerationState = {
            "context": context,
            "action": "edit" if context.reference_images else "generate",
            "original_prompt": original_prompt,
            "effective_prompt": original_prompt,
            "enhancement_attempted": context.enhance_prompt and self._agent._llm is not None,
            "enhancement_error": "",
            "visual_plan": {
                "subject": "",
                "composition": "",
                "camera": "",
                "lighting": "",
                "style": "",
                "constraints": [],
                "negative_prompt": "",
                "final_prompt": original_prompt,
                "format": "original",
            },
            "node_outputs": {},
            "skipped_nodes": [],
            "warning_nodes": [],
        }

        graph = self.build()
        if graph is not None:
            result = await graph.ainvoke(state)
            if result is None:
                raise RuntimeError("Image-generation workflow returned no final state")
            return result

        for node in (
            self._understand_request,
            self._plan_visuals,
            self._compose_prompt,
            self._generate_image,
            self._save_outputs,
        ):
            state.update(await node(state))
        return state

    async def _report(
        self,
        state: ImageGenerationState,
        node_id: str,
        progress: int,
        message: str,
    ) -> None:
        context = state["context"]
        node = next(item for item in _NODES if item[0] == node_id)
        await self._agent._report_progress(
            context.task_id,
            progress,
            node[2],
            message,
            {"workflow_nodes": build_workflow_nodes(state, active_node=node_id)},
        )

    async def _understand_request(self, state: ImageGenerationState) -> dict[str, Any]:
        context = state["context"]
        action = state["action"]
        await self._report(
            state,
            "understand_request",
            10,
            "Understanding image request and selected references",
        )
        skill_plan = await self._agent._prepare_agent_skills(
            context,
            "prepare",
            scope="image_generation",
            inputs={
                "reference_count": len(context.reference_images),
                "knowledge_count": len(context.knowledge_documents),
            },
        )
        output = {
            "node_outputs": {
                **state.get("node_outputs", {}),
                "understand_request": {
                    "input": state["original_prompt"],
                    "output": (
                        f"Prepared a {action} request with {len(context.reference_images)} reference image(s), "
                        f"{len(context.knowledge_documents)} knowledge source(s), and "
                        f"{state['enhancement_attempted'] and 'AI planning enabled' or 'AI planning disabled'}."
                    ),
                },
            },
            "skill_prompt": skill_plan.prompt,
        }
        self._agent._is_cancelled(context.task_id)
        return output

    async def _plan_visuals(self, state: ImageGenerationState) -> dict[str, Any]:
        context = state["context"]
        if not state["enhancement_attempted"]:
            return {
                "skipped_nodes": [*state.get("skipped_nodes", []), "plan_visuals"],
                "node_outputs": {
                    **state.get("node_outputs", {}),
                    "plan_visuals": {
                        "input": state["original_prompt"],
                        "output": "AI visual planning is disabled or no Agent LLM is configured.",
                    },
                },
            }

        await self._report(
            state,
            "plan_visuals",
            22,
            "Planning subject, composition, camera, lighting, and constraints with the Agent LLM",
        )
        try:
            prompt, visual_plan = await self._agent._enhance_prompt(
                state["original_prompt"],
                context,
                state["action"],
                state.get("skill_prompt", ""),
            )
            self._agent._is_cancelled(context.task_id)
            return {
                "effective_prompt": prompt,
                "visual_plan": visual_plan,
                "node_outputs": {
                    **state.get("node_outputs", {}),
                    "plan_visuals": {
                        "input": state["original_prompt"],
                        "output": _visual_plan_summary(visual_plan),
                    },
                },
            }
        except CancelledException:
            raise
        except Exception as error:
            error_message = str(error).strip() or error.__class__.__name__
            logger.warning(
                "Image prompt planning failed for task {}: {}",
                context.task_id,
                error_message,
            )
            return {
                "effective_prompt": state["original_prompt"],
                "enhancement_error": error_message,
                "warning_nodes": [*state.get("warning_nodes", []), "plan_visuals"],
                "visual_plan": {**state["visual_plan"], "format": "planner_fallback"},
                "node_outputs": {
                    **state.get("node_outputs", {}),
                    "plan_visuals": {
                        "input": state["original_prompt"],
                        "output": f"Planning failed; the original request will be used. {error_message}",
                    },
                },
            }

    async def _compose_prompt(self, state: ImageGenerationState) -> dict[str, Any]:
        context = state["context"]
        await self._report(
            state,
            "compose_prompt",
            36,
            "Checking the final prompt against the original request",
        )
        effective_prompt = preserve_user_requirements(
            state["effective_prompt"],
            state["original_prompt"],
        )
        negative_prompt = str(state["visual_plan"].get("negative_prompt") or "").strip()
        if negative_prompt and negative_prompt.casefold() not in effective_prompt.casefold():
            effective_prompt = f"{effective_prompt}\n\nAvoid: {negative_prompt}"
        if context.knowledge_context and effective_prompt == state["original_prompt"]:
            effective_prompt = append_knowledge_context(
                effective_prompt,
                context.knowledge_context,
            )
        visual_plan = {
            **state["visual_plan"],
            "final_prompt": effective_prompt,
        }
        return {
            "effective_prompt": effective_prompt,
            "visual_plan": visual_plan,
            "node_outputs": {
                **state.get("node_outputs", {}),
                "compose_prompt": {
                    "input": _visual_plan_summary(state["visual_plan"]),
                    "output": effective_prompt,
                },
            },
        }

    async def _generate_image(self, state: ImageGenerationState) -> dict[str, Any]:
        context = state["context"]
        await self._report(
            state,
            "generate_image",
            58,
            "Generating the final image with the configured image provider",
        )
        self._agent._is_cancelled(context.task_id)
        result = await self._agent._provider.generate(
            prompt=state["effective_prompt"],
            options=context.options,
            reference_images=context.reference_images,
            mask=context.mask,
            request_id=context.task_id,
        )
        self._agent._is_cancelled(context.task_id)
        images = getattr(result, "images", None) or []
        if not images:
            raise ValueError("The image provider returned no images")
        return {
            "provider_result": result,
            "node_outputs": {
                **state.get("node_outputs", {}),
                "generate_image": {
                    "input": state["effective_prompt"],
                    "output": f"The provider returned {len(images)} image(s) using {self._agent._provider.config.model}.",
                },
            },
        }

    async def _save_outputs(self, state: ImageGenerationState) -> dict[str, Any]:
        context = state["context"]
        await self._report(
            state,
            "save_outputs",
            86,
            "Saving generated image files and final workflow outputs",
        )
        images = state["provider_result"].images
        stored_images = await self._agent._store_images(context.task_id, images)
        output_names = ", ".join(image["filename"] for image in stored_images)
        node_outputs = {
            **state.get("node_outputs", {}),
            "save_outputs": {
                "input": f"{len(images)} generated image(s)",
                "output": f"Saved {len(stored_images)} image(s): {output_names}",
            },
        }
        final_state = {**state, "node_outputs": node_outputs}
        return {
            "stored_images": stored_images,
            "node_outputs": node_outputs,
            "workflow_nodes": build_workflow_nodes(
                final_state,
                terminal_status=AgentStatus.COMPLETED.value,
            ),
        }


def _visual_plan_summary(plan: dict[str, Any]) -> str:
    """Format the compact, user-readable parts of a visual plan."""
    fields = (
        ("Subject", plan.get("subject")),
        ("Composition", plan.get("composition")),
        ("Camera", plan.get("camera")),
        ("Lighting", plan.get("lighting")),
        ("Style", plan.get("style")),
    )
    lines = [f"{label}: {value}" for label, value in fields if value]
    constraints = plan.get("constraints") or []
    if constraints:
        lines.append("Constraints: " + "; ".join(str(item) for item in constraints))
    if plan.get("negative_prompt"):
        lines.append(f"Avoid: {plan['negative_prompt']}")
    if not lines:
        return str(plan.get("final_prompt") or "The original prompt will be used.")
    return "\n".join(lines)
