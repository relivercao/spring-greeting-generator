"""ImageGenerationAgent - generate or edit images through the configured provider."""

from __future__ import annotations

import asyncio
from typing import Optional

from loguru import logger

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.infrastructure.storage import ImageArtifactStore
from app.llm.bridge import LLMBridge
from app.llm.image_provider import (
    OpenAICompatibleImageProvider,
)
from .prompts import build_enhancer_messages, parse_visual_plan
from .types import ImageGenerationContext
from .validation import validate_generation_input
from .workflow import ImageGenerationWorkflow


class ImageGenerationAgent(BaseAgent):
    """Generate or edit images through the configured image provider.

    Workflow: validate inputs -> build a visual plan -> preserve the original
    requirements -> generate and persist image artifacts.
    """

    def __init__(
        self,
        provider: OpenAICompatibleImageProvider,
        artifact_store: ImageArtifactStore,
        llm_bridge: Optional[LLMBridge] = None,
        max_reference_images: int = 16,
        max_total_input_bytes: int = 256 * 1024 * 1024,
        skill_registry=None,
    ):
        super().__init__(AgentConfig(
            agent_type=AgentType.IMAGE_GENERATION,
            timeout_seconds=900,
            enable_streaming=True,
            durable_runtime=True,
        ), skill_registry=skill_registry)
        self._provider = provider
        self._artifact_store = artifact_store
        self._llm = llm_bridge
        self._max_reference_images = max_reference_images
        self._max_total_input_bytes = max_total_input_bytes

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, ImageGenerationContext):
            raise ValidationError("ImageGenerationAgent requires ImageGenerationContext")
        validate_generation_input(
            context, self._max_reference_images, self._max_total_input_bytes
        )

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        if not isinstance(ctx, ImageGenerationContext):
            raise ValidationError("ImageGenerationAgent requires ImageGenerationContext")

        state = await ImageGenerationWorkflow(self).execute(ctx)
        provider_result = state["provider_result"]
        stored_images = state["stored_images"]
        original_prompt = state["original_prompt"]
        effective_prompt = state["effective_prompt"]
        enhancement_attempted = state["enhancement_attempted"]

        return AgentResult(
            task_id=ctx.task_id,
            status=AgentStatus.COMPLETED,
            message=f"Generated {len(stored_images)} image(s)",
            data={
                "action": state["action"],
                "prompt": effective_prompt,
                "original_prompt": original_prompt,
                "effective_prompt": effective_prompt,
                "prompt_enhanced": effective_prompt != original_prompt,
                "prompt_enhancement_requested": ctx.enhance_prompt,
                "prompt_enhancement_attempted": enhancement_attempted,
                "prompt_enhancement_provider": (
                    self._llm_selection.provider if enhancement_attempted else ""
                ),
                "prompt_enhancement_model": (
                    self._llm_selection.model if enhancement_attempted else ""
                ),
                "agent_llm_provider": self._llm_selection.provider,
                "agent_llm_model": self._llm_selection.model,
                "prompt_enhancement_error": state["enhancement_error"],
                "knowledge_document_ids": [
                    str(item.get("id")) for item in ctx.knowledge_documents if item.get("id")
                ],
                "knowledge_sources": ctx.knowledge_documents,
                "knowledge_context_used": bool(ctx.knowledge_context),
                "model": self._provider.config.model,
                "api_mode": self._provider.config.mode,
                "images": stored_images,
                "actual_params": provider_result.actual_params,
                "failed_requests": provider_result.failed_requests,
                "visual_plan": state["visual_plan"],
                "workflow_nodes": state["workflow_nodes"],
            },
        )

    async def _store_images(self, task_id: str, images) -> list[dict]:
        """Persist provider images, rolling back the whole task on failure."""
        stored_images = []
        try:
            for index, image in enumerate(images):
                self._is_cancelled(task_id)
                if not image.data:
                    raise ValueError("The image provider returned an empty image")
                artifact = await self._artifact_store.save(task_id, index, image.data)
                stored_images.append({
                    "filename": artifact.filename,
                    "media_type": artifact.media_type,
                    "size_bytes": artifact.size_bytes,
                    "width": artifact.width,
                    "height": artifact.height,
                    "revised_prompt": image.revised_prompt,
                    "source_url": image.source_url,
                })
            self._is_cancelled(task_id)
        except (Exception, asyncio.CancelledError):
            try:
                await self._artifact_store.delete_task(task_id)
            except Exception as cleanup_error:
                logger.warning(
                    "Failed to roll back image artifacts for task {}: {}",
                    task_id,
                    cleanup_error,
                )
            raise
        return stored_images

    async def _enhance_prompt(
        self,
        prompt: str,
        context: ImageGenerationContext,
        action: str,
        skill_prompt: str = "",
    ) -> tuple[str, dict]:
        """Plan the image and return a provider-ready prompt plus its trace."""
        if self._llm is None:
            return prompt, {"final_prompt": prompt, "format": "no_llm"}
        response = await self._llm.generate(
            build_enhancer_messages(prompt, context, action, skill_prompt),
            temperature=0.3,
            max_tokens=1200,
            **self._llm_call_options(),
        )
        return parse_visual_plan(response.content)
