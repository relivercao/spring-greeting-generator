"""Prompt enhancement helpers for the image generation agent."""

from __future__ import annotations

import json
import re
from typing import Any

from .types import ImageGenerationContext

ENHANCER_SYSTEM_PROMPT = (
    "You are the visual planning stage of an image generation workflow. "
    "Convert the user's request into a precise production-ready visual plan "
    "and a final image prompt. Preserve every requested object, text, quantity, "
    "relationship, dimension, constraint, and edit intent. Add useful composition, "
    "lighting, camera, material, and style detail only when compatible. Do not "
    "invent logos, labels, facts, or requirements. If grounding context is "
    "supplied, use only supported entities and relationships from those sources. "
    "Return JSON only with these keys: subject, composition, camera, lighting, "
    "style, constraints (array of strings), negative_prompt, final_prompt. "
    "The final_prompt must be directly usable by the image provider and must "
    "include the important constraints from the plan."
)

KNOWLEDGE_CONTEXT_LIMIT = 6000


def _bounded_knowledge_context(context: str) -> str:
    bounded = context[:KNOWLEDGE_CONTEXT_LIMIT]
    if len(context) > KNOWLEDGE_CONTEXT_LIMIT:
        bounded += "\n[Additional knowledge context omitted for image prompt size]"
    return bounded


def build_enhancer_messages(
    prompt: str,
    context: ImageGenerationContext,
    action: str,
    skill_prompt: str = "",
) -> list[dict[str, str]]:
    """Build the two-message prompt for the enhancement LLM call."""
    return [
        {"role": "system", "content": ENHANCER_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Action: {action}\n"
                f"Output size: {context.options.size}\n"
                f"Transparent output: {context.options.transparent_output}\n"
                f"Reference image count: {len(context.reference_images)}\n"
                f"Mask provided: {context.mask is not None}\n\n"
                f"Original prompt:\n{prompt}\n\n"
                f"Skill guidance:\n{skill_prompt}"
                + (
                    f"\n\nCanonical knowledge context:\n{_bounded_knowledge_context(context.knowledge_context)}"
                    if context.knowledge_context else ""
                )
            ),
        },
    ]


def parse_visual_plan(content: str) -> tuple[str, dict[str, Any]]:
    """Parse the planner response while retaining a safe plain-text fallback."""
    cleaned = (content or "").strip()
    fenced = re.fullmatch(r"```(?:json|text)?\s*(.*?)\s*```", cleaned, re.DOTALL | re.IGNORECASE)
    if fenced:
        cleaned = fenced.group(1).strip()

    try:
        parsed = json.loads(cleaned)
    except (TypeError, json.JSONDecodeError):
        final_prompt = clean_enhanced_prompt(cleaned)
        return final_prompt, {
            "subject": "",
            "composition": "",
            "camera": "",
            "lighting": "",
            "style": "",
            "constraints": [],
            "negative_prompt": "",
            "final_prompt": final_prompt,
            "format": "plain_text_fallback",
        }

    if not isinstance(parsed, dict):
        raise ValueError("The Agent LLM visual plan must be a JSON object")

    def text_value(key: str) -> str:
        value = parsed.get(key, "")
        return str(value).strip() if value is not None else ""

    constraints = parsed.get("constraints") or []
    if isinstance(constraints, str):
        constraints = [constraints]
    constraints = [str(item).strip() for item in constraints if str(item).strip()]
    final_prompt = clean_enhanced_prompt(text_value("final_prompt"))
    if not final_prompt:
        raise ValueError("The Agent LLM visual plan did not include final_prompt")

    plan = {
        "subject": text_value("subject"),
        "composition": text_value("composition"),
        "camera": text_value("camera"),
        "lighting": text_value("lighting"),
        "style": text_value("style"),
        "constraints": constraints,
        "negative_prompt": text_value("negative_prompt"),
        "final_prompt": final_prompt,
        "format": "visual_plan",
    }
    return final_prompt, plan


def clean_enhanced_prompt(content: str) -> str:
    """Remove common response wrappers from an enhanced image prompt."""
    cleaned = (content or "").strip()
    fenced = re.fullmatch(r"```(?:text)?\s*(.*?)\s*```", cleaned, re.DOTALL | re.IGNORECASE)
    if fenced:
        cleaned = fenced.group(1).strip()
    cleaned = re.sub(r"^(?:enhanced\s+)?prompt\s*:\s*", "", cleaned, flags=re.IGNORECASE)
    if len(cleaned) >= 2 and cleaned[0] == cleaned[-1] and cleaned[0] in {'"', "'"}:
        cleaned = cleaned[1:-1].strip()
    return cleaned


def append_knowledge_context(prompt: str, knowledge_context: str) -> str:
    """Keep selected sources useful when prompt enhancement is unavailable."""
    bounded_context = _bounded_knowledge_context(knowledge_context)
    return (
        f"{prompt}\n\n"
        "Use the following canonical knowledge context for factual labels and relationships. "
        "Do not invent unsupported details:\n"
        f"{bounded_context}"
    )


def preserve_user_requirements(final_prompt: str, original_prompt: str) -> str:
    """Retain the exact user request when the planner omits it from its rewrite."""
    cleaned_final = clean_enhanced_prompt(final_prompt)
    original = (original_prompt or "").strip()
    if not original:
        return cleaned_final
    normalized_final = " ".join(cleaned_final.casefold().split())
    normalized_original = " ".join(original.casefold().split())
    if normalized_original in normalized_final:
        return cleaned_final
    return (
        f"{cleaned_final}\n\n"
        "Required details from the user's original request; preserve them exactly:\n"
        f"{original}"
    )
