"""Deterministic input validation for the image generation agent."""

from __future__ import annotations

from app.agents.base import ValidationError
from app.llm.image_provider import ImageInput
from app.llm.image_processing import normalize_image_size

from .types import ImageGenerationContext

MAX_PROMPT_CHARS = 32000

_SUPPORTED_INPUT_MEDIA_TYPES = {"image/png", "image/jpeg", "image/webp"}
_SUPPORTED_QUALITIES = {"auto", "low", "medium", "high"}
_SUPPORTED_OUTPUT_FORMATS = {"png", "jpeg", "webp"}
_SUPPORTED_MODERATION_LEVELS = {"auto", "low"}


def validate_reference_image(image: ImageInput) -> None:
    """Validate one reference/mask image input."""
    if not isinstance(image, ImageInput):
        raise ValidationError("Reference images must be ImageInput values")
    if not image.filename.strip() or "\x00" in image.filename or len(image.filename) > 255:
        raise ValidationError("Reference image filenames must be non-empty and valid")
    if not image.data:
        raise ValidationError("Reference image data must not be empty")
    if image.media_type not in _SUPPORTED_INPUT_MEDIA_TYPES:
        raise ValidationError("Only PNG, JPEG, and WebP inputs are supported")


def validate_generation_options(options) -> None:
    """Validate provider-neutral generation options."""
    if normalize_image_size(options.size) is None:
        raise ValidationError(f"Unsupported image size: {options.size}")
    if options.quality not in _SUPPORTED_QUALITIES:
        raise ValidationError(f"Unsupported image quality: {options.quality}")
    if options.output_format not in _SUPPORTED_OUTPUT_FORMATS:
        raise ValidationError(f"Unsupported output format: {options.output_format}")
    if options.moderation not in _SUPPORTED_MODERATION_LEVELS:
        raise ValidationError(f"Unsupported moderation level: {options.moderation}")
    if not 1 <= options.n <= 10:
        raise ValidationError("Image count must be between 1 and 10")
    if options.output_compression is not None and not 0 <= options.output_compression <= 100:
        raise ValidationError("Output compression must be between 0 and 100")


def validate_generation_input(
    context: ImageGenerationContext,
    max_reference_images: int,
    max_total_input_bytes: int,
) -> None:
    """Run every deterministic check before any provider or LLM call."""
    if not context.prompt.strip():
        raise ValidationError("prompt is required")
    if len(context.prompt) > MAX_PROMPT_CHARS:
        raise ValidationError(f"prompt must not exceed {MAX_PROMPT_CHARS} characters")
    if len(context.reference_images) > max_reference_images:
        raise ValidationError(
            f"A maximum of {max_reference_images} reference images is allowed"
        )
    if context.mask and not context.reference_images:
        raise ValidationError("A mask requires at least one reference image")

    inputs = [*context.reference_images, *([context.mask] if context.mask else [])]
    for image in inputs:
        validate_reference_image(image)
    if sum(len(image.data) for image in inputs) > max_total_input_bytes:
        raise ValidationError("The combined image input exceeds the configured size limit")

    validate_generation_options(context.options)
