"""Typed inputs for the image generation agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from app.agents.base import AgentContext
from app.llm.image_provider import ImageGenerationOptions, ImageInput


@dataclass
class ImageGenerationContext(AgentContext):
    """Inputs required by the image generation agent."""

    prompt: str = ""
    options: ImageGenerationOptions = field(default_factory=ImageGenerationOptions)
    reference_images: list[ImageInput] = field(default_factory=list)
    mask: Optional[ImageInput] = None
    enhance_prompt: bool = True
    knowledge_documents: list[dict] = field(default_factory=list)
    knowledge_context: str = ""
