"""Bug fix agent package."""

from .agent import BugFixAgent
from .patches import (
    PatchFormatError,
    analysis_summary,
    build_fix_summary,
    fallback_analysis,
    normalize_patch_path,
    parse_analysis,
    parse_fix_response,
    validate_patch_structure,
    validate_patches,
)
from .prompts import (
    ANALYSIS_SYSTEM_PROMPT,
    FIX_SYSTEM_PROMPT,
    build_analysis_prompt,
    build_fix_prompt,
    build_repair_prompt,
)
from .types import BugAnalysis, BugFixContext, BugFixResult

__all__ = [
    "BugFixAgent",
    "BugFixContext",
    "BugAnalysis",
    "BugFixResult",
    "ANALYSIS_SYSTEM_PROMPT",
    "FIX_SYSTEM_PROMPT",
    "build_analysis_prompt",
    "build_fix_prompt",
    "build_repair_prompt",
    "parse_analysis",
    "fallback_analysis",
    "analysis_summary",
    "parse_fix_response",
    "normalize_patch_path",
    "validate_patches",
    "validate_patch_structure",
    "build_fix_summary",
    "PatchFormatError",
]
