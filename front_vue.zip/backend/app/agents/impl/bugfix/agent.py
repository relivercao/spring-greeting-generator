"""BugFixAgent - bug analysis, root cause localization, and patch generation."""

from __future__ import annotations

from loguru import logger

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    CancelledException,
    ValidationError,
)
from app.agents.structured_output import StructuredOutputError
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient

from .patches import (
    PatchFormatError,
    analysis_summary,
    fallback_analysis,
    normalize_patch_path,
    parse_analysis,
    parse_fix_response,
)
from .prompts import (
    ANALYSIS_SYSTEM_PROMPT,
    FIX_SYSTEM_PROMPT,
    build_analysis_prompt,
    build_fix_prompt,
    build_repair_prompt,
)
from .types import BugFixContext, BugFixResult
from .workflow import BugFixWorkflow
from app.services.bugfix_jira import JiraContextError, load_jira_bug

# Contracts used for the one-shot repair rounds of both LLM stages.
_ANALYSIS_CONTRACT = (
    "Return only one valid JSON object with keys root_cause, affected_files, "
    "severity, fix_approach."
)
_FIX_CONTRACT = (
    "Return only <<<FILE:path>>> sections with the complete corrected file "
    "content, followed by one <<<EXPLANATION>>> section."
)


class BugFixAgent(BaseAgent):
    """Bug fixing Agent.

    Stages: fetch issue -> read sources -> structured analysis (JSON with one
    repair round, then graceful fallback) -> module expert reviews -> patch generation (tagged sections
    with one repair round) -> deterministic patch validation -> summary.
    """

    def __init__(self, llm_bridge: LLMBridge, mcp_client: MCPClient, skill_registry=None):
        super().__init__(AgentConfig(agent_type=AgentType.BUGFIX, timeout_seconds=600, durable_runtime=True), skill_registry=skill_registry)
        self._llm = llm_bridge
        self._mcp = mcp_client

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, BugFixContext):
            raise ValidationError("BugFixAgent requires BugFixContext")
        if not context.bug_description and not context.issue_id:
            raise ValidationError("bug_description or issue_id is required")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        assert isinstance(ctx, BugFixContext)
        task_id = ctx.task_id
        skill_plan = await self._prepare_agent_skills(
            ctx, "analyze", scope="bugfix", inputs={"issue_id": ctx.issue_id}
        )

        state = await BugFixWorkflow(self).execute(ctx, skill_plan.prompt)
        self._is_cancelled(task_id)
        source_contents = state.get("source_contents", {})
        analysis = state["analysis"]
        patches = state.get("patches", {})
        explanation = state.get("explanation", "")
        validation_warnings = state.get("validation_warnings", [])

        return BugFixResult(
            task_id=task_id,
            status=AgentStatus.COMPLETED,
            message=(
                f"Bug analysis and fix generated for {len(source_contents)} files"
                if patches
                else f"Bug analysis generated for {len(source_contents)} files; no patch extracted"
            ),
            data={
                "files_analyzed": len(source_contents),
                "issue_id": ctx.issue_id,
                "repository": ctx.repo,
                "branch": ctx.branch,
                "source_files": list(source_contents),
                "severity": analysis.severity,
                "root_cause": analysis.root_cause,
                "fix_approach": analysis.fix_approach,
                "patches": patches,
                "patch_explanation": explanation,
                "validation_warnings": validation_warnings,
                "validation_errors": state.get("validation_errors", []),
                "patch_attempts": state.get("patch_attempts", 0),
                "patch_attempt_history": state.get("patch_attempt_history", []),
                "report_markdown": state.get("summary", ""),
                "expert_reviews": state.get("expert_reviews", []),
                "expert_conflicts": state.get("expert_conflicts", []),
                "code_diffs": state.get("code_diffs", {}),
            },
            analysis=analysis,
            patches=patches,
            fix_explanation=explanation,
            attempts_used=state.get("attempts_used", 0),
            validation_warnings=validation_warnings,
        )

    async def _fetch_issue_description(self, issue_id: str) -> str:
        """Require real Jira Bug context whenever the task specifies a ticket."""
        try:
            issue = await load_jira_bug(self._mcp, issue_id)
        except JiraContextError as error:
            raise ValidationError(str(error)) from error
        return (
            f"\n\nJira Issue {issue['key']}:\n"
            f"Summary: {issue['summary']}\n"
            f"Status: {issue['status']}\nPriority: {issue['priority']}\n"
            f"Description: {issue['description']}\n"
        )

    async def _load_sources(
        self,
        ctx: BugFixContext,
        warnings: list[str] | None = None,
    ) -> tuple[dict[str, str], list[str]]:
        """Merge inline sources with validated files fetched from Bitbucket."""
        source_warnings = list(warnings or [])
        source_contents = {}
        for raw_path, content in ctx.source_contents.items():
            safe_path = normalize_patch_path(raw_path)
            if not safe_path:
                source_warnings.append(f"{raw_path}: invalid inline source path; skipped.")
                continue
            source_contents[safe_path] = content
        for file_path in ctx.source_files:
            self._is_cancelled(ctx.task_id)
            safe_path = normalize_patch_path(file_path)
            if not safe_path:
                source_warnings.append(f"{file_path}: invalid Bitbucket source path; skipped.")
                continue
            if safe_path in source_contents:
                continue
            try:
                result = await self._mcp.call_tool(
                    "bb_get_file",
                    repo=ctx.repo or "firmware",
                    path=safe_path,
                    ref=ctx.branch or "main",
                )
                self._is_cancelled(ctx.task_id)
                data = result.data if isinstance(result.data, dict) else {}
                if result.success and isinstance(data.get("content"), str) and data["content"]:
                    source_contents[safe_path] = data["content"]
                else:
                    source_warnings.append(f"{safe_path}: Bitbucket did not return file content.")
            except CancelledException:
                raise
            except Exception as exc:
                logger.warning(f"Could not read file {file_path}: {exc}")
                source_warnings.append(f"{safe_path}: Bitbucket source could not be read.")
        return source_contents, source_warnings

    async def _run_analysis(
        self,
        bug_description: str,
        code_context: str,
        skill_prompt: str,
        *,
        task_id: str,
    ):
        """Run the structured analysis with one repair round, then fallback."""
        self._is_cancelled(task_id)
        prompt = build_analysis_prompt(bug_description, code_context, skill_prompt)
        response = await self._llm.generate(
            [
                {"role": "system", "content": ANALYSIS_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=4096,
            **self._llm_call_options(),
        )
        self._is_cancelled(task_id)
        try:
            return parse_analysis(response.content), 1
        except StructuredOutputError:
            repaired = await self._llm.generate(
                [
                    {"role": "system", "content": ANALYSIS_SYSTEM_PROMPT},
                    {
                        "role": "user",
                        "content": build_repair_prompt(response.content, _ANALYSIS_CONTRACT),
                    },
                ],
                temperature=0.0,
                max_tokens=4096,
                **self._llm_call_options(),
            )
            self._is_cancelled(task_id)
            try:
                return parse_analysis(repaired.content), 2
            except StructuredOutputError:
                logger.warning("Bug analysis fell back to plain-text root cause")
                return fallback_analysis(repaired.content), 2

    async def _run_fix(
        self,
        analysis,
        code_context: str,
        skill_prompt: str = "",
        *,
        task_id: str,
        previous_patches: dict[str, str] | None = None,
        validation_feedback: list[str] | None = None,
    ):
        """Generate patches with one repair round; tolerate patch failures."""
        self._is_cancelled(task_id)
        prompt = build_fix_prompt(
            analysis_summary(analysis),
            code_context,
            skill_prompt,
            previous_patches,
            validation_feedback,
        )
        response = await self._llm.generate(
            [
                {"role": "system", "content": FIX_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            max_tokens=16_384,
            **self._llm_call_options(),
        )
        self._is_cancelled(task_id)
        try:
            patches, explanation = parse_fix_response(response.content)
            return patches, explanation, 1
        except PatchFormatError as error:
            repaired = await self._llm.generate(
                [
                    {"role": "system", "content": FIX_SYSTEM_PROMPT},
                    {
                        "role": "user",
                        "content": build_repair_prompt(response.content, _FIX_CONTRACT),
                    },
                ],
                temperature=0.0,
                max_tokens=16_384,
                **self._llm_call_options(),
            )
            self._is_cancelled(task_id)
            try:
                patches, explanation = parse_fix_response(repaired.content)
                return patches, explanation, 2
            except PatchFormatError:
                logger.warning(f"Fix generation produced no patches: {error}")
                return {}, "", 2

    @staticmethod
    def _build_code_context(source_contents: dict[str, str]) -> str:
        return "".join(f"\n--- {path} ---\n{content}\n" for path, content in source_contents.items())
