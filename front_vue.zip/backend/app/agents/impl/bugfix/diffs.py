"""Derive reviewable unified diffs from actual source snapshots."""

from difflib import unified_diff


def build_code_diffs(sources: dict[str, str], patches: dict[str, str]) -> dict[str, str]:
    """Never invent an empty baseline for a file that was not read."""
    result = {}
    for path, updated in patches.items():
        if path not in sources or sources[path] == updated:
            continue
        lines = []
        for line in unified_diff(
            sources[path].splitlines(keepends=True), updated.splitlines(keepends=True),
            fromfile=f"a/{path}", tofile=f"b/{path}",
        ):
            lines.append(line)
            if not line.endswith("\n"):
                lines.append("\n\\ No newline at end of file\n")
        result[path] = "".join(lines)
    return result
