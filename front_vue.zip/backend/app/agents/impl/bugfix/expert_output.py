"""Validate module-expert findings and retain their source evidence."""

from pydantic import BaseModel, ConfigDict, Field

from app.agents.structured_output import parse_json_object

from .diffs import build_code_diffs
from .patches import normalize_patch_path, validate_patch_structure


class ExpertFinding(BaseModel):
    model_config = ConfigDict(extra="forbid")

    file: str = Field(min_length=1, max_length=1000)
    line: int | None = Field(default=None, ge=1)
    problem: str = Field(min_length=1, max_length=6000, pattern=r"\S")
    evidence: str = Field(min_length=1, max_length=6000, pattern=r"\S")
    fix_logic: str = Field(min_length=1, max_length=6000, pattern=r"\S")
    risk: str = Field(default="", max_length=4000)


class ExpertResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    summary: str = Field(min_length=1, max_length=8000, pattern=r"\S")
    findings: list[ExpertFinding] = Field(max_length=32)
    fix_logic: str = Field(default="", max_length=12000)
    patches: dict[str, str] = Field(default_factory=dict, max_length=32)
    verification: list[str] = Field(default_factory=list, max_length=32)


def parse_expert_response(content: str, sources: dict[str, str]) -> dict:
    """Reject unsupported files and separate unverified claims from evidence."""
    response = ExpertResponse.model_validate(parse_json_object(content))
    warnings, findings, patches = [], [], {}
    for finding in response.findings:
        path = normalize_patch_path(finding.file)
        if not path or path not in sources:
            warnings.append(f"Expert finding references an unread source: {finding.file}")
            continue
        quote = finding.evidence.strip()
        verified = quote in sources[path]
        if finding.line is not None:
            source_lines = sources[path].splitlines(keepends=True)
            start = sum(len(line) for line in source_lines[:finding.line - 1])
            found = sources[path].find(quote, start)
            verified = verified and finding.line <= len(source_lines) and start <= found < start + len(source_lines[finding.line - 1])
        if not verified:
            warnings.append(f"{path}: expert source evidence or line could not be verified")
        findings.append({**finding.model_dump(), "file": path, "evidence_verified": verified})
    for raw_path, updated in response.patches.items():
        path = normalize_patch_path(raw_path)
        if not path or path not in sources:
            warnings.append(f"Expert patch references an unread source: {raw_path}")
        elif not updated.strip() or len(updated) > 250_000:
            warnings.append(f"{path}: expert patch is empty or exceeds the source size limit")
        else:
            patches[path] = updated
    for path, error in validate_patch_structure(patches).items():
        warnings.append(f"{path}: expert patch rejected: {error}")
        patches.pop(path)
    return {
        "status": "needs_review" if warnings else "completed",
        "summary": response.summary, "findings": findings,
        "fix_logic": response.fix_logic, "patches": patches,
        "code_diffs": build_code_diffs(sources, patches),
        "verification": response.verification, "warnings": warnings,
    }


def expert_conflicts(reviews: list[dict]) -> list[dict]:
    """Keep differing independent proposals visible instead of overwriting them."""
    candidates = {}
    for review in reviews:
        for path, content in review.get("patches", {}).items():
            candidates.setdefault(path, []).append((review["skill"], content))
    return [
        {"file": path, "skills": [name for name, _ in proposals],
         "message": "Experts proposed different versions; the final fix must reconcile them."}
        for path, proposals in candidates.items()
        if len({content for _, content in proposals}) > 1
    ]


def expert_report_markdown(reviews: list[dict], conflicts: list[dict]) -> str:
    lines = ["## Module expert reviews", ""]
    if not reviews:
        lines.extend(["No applicable module expert skill was available for this source context.", ""])
    for review in reviews:
        lines.extend([
            f"### {review['skill']} ({review['module']})", "",
            f"Status: {review['status']}", "", review.get("summary", ""), "",
            review.get("fix_logic", ""), "",
        ])
        for finding in review.get("findings", []):
            location = f"{finding['file']}:{finding['line']}" if finding.get("line") else finding["file"]
            lines.extend([
                f"- {location}: {finding['problem']}",
                f"  - Evidence verified: {finding['evidence_verified']}",
                f"  - Evidence: {finding['evidence']}",
                f"  - Fix logic: {finding['fix_logic']}",
                f"  - Risk: {finding['risk']}",
            ])
        for path, diff in review.get("code_diffs", {}).items():
            lines.extend(["", f"#### Candidate diff: {path}", "", "````diff", diff, "````", ""])
        for check in review.get("verification", []):
            lines.append(f"- Proposed verification (not executed): {check}")
        for warning in review.get("warnings", []):
            lines.append(f"- Review warning: {warning}")
        lines.append("")
    for conflict in conflicts:
        lines.append(f"- Proposal conflict: {conflict['file']} ({', '.join(conflict['skills'])})")
    return "\n".join(lines) + "\n"
