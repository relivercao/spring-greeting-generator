"""Typed inputs and outputs for the bug fix agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from app.agents.base import AgentContext, AgentResult

VALID_SEVERITIES = {"low", "medium", "high", "critical"}


@dataclass
class BugFixContext(AgentContext):
    """Bug-fix context"""

    bug_description: str = ""
    issue_id: Optional[str] = None      # Jira issue key
    repo: Optional[str] = None
    branch: str = "main"
    source_files: list[str] = field(default_factory=list)
    source_contents: dict[str, str] = field(default_factory=dict)
    max_attempts: int = 3


@dataclass
class BugAnalysis:
    """Structured bug analysis result"""

    root_cause: str = ""
    affected_files: list[str] = field(default_factory=list)
    severity: str = "medium"
    fix_approach: str = ""


@dataclass
class BugFixResult(AgentResult):
    """Bug-fix result"""

    analysis: Optional[BugAnalysis] = None
    patches: dict[str, str] = field(default_factory=dict)  # file -> patch content
    fix_explanation: str = ""
    attempts_used: int = 0
    validation_warnings: list[str] = field(default_factory=list)
