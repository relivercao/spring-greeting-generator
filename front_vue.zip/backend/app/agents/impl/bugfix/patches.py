"""Parse and deterministically validate generated fix patches."""

from __future__ import annotations

import json
import re
from pathlib import PureWindowsPath
from typing import Any

from app.agents.structured_output import StructuredOutputError, parse_json_object
from app.core.c_source import mask_c_non_code

from .types import BugAnalysis, VALID_SEVERITIES

_PATCH_SECTION = re.compile(
    r"^<<<FILE:(.+?)>>>\s*\n(.*?)(?=^<<<[A-Z]+(?::.*?)?>>>\s*$|\Z)",
    re.MULTILINE | re.DOTALL,
)
_EXPLANATION_SECTION = re.compile(
    r"^<<<EXPLANATION>>>\s*\n(.*?)(?=^<<<[A-Z]+(?::.*?)?>>>\s*$|\Z)",
    re.MULTILINE | re.DOTALL,
)

_SEVERITY_ALIASES = {
    "info": "low",
    "minor": "low",
    "major": "high",
    "blocker": "critical",
    "trivial": "low",
}

# File extensions whose brace balance is checked.
_C_LIKE_EXTENSIONS = (".c", ".h", ".cpp", ".hpp", ".cc", ".cxx", ".inl")


class PatchFormatError(ValueError):
    """Raised when the fix response contains no usable patch sections."""


def parse_analysis(content: str) -> BugAnalysis:
    """Parse the structured analysis JSON into a BugAnalysis."""
    payload = parse_json_object(content)
    root_cause = str(payload.get("root_cause") or payload.get("probable_cause") or "").strip()
    if not root_cause:
        raise StructuredOutputError("The analysis JSON must contain a root_cause")
    severity = str(payload.get("severity") or "medium").strip().lower()
    severity = _SEVERITY_ALIASES.get(severity, severity)
    if severity not in VALID_SEVERITIES:
        severity = "medium"
    affected_files = _string_list(payload.get("affected_files"), limit=64)
    return BugAnalysis(
        root_cause=root_cause,
        affected_files=affected_files,
        severity=severity,
        fix_approach=str(payload.get("fix_approach") or "").strip(),
    )


def fallback_analysis(content: str) -> BugAnalysis:
    """Degrade a non-JSON analysis response into a plain root-cause text."""
    text = (content or "").strip()
    return BugAnalysis(root_cause=text or "The analysis provider returned no content.")


def analysis_summary(analysis: BugAnalysis) -> str:
    """Render the structured analysis for the fix prompt."""
    affected = ", ".join(analysis.affected_files) or "not determined"
    approach = analysis.fix_approach or "not specified"
    return (
        f"Root cause: {analysis.root_cause}\n"
        f"Affected files: {affected}\n"
        f"Severity: {analysis.severity}\n"
        f"Fix approach: {approach}"
    )


def parse_fix_response(content: str) -> tuple[dict[str, str], str]:
    """Parse tagged FILE/EXPLANATION sections from a fix response.

    Returns (patches, explanation). Raises PatchFormatError when the response
    contains no FILE section at all.
    """
    patches: dict[str, str] = {}
    for match in _PATCH_SECTION.finditer(content.strip()):
        path = normalize_patch_path(match.group(1))
        body = _strip_code_fence(match.group(2).strip())
        if path and body:
            patches[path] = body
    explanation_match = _EXPLANATION_SECTION.search(content.strip())
    explanation = explanation_match.group(1).strip() if explanation_match else ""
    if not patches:
        json_patches, json_explanation = _parse_json_patches(content)
        if json_patches:
            return json_patches, json_explanation
        raise PatchFormatError("The fix response contains no <<<FILE:path>>> sections")
    return patches, explanation


def normalize_patch_path(path: str) -> str:
    """Normalize a patch path; return an empty string for unsafe paths."""
    cleaned = str(path or "").strip().replace("\\", "/")
    while cleaned.startswith("./"):
        cleaned = cleaned[2:]
    if not cleaned or cleaned.startswith("/"):
        return ""
    if PureWindowsPath(cleaned).drive or re.search(r'[<>:"|?*\x00-\x1f]', cleaned):
        return ""
    parts = [segment for segment in cleaned.split("/") if segment not in ("", ".")]
    if not parts or any(
        segment == ".."
        or segment.endswith((".", " "))
        or re.fullmatch(r"(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", segment, re.IGNORECASE)
        for segment in parts
    ):
        return ""
    return "/".join(parts)


def validate_patches(
    patches: dict[str, str],
    known_files: list[str],
) -> tuple[dict[str, str], list[str]]:
    """Deterministically validate generated patches.

    Empty patches and unsafe paths are dropped, C-like files are checked for
    brace balance, and patches for
    files outside the analyzed set produce a warning. Every adjustment is
    reported, following the driver agent validation style.
    """
    warnings: list[str] = []
    known = {normalize_patch_path(path) or path for path in known_files}
    validated: dict[str, str] = {}
    structure_errors = validate_patch_structure(patches)
    for path, content in patches.items():
        normalized_path = normalize_patch_path(path)
        if not normalized_path:
            warnings.append(f"{path!r}: patch path is unsafe; dropped")
            continue
        if not content.strip():
            warnings.append(f"{path}: patch is empty; dropped")
            continue
        if path in structure_errors:
            warnings.append(f"{path}: patch has unbalanced braces ({structure_errors[path]})")
        if known and normalized_path not in known:
            warnings.append(f"{path}: patched file was not part of the analyzed sources")
        validated[normalized_path] = content
    return validated, warnings


def validate_patch_structure(patches: dict[str, str]) -> dict[str, str]:
    """Return blocking structural diagnostics for supported C-like patches."""
    errors: dict[str, str] = {}
    for path, content in patches.items():
        if not path.lower().endswith(_C_LIKE_EXTENSIONS):
            continue
        issue = _unbalanced_braces(content)
        if issue:
            errors[path] = issue
    return errors


def _unbalanced_braces(content: str) -> str:
    """Count code braces while ignoring comments and quoted literals."""
    opening_lines: list[int] = []
    for line_number, line in enumerate(mask_c_non_code(content).splitlines(), start=1):
        for character in line:
            if character == "{":
                opening_lines.append(line_number)
            elif character == "}":
                if not opening_lines:
                    return f"patch has an unmatched closing brace on line {line_number}"
                opening_lines.pop()
    if opening_lines:
        return f"patch has {len(opening_lines)} unmatched opening brace(s) from line {opening_lines[-1]}"
    return ""


def build_fix_summary(
    analysis: BugAnalysis,
    patches: dict[str, str],
    explanation: str,
    warnings: list[str],
    attempt_history: list[dict[str, Any]] | None = None,
) -> str:
    """Render a Markdown summary of the analysis and the generated patches."""
    lines = [
        "# Bug Fix Proposal",
        "",
        f"- Severity: {analysis.severity}",
        f"- Affected files: {', '.join(analysis.affected_files) or 'not determined'}",
        "",
        "## Root cause",
        "",
        analysis.root_cause,
        "",
    ]
    if patches:
        lines.extend(["## Generated patches", "", *[f"- `{path}`" for path in sorted(patches)], ""])
    else:
        lines.extend(["## Generated patches", "", "No patch files were produced.", ""])
    if explanation:
        lines.extend(["## Explanation", "", explanation, ""])
    if attempt_history:
        lines.extend(["## Action and observation", ""])
        for item in attempt_history:
            attempt = item.get("attempt", "?")
            outcome = item.get("validation") or "not validated"
            paths = ", ".join(item.get("patch_paths") or []) or "no patch files"
            lines.append(f"- Attempt {attempt}: {outcome}; {paths}.")
            for error in item.get("validation_errors") or []:
                lines.append(f"  - Feedback: {error}")
        lines.append("")
    if warnings:
        lines.extend(["## Validation warnings", "", *[f"- {warning}" for warning in warnings], ""])
    return "\n".join(lines).strip() + "\n"


def _parse_json_patches(content: str) -> tuple[dict[str, str], str]:
    """Fall back to a JSON ``{"patches": {"path": "content"}}`` response."""
    try:
        payload = parse_json_object(content)
    except StructuredOutputError:
        return {}, ""
    raw = payload.get("patches")
    if not isinstance(raw, dict):
        return {}, ""
    patches = {
        path: body
        for path, body in (
            (normalize_patch_path(str(key)), str(value))
            for key, value in raw.items()
            if isinstance(value, str)
        )
        if path and body.strip()
    }
    explanation = str(payload.get("explanation") or "").strip()
    return patches, explanation


def _string_list(raw: Any, limit: int) -> list[str]:
    if not isinstance(raw, list):
        return []
    return [str(item).strip() for item in raw[:limit] if str(item).strip()]


def _strip_code_fence(content: str) -> str:
    match = re.fullmatch(r"```(?:[A-Za-z0-9_+-]+)?\s*\n(.*?)\n```", content.strip(), re.DOTALL)
    return match.group(1).strip() if match else content.strip()
