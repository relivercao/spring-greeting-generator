"""Design parsing and deterministic fallback for the agent generator."""

from __future__ import annotations

from typing import Any

from app.agents.structured_output import parse_json_object

from .types import AgentGeneratorContext

_DEFAULT_CAPABILITIES = ["goal_analysis", "knowledge_grounding", "structured_output"]
_FALLBACK_CAPABILITIES = [
    "goal_analysis",
    "knowledge_grounding",
    "structured_output",
    "verification",
]


def parse_design(content: str) -> dict[str, Any]:
    """Parse the LLM design JSON; never raise on malformed output.

    Any response that is not a JSON object degrades to a design whose
    system_prompt is the raw text, so the caller keeps the model output.
    """
    text = (content or "").strip()
    if not text:
        return {}
    try:
        parsed = parse_json_object(text)
    except ValueError:
        return {"system_prompt": text}
    return parsed


def normalize_design(design: dict[str, Any]) -> tuple[str, str, list[str]]:
    """Extract and clean (system_prompt, description, capabilities)."""
    system_prompt = str(design.get("system_prompt") or "").strip()
    description = str(design.get("description") or "Generated firmware development Agent").strip()
    capabilities = [
        str(item).strip() for item in (design.get("capabilities") or []) if str(item).strip()
    ] or list(_DEFAULT_CAPABILITIES)
    return system_prompt, description, capabilities[:20]


def merge_reviewed_design(
    original: dict[str, Any], reviewed_content: str
) -> tuple[dict[str, Any], bool]:
    """Accept a structured review while preserving the original design contract."""
    try:
        reviewed = parse_json_object((reviewed_content or "").strip())
    except ValueError:
        return original, False
    system_prompt = str(reviewed.get("system_prompt") or "").strip()
    original_prompt = str(original.get("system_prompt") or "").strip()
    minimum_length = min(len(original_prompt), max(80, int(len(original_prompt) * 0.5)))
    if not system_prompt or len(system_prompt) < minimum_length:
        return original, False

    original_capabilities = original.get("capabilities") or []
    reviewed_capabilities = reviewed.get("capabilities") or []
    if not isinstance(original_capabilities, list):
        original_capabilities = []
    if not isinstance(reviewed_capabilities, list):
        reviewed_capabilities = []
    capabilities = list(dict.fromkeys(
        [str(item).strip() for item in original_capabilities if str(item).strip()]
        + [str(item).strip() for item in reviewed_capabilities if str(item).strip()]
    ))
    return {
        "description": str(reviewed.get("description") or original.get("description") or "").strip(),
        "system_prompt": system_prompt,
        "capabilities": capabilities,
    }, True


def fallback_design(
    context: AgentGeneratorContext, docs: list[dict[str, Any]]
) -> dict[str, Any]:
    """Build a deterministic design when the LLM is unavailable or failed."""
    name = context.name.strip() or "Generated Firmware Agent"
    references = ", ".join(str(item.get("title") or item.get("id")) for item in docs) or "the configured knowledge base"
    skills = ", ".join(str(item.get("name") or item.get("id")) for item in (context.skill_files or [])) or "none"
    tools = ", ".join(str(item.get("name") or "unknown") for item in (context.selected_tools or [])) or "none"
    prompt = (
        f"You are {name}, a focused firmware development Agent.\n\n"
        f"Mission: {context.goal.strip() or context.prompt.strip()}\n\n"
        "Workflow:\n"
        "1. Clarify missing hardware, interface, toolchain, and acceptance criteria.\n"
        "2. Ground factual claims in the selected canonical knowledge references.\n"
        "3. Produce safe, buildable, reviewable output with assumptions listed explicitly.\n"
        "4. Include validation steps, edge cases, and rollback guidance when code or configuration changes are proposed.\n\n"
        f"Selected knowledge references: {references}.\n"
        f"Attached skill files: {skills}. Apply their instructions when relevant, while preserving this Agent goal and safety rules.\n"
        f"Selected external tools: {tools}. Use their returned evidence when relevant and cite URLs or source metadata.\n"
        "Flow:\n"
        + "\n".join(
            f"{index}. {item.get('label') or item.get('id')}: {item.get('description') or ''}"
            for index, item in enumerate(context.flow_nodes or [], start=1)
        )
        + "\n\n"
        "Output format: concise summary, assumptions, implementation or answer, verification steps, and cited references.\n"
        + (
            "Return the answer in chat only."
            if context.output_mode == "text"
            else f"Also prepare a complete {context.output_format} artifact named {context.output_filename or 'agent-output'}."
        )
    )
    return {
        "description": f"Agent focused on {context.goal.strip() or context.prompt.strip()}",
        "system_prompt": prompt,
        "capabilities": list(_FALLBACK_CAPABILITIES),
    }
