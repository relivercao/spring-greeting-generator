"""Typed inputs for the agent generator."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from app.agents.base import AgentContext


@dataclass
class AgentGeneratorContext(AgentContext):
    """Context used during Agent design."""

    name: str = ""
    goal: str = ""
    prompt: str = ""
    knowledge_documents: list[dict[str, Any]] | None = None
    input_files: list[dict[str, Any]] | None = None
    input_definitions: list[dict[str, Any]] | None = None
    skill_files: list[dict[str, Any]] | None = None
    selected_tools: list[dict[str, Any]] | None = None
    flow_nodes: list[dict[str, Any]] | None = None
    llm_provider: str = "macode"
    llm_model: str = ""
    output_mode: str = "text"
    output_format: str = "markdown"
    output_filename: str = ""
