"""Bounded syntax validation and repair for generated code artifacts."""

from __future__ import annotations

import ast
import re
from typing import Any, Awaitable, Callable

from loguru import logger

from app.services.code_parser import analyze_source_file


_CODE_FORMATS = {"c_source": "agent-output.c", "c_header": "agent-output.h", "python": "agent-output.py"}
MAX_REPAIR_ATTEMPTS = 2
_FENCE = re.compile(r"^```(?:[\w.+-]+)?\s*\n(.*?)\n```\s*$", re.DOTALL)
PythonFunctionContract = tuple[str, str, str, tuple[str, ...]]


def _normalize_code(content: str) -> str:
    normalized = str(content or "").strip()
    match = _FENCE.fullmatch(normalized)
    return match.group(1).strip() if match else normalized


def _validate_code_artifact(content: str, output_format: str) -> tuple[list[str], str]:
    """Return deterministic syntax diagnostics and whether validation actually ran."""
    normalized = _normalize_code(content)
    if not normalized:
        return ["The generated code artifact is empty."], "failed"
    if output_format == "python":
        try:
            compile(normalized, "agent-output.py", "exec", dont_inherit=True)
        except SyntaxError as exc:
            return [f"Python syntax error at line {exc.lineno}, column {exc.offset}: {exc.msg}"], "failed"
        return [], "passed"

    analysis = analyze_source_file(_CODE_FORMATS[output_format], normalized.encode("utf-8"))
    if analysis.get("parser") != "tree-sitter":
        return [], "unavailable"
    syntax_errors = int(analysis.get("syntax_errors") or 0)
    if syntax_errors:
        return [
            f"The C parser found {syntax_errors} syntax error(s). "
            "Preserve complete declarations and fix malformed C syntax."
        ], "failed"
    return [], "passed"


def validate_code_artifact(content: str, output_format: str) -> list[str]:
    """Return deterministic syntax errors without treating a missing parser as success."""
    if output_format not in _CODE_FORMATS:
        return [f"Unsupported code output format: {output_format}"]
    issues, validation = _validate_code_artifact(content, output_format)
    if validation == "unavailable":
        return ["C syntax validation is unavailable because the Tree-sitter parser did not run."]
    return issues


def _function_names(content: str, output_format: str) -> set[str]:
    analysis = analyze_source_file(_CODE_FORMATS[output_format], content.encode("utf-8"))
    return {
        str(item.get("name"))
        for item in analysis.get("functions", [])
        if item.get("name")
    }


def _python_function_contracts(
    content: str,
) -> dict[str, set[PythonFunctionContract]] | None:
    """Collect qualified Python function signatures when the source parses."""
    try:
        tree = ast.parse(content, filename="agent-output.py")
    except SyntaxError:
        return None

    contracts: dict[str, set[PythonFunctionContract]] = {}

    def visit(node: ast.AST, scope: tuple[str, ...]) -> None:
        for child in ast.iter_child_nodes(node):
            child_scope = scope
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                qualified_name = ".".join((*scope, child.name))
                contract = (
                    type(child).__name__,
                    ast.dump(child.args, include_attributes=False),
                    ast.dump(child.returns, include_attributes=False)
                    if child.returns is not None
                    else "",
                    tuple(ast.dump(decorator, include_attributes=False) for decorator in child.decorator_list),
                )
                contracts.setdefault(qualified_name, set()).add(contract)
                child_scope = (*scope, child.name)
            elif isinstance(child, ast.ClassDef):
                child_scope = (*scope, child.name)
            visit(child, child_scope)

    visit(tree, ())
    return contracts


def _preserves_interfaces(
    original_functions: set[str],
    candidate_functions: set[str],
    original_contracts: dict[str, set[PythonFunctionContract]] | None,
    candidate: str,
    output_format: str,
) -> bool:
    """Keep existing callable names and parsed Python signatures stable."""
    if not original_functions.issubset(candidate_functions):
        return False
    if output_format != "python" or original_contracts is None:
        return True

    candidate_contracts = _python_function_contracts(candidate)
    if candidate_contracts is None:
        return False
    return all(
        signatures.issubset(candidate_contracts.get(name, set()))
        for name, signatures in original_contracts.items()
    )


async def improve_code_artifact(
    generate: Callable[[list[dict[str, str]]], Awaitable[Any]],
    messages: list[dict[str, str]],
    draft: str,
    output_format: str,
) -> tuple[str, dict[str, Any]]:
    """Review code once, then repair deterministic syntax errors with a strict limit."""
    if output_format not in _CODE_FORMATS:
        return draft, {"reviewed": False, "repair_attempts": 0, "validation": "not_applicable"}

    original = _normalize_code(draft)
    issues, validation = _validate_code_artifact(original, output_format)
    if validation == "unavailable":
        return original, {"reviewed": False, "repair_attempts": 0, "validation": validation}

    original_functions = _function_names(original, output_format)
    original_contracts = (
        _python_function_contracts(original) if output_format == "python" else None
    )
    reviewed = original
    review_completed = False
    review_prompt = (
        f"Review this complete {output_format} artifact against the original request and all "
        "evidence, safety, and output requirements above. Improve correctness, edge cases, API "
        "usage, and maintainability while preserving required interfaces and behavior. Do not "
        "invent unavailable project APIs. Return only the complete replacement artifact, without "
        "Markdown fences or review commentary.\n\n"
        f"CURRENT ARTIFACT:\n{original}"
    )
    try:
        reviewed_response = await generate(messages + [
            {"role": "assistant", "content": draft},
            {"role": "user", "content": review_prompt},
        ])
        candidate = _normalize_code(str(reviewed_response.content or ""))
        if candidate:
            candidate_functions = _function_names(candidate, output_format)
            candidate_issues, candidate_validation = _validate_code_artifact(candidate, output_format)
            preserves_interface = _preserves_interfaces(
                original_functions,
                candidate_functions,
                original_contracts,
                candidate,
                output_format,
            )
            if candidate_validation != "unavailable" and preserves_interface and (not candidate_issues or (issues and len(candidate_issues) < len(issues))):
                reviewed = candidate
                issues = candidate_issues
                validation = candidate_validation
                review_completed = True
    except Exception as error:
        # A failed optional review must not discard a draft that can still be checked or repaired.
        logger.warning("Optional generated-code review failed: {}", type(error).__name__)

    repair_attempts = 0
    while issues and validation == "failed" and repair_attempts < MAX_REPAIR_ATTEMPTS:
        repair_attempts += 1
        repair_prompt = (
            f"Repair this complete {output_format} artifact using these deterministic validation "
            f"diagnostics: {issues}. Make the smallest correct changes, preserve required public "
            "functions and behavior, and return only the complete replacement artifact. Do not "
            "claim validation passed.\n\n"
            f"CURRENT ARTIFACT:\n{reviewed}"
        )
        try:
            repaired_response = await generate(messages + [
                {"role": "assistant", "content": reviewed},
                {"role": "user", "content": repair_prompt},
            ])
        except Exception as error:
            raise ValueError(f"Code repair could not run: {error}") from error
        candidate = _normalize_code(str(repaired_response.content or ""))
        if candidate:
            candidate_functions = _function_names(candidate, output_format)
            candidate_issues, candidate_validation = _validate_code_artifact(candidate, output_format)
            preserves_interface = _preserves_interfaces(
                original_functions,
                candidate_functions,
                original_contracts,
                candidate,
                output_format,
            )
            if candidate_validation != "unavailable" and preserves_interface and (not candidate_issues or len(candidate_issues) < len(issues)):
                reviewed = candidate
                issues = candidate_issues
                validation = candidate_validation

    if issues and validation == "failed":
        raise ValueError(
            f"Generated code failed syntax validation after {MAX_REPAIR_ATTEMPTS} repair attempts: "
            + "; ".join(issues)
        )
    return reviewed, {
        "reviewed": review_completed,
        "repair_attempts": repair_attempts,
        "validation": validation,
    }
