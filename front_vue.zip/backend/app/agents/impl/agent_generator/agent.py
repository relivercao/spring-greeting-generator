"""AgentGeneratorAgent - turn a natural-language goal into a reusable Agent prompt."""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING

from loguru import logger

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    CancelledException,
    ValidationError,
)
from app.llm.bridge import LLMBridge
from .design import fallback_design, merge_reviewed_design, normalize_design, parse_design
from .prompts import DESIGN_REVIEW_INSTRUCTION, build_design_messages, runtime_contract
from .skill_generation import (
    build_skill_generation_messages,
    build_skill_repair_instruction,
    validate_generated_skill,
)
from .types import AgentGeneratorContext

if TYPE_CHECKING:
    from app.skills.registry import SkillRegistry

# Providers whose generation requests are routed through the Claude CLI.
_ROUTED_PROVIDERS = {"macode", "bedrock"}


class AgentGeneratorAgent(BaseAgent):
    """Generate a system prompt and metadata for a new Agent.

    Workflow: build the source prompt from all evidence -> ask the LLM for a
    JSON design (falling back to a deterministic scaffold) -> append the
    runtime contract -> return the packaged design.
    """

    def __init__(self, llm_bridge: LLMBridge, skill_registry: Optional["SkillRegistry"] = None):
        super().__init__(
            AgentConfig(
                agent_type=AgentType.AGENT_GENERATOR,
                timeout_seconds=300,
                enable_streaming=False,
                durable_runtime=True,
            ),
            skill_registry=skill_registry,
        )
        self._llm = llm_bridge

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, AgentGeneratorContext):
            raise ValidationError("AgentGeneratorAgent requires AgentGeneratorContext")
        if not context.prompt.strip():
            raise ValidationError("prompt is required")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        docs = ctx.knowledge_documents or []
        skill_plan = await self._prepare_agent_skills(
            ctx, "planning", scope="agent_generator",
            inputs={"document_count": len(docs), "flow_nodes": len(ctx.flow_nodes or [])},
        )
        await self._report_progress(ctx.task_id, 15, "planning", "Preparing Agent requirements")
        messages = build_design_messages(ctx, docs, skill_plan.prompt)

        generated_by_llm = True
        warnings: list[str] = []
        self._is_cancelled(ctx.task_id)
        try:
            response = await self._llm.generate(
                messages,
                temperature=0.35,
                max_tokens=5000,
                **self._design_llm_options(ctx),
            )
            self._is_cancelled(ctx.task_id)
            design = parse_design(response.content)
            if not design.get("system_prompt"):
                raise ValueError("The configured LLM returned no system prompt")
            try:
                review_response = await self._llm.generate(
                    messages + [
                        {"role": "assistant", "content": response.content},
                        {"role": "user", "content": DESIGN_REVIEW_INSTRUCTION},
                    ],
                    temperature=0.2,
                    max_tokens=5000,
                    **self._design_llm_options(ctx),
                )
                self._is_cancelled(ctx.task_id)
                design, review_accepted = merge_reviewed_design(design, review_response.content)
                if not review_accepted:
                    warnings.append("Agent design review returned no safe structured improvement; the initial design was retained.")
            except CancelledException:
                raise
            except Exception as review_error:
                warnings.append(f"Agent design review was unavailable; the initial design was retained: {review_error}")
                logger.warning("Agent design review kept initial prompt: {}", review_error)
        except CancelledException:
            raise
        except Exception as error:
            generated_by_llm = False
            warnings.append(f"LLM generation was unavailable; deterministic prompt scaffold used: {error}")
            logger.warning("Agent prompt generation fell back to deterministic scaffold: {}", error)
            design = fallback_design(ctx, docs)

        self._is_cancelled(ctx.task_id)
        system_prompt, description, capabilities = normalize_design(design)
        system_prompt = system_prompt + "\n\n" + runtime_contract(ctx)
        await self._report_progress(ctx.task_id, 90, "ready", "Agent prompt is ready")
        self._is_cancelled(ctx.task_id)
        return AgentResult(
            task_id=ctx.task_id,
            status=AgentStatus.COMPLETED,
            message="Agent prompt generated",
            data={
                "name": ctx.name.strip() or "Generated Firmware Agent",
                "goal": ctx.goal.strip(),
                "source_prompt": ctx.prompt.strip(),
                "description": description,
                "system_prompt": system_prompt,
                "prompt_preview": system_prompt,
                "capabilities": capabilities,
                "knowledge_documents": docs,
                "knowledge_document_ids": [str(item.get("id")) for item in docs if item.get("id")],
                "input_files": ctx.input_files or [],
                "input_definitions": ctx.input_definitions or [],
                "skill_files": ctx.skill_files or [],
                "selected_tools": ctx.selected_tools or [],
                "flow_nodes": ctx.flow_nodes or [],
                "llm_provider": ctx.llm_provider,
                "llm_model": ctx.llm_model,
                "output_mode": ctx.output_mode,
                "output_format": ctx.output_format,
                "output_filename": ctx.output_filename,
                "generated_by_llm": generated_by_llm,
                "warnings": warnings,
            },
        )

    async def generate_skill_draft(
        self,
        name: str,
        goal: str,
        context: AgentGeneratorContext,
    ) -> tuple[str, str, list[str]]:
        """Generate and validate one standalone SKILL.md for the current Agent."""
        messages = build_skill_generation_messages(
            name,
            goal,
            {"name": context.name, "goal": context.goal, "prompt": context.prompt},
        )
        llm_options = self._design_llm_options(context)
        response = await self._llm.generate(
            messages,
            temperature=0.35,
            max_tokens=5000,
            **llm_options,
        )
        draft = str(response.content or "")
        try:
            content, metadata = validate_generated_skill(draft, name)
            return content, str(metadata["description"]).strip(), []
        except ValueError as validation_error:
            repair_messages = messages + [
                {"role": "assistant", "content": draft[:256 * 1024]},
                {"role": "user", "content": build_skill_repair_instruction(validation_error)},
            ]
            repair_response = await self._llm.generate(
                repair_messages,
                temperature=0.2,
                max_tokens=5000,
                **llm_options,
            )
            content, metadata = validate_generated_skill(str(repair_response.content or ""), name)
            return content, str(metadata["description"]).strip(), [
                "The initial Skill draft required a format repair before it could be attached."
            ]

    def _design_llm_options(self, ctx: AgentGeneratorContext) -> dict[str, Any]:
        """LLM call options, rerouting configured providers through the CLI."""
        llm_options = self._llm_call_options()
        requested_provider = str(ctx.llm_provider or "").strip().lower()
        requested_model = str(ctx.llm_model or "").strip()
        if requested_provider in _ROUTED_PROVIDERS and requested_model:
            llm_options = {
                "provider": "claude_cli",
                "model": requested_model,
                "upstream_provider": requested_provider,
                "task_id": ctx.task_id,
                "unbounded_runtime": True,
            }
        return llm_options
