"""
@file publication.py
@author caoshwen
@brief Transactional publication of verified driver files to the source project

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from .build.session import IsolatedBuildSession
from .types import CompilationContext, ManifestScope


@dataclass(frozen=True)
class PublishedFile:
    """Evidence for one file committed by a publication transaction."""

    relative_path: str
    absolute_path: str
    scope: str
    sha256: str
    size: int
    replaced: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "relative_path": self.relative_path,
            "absolute_path": self.absolute_path,
            "scope": self.scope,
            "sha256": self.sha256,
            "size": self.size,
            "replaced": self.replaced,
        }


@dataclass(frozen=True)
class PublicationResult:
    """Outcome of publishing a verified candidate to the original repository."""

    attempted: bool
    success: bool
    configuration: str
    published_at: str
    files: tuple[PublishedFile, ...] = field(default_factory=tuple)
    rolled_back: bool = False
    error: str | None = None
    delivery_mode: str = "copy_to_original"

    @property
    def published_paths(self) -> list[str]:
        return [item.absolute_path for item in self.files]

    def to_dict(self) -> dict[str, object]:
        return {
            "attempted": self.attempted,
            "success": self.success,
            "configuration": self.configuration,
            "published_at": self.published_at,
            "published_files": [item.to_dict() for item in self.files],
            "rolled_back": self.rolled_back,
            "error": self.error,
            "delivery_mode": self.delivery_mode,
        }


@dataclass
class _PublicationTarget:
    relative_path: str
    destination: Path
    scope: str
    content: bytes
    existed: bool
    original_content: bytes | None
    original_mode: int | None
    staged_path: Path | None = None


def publish_compilation_output(context: CompilationContext) -> PublicationResult:
    """Publish a verified target-project build with rollback on failure."""
    published_at = datetime.now(timezone.utc).isoformat()
    configuration = context.configuration or ""
    prerequisite_error = _delivery_prerequisite_error(context)
    if prerequisite_error:
        return PublicationResult(
            attempted=False,
            success=False,
            configuration=configuration,
            published_at=published_at,
            error=prerequisite_error,
        )

    try:
        targets = _publication_targets(context)
        evidence = _commit_targets(targets)
        return PublicationResult(
            attempted=True,
            success=True,
            configuration=configuration,
            published_at=published_at,
            files=tuple(evidence),
            delivery_mode="copy_to_original",
        )
    except _PublicationFailure as exc:
        return PublicationResult(
            attempted=True,
            success=False,
            configuration=configuration,
            published_at=published_at,
            rolled_back=exc.rolled_back,
            error=str(exc),
            delivery_mode="copy_to_original",
        )
    except (OSError, ValueError) as exc:
        return PublicationResult(
            attempted=True,
            success=False,
            configuration=configuration,
            published_at=published_at,
            error=f"{type(exc).__name__}: {exc}",
            delivery_mode="copy_to_original",
        )


def record_in_place_delivery(context: CompilationContext) -> PublicationResult:
    """Record files verified by an in-place target-project build transaction."""
    published_at = datetime.now(timezone.utc).isoformat()
    configuration = context.configuration or ""
    prerequisite_error = _delivery_prerequisite_error(context)
    if prerequisite_error:
        return PublicationResult(
            attempted=False,
            success=False,
            configuration=configuration,
            published_at=published_at,
            error=prerequisite_error,
            delivery_mode="in_place_transaction",
        )
    try:
        targets = _publication_targets(context)
        evidence = _record_existing_targets(targets)
        return PublicationResult(
            attempted=True,
            success=True,
            configuration=configuration,
            published_at=published_at,
            files=tuple(evidence),
            delivery_mode="in_place_transaction",
        )
    except (OSError, ValueError) as exc:
        return PublicationResult(
            attempted=True,
            success=False,
            configuration=configuration,
            published_at=published_at,
            error=f"{type(exc).__name__}: {exc}",
            delivery_mode="in_place_transaction",
        )


def _delivery_prerequisite_error(context: CompilationContext) -> str | None:
    if not context.build_success:
        return "Publication requires a successful final build"
    firmware_path = Path(context.firmware_path) if context.firmware_path else None
    if firmware_path is None or not firmware_path.is_file():
        return "Publication requires a verified target-project firmware image"
    if not context.manifest:
        return "Publication requires a generated file manifest"
    return None


class _PublicationFailure(RuntimeError):
    def __init__(self, message: str, *, rolled_back: bool):
        super().__init__(message)
        self.rolled_back = rolled_back


def _publication_targets(context: CompilationContext) -> list[_PublicationTarget]:
    project_root = Path(context.existing_project_path).resolve()
    if not project_root.is_dir():
        raise ValueError(f"Project directory does not exist: {project_root}")
    repository_root = IsolatedBuildSession._find_repository_root(project_root)
    manifest_root = (
        repository_root
        if context.manifest and context.manifest.scope == ManifestScope.REPOSITORY
        else project_root
    )
    manifest_scope = context.manifest.scope.value if context.manifest else ManifestScope.PROJECT.value
    declared_paths = set(context.manifest.relative_paths().values())
    declared_paths.update(context.middleware_repair_paths)
    required_paths = set(context.manifest.compile_required_paths())
    generated_paths = set(context.generated_files)
    missing_required = sorted(required_paths - generated_paths)
    if missing_required:
        raise ValueError(f"Verified output is missing required files: {', '.join(missing_required)}")
    unexpected_paths = sorted(generated_paths - declared_paths)
    if unexpected_paths:
        raise ValueError(f"Verified output contains undeclared files: {', '.join(unexpected_paths)}")

    targets: list[_PublicationTarget] = []
    for relative_path, content in context.generated_files.items():
        targets.append(
            _target_from_text(
                root=manifest_root,
                relative_path=relative_path,
                content=content,
                scope=manifest_scope,
            )
        )
    for relative_path, content in context.project_metadata_files.items():
        targets.append(
            _target_from_text(
                root=project_root,
                relative_path=relative_path,
                content=content,
                scope="project_metadata",
            )
        )

    destinations = [item.destination for item in targets]
    if len(destinations) != len(set(destinations)):
        raise ValueError("Publication contains duplicate destination paths")
    return targets


def _target_from_text(*, root: Path, relative_path: str, content: str, scope: str) -> _PublicationTarget:
    normalized = Path(relative_path.replace("\\", "/"))
    if normalized.is_absolute() or not normalized.name or ".." in normalized.parts:
        raise ValueError(f"Unsafe publication path: {relative_path}")
    destination = (root / normalized).resolve()
    try:
        destination.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"Publication path escapes its root: {relative_path}") from exc
    if destination.exists() and not destination.is_file():
        raise ValueError(f"Publication destination is not a file: {destination}")
    existed = destination.is_file()
    return _PublicationTarget(
        relative_path=normalized.as_posix(),
        destination=destination,
        scope=scope,
        content=content.encode("utf-8"),
        existed=existed,
        original_content=destination.read_bytes() if existed else None,
        original_mode=destination.stat().st_mode if existed else None,
    )


def _commit_targets(targets: list[_PublicationTarget]) -> list[PublishedFile]:
    committed: list[_PublicationTarget] = []
    try:
        for target in targets:
            target.destination.parent.mkdir(parents=True, exist_ok=True)
            target.staged_path = _stage_bytes(target.destination, target.content)
        for target in targets:
            if target.staged_path is None:
                raise RuntimeError(f"Internal error: staged_path is None for {target.destination}")
            os.replace(target.staged_path, target.destination)
            target.staged_path = None
            committed.append(target)
            if target.original_mode is not None:
                os.chmod(target.destination, target.original_mode)
    except OSError as exc:
        rollback_errors = _rollback_targets(committed)
        _remove_staged_files(targets)
        rolled_back = not rollback_errors
        detail = f"Publication failed and changes were rolled back: {exc}"
        if rollback_errors:
            detail += f"; rollback errors: {'; '.join(rollback_errors)}"
        raise _PublicationFailure(detail, rolled_back=rolled_back) from exc
    finally:
        _remove_staged_files(targets)

    return [
        PublishedFile(
            relative_path=target.relative_path,
            absolute_path=str(target.destination),
            scope=target.scope,
            sha256=hashlib.sha256(target.content).hexdigest(),
            size=len(target.content),
            replaced=target.existed,
        )
        for target in targets
    ]


def _record_existing_targets(targets: list[_PublicationTarget]) -> list[PublishedFile]:
    evidence: list[PublishedFile] = []
    for target in targets:
        if not target.destination.is_file():
            raise ValueError(f"In-place delivery target is missing: {target.destination}")
        actual_content = target.destination.read_bytes()
        if not _text_content_matches(actual_content, target.content):
            raise ValueError(f"In-place delivery target differs from verified content: {target.destination}")
        evidence.append(
            PublishedFile(
                relative_path=target.relative_path,
                absolute_path=str(target.destination),
                scope=target.scope,
                sha256=hashlib.sha256(actual_content).hexdigest(),
                size=len(actual_content),
                replaced=target.existed,
            )
        )
    return evidence


def _text_content_matches(actual: bytes, expected: bytes) -> bool:
    """Compare generated text while tolerating platform newline translation.

    In-place builds write generated files through the normal text path before
    compilation. On Windows that may materialize LF input as CRLF bytes, while
    the verified context values are read back as normalized text. Treat those
    newline encodings as equivalent, but keep evidence hashes based on the
    actual bytes present in the delivered project.
    """

    if actual == expected:
        return True

    def normalize(payload: bytes) -> str:
        return payload.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")

    try:
        return normalize(actual) == normalize(expected)
    except UnicodeDecodeError:
        return False


def _rollback_targets(committed: list[_PublicationTarget]) -> list[str]:
    errors: list[str] = []
    for target in reversed(committed):
        staged: Path | None = None
        try:
            if target.existed:
                if target.original_content is None:
                    raise RuntimeError(f"Internal error: original_content is None for {target.destination}")
                staged = _stage_bytes(target.destination, target.original_content)
                os.replace(staged, target.destination)
                if target.original_mode is not None:
                    os.chmod(target.destination, target.original_mode)
            else:
                target.destination.unlink(missing_ok=True)
        except OSError as exc:
            errors.append(f"{target.destination}: {exc}")
        finally:
            if staged is not None:
                try:
                    staged.unlink(missing_ok=True)
                except OSError as exc:
                    errors.append(f"{target.destination}: restore staging cleanup failed: {exc}")
    return errors


def _stage_bytes(destination: Path, content: bytes) -> Path:
    descriptor, raw_path = tempfile.mkstemp(
        prefix=f".{destination.name}.driver-publish-",
        suffix=".tmp",
        dir=destination.parent,
    )
    staged = Path(raw_path)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
    except Exception:
        staged.unlink(missing_ok=True)
        raise
    return staged


def _remove_staged_files(targets: list[_PublicationTarget]) -> None:
    for target in targets:
        if target.staged_path is not None:
            target.staged_path.unlink(missing_ok=True)
            target.staged_path = None
