"""
@file validation.py
@author caoshwen
@brief Deterministic validation helpers for generated driver artifacts

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

import html
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from app.core.driver_storage import get_driver_temp_root

from app.core.driver_build_defaults import (
    DRIVER_C_LANGUAGE_STANDARD,
    STATIC_VALIDATION_COMPILER_CANDIDATES,
    STATIC_VALIDATION_FILENAME_MAX_CHARS,
    STATIC_VALIDATION_FORBIDDEN_FILENAME_CHARS,
    STATIC_VALIDATION_INCLUDE_DIR_LIMIT,
    STATIC_VALIDATION_LINE_LENGTH_LIMIT,
    STATIC_VALIDATION_PROJECT_FILE_SIZE_BYTES,
    STATIC_VALIDATION_STUB_HEADER_FILENAME,
    STATIC_VALIDATION_TIMEOUT_SECONDS,
)


@dataclass
class DriverValidationIssue:
    """A deterministic validation issue."""

    check: str
    severity: str
    message: str
    file: Optional[str] = None
    line: Optional[int] = None


@dataclass
class DriverValidationReport:
    """Validation report for generated driver artifacts."""

    syntax_ok: bool = True
    style_ok: bool = True
    interface_ok: bool = True
    self_test_ok: Optional[bool] = None
    issues: list[DriverValidationIssue] = field(default_factory=list)
    tool: Optional[str] = None
    command: Optional[str] = None
    output: str = ""
    syntax_checked: bool = False

    @property
    def success(self) -> bool:
        return (
            self.syntax_ok
            and self.style_ok
            and self.interface_ok
            and self.self_test_ok is not False
        )

    def add_issue(
        self,
        check: str,
        severity: str,
        message: str,
        file: str | None = None,
        line: int | None = None,
    ) -> None:
        self.issues.append(
            DriverValidationIssue(
                check=check,
                severity=severity,
                message=message,
                file=file,
                line=line,
            )
        )

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "syntax_ok": self.syntax_ok,
            "syntax_checked": self.syntax_checked,
            "style_ok": self.style_ok,
            "interface_ok": self.interface_ok,
            "self_test_ok": self.self_test_ok,
            "tool": self.tool,
            "command": self.command,
            "output": self.output,
            "issues": [issue.__dict__ for issue in self.issues],
        }

    def to_markdown(self) -> str:
        syntax_status = "PASS" if self.syntax_ok else "FAIL"
        if not self.syntax_checked and self.syntax_ok:
            syntax_status = "SKIPPED"
        lines = [
            "# Driver Validation Report",
            "",
            f"- Syntax: {syntax_status}",
            f"- Customer style: {'PASS' if self.style_ok else 'FAIL'}",
            f"- Interface consistency: {'PASS' if self.interface_ok else 'FAIL'}",
            (
                "- Self test: SKIPPED"
                if self.self_test_ok is None
                else f"- Self test: {'PASS' if self.self_test_ok else 'FAIL'}"
            ),
        ]
        if self.tool:
            lines.append(f"- Syntax tool: `{self.tool}`")
        if self.command:
            lines.append(f"- Command: `{self.command}`")
        if self.output:
            lines.extend([
                "",
                "## Tool Output",
                "",
                "```text",
                self.output,
                "```",
            ])
        if self.issues:
            lines.extend(["", "## Issues"])
            for issue in self.issues:
                loc = f" ({issue.file}:{issue.line})" if issue.file and issue.line else (
                    f" ({issue.file})" if issue.file else ""
                )
                lines.append(f"- [{issue.severity}] {issue.check}{loc}: {issue.message}")
        return "\n".join(lines) + "\n"


def validate_generated_driver(
    header_file: str,
    header_content: str,
    source_file: str,
    source_content: str,
    config_file: str | None = None,
    config_content: str | None = None,
    test_file: str | None = None,
    test_content: str | None = None,
    project_path: str | None = None,
    configuration: str | None = None,
) -> DriverValidationReport:
    """Run deterministic syntax/style/interface checks for generated driver files."""
    report = DriverValidationReport()
    project_style_context = bool(project_path)
    _check_customer_style(
        report, header_file, header_content, is_test=False,
        project_style_context=project_style_context,
    )
    _check_customer_style(
        report, source_file, source_content, is_test=False,
        project_style_context=project_style_context,
    )
    if config_file and config_content:
        _check_customer_style(
            report, config_file, config_content, is_test=False,
            project_style_context=project_style_context,
        )
    if test_file and test_content:
        _check_customer_style(
            report, test_file, test_content, is_test=True,
            project_style_context=project_style_context,
        )

    _check_interface_consistency(report, header_file, header_content, source_file, source_content)
    include_dirs = _collect_project_include_dirs(project_path, configuration)
    _check_c_syntax(
        report,
        header_file,
        header_content,
        source_file,
        source_content,
        config_file,
        config_content,
        include_dirs,
    )

    report.style_ok = not any(issue.check == "style" and issue.severity == "error" for issue in report.issues)
    report.interface_ok = not any(issue.check == "interface" and issue.severity == "error" for issue in report.issues)
    return report


def _check_customer_style(
    report: DriverValidationReport,
    file_name: str,
    content: str,
    is_test: bool,
    project_style_context: bool = False,
) -> None:
    if not content.strip():
        report.add_issue("style", "error", "Generated file is empty", file_name)
        return

    if not content.lstrip().startswith(("/**", "/*!")):
        report.add_issue("style", "warning", "Missing Doxygen-style file header", file_name)

    if "\t" in content:
        report.add_issue("style", "error", "Tabs are not allowed by customer style", file_name)

    for idx, line in enumerate(content.splitlines(), start=1):
        if line.rstrip() != line:
            report.add_issue("style", "warning", "Trailing whitespace", file_name, idx)
        if len(line) > STATIC_VALIDATION_LINE_LENGTH_LIMIT:
            report.add_issue(
                "style",
                "warning",
                f"Line exceeds {STATIC_VALIDATION_LINE_LENGTH_LIMIT} characters",
                file_name,
                idx,
            )

    if re.search(r"\b(malloc|calloc|realloc|free)\s*\(", content):
        report.add_issue("style", "error", "Dynamic heap allocation is not allowed in driver code", file_name)

    if re.search(r"\bcontroller[_-]", content, flags=re.IGNORECASE):
        report.add_issue("style", "error", "Driver layer must not depend on controller layer", file_name)

    if "TODO" in content or "PLACEHOLDER" in content:
        report.add_issue("style", "error", "Generated code must not contain TODO/PLACEHOLDER markers", file_name)

    if is_test and re.search(r"^\s*//", content, flags=re.MULTILINE):
        report.add_issue("style", "warning", "Test files should prefer Doxygen blocks over // comments", file_name)

    if (
        project_style_context
        and file_name.endswith(".c")
        and not re.search(r"\bhal_err_\w+|typedef\s+enum", content)
    ):
        report.add_issue(
            "style",
            "warning",
            "Source does not visibly use project-style hal_err_* or declare a module status enum",
            file_name,
        )

    if file_name.endswith((".c", ".h")) and re.search(r"\b[A-Z0-9_]+->\w+|[A-Z0-9_]+\s*=", content):
        if not re.search(r"\b(SET_BIT|CLEAR_BIT|READ_BIT|WRITE_REG|READ_REG|CLEAR_REG|MODIFY_REG)\b", content):
            report.add_issue(
                "style",
                "warning",
                "Register-style code should use project register access macros when applicable",
                file_name,
            )


def _check_interface_consistency(
    report: DriverValidationReport,
    header_file: str,
    header_content: str,
    source_file: str,
    source_content: str,
) -> None:
    guard = _expected_header_guard(header_file)
    if guard and guard not in header_content:
        report.add_issue("interface", "warning", f"Expected header guard token `{guard}` not found", header_file)

    declarations = _extract_function_declarations(header_content)
    definitions = _extract_function_definitions(source_content)

    for name in declarations:
        if name not in definitions and not name.startswith(("static",)):
            report.add_issue("interface", "error", f"Header declares `{name}` but source does not define it", source_file)

    own_include = header_file.replace("\\", "/").split("/")[-1]
    if own_include and f'"{own_include}"' not in source_content:
        report.add_issue("interface", "warning", f"Source does not include its own header `{own_include}`", source_file)


def _check_c_syntax(
    report: DriverValidationReport,
    header_file: str,
    header_content: str,
    source_file: str,
    source_content: str,
    config_file: str | None,
    config_content: str | None,
    include_dirs: list[Path] | None = None,
) -> None:
    compiler = _find_c_compiler()
    if compiler is None:
        report.syntax_ok = True
        report.tool = None
        report.add_issue("syntax", "warning", "No C compiler found; syntax-only validation skipped")
        return

    report.tool = compiler
    report.syntax_checked = True
    with tempfile.TemporaryDirectory(prefix="driver-syntax-", dir=get_driver_temp_root()) as tmp:
        tmp_dir = Path(tmp)
        try:
            safe_header = _safe_temp_filename(header_file)
            safe_source = _safe_temp_filename(source_file)
            safe_config = _safe_temp_filename(config_file) if config_file else None
        except ValueError as exc:
            report.syntax_ok = False
            report.add_issue("syntax", "error", str(exc), source_file)
            return

        (tmp_dir / safe_header).write_text(header_content, encoding="utf-8")
        (tmp_dir / safe_source).write_text(source_content, encoding="utf-8")
        if safe_config and config_content:
            (tmp_dir / safe_config).write_text(config_content, encoding="utf-8")

        missing_includes = _write_missing_local_include_stubs(
            tmp_dir,
            [header_content, source_content, config_content or ""],
            include_dirs or [],
        )
        stub = tmp_dir / STATIC_VALIDATION_STUB_HEADER_FILENAME
        stub.write_text(_syntax_stub_header(missing_includes), encoding="utf-8")

        cmd = [
            compiler,
            "-x",
            "c",
            f"-std={DRIVER_C_LANGUAGE_STANDARD}",
            "-fsyntax-only",
            "-include",
            str(stub),
            "-I",
            str(tmp_dir),
        ]
        for include_dir in include_dirs or []:
            cmd.extend(["-I", str(include_dir)])
        cmd.append(str(tmp_dir / safe_source))
        report.command = " ".join(cmd)
        try:
            completed = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=STATIC_VALIDATION_TIMEOUT_SECONDS,
            )
            report.output = (completed.stdout or "") + (completed.stderr or "")
            if completed.returncode != 0:
                report.syntax_ok = False
                report.add_issue("syntax", "error", "C syntax check failed", source_file)
        except Exception as exc:
            report.syntax_ok = False
            report.output = str(exc)
            report.add_issue("syntax", "error", f"C syntax check could not run: {exc}", source_file)


def normalize_generated_bitfield_comparisons(
    header_content: str,
    source_content: str,
) -> str:
    """Normalize proven register-mask comparisons to field-value comparisons."""
    macros: dict[str, int] = {}
    mask_specs: dict[str, tuple[str, int, int]] = {}
    macro_pattern = re.compile(
        r"^\s*#define\s+(?P<name>[A-Za-z_]\w*)\s+(?P<body>[^\r\n]+)$",
        re.MULTILINE,
    )
    mask_pattern = re.compile(
        r"^\(?\s*(?P<field>0[xX][0-9A-Fa-f]+|\d+)[uUlL]*\s*<<\s*"
        r"(?P<shift>[A-Za-z_]\w*)\s*\)?$"
    )

    for match in macro_pattern.finditer(header_content):
        name = match.group("name")
        body = match.group("body").split("//", 1)[0].strip()
        value = _parse_c_integer(body)
        if value is not None:
            macros[name] = value
            continue
        mask_match = mask_pattern.fullmatch(body)
        if mask_match:
            field_value = _parse_c_integer(mask_match.group("field"))
            shift_value = macros.get(mask_match.group("shift"))
            if field_value is not None and shift_value is not None and shift_value > 0:
                mask_specs[name] = (
                    mask_match.group("shift"),
                    shift_value,
                    field_value,
                )

    for match in macro_pattern.finditer(header_content):
        name = match.group("name")
        body = match.group("body").split("//", 1)[0].strip()
        mask_match = mask_pattern.fullmatch(body)
        if not mask_match:
            continue
        field_value = _parse_c_integer(mask_match.group("field"))
        shift_value = macros.get(mask_match.group("shift"))
        if field_value is not None and shift_value is not None and shift_value > 0:
            mask_specs[name] = (mask_match.group("shift"), shift_value, field_value)

    normalized = source_content
    for mask_name, (shift_name, _shift_value, field_max) in mask_specs.items():
        expression = re.compile(
            rf"\(\s*(?P<lhs>[A-Za-z_]\w*)\s*&\s*{re.escape(mask_name)}\s*\)"
            rf"\s*(?P<operator>==|!=)\s*"
            rf"(?P<rhs>[A-Za-z_]\w*|0[xX][0-9A-Fa-f]+[uUlL]*|\d+[uUlL]*)"
        )

        def replace(
            match: re.Match[str],
            *,
            current_mask: str = mask_name,
            current_shift: str = shift_name,
            current_field_max: int = field_max,
        ) -> str:
            rhs = match.group("rhs")
            rhs_value = macros.get(rhs) if re.match(r"[A-Za-z_]", rhs) else _parse_c_integer(rhs)
            if rhs_value is None or rhs_value < 0 or rhs_value > current_field_max:
                return match.group(0)
            return (
                f"(({match.group('lhs')} & {current_mask}) >> {current_shift}) "
                f"{match.group('operator')} {rhs}"
            )

        normalized = expression.sub(replace, normalized)
    return normalized


def _parse_c_integer(value: str) -> int | None:
    normalized = value.strip()
    while normalized.startswith("(") and normalized.endswith(")"):
        normalized = normalized[1:-1].strip()
    normalized = re.sub(r"[uUlL]+$", "", normalized)
    try:
        return int(normalized, 0)
    except ValueError:
        return None


def _find_c_compiler() -> str | None:
    for candidate in STATIC_VALIDATION_COMPILER_CANDIDATES:
        path = shutil.which(candidate)
        if path:
            return path
    return None


def _safe_temp_filename(file_name: str | None) -> str:
    normalized = str(file_name or "").replace("\\", "/")
    name = normalized.split("/")[-1]
    if (
        not name
        or name in {".", ".."}
        or name != normalized
        or "\x00" in name
        or any(char in name for char in STATIC_VALIDATION_FORBIDDEN_FILENAME_CHARS)
        or len(name) > STATIC_VALIDATION_FILENAME_MAX_CHARS
    ):
        raise ValueError(f"Unsafe generated filename: {file_name}")
    return name


def _expected_header_guard(file_name: str) -> str:
    base = file_name.replace("\\", "/").split("/")[-1]
    token = re.sub(r"[^A-Za-z0-9]", "_", base).upper()
    return token if token else ""


def _extract_function_declarations(header_content: str) -> set[str]:
    names: set[str] = set()
    pattern = re.compile(
        r"^\s*(?:extern\s+)?(?:[A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*;",
        re.MULTILINE,
    )
    for match in pattern.finditer(_strip_comments(header_content)):
        if re.match(r"\s*typedef\b", match.group(0)):
            continue
        name = match.group(1)
        if name not in {"if", "for", "while", "switch"}:
            names.add(name)
    return names


def _extract_function_definitions(source_content: str) -> set[str]:
    names: set[str] = set()
    pattern = re.compile(
        r"^\s*(?:static\s+)?(?:[A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{",
        re.MULTILINE,
    )
    for match in pattern.finditer(_strip_comments(source_content)):
        name = match.group(1)
        if name not in {"if", "for", "while", "switch"}:
            names.add(name)
    return names


def _strip_comments(content: str) -> str:
    content = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)
    content = re.sub(r"//.*", "", content)
    return content


def _collect_project_include_dirs(
    project_path: str | None,
    configuration: str | None,
) -> list[Path]:
    """
    Collect include directories from project .cproject file for the given configuration.

    Args:
        project_path: Path to the Eclipse CDT project directory
        configuration: Build configuration name (e.g. "Debug", "Release")

    Returns:
        List of absolute include directory paths, empty if project not found or parsing fails
    """
    if not project_path or not configuration:
        return []

    try:
        project_dir = Path(project_path).resolve()
    except OSError:
        return []
    if not project_dir.is_dir():
        return []

    cproject_file = project_dir / ".cproject"
    if not cproject_file.is_file():
        return []

    try:
        if cproject_file.stat().st_size > STATIC_VALIDATION_PROJECT_FILE_SIZE_BYTES:
            return []
        tree = ET.parse(cproject_file)
        root = tree.getroot()

        include_paths: list[Path] = []
        from .build.stm32.headless_executor import STM32HeadlessBuildExecutor

        configuration = STM32HeadlessBuildExecutor.resolve_build_configuration(
            project_dir, configuration,
        )

        # Find configuration matching the requested name
        for config in root.findall(".//configuration"):
            config_name = config.get("name", "")
            if configuration.casefold() != config_name.casefold():
                continue

            # Extract include paths from toolchain settings
            for option in config.findall(".//option"):
                option_id = option.get("id", "")
                # Common Eclipse CDT include path option patterns
                if "include.paths" in option_id.lower() or "includepath" in option_id.lower():
                    for list_option_value in option.findall(".//listOptionValue"):
                        raw_value = list_option_value.get("value", "")
                        if raw_value:
                            # Unescape HTML entities
                            unescaped = html.unescape(raw_value)
                            # Resolve workspace-relative paths (remove workspace macros)
                            resolved = _resolve_workspace_path(
                                unescaped, project_dir, configuration=configuration,
                            )
                            if resolved:
                                include_paths.append(resolved)
                                if len(include_paths) >= STATIC_VALIDATION_INCLUDE_DIR_LIMIT:
                                    return include_paths

        return include_paths

    except (ET.ParseError, OSError, ValueError):
        # Silently return empty list on parse errors - validation can proceed without project includes
        return []


def _resolve_workspace_path(
    path_str: str, project_dir: Path, configuration: str | None = None,
) -> Path | None:
    """
    Resolve workspace-relative or project-relative path macros.

    Args:
        path_str: Raw path string from .cproject (may contain Eclipse macros)
        project_dir: Absolute path to project directory

    Returns:
        Resolved absolute path, or None if path is invalid
    """
    # Remove common Eclipse CDT path macros
    cleaned = path_str.strip().strip('"')

    # Handle workspace-relative paths: ${workspace_loc:/ProjectName/path}
    workspace_match = re.match(r'\$\{workspace_loc:/[^/]+/(.+)\}', cleaned)
    if workspace_match:
        relative_path = workspace_match.group(1)
        resolved = project_dir / relative_path
        return _safe_existing_project_dir(resolved, project_dir)

    # Handle project-relative paths: ${workspace_loc}/../path or ../path
    cleaned = re.sub(r'\$\{workspace_loc\}/?', '', cleaned)
    cleaned = re.sub(r'\$\{ProjDirPath\}/?', '', cleaned)

    # Try as relative path from project directory
    if not Path(cleaned).is_absolute():
        if configuration:
            resolved = _safe_existing_project_dir(project_dir / configuration / cleaned, project_dir)
            if resolved:
                return resolved
        return _safe_existing_project_dir(project_dir / cleaned, project_dir)
    else:
        return _safe_existing_project_dir(Path(cleaned), project_dir)

    return None


def _safe_existing_project_dir(candidate: Path, project_dir: Path) -> Path | None:
    try:
        resolved = candidate.resolve()
        project_root = project_dir.resolve()
        project_root = next(
            (parent for parent in (project_root, *project_root.parents) if (parent / ".git").exists()),
            project_root,
        )
    except OSError:
        return None
    if not resolved.is_dir():
        return None
    try:
        resolved.relative_to(project_root)
    except ValueError:
        return None
    return resolved


def _write_missing_local_include_stubs(
    tmp_dir: Path,
    contents: list[str],
    include_dirs: list[Path],
) -> set[str]:
    """Create temporary placeholders only for unresolved quoted includes."""
    include_names = {
        match.group(1).strip().replace("\\", "/")
        for content in contents
        for match in re.finditer(r'^\s*#\s*include\s*"([^"]+)"', content, flags=re.MULTILINE)
    }
    missing: set[str] = set()
    for include_name in sorted(include_names):
        relative = Path(include_name)
        if (
            not include_name
            or relative.is_absolute()
            or ".." in relative.parts
            or "\x00" in include_name
            or len(include_name) > STATIC_VALIDATION_FILENAME_MAX_CHARS
        ):
            continue
        if (tmp_dir / relative).is_file():
            continue
        if any((include_dir / relative).is_file() for include_dir in include_dirs):
            continue
        destination = tmp_dir / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(
            f'#include "{STATIC_VALIDATION_STUB_HEADER_FILENAME}"\n',
            encoding="utf-8",
        )
        missing.add(include_name.lower())
    return missing


def _syntax_stub_header(missing_includes: set[str] | None = None) -> str:
    missing = missing_includes or set()
    hal_api_stubs: list[str] = []
    if "hal-gpio.h" in missing:
        hal_api_stubs.append(
            """
typedef struct {
    int32_t (*initialize)();
    int32_t (*deinitialize)();
    int32_t (*writegpio)();
    int32_t (*readgpio)();
} driver_validation_hal_gpio_api_t;
extern driver_validation_hal_gpio_api_t hal_gpio;
#ifndef gpio_value_reset
#define gpio_value_reset 0
#endif
#ifndef gpio_value_set
#define gpio_value_set 1
#endif
"""
        )
    if "hal-i2c.h" in missing:
        hal_api_stubs.append(
            """
typedef struct {
    int32_t (*initialize)();
    int32_t (*deinitialize)();
    int32_t (*memwrite)();
    int32_t (*memread)();
} driver_validation_hal_i2c_api_t;
extern driver_validation_hal_i2c_api_t hal_i2c;
#ifndef I2C_MEMADD_SIZE_8BIT
#define I2C_MEMADD_SIZE_8BIT 1U
#endif
"""
        )
    return """
#ifndef DRIVER_VALIDATION_STUBS_H
#define DRIVER_VALIDATION_STUBS_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef uint32_t HAL_StatusTypeDef;
#ifndef SET_BIT
#define SET_BIT(REG, BIT) ((REG) |= (BIT))
#endif
#ifndef CLEAR_BIT
#define CLEAR_BIT(REG, BIT) ((REG) &= ~(BIT))
#endif
#ifndef READ_BIT
#define READ_BIT(REG, BIT) ((REG) & (BIT))
#endif
#ifndef WRITE_REG
#define WRITE_REG(REG, VAL) ((REG) = (VAL))
#endif
#ifndef READ_REG
#define READ_REG(REG) (REG)
#endif
#ifndef CLEAR_REG
#define CLEAR_REG(REG) ((REG) = 0U)
#endif
#ifndef MODIFY_REG
#define MODIFY_REG(REG, CLEARMASK, SETMASK) WRITE_REG((REG), (((READ_REG(REG)) & (~(CLEARMASK))) | (SETMASK)))
#endif
""" + "".join(hal_api_stubs) + """
#endif
"""
