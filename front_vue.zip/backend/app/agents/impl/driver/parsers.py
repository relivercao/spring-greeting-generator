"""
@file parsers.py
@author caoshwen
@brief Build diagnostic parsing utilities for compiler and linker output

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
import re
import hashlib
from typing import List, Dict
from pathlib import Path

from app.core.driver_build_defaults import (
    DEFAULT_CRITICAL_DIAGNOSTIC_LIMIT,
    DEFAULT_DIAGNOSTIC_CONTEXT_LINES,
    DIAGNOSTIC_FINGERPRINT_LENGTH,
    HEADER_DIAGNOSTIC_PRIORITY_LIMIT,
)

from .types import BuildError, ErrorPattern


_GCC_DIAGNOSTIC = re.compile(
    r"^(.*?):(\d+)(?::(\d+))?:\s+(fatal error|error|warning|note):\s+(.+)$",
    re.IGNORECASE,
)


def _fingerprint(phase: str, category: str, file_path: str, message: str) -> str:
    normalized = re.sub(r"\s+", " ", message.strip().lower())
    payload = f"{phase}|{category}|{file_path.lower()}|{normalized}"
    return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[
        :DIAGNOSTIC_FINGERPRINT_LENGTH
    ]


def create_build_diagnostic(
    *,
    message: str,
    raw_message: str,
    phase: str,
    category: str,
    tool: str,
    file_path: str = "",
    line: int = 0,
    column: int = 0,
    severity: str = "error",
    symbol: str | None = None,
    repairable: bool = False,
) -> BuildError:
    return BuildError(
        file=file_path,
        line=line,
        column=column,
        message=message,
        error_type=severity,
        pattern=extract_error_pattern(message),
        phase=phase,
        category=category,
        tool=tool,
        symbol=symbol,
        raw_message=raw_message,
        is_repairable=repairable,
        fingerprint=_fingerprint(phase, category, file_path, message),
    )


def _parse_generic_line(line: str) -> BuildError | None:
    raw = line.strip()
    if not raw:
        return None

    gcc_match = _GCC_DIAGNOSTIC.match(raw)
    if gcc_match:
        file_path, line_str, column, severity, message = gcc_match.groups()
        severity = severity.lower()
        category = "missing_header" if severity == "fatal error" and "no such file" in message.lower() else "syntax"
        return create_build_diagnostic(
            message=message,
            raw_message=raw,
            phase="compile",
            category=category,
            tool="gcc",
            file_path=file_path,
            line=int(line_str),
            column=int(column or 0),
            severity="error" if severity in {"error", "fatal error"} else severity,
            repairable=severity in {"error", "fatal error", "warning"},
        )

    linker_patterns = [
        (r"undefined reference to\s+[`']([^`']+)[`']", "undefined_symbol", True),
        (r"multiple definition of\s+[`']([^`']+)[`']", "duplicate_symbol", True),
        (r"region\s+[`']([^`']+)[`']\s+overflowed by", "memory_overflow", False),
        (r"cannot find\s+-l(\S+)", "missing_library", False),
    ]
    for pattern, category, repairable in linker_patterns:
        match = re.search(pattern, raw, re.IGNORECASE)
        if match:
            return create_build_diagnostic(
                message=raw,
                raw_message=raw,
                phase="link",
                category=category,
                tool="ld",
                symbol=match.group(1),
                repairable=repairable,
            )
    if re.search(r"(?:collect2(?:\.exe)?|ld(?:\.exe)?).*returned?\s+1 exit status", raw, re.IGNORECASE):
        return create_build_diagnostic(
            message=raw,
            raw_message=raw,
            phase="link",
            category="link_failed",
            tool="ld",
        )

    if re.search(r"no rule to make target", raw, re.IGNORECASE):
        return create_build_diagnostic(
            message=raw,
            raw_message=raw,
            phase="make",
            category="missing_target",
            tool="make",
        )
    if re.search(r"(?:^|\s)make(?:\[\d+\])?:\s+\*\*\*.*Error\s+\d+", raw, re.IGNORECASE):
        return create_build_diagnostic(
            message=raw,
            raw_message=raw,
            phase="make",
            category="make_failed",
            tool="make",
        )
    return None


def parse_build_diagnostics(output: str) -> List[BuildError]:
    """Parse platform-neutral GCC, linker, and Make diagnostics."""
    diagnostics: List[BuildError] = []
    seen: set[str] = set()
    for line in output.splitlines():
        diagnostic = _parse_generic_line(line)
        if diagnostic and diagnostic.fingerprint not in seen:
            diagnostics.append(diagnostic)
            seen.add(diagnostic.fingerprint)
    return diagnostics


def parse_build_errors(output: str) -> List[BuildError]:
    """Parse errors emitted by platform-neutral GCC, linker, and Make tools."""
    return [item for item in parse_build_diagnostics(output) if item.error_type == "error"]


def parse_build_warnings(output: str) -> List[BuildError]:
    """Parse warnings emitted by platform-neutral GCC, linker, and Make tools."""
    return [item for item in parse_build_diagnostics(output) if item.error_type == "warning"]


def extract_error_pattern(message: str) -> ErrorPattern:
    """
    Extract error pattern from error message

    Examples:
    - "'HAL_GPIO_Init' undeclared" -> UNDECLARED_IDENTIFIER
    - "unknown type name 'GPIO_TypeDef'" -> UNKNOWN_TYPE
    """
    message_lower = message.lower()

    # Pattern matching rules
    patterns = [
        (r"undeclared|not declared", ErrorPattern.UNDECLARED_IDENTIFIER),
        (r"unknown type name", ErrorPattern.UNKNOWN_TYPE),
        (r"implicit declaration of function", ErrorPattern.IMPLICIT_FUNCTION),
        (r"expected .+ before|syntax error", ErrorPattern.SYNTAX_ERROR),
        (r"incompatible type|type mismatch", ErrorPattern.TYPE_MISMATCH),
        (r"undefined reference", ErrorPattern.LINKER_ERROR),
    ]

    for pattern_regex, pattern_type in patterns:
        if re.search(pattern_regex, message_lower):
            return pattern_type

    return ErrorPattern.OTHER


def group_errors_by_pattern(errors: List[BuildError]) -> Dict[str, dict]:
    """
    Group errors by pattern

    Returns:
    {
        'undeclared_identifier': {
            'pattern': "'HAL_GPIO_Init' undeclared",
            'count': 3,
            'locations': ['driver.c:45', 'driver.c:67', 'driver.c:89']
        }
    }
    """
    grouped = {}

    for error in errors:
        pattern_key = error.pattern.value if error.pattern else 'other'

        if pattern_key not in grouped:
            grouped[pattern_key] = {
                'pattern': error.message,
                'count': 0,
                'locations': [],
                'example_message': error.message
            }

        grouped[pattern_key]['count'] += 1
        grouped[pattern_key]['locations'].append(f"{error.file}:{error.line}")

    return grouped


def select_critical_errors(
    errors: List[BuildError],
    max_count: int = DEFAULT_CRITICAL_DIAGNOSTIC_LIMIT
) -> List[BuildError]:
    """
    Select most critical errors

    Priority:
    1. error > warning
    2. Header file errors > source file errors (wider impact)
    3. New error types > duplicate errors
    """
    critical_errors = []
    critical_errors_set = set()

    # 1. Header file errors (global impact)
    header_errors = [e for e in errors if '.h' in e.file]
    for error in header_errors[:HEADER_DIAGNOSTIC_PRIORITY_LIMIT]:
        critical_errors.append(error)
        critical_errors_set.add(id(error))

    # 2. New error types (deduplicate by pattern)
    seen_patterns = set()
    for error in errors:
        if id(error) not in critical_errors_set:
            pattern = error.pattern.value if error.pattern else 'other'
            if pattern not in seen_patterns:
                critical_errors.append(error)
                critical_errors_set.add(id(error))
                seen_patterns.add(pattern)
                if len(critical_errors) >= max_count:
                    break

    # 3. Fill with other errors
    for error in errors:
        if id(error) not in critical_errors_set:
            critical_errors.append(error)
            critical_errors_set.add(id(error))
            if len(critical_errors) >= max_count:
                break

    return critical_errors[:max_count]


def extract_error_context(
    file_path: str,
    line_num: int,
    context_lines: int = DEFAULT_DIAGNOSTIC_CONTEXT_LINES
) -> str:
    """
    Extract error context code

    Return format:
        42: void init_gpio(void) {
        43:     GPIO_InitTypeDef gpio_init;
        44:     gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
    >>> 45:     HAL_GPIO_Init(GPIOA, &gpio_init);  # Error line
        46:     return;
        47: }
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        start = max(0, line_num - context_lines - 1)
        end = min(len(lines), line_num + context_lines)

        context = []
        for i in range(start, end):
            prefix = ">>> " if i == line_num - 1 else "    "
            context.append(f"{prefix}{i+1}: {lines[i].rstrip()}")

        return '\n'.join(context)
    except Exception:
        return ""


def fill_error_contexts(errors: List[BuildError]) -> List[BuildError]:
    """Fill error list with context"""
    for error in errors:
        if not error.context:
            error.context = extract_error_context(error.file, error.line)
    return errors
