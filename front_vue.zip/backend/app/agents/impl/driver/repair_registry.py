"""
@file repair_registry.py
@author caoshwen
@brief Compile repairer registry for platform-specific repair flows

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from collections.abc import Callable

from app.utils.claude_cli_monitor import ClaudeCliMonitor

from .build.registry import normalize_build_platform
from .repairer import CompileRepairer, ClaudeCliRepairer


RepairerFactory = Callable[[ClaudeCliMonitor | None], CompileRepairer]


class CompileRepairerRegistry:
    """Resolve optional platform overrides with a platform-neutral default."""

    def __init__(self, default_factory: RepairerFactory | None = None):
        self._default_factory = default_factory
        self._factories: dict[str, RepairerFactory] = {}

    def register(self, platform: str, factory: RepairerFactory) -> None:
        self._factories[normalize_build_platform(platform)] = factory

    def create(
        self,
        platform: str | None,
        monitor: ClaudeCliMonitor | None = None,
    ) -> CompileRepairer:
        canonical = normalize_build_platform(platform)
        factory = self._factories.get(canonical, self._default_factory)
        if factory is None:
            raise ValueError(
                f"No compile repairer is registered for platform '{canonical}' "
                "and no default repairer is configured"
            )
        return factory(monitor)


def _create_claude_repairer(monitor: ClaudeCliMonitor | None) -> CompileRepairer:
    return ClaudeCliRepairer(monitor=monitor)


compile_repairer_registry = CompileRepairerRegistry(_create_claude_repairer)
