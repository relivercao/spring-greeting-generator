"""Driver contract extraction and validation data structures."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


MAX_PROJECT_METADATA_CHARS = 2_000_000


@dataclass
class DriverContract:
    """Machine-readable contract used to guide and validate driver generation."""

    device_name: str = ""
    interface: str = ""
    required_files: list[str] = field(default_factory=list)
    public_functions: list[str] = field(default_factory=list)
    reference_public_functions: list[str] = field(default_factory=list)
    private_functions: list[str] = field(default_factory=list)
    function_table_members: list[str] = field(default_factory=list)
    logical_led_count: int | None = None
    channel_mapping: list[int] = field(default_factory=list)
    brightness_range: list[int] = field(default_factory=list)
    current_limits_ma: dict[str, int] = field(default_factory=dict)
    sws_configuration: str = ""
    instance_type: str = ""
    instance_fields: list[str] = field(default_factory=list)
    function_table_type: str = ""
    export_symbol: str = ""
    required_includes: list[str] = field(default_factory=list)
    hardware_facts: dict[str, Any] = field(default_factory=dict)
    prompt_facts: dict[str, Any] = field(default_factory=dict)
    generation_prompt: str = ""
    fact_extraction_status: str = "pending_cli_extraction"
    input_roles: dict[str, list[str]] = field(default_factory=dict)
    target_project_path: str = ""
    upper_layer_owns: list[str] = field(default_factory=list)
    evidence: list[Any] = field(default_factory=list)
    ambiguities: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def collect_reference_evidence(reference_files: list[dict[str, str]]) -> DriverContract:
    """Record reference files without treating their implementation as a contract.

    Reference C/H files are implementation examples for the CLI. Their symbols
    and function-table members are intentionally not promoted into required
    capabilities because a reference device can expose a different API.
    """
    contract = DriverContract()
    for item in reference_files:
        path = item.get("path", "")
        content = item.get("content", "")
        if not content:
            continue
        contract.evidence.append(path)
    return contract


def classify_driver_inputs(source_files: list[dict[str, str]]) -> dict[str, list[str]]:
    """Classify uploaded inputs by authority instead of treating them as peers."""
    roles: dict[str, list[str]] = {
        "software_reference": [],
        "target_datasheet": [],
        "project_contract": [],
        "project_build": [],
        "other": [],
    }
    project_build_names = {".project", ".cproject", "makefile"}
    source_suffixes = {".c", ".cc", ".cpp", ".cxx"}
    header_suffixes = {".h", ".hh", ".hpp", ".hxx"}
    code_suffixes = source_suffixes | header_suffixes
    for item in source_files:
        name = str(item.get("name") or item.get("path") or "").replace("\\", "/")
        basename = Path(name).name.lower()
        suffix = Path(basename).suffix.lower()
        source_type = str(item.get("source_type") or "").strip().lower()
        origin = str(item.get("origin") or "").strip().lower()
        if basename in project_build_names or basename.endswith((".mk", ".make")):
            role = "project_build"
        elif source_type == "reference":
            role = "software_reference" if suffix in code_suffixes else "other"
        elif source_type == "knowledge_base":
            role = "target_datasheet" if suffix not in code_suffixes else "other"
        elif origin == "uploaded" and suffix in code_suffixes:
            role = "software_reference"
        else:
            role = "other"
        roles[role].append(name)
    return roles


def resolve_target_project_path(ctx: Any) -> Path | None:
    """Resolve a server-local target project directory from the request context."""
    raw_path = str((ctx.module_config or {}).get("project_path") or "").strip()
    if not raw_path:
        return None
    try:
        project_path = Path(raw_path).resolve(strict=True)
    except (OSError, RuntimeError):
        return None
    return project_path if project_path.is_dir() else None


def _load_target_project_metadata(project_path: Path | None) -> list[dict[str, str]]:
    """Load bounded build metadata from the selected target project directory."""
    if project_path is None:
        return []
    files: list[dict[str, str]] = []
    for name in (".project", ".cproject", "Makefile"):
        path = project_path / name
        try:
            if not path.is_file() or path.stat().st_size > MAX_PROJECT_METADATA_CHARS:
                continue
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        files.append({"name": str(path), "path": str(path), "content": content})
    return files


def build_driver_contract(ctx: Any) -> DriverContract:
    """Build a target contract from request configuration and repository evidence."""
    config = ctx.module_config or {}
    uploaded_files = [
        {
            "name": item.get("name", "source"),
            "path": item.get("name", "source"),
            "content": item.get("content", ""),
            "source_type": item.get("source_type", ""),
            "origin": "uploaded",
        }
        for item in (ctx.source_contents or [])
    ]
    repository_files = [
        {
            "name": item.get("path", "repository-file"),
            "path": item.get("path", "repository-file"),
            "content": item.get("content", ""),
            "origin": "repository",
        }
        for item in (ctx.repo_files or [])
    ]
    target_project_path = resolve_target_project_path(ctx)
    project_metadata_files = _load_target_project_metadata(target_project_path)
    all_files = [*uploaded_files, *repository_files, *project_metadata_files]
    input_roles = classify_driver_inputs(all_files)
    software_paths = set(input_roles["software_reference"])
    reference_files = [item for item in all_files if item["name"] in software_paths]
    contract = collect_reference_evidence(reference_files)
    contract.device_name = ctx.device_name
    contract.interface = ctx.interface
    contract.public_functions = list(dict.fromkeys(config.get("required_capabilities") or []))
    contract.input_roles = input_roles
    contract.target_project_path = str(target_project_path) if target_project_path else ""
    contract.generation_prompt = str(getattr(ctx, "prompt", "") or "")
    return contract
