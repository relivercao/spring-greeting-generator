"""
@file types.py
@author caoshwen
@brief Driver agent type definitions

@version 1.0
@date 2026-07-21

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, List, Dict
from enum import Enum
from datetime import datetime
from pathlib import Path

from app.agents.base import AgentContext, AgentResult
from app.core.driver_build_defaults import (
    COMPARISON_HISTORY_WINDOW,
    DEFAULT_BASELINE_FAIL_FAST,
    DEFAULT_BUILD_ACTIVITY_TIMEOUT,
    DEFAULT_BUILD_JOBS,
    DEFAULT_CLEAN_BUILD,
    DEFAULT_DRIVER_BUILD_CONFIGURATION,
    DEFAULT_DRIVER_BUILD_TIMEOUT_SECONDS,
    DEFAULT_DRIVER_COMPILE_ATTEMPTS,
    DEFAULT_DRIVER_HEADER_DIRECTORY,
    DEFAULT_DRIVER_SOURCE_DIRECTORY,
    DEFAULT_INFRASTRUCTURE_RETRIES,
    DEFAULT_STRICT_CONFIGURATION,
    DRIVER_COMPILE_PROGRESS_START,
    DRIVER_MANIFEST_DIR_MAX_CHARS,
    DRIVER_MANIFEST_FILENAME_MAX_CHARS,
    MAX_BUILD_JOBS,
    MAX_DRIVER_COMPILE_ATTEMPTS,
    MAX_DRIVER_BUILD_TIMEOUT_SECONDS,
    MIN_BUILD_ACTIVITY_TIMEOUT,
    MIN_BUILD_JOBS,
    MIN_DRIVER_BUILD_TIMEOUT_SECONDS,
    MIN_DRIVER_COMPILE_ATTEMPTS,
    MIN_INFRASTRUCTURE_RETRIES,
    SLOWING_PROGRESS_THRESHOLD,
    SLOWING_PROGRESS_WINDOW,
)


# ========== Driver Domain Types ==========


class ManifestScope(str, Enum):
    """Base directory used to resolve generated file manifest paths."""

    PROJECT = "project"
    REPOSITORY = "repository"

@dataclass
class DriverContext(AgentContext):
    """Driver generation context"""
    device_name: str = ""
    device_type: str = ""           # sensor / actuator / communication
    interface: str = ""             # i2c / spi / uart / gpio
    mcu_family: str = ""
    registers: list[dict[str, Any]] = field(default_factory=list)
    platform: Optional[str] = None
    datasheet_content: Optional[str] = None
    # Extended fields for multi-turn pipeline
    prompt: Optional[str] = None
    source_ids: list[str] = field(default_factory=list)
    source_contents: list[dict[str, Any]] = field(default_factory=list)
    repository_source_id: Optional[str] = None
    repo_files: list[dict[str, str]] = field(default_factory=list)
    output_options: Optional[dict[str, Any]] = None
    module_config: Optional[dict[str, Any]] = None
    cli_session_id: str = ""


@dataclass
class FileManifest:
    """File manifest for generated driver files (P0 Task 4)"""
    header_filename: str                    # e.g., "drv_bq25620.h"
    source_filename: str                    # e.g., "drv_bq25620.c"
    config_filename: Optional[str] = None   # e.g., "drv_bq25620_config.h"
    test_filename: Optional[str] = None     # e.g., "drv_bq25620_test.c"
    target_inc_dir: str = DEFAULT_DRIVER_HEADER_DIRECTORY
    target_src_dir: str = DEFAULT_DRIVER_SOURCE_DIRECTORY
    scope: ManifestScope = ManifestScope.PROJECT

    def __post_init__(self) -> None:
        self.target_inc_dir = self._validate_relative_dir(self.target_inc_dir, "target_inc_dir")
        self.target_src_dir = self._validate_relative_dir(self.target_src_dir, "target_src_dir")
        self.header_filename = self._validate_filename(self.header_filename, "header_filename")
        self.source_filename = self._validate_filename(self.source_filename, "source_filename")
        if self.config_filename is not None:
            self.config_filename = self._validate_filename(self.config_filename, "config_filename")
        if self.test_filename is not None:
            self.test_filename = self._validate_filename(self.test_filename, "test_filename")

    @staticmethod
    def _validate_relative_dir(path: str, field_name: str) -> str:
        normalized = str(path or "").strip().replace("\\", "/")
        parts = normalized.split("/")
        if (
            not normalized
            or "\x00" in normalized
            or normalized.startswith("/")
            or (len(normalized) >= 2 and normalized[1] == ":")
            or len(normalized) > DRIVER_MANIFEST_DIR_MAX_CHARS
            or any(part in {"", ".", ".."} for part in parts)
        ):
            raise ValueError(f"{field_name} must be a safe relative directory")
        return "/".join(parts)

    @staticmethod
    def _validate_filename(filename: str, field_name: str) -> str:
        normalized = str(filename or "").replace("\\", "/")
        name = normalized.split("/")[-1]
        if (
            not name
            or name in {".", ".."}
            or name != normalized
            or "\x00" in name
            or ":" in name
            or len(name) > DRIVER_MANIFEST_FILENAME_MAX_CHARS
        ):
            raise ValueError(f"{field_name} must be a safe filename")
        return name

    def relative_paths(self) -> Dict[str, str]:
        """Return generated file roles mapped to manifest-scope-relative paths."""
        paths = {
            "header": str(Path(self.target_inc_dir) / self.header_filename),
            "source": str(Path(self.target_src_dir) / self.source_filename),
        }
        if self.config_filename:
            paths["config"] = str(Path(self.target_inc_dir) / self.config_filename)
        if self.test_filename:
            paths["test"] = str(Path(self.target_src_dir) / self.test_filename)
        return {role: path.replace("\\", "/") for role, path in paths.items()}

    def compile_required_paths(self) -> list[str]:
        """Return manifest paths that must be proven compiled."""
        return [self.relative_paths()["source"]]


@dataclass
class GeneratedDriver:
    """Generated driver code"""
    header_file: str
    header_content: str
    source_file: str
    source_content: str
    config_file: Optional[str] = None
    config_content: Optional[str] = None
    test_file: Optional[str] = None
    test_content: Optional[str] = None
    doc_file: Optional[str] = None
    doc_content: Optional[str] = None
    manifest: Optional[FileManifest] = None  # P0 Task 4: File manifest


@dataclass
class DriverResult(AgentResult):
    """Driver generation result"""
    generated_driver: Optional[GeneratedDriver] = None
    compile_success: bool = False
    firmware_path: Optional[str] = None
    build_log: str = ""
    build_attempts: int = 0
    artifacts: list[dict[str, Any]] = field(default_factory=list)


# ========== Compilation Types ==========

class ErrorPattern(str, Enum):
    """Error pattern classification"""
    UNDECLARED_IDENTIFIER = "undeclared_identifier"
    UNKNOWN_TYPE = "unknown_type"
    IMPLICIT_FUNCTION = "implicit_function"
    SYNTAX_ERROR = "syntax_error"
    TYPE_MISMATCH = "type_mismatch"
    LINKER_ERROR = "linker_error"
    OTHER = "other"


class CompressionLevel(str, Enum):
    """Prompt compression level"""
    DETAILED = "detailed"      # Detailed mode (rounds 1-2)
    BALANCED = "balanced"      # Balanced mode (rounds 3-4)
    COMPRESSED = "compressed"  # Compressed mode (round 5)


@dataclass
class BuildError:
    """Build error structure"""
    file: str                  # File path
    line: int                  # Line number
    column: int                # Column number
    message: str               # Error message
    error_type: str            # 'error' or 'warning'
    context: str = ""          # Error context code (3 lines before/after)
    pattern: Optional[ErrorPattern] = None  # Error pattern
    phase: str = "compile"
    category: str = "other"
    tool: str = "unknown"
    symbol: Optional[str] = None
    raw_message: str = ""
    is_repairable: bool = False
    fingerprint: str = ""


@dataclass
class BuildResult:
    """Build result"""
    success: bool                      # Success status
    firmware_path: Optional[str]       # Firmware file path
    stdout: str                        # Standard output
    stderr: str                        # Standard error
    errors: List[BuildError]           # Error list
    warnings: List[BuildError]         # Warning list
    attempt: int                       # Attempt count
    returncode: int = 0                # Return code
    failure_category: Optional[str] = None
    changed_files: List[str] = field(default_factory=list)
    attempt_history: List[Dict[str, Any]] = field(default_factory=list)
    build_log_path: Optional[str] = None
    exception_type: Optional[str] = None
    post_build_success: Optional[bool] = None
    infrastructure_attempts: int = 1
    infrastructure_history: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class FixAttempt:
    """Fix attempt record"""
    attempt: int                       # Attempt number
    prev_errors: int                   # Error count before fix
    current_errors: int                # Error count after fix
    error_patterns: Dict[str, int]     # Error pattern statistics
    fix_actions: List[str]             # Fix actions taken
    fixed_files: Dict[str, str]        # Fixed files
    success: bool                      # Success status
    timestamp: datetime = field(default_factory=datetime.now)
    diagnostic_fingerprint: str = ""
    changed_paths: List[str] = field(default_factory=list)
    result: str = "failed"


@dataclass
class CompilationContext:
    """Compilation context"""
    # Input
    header_file: str                   # Header file content
    source_file: str                   # Source file content
    test_file: Optional[str] = None    # Test file content
    existing_project_path: str = ""    # Existing project path
    manifest: Optional[FileManifest] = None  # File manifest (P0 Task 4)
    generated_files: Dict[str, str] = field(default_factory=dict)
    allowed_write_paths: List[str] = field(default_factory=list)
    middleware_repair_paths: List[str] = field(default_factory=list)

    # Configuration
    build_tool_path: str = ""           # Platform build tool path
    stm32cubeide_path: str = ""        # STM32 Cube IDE path
    workspace_path: str = ""           # Workspace path
    configuration: str = DEFAULT_DRIVER_BUILD_CONFIGURATION
    requested_configuration: Optional[str] = None
    max_attempts: int = DEFAULT_DRIVER_COMPILE_ATTEMPTS
    compile_verify: bool = True        # Whether to actually execute compilation
    platform: str = ""
    clean_build: bool = DEFAULT_CLEAN_BUILD
    timeout: int = DEFAULT_DRIVER_BUILD_TIMEOUT_SECONDS
    baseline_verify: bool = True
    baseline_fail_fast: bool = DEFAULT_BASELINE_FAIL_FAST
    in_place_build: bool = False
    defer_in_place_commit: bool = False
    strict_configuration: bool = DEFAULT_STRICT_CONFIGURATION
    artifact_dir: str = ""
    cancellation_check: Optional[Callable[[], bool]] = None

    # Output
    firmware_path: Optional[str] = None  # Firmware path
    build_success: bool = False          # Build success status
    build_log: str = ""                  # Build log
    build_attempts: int = 0              # Actual attempt count
    changed_files: List[str] = field(default_factory=list)
    rolled_back: bool = False
    failure_category: Optional[str] = None
    placement_evidence: List[str] = field(default_factory=list)
    project_updates: List[str] = field(default_factory=list)
    project_metadata_files: Dict[str, str] = field(default_factory=dict)
    final_build_returncode: Optional[int] = None
    final_post_build_success: Optional[bool] = None
    infrastructure_retries: int = DEFAULT_INFRASTRUCTURE_RETRIES
    build_jobs: int = DEFAULT_BUILD_JOBS
    build_activity_timeout: int = DEFAULT_BUILD_ACTIVITY_TIMEOUT

    # History
    fix_history: List[FixAttempt] = field(default_factory=list)
    error_patterns: Dict[str, int] = field(default_factory=dict)

    # Metadata
    task_id: Optional[str] = None      # Task ID for progress reporting
    progress: float = DRIVER_COMPILE_PROGRESS_START

    def __post_init__(self) -> None:
        if not self.requested_configuration:
            self.requested_configuration = self.configuration
        self.max_attempts = min(
            max(int(self.max_attempts), MIN_DRIVER_COMPILE_ATTEMPTS),
            MAX_DRIVER_COMPILE_ATTEMPTS,
        )
        self.timeout = min(
            max(int(self.timeout), MIN_DRIVER_BUILD_TIMEOUT_SECONDS),
            MAX_DRIVER_BUILD_TIMEOUT_SECONDS,
        )
        self.infrastructure_retries = max(int(self.infrastructure_retries), MIN_INFRASTRUCTURE_RETRIES)
        self.build_jobs = min(max(int(self.build_jobs), MIN_BUILD_JOBS), MAX_BUILD_JOBS)
        self.build_activity_timeout = max(int(self.build_activity_timeout), MIN_BUILD_ACTIVITY_TIMEOUT)

    @property
    def resolved_build_tool_path(self) -> str:
        """Return the generic tool path with legacy STM32 compatibility."""
        return self.build_tool_path or self.stm32cubeide_path

    def add_attempt(self, attempt: FixAttempt):
        """Add fix attempt record"""
        self.fix_history.append(attempt)
        self.build_attempts = len(self.fix_history)

        # Update error pattern statistics
        for pattern, count in attempt.error_patterns.items():
            self.error_patterns[pattern] = self.error_patterns.get(pattern, 0) + count

    def get_persistent_errors(self) -> List[str]:
        """Get persistent errors (appearing in all rounds)"""
        if len(self.fix_history) < COMPARISON_HISTORY_WINDOW:
            return []

        # Extract error patterns from all rounds
        all_patterns = [set(attempt.error_patterns.keys()) for attempt in self.fix_history]

        # Find intersection
        persistent = set.intersection(*all_patterns)

        return list(persistent)

    def has_progress(self) -> bool:
        """Check if there is progress"""
        if len(self.fix_history) < 2:
            return True

        previous_attempt = self.fix_history[-2]
        current_attempt = self.fix_history[-1]
        return current_attempt.current_errors < previous_attempt.current_errors

    def is_slowing_down(self) -> bool:
        """Check if progress is slowing down"""
        if len(self.fix_history) < SLOWING_PROGRESS_WINDOW:
            return False

        last_three = self.fix_history[-SLOWING_PROGRESS_WINDOW:]

        # Calculate improvement rates
        improvements = [
            attempt.prev_errors - attempt.current_errors
            for attempt in last_three
        ]

        improvements_are_decreasing = all(
            previous > current
            for previous, current in zip(improvements, improvements[1:])
        )
        return (
            improvements_are_decreasing
            and improvements[-1] <= SLOWING_PROGRESS_THRESHOLD
        )
