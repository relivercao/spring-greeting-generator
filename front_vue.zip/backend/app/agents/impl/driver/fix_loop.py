"""
@file fix_loop.py
@author caoshwen
@brief Isolated compile and repair loop for generated driver files

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
from pathlib import Path
from typing import Optional

from loguru import logger

from app.core.driver_build_defaults import (
    COMPILE_EVIDENCE_EXTENSIONS,
    DEFAULT_DRIVER_COMPILE_ATTEMPTS,
    DIAGNOSTIC_FINGERPRINT_LENGTH,
    PROCESS_NOT_STARTED_RETURN_CODE,
    REPAIR_REGRESSION_STREAK_LIMIT,
)

from .build.base import deterministic_failure_category
from .build.session import InPlaceBuildSession, IsolatedBuildSession
from .repairer import CompileRepairer
from .types import BuildResult, CompilationContext, FixAttempt, ManifestScope


class CompileFixLoop:
    """Build a project session and repair generated files until a stop condition."""

    def __init__(
        self,
        executor,
        llm_bridge=None,
        max_attempts: int = DEFAULT_DRIVER_COMPILE_ATTEMPTS,
        repairer: Optional[CompileRepairer] = None,
    ):
        self.executor = executor
        self.llm_bridge = llm_bridge
        self.max_attempts = max_attempts
        self.repairer = repairer
        # Transaction entries are scoped to one async compile call; context identity
        # remains stable while that workflow retains the context object.
        self._in_place_transactions: dict[int, tuple[InPlaceBuildSession, object]] = {}

    async def compile_with_auto_fix(self, context: CompilationContext) -> BuildResult:
        """Execute baseline validation and a compile-repair loop."""
        if not context.compile_verify:
            return BuildResult(
                success=True,
                firmware_path=None,
                stdout="",
                stderr="Compilation skipped: compile_verify=False",
                errors=[],
                warnings=[],
                attempt=0,
                failure_category="skipped",
            )

        generated_files = self._generated_files(context)
        if not generated_files:
            raise ValueError("Compilation requires an explicit generated file manifest")
        context.allowed_write_paths = list(context.allowed_write_paths or generated_files.keys())
        max_attempts = self._clamp_max_attempts(context.max_attempts)
        await self._validate_environment(context)
        session = await self._prepare_session(context)
        history: list[dict] = []
        # The first failed build establishes the error-count baseline; only later
        # attempts can be classified as regressions.
        previous_error_count: Optional[int] = None
        regression_streak = 0
        seen_repair_states: set[str] = set()
        completed_successfully = False
        allow_downstream_diagnostics = False

        try:
            self._begin_in_place_transaction(session, context)
            if context.baseline_verify:
                await self._prepare_baseline_build(session, context)
                try:
                    baseline = await self._run_build(
                        session,
                        context,
                        phase="baseline",
                        attempt=0,
                    )
                finally:
                    await self._finalize_baseline_build(session, context)
                baseline_record = {
                    "attempt": 0,
                    "phase": "baseline",
                    "clean_build": context.clean_build,
                    "returncode": baseline.returncode,
                    "post_build_success": baseline.post_build_success,
                    "infrastructure_attempts": baseline.infrastructure_attempts,
                    "infrastructure_history": baseline.infrastructure_history,
                    "error_count": len(baseline.errors),
                    "warning_count": len(baseline.warnings),
                    "failure_category": baseline.failure_category,
                    "exception_type": baseline.exception_type,
                    "build_log_path": baseline.build_log_path,
                    "changed_files": [],
                    "repair_applied": False,
                    "compile_verified": False,
                    "result": "baseline_build_success" if baseline.success else "baseline_build_failed",
                }
                history.append(baseline_record)
                allow_downstream_diagnostics = baseline.success
                if not baseline.success:
                    root_category = (
                        deterministic_failure_category(baseline)
                        or baseline.failure_category
                        or "build_failed"
                    )
                    baseline_record["failure_category"] = root_category
                    baseline_record["result"] = "baseline_build_failed"
                    baseline_record["continued_to_generated"] = not context.baseline_fail_fast
                    if context.baseline_fail_fast:
                        baseline_record["generated_validation_status"] = "not_executed"
                        baseline.attempt_history = history
                        baseline.failure_category = "baseline_build_failed"
                        context.failure_category = baseline.failure_category
                        self._redact_result_paths(baseline, session)
                        context.build_log = self._combined_log(baseline)
                        return baseline
                    logger.warning(
                        "Baseline build failed ({}); continuing with generated build so "
                        "allowlisted driver diagnostics can trigger CLI repair",
                        root_category,
                    )

            await self._integrate_files(session, context, generated_files)
            await self._prepare_generated_build(session, context)

            last_result: Optional[BuildResult] = None
            for attempt in range(1, max_attempts + 1):
                self._raise_if_cancelled(context)
                build_result = await self._run_build(
                    session,
                    context,
                    phase="generated",
                    attempt=attempt,
                )
                build_result.attempt = attempt
                self._add_diagnostic_write_paths(session, context, build_result)
                last_result = build_result
                context.build_attempts = attempt
                fingerprint = self._diagnostic_fingerprint(build_result)
                error_count = len(build_result.errors)
                attempt_record = {
                    "attempt": attempt,
                    "phase": "generated",
                    "clean_build": context.clean_build,
                    "returncode": build_result.returncode,
                    "post_build_success": build_result.post_build_success,
                    "infrastructure_attempts": build_result.infrastructure_attempts,
                    "infrastructure_history": build_result.infrastructure_history,
                    "error_count": error_count,
                    "warning_count": len(build_result.warnings),
                    "diagnostic_fingerprint": fingerprint,
                    "failure_category": build_result.failure_category,
                    "exception_type": build_result.exception_type,
                    "build_log_path": build_result.build_log_path,
                    "changed_files": [],
                    "repair_applied": False,
                    "compile_verified": False,
                    "result": "build_success" if build_result.success else "build_failed",
                }
                history.append(attempt_record)

                if build_result.success:
                    if not self._generated_sources_were_compiled(session, context, build_result):
                        build_result.success = False
                        build_result.failure_category = "generated_source_not_compiled"
                        attempt_record["failure_category"] = build_result.failure_category
                        attempt_record["result"] = "stopped_generated_source_not_compiled"
                        break
                    context.final_build_returncode = build_result.returncode
                    context.final_post_build_success = build_result.post_build_success
                    context.project_metadata_files = await self._collect_publication_metadata(
                        session,
                        context,
                    )
                    build_result.firmware_path = self._export_firmware(session, context, build_result.firmware_path)
                    self._redact_result_paths(build_result, session)
                    context.firmware_path = build_result.firmware_path
                    context.build_success = True
                    context.build_log = self._combined_log(build_result)
                    attempt_record["compile_verified"] = True
                    context.generated_files = session.read_files(
                        context.allowed_write_paths,
                        scope=self._manifest_scope(context),
                    )
                    build_result.changed_files = list(context.changed_files)
                    build_result.attempt_history = history
                    completed_successfully = True
                    return build_result

                if build_result.failure_category == "cancelled":
                    context.failure_category = build_result.failure_category
                    break
                repair_state = self._repair_state_fingerprint(
                    session,
                    context,
                    fingerprint,
                )
                attempt_record["repair_state_fingerprint"] = repair_state
                if repair_state in seen_repair_states:
                    build_result.failure_category = "repair_oscillation"
                    attempt_record["failure_category"] = build_result.failure_category
                    attempt_record["result"] = "stopped_repair_oscillation"
                    break
                seen_repair_states.add(repair_state)
                if (
                    build_result.failure_category == "timeout"
                    and not self._has_repairable_diagnostics(
                        build_result,
                        context.allowed_write_paths,
                        allow_downstream=allow_downstream_diagnostics,
                    )
                ):
                    context.failure_category = build_result.failure_category
                    break
                if previous_error_count is not None and error_count > previous_error_count:
                    regression_streak += 1
                else:
                    regression_streak = 0
                if regression_streak >= REPAIR_REGRESSION_STREAK_LIMIT:
                    build_result.failure_category = "repair_regression"
                    attempt_record["failure_category"] = build_result.failure_category
                    attempt_record["result"] = "stopped_regression"
                    break
                if not self._has_repairable_diagnostics(
                    build_result,
                    context.allowed_write_paths,
                    allow_downstream=allow_downstream_diagnostics,
                ):
                    build_result.failure_category = build_result.failure_category or "not_repairable"
                    attempt_record["failure_category"] = build_result.failure_category
                    attempt_record["result"] = "stopped_not_repairable"
                    break
                if attempt >= max_attempts:
                    # The limit is a loop stop reason, not the compiler root
                    # cause. Preserve both so callers can distinguish an
                    # exhausted budget from a non-repairable diagnostic.
                    attempt_record["root_failure_category"] = (
                        deterministic_failure_category(build_result)
                        or build_result.failure_category
                    )
                    attempt_record["terminal_stop_reason"] = "max_build_attempts"
                    build_result.failure_category = "max_attempts"
                    attempt_record["failure_category"] = build_result.failure_category
                    attempt_record["result"] = "stopped_max_attempts"
                    break
                if self.repairer is None:
                    build_result.failure_category = "repairer_unavailable"
                    attempt_record["failure_category"] = build_result.failure_category
                    attempt_record["result"] = "stopped_no_repairer"
                    break

                repair_result = await self.repairer.repair(session, context, build_result, attempt)
                attempt_record["changed_files"] = list(repair_result.changed_files)
                attempt_record["repair_diff"] = repair_result.diff
                attempt_record["repair_applied"] = repair_result.applied
                attempt_record["compile_verified"] = repair_result.compile_verified
                attempt_record["cli_exit_code"] = repair_result.cli_exit_code
                if not repair_result.applied:
                    root_failure_category = (
                        deterministic_failure_category(build_result)
                        or build_result.failure_category
                        or "build_failed"
                    )
                    repair_failure_category = repair_result.failure_category or "repair_failed"
                    build_result.failure_category = root_failure_category
                    attempt_record["failure_category"] = root_failure_category
                    attempt_record["root_failure_category"] = root_failure_category
                    attempt_record["repair_failure_category"] = repair_failure_category
                    attempt_record["repair_message"] = repair_result.message
                    attempt_record["terminal_stop_reason"] = repair_failure_category
                    attempt_record["result"] = f"stopped_{repair_failure_category}"
                    break

                logger.info(
                    "CLI repair attempt {} applied {} file(s); Python build verification is required",
                    attempt,
                    len(repair_result.changed_files),
                )

                context.changed_files = sorted(set(context.changed_files) | set(repair_result.changed_files))
                if context.clean_build:
                    context.clean_build = False
                    attempt_record["next_build_clean_build"] = False
                    logger.info(
                        "Switching subsequent Python build verification to incremental mode after CLI repair"
                    )
                context.generated_files = session.read_files(
                    context.allowed_write_paths,
                    scope=self._manifest_scope(context),
                )
                context.fix_history.append(
                    FixAttempt(
                        attempt=attempt,
                        prev_errors=previous_error_count if previous_error_count is not None else error_count,
                        current_errors=error_count,
                        error_patterns=self._error_categories(build_result),
                        fix_actions=[repair_result.message],
                        fixed_files=dict(context.generated_files),
                        success=repair_result.applied,
                        diagnostic_fingerprint=fingerprint,
                        changed_paths=list(repair_result.changed_files),
                        result="repair_applied",
                    )
                )
                previous_error_count = error_count

            if last_result is None:
                raise RuntimeError("Compile loop completed with no build result")
            context.build_success = False
            context.failure_category = last_result.failure_category or "build_failed"
            last_result.changed_files = list(context.changed_files)
            last_result.attempt_history = history
            self._redact_result_paths(last_result, session)
            context.build_log = self._combined_log(last_result)
            return last_result
        except asyncio.CancelledError:
            context.rolled_back = True
            context.failure_category = "cancelled"
            await self._terminate()
            raise
        finally:
            self._reset_repair_session(context, session)
            if completed_successfully:
                if not context.defer_in_place_commit:
                    self.commit_in_place_transaction(context)
            else:
                self.rollback_in_place_transaction(context)
            await self._cleanup(session)

    def commit_in_place_transaction(self, context: CompilationContext) -> None:
        """Discard the original-project snapshot after verified publication succeeds."""
        transaction = self._in_place_transactions.pop(id(context), None)
        if transaction is None:
            return
        session, snapshot = transaction
        session.discard_snapshot(snapshot)

    def rollback_in_place_transaction(self, context: CompilationContext) -> None:
        """Restore the original project when in-place compilation does not commit."""
        transaction = self._in_place_transactions.pop(id(context), None)
        if transaction is None:
            return
        session, snapshot = transaction
        try:
            session.restore(snapshot)
            context.rolled_back = True
            logger.warning("Restored original project after unfinished in-place compilation")
        finally:
            session.discard_snapshot(snapshot)

    def _begin_in_place_transaction(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
    ) -> None:
        """Snapshot original-project inputs before any in-place build preparation."""
        if not isinstance(session, InPlaceBuildSession):
            return
        snapshot = session.create_snapshot(
            context.allowed_write_paths,
            self._manifest_scope(context),
        )
        self._in_place_transactions[id(context)] = (session, snapshot)

    async def _build(self, session: IsolatedBuildSession, context: CompilationContext) -> BuildResult:
        if hasattr(self.executor, "build"):
            return await self.executor.build(session, context)
        return await self.executor.build_project(
            project_path=str(session.project_path),
            configuration=context.configuration,
            workspace_path=str(session.workspace_path),
            clean_build=context.clean_build,
            timeout=context.timeout,
            cancellation_check=context.cancellation_check,
        )

    async def _prepare_baseline_build(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
    ) -> None:
        prepare = getattr(self.executor, "prepare_baseline_build", None)
        if prepare is not None:
            await prepare(session, context)

    async def _finalize_baseline_build(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
    ) -> None:
        finalize = getattr(self.executor, "finalize_baseline_build", None)
        if finalize is not None:
            await finalize(session, context)

    async def _run_build(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
        *,
        phase: str,
        attempt: int,
    ) -> BuildResult:
        """Convert executor failures into durable, structured build results."""
        try:
            result = await self._build(session, context)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            exception_type = type(exc).__name__
            message = f"{exception_type}: {exc!r}"
            logger.exception(
                "Driver {} build raised an executor exception on attempt {}: {}",
                phase,
                attempt,
                message,
            )
            result = BuildResult(
                success=False,
                firmware_path=None,
                stdout="",
                stderr=message,
                errors=[],
                warnings=[],
                attempt=attempt,
                returncode=PROCESS_NOT_STARTED_RETURN_CODE,
                failure_category="executor_exception",
                exception_type=exception_type,
            )
        self._persist_build_log(context, result, phase=phase, attempt=attempt)
        return result

    async def _validate_environment(self, context: CompilationContext) -> None:
        if hasattr(self.executor, "validate_environment"):
            await self.executor.validate_environment(context)

    async def _prepare_session(self, context: CompilationContext) -> IsolatedBuildSession:
        if hasattr(self.executor, "prepare_session"):
            return await self.executor.prepare_session(context)
        if context.in_place_build:
            return InPlaceBuildSession(context.existing_project_path, context.task_id)
        return IsolatedBuildSession(context.existing_project_path, context.task_id)

    async def _integrate_files(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
        generated_files: dict[str, str],
    ) -> None:
        if context.manifest and context.manifest.scope == ManifestScope.REPOSITORY:
            session.write_files(generated_files, scope=context.manifest.scope)
            return
        if hasattr(self.executor, "integrate_files"):
            await self.executor.integrate_files(session, generated_files)
            return
        await self.executor.integrate_files_to_project(generated_files, str(session.project_path))

    async def _prepare_generated_build(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
    ) -> None:
        if hasattr(self.executor, "prepare_generated_build"):
            await self.executor.prepare_generated_build(session, context)

    async def _collect_publication_metadata(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
    ) -> dict[str, str]:
        if hasattr(self.executor, "collect_publication_metadata"):
            return await self.executor.collect_publication_metadata(session, context)
        return {}

    async def _terminate(self) -> None:
        if hasattr(self.executor, "terminate"):
            await self.executor.terminate()

    async def _cleanup(self, session: IsolatedBuildSession) -> None:
        if hasattr(self.executor, "cleanup"):
            await self.executor.cleanup(session)
            return
        session.cleanup()

    def _reset_repair_session(
        self,
        context: CompilationContext,
        session: IsolatedBuildSession,
    ) -> None:
        """Drop the logical CLI conversation after the Python loop terminates."""
        reset_session = getattr(self.repairer, "reset_session", None)
        if not callable(reset_session):
            return
        working_root = (
            session.isolated_source_root
            if self._manifest_scope(context) == ManifestScope.REPOSITORY
            else session.project_path
        )
        try:
            reset_session(context, working_root)
        except Exception as exc:
            logger.warning("Failed to reset CLI repair session for task {}: {}", context.task_id, exc)

    @staticmethod
    def _generated_files(context: CompilationContext) -> dict[str, str]:
        if context.generated_files:
            return {path.replace("\\", "/"): content for path, content in context.generated_files.items()}
        if not context.manifest:
            return {}
        paths = context.manifest.relative_paths()
        files = {
            paths["header"]: context.header_file,
            paths["source"]: context.source_file,
        }
        if context.test_file and "test" in paths:
            files[paths["test"]] = context.test_file
        return files

    @staticmethod
    def _manifest_scope(context: CompilationContext) -> ManifestScope:
        return context.manifest.scope if context.manifest else ManifestScope.PROJECT

    @staticmethod
    def _add_diagnostic_write_paths(
        session: IsolatedBuildSession,
        context: CompilationContext,
        build_result: BuildResult,
    ) -> None:
        if not context.manifest or context.manifest.scope != ManifestScope.REPOSITORY:
            return

        expected_names = {
            context.manifest.source_filename.casefold(),
            context.manifest.header_filename.casefold(),
        }
        allowed_paths = {
            path.replace('\\', '/').casefold()
            for path in context.allowed_write_paths
        }
        for diagnostic in build_result.errors:
            raw_path = (diagnostic.file or '').strip()
            if not raw_path:
                continue
            path = Path(raw_path)
            relative_candidates = []
            if path.is_absolute():
                for base in (session.isolated_source_root, session.project_path):
                    try:
                        relative_candidates.append(
                            path.resolve().relative_to(base.resolve()).as_posix()
                        )
                    except ValueError:
                        continue
            else:
                relative_candidates.append(path.as_posix())

            for relative_path in relative_candidates:
                normalized = relative_path.replace('\\', '/')
                if Path(normalized).name.casefold() not in expected_names:
                    continue
                try:
                    resolved = session.resolve_manifest_path(
                        normalized,
                        context.manifest.scope,
                    )
                except ValueError:
                    continue
                if not resolved.is_file():
                    continue
                if normalized.casefold() not in allowed_paths:
                    context.allowed_write_paths.append(normalized)
                    allowed_paths.add(normalized.casefold())
                    logger.warning(
                        'Compiler diagnostic path differs from placement manifest; '
                        'added actual source to repair allowlist: {}',
                        normalized,
                    )
                break

    @staticmethod
    def _generated_sources_were_compiled(
        session: IsolatedBuildSession,
        context: CompilationContext,
        build_result: BuildResult,
    ) -> bool:
        if not context.manifest or context.manifest.scope != ManifestScope.REPOSITORY:
            return True
        combined_log = "\n".join(part for part in (build_result.stdout, build_result.stderr) if part)
        normalized_log = combined_log.replace('\\', '/').casefold()
        for required_path in context.manifest.compile_required_paths():
            normalized_required_path = required_path.replace('\\', '/').casefold()
            if normalized_required_path not in normalized_log:
                return False
        for source_path in context.manifest.compile_required_paths():
            source_name = Path(source_path).name
            source_stem = Path(source_path).stem
            if source_name in combined_log:
                continue
            if any(
                any(session.project_path.rglob(f"{source_stem}{suffix}"))
                for suffix in COMPILE_EVIDENCE_EXTENSIONS
            ):
                continue
            return False
        return True

    @staticmethod
    def _diagnostic_fingerprint(build_result: BuildResult) -> str:
        fingerprints = sorted(item.fingerprint or item.message for item in build_result.errors)
        payload = "\n".join(fingerprints) or f"returncode:{build_result.returncode}"
        return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[
            :DIAGNOSTIC_FINGERPRINT_LENGTH
        ]

    @classmethod
    def _repair_state_fingerprint(
        cls,
        session: IsolatedBuildSession,
        context: CompilationContext,
        diagnostic_fingerprint: str,
    ) -> str:
        """Hash diagnostics and allowlisted contents to stop repair oscillation."""
        try:
            files = session.read_files(
                context.allowed_write_paths,
                scope=cls._manifest_scope(context),
            )
        except OSError:
            files = {}
        content = json.dumps(
            sorted((path.replace("\\", "/"), value) for path, value in files.items()),
            ensure_ascii=True,
            separators=(",", ":"),
        )
        payload = f"{diagnostic_fingerprint}\n{content}"
        return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()

    @staticmethod
    def _has_repairable_diagnostics(
        build_result: BuildResult,
        allowed_paths: list[str],
        *,
        allow_downstream: bool,
    ) -> bool:
        """Return whether diagnostics justify invoking the bounded repairer.

        A compiler can report an interface mismatch at a downstream consumer
        even though the fix belongs in an allowlisted generated header/source
        file. After a clean baseline build, these downstream diagnostics may
        trigger repair. If the baseline was already failing, retain the stricter
        generated-file filter to avoid spending repair attempts on pre-existing
        project errors. The repairer still enforces write authorization with a
        scoped restorable snapshot and disk/tool diff validation before accepting
        changes.
        """
        allowed_names = {Path(path).name.lower() for path in allowed_paths}
        for diagnostic in build_result.errors:
            if not diagnostic.is_repairable:
                continue
            if allow_downstream or not diagnostic.file:
                return True
            if Path(diagnostic.file).name.lower() in allowed_names:
                return True
        return False

    @staticmethod
    def _error_categories(build_result: BuildResult) -> dict[str, int]:
        categories: dict[str, int] = {}
        for diagnostic in build_result.errors:
            categories[diagnostic.category] = categories.get(diagnostic.category, 0) + 1
        return categories

    @staticmethod
    def _combined_log(build_result: BuildResult) -> str:
        return "\n".join(part for part in [build_result.stdout, build_result.stderr] if part)

    @staticmethod
    def _persist_build_log(
        context: CompilationContext,
        build_result: BuildResult,
        *,
        phase: str,
        attempt: int,
    ) -> None:
        if not context.artifact_dir:
            return
        log_dir = Path(context.artifact_dir).resolve() / "compile_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        filename = "baseline.log" if phase == "baseline" else f"attempt-{attempt}.log"
        log_path = log_dir / filename
        source_log = ''
        source_log_path = build_result.build_log_path
        if source_log_path:
            try:
                source_path = Path(source_log_path)
                if source_path.is_file() and source_path.resolve() != log_path.resolve():
                    source_log = source_path.read_text(encoding='utf-8', errors='replace')
            except OSError as exc:
                logger.warning(
                    'Failed to read executor build log for {} attempt {}: {}',
                    phase,
                    attempt,
                    exc,
                )
        if source_log:
            build_result.stdout = '\n'.join(
                part for part in [build_result.stdout, '[RAW EXECUTOR BUILD LOG]', source_log]
                if part
            )
        sections = [
            "P4 Driver Build Log",
            f"Phase: {phase}",
            f"Attempt: {attempt}",
            f"Configuration: {context.configuration}",
            f"Return code: {build_result.returncode}",
            f"Failure category: {build_result.failure_category or ''}",
            f"Exception type: {build_result.exception_type or ''}",
        ]
        if build_result.stdout:
            sections.extend(["", "[STDOUT]", build_result.stdout])
        if build_result.stderr:
            sections.extend(["", "[STDERR]", build_result.stderr])
        try:
            log_path.write_text("\n".join(sections) + "\n", encoding="utf-8")
            build_result.build_log_path = str(log_path)
        except OSError as exc:
            logger.warning(
                "Failed to persist {} build log for attempt {}: {}",
                phase,
                attempt,
                exc,
            )

    @staticmethod
    def _raise_if_cancelled(context: CompilationContext) -> None:
        if context.cancellation_check and context.cancellation_check():
            raise asyncio.CancelledError("Build cancelled by user")

    @staticmethod
    def _export_firmware(
        session: IsolatedBuildSession,
        context: CompilationContext,
        firmware_path: Optional[str],
    ) -> Optional[str]:
        if not firmware_path:
            return None
        if not context.artifact_dir:
            return firmware_path
        return session.export_file(firmware_path, context.artifact_dir)

    @staticmethod
    def _redact_result_paths(build_result: BuildResult, session: IsolatedBuildSession) -> None:
        replacements = {
            str(session.root_path): "<isolated-session>",
            session.root_path.as_posix(): "<isolated-session>",
        }
        for original, replacement in replacements.items():
            build_result.stdout = build_result.stdout.replace(original, replacement)
            build_result.stderr = build_result.stderr.replace(original, replacement)
        for diagnostic in build_result.errors + build_result.warnings:
            for original, replacement in replacements.items():
                diagnostic.file = diagnostic.file.replace(original, replacement)
                diagnostic.raw_message = diagnostic.raw_message.replace(original, replacement)

    def _clamp_max_attempts(self, requested_attempts: int) -> int:
        """Clamp max_attempts to valid range and log when clamping occurs."""
        clamped = min(max(requested_attempts, 1), self.max_attempts)
        if clamped != requested_attempts:
            logger.info(
                f"[CompileFixLoop] Clamped max_attempts from {requested_attempts} to {clamped} "
                f"(limit: {self.max_attempts})"
            )
        return clamped
