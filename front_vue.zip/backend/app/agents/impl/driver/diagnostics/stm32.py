"""
@file stm32.py
@author caoshwen
@brief STM32 diagnostic parser adapter for build logs

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

import re

from .base import DiagnosticParser, DiagnosticSet
from ..parsers import (
    create_build_diagnostic,
    fill_error_contexts,
    parse_build_diagnostics,
)
from ..types import BuildError


def _parse_stm32cubeide_line(line: str) -> BuildError | None:
    raw = line.strip()
    if not raw:
        return None

    ide_patterns = (
        (r"Build Failed\.\s*\d+ errors?", "build_failed"),
        (r"Workspace is already in use", "workspace_in_use"),
        (r"Project .+ does not exist", "project_missing"),
        (r"Configuration .+ does not exist", "configuration_missing"),
        (r"Problems occurred when invoking code", "ide_failure"),
    )
    for pattern, category in ide_patterns:
        if re.search(pattern, raw, re.IGNORECASE):
            return create_build_diagnostic(
                message=raw,
                raw_message=raw,
                phase="configure",
                category=category,
                tool="stm32cubeide",
            )

    tool_patterns = (
        (r"Java was started but returned exit code=\d+", "java_start_failed", "java"),
        (r"Toolchain not found", "toolchain_missing", "stm32cubeide"),
        (r"Executable not found", "executable_missing", "stm32cubeide"),
        (r"Build timeout", "timeout", "stm32cubeide"),
    )
    for pattern, category, tool in tool_patterns:
        if re.search(pattern, raw, re.IGNORECASE):
            return create_build_diagnostic(
                message=raw,
                raw_message=raw,
                phase="tool",
                category=category,
                tool=tool,
            )
    return None


def _parse_stm32_diagnostics(output: str) -> list[BuildError]:
    diagnostics = parse_build_diagnostics(output)
    seen = {item.fingerprint for item in diagnostics}
    for line in output.splitlines():
        diagnostic = _parse_stm32cubeide_line(line)
        if diagnostic and diagnostic.fingerprint not in seen:
            diagnostics.append(diagnostic)
            seen.add(diagnostic.fingerprint)
    return diagnostics


def parse_stm32_build_errors(output: str) -> list[BuildError]:
    """Parse generic tool and STM32CubeIDE errors."""
    return [item for item in _parse_stm32_diagnostics(output) if item.error_type == "error"]


def parse_stm32_build_warnings(output: str) -> list[BuildError]:
    """Parse generic tool and STM32CubeIDE warnings."""
    return [item for item in _parse_stm32_diagnostics(output) if item.error_type == "warning"]


class STM32DiagnosticParser(DiagnosticParser):
    """Parse GCC, linker, Make, STM32CubeIDE, and tool diagnostics."""

    platform = "stm32"

    def parse(self, stdout: str, stderr: str) -> DiagnosticSet:
        combined = "\n".join(part for part in (stdout, stderr) if part)
        diagnostics = _parse_stm32_diagnostics(combined)
        return DiagnosticSet(
            errors=fill_error_contexts(
                [item for item in diagnostics if item.error_type == "error"]
            ),
            warnings=[item for item in diagnostics if item.error_type == "warning"],
        )
