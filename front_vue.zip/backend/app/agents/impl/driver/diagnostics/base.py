"""
@file base.py
@author caoshwen
@brief Platform-neutral diagnostic parser contracts

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ..types import BuildError


@dataclass
class DiagnosticSet:
    """Structured diagnostics emitted by one build attempt."""

    errors: list[BuildError] = field(default_factory=list)
    warnings: list[BuildError] = field(default_factory=list)


class DiagnosticParser(ABC):
    """Parse one platform build log into the shared diagnostic model."""

    platform: str

    @abstractmethod
    def parse(self, stdout: str, stderr: str) -> DiagnosticSet:
        """Parse standard output and standard error without executing tools."""
