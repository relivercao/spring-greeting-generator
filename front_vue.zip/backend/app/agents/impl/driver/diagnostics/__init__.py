"""
@file __init__.py
@author caoshwen
@brief Platform diagnostic parser exports and default registry

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from .base import DiagnosticParser, DiagnosticSet
from .registry import DiagnosticParserRegistry, diagnostic_parser_registry
from .stm32 import (
    STM32DiagnosticParser,
    parse_stm32_build_errors,
    parse_stm32_build_warnings,
)

__all__ = [
    "DiagnosticParser",
    "DiagnosticSet",
    "DiagnosticParserRegistry",
    "STM32DiagnosticParser",
    "parse_stm32_build_errors",
    "parse_stm32_build_warnings",
    "parse_platform_diagnostics",
    "diagnostic_parser_registry",
]


def parse_platform_diagnostics(
    platform: str | None,
    stdout: str,
    stderr: str,
) -> DiagnosticSet:
    """Parse a build result with the registered platform diagnostic parser."""
    return diagnostic_parser_registry.parse(platform, stdout, stderr)
