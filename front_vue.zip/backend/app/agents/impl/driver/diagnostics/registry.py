"""
@file registry.py
@author caoshwen
@brief Diagnostic parser registry for platform-specific build logs

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from collections.abc import Callable

from ..build.registry import normalize_build_platform
from .base import DiagnosticParser, DiagnosticSet


class DiagnosticParserRegistry:
    """Resolve platform families to stateless parser factories."""

    def __init__(self):
        self._factories: dict[str, Callable[[], DiagnosticParser]] = {}

    def register(self, platform: str, factory: Callable[[], DiagnosticParser]) -> None:
        self._factories[normalize_build_platform(platform)] = factory

    def create(self, platform: str | None) -> DiagnosticParser:
        canonical = normalize_build_platform(platform)
        factory = self._factories.get(canonical)
        if factory is None:
            raise ValueError(f"No diagnostic parser is registered for platform '{canonical}'")
        return factory()

    def platforms(self) -> tuple[str, ...]:
        return tuple(sorted(self._factories))

    def parse(self, platform: str | None, stdout: str, stderr: str) -> DiagnosticSet:
        """Parse one build result with the registered platform parser."""
        return self.create(platform).parse(stdout, stderr)


def _create_default_registry() -> DiagnosticParserRegistry:
    from .stm32 import STM32DiagnosticParser

    registry = DiagnosticParserRegistry()
    registry.register("stm32", STM32DiagnosticParser)
    return registry


diagnostic_parser_registry = _create_default_registry()
