"""
@file stm32.py
@author caoshwen
@brief STM32CubeIDE driver placement resolver

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from functools import lru_cache
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from ..types import FileManifest, ManifestScope
from .base import DriverPlacementResolver, PlacementRequest, PlacementResult


_IGNORED_DIR_NAMES = {".git", ".metadata", ".svn", ".hg"}
_IGNORED_DIR_PREFIXES = ("debug", "release")
_KNOWN_WORKSPACE_ROOTS = {"apps", "bsp", "libs", "midware", "managers"}


@dataclass(frozen=True)
class _SourceEntry:
    root: Path
    exclusions: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class _Topology:
    repository_root: Path
    project_path: Path
    source_entries: tuple[_SourceEntry, ...]
    include_paths: tuple[Path, ...]
    linked_resource_paths: tuple[Path, ...]


class STM32DriverPlacementResolver(DriverPlacementResolver):
    """Resolve driver placement from STM32CubeIDE project topology."""

    def resolve(self, request: PlacementRequest) -> PlacementResult:
        project_path = Path(request.project_path).resolve()
        if not project_path.is_dir():
            raise ValueError(f"project_path must be a directory: {project_path}")

        topology = self._resolve_topology(project_path, request.configuration)
        module_type = _normalize_token(request.module_type)
        module_name = _normalize_token(request.module_name)
        if not module_type or not module_name:
            raise ValueError("module_type and module_name are required for driver placement")

        candidate_roots = self._candidate_driver_roots(topology.repository_root, module_type)
        candidate_roots = [
            root for root in candidate_roots
            if self._is_under_source_entries(root, topology.source_entries)
        ]
        if not candidate_roots:
            raise ValueError(f"No compiled driver root found for module type '{module_type}'")

        unique_roots = sorted(set(candidate_roots), key=lambda path: path.as_posix().lower())
        active_roots = self._roots_with_active_driver(
            unique_roots,
            topology,
            module_name,
        )
        if active_roots:
            before = tuple(
                root.relative_to(topology.repository_root).as_posix()
                for root in unique_roots
            )
            unique_roots = active_roots
            disambiguation_evidence = (
                self._selection_evidence(
                    before,
                    unique_roots[0],
                    topology.repository_root,
                    "active_project_resource",
                )
                if len(unique_roots) == 1
                else ()
            )
        else:
            include_roots = self._roots_referenced_by_includes(
                unique_roots,
                topology.include_paths,
            )
            if include_roots:
                unique_roots = sorted(
                    set(include_roots),
                    key=lambda path: path.as_posix().lower(),
                )

            structured_roots = [
                root for root in unique_roots if self._has_chip_driver_sibling(root)
            ]
            if structured_roots:
                unique_roots = structured_roots

            unique_roots, disambiguation_evidence = self._disambiguate_candidate_roots(
                unique_roots,
                topology,
            )
        if len(unique_roots) != 1:
            candidates = ", ".join(root.relative_to(topology.repository_root).as_posix() for root in unique_roots)
            raise ValueError(f"Ambiguous driver placement roots for '{module_type}': {candidates}")

        root = unique_roots[0]
        target, target_evidence = self._resolve_driver_target(
            root,
            topology,
            module_type,
            module_name,
            request.driver_hint,
        )
        inc_dir = target / "inc"
        src_dir = target / "src"
        header_filename = request.header_filename
        source_filename = request.source_filename
        generic_target_name = f"driver-{module_name}"
        if target.name.casefold() != generic_target_name.casefold():
            target_stem = target.name
            if header_filename.casefold() == f"{generic_target_name}.h":
                header_filename = f"{target_stem}.h"
            if source_filename.casefold() == f"{generic_target_name}.c":
                source_filename = f"{target_stem}.c"
        header_filename = 'driver-' + target.name.removeprefix('driver-') + '.h'
        source_filename = 'driver-' + target.name.removeprefix('driver-') + '.c'
        manifest = FileManifest(
            header_filename=header_filename,
            source_filename=source_filename,
            config_filename=request.config_filename,
            test_filename=None,
            target_inc_dir=inc_dir.relative_to(topology.repository_root).as_posix(),
            target_src_dir=src_dir.relative_to(topology.repository_root).as_posix(),
            scope=ManifestScope.REPOSITORY,
        )
        evidence = (
            f"repository_root={topology.repository_root}",
            f"driver_root={root.relative_to(topology.repository_root).as_posix()}",
            f"source_entry={self._matching_source_entry(root, topology.source_entries)}",
            f"driver_target={target.relative_to(topology.repository_root).as_posix()}",
            *target_evidence,
            *disambiguation_evidence,
        )
        project_updates = ()
        if not self._is_include_path_present(inc_dir, topology.include_paths):
            project_updates = (f"add_include_path={inc_dir.relative_to(topology.repository_root).as_posix()}",)
        return PlacementResult(manifest=manifest, evidence=evidence, project_updates=project_updates)

    @classmethod
    def _resolve_driver_target(
        cls,
        root: Path,
        topology: _Topology,
        module_type: str,
        module_name: str,
        driver_hint: str | None,
    ) -> tuple[Path, tuple[str, ...]]:
        requested = root / f"driver-{module_name}"
        requested_is_generic = _normalize_token(module_name) == _normalize_token(module_type)
        if not requested_is_generic:
            return requested, ('placement_target_selection=module_name',)

        sibling_targets = sorted(
            (
                child
                for child in root.iterdir()
                if child.is_dir()
                and child != requested
                and child.name.casefold().startswith("driver-")
                and cls._has_driver_files(child)
            ),
            key=lambda path: path.as_posix().casefold(),
        ) if root.is_dir() else []
        if cls._has_driver_files(requested) and not (requested_is_generic and sibling_targets):
            return requested, ()

        candidates = sibling_targets
        if cls._has_driver_files(requested) and not candidates:
            return requested, ()
        if not candidates:
            return requested, ()

        hint = _normalize_token(driver_hint)
        hinted = [
            child
            for child in candidates
            if _driver_token_matches_hint(
                _normalize_token(child.name.removeprefix("driver-")),
                hint,
            )
        ]
        if hinted:
            longest = max(
                len(_normalize_token(item.name.removeprefix("driver-")))
                for item in hinted
            )
            hinted = [
                item
                for item in hinted
                if len(_normalize_token(item.name.removeprefix("driver-"))) == longest
            ]
        if len(hinted) == 1:
            return hinted[0], ("placement_target_selection=driver_hint",)
        if len(hinted) > 1:
            names = ", ".join(item.name for item in hinted)
            raise ValueError(
                f"Driver hint '{driver_hint}' matches multiple targets: {names}"
            )

        active_tokens = cls._active_driver_tokens(topology, module_type)
        active = [
            child
            for child in candidates
            if _normalize_token(child.name.removeprefix("driver-")) in active_tokens
        ]
        if len(active) == 1:
            target = active[0]
            return target, ("placement_target_selection=active_target_macro",)
        if len(active) > 1:
            names = ", ".join(item.name for item in active)
            raise ValueError(
                f"Multiple active driver targets found for '{module_type}': {names}"
            )
        if len(candidates) == 1:
            return candidates[0], ("placement_target_selection=only_driver_target",)

        names = ", ".join(item.name for item in candidates)
        raise ValueError(
            f"Cannot resolve active driver target for '{module_type}'; candidates: {names}"
        )

    @staticmethod
    def _has_driver_files(path: Path) -> bool:
        return (
            path.is_dir()
            and (path / "inc").is_dir()
            and (path / "src").is_dir()
            and any(item.is_file() for item in (path / "inc").iterdir())
            and any(item.is_file() for item in (path / "src").iterdir())
        )

    @staticmethod
    def _active_driver_tokens(topology: _Topology, module_type: str) -> set[str]:
        prefix = f"SUPPORT_{module_type.upper()}_"
        tokens: set[str] = set()
        for include_path in topology.include_paths:
            target_header = include_path / "target.h"
            try:
                content = target_header.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for match in re.finditer(
                rf"^\s*#\s*define\s+{re.escape(prefix)}([A-Za-z0-9_]+)\b",
                content,
                flags=re.MULTILINE,
            ):
                tokens.add(_normalize_token(match.group(1)))
        return tokens

    def _resolve_topology(self, project_path: Path, configuration: str | None) -> _Topology:
        repository_root = _find_repository_root(project_path)
        linked_resources = _read_linked_resources(project_path, repository_root)
        source_entries, include_paths = _read_cproject_entries(
            project_path,
            repository_root,
            linked_resources,
            configuration,
        )
        if not source_entries:
            source_entries = (_SourceEntry(project_path),)
        return _Topology(
            repository_root=repository_root,
            project_path=project_path,
            source_entries=source_entries,
            include_paths=include_paths,
            linked_resource_paths=tuple(dict.fromkeys(linked_resources.values())),
        )

    @staticmethod
    def _candidate_driver_roots(repository_root: Path, module_type: str) -> list[Path]:
        expected_name = f"driver-{module_type}"
        roots: list[Path] = []
        for path in repository_root.rglob(expected_name):
            if path.is_dir() and not _is_ignored(path, repository_root):
                roots.append(path.resolve())
        return roots

    @staticmethod
    def _is_under_source_entries(path: Path, entries: tuple[_SourceEntry, ...]) -> bool:
        for entry in entries:
            try:
                relative = path.relative_to(entry.root)
            except ValueError:
                continue
            rel = relative.as_posix()
            if not any(rel == exclusion or rel.startswith(f"{exclusion}/") for exclusion in entry.exclusions):
                return True
        return False

    @staticmethod
    def _matching_source_entry(path: Path, entries: tuple[_SourceEntry, ...]) -> str:
        for entry in entries:
            try:
                path.relative_to(entry.root)
                return entry.root.as_posix()
            except ValueError:
                continue
        return ""

    @staticmethod
    def _roots_referenced_by_includes(candidate_roots: list[Path], include_paths: tuple[Path, ...]) -> list[Path]:
        referenced: list[Path] = []
        for root in candidate_roots:
            for include_path in include_paths:
                try:
                    include_path.relative_to(root)
                    referenced.append(root)
                    break
                except ValueError:
                    continue
        return referenced

    @staticmethod
    def _has_chip_driver_sibling(root: Path) -> bool:
        for child in root.iterdir() if root.exists() else []:
            if child.is_dir() and child.name.startswith("driver-") and (child / "inc").is_dir() and (child / "src").is_dir():
                return True
        return False

    @staticmethod
    def _roots_with_active_driver(
        roots: list[Path],
        topology: _Topology,
        module_name: str,
    ) -> list[Path]:
        """Return roots whose requested driver is visible in the Eclipse project."""
        active: list[Path] = []
        for root in roots:
            target = (root / f"driver-{module_name}").resolve()
            if any(
                _paths_overlap(target, resource_path)
                for resource_path in topology.linked_resource_paths
            ):
                active.append(root)
        return active

    @classmethod
    def _disambiguate_candidate_roots(
        cls,
        roots: list[Path],
        topology: _Topology,
    ) -> tuple[list[Path], tuple[str, ...]]:
        """Narrow equivalent driver roots without aborting the build loop.

        Some customer workspaces expose both a repository-level mirror such as
        bsp/drivers/driver-led and the compiled platformkit copy under
        libs/platformkit/bsp/drivers/driver-led. Treat the most specific source
        entry, then the canonical platformkit path, as deterministic evidence so
        placement does not fail before compilation can even start.
        """
        if len(roots) <= 1:
            return roots, ()

        before = tuple(
            root.relative_to(topology.repository_root).as_posix()
            for root in roots
        )
        source_specificity = {
            root: cls._source_entry_specificity(root, topology.source_entries)
            for root in roots
        }
        best_specificity = max(source_specificity.values(), default=0)
        if best_specificity > 0:
            narrowed = [root for root in roots if source_specificity[root] == best_specificity]
            if len(narrowed) == 1:
                return narrowed, cls._selection_evidence(
                    before,
                    narrowed[0],
                    topology.repository_root,
                    "most_specific_source_entry",
                )
            roots = narrowed

        preferred = [root for root in roots if cls._is_platformkit_bsp_driver_root(root, topology.repository_root)]
        if len(preferred) == 1:
            return preferred, cls._selection_evidence(
                before,
                preferred[0],
                topology.repository_root,
                "platformkit_bsp_driver_root",
            )

        return roots, ()

    @staticmethod
    def _source_entry_specificity(root: Path, entries: tuple[_SourceEntry, ...]) -> int:
        """Return the deepest matching source-entry depth for a candidate root."""
        best = 0
        for entry in entries:
            try:
                root.relative_to(entry.root)
            except ValueError:
                continue
            best = max(best, len(entry.root.parts))
        return best

    @staticmethod
    def _is_platformkit_bsp_driver_root(root: Path, repository_root: Path) -> bool:
        try:
            parts = root.relative_to(repository_root).parts
        except ValueError:
            parts = root.parts
        lowered = tuple(part.lower() for part in parts)
        return any(
            lowered[index:index + 4] == ("libs", "platformkit", "bsp", "drivers")
            for index in range(0, max(len(lowered) - 3, 0))
        )

    @staticmethod
    def _selection_evidence(
        candidates: tuple[str, ...],
        selected: Path,
        repository_root: Path,
        reason: str,
    ) -> tuple[str, ...]:
        return (
            f"placement_disambiguation={reason}",
            "placement_candidates=" + ",".join(candidates),
            f"placement_selected={selected.relative_to(repository_root).as_posix()}",
        )

    @staticmethod
    def _is_include_path_present(path: Path, include_paths: tuple[Path, ...]) -> bool:
        resolved = path.resolve()
        return any(item.resolve() == resolved for item in include_paths)


def _normalize_token(value: str | None) -> str:
    text = (value or "").strip().lower()
    text = re.sub(r"^driver[-_]", "", text)
    return re.sub(r"[^a-z0-9]+", "", text)


def _driver_token_matches_hint(token: str, hint: str) -> bool:
    return bool(token and hint and (token in hint or hint in token))


@lru_cache(maxsize=32)
def infer_active_driver_slug(
    project_path: str,
    module_type: str,
    configuration: str | None = None,
    driver_hint: str | None = None,
) -> str | None:
    """Return the active chip-driver slug for a generic module request."""
    resolver = STM32DriverPlacementResolver()
    result = resolver.resolve(
        PlacementRequest(
            project_path=project_path,
            module_type=module_type,
            module_name=module_type,
            configuration=configuration,
            header_filename=f"driver-{_normalize_token(module_type)}.h",
            source_filename=f"driver-{_normalize_token(module_type)}.c",
            driver_hint=driver_hint,
        )
    )
    target_name = Path(result.manifest.target_inc_dir).parent.name
    normalized = _normalize_token(target_name.removeprefix("driver-"))
    return normalized or None


def _paths_overlap(first: Path, second: Path) -> bool:
    """Return whether either path contains the other."""
    try:
        first.relative_to(second)
        return True
    except ValueError:
        pass
    try:
        second.relative_to(first)
        return True
    except ValueError:
        return False


def _find_repository_root(project_path: Path) -> Path:
    for candidate in (project_path, *project_path.parents):
        if (candidate / ".git").exists():
            return candidate.resolve()
    return project_path.resolve()


def _read_linked_resources(project_path: Path, repository_root: Path) -> dict[str, Path]:
    project_file = project_path / ".project"
    if not project_file.exists():
        return {}
    try:
        root = ET.parse(project_file).getroot()
    except ET.ParseError:
        return {}

    linked: dict[str, Path] = {}
    for link in root.findall(".//link"):
        name = (link.findtext("name") or "").strip().replace("\\", "/")
        location_uri = (link.findtext("locationURI") or "").strip()
        if not name or not location_uri:
            continue
        resolved = _resolve_eclipse_path(location_uri, project_path, repository_root)
        if resolved:
            linked[name] = resolved
    return linked


def _read_cproject_entries(
    project_path: Path,
    repository_root: Path,
    linked_resources: dict[str, Path],
    configuration: str | None,
) -> tuple[tuple[_SourceEntry, ...], tuple[Path, ...]]:
    cproject_file = project_path / ".cproject"
    if not cproject_file.exists():
        return (), ()
    try:
        root = ET.parse(cproject_file).getroot()
    except ET.ParseError:
        return (), ()

    config_nodes = root.findall(".//cconfiguration") or root.findall(".//{*}cconfiguration")
    selected_nodes = [
        node for node in config_nodes
        if not configuration or _configuration_name(node).lower() == configuration.lower()
    ]
    if not selected_nodes and configuration:
        selected_nodes = [
            node for node in config_nodes
            if _configuration_name(node).lower().startswith(configuration.lower())
        ]
    if not selected_nodes:
        selected_nodes = config_nodes

    source_entries: list[_SourceEntry] = []
    include_paths: list[Path] = []
    for node in selected_nodes:
        for entry in node.findall(".//entry"):
            if entry.get("kind") != "sourcePath":
                continue
            name = (entry.get("name") or "").replace("\\", "/").strip("/")
            exclusions = tuple(part.strip("/") for part in (entry.get("excluding") or "").split("|") if part)
            if not name:
                source_entries.append(_SourceEntry(root=project_path, exclusions=exclusions))
                for linked_root in linked_resources.values():
                    source_entries.append(_SourceEntry(root=linked_root, exclusions=()))
                continue
            root_path = _resolve_workspace_path(name, project_path, repository_root, linked_resources)
            if root_path:
                source_entries.append(_SourceEntry(root=root_path, exclusions=exclusions))

        for option in node.findall(".//option"):
            if option.get("valueType") != "includePath":
                continue
            for value in option.findall("./listOptionValue"):
                resolved = _resolve_eclipse_path(value.get("value") or "", project_path, repository_root)
                if resolved:
                    include_paths.append(resolved)
    return tuple(dict.fromkeys(source_entries)), tuple(dict.fromkeys(include_paths))


def _configuration_name(node: ET.Element) -> str:
    settings = node.find("./storageModule[@moduleId='org.eclipse.cdt.core.settings']")
    if settings is None:
        settings = node.find("./{*}storageModule[@moduleId='org.eclipse.cdt.core.settings']")
    if settings is not None and settings.get("name"):
        return settings.get("name", "").strip()
    config = node.find(".//configuration")
    if config is None:
        config = node.find(".//{*}configuration")
    return config.get("name", "").strip() if config is not None else ""


def _resolve_workspace_path(
    value: str,
    project_path: Path,
    repository_root: Path,
    linked_resources: dict[str, Path],
) -> Path | None:
    if not value:
        return project_path
    parts = value.replace("\\", "/").split("/")
    for index in range(len(parts), 0, -1):
        prefix = "/".join(parts[:index])
        if prefix in linked_resources:
            suffix = Path(*parts[index:]) if index < len(parts) else Path()
            return (linked_resources[prefix] / suffix).resolve()
    candidate = repository_root / value
    if candidate.exists() or value.split("/")[0] in _KNOWN_WORKSPACE_ROOTS:
        return candidate.resolve()
    return (project_path / value).resolve()


def _resolve_eclipse_path(raw: str, project_path: Path, repository_root: Path) -> Path | None:
    value = raw.strip()
    if not value or value.startswith("virtual:") or value.startswith("${workspace_loc:/"):
        return None
    parent_match = re.match(r"PARENT-(\d+)-PROJECT_LOC(?:/(.*))?", value)
    if parent_match:
        levels = int(parent_match.group(1))
        suffix = parent_match.group(2) or ""
        base = project_path
        for _ in range(levels):
            base = base.parent
        return (base / suffix).resolve()
    if value.startswith("PROJECT_LOC"):
        suffix = value.removeprefix("PROJECT_LOC").lstrip("/\\")
        return (project_path / suffix).resolve()
    path = Path(value)
    if path.is_absolute():
        return path.resolve()
    project_candidate = (project_path / path).resolve()
    if project_candidate.exists():
        return project_candidate
    parts = [part for part in path.parts if part not in {".", ".."}]
    if parts:
        repository_candidate = (repository_root.joinpath(*parts)).resolve()
        if repository_candidate.exists():
            return repository_candidate
    return project_candidate


def _is_ignored(path: Path, repository_root: Path) -> bool:
    try:
        relative_parts = path.relative_to(repository_root).parts
    except ValueError:
        relative_parts = path.parts
    for part in relative_parts:
        lowered = part.lower()
        if lowered in _IGNORED_DIR_NAMES:
            return True
        if any(lowered.startswith(prefix) for prefix in _IGNORED_DIR_PREFIXES):
            return True
    return False
