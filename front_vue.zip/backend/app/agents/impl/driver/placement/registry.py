"""
@file registry.py
@author caoshwen
@brief Driver placement resolver registry for platform-specific placement

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from collections.abc import Callable

from ..build.registry import normalize_build_platform
from .base import DriverPlacementResolver


class DriverPlacementRegistry:
    """Resolve placement plugins without platform branches in the agent."""

    def __init__(self):
        self._factories: dict[str, Callable[[], DriverPlacementResolver]] = {}

    def register(self, platform: str, factory: Callable[[], DriverPlacementResolver]) -> None:
        self._factories[normalize_build_platform(platform)] = factory

    def create(self, platform: str | None) -> DriverPlacementResolver:
        canonical = normalize_build_platform(platform)
        factory = self._factories.get(canonical)
        if factory is None:
            raise ValueError(f"No driver placement resolver is registered for platform '{canonical}'")
        return factory()

    def is_registered(self, platform: str | None) -> bool:
        return normalize_build_platform(platform) in self._factories

    def platforms(self) -> tuple[str, ...]:
        return tuple(sorted(self._factories))


def _create_default_registry() -> DriverPlacementRegistry:
    from .stm32 import STM32DriverPlacementResolver

    registry = DriverPlacementRegistry()
    registry.register("stm32", STM32DriverPlacementResolver)
    return registry


driver_placement_registry = _create_default_registry()
