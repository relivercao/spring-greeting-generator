"""
@file __init__.py
@author caoshwen
@brief Driver placement resolver interfaces and default registry exports

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from .base import DriverPlacementResolver, PlacementRequest, PlacementResult
from .registry import DriverPlacementRegistry, driver_placement_registry

__all__ = [
    "DriverPlacementResolver",
    "PlacementRequest",
    "PlacementResult",
    "DriverPlacementRegistry",
    "driver_placement_registry",
]
