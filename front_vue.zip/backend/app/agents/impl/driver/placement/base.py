"""
@file base.py
@author caoshwen
@brief Platform-neutral driver placement contracts

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ..types import FileManifest


@dataclass(frozen=True)
class PlacementRequest:
    """Inputs required to locate generated driver files in a project."""

    project_path: str
    module_type: str
    module_name: str
    configuration: str | None = None
    header_filename: str = ""
    source_filename: str = ""
    config_filename: str | None = None
    test_filename: str | None = None
    driver_hint: str | None = None


@dataclass(frozen=True)
class PlacementResult:
    """Resolved manifest and deterministic evidence for the placement."""

    manifest: FileManifest
    evidence: tuple[str, ...] = field(default_factory=tuple)
    project_updates: tuple[str, ...] = field(default_factory=tuple)


class DriverPlacementResolver(ABC):
    """Resolve generated driver placement for one platform family."""

    @abstractmethod
    def resolve(self, request: PlacementRequest) -> PlacementResult:
        """Return a deterministic placement or raise ValueError with details."""
