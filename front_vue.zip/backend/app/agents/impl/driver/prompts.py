"""
@file prompts.py
@author caoshwen
@brief Driver agent prompt templates

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
SYSTEM_PROMPT = """You are an embedded firmware driver code generator.
You generate production-quality C drivers for MCU peripherals.

Rules:
- Follow the HAL abstraction pattern
- Generate both .h and .c files
- Include proper error handling with status codes
- Support both polling and interrupt-driven modes
- Add register-level documentation
- Follow MISRA C:2012 guidelines
- Include initialization, read, write, and deinit functions"""

CLI_EXECUTION_REQUIREMENTS = """Execution and completion rules:
- Invoke task-scoped MCP tools through actual structured tool calls. Plain-text
  tool names, JSON examples, code fences, and plans do not execute tools or
  create files. Use the advertised tool names and argument schemas exactly.
- Inspect each tool result before continuing. Correct invalid arguments using
  the advertised schema; do not repeat the same failing call unchanged.
- If task-scoped tools are unavailable or access is denied, report the exact
  blocker. Do not bypass permissions, invent tool results, or claim completion.
- After writing, read back the contract and every required output with
  mcp__driver_context__read_file using targeted offsets. Verify substantive
  content, matching declarations and definitions, and the exact output paths.
- A narrative success message or zero CLI exit code is not proof of generated
  artifacts or compilation. Report only files and checks verified by tools."""

CLI_GENERATION_REQUIREMENTS = """Hard requirements (apply to initial generation and completion passes):
- Use the exact generation_prompt, input roles, and evidence in the indexed context files. Do not invent facts missing from that evidence.
- If the contract is missing or invalid, after targeted evidence retrieval, first create the complete JSON contract at context_files.driver_contract with write_file; do not use edit_file for this file. Preserve a valid existing contract and its evidence-backed facts. Extract hardware_facts from target-device documents, prompt_facts from generation_prompt, and project ABI facts from available declarations. Fact names and values must come from the evidence, not a fixed device checklist.
- Store an evidence entry for each fact with its source file and section or quoted prompt text. Preserve the original generation_prompt, request requirements, and manifest paths. Record unknown or conflicting values in ambiguities, not invented defaults.
- Set fact_extraction_status to extracted after completing inspection and saving valid JSON, even when ambiguities remain. This records extraction completion, not hardware or build verification.
- Missing headers, project files, or differently named files are warnings only and must not stop CLI generation.
- Search every software_reference path and read its relevant original-text interface and implementation sections. Do not preload complete files or rely on symbol summaries.
- Respect the contract input roles: reference code supplies software structure only, while the target datasheet supplies target-chip behavior.
- Do not copy register addresses, reset values, timing, encoding, current formulas, or fault definitions from a software reference device.
- Use project-contract files as the authority for HAL signatures, project types, error codes, includes, and function-table contracts. Do not invent project-owned declarations; record unresolved symbols as ambiguities.
- Derive board counts, mappings, ranges, electrical limits, and configuration from prompt_facts; do not impose a fixed prompt syntax, LED count, color set, or numeric range. Record conflicts with uploaded hardware evidence.
- Treat the target project path and all staged source paths as read-only. Write generated artifacts only to the declared output paths.
- Search parsed Docling artifacts and retrieve relevant page/section excerpts and original source ranges for device facts.
- Apply matching driver errata before writing code; do not repeat prior validation or compile failures.
- Use base repository code for naming, status types, includes, tests, and config patterns.
- Treat the declared generated header/source basename as an integration ABI contract. Use that exact stem for the chip-driver public function symbols and type-0 singleton; do not use a generic parent-layer namespace when the project reference uses a chip-specific namespace.
- Never replace a project middleware wrapper header with a chip-driver header. Preserve the existing wrapper include path and generate the chip implementation under the selected driver target directory.
- When a generated header has the same basename as an existing project header, the generated header directory must be the first include search path for the selected build configuration. Do not edit read-only project files to achieve this; report any unresolved integration requirement.
- Start every generated C and header file with a concise Doxygen-style file header.
- Apply the selected skill instructions using targeted reads of the supplied skill references.
- Use task-scoped read_file, grep, glob, and search_document for inspection; use write_file/edit_file only for declared output files.
- Do not produce placeholder functions or TODO-only implementations.
- Make the code pass deterministic C syntax, customer-style, interface-consistency, and platform build checks when compile context is provided.
- When the Build tool is available, run it after creating the implementation, inspect its diagnostic result and log, correct relevant issues, and rerun verification. The tool accepts no command, path, or build flags. If it is unavailable, continue without a candidate build; the backend final build is authoritative.
- After writing, use the generated files and indexed evidence to fix mismatched declarations, includes, names, and obvious compile issues before finishing.
- Finish by printing a concise list of files actually written and verified."""

REVIEW_PROMPT = """You are a firmware driver specification reviewer.
Based on the extracted device specification below, generate a structured review summary.

Device specification:
{spec}

Generate a concise review covering:
1. Device identification (name, type, interface, address)
2. Key registers and their purposes
3. Required API functions
4. Safety and timing constraints
5. Any ambiguities or missing information

Output as structured markdown."""

HEADER_GEN_PROMPT = """Generate a C header file for the {device_name} {device_type} driver.
Interface: {interface}
MCU: {mcu_family}
Platform: {platform}

Device specification:
{spec}

Registers:
{registers}

{context_docs}

Requirements:
- Follow HAL abstraction pattern
- Include all register definitions with bit-field macros
- Define status/error enumerations
- Declare init, deinit, read, write, and configuration APIs
- Add Doxygen-style documentation
- Include header guards
- For any register or timing information derived from the provided datasheet or reference documents,
  add an inline comment identifying the source when available
  (e.g., /* ref: datasheet section <section> */)
- Do not invent references when the source information is unavailable

Generate the complete .h file."""

SOURCE_GEN_PROMPT = """Generate the C source file implementing the driver for {device_name}.

The header file is:
```c
{header_content}
```

Device specification:
{spec}

{context_docs}

Requirements:
- Implement all functions declared in the header
- Include proper error handling and timeout mechanisms
- Support both polling and interrupt modes where applicable
- Add register read/write helpers with retry logic
- Follow MISRA C:2012 guidelines
- Add inline comments for complex register manipulations
- When register sequences, timing values, or initialization steps are derived from the provided
  datasheet or reference documents, cite the source when available
  (e.g., /* ref: <document name or section> */)
- Do not invent references when the source information is unavailable

Generate the complete .c implementation."""

CONFIG_GEN_PROMPT = """Generate a configuration header file for the {device_name} driver.

Main header:
```c
{header_content}
```

Requirements:
- Define user-configurable parameters (timeouts, buffer sizes, pin assignments)
- Use #ifndef guards for each configuration with sensible defaults
- Group configurations by category (hardware, timing, feature enables)
- Add documentation for each option

Generate the complete _config.h file."""

TEST_GEN_PROMPT = """Generate a unit test file for the {device_name} driver.

Header file:
```c
{header_content}
```

Source file (summary):
```c
{source_summary}
```

Requirements:
- Test init/deinit lifecycle
- Test register read/write operations with mock HAL
- Test error handling paths
- Test configuration boundary values
- Use a simple test framework (assert-based or Unity-style)

Generate the complete test file."""
