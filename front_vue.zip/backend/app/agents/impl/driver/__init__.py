"""
@file __init__.py
@author caoshwen
@brief Driver Agent module initialization - provides driver generation and compilation support.

This module exports components for building, diagnosing, and repairing driver code in
embedded systems, including build execution, compilation diagnostics, automated repair
strategies, and context management for build workflows.

@version 1.0
@date 2026-07-22

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
# Core Agent - Primary entry point
from .agent import DriverAgent

# Core types needed by consumers
from .types import (
    DriverContext,
    FileManifest,
    GeneratedDriver,
    DriverResult,
    BuildResult,
    CompilationContext,
)

# Main workflow entry point
from .workflow import compile_driver

# Registry singletons (consumers need these for registration/lookup)
from .repair_registry import compile_repairer_registry
from .build import build_executor_registry, normalize_build_platform, UnsupportedBuildPlatformError
from .diagnostics import diagnostic_parser_registry

__all__ = [
    # Core Agent
    "DriverAgent",
    # Essential types
    "DriverContext",
    "FileManifest",
    "GeneratedDriver",
    "DriverResult",
    "BuildResult",
    "CompilationContext",
    # Main workflow
    "compile_driver",
    # Registries
    "compile_repairer_registry",
    "build_executor_registry",
    "diagnostic_parser_registry",
    # Utilities
    "normalize_build_platform",
    "UnsupportedBuildPlatformError",
]

# Note for consumers: Import specific submodules directly for advanced use:
#   - from .build import BuildExecutor, BuildExecutorConfig, ...
#   - from .diagnostics import DiagnosticParser, DiagnosticSet, ...
#   - from .parsers import parse_build_diagnostics, extract_error_pattern, ...
#   - from .repairer import ClaudeCliRepairer, CompileRepairer, ...
#   - from .prompts import SYSTEM_PROMPT, HEADER_GEN_PROMPT, ...
