"""Thread-safe, content-free activity snapshots for the Driver CLI."""

import json
import threading
import time
from datetime import datetime, timezone


_DRIVER_TOOLS = frozenset(
    f"mcp__driver_context__{name}"
    for name in ("read_file", "grep", "glob", "search_document", "write_file", "edit_file", "build")
)


class DriverCliRuntime:
    def __init__(self):
        self._lock = threading.Lock()
        self._started = time.monotonic()
        self._last_output = self._started
        self._output_bytes = 0
        self._tools = set()
        self._results = set()
        self._pending = {}
        self._last_tool = None
        self._failed_tools = 0
        self._initialization_seen = False
        self._driver_mcp_status = None
        self._registered_tools = set()
        self._assistant_events = 0
        self._stop_reasons = set()
        self._result_subtype = None
        self._result_is_error = None
        self._permission_denials = 0

    def observe(self, stream: str, content: str) -> None:
        now = time.monotonic()
        with self._lock:
            self._last_output = now
            self._output_bytes += len(content.encode("utf-8"))
            if stream != "stdout":
                return
            try:
                event = json.loads(content)
            except (TypeError, ValueError):
                return
            if not isinstance(event, dict):
                return
            if event.get("type") == "system" and event.get("subtype") == "init":
                self._initialization_seen = True
                tools = event.get("tools")
                if isinstance(tools, list):
                    for tool in tools:
                        name = tool.get("name") if isinstance(tool, dict) else tool
                        if isinstance(name, str) and name in _DRIVER_TOOLS:
                            self._registered_tools.add(name)
                servers = event.get("mcp_servers")
                if isinstance(servers, list):
                    for server in servers:
                        if isinstance(server, dict) and server.get("name") == "driver_context":
                            status = server.get("status")
                            self._driver_mcp_status = (
                                status if status in ("connected", "failed", "pending", "disabled", "needs-auth")
                                else "unknown"
                            )
                return
            if event.get("type") == "result":
                subtype = event.get("subtype")
                self._result_subtype = (
                    subtype if subtype in (
                        "success", "error_during_execution", "error_max_turns",
                        "error_max_budget_usd", "error_max_structured_output_retries",
                    ) else "unknown"
                )
                self._result_is_error = bool(event.get("is_error"))
                denials = event.get("permission_denials")
                if isinstance(denials, list):
                    self._permission_denials = len(denials)
                return
            if event.get("type") not in ("assistant", "user"):
                return
            message = event.get("message")
            if not isinstance(message, dict):
                return
            if event.get("type") == "assistant":
                self._assistant_events += 1
                reason = message.get("stop_reason")
                if reason in ("end_turn", "tool_use", "max_tokens", "stop_sequence", "pause_turn", "refusal"):
                    self._stop_reasons.add(reason)
            blocks = message.get("content")
            if not isinstance(blocks, list):
                return
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                if event.get("type") == "assistant" and block.get("type") == "tool_use":
                    tool_id = block.get("id")
                    if not tool_id or tool_id in self._tools:
                        continue
                    self._tools.add(tool_id)
                    self._last_tool = str(block.get("name") or "unknown")
                    self._pending[tool_id] = (self._last_tool, now)
                elif event.get("type") == "user" and block.get("type") == "tool_result":
                    tool_id = block.get("tool_use_id")
                    if tool_id not in self._tools or tool_id in self._results:
                        continue
                    self._results.add(tool_id)
                    self._pending.pop(tool_id, None)
                    self._failed_tools += int(bool(block.get("is_error")))

    def incomplete_failure_category(self) -> str | None:
        """Classify incomplete generation without treating narrative text as execution."""
        with self._lock:
            if self._permission_denials:
                return "cli_permission_denied"
            if self._tools:
                return None
            if self._initialization_seen and (
                self._driver_mcp_status not in (None, "connected")
                or not self._registered_tools
            ):
                return "cli_mcp_unavailable"
            if self._assistant_events:
                return "cli_no_tool_calls"
            return None

    def snapshot(self) -> dict:
        now = time.monotonic()
        with self._lock:
            return {
                "heartbeat_at": datetime.now(timezone.utc).isoformat(),
                "elapsed_seconds": round(max(0, now - self._started), 1),
                "silence_seconds": round(max(0, now - self._last_output), 1),
                "tool_calls": len(self._tools),
                "tool_results": len(self._results),
                "tool_errors": self._failed_tools,
                "last_tool": self._last_tool,
                "active_tools": [
                    {"name": name, "elapsed_seconds": round(max(0, now - started), 1)}
                    for name, started in self._pending.values()
                ],
                "output_bytes": self._output_bytes,
                "initialization_seen": self._initialization_seen,
                "driver_mcp_status": self._driver_mcp_status,
                "registered_driver_tools": sorted(self._registered_tools),
                "assistant_events": self._assistant_events,
                "stop_reasons": sorted(self._stop_reasons),
                "result_subtype": self._result_subtype,
                "result_is_error": self._result_is_error,
                "permission_denials": self._permission_denials,
            }
