"""
@file errata.py
@author caoshwen
@brief Persistent driver errata records for validation and compile feedback

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

import json
import re
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.driver_build_defaults import (
    DEFAULT_DRIVER_ERRATA_DIRECTORY,
    DRIVER_ERRATA_FILENAME,
    ERRATA_DEFAULT_SEARCH_LIMIT,
    ERRATA_FALLBACK_SYMPTOM_LENGTH,
    ERRATA_MAX_FILE_BYTES,
    ERRATA_MAX_SEARCH_LIMIT,
    ERRATA_TRIM_RETAIN_DIVISOR,
)


_ERRATA_FILE_LOCK = threading.Lock()


@dataclass
class DriverErrataRecord:
    """A single driver generation errata entry."""

    task_id: str
    device: str
    interface: str
    issue_type: str
    symptom: str
    fix_hint: str
    user_id: str | None = None
    evidence: str = ""
    confidence: str = "observed"
    source_files: list[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "device": self.device,
            "interface": self.interface,
            "issue_type": self.issue_type,
            "symptom": self.symptom,
            "fix_hint": self.fix_hint,
            "user_id": self.user_id,
            "evidence": self.evidence,
            "confidence": self.confidence,
            "source_files": self.source_files,
            "created_at": self.created_at,
        }


class DriverErrataStore:
    """Append-only JSONL store for driver errata."""

    def __init__(self, root: str | Path | None = None):
        self.root = Path(root or DEFAULT_DRIVER_ERRATA_DIRECTORY)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / DRIVER_ERRATA_FILENAME

    def append(self, record: DriverErrataRecord) -> None:
        self.append_many([record])

    def append_many(self, records: list[DriverErrataRecord]) -> None:
        if not records:
            return
        with _ERRATA_FILE_LOCK:
            self._enforce_size_limit()
            with self.path.open("a", encoding="utf-8") as fh:
                for record in records:
                    fh.write(json.dumps(record.to_dict(), ensure_ascii=False) + "\n")

    def search(
        self,
        query: str,
        limit: int | None = ERRATA_DEFAULT_SEARCH_LIMIT,
        user_id: str | None = None,
    ) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        try:
            safe_limit = (
                None if limit is None
                else min(max(int(limit), 0), ERRATA_MAX_SEARCH_LIMIT)
            )
        except (TypeError, ValueError):
            safe_limit = ERRATA_DEFAULT_SEARCH_LIMIT
        if safe_limit == 0:
            return []
        terms = [t.lower() for t in query.split() if t.strip()]
        if not terms:
            return []
        hits: list[tuple[int, dict[str, Any]]] = []
        with self.path.open("r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if record.get("user_id") != user_id:
                    continue
                haystack = " ".join(
                    str(record.get(k, ""))
                    for k in ("device", "interface", "issue_type", "symptom", "fix_hint", "evidence")
                ).lower()
                score = sum(1 for term in terms if term in haystack)
                if score > 0:
                    hits.append((score, record))
        hits.sort(key=lambda item: item[0], reverse=True)
        return [record for _, record in hits[:safe_limit]]

    def _enforce_size_limit(self) -> None:
        if not self.path.exists() or self.path.stat().st_size <= ERRATA_MAX_FILE_BYTES:
            return
        keep_bytes = ERRATA_MAX_FILE_BYTES // ERRATA_TRIM_RETAIN_DIVISOR
        with self.path.open("rb") as fh:
            fh.seek(max(self.path.stat().st_size - keep_bytes, 0))
            data = fh.read()
        first_newline = data.find(b"\n")
        if first_newline >= 0:
            data = data[first_newline + 1:]
        self.path.write_bytes(data)


def records_from_validation(
    task_id: str,
    device: str,
    interface: str,
    validation_report: Any,
    source_files: list[str],
    user_id: str | None = None,
) -> list[DriverErrataRecord]:
    records: list[DriverErrataRecord] = []
    safe_source_files = [_redact_sensitive(source_file) for source_file in source_files]
    for issue in getattr(validation_report, "issues", []):
        if getattr(issue, "severity", "") not in {"error", "warning"}:
            continue
        records.append(
            DriverErrataRecord(
                task_id=task_id,
                device=device,
                interface=interface,
                issue_type=f"validation_{issue.check}",
                symptom=_redact_sensitive(issue.message),
                fix_hint=_fix_hint_for_issue(issue.check, issue.message),
                user_id=user_id,
                evidence=_redact_sensitive(f"{issue.file or ''}:{issue.line or ''}".strip(":")),
                confidence="deterministic_check",
                source_files=safe_source_files,
            )
        )
    return records


def record_from_compile_failure(
    task_id: str,
    device: str,
    interface: str,
    build_log: str,
    source_files: list[str],
    user_id: str | None = None,
) -> DriverErrataRecord | None:
    if not build_log.strip():
        return None
    first_line = next(
        (line.strip() for line in build_log.splitlines() if line.strip()),
        build_log[:ERRATA_FALLBACK_SYMPTOM_LENGTH],
    )
    return DriverErrataRecord(
        task_id=task_id,
        device=device,
        interface=interface,
        issue_type="compile_error",
        symptom=_redact_sensitive(first_line),
        fix_hint="Use the build log to repair includes, types, declarations, and linker-visible symbols; re-run compile verification.",
        user_id=user_id,
        evidence=_redact_sensitive(build_log),
        confidence="compile_log",
        source_files=[_redact_sensitive(source_file) for source_file in source_files],
    )


def _fix_hint_for_issue(check: str, message: str) -> str:
    lower = message.lower()
    if check == "syntax":
        return "Run C syntax-only validation and repair diagnostics before the platform build."
    if "todo" in lower or "placeholder" in lower:
        return "Replace placeholder implementation with production behavior based on datasheet/base code."
    if "header declares" in lower:
        return "Make header declarations and source definitions match exactly."
    if "include" in lower:
        return "Include the module's own header first and add only required project headers."
    if "heap" in lower:
        return "Remove dynamic memory and use caller-provided buffers or static configuration."
    return "Apply customer code-style rules and re-run deterministic validation."


def _redact_sensitive(text: str) -> str:
    redacted = re.sub(r"(?i)(authorization\s*[:=]\s*bearer\s+)[^\s]+", r"\1***", text)
    redacted = re.sub(r"(?i)(token|password|secret)\s*[:=]\s*[^\s]+", r"\1=***", redacted)
    redacted = re.sub(r"gh[pousr]_[A-Za-z0-9_]+", "gh*_***", redacted)
    return redacted
