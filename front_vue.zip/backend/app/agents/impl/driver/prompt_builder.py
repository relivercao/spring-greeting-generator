"""
@file prompt_builder.py
@author caoshwen
@brief Optimized prompt builders for LLM-based compilation fixes

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
import logging
from typing import List, Dict

from app.core.driver_build_defaults import (
    BALANCED_PROMPT_MAX_ATTEMPT,
    BASIC_PROMPT_DIAGNOSTIC_LIMIT,
    DEFAULT_CRITICAL_DIAGNOSTIC_LIMIT,
    DEFAULT_HISTORY_SUMMARY_WINDOW,
    DETAILED_PROMPT_MAX_ATTEMPT,
    PROMPT_PATTERN_LOCATION_LIMIT,
)

from .types import BuildError, CompressionLevel
from .context import CompilationContextManager
from .parsers import group_errors_by_pattern, select_critical_errors

logger = logging.getLogger(__name__)


class PromptBuilder:
    """
    Basic Prompt Builder for compilation error fixes.

    Use this for:
    - Initial compilation attempts where context is minimal
    - Simple error scenarios with few diagnostics
    - When LLM token budget is not a concern

    This builder provides a straightforward error list with full driver source code.
    It does not compress errors, track history, or provide context-aware suggestions.
    Suitable for early attempts (1-2) where detailed information helps the LLM understand
    the codebase structure.
    """

    def build_fix_prompt(
        self,
        errors: List[BuildError],
        driver_files: Dict[str, str],
        attempt: int
    ) -> str:
        """Build basic fix prompt"""

        # Validate driver_files
        self._validate_driver_files(driver_files)

        error_list = []
        for i, error in enumerate(errors[:BASIC_PROMPT_DIAGNOSTIC_LIMIT], 1):
            error_list.append(
                f"{i}. {error.file}:{error.line} - {error.message}"
            )

        prompt = f"""Fix embedded C driver compilation errors.

## Errors ({len(errors)} total, showing top {BASIC_PROMPT_DIAGNOSTIC_LIMIT})
{chr(10).join(error_list)}

## Files

### Header File
```c
{driver_files.get('header', '')}
```

### Source File
```c
{driver_files.get('source', '')}
```

## Task
Fix the compilation errors by modifying the driver files.

**Important Guidelines:**
1. Only fix the specific errors listed above
2. Do NOT change the overall structure or functionality
3. Ensure all HAL APIs are correctly included
4. Check for missing #include statements
5. Verify variable declarations and types
6. Fix syntax errors

## Output Format

Return the fixed files in this format:

### FILE: header
```c
// Fixed header content
```

### FILE: source
```c
// Fixed source content
```
"""
        return prompt

    def _validate_driver_files(self, driver_files: Dict[str, str]) -> None:
        """
        Validate that driver_files contains required keys.

        Args:
            driver_files: Dictionary containing driver file contents

        Raises:
            ValueError: If both 'header' and 'source' keys are missing
        """
        if not driver_files:
            raise ValueError("driver_files dictionary is empty")

        has_header = 'header' in driver_files and driver_files['header']
        has_source = 'source' in driver_files and driver_files['source']

        if not has_header and not has_source:
            raise ValueError(
                "driver_files must contain at least one of 'header' or 'source' keys with non-empty content"
            )

        if not has_header:
            logger.warning("driver_files missing 'header' key - prompt will have empty header section")
        if not has_source:
            logger.warning("driver_files missing 'source' key - prompt will have empty source section")


class OptimizedPromptBuilder:
    """
    Optimized Prompt Builder with compression and context awareness.

    Use this for:
    - Later compilation attempts (3+) where context accumulates
    - Complex error scenarios with many diagnostics
    - When LLM token budget needs management

    Key differences from PromptBuilder:
    - Adaptive compression: errors grouped by pattern in later attempts
    - Historical context: tracks previous failures and suggests fixes
    - Smart filtering: prioritizes critical errors over noise
    - Context consumption: reduces token usage by 40-60% in late attempts

    Compression levels:
    - DETAILED (attempts 1-2): Full error details with code context
    - BALANCED (attempts 3-4): Critical errors only, compressed history
    - COMPRESSED (attempts 5+): Error patterns, sliding window summary
    """

    def __init__(self):
        self.max_errors_shown = DEFAULT_CRITICAL_DIAGNOSTIC_LIMIT
        self.history_window_size = DEFAULT_HISTORY_SUMMARY_WINDOW
        self.use_compressed_history = True

    def build_prompt(
        self,
        errors: List[BuildError],
        driver_files: Dict[str, str],
        context_manager: CompilationContextManager,
        attempt: int
    ) -> str:
        """Build optimized prompt"""

        # Validate driver_files
        self._validate_driver_files(driver_files)

        # Determine compression level
        compression_level = self._get_compression_level(attempt, len(errors))

        # Select critical errors
        if compression_level == CompressionLevel.COMPRESSED:
            # Compressed mode: group by pattern
            error_groups = group_errors_by_pattern(errors)
            error_section = self._format_error_patterns(error_groups)
        else:
            # Detailed/Balanced mode: select critical errors
            critical_errors = select_critical_errors(
                errors,
                max_count=self.max_errors_shown
            )
            error_section = self._format_errors(
                critical_errors,
                include_context=(compression_level == CompressionLevel.DETAILED)
            )

        # Compress history
        if compression_level == CompressionLevel.COMPRESSED:
            history_text = context_manager.get_sliding_window_summary(
                window_size=self.history_window_size
            )
        else:
            history_text = context_manager.get_compressed_summary()

        # Generate suggestions
        suggestions = context_manager.generate_smart_suggestions()

        # Assemble prompt
        prompt = self._assemble_prompt(
            error_section=error_section,
            files=driver_files,
            history=history_text,
            suggestions=suggestions,
            attempt=attempt,
            compression_level=compression_level
        )

        return prompt

    def _get_compression_level(self, attempt: int, error_count: int) -> CompressionLevel:
        """Determine compression level based on attempt number"""
        if attempt <= DETAILED_PROMPT_MAX_ATTEMPT:
            return CompressionLevel.DETAILED
        elif attempt <= BALANCED_PROMPT_MAX_ATTEMPT:
            return CompressionLevel.BALANCED
        else:
            return CompressionLevel.COMPRESSED

    def _format_error_patterns(self, error_groups: Dict[str, dict]) -> str:
        """Format error patterns (compressed mode)"""
        lines = []
        for i, (pattern, info) in enumerate(error_groups.items(), 1):
            locations = ', '.join(info['locations'][:PROMPT_PATTERN_LOCATION_LIMIT])
            if len(info['locations']) > PROMPT_PATTERN_LOCATION_LIMIT:
                locations += (
                    f" ... and {len(info['locations']) - PROMPT_PATTERN_LOCATION_LIMIT} more"
                )

            lines.append(
                f"{i}. {info['example_message']} ({info['count']} occurrences)\n"
                f"   Locations: {locations}"
            )
        return '\n'.join(lines)

    def _format_errors(
        self,
        errors: List[BuildError],
        include_context: bool
    ) -> str:
        """Format error list"""
        lines = []
        for i, error in enumerate(errors, 1):
            line = f"{i}. {error.file}:{error.line} - {error.message}"
            if include_context and error.context:
                line += f"\n{error.context}"
            lines.append(line)
        return '\n'.join(lines)

    def _assemble_prompt(
        self,
        error_section: str,
        files: Dict[str, str],
        history: str,
        suggestions: str,
        attempt: int,
        compression_level: CompressionLevel
    ) -> str:
        """Assemble final prompt"""

        # Build history section
        history_section = ""
        if history:
            history_section = f"""
## Compilation History

{history}

## Suggestions

{suggestions}
"""

        # Build prompt
        prompt = f"""Fix embedded C driver compilation errors (Attempt {attempt}).

## Current Errors

{error_section}

{history_section}

## Driver Files

### Header File
```c
{files.get('header', '')}
```

### Source File
```c
{files.get('source', '')}
```

## Task

Fix the compilation errors by modifying the driver files.

**Guidelines:**
1. Focus on the error patterns shown above
2. Ensure all HAL APIs are correctly included
3. Check for missing #include statements
4. Verify variable declarations and types
5. Fix syntax errors
6. Do NOT change the overall structure unnecessarily

## Output Format

Return the fixed files in this exact format:

### FILE: header
```c
// Fixed header content
```

### FILE: source
```c
// Fixed source content
```
"""
        return prompt

    def _validate_driver_files(self, driver_files: Dict[str, str]) -> None:
        """
        Validate that driver_files contains required keys.

        Args:
            driver_files: Dictionary containing driver file contents

        Raises:
            ValueError: If both 'header' and 'source' keys are missing
        """
        if not driver_files:
            raise ValueError("driver_files dictionary is empty")

        has_header = 'header' in driver_files and driver_files['header']
        has_source = 'source' in driver_files and driver_files['source']

        if not has_header and not has_source:
            raise ValueError(
                "driver_files must contain at least one of 'header' or 'source' keys with non-empty content"
            )

        if not has_header:
            logger.warning("driver_files missing 'header' key - prompt will have empty header section")
        if not has_source:
            logger.warning("driver_files missing 'source' key - prompt will have empty source section")

