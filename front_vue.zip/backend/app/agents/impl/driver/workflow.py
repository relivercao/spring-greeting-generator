"""
@file workflow.py
@author caoshwen
@brief Main entry point for driver compilation with automatic error fixing.

@version 1.0
@date 2026-07-21

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""

from loguru import logger

from app.core.driver_build_defaults import (
    DRIVER_COMPILE_PROGRESS_END,
    DRIVER_COMPILE_PROGRESS_START,
)

from .types import CompilationContext
from .build import BuildExecutorConfig, build_executor_registry, normalize_build_platform
from .fix_loop import CompileFixLoop
from .repair_registry import compile_repairer_registry


async def compile_driver(
    context: CompilationContext,
) -> CompilationContext:
    """
    Compile driver code with automatic error fixing

    Flow:
    1. Integrate driver files to project
    2. Execute the registered platform build
    3. If failed, invoke the registered repairer up to the configured attempt limit
    4. Return compilation result

    Args:
        context: Compilation context with driver files and project path

    Returns:
        Updated context with build results
    """
    logger.info("Starting driver compilation")

    platform = normalize_build_platform(context.platform)
    executor = build_executor_registry.create(
        BuildExecutorConfig(
            platform=platform,
            tool_path=context.resolved_build_tool_path,
        )
    )

    # Initialize fix loop
    fix_loop = CompileFixLoop(
        executor=executor,
        max_attempts=context.max_attempts,
        repairer=compile_repairer_registry.create(platform),
    )

    # Execute compilation with auto-fix
    build_result = await fix_loop.compile_with_auto_fix(context)

    # Update context
    context.firmware_path = build_result.firmware_path
    context.build_success = build_result.success
    context.build_log = "\n".join(part for part in [build_result.stdout, build_result.stderr] if part)
    context.build_attempts = build_result.attempt

    # Update progress
    if build_result.success:
        context.progress = DRIVER_COMPILE_PROGRESS_END
    else:
        attempt_limit = max(context.max_attempts, 1)
        attempt_ratio = min(max(build_result.attempt, 0) / attempt_limit, 1.0)
        progress_span = DRIVER_COMPILE_PROGRESS_END - DRIVER_COMPILE_PROGRESS_START
        context.progress = DRIVER_COMPILE_PROGRESS_START + attempt_ratio * progress_span

    # Log final result
    if build_result.success:
        logger.info(
            "Driver compilation succeeded: firmware={}, attempts={}",
            build_result.firmware_path,
            build_result.attempt,
        )
    else:
        logger.warning(
            "Driver compilation failed: attempts={}, errors={}",
            build_result.attempt,
            len(build_result.errors),
        )
        if context.fix_history:
            persistent = context.get_persistent_errors()
            if persistent:
                logger.warning("Persistent build errors: {}", ", ".join(persistent))
    logger.info("Driver compilation progress: {:.1f}%", context.progress)

    return context
