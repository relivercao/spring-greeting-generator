"""
@file repairer.py
@author caoshwen
@brief Compile repair abstractions and Claude CLI repair implementation

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

import asyncio
import difflib
import json
import shutil
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from loguru import logger

from app.core.config import get_resolved_cli_path, get_settings, resolve_claude_cli_model
from app.core.driver_build_defaults import (
    DEFAULT_DRIVER_BUILD_PLATFORM,
    PROCESS_NOT_STARTED_RETURN_CODE,
    PROCESS_EXIT_WAIT_SECONDS,
)
from app.utils.claude_cli_monitor import (
    ClaudeCliMonitor,
    kill_cli_by_task_id,
    register_task_cancellation,
)

from .build.session import IsolatedBuildSession, ProjectSnapshot
from .cli_tools import execute_scoped_cli
from .types import BuildResult, CompilationContext, ManifestScope


# Keep repair turns shell-free while allowing the CLI to discover and inspect
# repository interfaces. Grep searches file contents and Glob discovers file
# paths; neither tool grants write or arbitrary command execution capability.
# Disk-diff-only exemptions; explicit CLI Edit/Write calls remain unauthorized.
_VOLATILE_BUILD_METADATA_PATHS = frozenset({".settings/language.settings.xml"})


@dataclass
class RepairResult:
    """Result of one bounded repair operation.

    ``applied`` means that the CLI applied an allowlisted file change. It does
    not mean that the project compiled; only the Python-controlled build loop
    can set the terminal build result to successful.

    In audit payloads written by ``_complete_repair``, ``success`` means that
    compilation was verified. For callers, ``success``/``applied`` means only
    that a file change was made, not necessarily that compilation passed.
    """

    applied: bool
    changed_files: list[str] = field(default_factory=list)
    diff: str = ""
    failure_category: Optional[str] = None
    message: str = ""
    cli_exit_code: Optional[int] = None
    compile_verified: bool = False

    @property
    def success(self) -> bool:
        """Compatibility alias for ``applied``, not compilation success.

        Use ``applied`` to check whether a file change was made and
        ``compile_verified`` to check whether compilation passed.
        """
        return self.applied


class CompileRepairer(ABC):
    """Repair generated files inside an isolated build session."""

    @abstractmethod
    async def repair(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
        build_result: BuildResult,
        attempt: int,
    ) -> RepairResult:
        """Apply one repair attempt and return validated changes."""


class ClaudeCliRepairer(CompileRepairer):
    """Use the project-local Claude CLI to repair only manifest files."""

    def __init__(
        self,
        monitor: Optional[ClaudeCliMonitor] = None,
        runner: Optional[Callable[..., dict[str, Any]]] = None,
    ):
        self._monitor = monitor or ClaudeCliMonitor()
        self._runner = runner or self._monitor.execute_with_prodding
        self._session_ids: dict[str, str] = {}

    @staticmethod
    def _session_key(context: CompilationContext, working_root: Path) -> str:
        """Return a stable key for one compile-repair conversation."""
        return context.task_id or str(working_root.resolve())

    def reset_session(self, context: CompilationContext, working_root: Path | None = None) -> None:
        """Forget the persisted CLI session after a terminal build outcome."""
        key = context.task_id
        if not key and working_root is not None:
            key = str(working_root.resolve())
        if key:
            self._session_ids.pop(key, None)

    async def repair(
        self,
        session: IsolatedBuildSession,
        context: CompilationContext,
        build_result: BuildResult,
        attempt: int,
    ) -> RepairResult:
        allowed_paths = list(dict.fromkeys(
            path.replace("\\", "/") for path in context.allowed_write_paths
        ))
        if not allowed_paths:
            return RepairResult(False, failure_category="no_allowed_files", message="No repair files are allowed")

        manifest_scope = _manifest_scope(context)
        working_root = (
            session.isolated_source_root
            if manifest_scope == ManifestScope.REPOSITORY
            else session.project_path
        )
        session_key = self._session_key(context, working_root)
        cli_session_id = self._session_ids.get(session_key)
        if cli_session_id is None:
            cli_session_id = str(uuid.uuid4())
        repair_context_path = self._write_repair_context(
            session,
            context,
            build_result,
            attempt,
            allowed_paths,
        )
        snapshot: Optional[ProjectSnapshot] = None
        cli_result: Optional[dict[str, Any]] = None
        runner_task: Optional[asyncio.Task] = None
        allowed_dirs: list[str] = []
        try:
            try:
                snapshot = session.create_snapshot(
                    allowed_paths,
                    manifest_scope,
                )
            except (OSError, shutil.Error, ValueError) as exc:
                exception_type = type(exc).__name__
                logger.exception(
                    "Could not create CLI repair snapshot on attempt {}: {}: {!r}",
                    attempt,
                    exception_type,
                    exc,
                )
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        failure_category="repair_snapshot_failed",
                        message=f"{exception_type}: {exc!r}",
                    ),
                )

            prompt = self._build_prompt(
                context,
                attempt,
                allowed_paths,
                repair_context_path,
            )
            settings = get_settings()
            timeout, activity_timeout = self._compute_repair_timeout(context)
            # Keep the CLI's filesystem grant limited to the isolated build tree
            # and the one short-lived diagnostics directory. Resolve both roots
            # before handing them to Claude so a relative path or a symlink cannot
            # silently widen the Grep/Glob search scope.
            allowed_dirs = self._repair_allowed_dirs(working_root, repair_context_path.parent)
            tool_config = {
                "output_root": str(working_root.resolve()),
                "search_roots": [str(working_root.resolve())],
                "readable_files": [str(repair_context_path.resolve())],
                "writable_files": [str(working_root / path) for path in allowed_paths],
            }
            runner_task = asyncio.create_task(
                asyncio.to_thread(
                    execute_scoped_cli, self._runner, tool_config,
                    cli_path=get_resolved_cli_path(),
                    prompt=prompt,
                    system_prompt=(
                        "You repair generated embedded C driver files inside an isolated workspace. "
                        "Use the built-in Read, Grep, and Glob tools to inspect the isolated workspace. "
                        "Use only the task-scoped mcp__driver_context__ edit_file and write_file tools to modify files. "
                        "Read the repair context before editing, "
                        "modify only allowlisted files, and do not run commands. This is a persistent "
                        "repair conversation: Python performs compilation between turns. Never treat "
                        "your own exit status or a textual claim as compile success; only the final "
                        "Python target-configuration build can establish success."
                    ),
                    model=resolve_claude_cli_model(settings),
                    working_dir=working_root,
                    timeout=timeout,
                    activity_timeout=activity_timeout,
                    unlimited_timeout=True,
                    bypass_permissions=False,
                    allowed_dirs=allowed_dirs,
                    tools_enabled=True,
                    allowed_tools=None,
                    max_total_tokens=0,
                    max_tool_calls=0,
                    task_id=context.task_id,
                    # Compile repair must not resume the generation conversation.
                    # It runs in the target repository, which is a different
                    # Claude project namespace from the generation output dir.
                    claude_session_id=cli_session_id,
                    resume_session=session_key in self._session_ids,
                    session_scope="compile_repair",
                )
            )
            cli_result = await asyncio.shield(runner_task)
            returned_session_id = cli_result.get("session_id") if isinstance(cli_result, dict) else None
            if isinstance(returned_session_id, str) and returned_session_id:
                cli_session_id = returned_session_id
            succeeded = (
                cli_result.get("status") == "success"
                and cli_result.get("exit_code", PROCESS_NOT_STARTED_RETURN_CODE) == 0
            )
            if not succeeded:
                self._session_ids.pop(session_key, None)
                session.restore(snapshot)
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        failure_category=cli_result.get("failure_category") or "cli_failure",
                        cli_exit_code=cli_result.get("exit_code"),
                        message=str(cli_result.get("error") or "Claude CLI repair failed"),
                    ),
                )

            try:
                validation = session.validate_changes(
                    snapshot,
                    allowed_paths,
                    scope=manifest_scope,
                )
                unauthorized_read_tool_paths = self._unauthorized_read_tool_paths(
                    cli_result,
                    allowed_dirs,
                    working_root,
                )
                unauthorized_tool_paths = self._unauthorized_write_tool_paths(
                    cli_result,
                    session,
                    allowed_paths,
                    manifest_scope,
                    working_root,
                )
                unauthorized_disk_paths = self._unauthorized_disk_paths(
                    validation.unauthorized_paths,
                    context.platform,
                    # No compiler runs while the CLI repair turn is active, so a
                    # metadata diff at this point cannot be attributed to the
                    # build and must not be exempted.
                    allow_volatile_metadata=False,
                )
            except (OSError, ValueError) as exc:
                self._session_ids.pop(session_key, None)
                session.restore(snapshot)
                context.rolled_back = True
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        failure_category="repair_validation_failed",
                        cli_exit_code=cli_result.get("exit_code"),
                        message=f"Could not validate the complete repair diff: {exc}",
                    ),
                )
            if unauthorized_disk_paths or unauthorized_tool_paths or unauthorized_read_tool_paths:
                self._session_ids.pop(session_key, None)
                session.restore(snapshot)
                context.rolled_back = True
                escaped_paths = (
                    set(unauthorized_disk_paths)
                    | set(unauthorized_tool_paths)
                    | set(unauthorized_read_tool_paths)
                )
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        changed_files=validation.changed_paths,
                        failure_category="unsafe_repair_failure",
                        cli_exit_code=cli_result.get("exit_code"),
                        message=(
                            "CLI repair accessed or changed a path outside the isolated repair scope: "
                            + ", ".join(sorted(escaped_paths))
                        ),
                    ),
                )

            if not self._used_tool_on_path(cli_result, "Read", repair_context_path, working_root):
                self._session_ids.pop(session_key, None)
                session.restore(snapshot)
                context.rolled_back = bool(validation.changed_paths)
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        failure_category="repair_context_not_read",
                        cli_exit_code=cli_result.get("exit_code"),
                        message="CLI did not read the required compile diagnostics context",
                    ),
                )

            if not self._used_any_tool(cli_result, {"Edit", "Write"}):
                self._session_ids.pop(session_key, None)
                session.restore(snapshot)
                context.rolled_back = bool(validation.changed_paths)
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        failure_category="repair_edit_not_observed",
                        cli_exit_code=cli_result.get("exit_code"),
                        message="CLI did not use Edit or Write to repair an allowlisted file",
                    ),
                )

            if not validation.changed_paths:
                self._session_ids.pop(session_key, None)
                return self._complete_repair(
                    context,
                    attempt,
                    repair_context_path,
                    cli_result,
                    RepairResult(
                        False,
                        failure_category="no_effective_change",
                        cli_exit_code=cli_result.get("exit_code"),
                        message="CLI repair produced no file changes",
                    ),
                )

            changed_paths = self._manifest_changed_paths(
                session,
                validation.changed_paths,
                allowed_paths,
                manifest_scope,
            )
            self._session_ids[session_key] = cli_session_id
            return self._complete_repair(
                context,
                attempt,
                repair_context_path,
                cli_result,
                RepairResult(
                    True,
                    changed_files=changed_paths,
                    diff=self._build_diff(snapshot, session, changed_paths, manifest_scope),
                    cli_exit_code=cli_result.get("exit_code"),
                    compile_verified=False,
                    message="CLI changes applied; awaiting Python build verification",
                ),
            )
        except asyncio.CancelledError:
            self._session_ids.pop(session_key, None)
            if context.task_id:
                register_task_cancellation(context.task_id)
                kill_cli_by_task_id(context.task_id)
            if runner_task is not None and not runner_task.done():
                try:
                    cli_result = await asyncio.wait_for(
                        asyncio.shield(runner_task),
                        timeout=PROCESS_EXIT_WAIT_SECONDS,
                    )
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass
            if snapshot is not None:
                session.restore(snapshot)
            context.rolled_back = True
            self._complete_repair(
                context,
                attempt,
                repair_context_path,
                cli_result,
                RepairResult(
                    False,
                    failure_category="cancelled",
                    cli_exit_code=cli_result.get("exit_code") if cli_result else None,
                    message="CLI repair cancelled",
                ),
            )
            raise
        except Exception as exc:
            self._session_ids.pop(session_key, None)
            if snapshot is not None:
                session.restore(snapshot)
            exception_type = type(exc).__name__
            logger.exception(
                "CLI repair raised an exception on attempt {}: {}: {!r}",
                attempt,
                exception_type,
                exc,
            )
            return self._complete_repair(
                context,
                attempt,
                repair_context_path,
                cli_result,
                RepairResult(
                    False,
                    failure_category="repair_exception",
                    cli_exit_code=cli_result.get("exit_code") if cli_result else None,
                    message=f"{exception_type}: {exc!r}",
                ),
            )
        finally:
            if snapshot is not None:
                session.discard_snapshot(snapshot)
            repair_context_path.unlink(missing_ok=True)
            try:
                repair_context_path.parent.rmdir()
            except OSError:
                pass

    @staticmethod
    def _complete_repair(
        context: CompilationContext,
        attempt: int,
        repair_context_path: Path,
        cli_result: Optional[dict[str, Any]],
        repair_result: RepairResult,
    ) -> RepairResult:
        """Persist complete repair evidence outside the isolated build session."""
        if not context.artifact_dir:
            return repair_result
        try:
            audit_dir = Path(context.artifact_dir).resolve() / "repair_logs"
            audit_dir.mkdir(parents=True, exist_ok=True)
            prefix = f"attempt-{attempt}"
            if repair_context_path.is_file():
                (audit_dir / f"{prefix}-context.json").write_text(
                    repair_context_path.read_text(encoding="utf-8", errors="replace"),
                    encoding="utf-8",
                )
            if cli_result is not None:
                (audit_dir / f"{prefix}-cli.json").write_text(
                    json.dumps(cli_result, indent=2, ensure_ascii=True, default=str),
                    encoding="utf-8",
                )
            result_payload = {
                "success": repair_result.compile_verified,
                "applied": repair_result.applied,
                "compile_verified": repair_result.compile_verified,
                "cli_exit_code": repair_result.cli_exit_code,
                "failure_category": repair_result.failure_category,
                "message": repair_result.message,
                "changed_files": repair_result.changed_files,
            }
            (audit_dir / f"{prefix}-result.json").write_text(
                json.dumps(result_payload, indent=2, ensure_ascii=True),
                encoding="utf-8",
            )
            if repair_result.diff:
                (audit_dir / f"{prefix}.diff").write_text(
                    repair_result.diff + "\n",
                    encoding="utf-8",
                )
        except OSError as exc:
            logger.warning("Failed to persist CLI repair audit for attempt {}: {}", attempt, exc)
        return repair_result

    @staticmethod
    def _build_prompt(
        context: CompilationContext,
        attempt: int,
        allowed_paths: list[str],
        repair_context_path: Path,
    ) -> str:
        allowed = "\n".join(f"- {path}" for path in allowed_paths)
        return f"""Repair the embedded C driver compilation errors in this isolated workspace.

Attempt: {attempt}/{context.max_attempts}

This is one turn in a persistent repair conversation. Python runs the build
between turns and will provide fresh diagnostics in a new context file. Use
the prior conversation as history, but always read the latest context first.

Required first action:
- Use mcp__driver_context__read_file on `{repair_context_path}`; search and continue through relevant diagnostic ranges.
- Read the relevant allowlisted source files before editing them.

Allowed files:
{allowed}

Constraints:
- Fix only errors caused by the generated driver.
- After reading the diagnostics and relevant source, make a concrete
  Edit or Write to an allowlisted file in this turn; do not finish with
  inspection-only output when a repairable compiler error is present.
- Use only task-scoped read_file, edit_file, write_file, grep, and glob. Keep
  searches under the isolated workspace or the provided repair-context
  directory; paths outside those roots are rejected by the backend.
- Modify only files from the allowed file list.
- Do not invoke Bash, builds, tests, web access, or other tools.
- Make the smallest source change that addresses the reported root cause.
- Inspect existing repository headers and symbols with Read before inventing
  an include or API name.
- Do not claim that compilation succeeded. The Python build result is the only
  authoritative compilation verdict.
- Do not edit the repair context file.
- Finish with a concise summary; the backend validates the actual file diff.
"""

    @staticmethod
    def _successful_tool_uses(result: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
        requests: dict[str, tuple[str, dict[str, Any]]] = {}
        successful_ids: set[str] = set()
        output = result.get("output")
        if not isinstance(output, str):
            return []
        for line in output.splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            message = event.get("message")
            if not isinstance(message, dict):
                continue
            for item in message.get("content", []):
                if not isinstance(item, dict):
                    continue
                if event.get("type") == "assistant" and item.get("type") == "tool_use":
                    tool_use_id = item.get("id")
                    tool_input = item.get("input", {})
                    if isinstance(tool_use_id, str) and isinstance(tool_input, dict):
                        name = str(item.get("name", ""))
                        normalized = {
                            "read_file": "Read", "write_file": "Write", "edit_file": "Edit",
                            "grep": "Grep", "glob": "Glob", "search_document": "Read",
                        }
                        if name.startswith("mcp__driver_context__"):
                            name = normalized.get(name.rsplit("__", 1)[-1], name)
                            tool_input = dict(tool_input, file_path=tool_input.get("path"))
                        requests[tool_use_id] = (name, tool_input)
                elif event.get("type") == "user" and item.get("type") == "tool_result":
                    tool_use_id = item.get("tool_use_id")
                    if isinstance(tool_use_id, str) and not item.get("is_error", False):
                        successful_ids.add(tool_use_id)
        return [requests[tool_use_id] for tool_use_id in successful_ids if tool_use_id in requests]

    @classmethod
    def _used_any_tool(cls, result: dict[str, Any], names: set[str]) -> bool:
        return any(name in names for name, _ in cls._successful_tool_uses(result))

    @staticmethod
    def _unauthorized_disk_paths(
        paths: list[str],
        platform: str,
        *,
        allow_volatile_metadata: bool = True,
    ) -> list[str]:
        """Filter known Eclipse metadata changes outside an active repair turn."""
        if (
            not allow_volatile_metadata
            or not platform.strip().casefold().startswith(DEFAULT_DRIVER_BUILD_PLATFORM)
        ):
            return list(paths)
        return [
            path
            for path in paths
            if path.replace("\\", "/") not in _VOLATILE_BUILD_METADATA_PATHS
        ]

    @staticmethod
    def _repair_allowed_dirs(working_root: Path, repair_context_dir: Path) -> list[str]:
        """Return the exact filesystem roots granted to the repair CLI."""
        roots: list[str] = []
        for raw_root in (working_root, repair_context_dir):
            root = Path(raw_root).resolve()
            if not root.is_dir():
                raise FileNotFoundError(f"Repair CLI allowlisted directory does not exist: {root}")
            value = str(root)
            if value not in roots:
                roots.append(value)
        return roots

    @staticmethod
    def _path_is_under(path: Path, roots: list[Path]) -> bool:
        """Return whether a resolved path is inside one of ``roots``."""
        for root in roots:
            try:
                path.relative_to(root)
                return True
            except ValueError:
                continue
        return False

    @classmethod
    def _unauthorized_read_tool_paths(
        cls,
        result: dict[str, Any],
        allowed_dirs: list[str],
        working_root: Path,
    ) -> list[str]:
        """Reject successful Read/Grep/Glob calls that escaped the CLI roots.

        The task MCP server rejects paths before access. This audit independently
        checks successful tool events before accepting the final repair diff.
        """
        roots = [Path(directory).resolve() for directory in allowed_dirs]
        unauthorized: list[str] = []
        path_keys = {
            "Read": ("file_path",),
            "Grep": ("path", "file_path"),
            "Glob": ("path", "file_path"),
        }
        for name, tool_input in cls._successful_tool_uses(result):
            keys = path_keys.get(name)
            if not keys:
                continue
            raw_path = next((tool_input.get(key) for key in keys if key in tool_input), None)
            if raw_path in (None, "") and name == "Glob":
                pattern = tool_input.get("pattern")
                if isinstance(pattern, str):
                    pattern_path = Path(pattern)
                    if pattern_path.is_absolute() or ".." in pattern_path.parts:
                        raw_path = pattern
            if raw_path in (None, "") and name == "Grep":
                glob_filter = tool_input.get("glob")
                if isinstance(glob_filter, str):
                    glob_path = Path(glob_filter)
                    if glob_path.is_absolute() or ".." in glob_path.parts:
                        raw_path = glob_filter
            # Grep/Glob default to the process working directory when no path
            # is supplied.  That directory is explicitly allowlisted.
            if raw_path is None or raw_path == "":
                if name == "Read":
                    unauthorized.append("Read:<missing-file-path>")
                continue
            if not isinstance(raw_path, str):
                unauthorized.append(f"{name}:<invalid-path>")
                continue
            candidate = Path(raw_path)
            if not candidate.is_absolute():
                candidate = Path(working_root) / candidate
            try:
                resolved = candidate.resolve()
            except OSError:
                unauthorized.append(f"{name}:{raw_path}")
                continue
            if not cls._path_is_under(resolved, roots):
                unauthorized.append(f"{name}:{raw_path}")
        return unauthorized

    @classmethod
    def _used_tool_on_path(
        cls,
        result: dict[str, Any],
        tool_name: str,
        expected_path: Path,
        working_root: Path,
    ) -> bool:
        expected = expected_path.resolve()
        for name, tool_input in cls._successful_tool_uses(result):
            if name != tool_name:
                continue
            raw_path = tool_input.get("file_path")
            if not isinstance(raw_path, str) or not raw_path:
                continue
            candidate = Path(raw_path)
            if not candidate.is_absolute():
                candidate = working_root / candidate
            try:
                if candidate.resolve() == expected:
                    return True
            except OSError:
                continue
        return False

    @classmethod
    def _unauthorized_write_tool_paths(
        cls,
        result: dict[str, Any],
        session: IsolatedBuildSession,
        allowed_paths: list[str],
        scope: ManifestScope,
        working_root: Path,
    ) -> list[str]:
        """Return Edit/Write paths that do not resolve to an allowlisted file."""
        allowed = {
            session.resolve_manifest_path(path, scope).resolve()
            for path in allowed_paths
        }
        unauthorized: list[str] = []
        for name, tool_input in cls._successful_tool_uses(result):
            if name not in {"Edit", "Write"}:
                continue
            raw_path = tool_input.get("file_path")
            if not isinstance(raw_path, str) or not raw_path:
                unauthorized.append("<missing-file-path>")
                continue
            candidate = Path(raw_path)
            if not candidate.is_absolute():
                candidate = working_root / candidate
            try:
                resolved = candidate.resolve()
            except OSError:
                unauthorized.append(raw_path)
                continue
            if resolved not in allowed:
                unauthorized.append(raw_path)
        return unauthorized

    @staticmethod
    def _write_repair_context(
        session: IsolatedBuildSession,
        context: CompilationContext,
        build_result: BuildResult,
        attempt: int,
        allowed_paths: list[str],
    ) -> Path:
        context_dir = session.root_path / "repair-context"
        context_dir.mkdir(parents=True, exist_ok=True)
        context_path = context_dir / f"attempt-{attempt}.json"
        diagnostics = [
            {
                "file": item.file,
                "line": item.line,
                "column": item.column,
                "severity": item.error_type,
                "phase": item.phase,
                "category": item.category,
                "tool": item.tool,
                "message": item.message,
                "raw_message": item.raw_message,
            }
            for item in build_result.errors
        ]
        payload = {
            "schema_version": 1,
            "attempt": attempt,
            "max_attempts": context.max_attempts,
            "allowed_files": allowed_paths,
            "build": {
                "returncode": build_result.returncode,
                "failure_category": build_result.failure_category,
                "stdout": build_result.stdout,
                "stderr": build_result.stderr,
            },
            "diagnostics": diagnostics,
        }
        context_path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=True),
            encoding="utf-8",
        )
        return context_path

    @staticmethod
    def _manifest_changed_paths(
        session: IsolatedBuildSession,
        changed_root_paths: list[str],
        allowed_paths: list[str],
        scope: ManifestScope,
    ) -> list[str]:
        changed = set(changed_root_paths)
        matched: list[str] = []
        for path in allowed_paths:
            resolved = session.resolve_manifest_path(path, scope)
            candidates = {
                path.replace("\\", "/"),
                resolved.relative_to(session.isolated_source_root).as_posix(),
            }
            try:
                candidates.add(resolved.relative_to(session.project_path).as_posix())
            except ValueError:
                pass
            if candidates & changed:
                matched.append(path)
        return matched

    @staticmethod
    def _build_diff(
        snapshot: ProjectSnapshot,
        session: IsolatedBuildSession,
        changed_paths: list[str],
        scope: ManifestScope = ManifestScope.PROJECT,
    ) -> str:
        chunks: list[str] = []
        for relative_path in changed_paths:
            before_base = (
                snapshot.backup_path
                if scope == ManifestScope.REPOSITORY
                else snapshot.backup_path / snapshot.project_relative_path
            )
            before_path = before_base / relative_path
            after_path = session.resolve_manifest_path(relative_path, scope)
            before = (
                before_path.read_text(encoding="utf-8", errors="replace").splitlines()
                if before_path.is_file()
                else []
            )
            after = (
                after_path.read_text(encoding="utf-8", errors="replace").splitlines()
                if after_path.is_file()
                else []
            )
            chunks.extend(
                difflib.unified_diff(
                    before,
                    after,
                    fromfile=f"a/{relative_path}",
                    tofile=f"b/{relative_path}",
                    lineterm="",
                )
            )
        return "\n".join(chunks)

    @staticmethod
    def _compute_repair_timeout(context: CompilationContext) -> tuple[int, int]:
        """
        Compute repair timeout and activity_timeout from context.

        Returns:
            (timeout, activity_timeout) in seconds
        """
        del context
        # A repair turn is user-directed work, not a build watchdog. The build
        # loop remains responsible for cancellation; Claude must be allowed to
        # inspect the complete diagnostics and finish the requested edit.
        return 0, 0


def _manifest_scope(context: CompilationContext) -> ManifestScope:
    return context.manifest.scope if context.manifest else ManifestScope.PROJECT
