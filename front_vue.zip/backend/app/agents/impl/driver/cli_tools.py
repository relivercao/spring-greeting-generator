"""Task-scoped MCP file tools and isolated candidate build verification."""
from __future__ import annotations

import argparse
import fnmatch
import json
import logging
import os
import re
import shutil
import sys
import tempfile
from collections.abc import Iterable
from pathlib import Path
from typing import Any

MCP_SERVER_NAME = "driver_context"
_LOGGER = logging.getLogger(__name__)
_TEXT_SUFFIXES = frozenset({
    ".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".s", ".asm", ".ld",
    ".md", ".txt", ".json", ".xml", ".yaml", ".yml", ".ini", ".log",
    ".cfg", ".conf", ".mk", ".cmake", ".ioc", ".properties", ".qbs",
})
_TEXT_FILENAMES = frozenset({".project", ".cproject", "makefile", "cmakelists.txt"})
_IGNORED_DIRECTORIES = frozenset({
    ".git", ".hg", ".svn", ".codex", ".claude", ".venv", "venv",
    "node_modules", "__pycache__",
})
_SENSITIVE_NAMES = frozenset({"id_rsa", "id_ed25519", "credentials", "secrets", "secrets.json"})
_PAGE_MARKER = re.compile(
    r"^\s*(?:<!--\s*page(?:_number)?[:\s]+(\d+)\s*-->|"
    r"#{1,6}\s*page\s+(\d+)\s*|[-=]*\s*page\s+(\d+)\s*[-=]*)$",
    re.IGNORECASE,
)


def _encoded(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def _shorten(text: str, limit: int = 1_000) -> str:
    text = str(text or "")
    if len(text) <= limit:
        return text
    marker = " ... [truncated]"
    return text[: max(0, limit - len(marker))] + marker


def _exception_summary(exc: BaseException) -> dict[str, Any]:
    """Return a bounded, actionable summary for an MCP-visible exception."""
    exception_type = type(exc).__name__
    raw_message = str(exc) or repr(exc)
    summary: dict[str, Any] = {
        "error_type": exception_type,
        "error": f"{exception_type}: {_shorten(raw_message)}",
    }
    if isinstance(exc, shutil.Error):
        copy_errors = exc.args[0] if exc.args and isinstance(exc.args[0], list) else []
        error_codes = sorted(set(re.findall(r"WinError\s+(\d+)", raw_message)))
        samples: list[dict[str, str]] = []
        long_path_count = 0
        for index, item in enumerate(copy_errors):
            if not isinstance(item, (tuple, list)) or len(item) < 3:
                continue
            if len(str(item[1])) >= 248:
                long_path_count += 1
            if index >= 3:
                continue
            samples.append({
                "source": _shorten(str(item[0]), 500),
                "destination": _shorten(str(item[1]), 500),
                "reason": _shorten(str(item[2]), 300),
            })
        summary["failure_category"] = "repository_snapshot_failed"
        summary["copy_error_count"] = len(copy_errors)
        summary["error_codes"] = error_codes
        summary["long_path_count"] = long_path_count
        summary["exception_sample"] = samples
        if long_path_count:
            root_cause = "The isolated repository snapshot destination exceeds the Windows path length limit."
        elif "206" in error_codes and "3" in error_codes:
            root_cause = (
                "The isolated repository snapshot contains stale generated trees and "
                "Windows-incompatible paths."
            )
        elif "206" in error_codes:
            root_cause = "The isolated repository snapshot contains paths longer than the Windows path limit."
        elif "3" in error_codes:
            root_cause = "A source path disappeared or was invalid while the isolated repository snapshot was copied."
        else:
            root_cause = "The repository could not be copied into the isolated build session."
        if long_path_count and "3" in error_codes:
            root_cause = (
                "The isolated repository snapshot destination exceeds the Windows path length limit; "
                "WinError 3 is reported for the overlong destination."
            )
        summary["root_cause"] = root_cause
        summary["next_action"] = (
            "Prune stale worktree/build/cache directories or use a clean source snapshot, then retry."
        )
    else:
        summary["root_cause"] = f"The build tool raised {exception_type} before returning a build result."
        summary["next_action"] = "Read diagnostics_path and build.log, correct the reported cause, then retry."
    return summary


def _integer(value: int, name: str, minimum: int = 0) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


class DriverCliToolServer:
    """Enforce canonical path grants on each operation, independently of prompts."""

    def __init__(self, config: dict[str, Any]):
        self.output_root = Path(config["output_root"]).resolve(strict=True)
        self.readable_files = tuple(Path(item).resolve() for item in config.get("readable_files", []))
        self.search_roots = tuple(Path(item).resolve(strict=True) for item in config.get("search_roots", []))
        self.writable_files = tuple(Path(item).absolute() for item in config.get("writable_files", []))
        self.excluded_paths = tuple(Path(item).resolve() for item in config.get("excluded_paths", []))
        if any(not path.is_relative_to(self.output_root) for path in self.writable_files):
            raise ValueError("Write grants must belong to the task output root")
        self.documents = {Path(item["path"]).resolve(): item for item in config.get("documents", [])}
        self.build_config = config.get("build_config")
        self._build_revision = 0
        self._build_result_cache: tuple[int, dict[str, Any]] | None = None

    def _resolve_path(self, raw_path: str, *, must_exist: bool = True) -> Path:
        if not isinstance(raw_path, str) or not raw_path or "\x00" in raw_path:
            raise ValueError("A non-empty file path is required")
        candidate = Path(raw_path)
        if ".." in candidate.parts or any(":" in part for part in candidate.parts if part != candidate.anchor):
            raise PermissionError("Parent traversal and alternate streams are not allowed")
        if not candidate.is_absolute():
            candidate = self.output_root / candidate
        return candidate.resolve(strict=must_exist)

    @staticmethod
    def _is_safe_text_file(path: Path) -> bool:
        name = path.name.casefold()
        return (
            not name.startswith(".env") and name not in _SENSITIVE_NAMES
            and path.stem.casefold() not in _SENSITIVE_NAMES
            and (path.suffix.casefold() in _TEXT_SUFFIXES or name in _TEXT_FILENAMES)
        )

    def _authorized_file(self, path: Path) -> bool:
        if any(path.is_relative_to(excluded) for excluded in self.excluded_paths):
            return False
        if not self._is_safe_text_file(path) or path.stat().st_nlink > 1:
            return False
        if path in self.readable_files:
            return True
        for root in (self.output_root, *self.search_roots):
            if path.is_relative_to(root):
                parts = path.relative_to(root).parts
                if not any(part.casefold() in _IGNORED_DIRECTORIES for part in parts):
                    return True
        return False

    def _require_readable_file(self, raw_path: str) -> Path:
        path = self._resolve_path(raw_path)
        if not path.is_file() or not self._authorized_file(path):
            raise PermissionError("File is outside the task's authorized read scope")
        return path

    def _require_writable_file(self, raw_path: str) -> Path:
        requested = Path(str(raw_path))
        if not requested.is_absolute():
            requested = self.output_root / requested
        if ".." in requested.parts or not requested.is_relative_to(self.output_root):
            raise PermissionError("Write paths must stay inside the task output root")
        current = self.output_root
        for part in requested.relative_to(self.output_root).parts:
            current = current / part
            if current.is_symlink() or current.resolve() != current.absolute():
                raise PermissionError("Writing through file or directory links is not allowed")
        path = self._resolve_path(raw_path, must_exist=False)
        if any(path.is_relative_to(excluded) for excluded in self.excluded_paths):
            raise PermissionError("Task policy files cannot be modified")
        if path not in self.writable_files or not path.is_relative_to(self.output_root):
            raise PermissionError("Only explicitly declared output files may be written")
        if path.exists() and path.stat().st_nlink > 1:
            raise PermissionError("Writing multiply linked files is not allowed")
        return path

    def _walk(self, root: Path) -> Iterable[Path]:
        for directory, directories, filenames in os.walk(root, followlinks=False):
            current = Path(directory)
            directories[:] = sorted(
                name for name in directories
                if name.casefold() not in _IGNORED_DIRECTORIES
                and not any((current / name).resolve().is_relative_to(excluded) for excluded in self.excluded_paths)
                and (current / name).resolve() == (current / name).absolute()
            )
            for name in sorted(filenames):
                path = (current / name).resolve()
                if path.is_relative_to(root) and path.is_file() and self._authorized_file(path):
                    yield path

    def _files_under(self, base: Path) -> list[Path]:
        if base.is_file():
            return [self._require_readable_file(str(base))]
        candidates = [path for path in self.readable_files if path.is_relative_to(base)]
        roots = (self.output_root, *self.search_roots)
        if any(base.is_relative_to(root) for root in roots):
            candidates.extend(self._walk(base))
        else:
            for root in roots:
                if root.is_relative_to(base):
                    candidates.extend(self._walk(root))
        return sorted({path for path in candidates if path.is_file() and self._authorized_file(path)}, key=str)

    def _require_search_scope(self, base: Path) -> None:
        if base.is_file():
            self._require_readable_file(str(base))
            return
        if base.is_dir() and (
            any(base.is_relative_to(root) for root in (self.output_root, *self.search_roots))
            or any(base == item.parent for item in self.readable_files)
        ):
            return
        raise PermissionError("Directory is outside the task's authorized search scope")

    def read_file(self, path: str, offset: int = 0, length: int = 4_000) -> dict[str, Any]:
        file_path = self._require_readable_file(path)
        start = _integer(offset, "offset")
        length = _integer(length, "length", 1)
        text = file_path.read_text(encoding="utf-8", errors="replace")
        excerpt = text[start:start + length]
        return {
            "path": str(file_path), "offset": start,
            "next_offset": start + len(excerpt), "total_chars": len(text),
            "truncated": start + len(excerpt) < len(text), "text": excerpt,
        }

    def grep(self, query: str, path: str, offset: int = 0) -> dict[str, Any]:
        if not isinstance(query, str) or not query:
            raise ValueError("A non-empty literal query is required; regular expressions are not executed")
        base = self._resolve_path(path)
        self._require_search_scope(base)
        start = _integer(offset, "offset")
        matches = []
        match_index = 0
        for candidate in self._files_under(base):
            try:
                file_path = self._require_readable_file(str(candidate))
                with file_path.open(encoding="utf-8", errors="replace") as source:
                    consumed = 0
                    for line_number, line in enumerate(source, start=1):
                        line_start = consumed
                        consumed += len(line)
                        match = re.search(re.escape(query), line, re.IGNORECASE)
                        if match is None:
                            continue
                        position = match.start()
                        if match_index < start:
                            match_index += 1
                            continue
                        snippet_start = max(position - 100, 0)
                        item = {"path": str(file_path), "line": line_number,
                                "offset": line_start + snippet_start,
                                "text": line[snippet_start:snippet_start + 800].rstrip("\r\n")}
                        matches.append(item)
                        match_index += 1
            except OSError:
                continue
        return {"matches": matches, "next_offset": match_index, "truncated": False}

    def glob(self, pattern: str, path: str, offset: int = 0) -> dict[str, Any]:
        if not pattern or ".." in Path(pattern).parts or Path(pattern).is_absolute():
            raise ValueError("A relative, non-empty glob pattern without parent traversal is required")
        base = self._resolve_path(path)
        self._require_search_scope(base)
        start = _integer(offset, "offset")
        matches = []
        match_index = 0
        for file_path in self._files_under(base):
            relative = file_path.relative_to(base).as_posix() if base.is_dir() else file_path.name
            patterns = (pattern, pattern[3:]) if pattern.startswith("**/") else (pattern,)
            if not any(fnmatch.fnmatchcase(relative.casefold(), value.casefold()) for value in patterns):
                continue
            if match_index < start:
                match_index += 1
                continue
            matches.append(str(file_path))
            match_index += 1
        return {"matches": matches, "next_offset": match_index, "truncated": False}

    def search_document(
        self, path: str, query: str = "", page: int | None = None,
        section: str | None = None, offset: int = 0,
    ) -> dict[str, Any]:
        document_path = self._require_readable_file(path)
        if document_path not in self.documents:
            raise PermissionError("Document is not registered in this task")
        if not query and page is None and not section:
            raise ValueError("Supply a query, page, or section to search")
        if page is not None:
            _integer(page, "page", 1)
        start = _integer(offset, "offset")
        current_page = None
        headings = []
        matches = []
        current_offset = 0
        page_available = False
        with document_path.open(encoding="utf-8", errors="replace") as source:
            for line_number, line in enumerate(source, start=1):
                line_start = current_offset
                current_offset += len(line)
                marker = _PAGE_MARKER.match(line.rstrip("\r\n"))
                if marker:
                    current_page = next(int(group) for group in marker.groups() if group)
                    page_available = True
                heading = re.match(r"^(#{1,6})\s+(.+)", line)
                if heading:
                    level = len(heading[1])
                    headings = [(depth, title) for depth, title in headings if depth < level]
                    headings.append((level, heading[2].strip()))
                section_name = " / ".join(title for _, title in headings)
                if line_start < start or (page is not None and current_page != page):
                    continue
                if section and section.casefold() not in section_name.casefold():
                    continue
                match = re.search(re.escape(query), line, re.IGNORECASE)
                if match is None:
                    continue
                position = match.start()
                snippet_start = max(position - 100, 0)
                item = {"line": line_number, "offset": line_start + snippet_start,
                        "page": current_page, "section": section_name[:500],
                        "excerpt": line[snippet_start:snippet_start + 800].rstrip("\r\n")}
                matches.append(item)
        return {"matches": matches, "next_offset": current_offset,
                "truncated": False, "page_available": page_available}

    def write_file(self, path: str, content: str) -> dict[str, Any]:
        file_path = self._require_writable_file(path)
        if not isinstance(content, str):
            raise TypeError("content must be text")
        file_path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(dir=file_path.parent, prefix=".driver-write-")
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as target:
                target.write(content)
            self._require_writable_file(path)
            os.replace(temporary, file_path)
            self._build_revision += 1
            self._build_result_cache = None
        finally:
            Path(temporary).unlink(missing_ok=True)
        return {"path": str(file_path), "characters_written": len(content)}

    def edit_file(self, path: str, old_text: str, new_text: str, replace_all: bool = False) -> dict[str, Any]:
        file_path = self._require_writable_file(path)
        content = file_path.read_text(encoding="utf-8")
        if not old_text or old_text not in content:
            raise ValueError("old_text must be non-empty and present in the authorized file")
        if not replace_all and content.count(old_text) != 1:
            raise ValueError("old_text must be unique unless replace_all is true")
        return self.write_file(path, content.replace(old_text, new_text, -1 if replace_all else 1))

    def build(self) -> dict[str, Any]:
        if self.build_config:
            if self._build_result_cache and self._build_result_cache[0] == self._build_revision:
                result = dict(self._build_result_cache[1])
                result["cached"] = True
                return result
            result = _run_build(self.build_config)
            if isinstance(result, dict):
                self._build_result_cache = (self._build_revision, dict(result))
            return result
        raise RuntimeError("The task does not have an authorized build executor")

    def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
        handlers = {
            "read_file": self.read_file,
            "grep": self.grep,
            "glob": self.glob,
            "search_document": self.search_document,
            "write_file": self.write_file,
            "edit_file": self.edit_file,
            "build": self.build,
        }
        handler = handlers.get(name)
        if handler is None:
            raise ValueError(f"Unknown driver tool: {name}")
        if not isinstance(arguments, dict):
            raise TypeError("Tool arguments must be an object")
        return handler(**arguments)


_TOOL_SCHEMAS = [
    {
        "name": "read_file",
        "description": "Read a small character range from an authorized file; use offset to continue.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"}, "offset": {"type": "integer", "minimum": 0},
            "length": {"type": "integer", "minimum": 1},
        }, "required": ["path"]},
    },
    {
        "name": "grep",
        "description": "Search literal text in authorized indexed files or project roots.",
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string"}, "path": {"type": "string"},
            "offset": {"type": "integer", "minimum": 0},
        }, "required": ["query", "path"]},
    },
    {
        "name": "glob",
        "description": "List matching file paths inside authorized indexed roots.",
        "inputSchema": {"type": "object", "properties": {
            "pattern": {"type": "string"}, "path": {"type": "string"},
            "offset": {"type": "integer", "minimum": 0},
        }, "required": ["pattern", "path"]},
    },
    {
        "name": "search_document",
        "description": "Search Docling Markdown by literal query, optional page, and heading section.",
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string"}, "path": {"type": "string"},
            "offset": {"type": "integer", "minimum": 0},
            "page": {"type": "integer", "minimum": 1}, "section": {"type": "string"},
        }, "required": ["path"]},
    },
    {
        "name": "write_file",
        "description": "Create or replace a declared driver output file only.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"}, "content": {"type": "string"},
        }, "required": ["path", "content"]},
    },
    {
        "name": "edit_file",
        "description": "Replace exact text in a declared driver output file only.",
        "inputSchema": {"type": "object", "properties": {
            "path": {"type": "string"}, "old_text": {"type": "string"},
            "new_text": {"type": "string"}, "replace_all": {"type": "boolean"},
        }, "required": ["path", "old_text", "new_text"]},
    },
]
_READ_ONLY_TOOLS = {"read_file", "grep", "glob", "search_document"}


def tool_schemas(build_enabled: bool) -> list[dict[str, Any]]:
    tools = json.loads(json.dumps(_TOOL_SCHEMAS))
    for tool in tools:
        tool["annotations"] = {"readOnlyHint": tool["name"] in _READ_ONLY_TOOLS}
    if build_enabled:
        tools.append({
            "name": "build",
            "description": "Compile the candidate in an isolated copy with fixed task configuration. No command, path, or flags are accepted.",
            "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
            "annotations": {"readOnlyHint": False, "destructiveHint": False},
        })
    for tool in tools:
        tool["inputSchema"]["additionalProperties"] = False
    return tools



def _mcp_parameters(policy_path: Path) -> tuple[Path, list[str], dict[str, str]]:
    entrypoint = Path(__file__).resolve().parents[4] / "mcp_server.py"
    arguments = ["-u", str(entrypoint), "--config", str(policy_path)]
    environment = {"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}
    return entrypoint, arguments, environment


def check_driver_mcp() -> dict[str, Any]:
    """Check file-tool startup before document parsing or model requests."""
    from mcp_server import probe_mcp

    from app.core.driver_storage import get_driver_temp_root

    with tempfile.TemporaryDirectory(
        prefix="driver-mcp-preflight-", dir=get_driver_temp_root(),
    ) as directory:
        root = Path(directory)
        policy_path = root / "tools.json"
        policy_path.write_text(_encoded({"output_root": str(root)}), encoding="utf-8")
        entrypoint, arguments, environment = _mcp_parameters(policy_path)
        preflight = probe_mcp(
            [sys.executable, *arguments], cwd=str(entrypoint.parent),
            env=dict(os.environ, **environment),
        )
        return {
            "python": sys.executable, "entrypoint": str(entrypoint),
            "preflight": preflight, "stderr": preflight.get("stderr", ""),
        }


def execute_scoped_cli(runner: Any, tool_config: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
    """Keep policy files outside model-visible roots for the entire CLI lifetime."""
    from mcp_server import probe_mcp, read_stderr

    from app.core.driver_storage import get_driver_temp_root

    with tempfile.TemporaryDirectory(prefix="driver-cli-mcp-", dir=get_driver_temp_root()) as directory:
        config_root = Path(directory)
        policy_path = config_root / "tools.json"
        policy = dict(tool_config, excluded_paths=[
            *tool_config.get("excluded_paths", []), str(config_root),
        ])
        policy_path.write_text(_encoded(policy), encoding="utf-8")
        entrypoint, arguments, environment = _mcp_parameters(policy_path)
        stderr_path = config_root / "mcp-stderr.log"
        preflight = probe_mcp(
            [sys.executable, *arguments], cwd=str(entrypoint.parent),
            env=dict(os.environ, **environment),
        )
        diagnostics = {
            "python": sys.executable, "entrypoint": str(entrypoint),
            "preflight": preflight, "stderr": "",
        }
        if preflight["status"] != "connected":
            diagnostics["stderr"] = preflight.get("stderr", "")
            return {
                "status": "error", "exit_code": -1, "output": "",
                "error": preflight.get("error", "Driver MCP preflight failed"),
                "failure_category": "cli_mcp_unavailable",
                "incomplete_failure_category": "cli_mcp_unavailable",
                "mcp_startup_diagnostics": diagnostics,
            }
        mcp_path = config_root / "mcp.json"
        mcp_path.write_text(_encoded({"mcpServers": {MCP_SERVER_NAME: {
            "command": sys.executable,
            "args": [*arguments, "--stderr-log", str(stderr_path)],
            "env": environment,
        }}}), encoding="utf-8")
        tool_names = [item["name"] for item in tool_schemas(bool(tool_config.get("build_config")))]
        kwargs.update(
            bypass_permissions=False, tools_enabled=True, allowed_tools=None, allowed_dirs=[],
            allowed_mcp_tools=[f"mcp__{MCP_SERVER_NAME}__{name}" for name in tool_names],
            mcp_config=str(mcp_path), permission_mode="dontAsk",
        )
        result = runner(**kwargs)
        try:
            diagnostics["stderr"] = read_stderr(stderr_path)
        except OSError as exc:
            diagnostics["stderr_read_error"] = f"{type(exc).__name__}: {exc}"
        return dict(result, mcp_startup_diagnostics=diagnostics)


def _tool_result(request_id: Any, value: Any, *, is_error: bool = False) -> dict[str, Any]:
    text = _encoded(value)
    return {"jsonrpc": "2.0", "id": request_id,
            "result": {"content": [{"type": "text", "text": text}], "isError": is_error}}


def _run_build(config: dict[str, Any]) -> dict[str, Any]:
    backend_root = Path(config["backend_root"]).resolve(strict=True)
    sys.path.insert(0, str(backend_root))
    from app.agents.impl.driver.build import (
        BuildExecutorConfig,
        build_executor_registry,
    )
    from app.agents.impl.driver.fix_loop import CompileFixLoop
    from app.agents.impl.driver.types import (
        CompilationContext,
        FileManifest,
        ManifestScope,
    )

    output_root = Path(config["output_root"]).resolve(strict=True)
    project_path = Path(config["project_path"]).resolve(strict=True)
    if not project_path.is_dir():
        raise ValueError("The configured build project is not a directory")
    expected = config["expected_files"]
    manifest_data = config["manifest"]
    manifest = FileManifest(
        header_filename=manifest_data["header_filename"],
        source_filename=manifest_data["source_filename"],
        config_filename=manifest_data.get("config_filename"),
        test_filename=manifest_data.get("test_filename"),
        target_inc_dir=manifest_data["target_inc_dir"],
        target_src_dir=manifest_data["target_src_dir"],
        scope=ManifestScope(manifest_data["scope"]),
    )
    relative_paths = manifest.relative_paths()
    role_to_relative = {
        "header": relative_paths["header"],
        "source": relative_paths["source"],
    }
    if manifest.config_filename and "config" in relative_paths:
        role_to_relative["config"] = relative_paths["config"]

    generated_files = {}
    contents = {}
    for role, relative_path in role_to_relative.items():
        output_name = expected.get(role)
        if not output_name or Path(output_name).name != output_name:
            raise ValueError(f"No safe generated output is configured for {role}")
        output_path = (output_root / output_name).resolve(strict=True)
        if (output_path.parent != output_root or not output_path.is_file()
                or (output_root / output_name).is_symlink()):
            raise ValueError(f"Generated {role} file is missing or outside the task output")
        content = output_path.read_text(encoding="utf-8")
        if not content.strip():
            raise ValueError(f"Generated {role} file is empty")
        generated_files[relative_path] = content
        contents[role] = content

    platform = build_executor_registry.resolve(config["platform"])
    executor = build_executor_registry.create(
        BuildExecutorConfig(platform=platform, tool_path=str(config.get("tool_path", "")))
    )
    task_id = str(config.get("task_id") or "driver-cli-build")
    from uuid import uuid4

    artifact_dir = output_root / "cli_build_artifacts" / uuid4().hex
    artifact_dir.mkdir(parents=True, exist_ok=False)
    compilation = CompilationContext(
        header_file=contents["header"],
        source_file=contents["source"],
        existing_project_path=str(project_path),
        build_tool_path=str(config.get("tool_path", "")),
        workspace_path=str(artifact_dir / "workspace"),
        configuration=str(config["configuration"]),
        max_attempts=1,
        task_id=task_id,
        manifest=manifest,
        generated_files=generated_files,
        allowed_write_paths=list(generated_files),
        compile_verify=True,
        platform=platform,
        clean_build=bool(config.get("clean_build", False)),
        timeout=int(config.get("timeout", 3600)),
        baseline_verify=bool(config.get("baseline_verify", False)),
        baseline_fail_fast=False,
        in_place_build=False,
        defer_in_place_commit=False,
        strict_configuration=bool(config.get("strict_configuration", False)),
        artifact_dir=str(artifact_dir),
        infrastructure_retries=int(config.get("infrastructure_retries", 0)),
        build_jobs=int(config.get("build_jobs", 0)),
        build_activity_timeout=int(config.get("build_activity_timeout", 0)),
    )
    loop = CompileFixLoop(executor=executor, max_attempts=1, repairer=None)
    import asyncio

    try:
        result = asyncio.run(loop.compile_with_auto_fix(compilation))
    except Exception as exc:
        summary = _exception_summary(exc)
        summary.update({
            "success": False,
            "returncode": -1,
            "attempt": 0,
            "configuration": compilation.configuration,
            "verification": "isolated_candidate_only",
        })
        exception_path = artifact_dir / "exception.json"
        exception_path.write_text(
            _encoded({
                **summary,
                "exception": raw_message if (raw_message := str(exc)) else repr(exc),
            }),
            encoding="utf-8",
        )
        summary["diagnostics_path"] = str(exception_path)
        summary["next_action"] = (
            "Read diagnostics_path for the full exception; prune stale repository artifacts and retry."
        )
        _LOGGER.exception("Driver isolated build failed before returning a result: %s", summary["error"])
        return summary
    full_log = "\n".join(part for part in (result.stdout, result.stderr) if part)
    log_path = artifact_dir / "build.log"
    log_path.write_text(full_log, encoding="utf-8")
    from dataclasses import asdict
    from hashlib import sha256

    evidence_path = artifact_dir / "result.json"
    evidence = asdict(result)
    evidence["input_sha256"] = {
        relative_path: sha256(content.encode("utf-8")).hexdigest()
        for relative_path, content in generated_files.items()
    }
    evidence["configuration"] = compilation.configuration
    evidence_path.write_text(json.dumps(evidence, indent=2, default=str), encoding="utf-8")
    root_category = next(
        (item.get("root_failure_category") for item in reversed(result.attempt_history)
         if item.get("root_failure_category")), result.failure_category,
    )
    return {
        "success": result.success,
        "failure_category": root_category,
        "returncode": result.returncode,
        "attempt": result.attempt,
        "configuration": compilation.configuration,
        "log_path": str(log_path),
        "diagnostics_path": str(evidence_path),
        "error_count": len(result.errors),
        "warning_count": len(result.warnings),
        "verification": "isolated_candidate_only",
        "next_action": "Read or search the full diagnostics and log; final publication still requires the pipeline build.",
    }


def _serve(config_path: Path) -> None:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    server = DriverCliToolServer(config)
    tools = tool_schemas(bool(server.build_config))
    for raw_message in sys.stdin.buffer:
        try:
            request = json.loads(raw_message.decode("utf-8"))
            if not isinstance(request, dict):
                continue
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        method = request.get("method")
        request_id = request.get("id")
        if method == "notifications/initialized" or request_id is None:
            continue
        params = request.get("params", {})
        if not isinstance(params, dict):
            response = {
                "jsonrpc": "2.0", "id": request_id,
                "error": {"code": -32602, "message": "MCP params must be an object"},
            }
        elif method == "initialize":
            requested_version = params.get("protocolVersion")
            supported_versions = {"2024-11-05", "2025-03-26", "2025-06-18"}
            version = requested_version if requested_version in supported_versions else "2024-11-05"
            response = {
                "jsonrpc": "2.0", "id": request_id,
                "result": {
                    "protocolVersion": version,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "driver_context", "version": "1.0.0"},
                },
            }
        elif method == "ping":
            response = {"jsonrpc": "2.0", "id": request_id, "result": {}}
        elif method == "tools/list":
            response = {"jsonrpc": "2.0", "id": request_id, "result": {"tools": tools}}
        elif method == "tools/call":
            try:
                from contextlib import redirect_stdout

                with redirect_stdout(sys.stderr):
                    value = server.call_tool(params.get("name", ""), params.get("arguments", {}))
                response = _tool_result(request_id, value)
            except Exception as exc:
                _LOGGER.exception("Driver CLI tool request failed")
                response = _tool_result(request_id, _exception_summary(exc), is_error=True)
        else:
            response = {
                "jsonrpc": "2.0", "id": request_id,
                "error": {"code": -32601, "message": f"Unsupported MCP method: {method}"},
            }
        sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
        sys.stdout.flush()


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    args = parser.parse_args()
    _serve(args.config)


if __name__ == "__main__":
    main()
