"""
@file self_test.py
@author caoshwen
@brief Self-test summary helpers for Driver Agent outputs

@version 1.0
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


SELF_TEST_SKIPPED = "SKIPPED"
SELF_TEST_COMPILE_LEVEL = "L4 platform_compile"


@dataclass
class DriverSelfTestReport:
    """Aggregated self-test report for one generated driver."""

    levels: dict[str, bool | str] = field(default_factory=dict)
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def success(self) -> bool:
        return (
            all(value is True or value == SELF_TEST_SKIPPED for value in self.levels.values())
            if self.levels
            else False
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "levels": self.levels,
            "details": self.details,
        }

    def to_markdown(self) -> str:
        lines = ["# Driver Self-Test Report", ""]
        for level, value in self.levels.items():
            status = value if value == SELF_TEST_SKIPPED else ("PASS" if value else "FAIL")
            lines.append(f"- {level}: {status}")
        if self.details:
            lines.extend(["", "## Details"])
            for key, value in self.details.items():
                lines.append(f"- {key}: {value}")
        return "\n".join(lines) + "\n"


def build_self_test_report(
    artifacts: list[dict[str, Any]],
    validation: Any,
    compile_success: bool,
    build_attempts: int,
    firmware_path: str | None,
    compile_requested: bool,
) -> DriverSelfTestReport:
    """Build a deterministic self-test report from pipeline outputs."""
    artifact_types = {artifact.get("type") for artifact in artifacts}
    levels = {
        "L0 artifacts_exist": {"header", "source"}.issubset(artifact_types),
        "L1 syntax_check": bool(getattr(validation, "syntax_ok", False)),
        "L2 customer_style": bool(getattr(validation, "style_ok", False)),
        "L3 interface_consistency": bool(getattr(validation, "interface_ok", False)),
    }
    if not getattr(validation, "syntax_checked", True) and getattr(validation, "syntax_ok", False):
        levels["L1 syntax_check"] = SELF_TEST_SKIPPED
    compile_status: bool | str = bool(compile_success) if compile_requested else SELF_TEST_SKIPPED
    levels[SELF_TEST_COMPILE_LEVEL] = compile_status

    details = {
        "artifact_count": len(artifacts),
        "validation_issue_count": len(getattr(validation, "issues", []) or []),
        "compile_requested": compile_requested,
        "compile_success": compile_success,
        "build_attempts": build_attempts,
        "firmware_path": firmware_path or "",
    }
    return DriverSelfTestReport(levels=levels, details=details)
