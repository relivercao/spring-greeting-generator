"""
@file context.py
@author caoshwen
@brief Manage compilation history, error patterns, and fix attempts.

@version 1.0
@date 2026-07-21

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.
"""

from typing import List, Dict, Set
from app.core.driver_build_defaults import (
    DEFAULT_HISTORY_SUMMARY_WINDOW,
    MANUAL_INTERVENTION_ATTEMPT_THRESHOLD,
)

from .types import CompilationContext, FixAttempt, ErrorPattern


class CompilationContextManager:
    """Compilation Context Manager"""

    def __init__(self, context: CompilationContext):
        self.context = context

    def add_fix_attempt(
        self,
        prev_errors: int,
        current_errors: int,
        error_patterns: Dict[str, int],
        fix_actions: List[str],
        fixed_files: Dict[str, str],
        success: bool
    ) -> None:
        """Add a fix attempt record"""
        attempt = FixAttempt(
            attempt=len(self.context.fix_history) + 1,
            prev_errors=prev_errors,
            current_errors=current_errors,
            error_patterns=error_patterns,
            fix_actions=fix_actions,
            fixed_files=fixed_files,
            success=success,
        )

        self.context.add_attempt(attempt)

    def detect_no_progress(self) -> bool:
        """
        Detect if there's no progress

        Condition: Error count is unchanged across the comparison window
        """
        if len(self.context.fix_history) < 2:
            return False

        previous_attempt = self.context.fix_history[-2]
        current_attempt = self.context.fix_history[-1]
        return previous_attempt.current_errors == current_attempt.current_errors

    def detect_regression(self) -> bool:
        """
        Detect if errors increased

        Condition: Current errors > previous errors
        """
        if len(self.context.fix_history) < 2:
            return False

        previous_attempt = self.context.fix_history[-2]
        current_attempt = self.context.fix_history[-1]
        prev = previous_attempt.current_errors
        curr = current_attempt.current_errors
        return curr > prev

    def get_persistent_errors(self) -> List[str]:
        """
        Get persistent errors that appear in all attempts

        Returns:
            List of error patterns that persist across all attempts
        """
        return self.context.get_persistent_errors()

    def get_failed_approaches(self) -> List[str]:
        """Get approaches that failed (no improvement)"""
        failed = []

        for i, attempt in enumerate(self.context.fix_history):
            if i > 0:
                prev_attempt = self.context.fix_history[i - 1]
                if attempt.current_errors >= prev_attempt.current_errors:
                    failed.extend(attempt.fix_actions)

        return failed

    def get_successful_approaches(self) -> List[str]:
        """Get approaches that succeeded (reduced errors)"""
        successful = []

        for i, attempt in enumerate(self.context.fix_history):
            if i > 0:
                prev_attempt = self.context.fix_history[i - 1]
                if attempt.current_errors < prev_attempt.current_errors:
                    successful.extend(attempt.fix_actions)

        return successful

    def get_compressed_summary(self) -> str:
        """
        Get compressed history summary

        Format:
        Attempt 1: 10->8 errors | Fixed: includes | Pattern: undeclared(5), unknown_type(3)
        """
        lines = []

        for attempt in self.context.fix_history:
            # Error change
            error_change = f"{attempt.prev_errors}->{attempt.current_errors}"

            # Error patterns
            pattern_str = ', '.join([
                f"{k}({v})" for k, v in attempt.error_patterns.items()
            ])

            # Fix actions
            action_str = ', '.join(attempt.fix_actions) if attempt.fix_actions else 'none'

            # Single line summary
            summary = (
                f"Attempt {attempt.attempt}: {error_change} errors | "
                f"Fixed: {action_str} | Pattern: {pattern_str}"
            )
            lines.append(summary)

        return '\n'.join(lines)

    def get_sliding_window_summary(
        self,
        window_size: int = DEFAULT_HISTORY_SUMMARY_WINDOW,
    ) -> str:
        """
        Get sliding window history summary

        Strategy:
        - Always keep first attempt (baseline)
        - Keep last N attempts (current context)
        - Drop middle attempts
        """
        if len(self.context.fix_history) <= window_size + 1:
            return self.get_compressed_summary()

        # First attempt (baseline)
        baseline = [self.context.fix_history[0]]

        # Last N attempts
        recent = self.context.fix_history[-window_size:]

        # Combine
        selected = baseline + recent

        # Generate summary
        lines = []
        for attempt in selected:
            error_change = f"{attempt.prev_errors}->{attempt.current_errors}"
            pattern_str = ', '.join([
                f"{k}({v})" for k, v in attempt.error_patterns.items()
            ])
            action_str = ', '.join(attempt.fix_actions) if attempt.fix_actions else 'none'

            summary = (
                f"Attempt {attempt.attempt}: {error_change} errors | "
                f"Fixed: {action_str} | Pattern: {pattern_str}"
            )
            lines.append(summary)

        return '\n'.join(lines)

    def generate_smart_suggestions(self) -> str:
        """
        Generate smart suggestions based on history

        Analysis:
        1. Repeated error patterns
        2. Fix effectiveness trend
        3. Possible root causes
        """
        suggestions = []

        # Check for repeated error patterns
        repeated_patterns = self._get_repeated_patterns()

        if repeated_patterns:
            suggestions.append("[WARN] Repeated error patterns detected:")
            for pattern, count in repeated_patterns.items():
                suggestions.append(f"  - {pattern}: appeared {count} times")
            suggestions.append("\n-> Consider a different approach to fix these errors.")

        # Check if includes are needed
        if ('undeclared_identifier' in repeated_patterns or
            'unknown_type' in repeated_patterns):
            suggestions.append("\n[TIP] Tip: Check if you need to add #include statements")
            suggestions.append("   Focus on HAL library includes")

        # Check if project configuration is needed
        if (
            self.context.build_attempts >= MANUAL_INTERVENTION_ATTEMPT_THRESHOLD
            and not self.context.has_progress()
        ):
            suggestions.append("\n[WARN] Multiple attempts failed. Consider:")
            suggestions.append("  - Checking project configuration (.cproject)")
            suggestions.append("  - Verifying HAL library paths")
            suggestions.append("  - Reviewing linker settings")
            suggestions.append("  - This may require manual intervention")

        # Check if progress is slowing down
        if self.context.is_slowing_down():
            suggestions.append("\n[SLOW] Progress is slowing down")
            suggestions.append("   Current approach may be reaching its limits")
            suggestions.append("   -> Try a fundamentally different strategy")

        return '\n'.join(suggestions) if suggestions else "No specific suggestions."

    def _get_repeated_patterns(self) -> Dict[str, int]:
        """Get error patterns that appear multiple times"""
        repeated = {}

        for pattern, count in self.context.error_patterns.items():
            if count > 1:
                repeated[pattern] = count

        return repeated
