"""Driver development Agent for production-oriented embedded C generation."""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field
from typing import Any, Optional

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.agents.structured_output import StructuredOutputError, parse_tagged_sections
from app.llm.base import TokenUsage
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient
from app.services.knowledge_base import KnowledgeBaseService


SYSTEM_PROMPT = """You are a senior embedded firmware driver engineer.
Generate production-oriented, portable C code from the supplied device specification.

Engineering requirements:
- Use a hardware abstraction boundary. Do not directly depend on one vendor HAL unless requested.
- Use fixed-width integer types, explicit status codes, null checks, timeouts, and deterministic behavior.
- Include initialization, deinitialization, read, write, and device-specific control operations.
- Preserve register reset values, access constraints, bit masks, and timing requirements from the specification.
- Avoid dynamic allocation, recursion, hidden global state, and undefined behavior.
- Follow MISRA C:2012 principles where practical and document unavoidable assumptions.
- Make interrupt support optional when the device or interface benefits from it.
- Keep public API declarations and implementation fully consistent.
- Produce a host-testable test file with transport callbacks or fakes.

Return only these four exact sections, with no Markdown fences and no text before them:
<<<HEADER>>>
complete header file
<<<SOURCE>>>
complete source file
<<<TEST>>>
complete test source file
<<<NOTES>>>
integration notes in Markdown
"""

_REQUIRED_CODE_SECTIONS = {"HEADER", "SOURCE", "TEST"}
_DEFAULT_INTEGRATION_NOTES = (
    "# Integration\n\nNo additional integration notes were provided by the model."
)
_MAX_SPEC_CHARS = 180_000
_MAX_REGISTER_EVIDENCE = 200


@dataclass
class DriverContext(AgentContext):
    """Inputs required to generate a peripheral driver."""

    device_name: str = ""
    device_type: str = "peripheral"
    interface: str = "auto"
    mcu_family: str = "generic"
    registers: list[dict[str, Any]] = field(default_factory=list)
    platform: Optional[str] = None
    datasheet_content: Optional[str] = None
    requirements: Optional[str] = None
    register_evidence: list[dict[str, Any]] = field(default_factory=list)
    register_evidence_warnings: list[str] = field(default_factory=list)


@dataclass
class GeneratedDriver:
    """Generated driver source set."""

    header_file: str
    header_content: str
    source_file: str
    source_content: str
    test_file: str
    test_content: str
    doc_file: str
    doc_content: str


@dataclass
class DriverResult(AgentResult):
    """Driver generation result with validation metadata."""

    generated_driver: Optional[GeneratedDriver] = None
    compile_success: bool = False
    validation_passed: bool = False
    validation_warnings: list[str] = field(default_factory=list)


class DriverAgent(BaseAgent):
    """Generate a consistent driver source set from an uploaded specification."""

    def __init__(self, llm_bridge: LLMBridge, mcp_client: MCPClient, skill_registry=None):
        super().__init__(
            AgentConfig(agent_type=AgentType.DRIVER, timeout_seconds=600, durable_runtime=True),
            skill_registry=skill_registry,
        )
        self._llm = llm_bridge
        self._mcp = mcp_client
        self._task_token_usage: dict[str, dict[str, int]] = {}

    def get_token_usage(self, task_id: str) -> dict[str, int]:
        """Return an isolated token usage snapshot for one Driver task."""
        return dict(self._task_token_usage.get(task_id, self._empty_token_usage()))

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, DriverContext):
            raise ValidationError("DriverAgent requires DriverContext")
        if not context.device_name.strip():
            raise ValidationError("device_name is required")
        supported_interfaces = {"auto", "i2c", "spi", "uart", "gpio", "can", "usb", "parallel"}
        if context.interface.lower() not in supported_interfaces:
            raise ValidationError(f"Unsupported interface: {context.interface}")
        if not (context.datasheet_content or context.registers or context.requirements):
            raise ValidationError("A specification, register list, or driver requirement is required")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        assert isinstance(ctx, DriverContext)
        task_id = ctx.task_id
        self._task_token_usage[task_id] = self._empty_token_usage()
        skill_plan = await self._prepare_agent_skills(
            ctx, "knowledge", layer=ctx.interface.lower(), scope="driver",
            inputs={"device_name": ctx.device_name},
        )
        style_plan = await self._prepare_agent_skills(
            ctx, "analysis", layer=ctx.interface.lower(), scope="driver_style",
        )
        stem = self._safe_stem(ctx.device_name)
        filenames = {
            "header": f"drv_{stem}.h",
            "source": f"drv_{stem}.c",
            "test": f"test_drv_{stem}.c",
            "notes": f"drv_{stem}_integration.md",
        }

        await self._report_progress(task_id, 15, "knowledge", "Retrieving structured register and bitfield evidence")
        register_evidence, evidence_warnings = await self._retrieve_register_evidence(ctx)
        ctx.register_evidence = register_evidence
        ctx.register_evidence_warnings = evidence_warnings
        await self._report_progress(
            task_id,
            22,
            "knowledge",
            f"Retrieved {len(register_evidence)} structured register rows",
            {"register_rows": len(register_evidence), "warnings": evidence_warnings},
        )
        await self._report_progress(task_id, 25, "analyze", "Analyzing device requirements")
        prompt = self._build_prompt(ctx, filenames)
        if skill_plan.prompt:
            prompt = f"{skill_plan.prompt}\n\n{prompt}"
        if style_plan.prompt:
            prompt = f"{style_plan.prompt}\n\n{prompt}"

        await self._report_progress(task_id, 45, "generate", "Generating driver source set")
        response = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.15,
            max_tokens=24_000,
            **self._llm_call_options(),
        )
        token_usage = self._record_token_usage(task_id, getattr(response, "usage", None))
        await self._report_progress(
            task_id,
            62,
            "generate",
            "Driver source set generated",
            {"token_usage": token_usage},
        )

        try:
            sections = self._parse_driver_sections(response.content)
        except StructuredOutputError:
            await self._report_progress(
                task_id,
                68,
                "repair",
                "Repairing the generated file structure",
            )
            sections = await self._repair_response(response.content, prompt, task_id)

        driver = GeneratedDriver(
            header_file=filenames["header"],
            header_content=self._strip_code_fence(sections["HEADER"]),
            source_file=filenames["source"],
            source_content=self._strip_code_fence(sections["SOURCE"]),
            test_file=filenames["test"],
            test_content=self._strip_code_fence(sections["TEST"]),
            doc_file=filenames["notes"],
            doc_content=self._strip_code_fence(sections["NOTES"]),
        )

        await self._report_progress(task_id, 82, "validate", "Validating generated files")
        warnings = self._validate_generated_driver(driver)
        files = [
            {
                "filename": driver.header_file,
                "kind": "header",
                "language": "c",
                "content": driver.header_content,
            },
            {
                "filename": driver.source_file,
                "kind": "source",
                "language": "c",
                "content": driver.source_content,
            },
            {
                "filename": driver.test_file,
                "kind": "test",
                "language": "c",
                "content": driver.test_content,
            },
            {
                "filename": driver.doc_file,
                "kind": "documentation",
                "language": "markdown",
                "content": driver.doc_content,
            },
        ]
        result_data = {
            "device": {
                "name": ctx.device_name,
                "type": ctx.device_type,
                "interface": ctx.interface,
                "mcu_family": ctx.mcu_family,
                "platform": ctx.platform,
            },
            "files": files,
            "validation": {
                "passed": True,
                "compile_checked": False,
                "warnings": warnings,
            },
            "integration_notes": driver.doc_content,
            "register_evidence": register_evidence,
            "register_evidence_warnings": evidence_warnings,
            "token_usage": self.get_token_usage(task_id),
        }
        return DriverResult(
            task_id=task_id,
            status=AgentStatus.COMPLETED,
            message=f"Driver source set generated for {ctx.device_name}",
            data=result_data,
            generated_driver=driver,
            validation_passed=True,
            validation_warnings=warnings,
        )

    async def _repair_response(
        self,
        response_content: str,
        original_prompt: str,
        task_id: str,
    ) -> dict[str, str]:
        repair_prompt = f"""The previous response did not follow the required section format.
Reformat and complete it without shortening any file. Return only HEADER, SOURCE, TEST, and NOTES sections.

Original request:
{original_prompt}

Previous response:
{response_content}
"""
        repaired = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": repair_prompt},
            ],
            temperature=0.0,
            max_tokens=24_000,
            **self._llm_call_options(),
        )
        token_usage = self._record_token_usage(task_id, getattr(repaired, "usage", None))
        await self._report_progress(
            task_id,
            73,
            "repair",
            "Generated file structure repaired",
            {"token_usage": token_usage},
        )
        return self._parse_driver_sections(repaired.content)

    @staticmethod
    def _parse_driver_sections(content: str) -> dict[str, str]:
        """Parse required code sections and supply optional integration notes."""
        sections = parse_tagged_sections(content, _REQUIRED_CODE_SECTIONS)
        if not sections.get("NOTES"):
            sections["NOTES"] = _DEFAULT_INTEGRATION_NOTES
        return sections

    @staticmethod
    def _empty_token_usage() -> dict[str, int]:
        return {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
            "cache_creation_input_tokens": 0,
            "cache_read_input_tokens": 0,
        }

    def _record_token_usage(
        self,
        task_id: str,
        usage: Optional[TokenUsage],
    ) -> dict[str, int]:
        current = self._task_token_usage.setdefault(task_id, self._empty_token_usage())
        if usage is None:
            return dict(current)

        input_tokens = max(0, int(getattr(usage, "prompt_tokens", 0) or 0))
        output_tokens = max(0, int(getattr(usage, "completion_tokens", 0) or 0))
        cache_creation_tokens = max(
            0,
            int(getattr(usage, "cache_creation_input_tokens", 0) or 0),
        )
        cache_read_tokens = max(
            0,
            int(getattr(usage, "cache_read_input_tokens", 0) or 0),
        )
        total_tokens = max(0, int(getattr(usage, "total_tokens", 0) or 0))
        if total_tokens == 0:
            total_tokens = (
                input_tokens
                + output_tokens
                + cache_creation_tokens
                + cache_read_tokens
            )

        current["input_tokens"] += input_tokens
        current["output_tokens"] += output_tokens
        current["total_tokens"] += total_tokens
        current["cache_creation_input_tokens"] += cache_creation_tokens
        current["cache_read_input_tokens"] += cache_read_tokens
        return dict(current)

    async def _retrieve_register_evidence(
        self,
        ctx: DriverContext,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """Retrieve structured register and bitfield rows before LLM generation."""
        specification_excerpt = self._bounded_specification(ctx.datasheet_content or "")[:16_000]
        request_text = "\n".join(
            value
            for value in (
                ctx.device_name,
                ctx.device_type,
                ctx.interface,
                ctx.mcu_family,
                ctx.requirements or "",
                specification_excerpt,
            )
            if value
        )
        parsed = KnowledgeBaseService.parse_query(request_text)
        service = await asyncio.to_thread(KnowledgeBaseService)
        documents = await asyncio.to_thread(service.list_documents)

        def normalized(value: Any) -> str:
            return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())

        name_key = normalized(ctx.device_name)
        spec_tokens = [
            token
            for token in re.findall(r"\b[A-Za-z][A-Za-z0-9_-]{3,}\b", specification_excerpt)
            if any(char.isdigit() for char in token)
        ]
        chip_candidates: list[str] = []
        document_candidates: list[str] = []
        for document in documents:
            chip = str(document.get("chip") or "").strip()
            document_id = str(document.get("id") or "").strip()
            chip_key = normalized(chip)
            title_key = normalized(document.get("title"))
            source_key = normalized(document.get("source_path"))
            matches_device = chip_key in name_key or name_key in chip_key
            matches_spec = any(
                normalized(token) in chip_key or normalized(token) in title_key or normalized(token) in source_key
                for token in spec_tokens
            )
            if chip and (matches_device or matches_spec):
                chip_candidates.append(chip)
                if document_id:
                    document_candidates.append(document_id)

        if not chip_candidates:
            name_tokens = [
                token
                for token in re.findall(r"[A-Za-z0-9][A-Za-z0-9._-]{2,}", ctx.device_name)
            ]
            for document in documents:
                chip = str(document.get("chip") or "").strip()
                if chip and any(token.lower() in chip.lower() for token in name_tokens):
                    chip_candidates.append(chip)
                    document_id = str(document.get("id") or "").strip()
                    if document_id:
                        document_candidates.append(document_id)

        rows: list[dict[str, Any]] = []
        seen: set[tuple[Any, ...]] = set()

        async def collect(**filters: Any) -> None:
            result = await asyncio.to_thread(
                service.search_registers,
                limit=_MAX_REGISTER_EVIDENCE,
                **{key: value for key, value in filters.items() if value not in (None, "")},
            )
            for row in result:
                key = (
                    row.get("document_id"),
                    row.get("register_id"),
                    row.get("field_name"),
                    row.get("bit_range"),
                )
                if key not in seen:
                    seen.add(key)
                    rows.append(row)
                    if len(rows) >= _MAX_REGISTER_EVIDENCE:
                        return

        base_filters = {
            "peripheral": parsed.peripheral,
            "register": parsed.register,
            "address": parsed.address,
            "bit": parsed.bit,
            "bit_lsb": parsed.bit_lsb,
            "bit_msb": parsed.bit_msb,
            "field": parsed.field,
        }
        for chip in chip_candidates[:4]:
            await collect(chip=chip, **base_filters)
            if len(rows) >= _MAX_REGISTER_EVIDENCE:
                break

        if not rows:
            for document_id in document_candidates[:4]:
                await collect(document_id=document_id, **base_filters)
                if len(rows) >= _MAX_REGISTER_EVIDENCE:
                    break

        if not rows:
            for chip in chip_candidates[:4]:
                await collect(chip=chip)
                if len(rows) >= _MAX_REGISTER_EVIDENCE:
                    break
        if (
            not rows
            and not chip_candidates
            and documents
            and any((parsed.register, parsed.address, parsed.field, parsed.bit_lsb is not None))
        ):
            await collect(
                register=parsed.register,
                address=parsed.address,
                bit=parsed.bit,
                bit_lsb=parsed.bit_lsb,
                bit_msb=parsed.bit_msb,
                field=parsed.field,
            )
        warnings: list[str] = []
        exact_rows = [
            row
            for row in rows
            if any(str(reason).startswith("exact_") for reason in row.get("match_reasons", []))
        ]
        if not rows:
            warnings.append(
                "No structured register or bitfield evidence matched this device; verify every register value against the source datasheet."
            )
        elif not exact_rows and any((parsed.register, parsed.address, parsed.field, parsed.bit_lsb is not None)):
            warnings.append(
                "Structured evidence is chip-level or partial; do not invent register names, addresses, reset values, or bit ranges."
            )
        if len({row.get("chip") for row in rows if row.get("chip")}) > 1:
            warnings.append("Evidence spans multiple chip documents; use only the requested device document.")
        return rows[:_MAX_REGISTER_EVIDENCE], warnings

    @staticmethod
    def _format_register_evidence(
        evidence: list[dict[str, Any]],
        warnings: list[str],
    ) -> str:
        """Render machine-matched register rows in a compact, auditable format."""
        if not evidence:
            return (
                "No structured register evidence was found. Do not invent register, address, reset, "
                "access, or bitfield values; mark them as assumptions in NOTES."
            )
        lines = [
            "Structured register knowledge (authoritative when present; preserve values exactly):",
            "| Chip | Peripheral | Register | Address | Offset | Register reset | Register access | Field | Bits | Field reset | Field access | Source |",
            "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
        ]
        for row in evidence:
            values = [
                row.get("chip") or "",
                row.get("peripheral") or "",
                row.get("register_name") or "",
                row.get("address") or "",
                row.get("offset") or "",
                row.get("register_reset") or "",
                row.get("register_access") or "",
                row.get("field_name") or "",
                row.get("bit_range") or "",
                row.get("bitfield_reset") or "",
                row.get("bitfield_access") or "",
                row.get("source_ref") or "",
            ]
            lines.append(
                "| "
                + " | ".join(
                    str(value).replace("|", "\\|").replace("\n", " ")
                    for value in values
                )
                + " |"
            )
            description = " ".join(str(row.get("bitfield_description") or "").split())
            if description:
                lines.append(
                    f"  - {row.get('register_name') or 'Register'} "
                    f"{row.get('field_name') or 'field'} description: {description}"
                )
        if warnings:
            lines.extend(["", "Evidence warnings:", *[f"- {warning}" for warning in warnings]])
        return "\n".join(lines)

    def _build_prompt(self, ctx: DriverContext, filenames: dict[str, str]) -> str:
        specification = self._bounded_specification(ctx.datasheet_content or "")
        registers = json.dumps(ctx.registers, indent=2) if ctx.registers else "Not separately provided"
        requirements = (ctx.requirements or "Use the specification as the source of truth").strip()
        structured_evidence = self._format_register_evidence(
            ctx.register_evidence,
            ctx.register_evidence_warnings,
        )
        return f"""Generate the following exact files:
- Header: {filenames['header']}
- Source: {filenames['source']}
- Test: {filenames['test']}
- Notes: {filenames['notes']}

Device name: {ctx.device_name}
Device type: {ctx.device_type}
Interface: {ctx.interface}
MCU family: {ctx.mcu_family}
Platform: {ctx.platform or 'portable C'}
Additional requirements: {requirements}

Explicit register definitions:
{registers}

{structured_evidence}

Specification content:
{specification or 'No document text was supplied.'}

The source and test files must include "{filenames['header']}". The notes must list assumptions,
integration steps, callback contracts, timing constraints, and any specification gaps.
Structured register knowledge is authoritative over conflicting prose. Preserve exact register names,
addresses, offsets, reset values, access modes, field names, and bit ranges from the evidence table,
and cite its Source value in NOTES. When a value is absent or warned as partial, do not guess it;
use a clearly marked assumption or leave the API configurable.
"""

    @staticmethod
    def _validate_generated_driver(driver: GeneratedDriver) -> list[str]:
        warnings: list[str] = []
        if "#ifndef" not in driver.header_content or "#define" not in driver.header_content:
            warnings.append("The header file does not contain a conventional include guard")
        include = f'#include "{driver.header_file}"'
        if include not in driver.source_content:
            warnings.append("The source file does not include the generated header by name")
        if include not in driver.test_content:
            warnings.append("The test file does not include the generated header by name")
        for filename, content in (
            (driver.header_file, driver.header_content),
            (driver.source_file, driver.source_content),
            (driver.test_file, driver.test_content),
        ):
            if content.count("{") != content.count("}"):
                warnings.append(f"{filename} has unbalanced braces")
        return warnings

    @staticmethod
    def _bounded_specification(content: str) -> str:
        if len(content) <= _MAX_SPEC_CHARS:
            return content
        head_size = int(_MAX_SPEC_CHARS * 0.75)
        tail_size = _MAX_SPEC_CHARS - head_size
        return (
            content[:head_size]
            + "\n\n[Specification content omitted because of context limits]\n\n"
            + content[-tail_size:]
        )

    @staticmethod
    def _safe_stem(device_name: str) -> str:
        stem = re.sub(r"[^A-Za-z0-9]+", "_", device_name.strip()).strip("_").lower()
        return stem[:64] or "device"

    @staticmethod
    def _strip_code_fence(content: str) -> str:
        match = re.fullmatch(r"```(?:[A-Za-z0-9_+-]+)?\s*\n(.*?)\n```", content.strip(), re.DOTALL)
        return match.group(1).strip() if match else content.strip()
