"""DebugAgent - crash log and fault analysis for ARM Cortex-M targets."""

from __future__ import annotations

import asyncio
from dataclasses import replace

from loguru import logger

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    CancelledException,
    ValidationError,
)
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient

from .fault_decode import (
    FAULT_REGISTER_ADDRESSES,
    classify_log_faults,
    decode_fault_registers,
    scan_crash_log,
)
from .log_evidence import read_debug_logs
from .parsers import fallback_analysis, merge_with_evidence, parse_analysis
from .prompts import SYSTEM_PROMPT, build_analysis_prompt, build_repair_prompt
from .report import build_debug_report
from .types import CrashAnalysis, DebugContext, DebugResult, FaultRegisterEvidence
from app.agents.structured_output import StructuredOutputError


class DebugAgent(BaseAgent):
    """Debug analysis agent.

    Stages: collect -> read live fault registers (optional) -> deterministic
    decode -> LLM structured analysis (JSON with one repair round, then a
    graceful fallback) -> merge with evidence -> report.
    """

    def __init__(self, llm_bridge: LLMBridge, mcp_client: MCPClient, skill_registry=None):
        super().__init__(AgentConfig(agent_type=AgentType.DEBUG, timeout_seconds=300, durable_runtime=True), skill_registry=skill_registry)
        self._llm = llm_bridge
        self._mcp = mcp_client

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, DebugContext):
            raise ValidationError("DebugAgent requires DebugContext")
        ctx = context
        if not ctx.crash_description and not ctx.crash_log and not ctx.log_files:
            raise ValidationError("crash_description, crash_log, or log_files is required")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        assert isinstance(ctx, DebugContext)
        task_id = ctx.task_id
        if ctx.log_files:
            await self._report_progress(task_id, 5, "read_logs", "Reading debug log evidence")
            try:
                file_evidence = await asyncio.to_thread(read_debug_logs, ctx.project_root, ctx.log_files)
            except ValueError as error:
                raise ValidationError(str(error)) from error
            ctx = replace(ctx, crash_log="\n\n".join(part for part in (ctx.crash_log, file_evidence) if part))
        skill_plan = await self._prepare_agent_skills(
            ctx, "analyze", scope="debug", inputs={"mcu_target": ctx.mcu_target}
        )

        # Stage 1: collect the reported evidence
        await self._report_progress(task_id, 10, "collect", "Collecting debug information")
        debug_info = self._build_debug_info(ctx)

        # Stage 2: read live fault registers when a target is connected
        register_dump = {str(name).strip().upper(): value for name, value in (ctx.register_dump or {}).items()}
        if ctx.mcu_target:
            await self._report_progress(task_id, 25, "read_regs", "Reading MCU fault registers")
            live = await self._read_fault_registers(task_id)
            for name, value in live.items():
                register_dump.setdefault(name, value)

        # Stage 3: deterministic decode (never delegated to the LLM)
        await self._report_progress(task_id, 40, "decode", "Decoding fault status registers")
        evidence = decode_fault_registers(register_dump)
        log_signatures = scan_crash_log(ctx.crash_log or "")
        deterministic_fault_type = evidence.fault_type or classify_log_faults(ctx.crash_log or "")
        deterministic_evidence = "\n".join(
            [
                *(f"- {item}" for item in evidence.decoded),
                *(f"- {item}" for item in log_signatures),
            ]
        )
        deterministic_steps = self._deterministic_recommendations(
            evidence, deterministic_fault_type
        )

        # Stage 4: structured LLM analysis with repair and fallback
        await self._report_progress(task_id, 60, "analyze", "Analyzing crash with LLM")
        self._is_cancelled(task_id)
        analysis_error = ""
        try:
            analysis = await self._analyze(
                debug_info, deterministic_evidence, skill_plan.prompt, task_id=task_id
            )
        except CancelledException:
            raise
        except Exception as error:
            if not deterministic_evidence:
                raise
            logger.warning("Debug model analysis unavailable: {}", type(error).__name__)
            analysis_error = "Model analysis is unavailable; deterministic fault evidence is preserved."
            analysis = fallback_analysis(analysis_error)
        self._is_cancelled(task_id)
        analysis = merge_with_evidence(
            analysis, deterministic_fault_type, evidence.affected_address, deterministic_steps
        )

        # Stage 5: report
        await self._report_progress(task_id, 90, "report", "Generating debug report")
        self._is_cancelled(task_id)
        report = build_debug_report(ctx, analysis, evidence, log_signatures)
        return DebugResult(
            task_id=task_id,
            status=AgentStatus.COMPLETED,
            message="Crash analysis completed",
            data={
                "analysis": analysis.probable_cause,
                "analysis_error": analysis_error,
                "fault_type": analysis.fault_type,
                "affected_address": analysis.affected_address,
                "call_stack": analysis.call_stack,
                "recommendations": analysis.recommendations,
                "register_evidence": evidence.decoded,
                "log_signatures": log_signatures,
                "mcu_target": ctx.mcu_target,
                "report_markdown": report,
            },
            crash_analysis=analysis,
            debug_steps=analysis.recommendations,
            register_evidence=evidence,
        )

    async def _analyze(
        self,
        debug_info: str,
        deterministic_evidence: str,
        skill_prompt: str,
        *,
        task_id: str,
    ) -> CrashAnalysis:
        """Run the structured analysis with one repair round, then fallback."""
        prompt = build_analysis_prompt(debug_info, deterministic_evidence)
        if skill_prompt:
            prompt = f"{skill_prompt}\n\n{prompt}"
        response = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=4096,
            **self._llm_call_options(),
        )
        self._is_cancelled(task_id)
        try:
            return parse_analysis(response.content)
        except StructuredOutputError:
            repaired = await self._llm.generate(
                [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": build_repair_prompt(response.content)},
                ],
                temperature=0.0,
                max_tokens=4096,
                **self._llm_call_options(),
            )
            self._is_cancelled(task_id)
            try:
                return parse_analysis(repaired.content)
            except StructuredOutputError:
                logger.warning("Crash analysis fell back to plain-text cause")
                return fallback_analysis(repaired.content)

    async def _read_fault_registers(self, task_id: str) -> dict[str, str]:
        """Read the SCB fault status registers from a connected target."""
        values: dict[str, str] = {}
        for address, name in FAULT_REGISTER_ADDRESSES.items():
            self._is_cancelled(task_id)
            try:
                result = await self._mcp.call_tool("stm32_read_register", address=address, size=4)
            except CancelledException:
                raise
            except Exception as exc:
                logger.debug(f"Could not read MCU fault register {name}: {exc}")
                continue
            self._is_cancelled(task_id)
            if result.success:
                values[name] = str(result.data.get("output", ""))
        return values

    @staticmethod
    def _build_debug_info(ctx: DebugContext) -> str:
        """Render the reported crash evidence into the analysis input text."""
        debug_info = f"Crash description: {ctx.crash_description}\n"
        if ctx.crash_log:
            debug_info += f"\nCrash log:\n{ctx.crash_log}\n"
        if ctx.stack_trace:
            debug_info += f"\nStack trace:\n{ctx.stack_trace}\n"
        if ctx.register_dump:
            debug_info += "\nRegister dump:\n"
            for reg, val in ctx.register_dump.items():
                debug_info += f"  {reg}: {val}\n"
        return debug_info

    @staticmethod
    def _deterministic_recommendations(
        evidence: FaultRegisterEvidence,
        fault_type: str,
    ) -> list[str]:
        """First-run debugging steps derived directly from the decoded evidence."""
        steps: list[str] = []
        decoded_text = " ".join(evidence.decoded).lower()
        if evidence.affected_address:
            steps.append(
                f"Map the faulting address {evidence.affected_address} in the linker map "
                "file to identify the accessed variable or peripheral."
            )
        if "unstacking" in decoded_text or "stacking" in decoded_text or "stack overflow" in fault_type.lower():
            steps.append(
                "Check stack sizing and interrupt nesting: raise the task and handler "
                "stack sizes, then retest with stack canaries or a fill pattern."
            )
        if "invstate" in decoded_text or "invpc" in decoded_text:
            steps.append(
                "Verify branch targets and exception return values: a corrupted "
                "function pointer or EXC_RETURN usually causes INVSTATE/INVPC."
            )
        if "undefinstr" in decoded_text:
            steps.append(
                "Disassemble the faulting PC: an undefined instruction often means a "
                "jump into data, a corrupted vector, or an unsupported instruction."
            )
        if "divbyzero" in decoded_text:
            steps.append("Audit every division and modulo site for zero divisors.")
        if "unaligned" in decoded_text:
            steps.append("Check pointer casts and packed-struct access for unaligned loads or stores.")
        if "impreciserr" in decoded_text:
            steps.append(
                "An imprecise bus fault reports an approximate PC: enable write "
                "buffering DISABLE or inspect nearby peripheral/DMA accesses."
            )
        if "nocp" in decoded_text:
            steps.append("The target executed an FPU instruction without the FPU enabled; check CPACR and build flags.")
        if "watchdog" in fault_type.lower():
            steps.append("Locate the watchdog refresh path and verify it runs in every loop and idle branch.")
        if not steps:
            steps.append(
                "Capture PC, LR, SP, and the stacked frame from the fault handler, then "
                "symbolize them with addr2line or the ELF map file."
            )
        return steps
