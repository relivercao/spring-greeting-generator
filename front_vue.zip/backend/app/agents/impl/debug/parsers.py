"""Parse and normalize the structured crash analysis returned by the LLM."""

from __future__ import annotations

import re
from typing import Any, Optional

from app.agents.structured_output import StructuredOutputError, parse_json_object

from .types import CrashAnalysis

_ADDRESS_PATTERN = re.compile(r"0[xX][0-9a-fA-F]{1,16}")


def parse_analysis(content: str) -> CrashAnalysis:
    """Parse the LLM JSON analysis into a CrashAnalysis.

    Raises StructuredOutputError when the response is not a usable JSON object,
    which signals the caller to attempt one repair round.
    """
    payload = parse_json_object(content)
    fault_type = str(payload.get("fault_type") or "").strip()
    probable_cause = str(payload.get("probable_cause") or "").strip()
    if not fault_type and not probable_cause:
        raise StructuredOutputError("The analysis JSON has neither fault_type nor probable_cause")
    return CrashAnalysis(
        fault_type=fault_type,
        probable_cause=probable_cause,
        affected_address=normalize_address(payload.get("affected_address")),
        call_stack=_string_list(payload.get("call_stack"), limit=64),
        recommendations=_string_list(payload.get("recommendations"), limit=32),
    )


def fallback_analysis(content: str) -> CrashAnalysis:
    """Degrade a non-JSON response into a plain-cause analysis.

    Used after the repair round also fails, mirroring the graceful fallback
    design of the agent generator: the raw text is preserved as the cause.
    """
    text = (content or "").strip()
    return CrashAnalysis(probable_cause=text or "The analysis provider returned no content.")


def merge_with_evidence(
    analysis: CrashAnalysis,
    deterministic_fault_type: str,
    deterministic_address: Optional[str],
    deterministic_recommendations: list[str],
) -> CrashAnalysis:
    """Reconcile the LLM analysis with the authoritative deterministic evidence.

    Deterministic values win when present; LLM values fill the gaps and the
    deterministic recommendations are surfaced first.
    """
    if deterministic_fault_type:
        analysis.fault_type = deterministic_fault_type
    elif not analysis.fault_type:
        analysis.fault_type = "Unclassified fault"
    if deterministic_address:
        analysis.affected_address = deterministic_address
    merged_recommendations = list(deterministic_recommendations)
    for recommendation in analysis.recommendations:
        if recommendation not in merged_recommendations:
            merged_recommendations.append(recommendation)
    analysis.recommendations = merged_recommendations
    return analysis


def normalize_address(raw: Any) -> Optional[str]:
    """Normalize an address-like value to a 0x-prefixed string or None."""
    if raw is None:
        return None
    text = str(raw).strip()
    if not text or text.lower() in {"null", "none", "n/a", "-"}:
        return None
    match = _ADDRESS_PATTERN.search(text)
    if match:
        try:
            return f"0x{int(match.group(0), 16):08X}"
        except ValueError:
            return None
    return None


def _string_list(raw: Any, limit: int) -> list[str]:
    if not isinstance(raw, list):
        return []
    return [str(item).strip() for item in raw[:limit] if str(item).strip()]
