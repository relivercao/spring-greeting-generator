"""Typed inputs and outputs for the crash debug agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from app.agents.base import AgentContext, AgentResult


@dataclass
class DebugContext(AgentContext):
    """Debug context"""

    crash_description: str = ""
    crash_log: Optional[str] = None
    log_files: list[str] = field(default_factory=list)
    register_dump: Optional[dict[str, str]] = None
    stack_trace: Optional[str] = None
    mcu_target: Optional[str] = None


@dataclass
class FaultRegisterEvidence:
    """Deterministic decoding result for Cortex-M fault registers."""

    raw: dict[str, str] = field(default_factory=dict)
    decoded: list[str] = field(default_factory=list)
    fault_type: str = ""
    affected_address: Optional[str] = None


@dataclass
class CrashAnalysis:
    """Crash analysis result"""

    fault_type: str = ""        # HardFault / UsageFault / BusFault / MemManage / etc.
    probable_cause: str = ""
    affected_address: Optional[str] = None
    call_stack: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


@dataclass
class DebugResult(AgentResult):
    """Debug result"""

    crash_analysis: Optional[CrashAnalysis] = None
    debug_steps: list[str] = field(default_factory=list)
    register_evidence: Optional[FaultRegisterEvidence] = None
