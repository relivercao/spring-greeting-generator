"""Deterministic ARM Cortex-M fault register and crash log decoding.

All logic in this module is pure and side-effect free: register values and
free-form crash logs are decoded into evidence strings without any LLM call,
following the deterministic-first design used by the driver agent. The LLM
stage consumes this evidence but never overrides it.
"""

from __future__ import annotations

import re
from typing import Optional

from .types import FaultRegisterEvidence

# SCB fault status registers read from a live target (address -> register name).
FAULT_REGISTER_ADDRESSES = {
    "0xE000ED28": "CFSR",
    "0xE000ED2C": "HFSR",
    "0xE000ED34": "MMFAR",
    "0xE000ED38": "BFAR",
}

# CFSR bit decoders: (register, bit index, label, meaning).
_CFSR_BITS: list[tuple[str, int, str, str]] = [
    ("MMFSR", 0, "IACCVIOL", "instruction fetch from an execute-never region (MemManage)"),
    ("MMFSR", 1, "DACCVIOL", "data access violated memory protection permissions (MemManage)"),
    ("MMFSR", 3, "MUNSTKERR", "unstacking error during exception return (MemManage)"),
    ("MMFSR", 4, "MSTKERR", "stacking error during exception entry (MemManage)"),
    ("MMFSR", 5, "MLSPERR", "fault during lazy FP state preservation (MemManage)"),
    ("MMFSR", 7, "MMARVALID", "MMFAR holds the faulting address"),
    ("BFSR", 8, "IBUSERR", "instruction bus error (BusFault)"),
    ("BFSR", 9, "PRECISERR", "precise data bus error; trust BFAR only when BFARVALID is set"),
    ("BFSR", 10, "IMPRECISERR", "imprecise data bus error; faulting PC is approximate"),
    ("BFSR", 11, "UNSTKERR", "unstacking bus error during exception return"),
    ("BFSR", 12, "STKERR", "stacking bus error during exception entry"),
    ("BFSR", 13, "LSPERR", "bus fault during lazy FP state preservation"),
    ("BFSR", 15, "BFARVALID", "BFAR holds the faulting address"),
    ("UFSR", 16, "UNDEFINSTR", "undefined instruction executed (UsageFault)"),
    ("UFSR", 17, "INVSTATE", "invalid EPSR state, e.g. branch to a non-ARM/Thumb address"),
    ("UFSR", 18, "INVPC", "invalid PC load, e.g. EXC_RETURN corruption"),
    ("UFSR", 19, "NOCP", "coprocessor access without an FPU present (UsageFault)"),
    ("UFSR", 20, "STKOF", "stack overflow detected on the PSPLIM/MSPLIM limit (Armv8-M)"),
    ("UFSR", 24, "UNALIGNED", "unaligned access where unsupported (UsageFault)"),
    ("UFSR", 25, "DIVBYZERO", "integer division by zero (UsageFault)"),
]

_HFSR_BITS: list[tuple[int, str, str]] = [
    (1, "VECTTBL", "fault while reading the vector table during exception entry"),
    (30, "FORCED", "fault escalated to HardFault from a configurable fault"),
    (31, "DEBUGEVT", "fault escalated from a debug event"),
]

# Textual crash log signatures (regex, fault classification, evidence text).
_LOG_SIGNATURES: list[tuple[str, str, str]] = [
    (r"\bhard\s*fault\b", "HardFault", "crash log mentions a HardFault"),
    (r"\busage\s*fault\b", "UsageFault", "crash log mentions a UsageFault"),
    (r"\bbus\s*fault\b", "BusFault", "crash log mentions a BusFault"),
    (r"\bmem(ory)?\s*manage(ment)?\s*fault\b", "MemManage", "crash log mentions a MemManage fault"),
    (r"\bstack\s*(overflow|collision|corruption)\b", "StackOverflow", "stack overflow signature in the log"),
    (r"\bheap\s*(overflow|corruption)\b", "HeapCorruption", "heap corruption signature in the log"),
    (r"\b(use[- ]after[- ]free|double[- ]free)\b", "HeapCorruption", "heap lifetime error signature in the log"),
    (r"\b(assert(ion)?\s+failed|assert\b)", "Assertion", "assertion failure signature in the log"),
    (r"\b(watchdog|iwdg|wwdg)\s*(timeout|reset)?\b", "WatchdogReset", "watchdog signature in the log"),
    (r"\bdeadlock\b", "Deadlock", "deadlock signature in the log"),
]

_MEMORY_WORD = re.compile(
    r"^\s*(?:0[xX])?[0-9a-fA-F]{8}\s*:\s*(?:0[xX])?([0-9a-fA-F]{1,8})\s*$",
    re.MULTILINE,
)
_REGISTER_ASSIGNMENT = re.compile(
    r"(?:CFSR|HFSR|MMFAR|BFAR|value)\s*[:=]\s*(.+)", re.IGNORECASE,
)
_CFSR_FAULT_MASKS = {
    group: sum(1 << bit for field, bit, _, _ in _CFSR_BITS if field == group and bit not in {7, 15})
    for group in ("MMFSR", "BFSR", "UFSR")
}


def parse_register_value(raw: str | int | None) -> Optional[int]:
    """Extract one 32-bit register value from a tool response string.

    OpenOCD address/value rows use hexadecimal data. Standalone values accept
    explicit hex, bare hex containing letters, or unsigned decimal. Diagnostic
    prose, ambiguous rows, partial numeric tokens, and values outside 32 bits
    are not register evidence.
    """
    if isinstance(raw, bool) or not isinstance(raw, (str, int)):
        return None
    text = str(raw).strip()
    if not text:
        return None
    words = _MEMORY_WORD.findall(text)
    if words:
        return int(words[0], 16) if len(words) == 1 else None
    assignment = _REGISTER_ASSIGNMENT.fullmatch(text)
    if assignment:
        text = assignment.group(1).strip()
    if re.fullmatch(r"0[xX][0-9a-fA-F]{1,8}", text):
        return int(text, 16)
    hex_word = re.fullmatch(r"(?=[0-9a-fA-F]*[a-fA-F])[0-9a-fA-F]{1,8}", text)
    if hex_word:
        return int(text, 16)
    decimal = re.fullmatch(r"[0-9]{1,10}", text)
    if decimal:
        value = int(text)
        return value if value <= 0xFFFFFFFF else None
    return None


def decode_fault_registers(register_dump: dict[str, str]) -> FaultRegisterEvidence:
    """Decode CFSR/HFSR/MMFAR/BFAR values into deterministic evidence.

    Accepts any register-name casing (``cfsr``/``CFSR``). Values may be hex,
    bare hex words, or decimal strings; unparsable values are ignored.
    """
    normalized = {str(name).strip().upper(): value for name, value in (register_dump or {}).items()}
    evidence = FaultRegisterEvidence(raw=dict(register_dump or {}))

    cfsr = parse_register_value(normalized.get("CFSR", ""))
    hfsr = parse_register_value(normalized.get("HFSR", ""))
    mmfar = parse_register_value(normalized.get("MMFAR", ""))
    bfar = parse_register_value(normalized.get("BFAR", ""))

    if cfsr is not None:
        for field_name, bit, label, meaning in _CFSR_BITS:
            if cfsr & (1 << bit):
                evidence.decoded.append(f"CFSR.{field_name}.{label}: {meaning}")
    if hfsr is not None:
        for bit, label, meaning in _HFSR_BITS:
            if hfsr & (1 << bit):
                evidence.decoded.append(f"HFSR.{label}: {meaning}")

    mmar_valid = cfsr is not None and cfsr & (1 << 7)
    bfar_valid = cfsr is not None and cfsr & (1 << 15)
    if mmar_valid and mmfar is not None:
        evidence.affected_address = f"0x{mmfar:08X}"
        evidence.decoded.append(f"MMFAR (valid): faulting data address {evidence.affected_address}")
    if bfar_valid and bfar is not None:
        address = f"0x{bfar:08X}"
        evidence.affected_address = evidence.affected_address or address
        evidence.decoded.append(f"BFAR (valid): faulting bus address {address}")

    evidence.fault_type = _classify_fault(cfsr, hfsr)
    return evidence


def scan_crash_log(crash_log: str) -> list[str]:
    """Detect known fault signatures in a free-form crash log."""
    if not crash_log:
        return []
    findings: list[str] = []
    lowered = crash_log.lower()
    for pattern, _, evidence in _LOG_SIGNATURES:
        if re.search(pattern, lowered):
            findings.append(evidence)
    return findings


def classify_log_faults(crash_log: str) -> str:
    """Return the first matching fault classification for a crash log."""
    if not crash_log:
        return ""
    lowered = crash_log.lower()
    for pattern, fault_type, _ in _LOG_SIGNATURES:
        if re.search(pattern, lowered):
            return fault_type
    return ""


def _classify_fault(cfsr: Optional[int], hfsr: Optional[int]) -> str:
    """Classify the fault from the decoded status registers."""
    if cfsr is None and hfsr is None:
        return ""
    escalated = hfsr is not None and hfsr & (1 << 30)
    if cfsr is not None:
        mmfsr = cfsr & _CFSR_FAULT_MASKS["MMFSR"]
        bfsr = cfsr & _CFSR_FAULT_MASKS["BFSR"]
        ufsr = cfsr & _CFSR_FAULT_MASKS["UFSR"]
        if ufsr:
            return "HardFault (escalated UsageFault)" if escalated else "UsageFault"
        if bfsr:
            return "HardFault (escalated BusFault)" if escalated else "BusFault"
        if mmfsr:
            return "HardFault (escalated MemManage)" if escalated else "MemManage"
    if escalated:
        return "HardFault (FORCED)"
    if hfsr is not None and hfsr & (1 << 31):
        return "HardFault (DEBUGEVT)"
    if hfsr is not None and hfsr & (1 << 1):
        return "HardFault (VECTTBL)"
    return ""
