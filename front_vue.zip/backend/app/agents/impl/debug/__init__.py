"""Crash debug agent package.

Public surface mirrors the former monolithic `debug_agent.py` module plus the
new deterministic fault decoding helpers.
"""

from .agent import DebugAgent
from .fault_decode import (
    FAULT_REGISTER_ADDRESSES,
    classify_log_faults,
    decode_fault_registers,
    parse_register_value,
    scan_crash_log,
)
from .parsers import (
    fallback_analysis,
    merge_with_evidence,
    normalize_address,
    parse_analysis,
)
from .prompts import SYSTEM_PROMPT, build_analysis_prompt, build_repair_prompt
from .report import build_debug_report
from .types import CrashAnalysis, DebugContext, DebugResult, FaultRegisterEvidence

__all__ = [
    "DebugAgent",
    "CrashAnalysis",
    "DebugContext",
    "DebugResult",
    "FaultRegisterEvidence",
    "FAULT_REGISTER_ADDRESSES",
    "SYSTEM_PROMPT",
    "decode_fault_registers",
    "parse_register_value",
    "scan_crash_log",
    "classify_log_faults",
    "parse_analysis",
    "fallback_analysis",
    "merge_with_evidence",
    "normalize_address",
    "build_analysis_prompt",
    "build_repair_prompt",
    "build_debug_report",
]
