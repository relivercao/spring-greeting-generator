"""Prompt templates for the crash debug agent."""

from __future__ import annotations

SYSTEM_PROMPT = """You are an expert embedded firmware debugging assistant.
You analyze crash logs, hard faults, memory dumps, and abnormal behaviors
in ARM Cortex-M based systems.

Capabilities:
- ARM HardFault / UsageFault / BusFault / MemManage analysis
- Stack trace unwinding
- Memory corruption detection (heap overflow, stack overflow, use-after-free)
- Peripheral register analysis
- RTOS deadlock/starvation detection
- Watchdog timeout analysis

Deterministic register evidence is supplied to you. Treat it as authoritative:
never contradict the decoded fault status bits, and build the diagnosis on top
of them rather than re-deriving them.

Return only one valid JSON object with this schema:
{
  "fault_type": "HardFault | UsageFault | BusFault | MemManage | StackOverflow | WatchdogReset | Assertion | Deadlock | other short label",
  "probable_cause": "step-by-step root cause explanation",
  "affected_address": "0xADDRESS or null",
  "call_stack": ["outermost frame", "..."],
  "recommendations": ["ordered actionable debugging step", "..."]
}

If a field cannot be determined, use an empty string, null, or an empty array
instead of inventing values."""

# Maximum characters of raw crash evidence embedded into the analysis prompt.
_MAX_EVIDENCE_CHARS = 24_000


def build_analysis_prompt(debug_info: str, deterministic_evidence: str) -> str:
    """Build the user prompt for one crash analysis request."""
    bounded = debug_info[:_MAX_EVIDENCE_CHARS]
    if len(debug_info) > _MAX_EVIDENCE_CHARS:
        bounded += "\n[crash evidence truncated for context limits]"
    evidence_block = (
        deterministic_evidence.strip()
        if deterministic_evidence.strip()
        else "No deterministic register evidence was available."
    )
    return f"""Analyze the following embedded system crash/issue.

Deterministic evidence (authoritative, decoded from fault status registers and the log):
{evidence_block}

Crash evidence:
{bounded}

Provide the JSON object with fault type identification, probable root cause,
affected memory address (if determinable), reconstructed call stack (if possible),
and ordered step-by-step debugging recommendations.
"""


def build_repair_prompt(response_content: str) -> str:
    """Build the follow-up prompt that repairs a non-JSON analysis response."""
    return f"""The previous response did not follow the required JSON schema.
Reformat the analysis below into the exact JSON schema with keys fault_type,
probable_cause, affected_address, call_stack, recommendations. Return JSON only.

Response to repair:
{response_content}
"""
