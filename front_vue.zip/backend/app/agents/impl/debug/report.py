"""Markdown report rendering for the crash debug agent."""

from __future__ import annotations

from .types import CrashAnalysis, DebugContext, FaultRegisterEvidence


def build_debug_report(
    ctx: DebugContext,
    analysis: CrashAnalysis,
    evidence: FaultRegisterEvidence,
    log_signatures: list[str],
) -> str:
    """Render the structured debug report in Markdown."""
    lines = [
        "# Crash Analysis Report",
        "",
        f"- MCU target: {ctx.mcu_target or 'not specified'}",
        f"- Fault type: {analysis.fault_type or 'Unclassified fault'}",
        f"- Affected address: {analysis.affected_address or 'not determined'}",
        "",
        "## Probable cause",
        "",
        analysis.probable_cause or "No cause was determined.",
        "",
    ]
    if evidence.decoded or evidence.raw:
        lines.extend(["## Register evidence (deterministic)", ""])
        if evidence.decoded:
            lines.extend(f"- {item}" for item in evidence.decoded)
        else:
            lines.append("- Fault status registers were present but no fault bits were set.")
        if evidence.raw:
            raw_values = ", ".join(f"{name}={value}" for name, value in evidence.raw.items())
            lines.append(f"- Raw values: {raw_values}")
        lines.append("")
    if log_signatures:
        lines.extend(["## Log signatures", "", *[f"- {item}" for item in log_signatures], ""])
    if analysis.call_stack:
        lines.extend(["## Reconstructed call stack", ""])
        lines.extend(f"{index}. {frame}" for index, frame in enumerate(analysis.call_stack, start=1))
        lines.append("")
    if analysis.recommendations:
        lines.extend(["## Debugging steps", ""])
        lines.extend(f"{index}. {step}" for index, step in enumerate(analysis.recommendations, start=1))
        lines.append("")
    return "\n".join(lines).strip() + "\n"
