"""Load bounded text evidence explicitly selected within a debug project."""

from __future__ import annotations

from pathlib import Path
import stat

MAX_LOG_FILES = 8
MAX_LOG_FILE_BYTES = 256 * 1024
MAX_LOG_TOTAL_BYTES = 512 * 1024


def read_debug_logs(project_root: str | None, log_files: list[str]) -> str:
    """Read requested logs, rejecting incomplete or out-of-project evidence."""
    if not log_files:
        return ""
    if not project_root:
        raise ValueError("A project root is required to read debug log files")
    if len(log_files) > MAX_LOG_FILES:
        raise ValueError(f"Select at most {MAX_LOG_FILES} debug log files")
    try:
        root = Path(project_root).resolve(strict=True)
        if not root.is_dir():
            raise ValueError("The debug log project root must be a directory")
        sections: list[str] = []
        total_bytes = 0
        for supplied in log_files:
            path = Path(supplied)
            path = (path if path.is_absolute() else root / path).resolve(strict=True)
            if not path.is_relative_to(root):
                raise ValueError("Debug log files must be inside the project root")
            info = path.stat()
            if not stat.S_ISREG(info.st_mode):
                raise ValueError("Debug log evidence must be a regular text file")
            if info.st_size > MAX_LOG_FILE_BYTES:
                raise ValueError(f"Each debug log file must be at most {MAX_LOG_FILE_BYTES} bytes")
            with path.open("rb") as stream:
                data = stream.read(MAX_LOG_FILE_BYTES + 1)
            total_bytes += len(data)
            if len(data) > MAX_LOG_FILE_BYTES or total_bytes > MAX_LOG_TOTAL_BYTES:
                raise ValueError("Debug log evidence exceeds the supported size limit")
            encoding = "utf-16" if data.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
            text = data.decode(encoding)
            if "\x00" in text:
                raise ValueError("Debug log evidence must contain text, not binary data")
            sections.append(f"Log file: {path.relative_to(root).as_posix()}\n{text}")
        return "\n\n".join(sections)
    except (OSError, RuntimeError, UnicodeError) as error:
        raise ValueError("A debug log file could not be read as text within the project root") from error
