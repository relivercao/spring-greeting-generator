"""Retrieval stage helpers for the knowledge base agent."""

from __future__ import annotations

import asyncio
from typing import Any

from app.services.knowledge_confidence import coerce_confidence_score

from .types import RETRIEVAL_KEYS, KnowledgeQuery


def normalize_retrieval(retrieval: dict[str, Any]) -> dict[str, Any]:
    """Guarantee the well-known retrieval keys exist and keep extra keys."""
    normalized = dict(retrieval or {})
    defaults: dict[str, Any] = {
        "mode": "register_first",
        "answer": "",
        "confidence": "low",
        "confidence_score": 0.5,
        "exact_hits": [],
        "evidence": [],
        "warnings": [],
    }
    for key in RETRIEVAL_KEYS:
        if normalized.get(key) in (None, ""):
            normalized[key] = defaults[key]
    normalized["confidence_score"] = coerce_confidence_score(
        normalized.get("confidence_score"),
        normalized.get("confidence"),
    )
    return normalized


async def retrieve(service: Any, query: KnowledgeQuery) -> dict[str, Any]:
    """Run the synchronous service lookup in a worker thread."""
    raw = await asyncio.to_thread(
        service.ask,
        query.question,
        chip=query.chip,
        document_id=query.document_id,
        limit=query.limit,
    )
    return normalize_retrieval(raw)
