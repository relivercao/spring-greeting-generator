"""Deterministic evidence summaries for knowledge base answers."""

from __future__ import annotations

from typing import Any

_MAX_SUMMARY_HITS = 3


def _describe_hit(hit: dict[str, Any]) -> str:
    """Render one structured hit as a compact single-line description."""
    parts: list[str] = []
    entity = ".".join(
        str(hit[field])
        for field in ("peripheral", "register_name", "field_name")
        if hit.get(field)
    )
    if entity:
        parts.append(f"`{entity}`")
    if hit.get("bit_range"):
        parts.append(f"bits {hit['bit_range']}")
    if hit.get("address"):
        parts.append(f"@ {hit['address']}")
    if hit.get("match_score") is not None:
        parts.append(f"score {hit['match_score']}")
    if hit.get("source_ref"):
        parts.append(f"src `{hit['source_ref']}`")
    return " — ".join(parts) if parts else "unnamed match"


def build_evidence_summary(retrieval: dict[str, Any]) -> str:
    """Build a short deterministic Markdown summary of the retrieval result.

    The summary always reflects the structured data so users can verify the
    grounding independently of semantic lookup.
    """
    hits = [hit for hit in (retrieval.get("exact_hits") or []) if isinstance(hit, dict)]
    lines = [f"- Retrieval confidence: {retrieval.get('confidence', 'low')}"]

    if hits:
        lines.append(f"- Structured matches: {len(hits)}")
        for hit in hits[:_MAX_SUMMARY_HITS]:
            lines.append(f"  - {_describe_hit(hit)}")
    else:
        lines.append("- Structured matches: none")

    evidence = retrieval.get("evidence") or []
    if evidence:
        lines.append(f"- Evidence excerpts: {len(evidence)}")

    for warning in retrieval.get("warnings") or []:
        lines.append(f"- Warning: {warning}")

    return "\n".join(lines)
