"""KnowledgeBaseAgent - register-first knowledge answers with evidence."""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from app.llm.bridge import LLMBridge
    from app.skills.registry import SkillRegistry

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.services.knowledge_base import KnowledgeBaseService
from app.services.knowledge_answer import augment_knowledge_answer

from .evidence import build_evidence_summary
from .retrieval import retrieve
from .types import KnowledgeQuery, parse_query


class KnowledgeBaseAgent(BaseAgent):
    """Answer firmware knowledge questions with structured evidence.

    Workflow: parse query options -> deterministic register retrieval ->
    LLM grounding (optional, falls back to the structured answer) ->
    deterministic evidence summary.
    """

    def __init__(
        self,
        service: Optional[KnowledgeBaseService] = None,
        llm_bridge: Optional["LLMBridge"] = None,
        skill_registry: Optional["SkillRegistry"] = None,
    ):
        super().__init__(
            AgentConfig(
                agent_type=AgentType.KNOWLEDGE,
                timeout_seconds=60,
                enable_streaming=False,
            ),
            skill_registry=skill_registry,
        )
        self._service = service or KnowledgeBaseService()
        self._llm = llm_bridge

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not (task or "").strip():
            raise ValidationError("Knowledge base question is required")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        query = parse_query(task, context.metadata)
        await self._report_progress(
            context.task_id,
            30,
            "retrieval",
            "Searching structured register data",
        )
        self._is_cancelled(context.task_id)
        retrieval = await retrieve(self._service, query)
        self._is_cancelled(context.task_id)
        result = await augment_knowledge_answer(
            query.question,
            retrieval,
            self._llm,
            use_llm=query.use_llm,
            task_id=context.task_id,
            document_id=query.document_id,
        )
        self._is_cancelled(context.task_id)
        await self._report_progress(
            context.task_id,
            90,
            "evidence",
            "Register evidence is ready",
        )
        self._is_cancelled(context.task_id)
        return AgentResult(
            task_id=context.task_id,
            status=AgentStatus.COMPLETED,
            message="Knowledge base answer generated",
            data={
                "response": result["answer"],
                "evidence_summary": build_evidence_summary(result),
                **result,
            },
        )
