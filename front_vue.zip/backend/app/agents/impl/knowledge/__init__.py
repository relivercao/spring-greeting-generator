"""KnowledgeBaseAgent package - register-first knowledge answers."""

from .agent import KnowledgeBaseAgent
from .evidence import build_evidence_summary
from .retrieval import normalize_retrieval, retrieve
from .types import (
    DEFAULT_QUERY_LIMIT,
    MAX_QUERY_LIMIT,
    KnowledgeQuery,
    parse_query,
)

__all__ = [
    "KnowledgeBaseAgent",
    "KnowledgeQuery",
    "parse_query",
    "retrieve",
    "normalize_retrieval",
    "build_evidence_summary",
    "DEFAULT_QUERY_LIMIT",
    "MAX_QUERY_LIMIT",
]
