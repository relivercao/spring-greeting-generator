"""Typed inputs and parsing helpers for the knowledge base agent."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional

DEFAULT_QUERY_LIMIT = 5
MIN_QUERY_LIMIT = 1
MAX_QUERY_LIMIT = 20

# Keys every normalized retrieval payload exposes to the agent and the report.
RETRIEVAL_KEYS = (
    "mode",
    "answer",
    "confidence",
    "confidence_score",
    "exact_hits",
    "evidence",
    "warnings",
)


@dataclass
class KnowledgeQuery:
    """One parsed knowledge base question with its retrieval options."""

    question: str = ""
    chip: Optional[str] = None
    document_id: Optional[str] = None
    limit: int = DEFAULT_QUERY_LIMIT
    use_llm: bool = True


def _coerce_limit(raw: Any) -> int:
    """Coerce a metadata limit into [MIN_QUERY_LIMIT, MAX_QUERY_LIMIT]."""
    try:
        limit = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_QUERY_LIMIT
    return max(MIN_QUERY_LIMIT, min(MAX_QUERY_LIMIT, limit))


def _clean_optional_str(raw: Any) -> Optional[str]:
    if raw is None:
        return None
    value = str(raw).strip()
    return value or None


def parse_query(task: str, metadata: Optional[Mapping[str, Any]]) -> KnowledgeQuery:
    """Build a KnowledgeQuery from the raw task text and context metadata.

    Invalid limit values fall back to the default instead of failing the
    question, and the limit is always clamped to a sane range.
    """
    meta = metadata or {}
    return KnowledgeQuery(
        question=(task or "").strip(),
        chip=_clean_optional_str(meta.get("chip")),
        document_id=_clean_optional_str(meta.get("document_id")),
        limit=_coerce_limit(meta.get("limit", DEFAULT_QUERY_LIMIT)),
        # Only an explicit False disables low-confidence semantic lookup.
        use_llm=meta.get("use_llm", True) is not False,
    )
