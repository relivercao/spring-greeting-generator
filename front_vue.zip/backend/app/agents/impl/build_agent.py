"""Compatibility shim - the BuildAgent implementation moved to `app.agents.impl.build`.

The build agent now parses structured diagnostics through the driver agent's
GCC-compatible parser and returns JSON-validated fix suggestions. This module
re-exports the previous public symbols so existing imports keep working.
"""

from app.agents.impl.build import (
    BuildAgent,
    BuildContext,
    BuildResult,
    CompileError,
)

__all__ = [
    "BuildAgent",
    "BuildContext",
    "BuildResult",
    "CompileError",
]
