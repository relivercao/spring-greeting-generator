"""Compatibility shim: the AgentGeneratorAgent implementation moved to the agent_generator/ package."""

from app.agents.impl.agent_generator.agent import AgentGeneratorAgent
from app.agents.impl.agent_generator.types import AgentGeneratorContext

__all__ = ["AgentGeneratorAgent", "AgentGeneratorContext"]
