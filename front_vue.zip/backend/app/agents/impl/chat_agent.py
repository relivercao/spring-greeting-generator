"""Compatibility shim: the ChatAgent implementation moved to the chat/ package."""

from app.agents.impl.chat.agent import ChatAgent
from app.agents.impl.chat.intents import detect_intent
from app.agents.impl.chat.prompts import SYSTEM_PROMPT
from app.agents.impl.chat.types import ChatContext, ChatResult

__all__ = [
    "ChatAgent",
    "ChatContext",
    "ChatResult",
    "SYSTEM_PROMPT",
    "detect_intent",
]
