"""Compatibility shim: the ImageGenerationAgent implementation moved to the image_generation/ package."""

from app.agents.impl.image_generation.agent import ImageGenerationAgent
from app.agents.impl.image_generation.types import ImageGenerationContext

__all__ = ["ImageGenerationAgent", "ImageGenerationContext"]
