"""Compatibility shim - the DebugAgent implementation moved to `app.agents.impl.debug`.

The debug agent now decodes Cortex-M fault registers deterministically and
uses a structured JSON LLM analysis with repair and fallback. This module
re-exports the previous public symbols so existing imports keep working.
"""

from app.agents.impl.debug import (
    CrashAnalysis,
    DebugAgent,
    DebugContext,
    DebugResult,
)

__all__ = [
    "DebugAgent",
    "DebugContext",
    "CrashAnalysis",
    "DebugResult",
]
