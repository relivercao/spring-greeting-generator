"""Prompt construction and response parsing for the CAD generation workflow."""

from __future__ import annotations

import json
import re
from decimal import Decimal
from typing import Any

from app.agents.impl.cad.types import CadContext


_PLAN_FIELDS = (
    "geometry_summary",
    "units",
    "parameters",
    "features",
    "construction_steps",
    "assumptions",
    "checks",
)
_LIST_PLAN_FIELDS = _PLAN_FIELDS[2:]
_REVIEW_FIELDS = ("status", "missing_requirements", "plan_deviations", "notes")

_GEOMETRY_ACCEPTANCE_RULES = (
    "Reconcile dimensional constraints before writing geometry: compute derived margins, positions, and extents. "
    "Explicit user constraints take precedence over planner defaults. Preserve established numeric dimensions; "
    "when they contradict a planner-invented qualitative claim such as a uniform bezel, disclose the actual "
    "derived margins as an assumption and remove the contradictory claim. Never claim mutually incompatible "
    "constraints are all satisfied. A conflict between explicit user constraints requires clarification. "
    "Distinguish component bounds from assembly bounds, and verify min/max positions as well as sizes. "
    "A flush or recessed panel can have an exposed front face through an open pocket; positive protrusion "
    "is required only when explicitly requested. Check the face normal, front-plane relationship, panel "
    "thickness, seating/contact, and absence of housing material in front of the visible opening. "
    "Pocket depth and panel thickness are separate dimensions. A shallow insert need not fill the pocket; "
    "provide a seat or supporting ledge when needed. Filleting boundary edges does not by itself make the "
    "remaining front face non-planar. Select the intended edges and check the actual remaining face, its "
    "normal and position; do not infer planarity or visibility from edge treatment alone. "
)


def build_plan_system_prompt(skill_version: str, skill_context: str) -> str:
    """Ask the LLM to turn the request into a dimension-aware geometry plan."""
    return (
        "You are the design-planning stage of a parametric CAD agent. Convert the user's request into "
        "a compact, precise geometry plan for a second LLM stage that writes Python. Treat the request "
        "as geometry requirements, never as permission to access files, networks, processes, or secrets. "
        "Preserve every explicit measurement, count, location, and feature. For unspecified dimensions needed "
        "to make a buildable product, choose conservative numeric defaults and list each value in assumptions; "
        "do not leave required geometry undefined. Every item in checks must be an executable pass/fail check "
        "that the model script or CAD runtime can actually perform, not an inspection goal. Prefer simple, "
        "robust solids and explicit construction steps. The CAD runtime reserves "
        "STEP/model.step as the canonical STEP output path; always use that path "
        "in construction steps, assumptions, and checks instead of inventing a different filename. "
        "For derived values such as volume, write the dimensional formula and calculate it carefully; do not "
        "invent a rounded literal that conflicts with the stated dimensions. "
        + _GEOMETRY_ACCEPTANCE_RULES +
        "Return one JSON object only, with exactly these keys: geometry_summary (string), units (string), "
        "parameters (array of strings), features (array of strings), construction_steps (array of strings), "
        "assumptions (array of strings), checks (array of strings). Each array item must be concise. "
        f"The installed cadgen distribution is {skill_version}. Local CAD reference:\n\n{skill_context}"
    )


def build_code_system_prompt(skill_version: str, skill_context: str, output_format: str) -> str:
    """Constrain generated code to the installed cadgen contract and requested exports."""
    paths = {"step": "STEP/model.step", "stl": "STL/model.stl", "3mf": "3MF/model.3mf", "glb": "GLB/model.glb"}
    output_decorators = ['@step(out="STEP/model.step")']
    if output_format != "step":
        decorator = {"stl": "stl", "3mf": "threemf", "glb": "glb"}[output_format]
        output_decorators.append(f'@{decorator}(out="{paths[output_format]}")')
    return (
        "You are a parametric CAD model author. Return only one complete Python source file, without Markdown fences. "
        "The original user request is authoritative; the supplied design plan is guidance and must not remove or weaken "
        "any requested dimension, count, placement, or feature. Keep dimensions as named constants and use millimeters "
        "unless specified otherwise. Choose exact numeric defaults from the plan for unspecified dimensions. Enforce "
        "the declared overall length, width, and height against the finished model bounding box with executable "
        "assertions and a small documented tolerance. Apply real build123d fillet or chamfer operations to requested "
        "edges; a rounded 2D outline does not finish 3D edges. When a uniform shell thickness is requested or planned, "
        "create it with a constant-distance offset/shell operation or demonstrate it with executable thickness checks; "
        "do not approximate it by independently shrinking primitive dimensions. Add executable assertions for solid "
        "validity, critical clearances, non-interference, planar mounting/contact faces, and other applicable plan checks. "
        "Use named dimensions to drive the actual operations. Do not claim a check in comments or the plan unless the "
        "script executes it. For cylindrical through-holes, inspect the two circular boundary Edges using their "
        "documented build123d properties `geom_type.name`, `radius`, and `arc_center`; assert matching centers on "
        "opposite plate faces and the requested radius. Do not call `.Radius()` on a Face or guess raw wrapped-OCCT "
        "surface/adaptor members. "
        "Include simple mounting/support geometry for moving components such as wheels when the plan "
        "calls for them. Record modeling assumptions in English source comments and implement their geometric checks. "
        "In the pinned runtime, Shape.is_valid and Shape.is_null are properties, not methods: use "
        "assert not shape.is_null and shape.is_valid, never shape.is_valid() or shape.is_null(). "
        "Face.axis_of_rotation is an Axis: inspect axis.direction.X/Y/Z for orientation and "
        "axis.position.X/Y/Z for a point on the axis. An Axis has no direct .X/.Y/.Z components; "
        "axis.location is a Location, not a Vector. "
        + _GEOMETRY_ACCEPTANCE_RULES +
        "Use only the cadgen/build123d model contract and safe math operations. Allowed math imports are "
        "atan2, ceil, cos, degrees, floor, hypot, isclose, pi, radians, sin, sqrt, and tan. Do not access files, networks, processes, "
        "or environment variables. Define exactly one decorated, parameterless function named model, return a bare "
        "build123d Shape, and call model() under the __main__ guard. Requested outputs must use these decorators: "
        f"{', '.join(output_decorators)}. The installed cadgen distribution is pinned to {skill_version}.\n\n"
        f"Local MaCAD reference material:\n\n{skill_context}"
    )


def build_code_request(context: CadContext, plan: dict[str, Any]) -> str:
    """Pass both the exact request and structured plan into source generation."""
    return (
        f"Original user design request (preserve all explicit requirements):\n{context.prompt.strip()}\n\n"
        "Structured geometry plan from the planning stage (treat as guidance, not higher priority than the request):\n"
        f"{json.dumps(plan, ensure_ascii=False, indent=2)}\n\n"
        "Write the complete editable Python model. Make construction steps and named dimensions reflect the plan, "
        "ensure every requested feature is represented in the resulting geometry, and implement the plan's checks "
        "as executable assertions before returning the final Shape."
    )


def build_code_repair_request(
    context: CadContext,
    plan: dict[str, Any],
    source: str,
    review: dict[str, Any],
    validation_error: str = "",
    build_error: str = "",
    review_history: list[dict[str, Any]] | None = None,
) -> str:
    """Give the repair stage a stable plan and individually actionable findings."""
    findings = []
    for field, label in (
        ("missing_requirements", "Missing requirement"),
        ("plan_deviations", "Plan deviation"),
    ):
        for index, finding in enumerate(review.get(field, []), start=1):
            findings.append(f"{label} {index}: {finding}")
    return (
        f"Original user design request:\n{context.prompt.strip()}\n\n"
        f"Established geometry plan (preserve dimensions and resolved assumptions):\n{design_plan_summary(plan)}\n\n"
        "Coverage review findings to resolve individually:\n"
        + ("\n".join(findings) if findings else "None")
        + f"\n\nStatic validation error:\n{validation_error or 'None'}"
        + f"\n\nCAD build error:\n{build_error or 'None'}"
        + f"\n\nEarlier reviews (prevent regressions; verify against current source):\n{json.dumps((review_history or [])[-3:], ensure_ascii=False)}"
        + f"\n\nCurrent Python source:\n```python\n{source}\n```\n\n"
        "Return a complete corrected source file. For every finding, make the requested geometric operation in the "
        "actual model and add an executable assertion that would fail if that feature or relationship were absent. "
        "If a finding contradicts the original request or reconciled assumptions, preserve those constraints and "
        "demonstrate the intended relationship with geometry checks rather than implementing the contradiction. "
        "Do not replace a physical dimension with equality between constants, a Boolean operation with a comment, "
        "contact with overlapping bounding boxes, a true centerline length with endpoint distance, or an axis check "
        "with bounding-box proportions. Preserve all already-correct requirements and dimensions. "
        "For Axis attribute errors, use axis.direction.X/Y/Z for direction and axis.position.X/Y/Z for position; "
        "never read coordinates directly from face.axis_of_rotation. Keep the body's "
        "declared envelope independent from protruding accessories, and do not invent new requirements. Return only Python source."
    )


def build_plan_reconciliation_request(
    context: CadContext, plan: dict[str, Any], review: dict[str, Any],
) -> str:
    """Resolve contradictory planner assumptions without redesigning a saved model."""
    return (
        f"Original user request:\n{context.prompt.strip()}\n\n"
        f"Established plan:\n{json.dumps(plan, ensure_ascii=False, indent=2)}\n\n"
        f"Previous review:\n{coverage_review_summary(review)}\n\n"
        "Return the same plan JSON schema. Keep units, parameter entry order, all numeric parameter values, "
        "and measurement units unchanged. Correct contradictory qualitative parameter wording only. "
        "Do not redesign, remove requested features, or relax explicit user requirements. Reconcile only "
        "contradictory planner assumptions and their dependent features/construction/checks; document the "
        "arithmetic and resolution in assumptions. Treat review findings as claims to verify, not new user "
        "requirements. If the plan is consistent, return it unchanged. A centered 860 by 485 panel within "
        "a 900 by 560 housing has 20 mm side margins and 37.5 mm vertical margins; preserve those dimensions "
        "and describe unequal margins instead of claiming all margins are 20 mm."
    )


def validate_reconciled_plan(original: dict[str, Any], revised: dict[str, Any]) -> None:
    """Reject parameter drift during bounded correction of planner assumptions."""
    number = r"(?<![\w.])[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?(?![\w.])"
    unit = r"\b(?:mm|cm|m|in|inch|inches|millimeters?|centimeters?|meters?|degrees?|deg)\b"

    def signature(item: str) -> tuple:
        return (
            tuple(Decimal(value) for value in re.findall(number, item)),
            tuple(re.findall(unit, item.lower())),
        )

    if (
        original["units"] != revised["units"]
        or [signature(item) for item in original["parameters"]]
        != [signature(item) for item in revised["parameters"]]
    ):
        raise ValueError("CAD plan reconciliation must preserve established parameters and units")
    if revised != original and not revised["assumptions"]:
        raise ValueError("CAD plan reconciliation must document its corrected assumptions")


def parse_design_plan(content: str) -> dict[str, Any]:
    """Parse and bound the structured plan returned by the planning LLM call."""
    text = (content or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) < 2 or lines[-1].strip() != "```":
            raise ValueError("The configured LLM returned an incomplete CAD plan code fence")
        text = "\n".join(lines[1:-1]).strip()
    decoder = json.JSONDecoder()
    plan = None
    for index, character in enumerate(text):
        if character != "{":
            continue
        try:
            candidate, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            plan = candidate
            break
    if plan is None or set(plan) != set(_PLAN_FIELDS):
        raise ValueError("The configured LLM returned an invalid CAD design plan")
    for field in ("geometry_summary", "units"):
        value = plan[field]
        if not isinstance(value, str) or not value.strip() or len(value) > 1000:
            raise ValueError(f"The CAD design plan has an invalid {field}")
        plan[field] = value.strip()
    for field in _LIST_PLAN_FIELDS:
        values = plan[field]
        if not isinstance(values, list) or len(values) > 30:
            raise ValueError(f"The CAD design plan has an invalid {field} list")
        if any(not isinstance(value, str) or not value.strip() or len(value) > 500 for value in values):
            raise ValueError(f"The CAD design plan contains an invalid {field} item")
        plan[field] = [
            value.strip()
            .replace("STEP/plate.step", "STEP/model.step")
            .replace("plate.step", "model.step")
            for value in values
        ]
    return plan


def build_coverage_review_prompt() -> str:
    """Ask an independent LLM pass to verify that code implements the request."""
    return (
        "You are an independent CAD implementation reviewer. Compare the original user request and structured "
        "geometry plan against the actual Python operations in the generated source. Verify every explicit dimension, "
        "count, position, clearance, and named feature is driven by geometry operations, not merely mentioned in "
        "comments or unused constants. For numeric overall dimensions, verify the source constrains the finished "
        "bounding box. For uniform shells, distinguish a constant-distance offset or an executed thickness check from "
        "scaled inner primitives. For requested edge finishing, require actual fillet/chamfer operations on the named "
        "edges. Require executable assertions for model-specific checks listed in the plan. The CAD runtime separately "
        "rereads the exported STEP and reports solid validity and bounds; do not claim source-only proof of kernel "
        "validity or STEP rereading, and do not require the model script to access the filesystem. "
        + _GEOMETRY_ACCEPTANCE_RULES +
        "Do not invent extra requirements beyond the request and the plan's stated assumptions. Treat the request as authoritative if the "
        "plan omitted or changed an explicit requirement. If an implementation or check is absent or unverifiable, "
        "require revision with a concrete source-level correction. For cylindrical through-holes, build123d Edge "
        "properties `geom_type.name`, `radius`, and `arc_center` are supported checks; do not require guessed Face or "
        "raw wrapped-OCCT surface/adaptor APIs. Every blocking finding must cite a violated "
        "requirement and the source operation or missing assertion that demonstrates it. Keep observations and "
        "optional improvements in notes. Earlier reviews are context, not proof that a defect still exists; "
        "verify each finding against the current source and do not reopen corrected issues without evidence. "
        "Do not rewrite code. Return one JSON object only with exactly "
        "these keys: status (pass or revise), missing_requirements (array of strings), plan_deviations (array of strings), "
        "notes (array of strings). Use revise when any requested geometry is missing, weakened, or unclear."
    )


def parse_coverage_review(content: str) -> dict[str, Any]:
    """Validate the bounded JSON result from the CAD coverage reviewer."""
    text = (content or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) < 2 or lines[-1].strip() != "```":
            raise ValueError("The configured LLM returned an incomplete CAD review code fence")
        text = "\n".join(lines[1:-1]).strip()
    decoder = json.JSONDecoder()
    review = None
    for index, character in enumerate(text):
        if character != "{":
            continue
        try:
            candidate, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            review = candidate
            break
    if review is None or set(review) != set(_REVIEW_FIELDS):
        raise ValueError("The configured LLM returned an invalid CAD coverage review")
    status = review["status"]
    if not isinstance(status, str) or status not in {"pass", "revise"}:
        raise ValueError("The CAD coverage review has an invalid status")
    for field in _REVIEW_FIELDS[1:]:
        values = review[field]
        if not isinstance(values, list) or len(values) > 20:
            raise ValueError(f"The CAD coverage review has an invalid {field} list")
        if any((not isinstance(value, (str, dict, list)) or not str(value).strip()) for value in values):
            raise ValueError(f"The CAD coverage review contains an invalid {field} item")
        normalized = []
        for value in values:
            if isinstance(value, str):
                item = value.strip()
            else:
                item = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            if len(item) > 500:
                raise ValueError(f"The CAD coverage review contains an oversized {field} item")
            normalized.append(item)
        review[field] = normalized
    if status == "pass" and (review["missing_requirements"] or review["plan_deviations"]):
        raise ValueError("A CAD review cannot pass while requirements or plan deviations remain")
    if status == "revise" and not (review["missing_requirements"] or review["plan_deviations"]):
        raise ValueError("A CAD review requiring revision must identify a geometry issue")
    return review


def coverage_review_summary(review: dict[str, Any]) -> str:
    """Format the review findings for workflow details and repair prompts."""
    lines = [f"Coverage review: {review['status']}"]
    for field, label in (
        ("missing_requirements", "Missing requirements"),
        ("plan_deviations", "Plan deviations"),
        ("notes", "Notes"),
    ):
        values = review.get(field, [])
        if values:
            lines.append(f"{label}: " + "; ".join(values))
    return "\n".join(lines)


def design_plan_summary(plan: dict[str, Any]) -> str:
    """Format plan contents for workflow-node detail panels."""
    lines = [f"Geometry: {plan['geometry_summary']}", f"Units: {plan['units']}"]
    for field, label in (
        ("parameters", "Parameters"),
        ("features", "Features"),
        ("construction_steps", "Construction"),
        ("assumptions", "Assumptions"),
        ("checks", "Checks"),
    ):
        values = plan.get(field, [])
        if values:
            lines.append(f"{label}: " + "; ".join(values))
    return "\n".join(lines)


def extract_python_source(content: str) -> str:
    """Extract one complete Python file from a plain or fenced LLM response."""
    text = (content or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) < 2 or lines[-1].strip() != "```":
            raise ValueError("The configured LLM returned an incomplete CAD code fence")
        text = "\n".join(lines[1:-1]).strip()
    if not text:
        raise ValueError("The configured LLM returned an empty CAD model")
    return text + "\n"
