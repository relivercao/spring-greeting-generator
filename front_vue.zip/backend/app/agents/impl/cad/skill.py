"""Load the focused modeling contract from a local text-to-cad checkout."""

from __future__ import annotations

from pathlib import Path

from app.core.config import get_settings


MAX_REFERENCE_BYTES = 256 * 1024
_REFERENCE_FILES = (
    "SKILL.md",
    "references/step-generation.md",
    "references/inspection-and-validation.md",
    "references/supported-exports.md",
)


def resolve_cad_skill_dir() -> Path:
    """Resolve an explicitly configured skill path or the documented sibling clone."""
    settings = get_settings()
    configured = str(settings.CAD_AGENT_SKILL_DIR or "").strip()
    if configured:
        candidate = Path(configured).expanduser()
        if not candidate.is_absolute():
            candidate = Path(__file__).resolve().parents[4] / candidate
        return candidate.resolve()

    project_root = Path(__file__).resolve().parents[5]
    return (project_root.parent.parent / "MaCAD" / "skills" / "cad").resolve()


def load_cad_skill_context() -> tuple[str, str]:
    """Read the skill and model/export references without executing repository code."""
    skill_dir = resolve_cad_skill_dir()
    sections = []
    version_path = skill_dir.parent.parent / "VERSION"
    version = version_path.read_text(encoding="utf-8").strip()
    if not version or any(char not in "0123456789." for char in version):
        raise ValueError("The CAD repository has an invalid VERSION file")

    for relative_path in _REFERENCE_FILES:
        path = (skill_dir / relative_path).resolve()
        if not path.is_relative_to(skill_dir):
            raise ValueError("CAD skill reference escaped its directory")
        raw = path.read_bytes()
        if len(raw) > MAX_REFERENCE_BYTES:
            raise ValueError(f"CAD skill reference exceeds the size limit: {relative_path}")
        sections.append(f"## Reference: {relative_path}\n{raw.decode('utf-8')}")

    return version, "\n\n".join(sections)
