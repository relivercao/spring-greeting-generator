"""Local cadgen runtime with per-task output and bounded process execution."""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Any

import psutil
from loguru import logger

from app.core.config import get_settings
from app.agents.impl.cad.skill import load_cad_skill_context
from app.agents.impl.cad.types import CadOutputFormat
from app.agents.impl.cad.validation import validate_model_script
from app.agents.impl.cad.artifacts import CadPublicationError, publish_artifacts


MAX_PROCESS_OUTPUT_BYTES = 1024 * 1024
MAX_ARTIFACT_BYTES = 200 * 1024 * 1024
_SAFE_RUNTIME_ENV = {
    "APPDATA", "LOCALAPPDATA", "PATH", "PROGRAMDATA", "SYSTEMROOT", "TEMP", "TMP",
    "USERPROFILE", "UV_CACHE_DIR", "WINDIR", "SSL_CERT_FILE", "SSL_CERT_DIR",
}
_OUTPUT_FILES = {
    "step": [("STEP/model.step", "step")],
    "stl": [("STEP/model.step", "step"), ("STL/model.stl", "stl")],
    "3mf": [("STEP/model.step", "step"), ("3MF/model.3mf", "3mf")],
    "glb": [("STEP/model.step", "step"), ("GLB/model.glb", "glb")],
}
_STEP_GEOMETRY_CHECK = (
    "import json, sys\n"
    "from cadgen import read_step\n"
    "shape = read_step(sys.argv[1])\n"
    "solids = shape.solids()\n"
    "faces = shape.faces()\n"
    "edges = shape.edges()\n"
    "volumes = [float(solid.volume) for solid in solids]\n"
    "bounds = shape.bounding_box()\n"
    "print(json.dumps({'shape_valid': bool(shape.is_valid), 'solid_validity': [bool(solid.is_valid) for solid in solids], "
    "'solid_count': len(solids), 'face_count': len(faces), 'edge_count': len(edges), 'volumes': volumes, "
    "'bounds_mm': {'min': [float(bounds.min.X), float(bounds.min.Y), float(bounds.min.Z)], "
    "'max': [float(bounds.max.X), float(bounds.max.Y), float(bounds.max.Z)], "
    "'size': [float(bounds.size.X), float(bounds.size.Y), float(bounds.size.Z)]}}))\n"
)


class CadRuntimeError(RuntimeError):
    """Raised when local CAD tooling or generated artifacts fail validation."""


def _verify_preview_image(path: Path) -> None:
    from PIL import Image

    try:
        with Image.open(path) as preview:
            if preview.format != "PNG" or preview.width * preview.height > 25_000_000:
                raise ValueError("Expected a PNG preview of at most 25 million pixels")
            preview.verify()
        with Image.open(path) as preview:
            preview.load()
    except (OSError, ValueError, Image.DecompressionBombError) as error:
        raise CadRuntimeError("CAD preview is not a valid, decodable PNG image") from error


def task_output_dir(user_id: str, task_id: str) -> Path:
    """Return a canonical output directory that cannot escape OUTPUT_DIR."""
    try:
        canonical_task_id = str(uuid.UUID(task_id))
    except (ValueError, TypeError, AttributeError) as error:
        raise CadRuntimeError("Invalid CAD task identifier") from error
    settings = get_settings()
    root = Path(settings.OUTPUT_DIR).expanduser().resolve() / "cad"
    owner_hash = hashlib.sha256(str(user_id).encode("utf-8")).hexdigest()[:32]
    target = (root / owner_hash / canonical_task_id).resolve()
    if root not in target.parents:
        raise CadRuntimeError("Invalid CAD task output path")
    return target


def runtime_status() -> dict[str, Any]:
    """Report whether the configured MaCAD skill and local uvx runner exist."""
    settings = get_settings()
    try:
        version, _ = load_cad_skill_context()
        skill_error = ""
    except (OSError, UnicodeError, ValueError) as error:
        version = ""
        skill_error = error.__class__.__name__
    runtime = shutil.which(settings.CAD_AGENT_UVX_PATH)
    return {
        "skill_available": not skill_error,
        "skill_version": version,
        "skill_error": skill_error,
        "runtime_available": bool(runtime),
        "build_available": bool(runtime and not skill_error),
        "viewer_host": "127.0.0.1",
    }


def _runtime_command(version: str, *arguments: str) -> list[str]:
    runtime = shutil.which(get_settings().CAD_AGENT_UVX_PATH)
    if not runtime:
        raise CadRuntimeError("The configured uvx runtime is not available")
    return [
        runtime,
        "--no-config",
        "--managed-python",
        "--python",
        "3.13",
        "--from",
        f"cadgen=={version}",
        *arguments,
    ]


def _runtime_environment() -> dict[str, str]:
    """Keep local toolchain variables while excluding application credentials."""
    settings = get_settings()
    return {
        name: value
        for name, value in os.environ.items()
        if name.upper() in _SAFE_RUNTIME_ENV
    } | {
        "PYTHONNOUSERSITE": "1",
        # CAD dependencies include a large native wheel; allow slow first-run downloads.
        "UV_HTTP_TIMEOUT": str(settings.CAD_AGENT_UV_HTTP_TIMEOUT_SECONDS),
        # Serialize downloads/extraction to avoid Windows I/O contention on native wheels.
        "UV_CONCURRENT_DOWNLOADS": "1",
        # Playwright uses milliseconds for its first-run browser download timeout.
        "PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT": str(settings.CAD_AGENT_UV_HTTP_TIMEOUT_SECONDS * 1000),
    }


def _kill_process_tree(pid: int) -> None:
    try:
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return
    for process in reversed(children):
        try:
            process.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    try:
        parent.kill()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass


def _remove_build_dir(build_dir: Path) -> str:
    """Remove a completed attempt, preserving success when Windows still holds a file."""
    try:
        shutil.rmtree(build_dir)
    except OSError as error:
        if getattr(error, "winerror", None) != 32:
            raise
        warning = "The CAD build directory remains because Windows reported a file-sharing lock."
        logger.warning("{} Path: {}", warning, build_dir)
        return warning
    return ""


async def _read_bounded(stream: asyncio.StreamReader) -> bytes:
    chunks: list[bytes] = []
    remaining = MAX_PROCESS_OUTPUT_BYTES
    while chunk := await stream.read(65536):
        if remaining > 0:
            kept = chunk[:remaining]
            chunks.append(kept)
            remaining -= len(kept)
    return b"".join(chunks)


async def _run_command(command: list[str], cwd: Path, timeout_seconds: int) -> str:
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=str(cwd),
            env=_runtime_environment(),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
    except OSError as error:
        raise CadRuntimeError(f"Failed to start the local CAD runtime: {error}") from error

    output_task = asyncio.create_task(_read_bounded(process.stdout))
    try:
        await asyncio.wait_for(process.wait(), timeout=timeout_seconds)
    except asyncio.TimeoutError as error:
        _kill_process_tree(process.pid)
        await process.wait()
        await output_task
        raise CadRuntimeError(f"CAD build exceeded {timeout_seconds} seconds") from error
    except asyncio.CancelledError:
        _kill_process_tree(process.pid)
        await process.wait()
        await output_task
        raise
    output = (await output_task).decode("utf-8", errors="replace")
    if process.returncode != 0:
        detail = output[-12000:].strip()
        raise CadRuntimeError(detail or f"CAD command failed with exit code {process.returncode}")
    return output[-12000:].strip()


def _validate_step_geometry_report(output: str) -> dict[str, Any]:
    """Validate geometry reread from STEP and retain its measurable bounds."""
    try:
        report = json.loads(output.splitlines()[-1])
        shape_valid = report["shape_valid"]
        solid_validity = report["solid_validity"]
        solid_count = int(report["solid_count"])
        face_count = int(report["face_count"])
        edge_count = int(report["edge_count"])
        volumes = [float(value) for value in report["volumes"]]
        bounds = report["bounds_mm"]
        bound_min = [float(value) for value in bounds["min"]]
        bound_max = [float(value) for value in bounds["max"]]
        bound_size = [float(value) for value in bounds["size"]]
    except (IndexError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise CadRuntimeError("CAD geometry validation returned an invalid report") from error

    if not isinstance(shape_valid, bool) or not shape_valid:
        raise CadRuntimeError("The STEP geometry is invalid")
    if (
        not isinstance(solid_validity, list)
        or len(solid_validity) != solid_count
        or any(not isinstance(valid, bool) or not valid for valid in solid_validity)
    ):
        raise CadRuntimeError("The STEP geometry contains an invalid solid")
    if any(len(values) != 3 for values in (bound_min, bound_max, bound_size)):
        raise CadRuntimeError("CAD geometry validation returned invalid bounds")
    if any(not math.isfinite(value) for values in (bound_min, bound_max, bound_size) for value in values):
        raise CadRuntimeError("CAD geometry validation returned non-finite bounds")
    if solid_count == 0 and face_count == 0 and edge_count == 0:
        raise CadRuntimeError(
            "The generated STEP file contains no geometry (0 solids, 0 faces). "
            "Repair the model script and build it again."
        )
    if any(size <= 0 for size in bound_size):
        raise CadRuntimeError("The STEP geometry has a zero-size bounding box")
    if solid_count and (
        len(volumes) != solid_count
        or any(not math.isfinite(volume) or volume <= 0 for volume in volumes)
    ):
        raise CadRuntimeError("The generated STEP file contains a solid with non-positive volume")
    return {
        "step_reread": True,
        "shape_valid": shape_valid,
        "solid_count": solid_count,
        "valid_solid_count": sum(solid_validity),
        "face_count": face_count,
        "edge_count": edge_count,
        "volume_mm3": sum(volumes),
        "bounds_mm": {"min": bound_min, "max": bound_max, "size": bound_size},
    }


async def build_model(task_id: str, user_id: str, output_format: CadOutputFormat) -> dict[str, Any]:
    """Build a previously reviewed model and capture the MaCAD visual snapshot."""
    try:
        version, _ = load_cad_skill_context()
    except (OSError, UnicodeError, ValueError) as error:
        raise CadRuntimeError(f"The local MaCAD skill is unavailable: {error}") from error

    task_dir = task_output_dir(user_id, task_id)
    script = (task_dir / "model.py").resolve()
    if not script.is_relative_to(task_dir) or not script.is_file():
        raise CadRuntimeError("The reviewed CAD model script could not be found")
    source = await asyncio.to_thread(script.read_text, encoding="utf-8")
    validate_model_script(source, output_format)
    timeout_seconds = get_settings().CAD_AGENT_RUNTIME_TIMEOUT_SECONDS
    build_dir = Path(await asyncio.to_thread(tempfile.mkdtemp, prefix="cad-build-", dir=task_dir)).resolve()
    if build_dir.parent != task_dir:
        raise CadRuntimeError("CAD build directory escapes the task output directory")
    preserve_recovery = False
    result: dict[str, Any] | None = None
    try:
        await asyncio.to_thread((build_dir / "model.py").write_text, source, encoding="utf-8")
        result = await _build_attempt(build_dir, output_format, version, timeout_seconds)
        publication = asyncio.create_task(asyncio.to_thread(
            publish_artifacts, build_dir, task_dir, result["artifacts"],
        ))
        try:
            await asyncio.shield(publication)
        except asyncio.CancelledError:
            # Wait for the filesystem transaction before removing its backup directory.
            await publication
            raise
        return result
    except CadPublicationError as error:
        preserve_recovery = error.recovery_required
        raise CadRuntimeError(str(error)) from error
    finally:
        if not preserve_recovery:
            cleanup_warning = await asyncio.to_thread(_remove_build_dir, build_dir)
            if cleanup_warning and result is not None:
                result["cleanup_warning"] = cleanup_warning


async def _build_attempt(
    task_dir: Path, output_format: CadOutputFormat, version: str, timeout_seconds: int,
) -> dict[str, Any]:
    """Build and validate outputs in a fresh directory for this attempt only."""
    script = task_dir / "model.py"
    build_log = await _run_command(
        _runtime_command(version, "python", str(script)),
        task_dir,
        timeout_seconds,
    )

    output_records = []
    for relative_path, artifact_type in _OUTPUT_FILES[output_format]:
        path = (task_dir / relative_path).resolve()
        if not path.is_relative_to(task_dir) or not path.is_file():
            raise CadRuntimeError(f"CAD build did not produce the expected {relative_path} file")
        size = path.stat().st_size
        if size <= 0 or size > MAX_ARTIFACT_BYTES:
            raise CadRuntimeError(f"CAD output size is invalid for {relative_path}")
        output_records.append({"filename": relative_path, "type": artifact_type, "size_bytes": size})

    geometry_report = await _run_command(
        _runtime_command(version, "python", "-c", _STEP_GEOMETRY_CHECK, "STEP/model.step"),
        task_dir,
        timeout_seconds,
    )
    geometry = _validate_step_geometry_report(geometry_report)

    preview_source = output_records[-1]["filename"]
    preview_type = output_format
    preview_path = "preview.png"
    snapshot_log = await _run_command(
        _runtime_command(version, "cadgen", preview_type, "snapshot", preview_source, preview_path),
        task_dir,
        timeout_seconds,
    )
    preview_file = (task_dir / preview_path).resolve()
    if not preview_file.is_relative_to(task_dir) or not preview_file.is_file() or not preview_file.stat().st_size:
        raise CadRuntimeError("CAD snapshot command did not produce a preview image")
    if preview_file.stat().st_size > MAX_ARTIFACT_BYTES:
        raise CadRuntimeError("CAD preview exceeds the artifact size limit")
    await asyncio.to_thread(_verify_preview_image, preview_file)
    output_records.append({"filename": preview_path, "type": "preview", "size_bytes": preview_file.stat().st_size})

    return {
        "artifacts": output_records,
        "build_log": build_log,
        "snapshot_log": snapshot_log,
        "cadgen_version": version,
        "geometry_review": "snapshot_created",
        "geometry": geometry,
    }


def resolve_artifact(task_id: str, user_id: str, filename: str) -> Path | None:
    """Resolve only a task-relative artifact without allowing path escape."""
    normalized = filename.replace("\\", "/")
    relative_path = Path(*normalized.split("/"))
    if (
        not filename
        or relative_path.is_absolute()
        or ".." in relative_path.parts
        or bool(relative_path.drive)
        or any(part in {"", "."} for part in relative_path.parts)
    ):
        return None
    task_dir = task_output_dir(user_id, task_id)
    path = (task_dir / relative_path).resolve()
    if not path.is_relative_to(task_dir) or not path.is_file():
        return None
    return path
