"""CAD Agent that authors editable parametric Python models."""

from __future__ import annotations

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.agents.impl.cad.prompts import extract_python_source as _extract_python_source
from app.agents.impl.cad.skill import load_cad_skill_context
from app.agents.impl.cad.types import CadContext
from app.agents.impl.cad.validation import validate_model_script
from app.agents.impl.cad.workflow import CadGenerationWorkflow
from app.llm.bridge import LLMBridge


_OUTPUT_PATHS = {"step": "STEP/model.step", "stl": "STL/model.stl", "3mf": "3MF/model.3mf", "glb": "GLB/model.glb"}


class CadAgent(BaseAgent):
    """Generate one editable CAD model script using the local MaCAD skill."""

    def __init__(self, llm_bridge: LLMBridge, skill_registry=None):
        super().__init__(
            AgentConfig(
                agent_type=AgentType.CAD,
                timeout_seconds=600,
                enable_streaming=False,
                durable_runtime=True,
            ),
            skill_registry=skill_registry,
        )
        self._llm = llm_bridge

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, CadContext):
            raise ValidationError("CadAgent requires CadContext")
        if not context.prompt.strip():
            raise ValidationError("A CAD model description is required")
        if len(context.prompt) > 12000:
            raise ValidationError("CAD model description must not exceed 12000 characters")
        if context.output_format not in _OUTPUT_PATHS:
            raise ValidationError("Unsupported CAD output format")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        if not isinstance(context, CadContext):
            raise ValidationError("CadAgent requires CadContext")
        state = await CadGenerationWorkflow(self).execute(context)
        failed = bool(state.get("failed_node"))
        repairing = bool(context.metadata.get("cad_repair_source"))
        build_result = state.get("build_result", {})
        build_error = state.get("build_error", "")
        phase = (
            "build_failed" if build_error
            else "repair_failed" if failed and repairing
            else "generation_failed" if failed
            else "completed" if build_result
            else "script_ready"
        )
        data = {
            "model_code": state.get("model_code", ""),
            "output_format": context.output_format,
            "cadgen_version": state.get("skill_version", ""),
            "script_validation": "failed" if state.get("validation_error") else "passed",
            "validation_repair_used": state.get("validation_repair_used", False),
            "design_plan": state.get("design_plan", {}),
            "original_design_plan": state.get("original_design_plan", {}),
            "review_history": state.get("review_history", []),
            "coverage_review": state.get("coverage_review", {}),
            "workflow_state": state["workflow_state"],
            "workflow_nodes": state["workflow_state"]["nodes"],
            "execution_requires_user_confirmation": not context.auto_build,
            "phase": phase,
            "build_error": build_error,
            "build_result": build_result,
        }
        if state.get("model_file"):
            data["model_file"] = state["model_file"]
        return AgentResult(
            task_id=context.task_id,
            status=AgentStatus.FAILED if failed else AgentStatus.COMPLETED,
            message=(
                "CAD generation failed after review attempts"
                if failed
                else "CAD model and review artifacts generated"
                if build_result
                else "Editable CAD model script generated"
            ),
            data=data,
            errors=[build_error or state.get("review_error") or state.get("validation_error", "")]
            if failed else [],
        )

    async def repair_model(
        self,
        prompt: str,
        output_format: str,
        source: str,
        failure: str,
        task_id: str,
    ) -> str:
        """Return a reviewed replacement script after deterministic geometry failure."""
        version, skill_context = load_cad_skill_context()
        system_prompt = (
            "You repair one parametric CAD model. Return only a complete Python source file. "
            "Preserve the user's requested dimensions, shape, and features. Do not remove requested "
            "features such as threads, holes, ribs, or cutouts; replace a fragile implementation with a "
            "simpler valid approximation instead. Prefer robust build123d solids; avoid fragile sweeps "
            "or booleans unless their profiles and paths are correctly placed. Ensure the model contains "
            "visible non-empty geometry. Do not access files, "
            "networks, processes, or environment variables. Use the same cadgen output contract and "
            f"the installed cadgen {version}.\n\n{skill_context}"
        )
        call_options = self._llm_call_options()
        call_options["task_id"] = task_id
        response = await self._llm.generate(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"Original design request:\n{prompt}\n\n"
                        f"Requested output format: {output_format}\n\n"
                        f"Build validation failure:\n{failure}\n\n"
                        f"Current model source:\n```python\n{source}\n```\n\n"
                        "Return a corrected source file that passes deterministic CAD validation "
                        "and produces non-empty geometry."
                    ),
                },
            ],
            temperature=0.1,
            max_tokens=12000,
            **call_options,
        )
        code = _extract_python_source(response.content)
        validate_model_script(code, output_format)
        return code
