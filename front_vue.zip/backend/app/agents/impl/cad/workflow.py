"""LangGraph workflow for planning, generating, and validating CAD scripts."""

from __future__ import annotations

import asyncio
import json
from typing import Any, TypedDict

from app.agents.impl.cad.prompts import (
    build_code_request,
    build_code_repair_request,
    build_code_system_prompt,
    build_coverage_review_prompt,
    build_plan_system_prompt,
    build_plan_reconciliation_request,
    coverage_review_summary,
    design_plan_summary,
    extract_python_source,
    parse_coverage_review,
    parse_design_plan,
    validate_reconciled_plan,
)
from app.agents.base import AgentStatus
from app.agents.impl.cad.skill import load_cad_skill_context
from app.agents.impl.cad.runtime import CadRuntimeError, build_model, task_output_dir
from app.agents.impl.cad.types import CadContext
from app.agents.impl.cad.validation import validate_model_script


class CadWorkflowState(TypedDict, total=False):
    """State shared by CAD generation graph nodes."""

    context: CadContext
    skill_version: str
    skill_context: str
    design_plan: dict[str, Any]
    original_design_plan: dict[str, Any]
    review_history: list[dict[str, Any]]
    plan_reconciled: bool
    model_code: str
    model_file: str
    coverage_review: dict[str, Any]
    review_error: str
    review_attempts: int
    failed_node: str
    validation_error: str
    validation_attempts: int
    repair_attempts: int
    validation_repair_used: bool
    build_error: str
    build_result: dict[str, Any]
    completed_nodes: list[str]
    node_outputs: dict[str, dict[str, str]]
    workflow_state: dict[str, Any]
    workflow_nodes: list[dict[str, str]]


_MAX_REPAIR_ATTEMPTS = 2
_PLAN_FIELDS = (
    "geometry_summary",
    "units",
    "parameters",
    "features",
    "construction_steps",
    "assumptions",
    "checks",
)
_LIST_PLAN_FIELDS = _PLAN_FIELDS[2:]
_NODES = (
    ("init_project_context", "Initialize", "fetch", 5),
    ("plan_geometry", "Plan Geometry", "prompt", 22),
    ("generate_script", "Generate", "generate", 43),
    ("review_geometry", "Review Geometry", "review", 55),
    ("validate_script", "Validate", "validate", 68),
    ("repair_script", "Revise Model", "repair", 80),
    ("save_files", "Save Script", "save", 93),
    ("build_and_snapshot", "Build and Snapshot", "build", 97),
    ("finalize", "Finalize", "report", 99),
)


def build_workflow_nodes(
    state: CadWorkflowState,
    active_node: str | None = None,
    terminal_status: str | None = None,
) -> list[dict[str, str]]:
    """Build a serializable view of the ordered graph's node statuses."""
    completed = set(state.get("completed_nodes", []))
    nodes = []
    failed_node = state.get("failed_node", "")
    for node_id, _, _, _ in _NODES:
        if terminal_status == AgentStatus.FAILED.value and node_id == failed_node:
            status = "failed"
        elif node_id == active_node:
            status = "in_progress"
        elif node_id in completed:
            status = "completed"
        elif terminal_status:
            status = "skipped"
        else:
            status = "pending"
        nodes.append({"node_name": node_id, "status": status})
    return nodes


def build_workflow_state(
    state: CadWorkflowState,
    active_node: str | None = None,
    terminal_status: str | None = None,
) -> dict[str, Any]:
    """Return the canonical UnitTest-style workflow state for CAD."""
    current_node = active_node or state.get("failed_node", "")
    if not current_node:
        completed = state.get("completed_nodes", [])
        current_node = completed[-1] if completed else ""
    stage = next((item[2] for item in _NODES if item[0] == current_node), "")
    return {
        "status": terminal_status or AgentStatus.RUNNING.value,
        "current_stage": stage,
        "nodes": build_workflow_nodes(
            state,
            active_node=active_node,
            terminal_status=terminal_status,
        ),
        "details": {
            "node_outputs": state.get("node_outputs", {}),
            "design_plan": state.get("design_plan", {}),
            "original_design_plan": state.get("original_design_plan", {}),
            "review_history": state.get("review_history", []),
            "coverage_review": state.get("coverage_review", {}),
            "repair_attempts": state.get("repair_attempts", 0),
        },
    }


def build_initial_workflow_state() -> dict[str, Any]:
    """Return the first observable snapshot before the graph task is scheduled."""
    initial_state: CadWorkflowState = {
        "completed_nodes": [],
        "node_outputs": {},
        "coverage_review": {},
    }
    return build_workflow_state(initial_state, active_node="init_project_context")


class CadGenerationWorkflow:
    """Run the CAD authoring stages through a compiled LangGraph state machine."""

    def __init__(self, agent: Any):
        self._agent = agent
        self._reported_progress = 0

    async def _run_without_langgraph(self, state: CadWorkflowState) -> CadWorkflowState:
        """Run the same graph transitions when LangGraph is unavailable."""
        state = {**state, **await self._understand_request(state)}
        state = {**state, **await self._plan_geometry(state)}
        next_node = "repair_script" if state.get("model_code") else "generate_script"

        while True:
            if next_node == "generate_script":
                state = {**state, **await self._generate_script(state)}
                next_node = "review_geometry"
            elif next_node == "repair_script":
                state = {**state, **await self._repair_script(state)}
                next_node = "review_geometry"
            elif next_node == "review_geometry":
                state = {**state, **await self._review_geometry(state)}
                next_node = self._route_after_review(state)
            elif next_node == "validate_script":
                state = {**state, **await self._validate_script(state)}
                next_node = self._route_after_validation(state)
            elif next_node == "save_files":
                state = {**state, **await self._deliver_script(state)}
                next_node = self._route_after_save(state)
            elif next_node == "build_and_snapshot":
                state = {**state, **await self._build_and_snapshot(state)}
                next_node = self._route_after_build(state)
            elif next_node == "finalize":
                return {**state, **await self._finalize(state)}
            elif next_node == "generation_failed":
                return {**state, **await self._generation_failed(state)}
            else:
                raise RuntimeError(f"Unsupported CAD workflow transition: {next_node}")

    def build(self):
        """Compile the ordered graph, with a dependency-free compatibility runner."""
        try:
            from langgraph.graph import END, START, StateGraph
        except ImportError:
            class _FallbackGraph:
                def __init__(self, workflow):
                    self._workflow = workflow

                async def ainvoke(self, state, config=None):
                    del config
                    return await self._workflow._run_without_langgraph(state)

            return _FallbackGraph(self)

        graph = StateGraph(CadWorkflowState)
        graph.add_node("init_project_context", self._understand_request)
        graph.add_node("plan_geometry", self._plan_geometry)
        graph.add_node("generate_script", self._generate_script)
        graph.add_node("review_geometry", self._review_geometry)
        graph.add_node("validate_script", self._validate_script)
        graph.add_node("repair_script", self._repair_script)
        graph.add_node("save_files", self._deliver_script)
        graph.add_node("build_and_snapshot", self._build_and_snapshot)
        graph.add_node("finalize", self._finalize)
        graph.add_node("generation_failed", self._generation_failed)
        graph.add_edge(START, "init_project_context")
        graph.add_edge("init_project_context", "plan_geometry")
        graph.add_conditional_edges(
            "plan_geometry",
            lambda state: "repair_script" if state.get("model_code") else "generate_script",
            {"repair_script": "repair_script", "generate_script": "generate_script"},
        )
        graph.add_edge("generate_script", "review_geometry")
        graph.add_conditional_edges(
            "review_geometry",
            self._route_after_review,
            {
                "repair_script": "repair_script",
                "validate_script": "validate_script",
                "generation_failed": "generation_failed",
            },
        )
        graph.add_conditional_edges(
            "validate_script",
            self._route_after_validation,
            {
                "repair_script": "repair_script",
                "save_files": "save_files",
                "generation_failed": "generation_failed",
            },
        )
        graph.add_edge("repair_script", "review_geometry")
        graph.add_conditional_edges(
            "save_files",
            self._route_after_save,
            {
                "build_and_snapshot": "build_and_snapshot",
                "finalize": "finalize",
            },
        )
        graph.add_conditional_edges(
            "build_and_snapshot",
            self._route_after_build,
            {
                "repair_script": "repair_script",
                "finalize": "finalize",
                "generation_failed": "generation_failed",
            },
        )
        graph.add_edge("finalize", END)
        graph.add_edge("generation_failed", END)
        return graph.compile()

    async def execute(self, context: CadContext) -> CadWorkflowState:
        """Invoke the compiled graph with an isolated state for this CAD task."""
        repair_review = context.metadata.get("cad_repair_review")
        if not isinstance(repair_review, dict):
            repair_review = {}
        repair_review_error = (
            coverage_review_summary(repair_review)
            if repair_review.get("status") == "revise"
            else ""
        )
        initial_state: CadWorkflowState = {
            "context": context,
            "model_code": str(context.metadata.get("cad_repair_source", "")),
            "validation_attempts": 0,
            "review_attempts": 0,
            "review_error": repair_review_error,
            "coverage_review": repair_review,
            "review_history": [repair_review] if repair_review else [],
            "validation_error": "",
            "failed_node": "",
            "repair_attempts": 0,
            "build_error": (
                str(context.metadata.get("cad_repair_error", ""))
                if not repair_review_error
                else ""
            ),
            "build_result": {},
            "validation_repair_used": False,
            "completed_nodes": [],
            "node_outputs": {},
        }
        result = await self.build().ainvoke(initial_state, config={"recursion_limit": 64})
        if result is None:
            raise RuntimeError("CAD generation workflow returned no final state")
        return result

    async def _report(
        self,
        state: CadWorkflowState,
        node_id: str,
        message: str,
        terminal_status: str | None = None,
    ) -> None:
        node = next(item for item in _NODES if item[0] == node_id)
        self._reported_progress = max(self._reported_progress, node[3])
        await self._agent._report_progress(
            state["context"].task_id,
            self._reported_progress,
            node[2],
            message,
            {"workflow_state": build_workflow_state(
                state,
                active_node=node_id if terminal_status is None else None,
                terminal_status=terminal_status,
            )},
        )

    @staticmethod
    def _record(
        state: CadWorkflowState,
        node_id: str,
        input_text: str,
        output_text: str,
        **updates: Any,
    ) -> dict[str, Any]:
        completed_nodes = list(state.get("completed_nodes", []))
        if node_id not in completed_nodes:
            completed_nodes.append(node_id)
        return {
            **updates,
            "completed_nodes": completed_nodes,
            "node_outputs": {
                **state.get("node_outputs", {}),
                node_id: {"input": input_text, "output": output_text},
            },
        }

    async def _understand_request(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        await self._report(state, "init_project_context", "Reading design requirements and local CAD contract")
        version, skill_context = load_cad_skill_context()
        self._agent._is_cancelled(context.task_id)
        return self._record(
            state,
            "init_project_context",
            context.prompt.strip(),
            f"Loaded MaCAD {version} guidance and retained the original design request.",
            skill_version=version,
            skill_context=skill_context,
        )

    async def _plan_geometry(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        repair_plan = context.metadata.get("cad_repair_plan")
        await self._report(
            state,
            "plan_geometry",
            "Checking the saved plan for contradictory assumptions before source repair"
            if context.metadata.get("cad_repair_source") and isinstance(repair_plan, dict) and repair_plan
            else "Asking the configured LLM to resolve dimensions, features, construction order, and checks",
        )
        if context.metadata.get("cad_repair_source") and isinstance(repair_plan, dict) and repair_plan:
            plan = parse_design_plan(json.dumps(repair_plan, ensure_ascii=False))
            self._agent._is_cancelled(context.task_id)
            return self._record(
                state,
                "plan_geometry",
                context.prompt.strip(),
                design_plan_summary(plan),
                design_plan=plan,
            )
        response = await self._agent._llm.generate(
            [
                {
                    "role": "system",
                    "content": build_plan_system_prompt(state["skill_version"], state["skill_context"]),
                },
                {
                    "role": "user",
                    "content": (
                        f"Design request:\n{context.prompt.strip()}\n\n"
                        f"Requested output format: {context.output_format}\n"
                        "Return the required JSON plan. Preserve every explicit dimension and feature."
                    ),
                },
            ],
            temperature=0.1,
            max_tokens=5000,
            **self._agent._llm_call_options(),
        )
        plan = parse_design_plan(response.content)
        self._agent._is_cancelled(context.task_id)
        return self._record(
            state,
            "plan_geometry",
            context.prompt.strip(),
            design_plan_summary(plan),
            design_plan=plan,
        )

    async def _generate_script(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        await self._report(state, "generate_script", "Generating editable parametric Python from the LLM design plan")
        response = await self._agent._llm.generate(
            [
                {
                    "role": "system",
                    "content": build_code_system_prompt(
                        state["skill_version"],
                        state["skill_context"],
                        context.output_format,
                    ),
                },
                {
                    "role": "user",
                    "content": build_code_request(context, state["design_plan"]),
                },
            ],
            temperature=0.2,
            max_tokens=12000,
            **self._agent._llm_call_options(),
        )
        code = extract_python_source(response.content)
        self._agent._is_cancelled(context.task_id)
        return self._record(
            state,
            "generate_script",
            design_plan_summary(state["design_plan"]),
            f"Generated a {len(code.splitlines())}-line editable model script; static validation is next.",
            model_code=code,
            review_error="",
            validation_error="",
        )

    async def _review_geometry(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        await self._report(
            state,
            "review_geometry",
            "Comparing generated geometry against every requested dimension and feature",
        )
        response = await self._agent._llm.generate(
            [
                {"role": "system", "content": build_coverage_review_prompt()},
                {
                    "role": "user",
                    "content": (
                        f"Original user request:\n{context.prompt.strip()}\n\n"
                        f"Structured geometry plan:\n{design_plan_summary(state['design_plan'])}\n\n"
                        f"Earlier reviews (recheck against current source):\n{json.dumps(state.get('review_history', [])[-3:], ensure_ascii=False)}\n\n"
                        f"Generated Python source:\n```python\n{state['model_code']}\n```\n\n"
                        "Return the required JSON coverage review."
                    ),
                },
            ],
            temperature=0.0,
            max_tokens=3000,
            **self._agent._llm_call_options(),
        )
        review = parse_coverage_review(response.content)
        review_error = (
            coverage_review_summary(review)
            if review["status"] == "revise"
            else ""
        )
        attempts = state.get("review_attempts", 0) + 1
        self._agent._is_cancelled(context.task_id)
        return self._record(
            state,
            "review_geometry",
            f"{context.prompt.strip()}\n\n{design_plan_summary(state['design_plan'])}",
            coverage_review_summary(review),
            coverage_review=review,
            review_error=review_error,
            review_attempts=attempts,
            review_history=[*state.get("review_history", []), review][-3:],
        )

    async def _validate_script(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        await self._report(state, "validate_script", "Checking Python syntax, CAD exports, and restricted capabilities")
        validation_error = ""
        try:
            validate_model_script(state["model_code"], context.output_format)
        except ValueError as error:
            validation_error = str(error)
        attempts = state.get("validation_attempts", 0) + 1
        output = (
            "Passed deterministic CAD script validation."
            if not validation_error
            else f"Validation attempt {attempts} failed: {validation_error}"
        )
        self._agent._is_cancelled(context.task_id)
        return self._record(
            state,
            "validate_script",
            f"{len(state.get('model_code', '').splitlines())} source lines",
            output,
            validation_error=validation_error,
            validation_attempts=attempts,
        )

    def _route_after_validation(self, state: CadWorkflowState) -> str:
        if not state.get("validation_error"):
            return "save_files"
        if state.get("repair_attempts", 0) < _MAX_REPAIR_ATTEMPTS:
            return "repair_script"
        return "generation_failed"

    def _route_after_review(self, state: CadWorkflowState) -> str:
        if not state.get("review_error"):
            return "validate_script"
        if state.get("repair_attempts", 0) < _MAX_REPAIR_ATTEMPTS:
            return "repair_script"
        return "generation_failed"

    @staticmethod
    def _route_after_save(state: CadWorkflowState) -> str:
        return "build_and_snapshot" if state["context"].auto_build else "finalize"

    def _route_after_build(self, state: CadWorkflowState) -> str:
        if not state.get("build_error"):
            return "finalize"
        if state.get("repair_attempts", 0) < _MAX_REPAIR_ATTEMPTS:
            return "repair_script"
        return "generation_failed"

    async def _reconcile_plan(self, state: CadWorkflowState) -> dict[str, Any]:
        """Correct conflicting assumptions once, retaining an auditable original plan."""
        if state.get("plan_reconciled") or state.get("coverage_review", {}).get("status") != "revise":
            return {}
        context = state["context"]
        await self._report(state, "plan_geometry", "Reconciling review findings with established dimensions and assumptions")
        response = await self._agent._llm.generate(
            [
                {"role": "system", "content": build_plan_system_prompt(
                    state["skill_version"], state["skill_context"],
                )},
                {"role": "user", "content": build_plan_reconciliation_request(
                    context, state["design_plan"], state["coverage_review"],
                )},
            ],
            temperature=0.0, max_tokens=5000,
            **self._agent._llm_call_options(),
        )
        self._agent._is_cancelled(context.task_id)
        plan = parse_design_plan(response.content)
        validate_reconciled_plan(state["design_plan"], plan)
        return self._record(
            state, "plan_geometry", design_plan_summary(state["design_plan"]),
            design_plan_summary(plan), design_plan=plan,
            original_design_plan=state["design_plan"], plan_reconciled=True,
        )

    async def _repair_script(self, state: CadWorkflowState) -> dict[str, Any]:
        plan_updates = await self._reconcile_plan(state)
        state = {**state, **plan_updates}
        context = state["context"]
        attempt = state.get("repair_attempts", 0) + 1
        await self._report(
            state,
            "repair_script",
            f"Revising source from geometry or validation feedback (attempt {attempt} of {_MAX_REPAIR_ATTEMPTS})",
        )
        response = await self._agent._llm.generate(
            [
                {
                    "role": "system",
                    "content": build_code_system_prompt(
                        state["skill_version"],
                        state["skill_context"],
                        context.output_format,
                    ),
                },
                {
                    "role": "user",
                    "content": build_code_repair_request(
                        context,
                        state["design_plan"],
                        state["model_code"],
                        state.get("coverage_review", {}),
                        state.get("validation_error", ""),
                        state.get("build_error", ""),
                        review_history=state.get("review_history", []),
                    ),
                },
            ],
            temperature=0.1,
            max_tokens=12000,
            **self._agent._llm_call_options(),
        )
        code = extract_python_source(response.content)
        self._agent._is_cancelled(context.task_id)
        repaired = self._record(
            state,
            "repair_script",
            state.get("build_error") or state.get("review_error") or state.get("validation_error", ""),
            f"Generated corrected source for validation attempt {attempt}.",
            model_code=code,
            review_error="",
            build_error="",
            build_result={},
            coverage_review={},
            repair_attempts=attempt,
            validation_repair_used=True,
        )
        return {**plan_updates, **repaired}

    async def _deliver_script(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        await self._report(state, "save_files", "Saving validated CAD source")
        self._agent._is_cancelled(context.task_id)
        output = "Validated CAD source saved to the task workspace."
        output_dir = task_output_dir(context.user_id or "guest", context.task_id)
        await asyncio.to_thread(output_dir.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(
            (output_dir / "model.py").write_text,
            state["model_code"],
            encoding="utf-8",
        )
        completed = self._record(
            state,
            "save_files",
            design_plan_summary(state["design_plan"]),
            output,
            model_file="model.py",
        )
        self._agent._is_cancelled(context.task_id)
        return completed

    async def _build_and_snapshot(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        await self._report(
            state,
            "build_and_snapshot",
            "Building the CAD model, checking exported geometry, and capturing the review image",
        )
        try:
            result = await build_model(
                context.task_id,
                context.user_id or "guest",
                context.output_format,
            )
        except CadRuntimeError as error:
            self._agent._is_cancelled(context.task_id)
            return {
                "build_error": str(error),
                "build_result": {},
                "node_outputs": {
                    **state.get("node_outputs", {}),
                    "build_and_snapshot": {
                        "input": context.output_format,
                        "output": str(error),
                    },
                },
            }
        self._agent._is_cancelled(context.task_id)
        return self._record(
            state,
            "build_and_snapshot",
            context.output_format,
            "CAD geometry passed runtime checks and the review snapshot was created.",
            build_error="",
            build_result=result,
        )

    async def _finalize(self, state: CadWorkflowState) -> dict[str, Any]:
        """Finalize generation and any requested CAD review artifacts."""
        context = state["context"]
        completed = self._record(
            state,
            "finalize",
            "CAD model and review artifacts" if context.auto_build else "Validated CAD source",
            "CAD model and review snapshot are complete." if context.auto_build else "CAD source generation is complete.",
        )
        final_state = {**state, **completed}
        workflow_state = build_workflow_state(
            final_state,
            terminal_status=AgentStatus.COMPLETED.value,
        )
        await self._report(
            final_state,
            "finalize",
            "CAD generation workflow completed",
            terminal_status=AgentStatus.COMPLETED.value,
        )
        self._agent._is_cancelled(context.task_id)
        return {
            **completed,
            "workflow_state": workflow_state,
            "workflow_nodes": workflow_state["nodes"],
        }

    async def _generation_failed(self, state: CadWorkflowState) -> dict[str, Any]:
        context = state["context"]
        failure_reason = (
            state.get("build_error")
            or state.get("validation_error")
            or state.get("review_error")
            or "No valid CAD source was produced"
        )
        failed_node = (
            "build_and_snapshot" if state.get("build_error") else
            "repair_script" if state.get("repair_attempts", 0) else
            "review_geometry" if state.get("review_error") else "validate_script"
        )
        failed = {
            "failed_node": failed_node,
            "node_outputs": {
                **state.get("node_outputs", {}),
                failed_node: {
                    "input": failure_reason,
                    "output": f"Could not resolve the CAD issue after {_MAX_REPAIR_ATTEMPTS} repair attempts.",
                },
            },
        }
        final_state = {**state, **failed}
        workflow_state = build_workflow_state(
            final_state,
            terminal_status=AgentStatus.FAILED.value,
        )
        await self._report(
            final_state,
            "finalize",
            "CAD generation or review failed after the maximum repair attempts",
            terminal_status=AgentStatus.FAILED.value,
        )
        self._agent._is_cancelled(context.task_id)
        return {
            **failed,
            "workflow_state": workflow_state,
            "workflow_nodes": workflow_state["nodes"],
        }
