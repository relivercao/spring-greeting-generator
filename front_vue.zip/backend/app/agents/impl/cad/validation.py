"""Deterministic validation for generated CAD model scripts."""

from __future__ import annotations

import ast
from pathlib import PurePosixPath

from app.agents.impl.cad.types import CadOutputFormat


_OUTPUT_PATHS = {
    "step": "STEP/model.step",
    "stl": "STL/model.stl",
    "3mf": "3MF/model.3mf",
    "glb": "GLB/model.glb",
}
_FORMAT_DECORATORS = {"step": "step", "stl": "stl", "3mf": "threemf", "glb": "glb"}
_ALLOWED_MODULES = {"cadgen", "math", "__future__"}
_ALLOWED_CAD_IMPORTS = {"build123d", "step", "stl", "threemf", "glb"}
_ALLOWED_MATH_IMPORTS = {
    "atan2", "ceil", "cos", "degrees", "floor", "hypot", "isclose", "pi",
    "radians", "sin", "sqrt", "tan",
}
_FORBIDDEN_CALL_ATTRIBUTES = {
    "exec", "eval", "export", "import", "open", "read", "save", "system", "write",
}
_FORBIDDEN_NAMES = {
    "__import__", "breakpoint", "compile", "eval", "exec", "getattr", "globals",
    "input", "locals", "open", "setattr", "vars",
}
_ALLOWED_BUILTINS = {
    "abs", "all", "any", "atan2", "ceil", "cos", "degrees", "enumerate", "float",
    "floor", "hypot", "int", "isinstance", "len", "max", "min", "pi", "radians", "range", "round",
    "sin", "sorted", "sqrt", "sum", "tan", "zip",
}


def validate_model_script(source: str, output_format: CadOutputFormat) -> None:
    """Require a parseable single-model script with bounded imports and outputs."""
    if not source:
        raise ValueError("Generated model is empty")
    if len(source.encode("utf-8")) > 256 * 1024:
        raise ValueError("Generated CAD model exceeds the 256 KiB size limit")
    try:
        tree = ast.parse(source)
        compile(tree, "<cad-model>", "exec")
    except SyntaxError as error:
        raise ValueError(f"Generated model has invalid Python syntax: {error.msg}") from error

    function_names: set[str] = set()
    imported_names: set[str] = set()
    decorated_functions: list[ast.FunctionDef] = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            function_names.add(node.name)
            if node.decorator_list:
                decorated_functions.append(node)
        elif isinstance(node, ast.Import):
            for item in node.names:
                if item.name not in _ALLOWED_MODULES:
                    raise ValueError(f"Generated model imports a disallowed module: {item.name}")
                imported_names.add(item.asname or item.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module not in _ALLOWED_MODULES:
                raise ValueError(f"Generated model imports a disallowed module: {node.module}")
            if node.module == "cadgen" and any(item.name not in _ALLOWED_CAD_IMPORTS for item in node.names):
                raise ValueError("Generated model imports an unsupported cadgen capability")
            if node.module == "math":
                unsupported_math = sorted({item.name for item in node.names} - _ALLOWED_MATH_IMPORTS)
                if unsupported_math:
                    raise ValueError(
                        "Generated model imports unsupported math capabilities: "
                        + ", ".join(unsupported_math)
                    )
            if any(item.name == "*" for item in node.names):
                raise ValueError("Generated model cannot use wildcard imports")
            imported_names.update(item.asname or item.name for item in node.names)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            if any(isinstance(child, ast.Call) for child in ast.walk(node)):
                raise ValueError("Generated model cannot execute calls at module scope")
            continue
        elif (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        ):
            continue
        elif isinstance(node, ast.If) and _is_main_guard(node.test):
            continue
        else:
            raise ValueError("Generated model contains unsupported top-level statements")

    if len(decorated_functions) != 1:
        raise ValueError("Generated model must declare exactly one decorated model function")
    model_function = decorated_functions[0]
    if model_function.name != "model":
        raise ValueError("Generated CAD model function must be named model")
    if any((model_function.args.args, model_function.args.posonlyargs, model_function.args.kwonlyargs, model_function.args.vararg, model_function.args.kwarg)):
        raise ValueError("Generated CAD model function must be parameterless")
    decorator_calls = [item for item in model_function.decorator_list if isinstance(item, ast.Call)]
    decorator_names = {_call_name(item.func) for item in decorator_calls}
    required_decorator = _FORMAT_DECORATORS[output_format]
    if "step" not in decorator_names or required_decorator not in decorator_names:
        raise ValueError(f"Generated model must declare STEP and {output_format.upper()} outputs")

    expected_decorators = {"step": _OUTPUT_PATHS["step"], required_decorator: _OUTPUT_PATHS[output_format]}
    if decorator_names != set(expected_decorators):
        raise ValueError("Generated model must declare only the requested CAD outputs")
    if not decorator_names.issubset(imported_names):
        raise ValueError("CAD output decorators must be imported from cadgen")
    for call in decorator_calls:
        name = _call_name(call.func)
        if call.args or len(call.keywords) != 1 or call.keywords[0].arg != "out":
            raise ValueError("CAD output decorators may declare only one fixed out path")
        output = next((keyword.value for keyword in call.keywords if keyword.arg == "out"), None)
        if not isinstance(output, ast.Constant) or not isinstance(output.value, str):
            raise ValueError("CAD output decorators must use a fixed relative out path")
        safe_path = PurePosixPath(output.value.replace("\\", "/"))
        if safe_path.is_absolute() or ".." in safe_path.parts or safe_path.as_posix() != expected_decorators.get(name):
            raise ValueError("CAD output paths must stay inside the task output folders")

    main_guards = [node for node in tree.body if isinstance(node, ast.If) and _is_main_guard(node.test)]
    main_calls = [
        statement.value
        for node in main_guards
        for statement in node.body if isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Call)
    ]
    if (
        len(main_guards) != 1
        or len(main_calls) != 1
        or _call_name(main_calls[0].func) != model_function.name
    ):
        raise ValueError("Generated model must build itself from its __main__ entrypoint")

    decorator_call_ids = {id(call) for call in decorator_calls}
    assigned_names = [
        node.id
        for node in ast.walk(model_function)
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store)
    ]
    axis_names = {
        target.id
        for node in ast.walk(model_function)
        if isinstance(node, ast.Assign)
        and isinstance(node.value, ast.Attribute)
        and node.value.attr == "axis_of_rotation"
        for target in node.targets
        if isinstance(target, ast.Name) and assigned_names.count(target.id) == 1
    }
    for node in ast.walk(tree):
        if isinstance(node, ast.Import) and any(item.name not in _ALLOWED_MODULES for item in node.names):
            raise ValueError("Generated model contains a disallowed module import")
        if isinstance(node, ast.ImportFrom):
            if node.module not in _ALLOWED_MODULES:
                raise ValueError(f"Generated model imports a disallowed module: {node.module}")
            if node.module == "cadgen" and any(item.name not in _ALLOWED_CAD_IMPORTS for item in node.names):
                raise ValueError("Generated model imports an unsupported cadgen capability")
            if node.module == "math":
                unsupported_math = sorted({item.name for item in node.names} - _ALLOWED_MATH_IMPORTS)
                if unsupported_math:
                    raise ValueError(
                        "Generated model imports unsupported math capabilities: "
                        + ", ".join(unsupported_math)
                    )
            if any(item.name == "*" for item in node.names):
                raise ValueError("Generated model cannot use wildcard imports")
        if isinstance(node, ast.Name) and (
            node.id in _FORBIDDEN_NAMES or node.id.startswith("__") and node.id != "__name__"
        ):
            raise ValueError(f"Generated model uses a disallowed Python capability: {node.id}")
        if isinstance(node, ast.Attribute) and node.attr.startswith("_"):
            raise ValueError("Generated model cannot access private Python attributes")
        if (
            isinstance(node, ast.Attribute)
            and node.attr in {"X", "Y", "Z"}
            and isinstance(node.value, ast.Name)
            and node.value.id in axis_names
        ):
            raise ValueError(
                "CAD Axis does not expose coordinate components directly; "
                "use axis.direction.X/Y/Z for orientation and axis.position.X/Y/Z for location"
            )
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr in {"is_valid", "is_null"}:
                raise ValueError(
                    f"CAD Shape.{node.func.attr} is a property in the pinned runtime; remove the call parentheses"
                )
            if (
                node.func.attr in _FORBIDDEN_CALL_ATTRIBUTES
                or node.func.attr.startswith(("export_", "import_", "read_", "write_", "save_"))
            ):
                raise ValueError(f"Generated model calls an unsupported CAD operation: {node.func.attr}")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if id(node) in decorator_call_ids:
                continue
            if node.func.id in _FORBIDDEN_NAMES or node.func.id.startswith("__"):
                raise ValueError(f"Generated model uses a disallowed Python capability: {node.func.id}")
            if (
                node.func.id not in function_names
                and node.func.id not in imported_names
                and node.func.id not in _ALLOWED_BUILTINS
            ):
                raise ValueError(f"Generated model calls an unsupported global: {node.func.id}")


def _is_main_guard(node: ast.expr) -> bool:
    return (
        isinstance(node, ast.Compare)
        and isinstance(node.left, ast.Name)
        and node.left.id == "__name__"
        and len(node.ops) == 1
        and isinstance(node.ops[0], ast.Eq)
        and len(node.comparators) == 1
        and isinstance(node.comparators[0], ast.Constant)
        and node.comparators[0].value == "__main__"
    )


def _call_name(node: ast.expr) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""
