"""Publish a complete CAD attempt while retaining previous outputs on failure."""

from __future__ import annotations

import os
from pathlib import Path


class CadPublicationError(OSError):
    """Publication failure with an explicit recovery-directory retention flag."""

    def __init__(self, message: str, *, recovery_required: bool):
        super().__init__(message)
        self.recovery_required = recovery_required


def publish_artifacts(build_dir: Path, task_dir: Path, records: list[dict]) -> None:
    """Replace verified artifacts with a rollback journal for filesystem failures."""
    targets: list[tuple[Path, Path, Path]] = []
    for record in records:
        relative = Path(record["filename"])
        source = (build_dir / relative).resolve()
        destination = (task_dir / relative).resolve()
        if not source.is_relative_to(build_dir) or not destination.is_relative_to(task_dir):
            raise ValueError("CAD artifact publication path escapes its output directory")
        if not source.is_file() or (destination.exists() and not destination.is_file()):
            raise ValueError("CAD artifact publication requires regular files")
        targets.append((source, destination, build_dir / "previous" / relative))

    journal: list[tuple[Path, Path | None]] = []
    try:
        for source, destination, backup in targets:
            destination.parent.mkdir(parents=True, exist_ok=True)
            previous = None
            if destination.exists():
                backup.parent.mkdir(parents=True, exist_ok=True)
                os.replace(destination, backup)
                previous = backup
            journal.append((destination, previous))
            os.replace(source, destination)
    except OSError as error:
        rollback_errors = []
        for destination, previous in reversed(journal):
            try:
                if previous is None:
                    destination.unlink(missing_ok=True)
                else:
                    os.replace(previous, destination)
            except OSError as rollback_error:
                rollback_errors.append(str(rollback_error))
        detail = f"CAD artifact publication failed: {error}"
        if rollback_errors:
            detail += f"; recovery files retained at {build_dir}; rollback failed: " + "; ".join(rollback_errors)
        raise CadPublicationError(detail, recovery_required=bool(rollback_errors)) from error
