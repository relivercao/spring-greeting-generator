"""Typed inputs for the CAD Agent."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from app.agents.base import AgentContext


CadOutputFormat = Literal["step", "stl", "3mf", "glb"]


@dataclass
class CadContext(AgentContext):
    """Inputs required to author one standalone parametric CAD model."""

    prompt: str = ""
    output_format: CadOutputFormat = "step"
    auto_build: bool = False
