"""
@file api_filter.py
@author caoshwen
@brief API intelligent filter - extract relevant parts from complete API reference

@version 1.0
@date 2026-03-16

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

Used to optimize CLI Prompt, reduce unnecessary API definitions, improve execution efficiency.
"""
import re
from typing import Set, Optional
from loguru import logger


def extract_called_functions(source_code: str, layer: str) -> Set[str]:
    """
    Extract called function names from source code

    Args:
        source_code: Source file content
        layer: Architecture layer (hal/driver)

    Returns:
        Set of called function names

    Example:
        >>> source = "void test() { HAL_PWR_EnableWakeUpPin(1); }"
        >>> extract_called_functions(source, "hal")
        {'HAL_PWR_EnableWakeUpPin'}
    """
    if not source_code:
        return set()

    # Select matching pattern based on layer
    if layer.lower() == "hal":
        # HAL layer: match HAL_XXX_YYYY(
        # Example: HAL_PWR_EnableWakeUpPin, HAL_GPIO_Init
        pattern = r'HAL_[A-Z]+_[A-Za-z0-9_]+\('
    elif layer.lower() == "driver":
        # Driver layer: match Driver_XXX_YYYY(
        pattern = r'Driver_[A-Za-z0-9_]+\('
    else:
        # Generic pattern: match any function call
        pattern = r'[A-Za-z][A-Za-z0-9_]*\('

    try:
        # Find all matches
        matches = re.findall(pattern, source_code)

        # Remove opening parenthesis to get function name
        functions = {m.rstrip('(') for m in matches}

        logger.info(f"📋 Extracted {len(functions)} called functions from source file")
        if functions:
            # Only show first 10 to avoid log bloat
            sample = list(functions)[:10]
            logger.debug(f"Function list (first 10): {sample}")

        return functions

    except Exception as e:
        logger.error(f"Failed to extract functions: {e}")
        return set()


def filter_relevant_apis(
    vendor_api_ref: str,
    called_functions: Set[str]
) -> str:
    """
    Filter API reference, keep only relevant parts for called functions

    Args:
        vendor_api_ref: Complete API reference documentation string
        called_functions: Set of called function names

    Returns:
        Filtered API reference string

    Example:
        >>> vendor_ref = "API 1: HAL_PWR_Enable...\\nAPI 2: HAL_PWR_Disable..."
        >>> called = {'HAL_PWR_Enable'}
        >>> filtered = filter_relevant_apis(vendor_ref, called)
        >>> # returns content containing only API 1
    """
    if not vendor_api_ref:
        logger.warning("API reference is empty, cannot filter")
        return vendor_api_ref

    if not called_functions:
        logger.warning("No called functions detected, returning full API reference")
        return vendor_api_ref

    try:
        # Split by API definitions
        # Assume each API definition is separated by "===" or "// API"
        # Try multiple splitting methods
        if "===" in vendor_api_ref:
            sections = vendor_api_ref.split("===")
            separator = "==="
        elif "// API" in vendor_api_ref:
            sections = vendor_api_ref.split("// API")
            separator = "// API"
        else:
            # Split by paragraphs
            sections = vendor_api_ref.split("\n\n")
            separator = "\n\n"

        original_count = len(sections)
        relevant_sections = []

        for section in sections:
            if not section.strip():
                continue

            # Check if this section contains any called function
            # Use word boundary matching to avoid false matches (e.g. HAL_PWR_Init should not match HAL_PWR_InitPVD)
            is_relevant = False
            for func in called_functions:
                # Use regex to check if function name appears in section
                # \b means word boundary
                pattern = r'\b' + re.escape(func) + r'\b'
                if re.search(pattern, section):
                    is_relevant = True
                    break

            if is_relevant:
                relevant_sections.append(section)

        filtered_count = len(relevant_sections)

        # If nothing left after filtering, return original (safe fallback)
        if not relevant_sections:
            logger.warning("No relevant APIs after filtering, returning full reference")
            return vendor_api_ref

        # Recombine
        filtered_ref = separator.join(relevant_sections)

        # Add statistics
        logger.info(
            f"✂️ API reference filtered: {original_count} → {filtered_count} sections "
            f"(reduced {original_count - filtered_count}, "
            f"saved {(1 - filtered_count/original_count)*100:.1f}%)"
        )

        # Add header description
        header = (
            f"=== Vendor API reference ({filtered_count}/{original_count} relevant) ===\n"
            f"Note: {original_count - filtered_count} irrelevant APIs filtered out\n\n"
        )

        return header + filtered_ref

    except Exception as e:
        logger.error(f"Failed to filter API: {e}, returning original reference")
        return vendor_api_ref


def estimate_prompt_reduction(
    original_length: int,
    called_functions: Set[str],
    total_apis: int
) -> dict:
    """
    Estimate Prompt compression effect

    Args:
        original_length: Original Prompt length
        called_functions: Set of called functions
        total_apis: Total number of APIs

    Returns:
        Dictionary containing estimation result
    """
    # Assume each API occupies average same length
    if total_apis == 0:
        return {"estimated_reduction": 0, "estimated_new_length": original_length}

    called_count = len(called_functions)

    # Estimate new API reference length
    avg_api_length = original_length / total_apis
    estimated_api_length = avg_api_length * called_count

    # Estimate new Prompt length
    # Prompt = other content + API reference
    # Assume API reference accounts for 40% of Prompt
    api_ratio = 0.4
    non_api_length = original_length * (1 - api_ratio)
    estimated_new_length = non_api_length + estimated_api_length

    estimated_reduction = (1 - estimated_new_length / original_length) * 100

    return {
        "original_length": original_length,
        "estimated_new_length": int(estimated_new_length),
        "estimated_reduction": f"{estimated_reduction:.1f}%",
        "api_count": f"{called_count}/{total_apis}",
        "api_reduction": f"{(1 - called_count/total_apis)*100:.1f}%"
    }