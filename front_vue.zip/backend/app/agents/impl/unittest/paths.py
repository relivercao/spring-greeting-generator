"""
@file _unittest_paths.py
@author caoshwen
@brief Layer detection, platform detection, test file path generation (internal module).

detect_layer_from_filename / detect_platform_from_path / generate_file_paths.
Migrated from original unittest_agent copy.py.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import os
import re
from pathlib import Path
from typing import Optional

from loguru import logger


_STATIC_FUNCTION_PATTERN = re.compile(
    r"(?m)^[ \t]*static[ \t]+"
    r"(?:(?:inline|const|volatile|__attribute__\s*\(\([^\n]*?\)\))[ \t]+)*"
    r"[A-Za-z_]\w*(?:[ \t\*]+[A-Za-z_]\w*)*[ \t\*]+"
    r"[A-Za-z_]\w*[ \t]*\([^;{}]*\)[ \t\r\n]*\{"
)


def source_has_static_functions(content: Optional[str]) -> bool:
    """Return whether source text defines a file-scope static function."""
    if not content:
        return False
    without_comments = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)
    without_comments = re.sub(r"//[^\n]*", "", without_comments)
    return _STATIC_FUNCTION_PATTERN.search(without_comments) is not None


def should_include_optional_artifacts(
    layer: Optional[str],
    source_content: Optional[str],
) -> bool:
    """Enable the optional APP test-access translation unit for static functions."""
    return (
        str(layer or "").strip().lower() == "app"
        and source_has_static_functions(source_content)
    )


def _is_app_forbidden_libs_path(path_value: str) -> bool:
    """Return whether an APP-layer path points into libs/platformkit."""
    normalized = path_value.replace("\\", "/").lower()
    return bool(re.search(r"(^|/)libs/platformkit(/|$)", normalized))


def contains_app_forbidden_libs_reference(content: str) -> bool:
    """Return whether generated APP content references libs/platformkit."""
    if not content:
        return False
    normalized = content.replace("\\", "/").lower()
    return bool(re.search(r"(^|[\"'\s])(?:\.\./)*libs/platformkit(?:/|$)", normalized, re.MULTILINE))


def detect_layer_from_filename(
    filename: str,
    layer_hint: Optional[str] = None,
    source_path: Optional[str] = None,
) -> str:
    """Detect architecture layer from filename and path.

    Supports BSP layers (hal / driver) and Midware layers (midware_controller / midware_driver).
    When filename contains "driver", source_path is used to distinguish BSP driver from midware driver.

    Args:
        filename: Source filename
        layer_hint: Layer hint (from UI selection)
        source_path: Full source file path (used to distinguish BSP vs midware via path pattern)

    Returns:
        Layer name (hal / driver / midware_controller / midware_driver / app / common)
    """
    valid_hints = (
        'driver', 'hal', 'controller', 'app', 'midware', 'common',
        'midware_driver', 'midware_controller',
    )
    hint = (layer_hint or '').lower().strip()
    if hint in ('', 'auto'):
        hint = ''
    if hint in valid_hints:
        if hint == 'midware':
            return 'midware_controller'
        if hint == 'controller':
            return 'midware_controller'
        return hint

    if source_path:
        path_lower = source_path.replace('\\', '/').lower()
        is_platformkit = 'platformkit' in path_lower

        if not is_platformkit:
            # Root-level bsp/ and midware/ directories are treated as app layer.
            if ('/bsp/' in path_lower
                    or path_lower.startswith('bsp/')
                    or path_lower == 'bsp'):
                return 'app'
            if ('/midware/' in path_lower
                    or path_lower.startswith('midware/')
                    or path_lower == 'midware'):
                return 'app'

        # platformkit BSP layer detection (must precede midware checks).
        if '/bsp/hal/' in path_lower:
            return 'hal'
        if '/bsp/drivers/' in path_lower or '/bsp/driver/' in path_lower:
            return 'driver'

        if '/midware/controllers/' in path_lower:
            return 'midware_controller'
        if '/midware/drivers/' in path_lower:
            return 'midware_driver'
        if '/midware/' in path_lower:
            return 'midware_controller'

        # Prefer app layer for common app-module locations.
        app_path_hints = (
            '/managers/', '/manager/',
            '/apps/', '/app/',
            '/services/', '/service/',
            '/modules/', '/module/',
            '/features/', '/feature/',
            '/tasks/', '/task/',
            '/workflows/', '/workflow/',
            '/usecases/', '/usecase/',
            '/business/',
            '/application/',
            '/state_machines/', '/state-machine/', '/statemachine/',
        )
        if any(hint in path_lower for hint in app_path_hints):
            return 'app'

        # Source path provided but no layer-specific directory hint matched.
        # Avoid misleading filename heuristics (e.g. 'hal' in 'hal-adc.c' outside
        # a platformkit tree) — fall back to 'common' for a neutral scaffold.
        return 'common'

    filename_lower = filename.lower()
    if filename_lower.startswith('app-') or filename_lower.startswith('app_'):
        return 'app'
    if 'controller' in filename_lower or 'ctrl' in filename_lower:
        return 'midware_controller'
    if 'hal' in filename_lower or 'bsp' in filename_lower:
        return 'hal'
    if 'driver' in filename_lower or 'sensor' in filename_lower or 'comm' in filename_lower:
        return 'driver'
    if 'app' in filename_lower or 'task' in filename_lower or 'service' in filename_lower:
        return 'app'
    # Unknown: fall back to 'common' instead of 'driver' so the caller can
    # route to a neutral test scaffold rather than a wrong BSP layer.
    return 'common'


def extract_app_layer_subdir(source_path: Optional[str], module_name: str) -> Optional[str]:
    """
    Extract app-layer subdirectory structure from source file path.

    Args:
        source_path: Source file absolute or relative path (e.g., "bsp/usb/usb_device.c" or "D:/project/bsp/usb/usb_device.c")
        module_name: Module name extracted from filename

    Returns:
        Subdirectory path for tests (e.g., "bsp/usb"), or None if extraction fails

    Examples:
        - "bsp/hal/stm32u3/hal-adc.c"                           → "bsp/hal/stm32u3"
        - "bsp/drivers/driver-imu/driver-lis2dux12/src/x.c"    → "bsp/drivers/driver-imu/driver-lis2dux12"
        - "midware/protocol/mqtt.c"                             → "midware/protocol"
        - "managers/task/task_manager.c"                        → "managers/task"
        - "apps/non-secure/adc/src/app-adc.c"                  → "apps/non-secure/adc"
        - "app-logger.c"                                        → None (flat file, use fallback)
    """
    if not source_path:
        return None

    # Normalize path separators
    normalized = source_path.replace('\\', '/')

    # Extract directory path (remove filename)
    parts = normalized.split('/')
    if len(parts) <= 1:
        # Flat file (no directory structure)
        return None

    # Remove filename to get directory path
    dir_parts = parts[:-1]

    # Known top-level subdirectory patterns that should be preserved
    known_top_level_subdirs = ['bsp', 'midware', 'managers', 'services', 'apps', 'controllers', 'drivers', 'libs']

    # Find the first occurrence of a known top-level subdirectory
    start_index = -1
    for i, part in enumerate(dir_parts):
        if part.lower() in known_top_level_subdirs:
            start_index = i
            break

    # If found, extract from that point onwards
    if start_index >= 0:
        dir_parts = dir_parts[start_index:]
    else:
        # No known subdirectory found, try to strip common prefixes
        prefixes_to_strip = ['src', 'source', 'lib', 'app']
        while dir_parts and dir_parts[0].lower() in prefixes_to_strip:
            dir_parts.pop(0)

    if not dir_parts:
        # All parts were stripped
        return None

    # Remove trailing 'src', 'source', 'inc', 'include' directories from the path
    # These are implementation details that shouldn't appear in test paths
    dirs_to_remove = ['src', 'source', 'inc', 'include']
    while dir_parts and dir_parts[-1].lower() in dirs_to_remove:
        dir_parts.pop()

    if not dir_parts:
        # All parts were stripped
        return None

    # Return extracted subdirectory structure
    return '/'.join(dir_parts)


_SOURCE_LAYOUT_TRAILING_DIRS = frozenset({"src", "source", "inc", "include"})
_PLATFORMKIT_ROOT_DIRS = frozenset({"bsp", "midware"})
_APP_ROOT_DIRS = frozenset({
    "bsp", "midware", "managers", "manager", "services", "service",
    "apps", "app", "controllers", "controller", "drivers", "driver",
    "common", "modules", "module", "features", "feature", "tasks", "task",
    "workflows", "workflow", "usecases", "usecase", "business", "application",
    "state_machines", "state-machine", "statemachine",
})


def _normalized_parts(path_value: str) -> list[str]:
    """Split a path into normalized, non-empty components."""
    return [part for part in path_value.replace("\\", "/").split("/") if part and part != "."]


def _strip_trailing_layout_dirs(parts: list[str]) -> list[str]:
    """Remove implementation-only leaf directories from a source directory path."""
    trimmed = list(parts)
    while trimmed and trimmed[-1].lower() in _SOURCE_LAYOUT_TRAILING_DIRS:
        trimmed.pop()
    return trimmed


def _find_platformkit_index(parts: list[str]) -> Optional[int]:
    """Return the index of a libs/platformkit sequence, if present."""
    lower_parts = [part.lower() for part in parts]
    for index in range(len(lower_parts) - 1):
        if lower_parts[index] == "libs" and lower_parts[index + 1] == "platformkit":
            return index
    return None


def _derive_source_test_subdir(
    source_path: Optional[str],
    project_root: Optional[str],
    is_platformkit_source: bool,
) -> Optional[Path]:
    """Mirror a source directory below the appropriate generated test root."""
    if not source_path:
        return None

    normalized = source_path.replace("\\", "/")
    source_dir = normalized.rsplit("/", 1)[0] if "/" in normalized else ""
    if not source_dir:
        return None

    relative_dir = source_dir
    if project_root:
        root = str(project_root).replace("\\", "/").rstrip("/")
        root_lower = root.lower()
        source_dir_lower = source_dir.lower()
        if source_dir_lower == root_lower:
            relative_dir = ""
        elif source_dir_lower.startswith(f"{root_lower}/"):
            relative_dir = source_dir[len(root) + 1:]

    if relative_dir.startswith("/") or re.match(r"^[A-Za-z]:", relative_dir):
        # The source lives outside the project tree (e.g. an uploads
        # directory on another branch). Mirroring its absolute path below
        # the test root would fabricate paths like tests/stubs/opt/...,
        # so no subdirectory mirroring applies.
        return None

    parts = _normalized_parts(relative_dir)
    if not parts:
        return None

    if is_platformkit_source:
        platformkit_index = _find_platformkit_index(parts)
        if platformkit_index is not None:
            parts = parts[platformkit_index + 2:]
        else:
            root_index = next(
                (index for index, part in enumerate(parts) if part.lower() in _PLATFORMKIT_ROOT_DIRS),
                0,
            )
            parts = parts[root_index:]
    else:
        root_index = next(
            (index for index, part in enumerate(parts) if part.lower() in _APP_ROOT_DIRS),
            0,
        )
        parts = parts[root_index:]

    trimmed = _strip_trailing_layout_dirs(parts)
    return Path(*trimmed) if trimmed else None


def detect_platform_from_path(
    project_root: Optional[str],
    source_filename: str,
) -> str:
    """Detect target platform from source file path.

    Returns:
        Platform name (stm32u3 / rtl8722fam / nrf52)
    """
    if not project_root:
        return "stm32u3"

    source_path = Path(project_root) / source_filename
    path_str = str(source_path).lower()

    # Distinguish stm32u5 before stm32u3 (u5 path contains "stm32u5", not "stm32u3")
    if 'stm32u5' in path_str:
        return 'stm32u5'
    if 'stm32u3' in path_str:
        return 'stm32u3'
    # Check rtl8720cx before rtl8722fam (more specific first)
    if 'rtl8720cx' in path_str:
        return 'rtl8720cx'
    if 'rtl8722fam' in path_str or 'rtl8722' in path_str or 'realtek' in path_str:
        return 'rtl8722fam'
    if 'nrf52' in path_str or 'nrf53' in path_str or 'nordic' in path_str:
        return 'nrf52'

    if source_path.exists():
        try:
            content = source_path.read_text(encoding='utf-8', errors='ignore')[:5000]
            if 'STM32U5' in content or 'stm32u5' in content.lower():
                return 'stm32u5'
            if 'stm32u3' in content.lower() or 'STM32U3' in content:
                return 'stm32u3'
            if 'rtl8722' in content.lower() or 'RTL8722' in content or 'REALTEK' in content:
                return 'rtl8722fam'
            if 'nrf52' in content.lower() or 'NRF52' in content or 'NORDIC' in content:
                return 'nrf52'
        except Exception as e:
            logger.debug(f"Failed to read file content for platform detection: {e}")

    return "stm32u3"


def generate_file_paths(
    source_filename: str,
    layer: Optional[str] = None,
    project_root: Optional[str] = None,
    platform: Optional[str] = None,
    source_path: Optional[str] = None,
    source_content: Optional[str] = None,
) -> dict[str, str]:
    """Generate test file save paths based on source filename and layer.

    Args:
        source_filename: Source filename (e.g. driver-charger.c)
        layer: Layer (driver / hal / midware_controller / midware_driver / app)
        project_root: Project root path
        platform: Target platform
        source_path: Full source file path (used to distinguish BSP vs midware via path patterns)

    Returns:
        Dictionary containing paths for all files
    """
    detected_layer = detect_layer_from_filename(source_filename, layer, source_path)

    # Platform detection: ALWAYS detect from source_path when available (ground truth).
    # User-provided platform parameter may be incorrect or outdated.
    # Source path contains the actual platform directory (e.g., stm32u5/hal-adc.c).
    if source_path:
        # Always use source_path for detection when available
        detected_platform = detect_platform_from_path(project_root, source_path)
        if platform and platform != detected_platform:
            logger.warning(
                f"[Platform] User specified '{platform}' but source path indicates '{detected_platform}'. "
                f"Using detected platform '{detected_platform}' from source path."
            )
        platform = detected_platform
    elif not platform:
        # Fallback: no source_path and no platform specified
        if detected_layer == 'hal':
            # Use filename as last resort (may miss stm32u5 hints)
            platform = detect_platform_from_path(project_root, source_filename)
        else:
            platform = detect_platform_from_path(project_root, source_filename)

    module_name = Path(source_filename).stem
    if detected_layer == 'app':
        # App layer rule (rulebook 4.3/4.4): only strip 'app-' prefix.
        # Files like hal-usb.c or controller-adc.c must keep their full stem
        # to avoid tc-app-usb.cpp collisions across layers.
        for prefix in ['app-', 'app_']:
            if module_name.startswith(prefix):
                module_name = module_name[len(prefix):]
                break
    else:
        for prefix in [
            'controller-', 'controller_', 'ctrl-', 'ctrl_',
            'driver-', 'driver_', 'hal-', 'hal_', 'app-', 'app_',
        ]:
            if module_name.startswith(prefix):
                module_name = module_name[len(prefix):]
                break

    # --- File name generation ---
    if detected_layer == 'hal':
        test_file = f"tc-hal-{module_name}.cpp"
        test_header = f"tc-hal-{module_name}.h"
        if platform and 'rtl' in platform.lower():
            mock_file = f"mock-ameba-{module_name}.cpp"
            mock_header = f"mock-ameba-{module_name}.h"
        elif platform and 'stm32' in platform.lower():
            mock_file = f"mock-stm32-hal-{module_name}.cpp"
            mock_header = f"mock-stm32-hal-{module_name}.h"
        elif platform and 'nrf' in platform.lower():
            mock_file = f"mock-nrf-{module_name}.cpp"
            mock_header = f"mock-nrf-{module_name}.h"
        else:
            mock_prefix = platform if platform else "stm32"
            mock_file = f"mock-{mock_prefix}-{module_name}.cpp"
            mock_header = f"mock-{mock_prefix}-{module_name}.h"
    elif detected_layer == 'driver':
        test_file = f"tc-driver-{module_name}.cpp"
        test_header = f"tc-driver-{module_name}.h"
        mock_file = f"mock-hal-{module_name}.cpp"
        mock_header = f"mock-hal-{module_name}.h"
    elif detected_layer == 'midware_controller':
        test_file = f"tc-controller-{module_name}.cpp"
        test_header = f"tc-controller-{module_name}.h"
        mock_file = f"mock-driver-{module_name}.cpp"
        mock_header = f"mock-driver-{module_name}.h"
    elif detected_layer == 'midware_driver':
        test_file = f"tc-driver-{module_name}.cpp"
        test_header = f"tc-driver-{module_name}.h"
        mock_file = f"mock-driver-{module_name}-type0.cpp"
        mock_header = f"mock-driver-{module_name}-type0.h"
    elif detected_layer == 'app':
        test_file = f"tc-app-{module_name}.cpp"
        test_header = f"tc-app-{module_name}.h"
        mock_file = f"mock-{module_name}.cpp"
        mock_header = f"mock-{module_name}.h"
    else:
        test_file = f"tc-{detected_layer}-{module_name}.cpp"
        test_header = f"tc-{detected_layer}-{module_name}.h"
        mock_file = f"mock-{module_name}.cpp"
        mock_header = f"mock-{module_name}.h"

    base_path = Path(project_root) if project_root else Path(".")

    # --- Directory path generation ---
    # midware layer mock uses FLAT layout (no inc/src subdirectories)
    use_flat_mock = False

    # Determine whether project_root is a platformkit sub-repo root (scenario 1):
    #   Directly containing bsp/ and tests/ means it's a platformkit sub-repo; path templates don't need the libs/platformkit/ prefix.
    # Scenario 2 (project root): project_root contains libs/platformkit/; path templates need the libs/platformkit/ prefix.
    # Scenario 3 (standalone file): project_root is the file directory; same logic as scenario 2 (falls back when libs/platformkit is absent).
    _is_platformkit_root = is_platformkit_subrepo(str(base_path), source_path=source_path)
    is_platformkit_layer = detected_layer in {
        "hal", "driver", "midware_controller", "midware_driver",
    }
    source_subdir = _derive_source_test_subdir(
        source_path,
        str(base_path),
        is_platformkit_layer,
    )

    if detected_layer == 'driver':
        if _is_platformkit_root:
            test_base = base_path / "tests/unit/bsp/drivers" / f"driver-{module_name}"
            mock_base = base_path / "tests/mocks/drivers"
        else:
            test_base = base_path / "tests/unit/bsp/drivers" / f"driver-{module_name}"
            mock_base = base_path / "tests/mocks/drivers"
    elif detected_layer == 'hal':
        plat = platform if platform else "stm32u3"
        if _is_platformkit_root:
            # Scenario 1: project_root is platformkit/, use tests/unit/bsp/hal/ directly
            test_base = base_path / "tests/unit/bsp/hal" / plat
            mock_base = base_path / "tests/mocks" / plat / "platform-mocks"
        else:
            # Scenario 2/3: project_root is the project root, needs libs/platformkit/ prefix
            test_base = base_path / "libs/platformkit/tests/unit/bsp/hal" / plat
            mock_base = base_path / "libs/platformkit/tests/mocks" / plat / "platform-mocks"
    elif detected_layer == 'midware_controller':
        if _is_platformkit_root:
            test_base = (
                base_path / "tests/unit/midware/controllers"
                / f"controller-{module_name}"
            )
            mock_base = base_path / "tests/mocks/midware/controllers"
        else:
            test_base = (
                base_path / "libs/platformkit/tests/unit/midware/controllers"
                / f"controller-{module_name}"
            )
            mock_base = base_path / "libs/platformkit/tests/mocks/midware/controllers"
        use_flat_mock = True
    elif detected_layer == 'midware_driver':
        if _is_platformkit_root:
            test_base = (
                base_path / "tests/unit/midware/drivers"
                / f"driver-{module_name}"
            )
            mock_base = base_path / "tests/mocks/midware/drivers"
        else:
            test_base = (
                base_path / "libs/platformkit/tests/unit/midware/drivers"
                / f"driver-{module_name}"
            )
            mock_base = base_path / "libs/platformkit/tests/mocks/midware/drivers"
        use_flat_mock = True
    elif detected_layer == 'common':
        test_base = base_path / "tests/unit/common" / module_name
        mock_base = base_path / "tests/mocks/common"
        use_flat_mock = True
    elif detected_layer == 'app':
        # App layer: extract subdirectory structure from source path
        # Examples:
        #   - bsp/usb/usb.c        → tests/unit/bsp/usb/
        #   - midware/mqtt.c       → tests/unit/midware/
        #   - managers/task.c      → tests/unit/managers/
        #   - app-logger.c (flat)  → tests/unit/app-logger/ (fallback)
        logger.info(f"[AppLayer] Extracting subdir from source_path='{source_path}', module_name='{module_name}'")
        app_subdir_path = _derive_source_test_subdir(
            source_path,
            str(base_path),
            is_platformkit_source=False,
        )
        app_subdir = str(app_subdir_path).replace("\\", "/") if app_subdir_path else None
        logger.info(f"[AppLayer] Extracted app_subdir='{app_subdir}'")
        if app_subdir:
            # Use extracted subdirectory structure
            test_base = base_path / "tests/unit" / app_subdir
            logger.info(f"[AppLayer] Using subdirectory structure: test_base='{test_base}'")
        else:
            # Fallback to app-<module> for flat files
            test_base = base_path / "tests/unit" / f"app-{module_name}"
            logger.info(f"[AppLayer] Using fallback flat structure: test_base='{test_base}'")
        # mocks: tests/mocks/inc/ and tests/mocks/src/ (with inc/src subdirs)
        mock_base = base_path / "tests/mocks"
    else:
        test_base = base_path / "tests/unit"
        mock_base = base_path / "tests/mocks"

    if is_platformkit_layer:
        platformkit_tests_root = (
            base_path / "tests"
            if _is_platformkit_root
            else base_path / "libs/platformkit/tests"
        )
    else:
        platformkit_tests_root = base_path / "tests"
    stub_base = platformkit_tests_root / "stubs" / (source_subdir or Path(module_name))

    if use_flat_mock:
        mock_impl_path = str(mock_base / mock_file)
        mock_header_path = str(mock_base / mock_header)
    else:
        mock_impl_path = str(mock_base / 'src' / mock_file)
        mock_header_path = str(mock_base / 'inc' / mock_header)

    # Determine overwrite-inc directory for SDK header files
    # HAL layer: platform-specific overwrite-inc (e.g., tests/mocks/stm32u5/overwrite-inc/)
    # Common layer: shared overwrite-inc (tests/mocks/overwrite-inc/)
    overwrite_inc_dir = None
    if detected_layer == 'hal':
        plat = platform if platform else "stm32u3"
        if _is_platformkit_root:
            overwrite_inc_dir = str(base_path / "tests/mocks" / plat / "overwrite-inc")
        else:
            overwrite_inc_dir = str(base_path / "libs/platformkit/tests/mocks" / plat / "overwrite-inc")
    elif detected_layer == 'common':
        overwrite_inc_dir = str(base_path / "tests/mocks/overwrite-inc")

    result = {
        'layer': detected_layer,
        'platform': platform if platform else "stm32u3",
        'module_name': module_name,
        'test_file': test_file,
        'test_header': test_header,
        'mock_file': mock_file,
        'mock_header': mock_header,
        'test_impl_path': str(test_base / test_file),
        'test_header_path': str(test_base / test_header),
        'mock_impl_path': mock_impl_path,
        'mock_header_path': mock_header_path,
        'stub_file': f"stub-{module_name}.cpp",
        'stub_header': f"stub-{module_name}.h",
        'stub_impl_path': str(stub_base / f"stub-{module_name}.cpp"),
        'stub_header_path': str(stub_base / f"stub-{module_name}.h"),
        'test_base_dir': str(test_base),
        'mock_base_dir': str(mock_base),
        'stub_base_dir': str(stub_base),
    }
    if detected_layer == "app":
        source_text = source_content
        if source_text is None:
            candidate_paths = []
            if source_path:
                candidate_paths.append(Path(source_path))
            if project_root:
                candidate_paths.append(Path(project_root) / source_filename)
            for candidate in candidate_paths:
                try:
                    if candidate.is_file():
                        source_text = candidate.read_text(encoding="utf-8", errors="ignore")
                        break
                except OSError:
                    continue
        if should_include_optional_artifacts(detected_layer, source_text):
            source_stem = Path(source_filename).stem
            result["test_access_impl_path"] = str(test_base / f"{source_stem}_test_access.c")
    if overwrite_inc_dir is not None:
        result['overwrite_inc_dir'] = overwrite_inc_dir

    logger.info(f"[PathGen] Final paths: test_impl='{result['test_impl_path']}', test_base='{result['test_base_dir']}'")
    return result


def save_test_files_to_project(
    test_content: dict[str, str],
    file_paths: dict[str, str],
    auto_create_dirs: bool = True,
    allow_stub: bool | None = None,
) -> dict[str, list]:
    """Save test files to project path.

    Args:
        test_content: Test file contents (test_impl / test_header / mock_impl / mock_header)
        file_paths: File paths dictionary (returned by generate_file_paths)
        auto_create_dirs: Whether to automatically create directories

    Returns:
        Save result {success, failed, created_dirs, skipped}
    """
    result: dict[str, list] = {
        'success': [],
        'failed': [],
        'created_dirs': [],
        'skipped': [],
    }

    if file_paths.get("layer") == "hal":
        allow_stub = False
    elif allow_stub is None:
        allow_stub = True

    if auto_create_dirs:
        dirs_to_create = ['test_base_dir', 'mock_base_dir']
        if allow_stub and (
            test_content.get("stub_impl") or test_content.get("stub_header")
        ) and file_paths.get("stub_base_dir"):
            dirs_to_create.append("stub_base_dir")
        if 'overwrite_inc_dir' in file_paths:
            dirs_to_create.append('overwrite_inc_dir')
        for dir_key in dirs_to_create:
            dir_path = Path(file_paths.get(dir_key, ''))
            if dir_path and not dir_path.exists():
                try:
                    dir_path.mkdir(parents=True, exist_ok=True)
                    result['created_dirs'].append(str(dir_path))
                except Exception as e:
                    logger.error(f"Failed to create directory {dir_path}: {e}")
                    result['failed'].append({'path': str(dir_path), 'error': f"Directory creation failed: {e}"})
                    return result

    files_to_save = [
        ('test_impl_path', 'test_impl', 'Test implementation'),
        ('test_header_path', 'test_header', 'Test header'),
        ('mock_impl_path', 'mock_impl', 'Mock implementation'),
        ('mock_header_path', 'mock_header', 'Mock header'),
    ]
    if allow_stub:
        stub_impl_path_key = (
            "test_access_impl_path"
            if file_paths.get("layer") == "app" and file_paths.get("test_access_impl_path")
            else "stub_impl_path"
        )
        stub_description = (
            "Test access translation unit"
            if stub_impl_path_key == "test_access_impl_path"
            else "Stub implementation"
        )
        files_to_save.extend([
            (stub_impl_path_key, "stub_impl", stub_description),
            ("stub_header_path", "stub_header", "Stub header"),
        ])

    test_impl_content = test_content.get('test_impl', '')
    if not test_impl_content:
        logger.error("Test implementation (.cpp) is empty or missing!")
        result['failed'].append({
            'path': file_paths.get('test_impl_path', 'unknown'),
            'type': 'Test implementation',
            'error': 'Test implementation (.cpp) was not generated.',
        })

    for path_key, content_key, description in files_to_save:
        content = test_content.get(content_key, '')
        if not content:
            result['skipped'].append({'file': path_key, 'reason': 'No content generated'})
            continue

        file_path_value = file_paths.get(path_key)
        if not file_path_value:
            result['skipped'].append({'file': path_key, 'reason': 'No output path available'})
            continue
        file_path = Path(file_path_value)
        try:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            # Skip write if file exists and content is identical (avoid redundant I/O)
            if file_path.exists():
                try:
                    existing = file_path.read_text(encoding='utf-8')
                    if existing == content:
                        result['skipped'].append({'file': path_key, 'reason': 'Content unchanged'})
                        continue
                except Exception:
                    pass  # If read fails, proceed with write
            with open(file_path, 'w', encoding='utf-8', newline='\n') as f:
                f.write(content)
            result['success'].append({'path': str(file_path), 'type': description, 'size': len(content)})
            logger.info(f"Saved {description}: {file_path}")
        except Exception as e:
            logger.error(f"Failed to save {description} to {file_path}: {e}")
            result['failed'].append({'path': str(file_path), 'type': description, 'error': str(e)})

    return result


def filter_mock_paths(file_paths: dict[str, str], enable_mock: bool) -> dict[str, str]:
    """Return an artifact manifest containing only the requested output kinds."""
    return {
        key: value for key, value in file_paths.items()
        if enable_mock or not key.startswith("mock_")
    }


def generate_header_templates(file_paths: dict[str, str], enable_mock: bool = True) -> dict[str, str]:
    """Generate test header and mock header template content based on file path info.

    Args:
        file_paths: Return value from generate_file_paths

    Returns:
        {"test_header": str, "mock_header": str}
    """
    module = file_paths.get("module_name", "unknown")
    layer = file_paths.get("layer", "hal")
    test_file = file_paths.get("test_file", "")
    mock_header_name = file_paths.get("mock_header", "")

    # test header: include guard + gtest + mock header include
    test_guard = test_file.replace("-", "").replace(".", "_").upper()
    test_header = (
        f"#ifndef {test_guard}\n"
        f"#define {test_guard}\n"
        f"#include <gtest/gtest.h>\n"
        f"#include <gmock/gmock.h>\n"
        + (f'#include "{mock_header_name}"\n' if enable_mock and mock_header_name else "")
        + f'#include "{layer}-{module}.h"\n'
        f"\n"
        f"using namespace testing;\n"
        f"\n"
        f"#endif\n"
    )

    # mock header: include guard + gmock MOCK_METHOD class
    mock_guard = mock_header_name.replace("-", "_").replace(".", "_").upper()
    mock_class_name = f"Mock{module.capitalize()}{layer.upper()}"

    mock_header = (
        f"#ifndef {mock_guard}\n"
        f"#define {mock_guard}\n"
        f"\n"
        f"#include <gmock/gmock.h>\n"
        f'#include "{layer}-{module}.h"\n'
        f"\n"
        f"/**\n"
        f" * @brief Mock class for {layer}-{module} external dependencies.\n"
        f" *\n"
        f" * Add MOCK_METHOD declarations for functions that your tests need to mock.\n"
        f" * Example:\n"
        f" *   MOCK_METHOD(int, HAL_Init, (), (override));\n"
        f" *   MOCK_METHOD(HAL_StatusTypeDef, HAL_GPIO_ReadPin, \n"
        f" *               (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin), (override));\n"
        f" */\n"
        f"class {mock_class_name} {{\n"
        f"public:\n"
        f"    virtual ~{mock_class_name}() = default;\n"
        f"\n"
        f"    // Add your MOCK_METHOD declarations here\n"
        f"    // MOCK_METHOD(return_type, function_name, (param_types), (override));\n"
        f"}};\n"
        f"\n"
        f"#endif\n"
    )

    return {"test_header": test_header, "mock_header": mock_header if enable_mock else ""}


# ========== Header file search and context collection ==========

def find_and_read_header_file(
    source_filename: str,
    project_root: str,
    detected_layer: str,
) -> str:
    """Find and read header file content corresponding to the source file.

    Args:
        source_filename: Source filename (e.g. hal-pwr.c)
        project_root: Project root directory
        detected_layer: Detected layer

    Returns:
        Header file content, empty string if not found. Content over 10KB is automatically truncated.
    """
    base_name = Path(source_filename).stem
    header_name = f"{base_name}.h"

    search_paths: list[str] = []

    if detected_layer == 'hal':
        search_paths.extend([
            f"libs/platformkit/bsp/hal/inc/{header_name}",
            f"libs/platformkit/bsp/hal/{header_name}",
            f"bsp/hal/inc/{header_name}",
            f"bsp/hal/{header_name}",
        ])
    elif detected_layer == 'driver':
        search_paths.extend([
            f"libs/platformkit/driver/inc/{header_name}",
            f"libs/platformkit/driver/{header_name}",
            f"libs/drivers/inc/{header_name}",
            f"drivers/inc/{header_name}",
        ])
    elif detected_layer == 'midware_controller':
        search_paths.extend([
            f"libs/platformkit/midware/controllers/{base_name}/inc/{header_name}",
            f"libs/platformkit/midware/controllers/inc/{header_name}",
            f"midware/controllers/{base_name}/inc/{header_name}",
            f"midware/controllers/inc/{header_name}",
            f"midware/{base_name}/inc/{header_name}",
            f"midware/inc/{header_name}",
        ])
    elif detected_layer == 'midware_driver':
        search_paths.extend([
            f"libs/platformkit/midware/drivers/{base_name}/inc/{header_name}",
            f"libs/platformkit/midware/drivers/inc/{header_name}",
            f"midware/drivers/{base_name}/inc/{header_name}",
            f"midware/drivers/inc/{header_name}",
        ])
    elif detected_layer == 'app':
        search_paths.extend([
            f"apps/{base_name}/inc/{header_name}",
            f"apps/{base_name}/include/{header_name}",
            f"apps/inc/{header_name}",
            f"apps/{header_name}",
        ])

    search_paths.extend([
        f"inc/{header_name}",
        f"include/{header_name}",
        f"libs/platformkit/inc/{header_name}",
    ])

    # Search same directory
    source_path = Path(source_filename)
    if source_path.parent != Path('.'):
        search_paths.insert(0, str(source_path.parent / header_name))
        search_paths.insert(1, str(source_path.parent / "inc" / header_name))
        search_paths.insert(2, str(source_path.parent.parent / "inc" / header_name))
        search_paths.insert(3, str(source_path.parent.parent / "include" / header_name))

    project_path = Path(project_root)
    for rel_path in search_paths:
        header_path = project_path / rel_path
        if header_path.exists():
            try:
                content = header_path.read_text(encoding='utf-8', errors='ignore')
                logger.info(f"Found header file: {header_path}")
                if len(content) > 10000:
                    content = content[:10000] + "\n/* ... (content truncated) ... */"
                return content
            except Exception as e:
                logger.warning(f"Failed to read header file {header_path}: {e}")

    # Recursive search fallback
    try:
        for root, dirs, files in os.walk(project_root):
            # Generated mocks and abandoned CLI worktrees are not source truth.
            excluded = {
                '.git', '.claude', '.codex', '.worktrees', 'node_modules',
                'build', 'debug', 'release', 'default', 'output', 'outputdata',
                '__pycache__', 'tests', 'mocks', 'overwrite-inc',
            }
            dirs[:] = sorted(d for d in dirs if d.lower() not in excluded)
            if header_name in files:
                header_path = Path(root) / header_name
                try:
                    content = header_path.read_text(encoding='utf-8', errors='ignore')
                    logger.info(f"Found header file via recursive search: {header_path}")
                    if len(content) > 10000:
                        content = content[:10000] + "\n/* ... (content truncated) ... */"
                    return content
                except OSError as exc:
                    logger.warning(f"Failed to read candidate header {header_path}: {exc}")
    except Exception as e:
        logger.warning(f"Recursive search failed: {e}")

    logger.debug(f"Header file '{header_name}' not found for source '{source_filename}'")
    return ""


def _extract_typedef_structures(header_content: str) -> str:
    """Extract typedef struct and typedef enum definitions from header content."""
    relevant: list[str] = []

    struct_pat = re.compile(
        r'(typedef\s+struct\s+\w*\s*\{[^}]+\}[^;]*;)',
        re.DOTALL | re.MULTILINE,
    )
    for struct in struct_pat.findall(header_content):
        if re.search(r'\}\s*(?:const\s+)?\w+_t\s*;', struct):
            relevant.append(re.sub(r'\n\s*\n', '\n', struct.strip()))

    enum_pat = re.compile(
        r'(typedef\s+enum\s*\{[^}]+\}[^;]*;)',
        re.DOTALL | re.MULTILINE,
    )
    for enum in enum_pat.findall(header_content):
        if re.search(r'\}\s*\w+_t\s*;', enum):
            relevant.append(re.sub(r'\n\s*\n', '\n', enum.strip()))

    return "\n\n".join(relevant)


def find_dependent_hal_headers(
    main_header_content: str,
    project_root: str,
    detected_layer: str,
) -> str:
    """Parse #include directives in header, read dependent HAL header typedef struct/enum definitions.

    Args:
        main_header_content: Main header content
        project_root: Project root directory
        detected_layer: Detected layer

    Returns:
        Formatted string containing dependent header structure definitions
    """
    if not main_header_content or detected_layer not in [
        'hal', 'driver', 'midware_controller', 'midware_driver',
    ]:
        return ""

    include_pat = re.compile(
        r'#include\s+[<"](?:\.*/)?(?:hal[_-](\w+)\.h)[">]',
        re.IGNORECASE,
    )
    included_modules = [
        m.group(1).lower()
        for m in include_pat.finditer(main_header_content)
        if m.group(1)
    ]
    if not included_modules:
        return ""

    logger.info(f"Found dependent HAL modules in includes: {included_modules}")

    project_path = Path(project_root)
    search_dirs = [
        "libs/platformkit/bsp/hal/inc",
        "bsp/hal/inc",
        "libs/platformkit/bsp/hal",
    ]

    dependent_headers: list[dict] = []
    for module in included_modules[:5]:
        header_name = f"hal-{module}.h"
        for search_path in search_dirs:
            header_path = project_path / search_path / header_name
            if header_path.exists():
                try:
                    content = header_path.read_text(encoding='utf-8', errors='ignore')
                    struct_content = _extract_typedef_structures(content)
                    if struct_content:
                        dependent_headers.append({
                            'module': module,
                            'file': header_name,
                            'structures': struct_content,
                        })
                    break
                except Exception as e:
                    logger.debug(f"Failed to read {header_path}: {e}")

    if not dependent_headers:
        return ""

    lines = [
        "",
        "## Dependent HAL Header Structure Definitions",
        "",
        "**CRITICAL: When mocking structures from these dependent headers, "
        "you MUST use the EXACT member names defined below!**",
        "",
    ]
    for hdr in dependent_headers:
        lines.append(f"### {hdr['file']} (hal_{hdr['module']}_t structure)")
        lines.append("```c")
        lines.append(hdr['structures'])
        lines.append("```")
        lines.append("")

    return "\n".join(lines)


def find_vendor_hal_api_definitions(
    project_root: str,
    detected_layer: str,
    module_name: str,
    platform: str,
) -> str:
    """Find and extract vendor HAL API function signature definitions.

    Used to provide correct API signature references during retry after compilation failure.

    Returns:
        Formatted string containing API signature definitions, empty string if not found.
    """
    if detected_layer not in ["hal", "driver", "midware_controller", "midware_driver"]:
        return ""

    project_path = Path(project_root)
    platform_lower = platform.lower()

    if 'stm32' in platform_lower:
        header_patterns = [
            f"**/stm32*_hal_{module_name}.h",
            f"**/stm32*_hal_{module_name}_ex.h",
        ]
        func_prefix = "HAL_"
    elif 'rtl' in platform_lower:
        header_patterns = [f"**/*rtl*_{module_name}*.h", f"**/hal_{module_name}*.h"]
        func_prefix = ""
    elif 'nrf' in platform_lower:
        header_patterns = [f"**/nrf*_{module_name}*.h", f"**/nrfx_{module_name}*.h"]
        func_prefix = "nrf"
    else:
        header_patterns = [f"**/*hal*{module_name}*.h"]
        func_prefix = ""

    # Search SDK directories
    sdk_dirs: list[str] = []
    for root, dirs, _files in os.walk(project_root):
        rel_path = os.path.relpath(root, project_root)
        if rel_path.count(os.sep) > 5:
            dirs[:] = []
            continue
        dirs[:] = [d for d in dirs if d not in [
            '.git', 'build', 'output', 'outputdata', '__pycache__',
            'tests', 'test', 'node_modules', 'cache',
        ]]
        dir_lower = os.path.basename(root).lower()
        if any(kw in dir_lower for kw in ['sdk', 'vendor', 'drivers', 'hal', 'cmsis']):
            sdk_dirs.append(root)

    found_headers: list[Path] = []
    for sdk_dir in sdk_dirs:
        for pattern in header_patterns:
            try:
                for hp in Path(sdk_dir).glob(pattern):
                    if hp.is_file() and hp not in found_headers:
                        found_headers.append(hp)
            except Exception:
                continue

    api_definitions: list[str] = []
    module_upper = module_name.upper()
    for header_path in found_headers[:5]:
        try:
            content = header_path.read_text(encoding='utf-8', errors='ignore')
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('#define') or line.endswith('\\'):
                    continue
                if '__HAL_' in line:
                    continue
                if (func_prefix and func_prefix in line
                        and module_upper in line.upper()
                        and '(' in line and ');' in line
                        and not line.startswith('/') and not line.startswith('*')):
                    clean = re.sub(r'\s+', ' ', line).strip()
                    if len(clean) < 200:
                        api_definitions.append(clean)
        except Exception as e:
            logger.debug(f"Failed to parse header {header_path}: {e}")

    api_definitions = list(dict.fromkeys(api_definitions))[:25]

    if not api_definitions:
        return ""

    header_names = [h.name for h in found_headers[:3]]
    logger.info(f"Found {len(api_definitions)} API definitions from: {', '.join(header_names)}")
    return (
        "\n## Vendor HAL API Reference (Official Signatures)\n\n"
        "**CRITICAL: Use EXACTLY these function signatures for your mock implementations.**\n"
        "**Do NOT guess parameter types - use the exact types shown below.**\n\n"
        f"Source files: {', '.join(header_names)}\n\n"
        f"```c\n{chr(10).join(api_definitions)}\n```\n"
    )


def find_existing_mock_files(
    project_root: str,
    platform: str,
    module_name: Optional[str] = None,
    layer: str = "",
) -> str:
    """Scan existing mock files and extract MOCK_METHOD declarations.

    Returns:
        Formatted mock file reference string
    """
    project_path = Path(project_root)
    platform_lower = platform.lower()

    mock_patterns = [
        f"**/tests/mocks/{platform_lower}/platform-mocks/inc/mock-*.h",
        "**/tests/mocks/inc/mock-*.h",
        f"**/mocks/{platform_lower}/**/mock-*.h",
        f"**/platform-mocks/inc/mock-*.h",
        "**/tests/app/mocks/inc/mock-*.h",
        "**/tests/mocks/midware/controllers/mock-*.h",
        "**/tests/mocks/midware/drivers/mock-*.h",
        "**/tests/mocks/managers/**/mock-*.h",
        "**/tests/mocks/apps/**/mock-*.h",
        "**/tests/mocks/bsp/**/mock-*.h",
        "**/tests/mocks/midware/**/mock-*.h",
        "**/tests/mocks/**/mock-*.h",
    ]
    if 'stm32' in platform_lower:
        mock_patterns.append("**/tests/mocks/stm32*/platform-mocks/inc/mock-*.h")
    # stm32u5 shares mock structure with stm32u3: always include u3 mocks as reference
    if platform_lower == 'stm32u5':
        mock_patterns.insert(0, "**/tests/mocks/stm32u3/platform-mocks/inc/mock-*.h")

    found: list[Path] = []
    for pattern in mock_patterns:
        try:
            for mp in project_path.glob(pattern):
                if layer == "app" and _is_app_forbidden_libs_path(str(mp)):
                    continue
                if mp.is_file() and mp not in found:
                    found.append(mp)
        except Exception:
            continue

    if not found:
        return ""

    mock_info: list[dict] = []
    for mock_path in found[:15]:
        try:
            content = mock_path.read_text(encoding='utf-8', errors='ignore')
            class_match = re.search(r'class\s+(\w+)\s*[:{]', content)
            class_name = class_match.group(1) if class_match else "Unknown"
            mock_methods = re.findall(
                r'MOCK_METHOD\s*\(\s*(\w+)\s*,\s*(\w+)\s*,\s*\([^)]*\)',
                content,
            )
            extern_match = re.search(
                r'extern\s+(?:::testing::)?(?:Strict|Nice)?Mock<(\w+)>\s+(\w+);',
                content,
            )
            mock_instance = extern_match.group(2) if extern_match else ""
            if mock_methods:
                mock_info.append({
                    'file': mock_path.name,
                    'class': class_name,
                    'instance': mock_instance,
                    'methods': [f"  - {ret} {name}(...)" for ret, name in mock_methods],
                })
        except Exception:
            continue

    if not mock_info:
        return ""

    lines = [
        "\n## Existing Mock Files Reference\n",
        "**CRITICAL: Use existing mock classes and methods listed below.**",
        "**DO NOT create new mock classes for functions that are already mocked!**\n",
    ]
    for mock in mock_info:
        lines.append(f"### {mock['file']}")
        lines.append(f"- **Mock Class**: `{mock['class']}`")
        if mock['instance']:
            lines.append(f"- **Mock Instance**: `{mock['instance']}`")
        lines.append("- **Available Methods**:")
        for method in mock['methods'][:10]:
            lines.append(f"  {method}")
        if len(mock['methods']) > 10:
            lines.append(f"  ... and {len(mock['methods']) - 10} more")
        lines.append("")

    total_methods = sum(len(m['methods']) for m in mock_info)
    logger.info(f"Found {len(mock_info)} existing mock files with {total_methods} methods")
    return "\n".join(lines)


# ========== Phase 2: Project membership detection ==========

# Markers that indicate a directory is a project root.
_PROJECT_ROOT_MARKERS = (
    '.git',
    '.gitmodules',
    'CMakeLists.txt',
    'Makefile',
    'compile_commands.json',
    'projects/test/qbs',
    # NOTE: 'tests/unit' and 'tests/mocks' removed — they are generated artifacts
    # that can appear inside sub-directories (e.g. apps/non-secure/adc/src/tests/unit),
    # causing false-positive project root detection.
    'libs/platformkit',
)

_APPS_LIBS_ROOT_MARKER = "apps+libs"


def _find_project_root_markers(candidate: Path) -> list[str]:
    """Return repository markers, including the apps-plus-libs layout."""
    markers = [marker for marker in _PROJECT_ROOT_MARKERS if (candidate / marker).exists()]
    if (candidate / "apps").is_dir() and (candidate / "libs").is_dir():
        markers.append(_APPS_LIBS_ROOT_MARKER)
    return markers


def is_platformkit_subrepo(project_root: str, source_path: Optional[str] = None) -> bool:
    """Determine whether project_root is a platformkit sub-repo root (scenario 1).

    Detection strategy (in priority order):
    1. If project_root path itself contains 'libs/platformkit', it IS the sub-repo root
       (the caller already resolved to that sub-directory) → scenario 1.
    2. If source_path (absolute source file path) contains 'libs/platformkit', the source
       lives inside platformkit → project_root is the full project root (scenario 2).
    3. If the directory contains a libs/platformkit/ sub-directory → full project root
       (scenario 2) — return False.
    4. Fallback: check for bsp/ and tests/ at the top level → scenario 1.

    Args:
        project_root: Directory path to check.
        source_path: Optional absolute path to the source file being processed.
                     When provided, used as the primary signal for scenario detection,
                     avoiding filesystem access entirely.

    Returns:
        True if it is a platformkit sub-repo root, False if it is a project root or other directory.
    """
    p = Path(project_root)
    path_str = str(p).replace("\\", "/").lower()

    # Priority 1: project_root path itself contains libs/platformkit → IS the sub-repo root.
    # This must be checked BEFORE source_path to avoid false negatives when both contain libs/platformkit.
    if "libs/platformkit" in path_str:
        return True

    # Priority 2: source_path contains libs/platformkit → source is inside platformkit,
    # so project_root is the full project root (scenario 2), not the sub-repo root.
    if source_path:
        src_str = str(source_path).replace("\\", "/").lower()
        if "libs/platformkit" in src_str:
            return False

    # Priority 3: directory contains libs/platformkit/ sub-directory → full project root (scenario 2).
    if (p / "libs" / "platformkit").is_dir():
        return False

    # A repository-level application QBS project is authoritative evidence
    # that this is the full firmware root. Some products keep bsp/ and tests/
    # at the root without vendoring platformkit, so the fallback below would
    # otherwise misclassify them as a platformkit sub-repository.
    if (p / "projects" / "test" / "qbs").is_dir():
        return False

    # Fallback: bsp/ + tests/ present → treat as sub-repo root.
    return (p / "bsp").is_dir() and (p / "tests").is_dir()


def find_project_root_for_source(source_path: str) -> Optional[str]:
    """Walk up from source_path looking for a project root marker.

    Args:
        source_path: Absolute (or relative) path to the source file.

    Returns:
        The detected project root directory, or None if not found.
    """
    p = Path(source_path).resolve()
    # Start from the file's directory and walk up.
    candidate = p.parent if p.is_file() else p
    prev = None
    while candidate != prev:
        # Uploaded inputs belong to the chosen task workspace. Never discover
        # an enclosing application repository above this snapshot boundary.
        if candidate.name == ".unittest-inputs":
            return str(candidate.parent)
        if (candidate / ".unittest-upload.json").is_file():
            return str(candidate)
        markers = _find_project_root_markers(candidate)
        if markers:
            logger.info(
                f"[ProjectRoot] Detected root '{candidate}' via marker(s) {markers}"
            )
            return str(candidate)
        prev = candidate
        candidate = candidate.parent
    return None


def detect_project_membership(
    source_path: str,
    current_project_root: Optional[str] = None,
) -> dict:
    """Determine whether source_path belongs to the current project, an external
    project, or is a standalone file.

    Args:
        source_path: Absolute path to the source file.
        current_project_root: The backend's own project root (optional).

    Returns:
        {
            "status": "in_current_project" | "in_external_project" | "standalone_file",
            "detected_root": str | None,
            "markers": list[str],
        }
    """
    p = Path(source_path).resolve()

    # 1. Check if the file is inside the current project root.
    if current_project_root:
        try:
            p.relative_to(Path(current_project_root).resolve())
            return {
                "status": "in_current_project",
                "detected_root": str(current_project_root),
                "markers": [],
            }
        except ValueError:
            pass  # Not inside current project root.

    # 2. Walk up to find an external project root.
    candidate = p.parent if p.is_file() else p
    prev = None
    while candidate != prev:
        found_markers = _find_project_root_markers(candidate)
        if found_markers:
            # At least one marker found at this level — accept it.
            logger.info(
                f"[Membership] External project root '{candidate}' "
                f"via markers {found_markers}"
            )
            return {
                "status": "in_external_project",
                "detected_root": str(candidate),
                "markers": found_markers,
            }
        prev = candidate
        candidate = candidate.parent

    # 3. No project root found → standalone file.
    logger.info(f"[Membership] Standalone file: {source_path}")
    return {
        "status": "standalone_file",
        "detected_root": str(p.parent) if p.is_file() else str(p),
        "markers": [],
    }
