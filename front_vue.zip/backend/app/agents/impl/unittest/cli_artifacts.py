"""Preserve CLI edits for authoritative build and coverage verification."""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from typing import Any

from app.utils.claude_cli_monitor import is_cli_cancelled, is_task_cancelled


ARTIFACT_FIELDS = (
    ("test_impl_path", "test_content"),
    ("test_header_path", "test_header_content"),
    ("mock_impl_path", "mock_content"),
    ("mock_header_path", "mock_header_content"),
    ("stub_impl_path", "stub_content"),
    ("test_access_impl_path", "stub_content"),
    ("stub_header_path", "stub_header_content"),
)


def snapshot_cli_artifacts(file_paths: dict[str, Any]) -> dict[str, str | None]:
    """Hash generated files, including absent artifacts that a turn may create."""
    snapshot = {}
    for path_key, _ in ARTIFACT_FIELDS:
        file_path = file_paths.get(path_key)
        if not file_path:
            continue
        try:
            snapshot[path_key] = hashlib.sha256(Path(file_path).read_bytes()).hexdigest()
        except FileNotFoundError:
            snapshot[path_key] = None
    return snapshot


def reload_cli_artifacts(
    test: Any, file_paths: dict[str, Any], before: dict[str, str | None],
) -> bool:
    """Reload all generated artifacts and report content changes, never build success."""
    after = snapshot_cli_artifacts(file_paths)
    for path_key, content_field in ARTIFACT_FIELDS:
        if after.get(path_key) is not None:
            setattr(test, content_field, Path(file_paths[path_key]).read_text(encoding="utf-8"))
        elif before.get(path_key) is not None:
            # Do not restore a deleted artifact from stale in-memory content.
            setattr(test, content_field, "")
    return after != before


def raise_if_cli_cancelled(result: dict[str, Any], task_id: str | None) -> None:
    """Cancellation must not be interpreted as a request for another repair turn."""
    if result.get("failure_category") == "cancelled" or (
        task_id and (is_cli_cancelled(task_id) or is_task_cancelled(task_id))
    ):
        raise asyncio.CancelledError("UnitTest CLI task was cancelled")
