"""
@file fixers.py
@author caoshwen
@brief Deterministic C/C++ test code fix engine.

Provides a set of independent functions for automatically fixing common
syntax errors, include path errors and compilation errors in LLM-generated
C/C++ unit test code.

@version 3.2
@date 2026-03-10

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import re
from typing import Any, Dict, List, Tuple

from loguru import logger


# ========== 1. C/C++ Syntax Fixes ==========

def fix_cpp_syntax_errors(parsed_content: Dict[str, str]) -> Dict[str, str]:
    """
    Fix common C/C++ syntax errors in AI-generated code.

    Applies 13+ regex-based rules to each file in parsed_content:
      1. Stray '/' at file start
      1b. Missing '/*' in comments
      2. Empty Doxygen blocks
      3. Empty '/**\\n\\n' patterns
      4. Standalone '/' / '/*' / '/**' lines
      5. '#endif / GUARD /' format
      5b. '} / extern "C" /' closing
      6. Missing #endif for header guards
      7. Nested block comments
      8. Unterminated block comments
      9. Multiple empty lines collapse
      10. Line endings normalization
      11. SysTick pointer mismatch (mock_impl)
      12. reinterpret_cast to non-pointer type
      13. extern "C" declarations inside function body (test_impl)

    Args:
        parsed_content: Dict with keys test_impl, test_header, mock_impl, mock_header.

    Returns:
        Dict with fixed content.
    """
    logger.info("Fixing C/C++ syntax errors in generated code...")

    result = parsed_content.copy()

    for file_key in ['test_impl', 'test_header', 'mock_impl', 'mock_header']:
        content = result.get(file_key, '')
        if not content:
            continue

        original_len = len(content)
        fixes_applied: List[str] = []

        # === Fix 1: Remove stray "/" at file start ===
        if content.strip().startswith('/\n') or content.strip().startswith('/ \n'):
            content = re.sub(r'^\s*/\s*\n', '', content)
            fixes_applied.append("removed stray / at start")

        # === Fix 1b: Fix "/ comment */" pattern (missing leading *) ===
        content = re.sub(
            r'^(\s*)/\s+([^*\n][^\n]*\*/)\s*$',
            r'\1/* \2',
            content,
            flags=re.MULTILINE,
        )
        content = re.sub(
            r'(?<!\*)\s*/\s+([A-Za-z][^*/\n]*\*/)',
            r' /* \1',
            content,
        )
        if '/ ' in content and '*/' in content:
            broken_pattern = re.search(r'(?<!\*)/ [A-Za-z].*\*/', content)
            if broken_pattern:
                fixes_applied.append("fixed missing /* in comments")

        # === Fix 2: Fix incomplete Doxygen comments ===
        def _fix_empty_doxygen(match: re.Match) -> str:  # noqa: ARG001
            return "/** @brief Auto-generated. */\n"

        content = re.sub(
            r'/\*\*\s*\n(?!\s*\*)(?=\s*(?:class |extern |void |int |MOCK_METHOD|#|using |namespace |\w+\s+\w+\())',
            _fix_empty_doxygen,
            content,
        )

        # === Fix 3: Fix "/**\n\n" patterns (empty doxygen blocks) ===
        content = re.sub(r'/\*\*\s*\n(?!\s*\*)\s*\n', '/** @brief Auto-generated. */\n', content)

        # === Fix 4: Fix standalone "/" lines (truncated comments) ===
        content = _fix_standalone_comment_markers(content, fixes_applied)

        # === Fix 5: Fix "#endif / GUARD /" pattern ===
        content = re.sub(
            r'#endif\s*/\s*([A-Z_0-9]+)\s*/\s*$',
            r'#endif // \1',
            content,
            flags=re.MULTILINE,
        )
        content = re.sub(r'#endif\s+/([A-Z_0-9]+)/', r'#endif // \1', content)

        # === Fix 5b: Fix "} / extern "C" /" pattern ===
        content = re.sub(
            r'\}\s*/\s*extern\s*"C"\s*/\s*$',
            '#ifdef __cplusplus\n}\n#endif',
            content,
            flags=re.MULTILINE,
        )
        content = re.sub(
            r'\}\s*/\s*extern\s*"C"\s*/\s*\n',
            '#ifdef __cplusplus\n}\n#endif\n',
            content,
        )
        content = re.sub(
            r'\}\s*/\s*extern\s*"C"\s*/\s*\n\s*(#endif)',
            r'#ifdef __cplusplus\n}\n#endif\n\n\1',
            content,
        )
        if '} / extern' in content or '}/extern' in content:
            fixes_applied.append("fixed broken extern C closing")

        # === Fix 6: Ensure header files have #endif ===
        if file_key in ['test_header', 'mock_header']:
            has_ifndef = '#ifndef' in content or '#pragma once' in content
            has_endif = '#endif' in content
            if has_ifndef and not has_endif:
                guard_match = re.search(r'#ifndef\s+(\w+)', content)
                guard_name = guard_match.group(1) if guard_match else 'HEADER_H'
                content = content.rstrip() + f'\n\n#endif // {guard_name}\n'
                fixes_applied.append(f"added missing #endif for {guard_name}")

        # === Fix 7: Fix nested comment warnings ===
        content = _fix_nested_block_comments(content, fixes_applied)

        # === Fix 8: Fix unterminated block comments ===
        open_comments = len(re.findall(r'/\*', content))
        close_comments = len(re.findall(r'\*/', content))
        if open_comments > close_comments:
            missing = open_comments - close_comments
            for _ in range(missing):
                content = content.rstrip() + '\n */'
                fixes_applied.append("added missing */")

        # === Fix 9: Clean up multiple empty lines ===
        content = re.sub(r'\n{4,}', '\n\n\n', content)

        # === Fix 10: Ensure proper line endings ===
        content = content.replace('\r\n', '\n').replace('\r', '\n')

        # === Fix 11: Fix SysTick pointer mismatch in mock files ===
        if file_key == 'mock_impl':
            content = _fix_systick_pointer(content, fixes_applied)

        # === Fix 12: Fix invalid reinterpret_cast to non-pointer type ===
        content = re.sub(
            r'reinterpret_cast<(\w+_Type)>\s*\(\s*&(\w+)\s*\)',
            r'reinterpret_cast<\1*>(&\2)',
            content,
        )

        # === Fix 13: Fix extern "C" declarations inside function body ===
        if file_key == 'test_impl':
            content = _move_extern_c_declarations(content, fixes_applied)

        if fixes_applied:
            logger.info(f"   {file_key}: {len(fixes_applied)} fixes applied")
            for fix in fixes_applied[:5]:
                logger.debug(f"      - {fix}")
            if len(fixes_applied) > 5:
                logger.debug(f"      - ... and {len(fixes_applied) - 5} more")

        result[file_key] = content.strip()

    return result


# ---------- internal helpers for fix_cpp_syntax_errors ----------

def _fix_standalone_comment_markers(content: str, fixes_applied: List[str]) -> str:
    """Fix standalone '/', '/*', '/**' lines that are broken comment markers."""
    lines = content.split('\n')
    fixed_lines: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped == '/':
            if i + 1 < len(lines):
                next_stripped = lines[i + 1].strip()
                if next_stripped and not next_stripped.startswith('*'):
                    fixed_lines.append('/** @brief Auto-generated. */')
                    fixes_applied.append(f"fixed broken / at line {i + 1}")
                else:
                    fixed_lines.append(line)
            else:
                fixed_lines.append(line)
        elif stripped == '/*':
            if i + 1 < len(lines):
                next_stripped = lines[i + 1].strip()
                if next_stripped and not next_stripped.startswith('*') and next_stripped != '*/':
                    fixed_lines.append('/** @brief Auto-generated. */')
                    fixes_applied.append(f"fixed broken /* at line {i + 1}")
                else:
                    fixed_lines.append(line)
            else:
                fixed_lines.append(line)
        elif stripped == '/**':
            if i + 1 < len(lines):
                next_stripped = lines[i + 1].strip()
                if next_stripped.startswith('*') or next_stripped == '*/':
                    fixed_lines.append(line)
                elif next_stripped == '':
                    fixed_lines.append(line)
                else:
                    fixed_lines.append('/** @brief Auto-generated. */')
                    fixes_applied.append(f"fixed broken /** at line {i + 1}")
            else:
                fixed_lines.append(line)
        else:
            fixed_lines.append(line)
        i += 1

    return '\n'.join(fixed_lines)


def _fix_nested_block_comments(content: str, fixes_applied: List[str]) -> str:
    """Remove nested ``/*`` inside existing block comments."""
    in_block_comment = False
    char_list = list(content)
    i = 0
    while i < len(char_list) - 1:
        if not in_block_comment:
            if char_list[i] == '/' and char_list[i + 1] == '*':
                in_block_comment = True
                i += 2
                continue
        else:
            if char_list[i] == '*' and char_list[i + 1] == '/':
                in_block_comment = False
                i += 2
                continue
            if char_list[i] == '/' and char_list[i + 1] == '*':
                char_list[i] = ' '
                char_list[i + 1] = ' '
                fixes_applied.append(f"removed nested /* at position {i}")
        i += 1
    return ''.join(char_list)


def _fix_systick_pointer(content: str, fixes_applied: List[str]) -> str:
    """Fix SysTick pointer type mismatches in mock implementation files."""
    # Type SysTick = reinterpret_cast<Type>(&x) -> Type *SysTick = reinterpret_cast<Type*>(&x)
    pat1 = r'(\w+_Type)\s+SysTick\s*=\s*reinterpret_cast<(\w+_Type)>\s*\(\s*&(\w+)\s*\)\s*;'
    if re.search(pat1, content):
        content = re.sub(pat1, r'\1 *SysTick = reinterpret_cast<\2*>(&\3);', content)
        fixes_applied.append("fixed SysTick pointer type mismatch")

    # Type SysTick = &x -> Type *SysTick = reinterpret_cast<Type*>(&x)
    pat2 = r'(\w+_Type)\s+SysTick\s*=\s*&(\w+)\s*;'
    if re.search(pat2, content) and '*SysTick' not in content:
        content = re.sub(pat2, r'\1 *SysTick = reinterpret_cast<\1*>(&\2);', content)
        fixes_applied.append("fixed SysTick missing pointer and cast")

    # Type *SysTick = &x -> add reinterpret_cast when missing
    pat3 = r'(\w+_Type)\s*\*\s*SysTick\s*=\s*&(mock_\w+)\s*;'
    if re.search(pat3, content) and 'reinterpret_cast' not in content:
        content = re.sub(pat3, r'\1 *SysTick = reinterpret_cast<\1*>(&\2);', content)
        fixes_applied.append("added reinterpret_cast for SysTick")

    return content


def _move_extern_c_declarations(content: str, fixes_applied: List[str]) -> str:
    """Move ``extern "C"`` declarations from inside function bodies to file top."""
    extern_c_pattern = r'(\s+)(extern\s+"C"\s+void\s+(\w+IRQHandler|HAL_\w+Callback)\s*\([^)]*\)\s*;)'
    extern_c_matches = re.findall(extern_c_pattern, content)
    if not extern_c_matches:
        return content

    declarations_to_move: List[str] = []
    for indent, full_decl, func_name in extern_c_matches:
        declarations_to_move.append(full_decl.strip())
        fixes_applied.append(f"moved extern C declaration for {func_name} to file top")

    # Remove from function bodies
    content = re.sub(extern_c_pattern, '', content)

    # Find insertion position after last #include or extern "C" block
    lines = content.split('\n')
    insert_pos = 0
    in_extern_c_block = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('#include'):
            insert_pos = i + 1
        elif 'extern "C"' in stripped and '{' in stripped:
            in_extern_c_block = True
        elif in_extern_c_block and '}' in stripped:
            in_extern_c_block = False
            insert_pos = i + 1
        elif stripped.startswith('using ::testing::'):
            insert_pos = i + 1

    # Build declaration block
    decl_block = '\n/** IRQ handler and callback declarations for testing. */\nextern "C" {\n'
    for decl in set(declarations_to_move):
        clean_decl = re.sub(r'extern\s+"C"\s+', '', decl)
        decl_block += f'    {clean_decl}\n'
    decl_block += '}\n'

    lines.insert(insert_pos, decl_block)
    return '\n'.join(lines)


# ========== 2. Mock Header Include Fixes ==========

def fix_mock_header_includes(
    parsed_content: Dict[str, str],
    file_paths: Dict[str, str],
) -> Dict[str, str]:
    """
    Fix ``#include`` statements to match actual generated filenames.

    LLM may generate incorrect include paths such as ``mock-hal-xxx.h``
    instead of ``mock-stm32-hal-xxx.h``.  This function normalizes them
    based on *file_paths* (output of ``generate_file_paths``).

    Also calls :func:`_fix_const_mismatch_in_mocks` to correct const
    qualifier mismatches in mock signatures.

    Args:
        parsed_content: Dict with test_impl, test_header, mock_impl, mock_header.
        file_paths: Dict with actual filenames (mock_header, test_header, module_name …).

    Returns:
        Updated parsed_content with fixed include statements.
    """
    actual_mock_header = file_paths.get('mock_header', '')
    actual_test_header = file_paths.get('test_header', '')
    module_name = file_paths.get('module_name', '')

    if not module_name:
        for header in [actual_mock_header, actual_test_header]:
            match = re.search(
                r'(?:mock-(?:stm32-)?(?:hal|driver)-|tc-(?:hal|driver)-)(\w+)\.h', header,
            )
            if match:
                module_name = match.group(1)
                break

    if not module_name:
        return parsed_content

    result = parsed_content.copy()

    # Build replacement map for incorrect patterns
    replacements: Dict[str, str] = {}

    if actual_mock_header:
        mock_patterns = [
            f'mock-hal-{module_name}.h',
            f'mock-driver-{module_name}.h',
            f'mock_{module_name}.h',
            f'mock_hal_{module_name}.h',
            f'Mock{module_name.title()}.h',
            f'mock{module_name}.h',
            f'mock-{module_name}.h',
            f'mock-pwr.h',
        ]
        for pattern in mock_patterns:
            if pattern != actual_mock_header:
                replacements[pattern] = actual_mock_header

    if actual_test_header:
        test_patterns = [
            f'tc-driver-{module_name}.h',
            f'tc-hal-{module_name}.h',
            f'test_{module_name}.h',
            f'test-{module_name}.h',
            f'{module_name}_test.h',
        ]
        for pattern in test_patterns:
            if pattern != actual_test_header:
                replacements[pattern] = actual_test_header
    # Apply replacements to all content sections
    for content_key in ['test_impl', 'test_header', 'mock_impl', 'mock_header']:
        content = result.get(content_key, '')
        if not content:
            continue

        modified = False
        for incorrect, correct in replacements.items():
            if incorrect in content:
                content = content.replace(f'#include "{incorrect}"', f'#include "{correct}"')
                content = content.replace(f'#include <{incorrect}>', f'#include "{correct}"')
                modified = True
                logger.debug(f"Fixed include in {content_key}: {incorrect} -> {correct}")

        # Fix ALL mock-hal-xxx.h -> mock-stm32-hal-xxx.h patterns
        generic_mock_pattern = re.compile(r'#include\s*[<"]mock-hal-(\w+)\.h[>"]')
        matches = generic_mock_pattern.findall(content)
        for match_module in matches:
            old_include = f'mock-hal-{match_module}.h'
            new_include = f'mock-stm32-hal-{match_module}.h'
            content = content.replace(f'#include "{old_include}"', f'#include "{new_include}"')
            content = content.replace(f'#include <{old_include}>', f'#include "{new_include}"')
            modified = True
            logger.info(f"   Fixed generic mock include: {old_include} -> {new_include}")

        if modified:
            result[content_key] = content
            logger.info(f"   Fixed includes in {content_key}")

    # Fix const mismatch in mock function signatures
    result = _fix_const_mismatch_in_mocks(result)

    return result


# ========== 3. Structured Compile Error Fix Rules ==========

def apply_fixit_rules(
    parsed_content: Dict[str, str],
    structured_errors: Dict[str, Any],
) -> Tuple[Dict[str, str], List[str]]:
    """
    Apply deterministic fix rules based on structured error analysis.

    Eight rule categories:
      1. Multiple definitions — detect duplicate extern "C" wrappers
      2. Undefined references — detect missing mock wrappers
      3. Missing #endif
      4. Unbalanced braces in extern "C" blocks
      5. Header guard ``#endif`` comment format
      6. Compiler-suggested symbol fixes (with safety checks)
      7. Undefined mock object references
      8. Conflicting mock declarations

    Args:
        parsed_content: Dict with test_impl, test_header, mock_impl, mock_header.
        structured_errors: Output from ``_parse_qbs_build_errors_structured``.

    Returns:
        Tuple of (fixed_content, list of applied fix descriptions).
    """
    result = parsed_content.copy()
    fixes_applied: List[str] = []
    summary = structured_errors.get('summary', {})

    # --- Rule 1: Multiple definition errors ---
    multiple_defs = summary.get('multiple_definitions', [])
    if multiple_defs:
        for symbol in multiple_defs:
            logger.info(f"   Checking for duplicate definition: {symbol}")
            for file_key in ['mock_impl', 'mock_header']:
                content = result.get(file_key, '')
                if not content:
                    continue
                extern_c_func_pattern = (
                    rf'(?:HAL_StatusTypeDef|void|int|uint\d+_t)\s+'
                    rf'{re.escape(symbol)}\s*\([^)]*\)\s*\{{[^}}]*\}}'
                )
                if re.search(extern_c_func_pattern, content, re.MULTILINE | re.DOTALL):
                    logger.warning(f"   Found duplicate '{symbol}' in {file_key}")
                    fixes_applied.append(
                        f"DETECTED: duplicate '{symbol}' in {file_key} (needs LLM decision)",
                    )

    # --- Rule 2: Undefined reference errors ---
    undefined_refs = summary.get('undefined_references', [])
    if undefined_refs:
        for symbol in undefined_refs:
            logger.info(f"   Checking for missing definition: {symbol}")
            mock_header = result.get('mock_header', '')
            mock_impl = result.get('mock_impl', '')
            if mock_header and re.search(
                rf'MOCK_METHOD\s*\([^,]+,\s*{re.escape(symbol)}\s*,', mock_header,
            ):
                if mock_impl and not re.search(rf'{re.escape(symbol)}\s*\(', mock_impl):
                    fixes_applied.append(
                        f"DETECTED: '{symbol}' declared in mock_header but missing wrapper in mock_impl",
                    )
            else:
                fixes_applied.append(
                    f"DETECTED: '{symbol}' missing from both mock_header and mock_impl",
                )
    # --- Rule 3: Missing #endif ---
    for file_key in ['test_header', 'mock_header']:
        content = result.get(file_key, '')
        if not content:
            continue
        ifndef_count = len(re.findall(r'#ifndef\s+\w+', content))
        endif_count = len(re.findall(r'#endif', content))
        if ifndef_count > endif_count:
            guard_match = re.search(r'#ifndef\s+(\w+)', content)
            if guard_match:
                guard_name = guard_match.group(1)
                content = content.rstrip() + f'\n\n#endif  // {guard_name}\n'
                result[file_key] = content
                fixes_applied.append(f"Added missing #endif for {guard_name} in {file_key}")
                logger.info(f"   Added missing #endif in {file_key}")

    # --- Rule 4: Unbalanced braces in extern "C" blocks ---
    for file_key in ['mock_impl', 'mock_header']:
        content = result.get(file_key, '')
        if not content:
            continue
        extern_c_opens = len(re.findall(r'extern\s+"C"\s*\{', content))
        if extern_c_opens > 0:
            open_braces = content.count('{')
            close_braces = content.count('}')
            if open_braces > close_braces:
                missing = open_braces - close_braces
                content = content.rstrip() + '\n' + '}\n' * missing
                result[file_key] = content
                fixes_applied.append(f"Added {missing} missing closing brace(s) in {file_key}")
                logger.info(f"   Fixed unbalanced braces in {file_key}")

    # --- Rule 5: Header guard #endif comment format ---
    for file_key in ['test_header', 'mock_header']:
        content = result.get(file_key, '')
        if not content:
            continue
        old_content = content
        content = re.sub(r'#endif\s*/\s*(\w+)\s*/', r'#endif  // \1', content)
        if content != old_content:
            result[file_key] = content
            fixes_applied.append(f"Fixed #endif comment format in {file_key}")

    # --- Rule 6: Compiler-suggested symbol fixes ---
    raw_errors = structured_errors.get('raw_errors', []) or structured_errors.get('errors', [])
    _apply_suggested_symbol_fixes(result, raw_errors, fixes_applied)

    # --- Rule 7: Undefined mock object references ---
    _detect_undefined_mock_refs(raw_errors, fixes_applied)

    # --- Rule 8: Conflicting mock declarations ---
    _detect_conflicting_mocks(raw_errors, fixes_applied)

    if fixes_applied:
        logger.info(f"   Applied {len(fixes_applied)} deterministic fixes")
        for fix in fixes_applied:
            logger.debug(f"      - {fix}")

    return result, fixes_applied


# ---------- internal helpers for apply_fixit_rules ----------

# Patterns that indicate a HAL/STM32 API component — never auto-replace these.
_DANGEROUS_SYMBOL_PATTERNS = [
    r'^(HAL|LL|EXTI|GPIO|UART|SPI|I2C|TIM|RCC|PWR|DMA|NVIC|ADC|DAC|FLASH|IWDG|WWDG)$',
    r'^__HAL',
    r'_TypeDef$',
    r'_HandleTypeDef$',
    r'_InitTypeDef$',
    r'^stm32',
]


def _apply_suggested_symbol_fixes(
    result: Dict[str, str],
    raw_errors: list,
    fixes_applied: List[str],
) -> None:
    """Rule 6: apply compiler-suggested symbol replacements with safety checks."""
    suggested_fixes: List[Tuple[str, str]] = []
    seen_fixes: set = set()

    for i, err in enumerate(raw_errors):
        err_text = err.message if hasattr(err, 'message') else str(err)
        if "was not declared in this scope" not in err_text:
            continue
        wrong_match = re.search(r"'(\w+)'\s*was not declared in this scope", err_text)
        if not wrong_match:
            continue
        wrong_name = wrong_match.group(1)
        suggest_match = re.search(
            r"(?:note:\s*)?suggested alternative:\s*'(\w+)'", err_text, re.IGNORECASE,
        )
        if not suggest_match and i + 1 < len(raw_errors):
            next_err = raw_errors[i + 1]
            next_text = next_err.message if hasattr(next_err, 'message') else str(next_err)
            suggest_match = re.search(
                r"(?:note:\s*)?suggested alternative:\s*'(\w+)'", next_text, re.IGNORECASE,
            )
        if suggest_match:
            correct_name = suggest_match.group(1)
            fix_key = f"{wrong_name}->{correct_name}"
            if fix_key not in seen_fixes:
                seen_fixes.add(fix_key)
                suggested_fixes.append((wrong_name, correct_name))

    if not suggested_fixes:
        return

    logger.info(f"   Found {len(suggested_fixes)} compiler-suggested symbol fixes")
    for wrong_name, correct_name in suggested_fixes:
        logger.info(f"      - '{wrong_name}' -> '{correct_name}'")

        # Safety check 1: skip HAL/STM32 API components
        is_dangerous = False
        for pattern in _DANGEROUS_SYMBOL_PATTERNS:
            if re.search(pattern, wrong_name, re.IGNORECASE):
                is_dangerous = True
                logger.warning(f"      SKIPPING dangerous replacement: '{wrong_name}'")
                fixes_applied.append(
                    f"SKIPPED_DANGEROUS: '{wrong_name}' -> '{correct_name}' (HAL API component)",
                )
                break
        # Safety check 2: skip if used as part of HAL_ / LL_ identifiers
        if not is_dangerous:
            for file_key in ['test_impl', 'test_header', 'mock_impl', 'mock_header']:
                content = result.get(file_key, '')
                if not content:
                    continue
                hal_usage = rf'(HAL_|LL_|__HAL_){re.escape(wrong_name)}'
                typedef_usage = rf'{re.escape(wrong_name)}_(TypeDef|HandleTypeDef|InitTypeDef)'
                if re.search(hal_usage, content) or re.search(typedef_usage, content):
                    is_dangerous = True
                    logger.warning(f"      SKIPPING: '{wrong_name}' used in HAL API names in {file_key}")
                    fixes_applied.append(
                        f"SKIPPED_IN_API: '{wrong_name}' used in HAL API names (HAL_{wrong_name}_*)",
                    )
                    break

        if is_dangerous:
            continue

        # Apply standalone symbol replacement (word-boundary safe)
        for file_key in ['test_impl', 'test_header', 'mock_impl', 'mock_header']:
            content = result.get(file_key, '')
            if not content:
                continue
            safe_pattern = rf'(?<![A-Za-z0-9_]){re.escape(wrong_name)}(?![A-Za-z0-9_])'
            new_content = re.sub(safe_pattern, correct_name, content)
            if new_content != content:
                result[file_key] = new_content
                count = len(re.findall(safe_pattern, content))
                fixes_applied.append(
                    f"Replaced standalone '{wrong_name}' with '{correct_name}' "
                    f"({count} occurrences) in {file_key}",
                )


def _detect_undefined_mock_refs(raw_errors: list, fixes_applied: List[str]) -> None:
    """Rule 7: detect undefined mock object references and missing HAL wrappers."""
    undefined_mock_refs: List[str] = []
    undefined_funcs: List[str] = []

    for err in raw_errors:
        err_text = err.message if hasattr(err, 'message') else str(err)
        if "undefined reference to" not in err_text.lower():
            continue
        mock_match = re.search(r"undefined reference to [`'\"](\w+_mock)[`'\"]", err_text)
        if mock_match:
            undefined_mock_refs.append(mock_match.group(1))
        else:
            func_match = re.search(
                r"undefined reference to [`'\"]([A-Z_][A-Za-z0-9_]+)[`'\"]", err_text,
            )
            if func_match:
                func_name = func_match.group(1)
                if func_name.startswith(('HAL_', 'LL_', '__HAL')):
                    undefined_funcs.append(func_name)
    if undefined_mock_refs:
        logger.info(f"   Found {len(undefined_mock_refs)} undefined mock references")
        for mock_name in set(undefined_mock_refs):
            logger.warning(f"      - '{mock_name}' is referenced but not defined")
            module_match = re.search(r'stm32_(\w+)_mock', mock_name)
            if module_match:
                ref_module = module_match.group(1)
                expected_header = f"mock-stm32-hal-{ref_module}.h"
                expected_impl = f"mock-stm32-hal-{ref_module}.cpp"
                fixes_applied.append(
                    f"NEEDS_MOCK: '{mock_name}' requires {expected_header} and {expected_impl}",
                )

    if undefined_funcs:
        logger.info(f"   Found {len(undefined_funcs)} undefined HAL/LL functions")
        for func_name in set(undefined_funcs):
            logger.warning(f"      - '{func_name}' needs mock wrapper")
            fixes_applied.append(f"NEEDS_WRAPPER: '{func_name}' needs C wrapper in mock implementation")


def _detect_conflicting_mocks(raw_errors: list, fixes_applied: List[str]) -> None:
    """Rule 8: detect conflicting mock declarations (mock already exists elsewhere)."""
    conflicting_mocks: List[Tuple[str, str]] = []
    for err in raw_errors:
        err_text = err.message if hasattr(err, 'message') else str(err)
        if "conflicting declaration" not in err_text.lower():
            continue
        conflict_match = re.search(
            r"conflicting declaration ['`](\w+)\s+(\w+_mock)['`]", err_text,
        )
        if conflict_match:
            conflicting_mocks.append((conflict_match.group(2), conflict_match.group(1)))

    if conflicting_mocks:
        logger.warning(f"   Found {len(conflicting_mocks)} conflicting mock declarations")
        for mock_name, mock_type in conflicting_mocks:
            logger.warning(f"      - '{mock_name}' already defined elsewhere (type: {mock_type})")
            module_match = re.search(r'stm32_(\w+)_mock', mock_name)
            if module_match:
                module = module_match.group(1)
                fixes_applied.append(
                    f"CONFLICT_MOCK: '{mock_name}' already exists in "
                    f"mock-stm32-hal-{module}.h/cpp - DO NOT redefine, just include existing mock",
                )


# ========== 4. Const Qualifier Mismatch Fixes ==========

def _fix_const_mismatch_in_mocks(parsed_content: Dict[str, str]) -> Dict[str, str]:
    """
    Fix const qualifier mismatches in mock function signatures.

    LLMs often add ``const`` qualifiers that don't match vendor header
    declarations, causing *conflicting declaration* compilation errors.

    Known patterns (STM32 HAL):
      - ``HAL_GPIO_Init``: remove const from ``GPIO_InitTypeDef*``
      - ``HAL_GPIO_ReadPin``: remove const from ``GPIO_TypeDef*``

    Args:
        parsed_content: Dict with test_impl, test_header, mock_impl, mock_header.

    Returns:
        Dict with corrected const qualifiers.
    """
    result = parsed_content.copy()

    const_fixes = [
        (
            r'HAL_GPIO_Init\s*\(\s*GPIO_TypeDef\s*\*\s*GPIOx\s*,\s*const\s+GPIO_InitTypeDef\s*\*',
            'HAL_GPIO_Init(GPIO_TypeDef *GPIOx, GPIO_InitTypeDef *',
        ),
        (
            r'HAL_GPIO_ReadPin\s*\(\s*const\s+GPIO_TypeDef\s*\*',
            'HAL_GPIO_ReadPin(GPIO_TypeDef *',
        ),
    ]

    for content_key in ['mock_impl', 'mock_header']:
        content = result.get(content_key, '')
        if not content:
            continue
        modified = False
        for wrong_pattern, correct_pattern in const_fixes:
            new_content = re.sub(wrong_pattern, correct_pattern, content)
            if new_content != content:
                content = new_content
                modified = True
                logger.info(f"   Fixed const mismatch in {content_key}")
        if modified:
            result[content_key] = content

    return result


# ========== 5. Code Structure Trimming ==========

def trim_generated_code_structure(parsed_content: Dict[str, str]) -> Dict[str, str]:
    """
    Apply structure-boundary trimming to all generated code files.

    Call before saving files to ensure code ends at the correct C/C++
    structure boundary, removing any trailing explanatory text the LLM
    may have appended.

    Args:
        parsed_content: Dict from ``parse_and_split_test_output``.

    Returns:
        Trimmed content dict.
    """
    file_ext_map = {
        'test_impl': '.cpp',
        'test_header': '.h',
        'mock_impl': '.cpp',
        'mock_header': '.h',
    }

    result: Dict[str, str] = {}
    total_trimmed = 0

    for key, content in parsed_content.items():
        if key in file_ext_map and content:
            ext = file_ext_map[key]
            trimmed_content, was_trimmed = _trim_code_to_structure_end(content, ext)
            result[key] = trimmed_content
            if was_trimmed:
                total_trimmed += 1
                logger.info(f"   {key}: Trimmed trailing content after code structure end")
        else:
            result[key] = content

    if total_trimmed > 0:
        logger.info(f"   Structure trimming: {total_trimmed} files cleaned")

    return result


def _trim_code_to_structure_end(content: str, file_ext: str) -> Tuple[str, bool]:
    """
    Trim trailing content based on C/C++ structure boundaries.

    Strategy (no hard-coded keywords, language-spec only):
      - ``.cpp`` files should end at the last balanced ``}``
      - ``.h`` / ``.hpp`` files should end at the last ``#endif``

    Args:
        content: Code content.
        file_ext: File extension (``.cpp``, ``.h``, ``.hpp``).

    Returns:
        Tuple of (trimmed content, whether content was modified).
    """
    if not content or not content.strip():
        return content, False

    lines = content.split('\n')
    original_line_count = len(lines)
    code_end_index = len(lines)

    if file_ext in ['.h', '.hpp']:
        # Header files: find last #endif
        for i in range(len(lines) - 1, -1, -1):
            stripped = lines[i].strip()
            if stripped.startswith('#endif'):
                code_end_index = i + 1
                break
    else:
        # .cpp files: brace counting to find last balanced }
        brace_count = 0
        last_balanced_close = -1

        for i, line in enumerate(lines):
            stripped = line.strip()
            # Skip pure comment lines
            if stripped.startswith('//') or stripped.startswith('/*') or stripped.startswith('*'):
                if '*/' in line:
                    pass  # continue processing
                else:
                    continue
            open_count = line.count('{')
            close_count = line.count('}')
            brace_count += open_count - close_count
            if close_count > 0 and brace_count == 0:
                last_balanced_close = i

        if last_balanced_close >= 0:
            code_end_index = last_balanced_close + 1

    if code_end_index < original_line_count:
        trimmed_lines = lines[:code_end_index]
        trimmed_content = '\n'.join(trimmed_lines).rstrip() + '\n'

        removed_lines = lines[code_end_index:]
        removed_content = '\n'.join(removed_lines).strip()
        if removed_content:
            logger.debug(
                f"   Trimmed {original_line_count - code_end_index} lines from {file_ext} file",
            )
            preview = removed_content[:200]
            if len(removed_content) > 200:
                preview += "..."
            logger.debug(f"   Removed content preview: {preview}")

        return trimmed_content, True

    return content, False
