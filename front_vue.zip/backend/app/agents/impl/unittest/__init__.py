"""
@file __init__.py
@author caoshwen
@brief UnitTestAgent subpackage — unified export of public symbols.

@version 3.3
@date 2026-03-10

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from .agent import UnitTestAgent
from .types import (
    UnitTestContext,
    GenerateOptions,
    GeneratedTest,
    CompileError,
    ClassifiedCompileError,
    CompileResult,
    FixResult,
    CoverageReport,
    SourceFile,
    SourceAnalysis,
    UnitTestStreamChunk,
    UnitTestResult,
    UnitTestState,
)
from .parsers import (
    parse_gcc_errors,
    parse_qbs_build_errors,
    parse_qbs_build_errors_structured,
    parse_test_results,
    parse_coverage_from_output,
    extract_code_block,
    extract_named_code_blocks,
    parse_functions_regex,
    parse_calls_regex,
    infer_layer_from_paths,
    analyze_source_ast,
    ERROR_PATTERNS,
    parse_compile_error,
    classify_compile_errors,
    detect_truncation,
    validate_parsed_completeness,
)
from .prompts import (
    SYSTEM_PROMPT,
    build_system_prompt,
    build_generation_prompt,
    build_fix_prompt,
    build_mock_prompt,
    build_two_phase_prompt,
    build_coverage_improvement_prompt,
    build_test_failure_fix_prompt,
    build_multi_file_fix_prompt,
    build_autonomous_fix_prompt,
    build_autonomous_fix_system_prompt,
    build_cli_generation_prompt,
    build_cli_generation_system_prompt,
    build_cli_coverage_improvement_prompt,
    build_cli_team_generation_prompt,
    build_cli_team_system_prompt,
)
from .libclang import LibClangAnalyzer
from .paths import (
    detect_layer_from_filename,
    detect_platform_from_path,
    generate_file_paths,
    save_test_files_to_project,
    find_and_read_header_file,
    find_dependent_hal_headers,
    find_vendor_hal_api_definitions,
    find_existing_mock_files,
    find_project_root_for_source,
    detect_project_membership,
)
from .qbs import (
    update_qbs_config,
    create_isolated_app_qbs_file,
    resolve_qbs_project_path,
    resolve_qbs_file_path,
    run_qbs_build,
    run_test_executable,
    analyze_gcov_coverage,
    collect_gcov_coverage,
)
from .workflow import UnitTestWorkflow
from .fixers import (
    fix_cpp_syntax_errors,
    fix_mock_header_includes,
    apply_fixit_rules,
    trim_generated_code_structure,
)
from .output_parser import (
    parse_and_split_test_output,
)
from .external_mocks import (
    analyze_source_external_hal_calls,
    analyze_source_midware_calls,
    find_missing_mock_files,
    create_external_mock_file,
    generate_mock_dependency_guidance,
)

__all__ = [
    # Agent
    "UnitTestAgent",
    "UnitTestWorkflow",
    # Types
    "UnitTestContext",
    "GenerateOptions",
    "GeneratedTest",
    "CompileError",
    "ClassifiedCompileError",
    "CompileResult",
    "FixResult",
    "CoverageReport",
    "SourceFile",
    "SourceAnalysis",
    "UnitTestStreamChunk",
    "UnitTestResult",
    "UnitTestState",
    # Parsers
    "parse_gcc_errors",
    "parse_qbs_build_errors",
    "parse_qbs_build_errors_structured",
    "parse_test_results",
    "parse_coverage_from_output",
    "extract_code_block",
    "extract_named_code_blocks",
    "ERROR_PATTERNS",
    "parse_compile_error",
    "classify_compile_errors",
    "detect_truncation",
    "validate_parsed_completeness",
    # Output parser
    "parse_and_split_test_output",
    # Prompts
    "SYSTEM_PROMPT",
    "build_generation_prompt",
    "build_fix_prompt",
    "build_mock_prompt",
    "build_two_phase_prompt",
    "build_coverage_improvement_prompt",
    "build_test_failure_fix_prompt",
    "build_multi_file_fix_prompt",
    "build_autonomous_fix_prompt",
    "build_autonomous_fix_system_prompt",
    "build_cli_generation_prompt",
    "build_cli_generation_system_prompt",
    "build_cli_coverage_improvement_prompt",
    # LibClang
    "LibClangAnalyzer",
    # Paths
    "detect_layer_from_filename",
    "detect_platform_from_path",
    "generate_file_paths",
    "save_test_files_to_project",
    "find_and_read_header_file",
    "find_dependent_hal_headers",
    "find_vendor_hal_api_definitions",
    "find_existing_mock_files",
    "find_project_root_for_source",
    "detect_project_membership",
    # QBS
    "update_qbs_config",
    "create_isolated_app_qbs_file",
    "resolve_qbs_project_path",
    "resolve_qbs_file_path",
    "run_qbs_build",
    "run_test_executable",
    "analyze_gcov_coverage",
    "collect_gcov_coverage",
    # Fixers
    "fix_cpp_syntax_errors",
    "fix_mock_header_includes",
    "apply_fixit_rules",
    "trim_generated_code_structure",
    # External mocks
    "analyze_source_external_hal_calls",
    "analyze_source_midware_calls",
    "find_missing_mock_files",
    "create_external_mock_file",
    "generate_mock_dependency_guidance",
]
