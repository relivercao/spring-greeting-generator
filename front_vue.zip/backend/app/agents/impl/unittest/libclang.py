"""
@file _unittest_libclang.py
@author caoshwen
@brief LibClang enhanced analyzer (internal module).

Macro/function distinction, pre-compile validation, mock candidate identification,
existing project mock scanning.
Graceful degradation when libclang is not available.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger

try:
    import clang.cindex as cindex
    from clang.cindex import CursorKind, Diagnostic
    LIBCLANG_AVAILABLE = True
except ImportError:
    LIBCLANG_AVAILABLE = False
    cindex = None  # type: ignore
    CursorKind = None  # type: ignore
    Diagnostic = None  # type: ignore


class LibClangAnalyzer:
    """libclang C/C++ code analyzer.

    Features:
    1. Macro vs function distinction (critical for HAL code)
    2. Pre-compile validation + FixIt extraction
    3. Mock candidate identification
    4. Scan existing project mock objects

    Gracefully degrades and returns empty results when libclang is not available.
    """

    _index = None

    @classmethod
    def is_available(cls) -> bool:
        """Check if libclang is available."""
        return LIBCLANG_AVAILABLE

    @classmethod
    def get_index(cls):
        """Get or create singleton clang Index."""
        if not LIBCLANG_AVAILABLE:
            return None
        if cls._index is None:
            cls._index = cindex.Index.create()
        return cls._index

    @classmethod
    def analyze_symbols_in_header(
        cls,
        header_path: str,
        include_paths: Optional[List[str]] = None,
        defines: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """Analyze header file, classify all symbols (function/macro/typedef/struct/enum)."""
        if not LIBCLANG_AVAILABLE:
            return {}
        if not Path(header_path).exists():
            logger.warning(f"Header file not found: {header_path}")
            return {}

        try:
            index = cls.get_index()
            args = ['-x', 'c++', '-std=c++17']
            if include_paths:
                for p in include_paths:
                    args.extend(['-I', str(p)])
            if defines:
                for name, value in defines.items():
                    args.append(f'-D{name}={value}' if value else f'-D{name}')

            tu = index.parse(
                header_path, args=args,
                options=cindex.TranslationUnit.PARSE_DETAILED_PROCESSING_RECORD,
            )
            symbols: Dict[str, Dict[str, Any]] = {}

            def visit_node(node, in_file=False):
                loc = node.location
                if loc.file and str(loc.file.name) == header_path:
                    in_file = True
                if in_file and node.spelling:
                    name = node.spelling
                    kind = node.kind
                    loc_info = {'line': loc.line, 'column': loc.column}
                    if kind == CursorKind.MACRO_DEFINITION:
                        tokens = list(node.get_tokens())
                        symbols[name] = {
                            'kind': 'macro',
                            'is_function_like': any(t.spelling == '(' for t in tokens[:3]),
                            'location': loc_info,
                        }
                    elif kind == CursorKind.FUNCTION_DECL:
                        symbols[name] = {
                            'kind': 'function',
                            'return_type': node.result_type.spelling,
                            'params': [(p.spelling, p.type.spelling) for p in node.get_arguments()],
                            'location': loc_info,
                        }
                    elif kind == CursorKind.TYPEDEF_DECL:
                        symbols[name] = {
                            'kind': 'typedef',
                            'underlying': node.underlying_typedef_type.spelling,
                            'location': loc_info,
                        }
                    elif kind == CursorKind.STRUCT_DECL:
                        symbols[name] = {'kind': 'struct', 'location': loc_info}
                    elif kind == CursorKind.ENUM_DECL:
                        symbols[name] = {'kind': 'enum', 'location': loc_info}
                    elif kind == CursorKind.VAR_DECL:
                        symbols[name] = {'kind': 'variable', 'type': node.type.spelling, 'location': loc_info}
                for child in node.get_children():
                    visit_node(child, in_file)

            visit_node(tu.cursor)
            return symbols
        except Exception as e:
            logger.error(f"libclang analysis failed for {header_path}: {e}")
            return {}

    # PLACEHOLDER_VALIDATE_AND_MOCK

    @classmethod
    def validate_generated_code(
        cls,
        code: str,
        include_paths: Optional[List[str]] = None,
        defines: Optional[Dict[str, str]] = None,
        code_type: str = 'cpp',
    ) -> Dict[str, Any]:
        """Pre-compile validation of generated code, extract FixIt hints."""
        if not LIBCLANG_AVAILABLE:
            return {'valid': True, 'errors': [], 'warnings': [], 'fixits': []}

        import tempfile
        import os

        result: Dict[str, Any] = {'valid': True, 'errors': [], 'warnings': [], 'fixits': []}
        try:
            suffix = '.cpp' if code_type == 'cpp' else '.c'
            with tempfile.NamedTemporaryFile(mode='w', suffix=suffix, delete=False, encoding='utf-8') as f:
                f.write(code)
                temp_path = f.name
            try:
                index = cls.get_index()
                lang_flag = 'c++' if code_type == 'cpp' else 'c'
                std_flag = 'c++17' if code_type == 'cpp' else 'c11'
                args = ['-x', lang_flag, f'-std={std_flag}', '-fsyntax-only']
                if include_paths:
                    for p in include_paths:
                        args.extend(['-I', str(p)])
                if defines:
                    for name, value in defines.items():
                        args.append(f'-D{name}={value}' if value else f'-D{name}')

                tu = index.parse(
                    temp_path, args=args,
                    options=cindex.TranslationUnit.PARSE_DETAILED_PROCESSING_RECORD,
                )
                for diag in tu.diagnostics:
                    diag_info = {
                        'line': diag.location.line if diag.location else 0,
                        'column': diag.location.column if diag.location else 0,
                        'message': diag.spelling,
                        'severity': str(diag.severity).split('.')[-1],
                        'fixit': None,
                    }
                    if diag.fixits:
                        for fixit in diag.fixits:
                            result['fixits'].append({
                                'line': fixit.range.start.line,
                                'old': '',
                                'new': fixit.value,
                            })
                            diag_info['fixit'] = fixit.value
                    if diag.severity >= Diagnostic.Error:
                        result['errors'].append(diag_info)
                        result['valid'] = False
                    elif diag.severity == Diagnostic.Warning:
                        result['warnings'].append(diag_info)
            finally:
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass
        except Exception as e:
            logger.error(f"Pre-compile validation failed: {e}")
            result['valid'] = True
        return result

    @classmethod
    def identify_mock_candidates(
        cls,
        source_path: str,
        hal_symbols: Dict[str, Dict[str, Any]],
        include_paths: Optional[List[str]] = None,
    ) -> Dict[str, List[str]]:
        """Identify HAL symbols (functions/macros/types) that need mocking in source code."""
        result: Dict[str, List[str]] = {
            'functions_to_mock': [],
            'macros_to_replace': [],
            'types_needed': [],
        }
        if not LIBCLANG_AVAILABLE:
            return result
        try:
            if not Path(source_path).exists():
                return result
            with open(source_path, 'r', encoding='utf-8', errors='ignore') as f:
                source_content = f.read()

            hal_pattern = r'\b(HAL_\w+|__HAL_\w+|GPIO_\w+|UART_\w+|SPI_\w+|I2C_\w+|TIM_\w+|ADC_\w+|DMA_\w+|EXTI_\w+|PWR_\w+|RCC_\w+)\b'
            found_symbols = set(re.findall(hal_pattern, source_content))
            for symbol in found_symbols:
                if symbol in hal_symbols:
                    kind = hal_symbols[symbol].get('kind', 'unknown')
                    if kind == 'function':
                        result['functions_to_mock'].append(symbol)
                    elif kind == 'macro':
                        result['macros_to_replace'].append(symbol)
                    elif kind in ('typedef', 'struct', 'enum'):
                        result['types_needed'].append(symbol)
        except Exception as e:
            logger.error(f"Mock candidate identification failed: {e}")
        return result

    # PLACEHOLDER_GUIDANCE_AND_SCAN

    @classmethod
    def generate_mock_guidance(
        cls,
        mock_candidates: Dict[str, List[str]],
        hal_symbols: Dict[str, Dict[str, Any]],
    ) -> str:
        """Generate LLM mock guidance text based on symbol analysis."""
        if not mock_candidates.get('functions_to_mock') and not mock_candidates.get('macros_to_replace'):
            return ""

        parts = ["\n## LibClang Symbol Analysis (Auto-Generated)\n"]

        if mock_candidates.get('functions_to_mock'):
            parts.append("\n### Functions to Mock (use MOCK_METHOD + wrapper):\n")
            for func_name in mock_candidates['functions_to_mock']:
                info = hal_symbols.get(func_name, {})
                ret_type = info.get('return_type', 'void')
                params = info.get('params', [])
                param_str = ', '.join([f"{t} {n}" for n, t in params]) if params else 'void'
                parts.append(f"- `{ret_type} {func_name}({param_str})`\n")

        if mock_candidates.get('macros_to_replace'):
            parts.append("\n### Macros to Replace (use #undef + inline function):\n")
            parts.append("CRITICAL: These are MACROS, not functions! Cannot use MOCK_METHOD directly.\n")
            for macro_name in mock_candidates['macros_to_replace']:
                info = hal_symbols.get(macro_name, {})
                if info.get('is_function_like', False):
                    parts.append(f"- `{macro_name}(...)` -> #undef + mock via inline function\n")
                else:
                    parts.append(f"- `{macro_name}` -> #undef + define test value\n")

        if mock_candidates.get('types_needed'):
            parts.append("\n### Types Required (ensure included/forward-declared):\n")
            for type_name in mock_candidates['types_needed']:
                kind = hal_symbols.get(type_name, {}).get('kind', 'type')
                parts.append(f"- `{type_name}` ({kind})\n")

        return ''.join(parts)

    @classmethod
    def scan_project_mock_objects(
        cls,
        project_root: str,
        platform: str = "stm32u3",
    ) -> Dict[str, Dict[str, str]]:
        """Scan existing project mock files to discover mock object naming conventions."""
        mock_objects: Dict[str, Dict[str, str]] = {}
        project_path = Path(project_root)

        mock_search_paths = [
            project_path / "libs" / "platformkit" / "tests" / "mocks" / platform / "platform-mocks" / "inc",
            project_path / "tests" / "mocks" / "inc",
            project_path / "tests" / "app" / "mocks" / "inc",
            project_path / "tests" / "mocks" / platform,
            project_path / "tests" / "mocks",
        ]

        for mock_dir in mock_search_paths:
            if not mock_dir.exists():
                continue
            for mock_file in mock_dir.glob("mock-*.h"):
                try:
                    content = mock_file.read_text(encoding='utf-8', errors='ignore')
                    patterns = [
                        r'extern\s+(?:NiceMock<)?(\w+)(?:>)?\s+(\w+_mock\w*)\s*;',
                        r'extern\s+(\w+)\*?\s+(\w+_mock\w*)\s*;',
                    ]
                    for pattern in patterns:
                        for class_name, obj_name in re.findall(pattern, content):
                            mock_objects[obj_name] = {
                                'class': class_name,
                                'file': mock_file.name,
                                'path': str(mock_file),
                            }
                except Exception as e:
                    logger.debug(f"Failed to scan {mock_file.name}: {e}")

        return mock_objects

    @classmethod
    def generate_mock_naming_guidance(
        cls,
        existing_mocks: Dict[str, Dict[str, str]],
        module_name: str,
    ) -> str:
        """Generate naming guidance based on existing project mocks (prevents linker errors)."""
        if not existing_mocks:
            return ""

        parts = ["\n## Project Mock Object Registry (MUST USE THESE NAMES)\n"]
        parts.append("CRITICAL: The following mock objects already exist in this project.\n")
        parts.append("DO NOT create new mock objects with different names!\n\n")

        cortex_mocks = {}
        module_mocks = {}
        other_mocks = {}

        for obj_name, info in existing_mocks.items():
            if 'cortex' in obj_name.lower():
                cortex_mocks[obj_name] = info
            elif module_name.lower() in obj_name.lower():
                module_mocks[obj_name] = info
            else:
                other_mocks[obj_name] = info

        if cortex_mocks:
            parts.append("### CORTEX Mock (for HAL_NVIC_* functions):\n")
            parts.append("DO NOT redefine HAL_NVIC_* functions - they exist in mock-stm32-hal-cortex.cpp\n")
            for obj_name, info in cortex_mocks.items():
                parts.append(f"- Use `{obj_name}` (class: `{info['class']}`, file: `{info['file']}`)\n")

        if module_mocks:
            parts.append(f"\n### Module Mock ({module_name}):\n")
            for obj_name, info in module_mocks.items():
                parts.append(f"- `{obj_name}` (class: `{info['class']}`, file: `{info['file']}`)\n")

        if other_mocks and len(other_mocks) <= 10:
            parts.append("\n### Other Available Mocks:\n")
            for obj_name, info in sorted(other_mocks.items()):
                parts.append(f"- `{obj_name}` -> `{info['class']}`\n")

        return ''.join(parts)
