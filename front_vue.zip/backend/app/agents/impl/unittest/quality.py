"""Static quality analysis for generated C and C++ unit tests."""

from __future__ import annotations

import re
from collections import Counter
from typing import Any

from app.core.c_source import mask_c_non_code


_GTEST_CASE_PATTERN = re.compile(
    r"\bTEST(?:_F|_P)?\s*\(\s*([A-Za-z_]\w*)\s*,\s*([A-Za-z_]\w*)\s*\)"
)
_UNITY_CASE_PATTERN = re.compile(
    r"\bvoid\s+(test_[A-Za-z0-9_]+)\s*\(\s*(?:void)?\s*\)"
)
_ASSERTION_PATTERN = re.compile(
    r"\bEXPECT_(?!CALL\b)[A-Z0-9_]+\s*\(|"
    r"\bASSERT_[A-Z0-9_]+\s*\(|"
    r"\bTEST_ASSERT(?:_[A-Z0-9_]+)?\s*\(|"
    r"\b(?:CHECK|REQUIRE)(?:_[A-Z0-9_]+)?\s*\("
)
_BOUNDARY_PATTERN = re.compile(
    r"\b(?:boundary|edge|minimum|maximum|min|max|zero|empty|null|nullptr|"
    r"overflow|underflow|first|last|limit|out[_ ]of[_ ]range|INT_MAX|INT_MIN|"
    r"UINT_MAX|SIZE_MAX)\b",
    re.IGNORECASE,
)
_ERROR_PATH_PATTERN = re.compile(
    r"\b(?:error|failure|failed|invalid|reject|timeout|fault|exception|denied|"
    r"unsupported|unavailable|busy|retry|negative|abort)\b",
    re.IGNORECASE,
)
_FIXTURE_PATTERN = re.compile(
    r"\b(?:SetUp|TearDown|SetUpTestSuite|TearDownTestSuite|setUp|tearDown)\s*\("
)
_MOCK_EXPECTATION_PATTERN = re.compile(r"\bEXPECT_CALL\s*\(")
_DISABLED_PATTERN = re.compile(
    r"\bDISABLED_[A-Za-z0-9_]+|\bGTEST_SKIP\s*\(|\bTEST_IGNORE(?:_MESSAGE)?\s*\("
)
_PLACEHOLDER_PATTERN = re.compile(
    r"\b(?:TODO|FIXME|TBD)\b|not\s+implemented|add\s+test\s+here|"
    r"placeholder\s+test",
    re.IGNORECASE,
)


def analyze_generated_test(
    content: str,
    *,
    source_file: str = "",
    test_file: str = "",
) -> dict[str, Any]:
    """Score one generated test file and report hard blockers and warnings."""
    code = mask_c_non_code(content)
    gtest_names = [f"{suite}.{name}" for suite, name in _GTEST_CASE_PATTERN.findall(code)]
    unity_names = _UNITY_CASE_PATTERN.findall(code)
    test_names = [*gtest_names, *unity_names]
    duplicate_names = sorted(
        name for name, count in Counter(test_names).items() if count > 1
    )
    test_case_count = len(test_names)
    assertion_count = len(_ASSERTION_PATTERN.findall(code))
    assertion_density = assertion_count / test_case_count if test_case_count else 0.0
    semantic_text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", code).replace("_", " ")
    boundary_coverage = bool(_BOUNDARY_PATTERN.search(semantic_text))
    error_path_coverage = bool(_ERROR_PATH_PATTERN.search(semantic_text))
    fixture_usage = bool(_FIXTURE_PATTERN.search(code))
    mock_expectation_usage = bool(_MOCK_EXPECTATION_PATTERN.search(code))
    disabled_tests = len(_DISABLED_PATTERN.findall(code))
    placeholder_content = bool(_PLACEHOLDER_PATTERN.search(content))

    blockers: list[str] = []
    if test_case_count == 0:
        blockers.append("No supported test cases were detected.")
    if assertion_count == 0:
        blockers.append("No test assertions were detected.")
    if duplicate_names:
        blockers.append(
            "Duplicate test names were detected: " + ", ".join(duplicate_names)
        )
    if placeholder_content:
        blockers.append("Placeholder or unfinished test content was detected.")

    score = 0
    if test_case_count >= 3:
        score += 20
    elif test_case_count == 2:
        score += 15
    elif test_case_count == 1:
        score += 10

    if assertion_density >= 2.0:
        score += 30
    elif assertion_density >= 1.5:
        score += 25
    elif assertion_density >= 1.0:
        score += 20
    elif assertion_count:
        score += 10
    score += 15 if boundary_coverage else 0
    score += 15 if error_path_coverage else 0
    score += 10 if fixture_usage else 0
    score += 10 if mock_expectation_usage else 0

    warnings: list[str] = []
    if test_case_count and assertion_density < 1.0:
        warnings.append("Assertion density is below one assertion per test case.")
    if not boundary_coverage:
        warnings.append("No boundary-case coverage signal was detected.")
    if not error_path_coverage:
        warnings.append("No error-path coverage signal was detected.")
    if not fixture_usage:
        warnings.append("No fixture setup or teardown usage was detected.")
    if not mock_expectation_usage:
        warnings.append("No explicit mock expectation was detected.")
    if disabled_tests:
        warnings.append(f"Detected {disabled_tests} disabled or skipped test(s).")

    return {
        "source_file": source_file,
        "test_file": test_file,
        "score": score,
        "passed": not blockers,
        "test_case_count": test_case_count,
        "assertion_count": assertion_count,
        "assertion_density": round(assertion_density, 2),
        "boundary_coverage": boundary_coverage,
        "error_path_coverage": error_path_coverage,
        "fixture_usage": fixture_usage,
        "mock_expectation_usage": mock_expectation_usage,
        "duplicate_test_names": duplicate_names,
        "disabled_test_count": disabled_tests,
        "placeholder_content": placeholder_content,
        "blockers": blockers,
        "warnings": warnings,
    }


def summarize_generated_test_quality(generated_tests: list[Any]) -> dict[str, Any]:
    """Aggregate static quality results for generated test artifacts."""
    reports = [
        analyze_generated_test(
            test.test_content or "",
            source_file=test.source_file,
            test_file=test.test_file,
        )
        for test in generated_tests
    ]
    scores = [report["score"] for report in reports]
    blockers = [
        f"{report['test_file'] or report['source_file']}: {message}"
        for report in reports
        for message in report["blockers"]
    ]
    warnings = [
        f"{report['test_file'] or report['source_file']}: {message}"
        for report in reports
        for message in report["warnings"]
    ]
    average_score = round(sum(scores) / len(scores), 1) if scores else 0.0
    if reports and average_score < 60:
        warnings.insert(
            0,
            "Generated test quality score is below the recommended threshold of 60.",
        )
    if not reports:
        blockers.append("No generated test artifacts were available for quality analysis.")

    return {
        "passed": not blockers,
        "score": average_score,
        "reports": reports,
        "blockers": blockers,
        "warnings": warnings,
    }
