"""
@file _unittest_parsers.py
@author caoshwen
@brief UnitTestAgent parsing utilities (internal module).

GCC error parsing, GTest result parsing, coverage parsing, code block extraction, regex AST parsing.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import re
from typing import Any, Optional

from app.core.c_source import mask_c_non_code

from .types import ClassifiedCompileError, CompileError, SourceAnalysis


# ========== Source code branch detection ==========

def has_branches(source_code: str) -> bool:
    """
    Detect if source code contains branch statements.
    
    Returns True if the code contains any of:
    - if/else statements
    - switch/case statements
    - ternary operators (? :)
    - for/while loops (which have implicit branch conditions)
    
    Args:
        source_code: C/C++ source code content
        
    Returns:
        bool: True if branches exist, False otherwise
    """
    if not source_code:
        return False
    
    code = mask_c_non_code(source_code)
    
    # Check for branch keywords
    branch_patterns = [
        r'\bif\s*\(',           # if statement
        r'\belse\b',            # else statement
        r'\bswitch\s*\(',       # switch statement
        r'\bcase\s+',           # case label
        r'\bfor\s*\(',          # for loop
        r'\bwhile\s*\(',        # while loop
        r'\bdo\s*\{',           # do-while loop
        r'\?[^:]*:',            # ternary operator (? :)
    ]
    
    for pattern in branch_patterns:
        if re.search(pattern, code):
            return True
    
    return False


# ========== GCC / Compile error parsing ==========

def parse_gcc_errors(stderr: str) -> list[CompileError]:
    """Parse compilation error list from GCC stderr."""
    errors: list[CompileError] = []
    pattern = re.compile(
        r"^(.+?):(\d+):(\d+):\s+(error|warning):\s+(.+)$", re.MULTILINE
    )
    for m in pattern.finditer(stderr):
        errors.append(CompileError(
            file=m.group(1), line=int(m.group(2)), column=int(m.group(3)),
            severity=m.group(4), message=m.group(5),
        ))
    if not errors and stderr.strip():
        errors.append(CompileError(file="", line=0, column=0, message=stderr.strip()))
    return errors


# ========== Compile error pattern classification (migrated from copy) ==========

ERROR_PATTERNS: dict[str, dict[str, dict[str, Any]]] = {
    'preprocess': {
        'missing_header': {
            'pattern': r"fatal error:\s*(.+?):\s*No such file or directory",
            'extract': ['header'],
            'suggestion': "Add missing header file or fix include path",
        },
        'unterminated_if': {
            'pattern': r"error:\s*unterminated\s*#(if|ifdef|ifndef)",
            'extract': ['directive'],
            'suggestion': "Add matching #endif directive",
        },
        'endif_without_if': {
            'pattern': r"error:\s*#endif\s*without\s*#if",
            'extract': [],
            'suggestion': "Remove extra #endif or add missing #if/#ifdef/#ifndef",
        },
        'macro_args_mismatch': {
            'pattern': r"error:\s*macro\s*['\"](\w+)['\"]\s*passed\s*(\d+)\s*arguments,\s*but\s*takes\s*(?:just\s*)?(\d+)",
            'extract': ['macro', 'passed', 'expected'],
            'suggestion': "Fix macro argument count",
        },
        'invalid_preprocessing_directive': {
            'pattern': r"error:\s*invalid\s*preprocessing\s*directive\s*#(\w+)",
            'extract': ['directive'],
            'suggestion': "Use valid preprocessor directive",
        },
    },
    'compile_syntax': {
        'expected_semicolon': {
            'pattern': r"error:\s*expected\s*['\"];['\"]\s*(?:before|after|at end)",
            'extract': [],
            'suggestion': "Add missing semicolon",
        },
        'expected_brace': {
            'pattern': r"error:\s*expected\s*['\"]([{}])['\"]\s*(?:before|after|at)",
            'extract': ['brace'],
            'suggestion': "Add missing brace",
        },
        'expected_paren': {
            'pattern': r"error:\s*expected\s*['\"]\)['\"]\s*(?:before|after)",
            'extract': [],
            'suggestion': "Add missing closing parenthesis",
        },
        'unterminated_string': {
            'pattern': r"error:\s*(?:missing\s*terminating|unterminated)\s*['\"]?\s*character",
            'extract': [],
            'suggestion': "Close string literal with matching quote",
        },
        'stray_character': {
            'pattern': r"error:\s*stray\s*['\"\\](.)['\"] in program",
            'extract': ['char'],
            'suggestion': "Remove invalid character from source",
        },
    },
    'compile_semantic': {
        'undeclared_identifier': {
            'pattern': r"error:\s*['\"](\w+)['\"]\s*(?:was not|undeclared|has not been)\s*declared",
            'extract': ['symbol'],
            'suggestion': "Declare variable/function before use or add missing #include",
        },
        'type_mismatch': {
            'pattern': r"error:\s*(?:invalid conversion|cannot convert)\s*from\s*['\"](.+?)['\"]\s*to\s*['\"](.+?)['\"]",
            'extract': ['actual', 'expected'],
            'suggestion': "Fix type conversion or add explicit cast",
        },
        'redefinition': {
            'pattern': r"error:\s*redefinition\s*of\s*['\"](\w+)['\"]",
            'extract': ['symbol'],
            'suggestion': "Remove duplicate definition or use extern declaration",
        },
        'wrong_arg_count': {
            'pattern': r"error:\s*too\s*(few|many)\s*arguments\s*to\s*function\s*['\"](\w+)['\"]",
            'extract': ['count_issue', 'function'],
            'suggestion': "Fix function argument count",
        },
        'implicit_declaration': {
            'pattern': r"(?:error|warning):\s*implicit\s*declaration\s*of\s*function\s*['\"](\w+)['\"]",
            'extract': ['function'],
            'suggestion': "Add function declaration or #include appropriate header",
        },
        'no_member': {
            'pattern': r"error:\s*['\"](?:struct|class)\s*(\w+)['\"]\s*has\s*no\s*member\s*named\s*['\"](\w+)['\"]",
            'extract': ['struct', 'member'],
            'suggestion': "Fix member name or add member to struct/class",
        },
        'incomplete_type': {
            'pattern': r"error:\s*(?:invalid\s*use\s*of\s*)?incomplete\s*type\s*['\"](?:struct|class)?\s*(\w+)['\"]",
            'extract': ['type'],
            'suggestion': "Provide complete type definition or #include header with definition",
        },
    },
    'link': {
        'undefined_reference': {
            'pattern': r"undefined\s*reference\s*to\s*[`'\"](.+?)[`'\"]",
            'extract': ['symbol'],
            'suggestion': "Add missing function/variable definition or link required library",
        },
        'multiple_definition': {
            'pattern': r"multiple\s*definition\s*of\s*[`'\"](.+?)[`'\"]",
            'extract': ['symbol'],
            'suggestion': "Remove duplicate definition, use 'inline' keyword, or use extern declaration",
        },
        'cannot_find_library': {
            'pattern': r"cannot\s*find\s*-l(\w+)",
            'extract': ['library'],
            'suggestion': "Install library or fix library path (-L option)",
        },
        'undefined_vtable': {
            'pattern': r"undefined\s*reference\s*to\s*[`'\"]vtable\s*for\s*(\w+)[`'\"]",
            'extract': ['class'],
            'suggestion': "Implement all virtual functions declared in class",
        },
    },
}


def parse_compile_error(error_line: str) -> Optional[ClassifiedCompileError]:
    """Parse single-line compiler output into structured ClassifiedCompileError."""
    file_loc_match = re.match(r'^(.+?):(\d+):(?:(\d+):)?\s*(.+)$', error_line)
    file_path = None
    line_num = None
    col_num = None

    if file_loc_match:
        file_path = file_loc_match.group(1)
        line_num = int(file_loc_match.group(2))
        col_num = int(file_loc_match.group(3)) if file_loc_match.group(3) else None

    for stage, patterns in ERROR_PATTERNS.items():
        for error_type, pattern_info in patterns.items():
            match = re.search(pattern_info['pattern'], error_line, re.IGNORECASE)
            if match:
                error = ClassifiedCompileError(
                    stage=stage.split('_')[0],
                    error_type=error_type,
                    message=error_line,
                    file=file_path,
                    line=line_num,
                    column=col_num,
                    suggestion=pattern_info.get('suggestion'),
                )
                extract_fields = pattern_info.get('extract', [])
                groups = match.groups()
                for i, fld in enumerate(extract_fields):
                    if i < len(groups) and groups[i]:
                        if fld in ('symbol', 'function', 'class', 'macro', 'header'):
                            error.symbol = groups[i]
                        elif fld == 'expected':
                            error.expected = groups[i]
                        elif fld == 'actual':
                            error.actual = groups[i]
                return error
    return None


def classify_compile_errors(
    error_lines: list[str],
) -> dict[str, list[ClassifiedCompileError]]:
    """Classify compiler output lines into preprocess / compile / link / unknown."""
    classified: dict[str, list[ClassifiedCompileError]] = {
        'preprocess': [],
        'compile': [],
        'link': [],
        'unknown': [],
    }
    for line in error_lines:
        error = parse_compile_error(line)
        if error:
            classified[error.stage].append(error)
        elif 'error' in line.lower() or 'undefined' in line.lower():
            classified['unknown'].append(ClassifiedCompileError(
                stage='unknown',
                error_type='unclassified',
                message=line,
            ))
    return classified

def parse_test_results(stdout: str) -> tuple[int, list[str]]:
    """Parse test count and failed case list from GTest stdout."""
    total = 0
    failed: list[str] = []
    m = re.search(r"\[\s*PASSED\s*\]\s*(\d+)", stdout)
    if m:
        total += int(m.group(1))
    for fm in re.finditer(r"\[\s*FAILED\s*\]\s+(\S+)", stdout):
        name = fm.group(1)
        # Skip summary lines such as "[  FAILED  ] 4 tests, listed below:" —
        # real case entries are suite-qualified (Suite.TestName).
        if "." not in name or name in failed:
            continue
        failed.append(name)
        total += 1
    return total, failed


# ========== Coverage parsing ==========

def parse_coverage_from_output(test_output: str, source_files: list[str]) -> float:
    """Parse line coverage percentage from gcov/gtest stdout, return 0.0 on parse failure."""
    # gcov format: "Lines executed:85.71% of 42"
    m = re.search(r"Lines executed:(\d+(?:\.\d+)?)%", test_output)
    if m:
        return float(m.group(1))
    # lcov format: "lines......: 82.3%"
    m = re.search(r"lines[.\s]+:\s*(\d+(?:\.\d+)?)%", test_output)
    if m:
        return float(m.group(1))
    return 0.0


def parse_branch_coverage_from_output(test_output: str) -> float:
    """
    Parse branch coverage percentage from gcov/lcov stdout.
    gcov format: "Branches executed:75.00% of 44"
    lcov format: "branches....: 75.3% (33 of 44 branches)"
    Returns 0.0 on parse failure.
    """
    # gcov
    m = re.search(r"Branches executed:(\d+(?:\.\d+)?)%", test_output)
    if m:
        return float(m.group(1))
    # lcov
    m = re.search(r"branches[.\s]+:\s*(\d+(?:\.\d+)?)%", test_output)
    if m:
        return float(m.group(1))
    return 0.0


def parse_function_coverage_from_output(test_output: str) -> float:
    """
    Parse function coverage percentage from gcov/lcov stdout.
    gcov format: "Calls executed:90.00% of 20"
    lcov format: "functions....: 88.5% (9 of 10 functions)"
    Returns 0.0 on parse failure.
    """
    # gcov
    m = re.search(r"Calls executed:(\d+(?:\.\d+)?)%", test_output)
    if m:
        return float(m.group(1))
    # lcov
    m = re.search(r"functions[.\s]+:\s*(\d+(?:\.\d+)?)%", test_output)
    if m:
        return float(m.group(1))
    return 0.0


# ========== Code block extraction ==========

def extract_code_block(text: str) -> Optional[str]:
    """Extract code block content from LLM response."""
    match = re.search(r"```(?:cpp|c|cxx)?\n(.*?)```", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None


def extract_named_code_blocks(text: str) -> dict[str, str]:
    """Extract multiple code blocks with filenames from LLM response.

    Recognize two naming conventions:
    1. fence line with filename: ```cpp tc-hal-pwr.cpp
    2. first-line comment with filename: // tc-hal-pwr.cpp or @file tc-hal-pwr.cpp

    Returns:
        dict: filename -> code content. Fallback to {"_default": first block} when no named block.
    """
    blocks: dict[str, str] = {}

    pattern = re.compile(
        r"```(?:cpp|c|cxx|c\+\+)?(?:\s+([\w\-\.]+\.[ch](?:pp)?))?",
    )
    # Find all ``` start and end positions
    fence_starts = list(pattern.finditer(text))
    fence_ends = [m.start() for m in re.finditer(r"```\s*(?:\n|$)", text)
                  if not re.match(r"```(?:cpp|c|cxx|c\+\+)", text[m.start():])]

    for i, start_match in enumerate(fence_starts):
        fence_filename = start_match.group(1)
        content_start = start_match.end()
        # Skip leading newline
        if content_start < len(text) and text[content_start] == '\n':
            content_start += 1

        # Find corresponding end fence
        end_pos = None
        for ep in fence_ends:
            if ep > start_match.start():
                end_pos = ep
                break
        if end_pos is None:
            continue

        content = text[content_start:end_pos].strip()
        if not content:
            continue

        # Check filename in first-line comment
        first_line = content.split('\n', 1)[0].strip()
        comment_name = None
        m = re.match(
            r'^(?://|/\*\*?\s*@file\s+|\*\s*@file\s+|/\*\s*)\s*([\w\-\.]+\.[ch](?:pp)?)',
            first_line,
        )
        if m:
            comment_name = m.group(1)

        name = fence_filename or comment_name
        if name:
            blocks[name] = content
        elif "_default" not in blocks:
            blocks["_default"] = content

    # If regex matches no blocks, use extract_code_block as fallback
    if not blocks:
        single = extract_code_block(text)
        if single:
            blocks["_default"] = single

    return blocks


# ========== Regex AST parsing ==========

def parse_functions_regex(content: str) -> list[dict]:
    """Regex fallback: extract function declarations from C source."""
    pattern = re.compile(
        r"(?:[\w\s\*]+?)\s+(\w+)\s*\(([^)]*)\)\s*\{"
    )
    results = []
    for m in pattern.finditer(content):
        name = m.group(1)
        if name not in ("if", "for", "while", "switch", "return"):
            results.append({
                "name": name,
                "signature": m.group(0).split("{")[0].strip(),
                "line": content[: m.start()].count("\n") + 1,
                "return_type": "",
            })
    return results


def parse_calls_regex(content: str) -> list[str]:
    """Regex fallback: extract function calls from C source."""
    return re.findall(r"\b(\w+)\s*\(", content)


# ========== Layer inference ==========

def infer_layer_from_paths(
    source_files: list[str],
    functions: list[dict],
) -> str:
    """Infer architecture layer from file path and function names。

    Supports BSP layer (hal / driver) and Midware layer (midware_controller / midware_driver)。
    """
    combined = " ".join(source_files).replace("\\", "/").lower()

    if "/midware/controllers/" in combined:
        return "midware_controller"
    if "/midware/drivers/" in combined:
        return "midware_driver"
    if "/midware/" in combined:
        return "midware_controller"

    if any(kw in combined for kw in ("hal", "hardware")):
        return "hal"
    if any(kw in combined for kw in ("controller", "ctrl")):
        return "midware_controller"
    if any(kw in combined for kw in ("driver", "drv")):
        return "driver"
    if any(kw in combined for kw in ("app", "application")):
        return "app"

    func_names = " ".join(f.get("name", "") for f in functions).lower()
    if any(kw in func_names for kw in ("hal_", "gpio_", "uart_", "spi_", "i2c_")):
        return "hal"
    if any(kw in func_names for kw in ("drv_", "driver_")):
        return "driver"
    return "hal"


# ========== LibClang AST analysis ==========

def analyze_source_ast(source_path: str, content: str = "") -> SourceAnalysis:
    """Use libclang to analyze source AST structure, fallback to regex parsing。"""
    functions: list[dict] = []
    dependencies: list[str] = []
    external_calls: list[str] = []
    includes: list[str] = []

    try:
        import clang.cindex as clang  # type: ignore
        index = clang.Index.create()
        tu = index.parse(
            source_path,
            unsaved_files=[(source_path, content)] if content else None,
            args=["-x", "c", "-std=c99"],
        )
        for node in tu.cursor.walk_preorder():
            if node.kind == clang.CursorKind.FUNCTION_DECL and node.is_definition():
                functions.append({
                    "name": node.spelling,
                    "signature": node.displayname,
                    "line": node.location.line,
                    "return_type": node.result_type.spelling,
                })
            elif node.kind == clang.CursorKind.CALL_EXPR:
                callee = node.referenced.spelling if node.referenced else node.spelling
                if callee:
                    external_calls.append(callee)
            elif node.kind == clang.CursorKind.INCLUSION_DIRECTIVE:
                includes.append(node.spelling)
                dependencies.append(node.spelling)
    except (ImportError, Exception):
        # libclang unavailable or parse failed, fallback to regex parsing
        functions = parse_functions_regex(content or "")
        includes = re.findall(r'#include\s+[<"]([^>"]+)[>"]', content or "")
        dependencies = includes
        external_calls = parse_calls_regex(content or "")

    layer_hint = infer_layer_from_paths([source_path], functions)
    return SourceAnalysis(
        functions=functions,
        dependencies=list(set(dependencies)),
        external_calls=list(set(external_calls)),
        includes=includes,
        layer_hint=layer_hint,
    )


# ========== QBS build error parsing ==========

_LINKER_KEYWORDS = [
    "undefined reference",
    "multiple definition",
    "first defined here",
    "collect2",
    "ld returned",
    "cannot find -l",
    "undefined symbol",
    "duplicate symbol",
]


def detect_truncation(output: str) -> bool:
    """Detect if LLM output is truncated。

    Check conditions：
    - Unclosed code block fence (``` count is odd)
    - Last line is incomplete code (missing semicolon, braces, etc.)
    - Output suddenly ends in the middle of a code block
    """
    if not output or not output.strip():
        return True

    # Check for unclosed code block fence
    fence_count = len(re.findall(r'^```', output, re.MULTILINE))
    if fence_count % 2 != 0:
        return True

    # Check if ends in the middle of a code block
    lines = output.rstrip().split('\n')
    if not lines:
        return True

    last_line = lines[-1].strip()

    # If the last line is code (not  ``` or empty line), it may be truncated
    in_code_block = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('```'):
            in_code_block = not in_code_block
    if in_code_block:
        return True

    # Check patterns for sudden ending (keep only explicit truncation signals to avoid false positives)
    truncation_patterns = [
        r'//\s*\.\.\.\s*$',                        # ends with // ... (truncated comment)
        r'/\*\s*$',                                 # starts with unclosed comment
        r'^\s*#include\s*$',                        # incomplete #include
        r'^\s*(?:if|else|for|while)\s*\(\s*$',      # incomplete control flow
        r'^\s*\w+\s*\(\s*$',                        # function call with unclosed parenthesis
    ]
    if last_line and not last_line.startswith('```'):
        for pat in truncation_patterns:
            if re.match(pat, last_line) and len(last_line) > 3:
                if len(output) > 500:
                    return True

    return False


def validate_parsed_completeness(
    parsed_content: dict,
    min_sizes: Optional[dict] = None,
) -> tuple[bool, str]:
    """Validate parsed completeness。

    Args:
        parsed_content: parsed content dictionary (test_impl, test_header, mock_impl, mock_header)
        min_sizes: minimum character count per file, defaults to test_impl>=100, test_header>=50, mock_impl>=50, mock_header>=50

    Returns:
        (is_complete, missing_file_pattern)
        missing_file_pattern: "complete" / "missing_mocks_only" / "missing_tests_only" / "missing_all" / "partial"
    """
    if min_sizes is None:
        min_sizes = {
            'test_impl': 100,
            'test_header': 50,
            'mock_impl': 50,
            'mock_header': 50,
        }

    missing_files: list[str] = []
    for file_key, min_size in min_sizes.items():
        content = parsed_content.get(file_key, '')
        if not content or len(content) < min_size:
            missing_files.append(file_key)
            continue
        # Structure validation: check if key markers exist
        if file_key == 'test_impl' and 'TEST_F(' not in content and 'TEST(' not in content:
            missing_files.append(file_key)
        elif file_key == 'test_header' and '#ifndef' not in content and '#pragma once' not in content:
            missing_files.append(file_key)
        elif file_key == 'mock_header' and 'MOCK_METHOD' not in content and 'class ' not in content and 'fff.h' not in content:
            missing_files.append(file_key)

    if not missing_files:
        return True, "complete"

    missing_test = [f for f in missing_files if 'test_' in f]
    missing_mock = [f for f in missing_files if 'mock_' in f]

    if len(missing_files) >= 4:
        return False, "missing_all"
    if missing_mock and not missing_test:
        return False, "missing_mocks_only"
    if missing_test and not missing_mock:
        return False, "missing_tests_only"
    return False, "partial"


def parse_qbs_warnings_structured(output: str) -> list[CompileError]:
    """Parse QBS compiler warnings with source locations and note context."""
    if not output:
        return []

    ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
    lines = ansi_escape.sub("", output).replace("\r\n", "\n").replace("\r", "\n").split("\n")
    warnings: list[CompileError] = []
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        match = re.match(r"^(.+?):(\d+):(\d+):\s*warning:\s*(.+)$", line)
        if not match:
            index += 1
            continue
        context: list[str] = []
        cursor = index + 1
        while cursor < len(lines) and cursor < index + 5:
            candidate = lines[cursor].strip()
            if re.match(r"^\S+:\d+:\d+:\s*note:", candidate):
                context.append(candidate)
                cursor += 1
            elif candidate and context and not re.match(r"^\S+:\d+:\d+:", candidate):
                context[-1] += " " + candidate
                cursor += 1
            else:
                break
        message = match.group(4).strip()
        if context:
            message += "\n" + "\n".join(context)
        warnings.append(
            CompileError(
                file=match.group(1).replace("\\", "/"),
                line=int(match.group(2)),
                column=int(match.group(3)),
                message=message,
                severity="warning",
            )
        )
        index = cursor
    return warnings


def parse_qbs_build_errors(output: str) -> list[str]:
    """Parse QBS build stderr, keep context and linker errors.

    Unlike ``parse_gcc_errors``, this function keeps ``note:`` lines,
    ``first defined here`` lines and linker context, returns complete error blocks.
    """
    errors: list[str] = []
    lines = output.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        line_lower = line.lower()
        # QBS prefixes the failed compiler command with ERROR as well. It is
        # context, not a diagnostic, and can hide the root cause behind -I flags.
        if re.match(r"^\s*ERROR:\s+.*(?:gcc|g\+\+|clang(?:\+\+)?|cc|c\+\+)(?:\.exe)?[\"']?\s+-", line, re.IGNORECASE):
            i += 1
            continue
        if re.match(r"^\s*ERROR:\s+.+:\s+In function\s+", line, re.IGNORECASE):
            i += 1
            continue
        is_error = (
            "error:" in line_lower
            or "fatal error:" in line_lower
            or re.search(r":\d+:\d+: error:", line) is not None
            or any(kw in line_lower for kw in _LINKER_KEYWORDS)
        )
        if is_error:
            block = [line.strip()]
            j = i + 1
            while j < len(lines) and j < i + 8:
                nxt = lines[j].strip()
                nxt_lower = nxt.lower()
                if "note:" in nxt_lower:
                    block.append(f"    {nxt}")
                elif "required from" in nxt_lower:
                    block.append(f"    {nxt}")
                elif "first defined here" in nxt_lower or "first defined in" in nxt_lower:
                    block.append(f"    {nxt}")
                elif nxt.startswith("^") or nxt.startswith("|"):
                    block.append(f"    {nxt}")
                elif ".o:" in nxt or ".obj:" in nxt:
                    block.append(f"    {nxt}")
                elif "error:" in nxt_lower or "warning:" in nxt_lower or not nxt:
                    break
                j += 1
            errors.append("\n".join(block))
        i += 1
    return errors if errors else ([output.strip()] if output.strip() else [])


def parse_qbs_build_errors_structured(output: str) -> dict[str, Any]:
    """Structured classified QBS build errors (preprocess / compile / link / unknown)。"""
    raw_errors = parse_qbs_build_errors(output)
    result: dict[str, Any] = {
        "raw_errors": raw_errors,
        "errors": [],
        "by_stage": {"preprocess": [], "compile": [], "link": [], "unknown": []},
        "summary": {
            "total": 0,
            "preprocess_count": 0,
            "compile_count": 0,
            "link_count": 0,
            "multiple_definitions": [],
            "undefined_references": [],
            "missing_headers": [],
        },
    }
    for error_text in raw_errors:
        parsed = parse_compile_error(error_text)
        if parsed:
            result["errors"].append(parsed)
            result["by_stage"][parsed.stage].append(parsed)
            if parsed.error_type == "multiple_definition" and parsed.symbol:
                if parsed.symbol not in result["summary"]["multiple_definitions"]:
                    result["summary"]["multiple_definitions"].append(parsed.symbol)
            elif parsed.error_type == "undefined_reference" and parsed.symbol:
                if parsed.symbol not in result["summary"]["undefined_references"]:
                    result["summary"]["undefined_references"].append(parsed.symbol)
            elif parsed.error_type == "missing_header" and parsed.symbol:
                if parsed.symbol not in result["summary"]["missing_headers"]:
                    result["summary"]["missing_headers"].append(parsed.symbol)
        else:
            error_lower = error_text.lower()
            if "multiple definition" in error_lower:
                m = re.search(r"multiple\s*definition\s*of\s*[`'\"](.+?)[`'\"]", error_text)
                sym = m.group(1) if m else None
                if sym and sym not in result["summary"]["multiple_definitions"]:
                    result["summary"]["multiple_definitions"].append(sym)
                result["by_stage"]["link"].append(ClassifiedCompileError(
                    stage="link", error_type="multiple_definition",
                    message=error_text, symbol=sym,
                    suggestion="Remove duplicate definition or use 'inline' keyword",
                ))
            elif "undefined reference" in error_lower:
                m = re.search(r"undefined\s*reference\s*to\s*[`'\"](.+?)[`'\"]", error_text)
                sym = m.group(1) if m else None
                if sym and sym not in result["summary"]["undefined_references"]:
                    result["summary"]["undefined_references"].append(sym)
                result["by_stage"]["link"].append(ClassifiedCompileError(
                    stage="link", error_type="undefined_reference",
                    message=error_text, symbol=sym,
                    suggestion="Add missing mock function implementation",
                ))
            elif "no such file" in error_lower:
                m = re.search(r"fatal error:\s*(.+?):\s*No such file", error_text)
                hdr = m.group(1) if m else None
                if hdr and hdr not in result["summary"]["missing_headers"]:
                    result["summary"]["missing_headers"].append(hdr)
                result["by_stage"]["preprocess"].append(ClassifiedCompileError(
                    stage="preprocess", error_type="missing_header",
                    message=error_text, symbol=hdr,
                    suggestion="Add missing header file or fix include path",
                ))
            else:
                result["by_stage"]["unknown"].append(ClassifiedCompileError(
                    stage="unknown", error_type="unclassified", message=error_text,
                ))

    result["summary"]["total"] = len(raw_errors)
    result["summary"]["preprocess_count"] = len(result["by_stage"]["preprocess"])
    result["summary"]["compile_count"] = len(result["by_stage"]["compile"])
    result["summary"]["link_count"] = len(result["by_stage"]["link"])
    return result
