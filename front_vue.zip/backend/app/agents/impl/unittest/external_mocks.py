"""
@file external_mocks.py
@author caoshwen
@brief External mock dependency manager for HAL layer.

Detects cross-module HAL calls in source code and manages creation of
GMock-based mock files for external dependencies.

@version 3.2
@date 2026-03-10
"""

import re
from pathlib import Path
from typing import Any, Dict, List

from loguru import logger


# ---------------------------------------------------------------------------
# Platform helpers
# ---------------------------------------------------------------------------

def get_platform_prefix(platform: str) -> str:
    """
    Get the naming prefix for a platform (used in mock file naming).

    Args:
        platform: Platform name (stm32u3, rtl8722fam, nrf52, etc.)

    Returns:
        Platform prefix string.
    """
    platform_lower = platform.lower()

    if "stm32" in platform_lower:
        return "stm32"
    if "rtl" in platform_lower or "realtek" in platform_lower:
        return "rtl"
    if "nrf" in platform_lower or "nordic" in platform_lower:
        return "nrf"

    # Fallback: take up to 6 chars before common numeric splits
    return platform_lower.split("u")[0].split("5")[0].split("8")[0][:6]


def get_platform_class_name(platform: str) -> str:
    """
    Get the class-name prefix for a platform (capitalised form).

    Args:
        platform: Platform name.

    Returns:
        Capitalised platform prefix (e.g. ``Stm32``, ``Rtl``, ``Nrf``).
    """
    return get_platform_prefix(platform).capitalize()


# ---------------------------------------------------------------------------
# HAL call analysis
# ---------------------------------------------------------------------------

# (module_name, regex_pattern)
_HAL_MODULE_PATTERNS: list[tuple[str, str]] = [
    ("rcc",    r"\bHAL_RCC(?:Ex)?_\w+\s*\("),
    ("gpio",   r"\bHAL_GPIO_\w+\s*\("),
    ("uart",   r"\bHAL_UART(?:Ex)?_\w+\s*\("),
    ("i2c",    r"\bHAL_I2C(?:Ex)?_\w+\s*\("),
    ("spi",    r"\bHAL_SPI(?:Ex)?_\w+\s*\("),
    ("tim",    r"\bHAL_TIM(?:Ex)?_\w+\s*\("),
    ("timer",  r"\bHAL_TIM(?:Ex)?_\w+\s*\("),
    ("adc",    r"\bHAL_ADC(?:Ex)?_\w+\s*\("),
    ("dma",    r"\bHAL_DMA(?:Ex)?_\w+\s*\("),
    ("rtc",    r"\bHAL_RTC(?:Ex)?_\w+\s*\("),
    ("pwr",    r"\bHAL_PWR(?:Ex)?_\w+\s*\("),
    ("flash",  r"\bHAL_FLASH(?:Ex)?_\w+\s*\("),
    ("cortex", r"\bHAL_NVIC_\w+\s*\("),
    ("cortex", r"\bHAL_SYSTICK_\w+\s*\("),
    ("exti",   r"\bHAL_EXTI_\w+\s*\("),
    ("wdg",    r"\bHAL_(?:I)?WDG_\w+\s*\("),
    ("usb",    r"\bHAL_(?:PCD|HCD)_\w+\s*\("),
    # LL (Low-Level) functions
    ("rcc",    r"\bLL_RCC_\w+\s*\("),
    ("gpio",   r"\bLL_GPIO_\w+\s*\("),
    ("rtc",    r"\bLL_RTC_\w+\s*\("),
    ("tim",    r"\bLL_TIM_\w+\s*\("),
    ("dma",    r"\bLL_DMA_\w+\s*\("),
    ("exti",   r"\bLL_EXTI_\w+\s*\("),
    ("pwr",    r"\bLL_PWR_\w+\s*\("),
]

# Midware-level dependency patterns: driver_*, hal_* (project wrappers), FreeRTOS
_MIDWARE_DEPENDENCY_PATTERNS: list[tuple[str, str]] = [
    # Project HAL wrappers (lowercase hal_xxx_action)
    ("hal-gpio",    r"\bhal_gpio_\w+\s*\("),
    ("hal-uart",    r"\bhal_uart_\w+\s*\("),
    ("hal-i2c",     r"\bhal_i2c_\w+\s*\("),
    ("hal-spi",     r"\bhal_spi_\w+\s*\("),
    ("hal-tim",     r"\bhal_tim(?:er)?_\w+\s*\("),
    ("hal-adc",     r"\bhal_adc_\w+\s*\("),
    ("hal-pwr",     r"\bhal_pwr_\w+\s*\("),
    ("hal-rtc",     r"\bhal_rtc_\w+\s*\("),
    ("hal-flash",   r"\bhal_flash_\w+\s*\("),
    ("hal-wdg",     r"\bhal_wdg_\w+\s*\("),
    ("hal-err",     r"\bhal_err_\w+"),
    # BSP driver calls (driver_xxx_action)
    ("driver-charger",  r"\bdriver_charger_\w+\s*\("),
    ("driver-battery",  r"\bdriver_battery_\w+\s*\("),
    ("driver-gauge",    r"\bdriver_gauge_\w+\s*\("),
    ("driver-led",      r"\bdriver_led_\w+\s*\("),
    ("driver-motor",    r"\bdriver_motor_\w+\s*\("),
    ("driver-sensor",   r"\bdriver_sensor_\w+\s*\("),
    ("driver-flash",    r"\bdriver_flash_\w+\s*\("),
    ("driver-eeprom",   r"\bdriver_eeprom_\w+\s*\("),
    ("driver-display",  r"\bdriver_display_\w+\s*\("),
    ("driver-nfc",      r"\bdriver_nfc_\w+\s*\("),
    ("driver-ble",      r"\bdriver_ble_\w+\s*\("),
    # Generic driver pattern (catches driver_xxx_action not listed above)
    ("driver",          r"\bdriver_(\w+?)_\w+\s*\("),
    # Controller calls (controller_xxx_action)
    ("controller",      r"\bcontroller_(\w+?)_\w+\s*\("),
    # FreeRTOS calls
    ("freertos",    r"\bx(?:Task|Timer|Queue|Semaphore|Mutex|EventGroup)\w+\s*\("),
    ("freertos",    r"\bv(?:Task|Timer|Queue|Semaphore)\w+\s*\("),
    ("freertos",    r"\bpv(?:Port|Task)\w+\s*\("),
    ("freertos",    r"\btaskENTER_CRITICAL\s*\("),
    ("freertos",    r"\btaskEXIT_CRITICAL\s*\("),
    ("freertos",    r"\bportYIELD\s*\("),
]


def analyze_source_external_hal_calls(
    source_code: str,
    current_module: str,
) -> Dict[str, List[str]]:
    """
    Regex-based cross-module HAL call detection.

    Scans *source_code* for ``HAL_*`` / ``LL_*`` function calls that belong
    to modules other than *current_module*.

    Args:
        source_code: C source content to analyse.
        current_module: Module being tested (e.g. ``"rtc"``, ``"gpio"``).

    Returns:
        ``{module_name: [function_names]}`` excluding *current_module*.
    """
    current_lower = current_module.lower()
    external_calls: Dict[str, List[str]] = {}

    for module_name, pattern in _HAL_MODULE_PATTERNS:
        # Skip the module under test
        if module_name == current_lower:
            continue
        # tim / timer are aliases
        if current_lower in ("tim", "timer") and module_name in ("tim", "timer"):
            continue

        matches = re.findall(pattern, source_code)
        if not matches:
            continue

        func_names = list({m.strip().rstrip("(").strip() for m in matches})
        external_calls.setdefault(module_name, []).extend(func_names)

    # Deduplicate per module
    for mod in external_calls:
        external_calls[mod] = list(set(external_calls[mod]))

    if external_calls:
        logger.info(f"   Found external HAL calls: {dict(external_calls)}")

    return external_calls


def analyze_source_midware_calls(
    source_code: str,
    current_module: str,
) -> Dict[str, List[str]]:
    """
    Regex-based dependency detection for midware layer code.

    Scans *source_code* for ``driver_*``, ``hal_*`` (project wrappers),
    ``controller_*``, and FreeRTOS function calls that belong to modules
    other than *current_module*.

    Args:
        source_code: C source content to analyse.
        current_module: Module being tested (e.g. ``"charger"``, ``"battery"``).

    Returns:
        ``{dependency_name: [function_names]}`` excluding *current_module*.
    """
    current_lower = current_module.lower()
    external_calls: Dict[str, List[str]] = {}

    for dep_name, pattern in _MIDWARE_DEPENDENCY_PATTERNS:
        matches = re.findall(pattern, source_code)
        if not matches:
            continue

        # For generic driver/controller patterns, the regex captures the sub-module
        if dep_name == "driver":
            for sub_module in set(matches):
                if sub_module == current_lower:
                    continue
                key = f"driver-{sub_module}"
                full_matches = re.findall(
                    rf"\bdriver_{re.escape(sub_module)}_\w+\s*\(", source_code,
                )
                func_names = list({m.strip().rstrip("(").strip() for m in full_matches})
                external_calls.setdefault(key, []).extend(func_names)
            continue

        if dep_name == "controller":
            for sub_module in set(matches):
                if sub_module == current_lower:
                    continue
                key = f"controller-{sub_module}"
                full_matches = re.findall(
                    rf"\bcontroller_{re.escape(sub_module)}_\w+\s*\(", source_code,
                )
                func_names = list({m.strip().rstrip("(").strip() for m in full_matches})
                external_calls.setdefault(key, []).extend(func_names)
            continue

        # Skip if the dependency matches the current module
        dep_module = dep_name.split("-")[-1] if "-" in dep_name else dep_name
        if dep_module == current_lower:
            continue

        func_names = list({m.strip().rstrip("(").strip() for m in matches})
        external_calls.setdefault(dep_name, []).extend(func_names)

    # Deduplicate per dependency
    for dep in external_calls:
        external_calls[dep] = list(set(external_calls[dep]))

    if external_calls:
        logger.info(f"   Found midware dependency calls: {dict(external_calls)}")

    return external_calls


# ---------------------------------------------------------------------------
# Mock directory helpers
# ---------------------------------------------------------------------------

def _resolve_mock_dirs(
    project_root: str, platform: str
) -> tuple[Path | None, Path | None]:
    """Return (mock_inc_dir, mock_src_dir) or (None, None)."""
    mock_base = Path(project_root) / "libs" / "platformkit" / "tests" / "mocks"
    platform_lower = platform.lower()

    dirs = list(mock_base.glob(f"*{platform_lower}*/platform-mocks"))
    if not dirs:
        dirs = list(mock_base.glob("stm32*/platform-mocks"))
    if not dirs:
        return None, None

    return dirs[0] / "inc", dirs[0] / "src"


# ---------------------------------------------------------------------------
# Find missing mock files
# ---------------------------------------------------------------------------

def find_missing_mock_files(
    external_calls: Dict[str, List[str]],
    project_root: str,
    platform: str,
) -> List[Dict[str, Any]]:
    """
    Check which external mock files don't exist yet.

    Args:
        external_calls: Output of :func:`analyze_source_external_hal_calls`.
        project_root: Firmware project root path.
        platform: Platform name (e.g. ``"stm32u3"``).

    Returns:
        List of dicts ``{module, functions, mock_header, mock_impl,
        mock_header_path, mock_impl_path, header_exists, impl_exists,
        platform_prefix}``.
    """
    if not external_calls:
        return []

    mock_inc_dir, mock_src_dir = _resolve_mock_dirs(project_root, platform)
    prefix = get_platform_prefix(platform)
    missing: List[Dict[str, Any]] = []

    for module, functions in external_calls.items():
        mock_header = f"mock-{prefix}-hal-{module}.h"
        mock_impl = f"mock-{prefix}-hal-{module}.cpp"

        header_exists = bool(mock_inc_dir and (mock_inc_dir / mock_header).exists())
        impl_exists = bool(mock_src_dir and (mock_src_dir / mock_impl).exists())

        if not header_exists or not impl_exists:
            missing.append({
                "module": module,
                "functions": functions,
                "mock_header": mock_header,
                "mock_impl": mock_impl,
                "mock_header_path": str(mock_inc_dir / mock_header) if mock_inc_dir else None,
                "mock_impl_path": str(mock_src_dir / mock_impl) if mock_src_dir else None,
                "header_exists": header_exists,
                "impl_exists": impl_exists,
                "platform_prefix": prefix,
            })
            logger.info(
                f"   Missing mock files for module '{module}': "
                f"header={'exists' if header_exists else 'MISSING'}, "
                f"impl={'exists' if impl_exists else 'MISSING'}"
            )

    return missing



# ---------------------------------------------------------------------------
# Extract HAL function signatures from vendor headers
# ---------------------------------------------------------------------------

def extract_hal_function_signatures(
    project_root: str,
    platform: str,
    module: str,
    function_names: List[str],
) -> List[Dict[str, Any]]:
    """
    Extract function signatures from vendor HAL headers.

    Args:
        project_root: Project root path.
        platform: Platform name.
        module: HAL module name (e.g. ``"rcc"``, ``"gpio"``).
        function_names: Functions to look up.

    Returns:
        List of ``{name, return_type, params, params_str, is_stub}`` dicts.
    """
    signatures: List[Dict[str, Any]] = []

    # Determine vendor HAL paths and header names based on platform
    platform_lower = platform.lower()

    if "stm32u5" in platform_lower:
        vendor_hal_paths = [
            Path(project_root) / "libs" / "sdk-stm32u5" / "STM32U5xx_HAL_Driver" / "Inc",
            Path(project_root) / "bsp" / "stm32u5" / "STM32CubeU5" / "Drivers" / "STM32U5xx_HAL_Driver" / "Inc",
            # Fallback to overwrite-inc for test mocks (project_root is already platformkit)
            Path(project_root) / "tests" / "mocks" / "stm32u5" / "overwrite-inc",
        ]
        header_names = [
            f"stm32u5xx_hal_{module}.h",
            f"stm32u5xx_hal_{module}_ex.h",
        ]
    elif "stm32u3" in platform_lower:
        vendor_hal_paths = [
            Path(project_root) / "libs" / "sdk-stm32u3" / "STM32U3xx_HAL_Driver" / "Inc",
            Path(project_root) / "bsp" / "stm32u3" / "STM32CubeU3" / "Drivers" / "STM32U3xx_HAL_Driver" / "Inc",
            # Fallback to overwrite-inc for test mocks (project_root is already platformkit)
            Path(project_root) / "tests" / "mocks" / "stm32u3" / "overwrite-inc",
        ]
        header_names = [
            f"stm32u3xx_hal_{module}.h",
            f"stm32u3xx_hal_{module}_ex.h",
        ]
    else:
        # Generic fallback for unknown platforms
        logger.warning(f"Unknown platform '{platform}', using generic STM32 paths")
        vendor_hal_paths = [
            Path(project_root) / "libs" / f"sdk-{platform_lower}" / f"STM32{platform_lower.upper()}_HAL_Driver" / "Inc",
            Path(project_root) / "bsp" / platform_lower / f"STM32Cube{platform_lower.upper()}" / "Drivers" / f"STM32{platform_lower.upper()}_HAL_Driver" / "Inc",
        ]
        header_names = [
            f"{platform_lower}_hal_{module}.h",
            f"{platform_lower}_hal_{module}_ex.h",
        ]

    header_content = ""
    for hal_path in vendor_hal_paths:
        if not hal_path.exists():
            continue
        for hname in header_names:
            hfile = hal_path / hname
            if hfile.exists():
                try:
                    header_content += hfile.read_text(encoding="utf-8", errors="ignore")
                except Exception as exc:
                    logger.debug(f"Failed to read {hfile}: {exc}")

    if not header_content:
        logger.warning(f"   Could not find vendor HAL header for module '{module}'")
        for fn in function_names:
            signatures.append({
                "name": fn,
                "return_type": "HAL_StatusTypeDef",
                "params": [("void*", "arg")],
                "params_str": "void *arg",
                "is_stub": True,
            })
        return signatures

    for fn in function_names:
        patterns = [
            rf"(HAL_StatusTypeDef|void|uint32_t|int32_t|uint8_t)\s+{re.escape(fn)}\s*\(([^)]*)\)\s*;",
            rf"(HAL_StatusTypeDef|void|uint32_t|int32_t|uint8_t)\s+{re.escape(fn)}\s*\(([^;]*?)\)\s*;",
        ]
        found = False
        for pat in patterns:
            match = re.search(pat, header_content, re.DOTALL)
            if not match:
                continue
            return_type = match.group(1)
            params_str = re.sub(r"\s+", " ", match.group(2)).strip()

            params: list[tuple[str, str]] = []
            if params_str and params_str != "void":
                for part in params_str.split(","):
                    part = part.strip()
                    pm = re.match(r"(.*?)\s*(\w+)\s*$", part)
                    if pm:
                        params.append((pm.group(1).strip(), pm.group(2).strip()))
                    else:
                        params.append((part, "arg"))

            signatures.append({
                "name": fn,
                "return_type": return_type,
                "params": params,
                "params_str": params_str if params_str else "void",
                "is_stub": False,
            })
            found = True
            break

        if not found:
            logger.debug(f"   Could not find signature for {fn}, using stub")
            signatures.append({
                "name": fn,
                "return_type": "HAL_StatusTypeDef",
                "params": [("void*", "arg")],
                "params_str": "void *arg",
                "is_stub": True,
            })

    return signatures



# ---------------------------------------------------------------------------
# Mock file content generation
# ---------------------------------------------------------------------------

def generate_mock_header_content(
    module_name: str,
    platform: str,
    function_signatures: List[Dict[str, Any]],
    class_name: str,
) -> str:
    """
    Generate a GMock header with ``MOCK_METHOD`` declarations.

    Args:
        module_name: HAL module (e.g. ``"rcc"``).
        platform: Platform name.
        function_signatures: Signature dicts from :func:`extract_hal_function_signatures`.
        class_name: Mock class name (e.g. ``"MockStm32HalRcc"``).

    Returns:
        Complete header file content as a string.
    """
    prefix = get_platform_prefix(platform)
    guard = f"MOCK_{prefix.upper()}_HAL_{module_name.upper()}_H"
    instance = f"{prefix}_{module_name}_mock"

    mock_methods: list[str] = []
    for sig in function_signatures:
        ptypes = ", ".join(pt for pt, _ in sig["params"]) if sig["params"] else ""
        if not ptypes or ptypes == "void":
            mock_methods.append(f"    MOCK_METHOD({sig['return_type']}, {sig['name']}, ());")
        else:
            mock_methods.append(f"    MOCK_METHOD({sig['return_type']}, {sig['name']}, ({ptypes}));")

    methods_block = "\n".join(mock_methods)

    from datetime import datetime
    date_str = datetime.now().strftime("%Y-%m-%d")

    return f'''/**
 * @file mock-{prefix}-hal-{module_name}.h
 * @author UnitTestAgent
 * @brief Mock declarations for STM32 HAL {module_name.upper()} module.
 *
 * @version 0.1
 * @date {date_str}
 *
 * @copyright Copyright (c) 2025 relivercao@gmail.com
 * All rights reserved.
 *
 * @note Auto-generated mock file for cross-module dependencies.
 *
 */

#ifndef {guard}
#define {guard}

#include <gmock/gmock.h>

extern "C" {{
#include "stm32u3xx_hal.h"
}}

/**
 * @brief Mock class for STM32 HAL {module_name.upper()} functions.
 *
 */
class {class_name} {{
public:
    virtual ~{class_name}() {{}}

{methods_block}
}};

extern {class_name} {instance};

#endif // {guard}
'''



def generate_mock_impl_content(
    module_name: str,
    platform: str,
    function_signatures: List[Dict[str, Any]],
    class_name: str,
) -> str:
    """
    Generate mock implementation with C wrapper functions.

    Args:
        module_name: HAL module (e.g. ``"rcc"``).
        platform: Platform name.
        function_signatures: Signature dicts from :func:`extract_hal_function_signatures`.
        class_name: Mock class name.

    Returns:
        Complete ``.cpp`` implementation content.
    """
    prefix = get_platform_prefix(platform)
    instance = f"{prefix}_{module_name}_mock"

    wrappers: list[str] = []
    for sig in function_signatures:
        ret = sig["return_type"]
        fn = sig["name"]
        params_str = sig["params_str"]

        if sig["params"] and params_str != "void":
            param_names = ", ".join(pn for _, pn in sig["params"])
        else:
            param_names = ""

        if ret == "void":
            wrappers.append(
                f"/**\n * @brief Mock wrapper for {fn}.\n *\n */\n"
                f"{ret} {fn}({params_str})\n{{\n"
                f"    {instance}.{fn}({param_names});\n}}"
            )
        else:
            wrappers.append(
                f"/**\n * @brief Mock wrapper for {fn}.\n *\n */\n"
                f"{ret} {fn}({params_str})\n{{\n"
                f"    return {instance}.{fn}({param_names});\n}}"
            )

    wrappers_block = "\n\n".join(wrappers)

    from datetime import datetime
    date_str = datetime.now().strftime("%Y-%m-%d")

    return f'''/**
 * @file mock-{prefix}-hal-{module_name}.cpp
 * @author UnitTestAgent
 * @brief Mock implementation for STM32 HAL {module_name.upper()} functions.
 *
 * @version 0.1
 * @date {date_str}
 *
 * @copyright Copyright (c) 2025 relivercao@gmail.com
 * All rights reserved.
 *
 * @note Auto-generated mock file for cross-module dependencies.
 *
 */

#include "mock-{prefix}-hal-{module_name}.h"

{class_name} {instance};

extern "C" {{

{wrappers_block}

}}
'''



# ---------------------------------------------------------------------------
# Create external mock files on disk
# ---------------------------------------------------------------------------

def create_external_mock_file(
    mock_info: Dict[str, Any],
    project_root: str,
    platform: str,
) -> Dict[str, Any]:
    """
    Create mock header and implementation files for an external HAL module.

    Args:
        mock_info: Dict from :func:`find_missing_mock_files`.
        project_root: Project root path.
        platform: Platform name.

    Returns:
        ``{success, header_path, impl_path, error}``.
    """
    result: Dict[str, Any] = {
        "success": False,
        "files_created": [],
        "module": mock_info["module"],
        "error": None,
    }

    module = mock_info["module"]
    functions = mock_info["functions"]
    prefix = mock_info["platform_prefix"]

    signatures = extract_hal_function_signatures(
        project_root, platform, module, functions
    )

    class_name = f"Mock{prefix.capitalize()}Hal{module.capitalize()}"

    header_content = generate_mock_header_content(
        module_name=module,
        platform=platform,
        function_signatures=signatures,
        class_name=class_name,
    )
    impl_content = generate_mock_impl_content(
        module_name=module,
        platform=platform,
        function_signatures=signatures,
        class_name=class_name,
    )

    try:
        mock_inc_dir, mock_src_dir = _resolve_mock_dirs(project_root, platform)
        if mock_inc_dir is None or mock_src_dir is None:
            result["error"] = f"Could not find platform mock directory for {platform}"
            return result

        mock_inc_dir.mkdir(parents=True, exist_ok=True)
        mock_src_dir.mkdir(parents=True, exist_ok=True)

        header_path = mock_inc_dir / mock_info["mock_header"]
        if not header_path.exists():
            header_path.write_text(header_content, encoding="utf-8")
            result["files_created"].append(str(header_path))
            logger.info(f"   Created mock header: {mock_info['mock_header']}")

        impl_path = mock_src_dir / mock_info["mock_impl"]
        if not impl_path.exists():
            impl_path.write_text(impl_content, encoding="utf-8")
            result["files_created"].append(str(impl_path))
            logger.info(f"   Created mock impl: {mock_info['mock_impl']}")

        result["success"] = len(result["files_created"]) > 0

    except Exception as exc:
        result["error"] = str(exc)
        logger.error(f"   Failed to create mock files: {exc}")

    return result


# ---------------------------------------------------------------------------
# LLM prompt guidance generation
# ---------------------------------------------------------------------------

def generate_mock_dependency_guidance(
    external_calls: Dict[str, List[str]],
    project_root: str,
    platform: str,
    current_module: str,
) -> str:
    """
    Generate explicit mock dependency guidance for LLM prompt injection.

    Tells the LLM which mock files to include for cross-module dependencies,
    preventing it from defining other modules' mocks locally.

    Args:
        external_calls: Dict from :func:`analyze_source_external_hal_calls`.
        project_root: Project root path.
        platform: Platform name.
        current_module: Current module name.

    Returns:
        Formatted guidance string for the LLM prompt (empty if no deps).
    """
    if not external_calls:
        return ""

    mock_inc_dir, mock_src_dir = _resolve_mock_dirs(project_root, platform)
    prefix = get_platform_prefix(platform)

    lines: list[str] = [
        "",
        "## CRITICAL: Cross-Module Mock Dependencies Detected!",
        "",
        f"Your source file (`hal-{current_module}.c`) calls functions from OTHER HAL modules.",
        "**You MUST follow these instructions to avoid 'conflicting declaration' errors:**",
        "",
    ]

    existing_mocks: list[dict] = []
    missing_mocks: list[dict] = []


    for module, functions in external_calls.items():
        mock_header = f"mock-{prefix}-hal-{module}.h"
        mock_impl = f"mock-{prefix}-hal-{module}.cpp"
        mock_instance = f"{prefix}_{module}_mock"
        mock_class = f"Mock{prefix.capitalize()}Hal{module.capitalize()}"

        header_ok = bool(mock_inc_dir and (mock_inc_dir / mock_header).exists())
        impl_ok = bool(mock_src_dir and (mock_src_dir / mock_impl).exists())

        func_list = ", ".join(f"`{f}`" for f in functions[:5])
        if len(functions) > 5:
            func_list += f", ... ({len(functions)} total)"

        entry = {
            "module": module, "functions": functions, "func_list": func_list,
            "mock_header": mock_header, "mock_impl": mock_impl,
            "mock_instance": mock_instance, "mock_class": mock_class,
        }
        if header_ok and impl_ok:
            existing_mocks.append(entry)
        else:
            entry.update(header_exists=header_ok, impl_exists=impl_ok)
            missing_mocks.append(entry)

    # --- Existing mocks section ---
    if existing_mocks:
        lines.append("### EXISTING Mock Files - Just Include Them!")
        lines.append("")
        lines.append("These mock files ALREADY EXIST. **DO NOT redefine them!**")
        lines.append("")
        for m in existing_mocks:
            lines.extend([
                f"**{m['module'].upper()} Module** (called: {m['func_list']})",
                f"- Mock file: `{m['mock_header']}` / `{m['mock_impl']}`",
                f"- Mock instance: `{m['mock_instance']}`",
                "",
                f"**In `tc-hal-{current_module}.cpp`** - Include and use:",
                "```cpp",
                f'#include "{m["mock_header"]}"',
                f'EXPECT_CALL({m["mock_instance"]}, {m["functions"][0]}(_)).WillOnce(Return(HAL_OK));',
                "```",
                "",
                f"**In `mock-{prefix}-hal-{current_module}.cpp`** - DO NOT define `{m['mock_instance']}`!",
                f"The `{m['mock_instance']}` is already defined in `{m['mock_impl']}`.",
                "",
            ])


    # --- Missing mocks section ---
    if missing_mocks:
        lines.append("### Missing Mock Files - Create Separately!")
        lines.append("")
        lines.append(
            f"These mocks don't exist yet. Create SEPARATE mock files, "
            f"NOT in `mock-{prefix}-hal-{current_module}.cpp`!"
        )
        lines.append("")
        for m in missing_mocks:
            lines.extend([
                f"**{m['module'].upper()} Module** (called: {m['func_list']})",
                f"- Need to create: `{m['mock_header']}` and `{m['mock_impl']}`",
                "",
            ])

    # --- QBS update reminder ---
    qbs_lines: list[str] = []
    for m in existing_mocks:
        qbs_lines.append(f'            "{m["mock_impl"]}",  // Uncomment this line!')
    for m in missing_mocks:
        qbs_lines.append(f'            "{m["mock_impl"]}",  // Add this new file')

    if qbs_lines:
        lines.extend([
            "### QBS Configuration Update Required",
            "",
            "Make sure the QBS file (`test-hal-stm32u3.qbs`) includes these mock files:",
            "```javascript",
            "Group {",
            '    name: "Test mock sources"',
            "    files: [",
        ])
        lines.extend(qbs_lines)
        lines.extend(["    ]", "}", "```", ""])

    # --- DO NOT / DO examples ---
    lines.extend([
        "### DO NOT Do This:",
        "```cpp",
        f"// WRONG! In mock-{prefix}-hal-{current_module}.cpp:",
    ])
    if existing_mocks:
        m = existing_mocks[0]
        lines.extend([
            f'{m["mock_class"]} {m["mock_instance"]};  // WRONG! Already defined elsewhere!',
            f'HAL_StatusTypeDef {m["functions"][0]}(...) {{ ... }}  // WRONG! Already in {m["mock_impl"]}!',
        ])
    lines.extend(["```", "", "### DO This Instead:", "```cpp",
                   f"// In tc-hal-{current_module}.cpp - just include the existing mock header:"])
    if existing_mocks:
        m = existing_mocks[0]
        lines.extend([
            f'#include "{m["mock_header"]}"  // Include existing mock',
            f'// Then use: EXPECT_CALL({m["mock_instance"]}, ...)  // Use existing mock instance',
        ])
    lines.extend(["```", ""])

    result = "\n".join(lines)
    logger.info(f"   Generated mock dependency guidance for {len(external_calls)} external modules")
    return result
