"""
@file agent.py
@author caoshwen
@brief UnitTestAgent - unit test generation with compile-verify loop.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pathlib import Path
from typing import Any, AsyncIterator, Optional
import asyncio
from collections import Counter, deque
from contextlib import suppress
from contextvars import ContextVar
import hashlib
import json
import math
import os
import re
import uuid
from datetime import datetime, timezone

from loguru import logger

from app.core.config import (
    DEFAULT_UNITTEST_MAX_FINAL_REPAIR_ATTEMPTS,
    get_claude_code_max_tokens,
    get_resolved_cli_path,
    get_settings,
)

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient
from app.skills.runtime import SkillPreparationError
from .skill_support import prepare_unittest_skills, applied_skill_names

from .types import (  # noqa: F401 — re-export for backward compatibility
    UnitTestContext,
    GenerateOptions,
    GeneratedTest,
    CompileError,
    ClassifiedCompileError,
    CompileResult,
    FixResult,
    SourceFile,
    SourceAnalysis,
    UnitTestStreamChunk,
    UnitTestResult,
    UnitTestState,
)
from .parsers import (
    parse_gcc_errors,
    parse_qbs_build_errors,
    parse_test_results,
    parse_coverage_from_output,
    extract_code_block,
    parse_functions_regex,
    parse_calls_regex,
    infer_layer_from_paths,
    ERROR_PATTERNS,
    parse_compile_error,
    classify_compile_errors,
)
from .prompts import (
    SYSTEM_PROMPT,
    build_generation_prompt,
    build_fix_prompt,
    build_mock_prompt,
    build_two_phase_prompt,
    build_test_failure_fix_prompt,
    build_multi_file_fix_prompt,
    build_cli_generation_prompt,
    build_cli_generation_system_prompt,
    build_cli_coverage_improvement_prompt,
    build_coverage_improvement_prompt,
    build_autonomous_coverage_fix_prompt,
    COMPACT_CONTEXT_BEGIN,
    COMPACT_CONTEXT_END,
)
from .quality import summarize_generated_test_quality
from .libclang import LibClangAnalyzer  # noqa: F401
from .paths import (  # noqa: F401
    detect_layer_from_filename,
    detect_platform_from_path,
    generate_file_paths,
    generate_header_templates,
    filter_mock_paths,
    save_test_files_to_project,
    find_and_read_header_file,
    find_dependent_hal_headers,
    find_vendor_hal_api_definitions,
    find_existing_mock_files,
    contains_app_forbidden_libs_reference,
    should_include_optional_artifacts,
)
from .qbs import (
    resolve_qbs_build_context,
    resolve_qbs_project_path,
    resolve_qbs_file_path,
    validate_qbs_build_context,
    update_qbs_config,
    run_qbs_build,
    run_test_executable,
    collect_gcov_coverage,
    _ensure_app_qbs_file,
    configure_common_qbs_target,
    create_isolated_app_qbs_file,
)
from .workflow import UnitTestWorkflow
from .output_parser import parse_and_split_test_output
from .fixers import fix_cpp_syntax_errors, fix_mock_header_includes, trim_generated_code_structure
from .external_mocks import (
    analyze_source_external_hal_calls,
    find_missing_mock_files,
    create_external_mock_file,
    generate_mock_dependency_guidance,
)
from .api_filter import (
    extract_called_functions,
    filter_relevant_apis,
)
from .validation import GeneratedTestValidation, validate_generated_test
from .cli_artifacts import (
    ARTIFACT_FIELDS, raise_if_cli_cancelled, reload_cli_artifacts, snapshot_cli_artifacts,
)


_TEST_EXECUTION_FAILURE_PREFIX = "__test_execution_failure__"
_TEST_PROCESS_CRASH_PREFIX = "__test_process_crash__"
MAX_FINAL_REPAIR_ATTEMPTS = DEFAULT_UNITTEST_MAX_FINAL_REPAIR_ATTEMPTS
_INFRASTRUCTURE_BUILD_FAILURE_PATTERNS = (
    r"\bout of memory\b",
    r"\bcannot allocate memory\b",
    r"\bunable to allocate memory\b",
    r"\bnot enough memory\b",
    r"\binsufficient memory\b",
    r"\bmemory exhausted\b",
    r"\bvirtual memory exhausted\b",
    r"\bpaging file is too small\b",
    r"\bnot enough storage is available to process this command\b",
    r"\bresource temporarily unavailable\b",
    r"fatal error: killed signal terminated program (?:cc1|cc1plus)",
)
_NON_INFRASTRUCTURE_BUILD_ERROR_PATTERNS = (
    r"\bundefined reference to\b",
    r"\bunresolved external symbol\b",
    r"\bundefined symbol\b",
    r"\bmultiple definition of\b",
    r"\bduplicate symbol\b",
    r"\bredefinition of\b",
    r"\bsyntax error\b",
    r"error:\s+expected\b",
    r"error:.*\bwas not declared\b",
    r"error:.*\buse of undeclared identifier\b",
    r"error:.*\bno matching function for call\b",
    r"error:.*\bcannot convert\b",
    r"fatal error:.*\bno such file or directory\b",
)


def _is_test_execution_failure(case: Any) -> bool:
    return str(case).startswith(_TEST_EXECUTION_FAILURE_PREFIX)


def _has_real_test_failures(failed_cases: list[str]) -> bool:
    return any(not _is_test_execution_failure(case) for case in failed_cases)


def _case_name_body(case: str) -> str:
    """Return the bare test name from a suite-qualified failure marker."""
    return case.rsplit(".", 1)[-1] if "." in case else case


def _filter_failed_cases_for_test(failed_cases: list[str], test: Any) -> list[str]:
    """Select failures that plausibly belong to this file's generated tests."""
    relevant: list[str] = []
    for case in failed_cases:
        if _is_test_execution_failure(case) or case.startswith(_TEST_PROCESS_CRASH_PREFIX):
            relevant.append(case)
            continue
        if _case_name_body(case) in (test.test_content or ""):
            relevant.append(case)
    return relevant


def _test_failure_cases_from_result(result: dict[str, Any]) -> list[str]:
    """Convert a test-run result into stable runtime failure markers."""
    failed_cases = [
        f"{case.get('suite', 'Unknown')}.{case.get('name', 'Unknown')}"
        for case in result.get("test_cases", [])
        if case.get("passed") is False
    ]
    if result.get("failure_kind") == "process_crash" or result.get("crashed"):
        crash_case = (
            f"{_TEST_PROCESS_CRASH_PREFIX}: exit code {result.get('returncode')}"
        )
        if crash_case not in failed_cases:
            failed_cases.append(crash_case)
    elif not result.get("success") and not failed_cases:
        error = result.get("error") or "test execution returned no results"
        failed_cases.append(f"{_TEST_EXECUTION_FAILURE_PREFIX}: {error}")
    return failed_cases


def _build_failure_text(value: Any) -> str:
    """Flatten QBS diagnostics into searchable text."""
    if value is None:
        return ""
    if isinstance(value, dict):
        return "\n".join(_build_failure_text(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return "\n".join(_build_failure_text(item) for item in value)
    message = getattr(value, "message", None)
    return str(message if message is not None else value)


def _is_infrastructure_build_failure(result: dict[str, Any]) -> bool:
    """Return True only for explicit resource failures without code errors."""
    diagnostic_text = "\n".join(
        _build_failure_text(result.get(key))
        for key in ("error", "output", "errors")
    ).lower()
    if not any(
        re.search(pattern, diagnostic_text)
        for pattern in _INFRASTRUCTURE_BUILD_FAILURE_PATTERNS
    ):
        return False
    return not any(
        re.search(pattern, diagnostic_text)
        for pattern in _NON_INFRASTRUCTURE_BUILD_ERROR_PATTERNS
    )


def _is_coverage_measurement_unavailable(data: dict[str, Any]) -> bool:
    """Return True when gcov has no verified target metrics."""
    if data.get("coverage_unavailable") or data.get("targets_verified") is False:
        return True
    try:
        return int(data.get("lines_total", 0) or 0) <= 0
    except (TypeError, ValueError):
        return True


def _claude_code_max_tokens() -> int:
    """Return the configured token budget for large UnitTest generations."""
    return get_claude_code_max_tokens(get_settings())


def _coverage_is_measured(coverage_data: dict[str, Any]) -> bool:
    """Return whether coverage contains usable target-line data."""
    return not _is_coverage_measurement_unavailable(coverage_data)


def _get_max_final_repair_attempts() -> int:
    """Return the configured final-build repair budget."""
    try:
        configured = int(
            getattr(
                get_settings(),
                "UNITTEST_MAX_FINAL_REPAIR_ATTEMPTS",
                MAX_FINAL_REPAIR_ATTEMPTS,
            )
        )
    except (TypeError, ValueError):
        configured = MAX_FINAL_REPAIR_ATTEMPTS
    return max(0, configured)


# ========== UnitTestAgent ==========


class TerminalCliFailure(RuntimeError):
    """A CLI failure that must not fall back to the same LLM provider."""


class UnitTestAgent(BaseAgent):
    """
    Unit test generation Agent.

    Workflow:
    1. Detect code layer (HAL/Driver/Controller/App)
    2. Analyze source code, identify testable functions
    3. Generate test code via LLM
    4. Compile-verify tests (QBS MCP)
    5. If compilation fails, iterate and fix
    6. Calculate coverage statistics
    """

    _COMPACT_CONTEXT_MAX_CHARS = 3000
    _TOKEN_FIELDS = (
        "input_tokens",
        "output_tokens",
        "total_tokens",
        "cache_creation_input_tokens",
        "cache_read_input_tokens",
    )
    _ALLOWED_LAYERS = {
        "auto",
        "hal",
        "driver",
        "controller",
        "midware_driver",
        "midware_controller",
        "app",
        "common",
    }
    _ALLOWED_BUILD_PROFILES = {"mingw", "host_gcc"}
    _ALLOWED_GENERATION_METHODS = {"api", "cli"}
    _MAX_SOURCE_FILES = 128
    _MAX_SOURCE_FILE_CHARS = 12 * 1024 * 1024
    _MAX_SOURCE_TOTAL_CHARS = 64 * 1024 * 1024
    _LARGE_SOURCE_CONTEXT_THRESHOLD = 5_000
    _LARGE_SOURCE_PROMPT_CHARS = 24_000
    _LARGE_SOURCE_MAX_EXCERPTS = 18
    _LARGE_SOURCE_MAX_FUNCTIONS = 80
    _LARGE_SOURCE_MAX_BRANCH_LINES = 80
    _LARGE_SOURCE_FUNCTIONS_PER_GROUP = 6
    _LARGE_SOURCE_MAX_GROUPS = 14
    _CLI_GENERATION_TOOL_LIMIT = 64
    _CLI_REPAIR_TOOL_LIMIT = 24

    def __init__(self, llm_bridge: LLMBridge, mcp_client: MCPClient, skill_registry=None):
        super().__init__(AgentConfig(agent_type=AgentType.UNITTEST, timeout_seconds=600), skill_registry=skill_registry)
        self._llm = llm_bridge
        self._mcp = mcp_client
        # Keep token usage isolated when one agent instance serves concurrent tasks.
        self._token_usage_by_task: dict[str, dict[str, int]] = {}
        self._active_token_task: ContextVar[Optional[str]] = ContextVar(
            f"unit_test_token_task_{id(self)}", default=None
        )
        # Shared monitor instance for token tracking
        from app.utils.claude_cli_monitor import ClaudeCliMonitor
        self._monitor = ClaudeCliMonitor()
        self._qbs_compile_log_counter = 0

    @staticmethod
    def _resolve_context_project_root(ctx: "UnitTestContext", source_path: str | None = None) -> str:
        """Resolve a stable project root and isolate unverified Driver snapshots."""
        if ctx.metadata.get("driver_task_id"):
            if not ctx.compile_verify:
                return ctx.metadata.get("driver_output_dir") or ctx.output_dir or "."
            return ctx.output_dir or "."
        from .paths import find_project_root_for_source

        inferred_root = find_project_root_for_source(source_path) if source_path else None
        return inferred_root or ctx.output_dir or "."

    def _llm_call_options(self) -> dict[str, Any]:
        """Use durable LLM calls for UnitTest jobs with no wall-clock deadline."""
        options = super()._llm_call_options()
        options["unbounded_runtime"] = True
        return options

    @classmethod
    def _empty_token_usage(cls) -> dict[str, int]:
        return {field: 0 for field in cls._TOKEN_FIELDS}

    def _active_token_context(self) -> ContextVar[Optional[str]]:
        context = getattr(self, "_active_token_task", None)
        if context is None:
            context = ContextVar(f"unit_test_token_task_{id(self)}", default=None)
            self._active_token_task = context
        return context

    def _token_usage(self, task_id: Optional[str] = None) -> dict[str, int]:
        active_task_id = self._active_token_context().get()
        resolved_task_id = task_id or active_task_id or "__unscoped__"
        usage_by_task = getattr(self, "_token_usage_by_task", None)
        if usage_by_task is None:
            usage_by_task = {}
            self._token_usage_by_task = usage_by_task
        return usage_by_task.setdefault(
            resolved_task_id, self._empty_token_usage()
        )

    def _begin_token_tracking(self, task_id: str):
        self._token_usage_by_task = getattr(self, "_token_usage_by_task", {})
        self._token_usage_by_task[task_id] = self._empty_token_usage()
        return self._active_token_context().set(task_id)

    def _finish_token_tracking(self, task_id: str, token: Any) -> dict[str, int]:
        usage = dict(self._token_usage_by_task.pop(task_id, self._empty_token_usage()))
        self._active_token_context().reset(token)
        return usage

    def _token_usage_snapshot(self, task_id: Optional[str] = None) -> dict[str, int]:
        return dict(self._token_usage(task_id))

    def get_live_token_usage(self) -> dict[str, int]:
        """Combine completed task usage with the current CLI monitor snapshot."""
        usage = self._token_usage_snapshot()
        monitor = getattr(self, "_monitor", None)
        get_usage = getattr(monitor, "get_token_usage", None)
        if callable(get_usage):
            try:
                active_usage = get_usage() or {}
            except Exception as exc:
                logger.debug(f"[CLI] Live token usage unavailable: {exc}")
                active_usage = {}
            if isinstance(active_usage, dict):
                for field in self._TOKEN_FIELDS:
                    try:
                        usage[field] += max(0, int(active_usage.get(field, 0) or 0))
                    except (TypeError, ValueError):
                        continue
        return usage

    def _accumulate_cli_token_usage(self, token_usage: Any) -> None:
        """Move a completed CLI usage snapshot into task totals exactly once."""
        if isinstance(token_usage, dict):
            usage = self._token_usage()
            for field in self._TOKEN_FIELDS:
                try:
                    usage[field] += max(0, int(token_usage.get(field, 0) or 0))
                except (TypeError, ValueError):
                    continue

        monitor = getattr(self, "_monitor", None)
        reset_usage = getattr(monitor, "reset_token_usage", None)
        if callable(reset_usage):
            try:
                reset_usage()
            except Exception as exc:
                logger.debug(f"[CLI] Could not reset completed token snapshot: {exc}")

    @property
    def _total_input_tokens(self) -> int:
        return self._token_usage()["input_tokens"]

    @_total_input_tokens.setter
    def _total_input_tokens(self, value: int) -> None:
        self._token_usage()["input_tokens"] = value

    @property
    def _total_output_tokens(self) -> int:
        return self._token_usage()["output_tokens"]

    @_total_output_tokens.setter
    def _total_output_tokens(self, value: int) -> None:
        self._token_usage()["output_tokens"] = value

    @property
    def _total_tokens(self) -> int:
        return self._token_usage()["total_tokens"]

    @_total_tokens.setter
    def _total_tokens(self, value: int) -> None:
        self._token_usage()["total_tokens"] = value

    @property
    def _total_cache_creation_tokens(self) -> int:
        return self._token_usage()["cache_creation_input_tokens"]

    @_total_cache_creation_tokens.setter
    def _total_cache_creation_tokens(self, value: int) -> None:
        self._token_usage()["cache_creation_input_tokens"] = value

    @property
    def _total_cache_read_tokens(self) -> int:
        return self._token_usage()["cache_read_input_tokens"]

    @_total_cache_read_tokens.setter
    def _total_cache_read_tokens(self, value: int) -> None:
        self._token_usage()["cache_read_input_tokens"] = value

    def _iter_cli_text_parts(self, cli_output: str) -> list[str]:
        parts: list[str] = []
        for line in cli_output.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                parts.append(line)
                continue

            message = payload.get("message")
            if isinstance(message, dict):
                for item in message.get("content", []):
                    if isinstance(item, dict) and item.get("type") == "text":
                        text = item.get("text")
                        if isinstance(text, str):
                            parts.append(text)
            result_text = payload.get("result")
            if isinstance(result_text, str):
                parts.append(result_text)
        return parts

    def _extract_compact_context(self, cli_output: str) -> str:
        if not cli_output:
            return ""
        text = "\n".join(self._iter_cli_text_parts(cli_output))
        pattern = re.escape(COMPACT_CONTEXT_BEGIN) + r"(.*?)" + re.escape(COMPACT_CONTEXT_END)
        matches = list(re.finditer(pattern, text, re.DOTALL))
        if not matches:
            return ""
        return matches[-1].group(1).strip()[:self._COMPACT_CONTEXT_MAX_CHARS]

    def _get_backend_output_dir(self) -> Path:
        output_dir = Path(__file__).resolve().parents[4] / "data" / "outputs"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    def _safe_file_token(self, value: Any) -> str:
        safe_value = re.sub(r"[^A-Za-z0-9_-]", "_", str(value))
        return safe_value or "unknown"

    def _clear_disabled_mock_content(self, test: GeneratedTest, ctx: UnitTestContext) -> None:
        """Exclude unrequested mock content without touching shared project files."""
        if not ctx.enable_mock:
            test.mock_content = ""
            test.mock_header_content = ""

    def _persist_compact_context(self, ctx: UnitTestContext, phase: str, summary: str) -> None:
        try:
            output_dir = self._get_backend_output_dir()
            safe_task_id = self._safe_file_token(ctx.task_id)
            output_path = output_dir / f"compact_context_{safe_task_id}.md"
            timestamp = datetime.now(timezone.utc).isoformat()
            with output_path.open("a", encoding="utf-8") as f:
                f.write(f"\n\n## {phase} - {timestamp}\n\n")
                f.write(f"- chars: {len(summary)}\n\n")
                f.write("```text\n")
                f.write(summary.replace("```", "``\\`"))
                f.write("\n```\n")
            logger.info(f"[CTX] Compact context persisted: phase={phase}, path={output_path}")
        except Exception as exc:
            logger.warning(f"[CTX] Failed to persist compact context: phase={phase}, error={exc}")

    def _persist_latest_compact_context(self, ctx: UnitTestContext, summary: str) -> None:
        try:
            output_dir = self._get_backend_output_dir()
            safe_task_id = self._safe_file_token(ctx.task_id)
            output_path = output_dir / f"compact_context_latest_{safe_task_id}.txt"
            temporary_path = output_path.with_suffix(".txt.tmp")
            temporary_path.write_text(summary, encoding="utf-8")
            temporary_path.replace(output_path)
            logger.info(f"[CTX] Latest compact context persisted: path={output_path}")
        except Exception as exc:
            logger.warning(f"[CTX] Failed to persist latest compact context: error={exc}")

    def _persist_qbs_compile_log(
        self,
        ctx: UnitTestContext,
        build_result: dict[str, Any],
        phase: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Persist complete QBS output for a backend-triggered compilation."""
        try:
            self._qbs_compile_log_counter += 1
            output_dir = (
                self._get_backend_output_dir()
                / "qbs_compile_logs"
                / self._safe_file_token(ctx.task_id)
            )
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / (
                f"{self._qbs_compile_log_counter:03d}_{self._safe_file_token(phase)}.log"
            )
            data = build_result.get("data") if isinstance(build_result.get("data"), dict) else {}
            lines = [
                f"timestamp: {datetime.now(timezone.utc).isoformat()}",
                f"task_id: {ctx.task_id}",
                f"phase: {phase}",
                f"layer: {ctx.layer}",
                f"platform: {ctx.platform}",
                f"build_profile: {ctx.build_profile}",
                f"success: {build_result.get('success')}",
                f"error: {build_result.get('error') or ''}",
                f"warnings: {build_result.get('warnings') or data.get('warnings') or []}",
            ]
            for key, value in (metadata or {}).items():
                lines.append(f"{key}: {value}")
            lines.extend(
                [
                    "",
                    "=== stdout ===",
                    str(build_result.get("stdout") or data.get("stdout") or ""),
                    "",
                    "=== stderr ===",
                    str(build_result.get("stderr") or data.get("stderr") or ""),
                    "",
                    "=== combined_output ===",
                    str(build_result.get("output") or ""),
                    "",
                ]
            )
            output_path.write_text("\n".join(lines), encoding="utf-8")
            logger.info(f"[QBS] Full compile log persisted: path={output_path}")
            return str(output_path)
        except Exception as exc:
            logger.warning(f"[QBS] Failed to persist compile log: phase={phase}, error={exc}")
            return ""

    def _persist_qbs_build_failure(self, ctx: UnitTestContext, build_result: dict[str, Any]) -> None:
        try:
            output_dir = self._get_backend_output_dir()
            safe_task_id = self._safe_file_token(ctx.task_id)
            output_path = output_dir / f"qbs_build_failure_{safe_task_id}.log"
            timestamp = datetime.now(timezone.utc).isoformat()
            lines = [
                f"timestamp: {timestamp}",
                f"task_id: {ctx.task_id}",
                f"layer: {ctx.layer}",
                f"platform: {ctx.platform}",
                f"build_profile: {ctx.build_profile}",
                "",
                "=== error ===",
                str(build_result.get("error") or ""),
                f"error_code: {build_result.get('error_code') or ''}",
                f"retryable: {bool(build_result.get('retryable', True))}",
                f"project_path: {build_result.get('project_path') or ''}",
                "",
                "=== output ===",
                str(build_result.get("output") or ""),
                "",
            ]
            output_path.write_text("\n".join(lines), encoding="utf-8")
            logger.info(f"[QBS] Full build failure log persisted: path={output_path}")
        except Exception as exc:
            logger.warning(f"[QBS] Failed to persist full build failure log: error={exc}")

    def _record_large_file_diagnostic(
        self,
        ctx: UnitTestContext,
        diagnostic: Optional[dict[str, Any]],
    ) -> None:
        if not diagnostic:
            return
        diagnostics = getattr(ctx, "large_file_diagnostics", None)
        if not isinstance(diagnostics, list):
            diagnostics = []
            setattr(ctx, "large_file_diagnostics", diagnostics)
        key = (
            diagnostic.get("source_file"),
            diagnostic.get("generation_path"),
            diagnostic.get("original_chars"),
            diagnostic.get("prompt_chars"),
            diagnostic.get("source_sha256"),
        )
        for existing in diagnostics:
            existing_key = (
                existing.get("source_file"),
                existing.get("generation_path"),
                existing.get("original_chars"),
                existing.get("prompt_chars"),
                existing.get("source_sha256"),
            )
            if existing_key == key:
                return
        diagnostics.append(diagnostic)

    def _record_large_file_checkpoints(
        self,
        ctx: UnitTestContext,
        diagnostic: Optional[dict[str, Any]],
    ) -> None:
        """Seed resumable checkpoints for exactly one source revision.

        Checkpoints are evidence for a specific source hash.  Keeping an old
        revision next to a new revision lets a resumed task accidentally apply
        new build results to stale ranges, so a source revision change replaces
        the manifest for that source while preserving evidence for other files.
        """
        if not diagnostic:
            return
        checkpoints = getattr(ctx, "large_file_checkpoints", None)
        if not isinstance(checkpoints, list):
            checkpoints = []
            setattr(ctx, "large_file_checkpoints", checkpoints)
        source_hash = str(diagnostic.get("source_sha256") or "")
        source_file = str(diagnostic.get("source_file") or "")
        if not source_hash or not source_file:
            return

        manifest = diagnostic.get("chunk_manifest") or []
        chunk_ids = {
            str(chunk.get("chunk_id") or "")
            for chunk in manifest
            if isinstance(chunk, dict) and chunk.get("chunk_id")
        }
        # Remove stale revisions and duplicate entries for the active source.
        retained: list[dict[str, Any]] = []
        existing_by_id: dict[str, dict[str, Any]] = {}
        for item in checkpoints:
            if not isinstance(item, dict):
                continue
            if item.get("source_file") != source_file:
                retained.append(item)
                continue
            if item.get("source_sha256") != source_hash:
                continue
            if str(item.get("chunk_id") or "") not in chunk_ids:
                continue
            existing_by_id.setdefault(str(item.get("chunk_id")), item)
        for chunk in manifest:
            if not isinstance(chunk, dict):
                continue
            chunk_id = str(chunk.get("chunk_id") or "")
            if not chunk_id:
                continue
            existing = existing_by_id.get(chunk_id)
            base = {
                "source_file": source_file,
                **dict(chunk),
                "source_sha256": source_hash,
                "generation_status": "pending",
                "output_sha256": None,
                "updated_at": None,
                "last_gate": None,
            }
            if existing is not None:
                # Preserve valid evidence from the same source revision while
                # migrating manifests created before the generation gate.
                base.update(existing)
                if "generation_status" not in existing:
                    base["generation_status"] = (
                        "passed"
                        if existing.get("build_status") == "passed"
                        or existing.get("test_status") == "passed"
                        else "pending"
                    )
                base["source_file"] = source_file
                base["source_sha256"] = source_hash
                base["chunk_id"] = chunk_id
            retained.append(base)

        retained.sort(
            key=lambda item: (
                str(item.get("source_file") or ""),
                int(item.get("line_start") or 0),
                str(item.get("chunk_id") or ""),
            )
        )
        ctx.large_file_checkpoints = retained

    @staticmethod
    def _normalize_failure_signature(value: str) -> str:
        """Remove volatile path/timestamp details from a checkpoint failure."""
        text = re.sub(r"[A-Za-z]:[\\/][^\s:]+", "<path>", str(value or ""))
        text = re.sub(r"\b\d{4}-\d{2}-\d{2}[T ]\S+", "<timestamp>", text)
        return re.sub(r"\s+", " ", text).strip()[:2000]

    def _update_large_file_checkpoints(
        self,
        ctx: UnitTestContext,
        source_file: str,
        chunk_id: Optional[str] = None,
        source_sha256: Optional[str] = None,
        **updates: Any,
    ) -> int:
        """Apply evidence only to the active checkpoint for this source revision.

        When a caller does not provide a hash, it is inferred only if one
        revision exists for the source.  If multiple revisions are present the
        update is rejected instead of risking cross-revision evidence.
        """
        checkpoints = getattr(ctx, "large_file_checkpoints", []) or []
        source_candidates = [
            item for item in checkpoints
            if isinstance(item, dict) and item.get("source_file") == source_file
        ]
        if source_sha256 is None:
            content = None
            for key, value in (getattr(ctx, "source_contents", {}) or {}).items():
                if key == source_file or os.path.basename(str(key)) == os.path.basename(source_file):
                    content = value
                    break
            if content is not None:
                source_sha256 = hashlib.sha256(
                    str(content).encode("utf-8", errors="replace")
                ).hexdigest()
            else:
                hashes = {
                    str(item.get("source_sha256") or "")
                    for item in source_candidates
                    if item.get("source_sha256")
                }
                if len(hashes) == 1:
                    source_sha256 = next(iter(hashes))
        if not source_sha256:
            return 0

        matching_candidates = [
            item for item in source_candidates
            if item.get("source_sha256") == source_sha256
        ]
        if matching_candidates and not chunk_id:
            active_chunk_id = str(getattr(ctx, "large_file_active_chunk_id", "") or "")
            active_matches = [
                item for item in matching_candidates
                if str(item.get("chunk_id") or "") == active_chunk_id
            ]
            if len(active_matches) != 1:
                logger.error(
                    "[UnitTest] Rejected large-file checkpoint update without "
                    f"an unambiguous active chunk: source={source_file}"
                )
                return 0
            chunk_id = active_chunk_id

        normalized_updates = dict(updates)
        if "failure_signature" in normalized_updates:
            normalized_updates["failure_signature"] = self._normalize_failure_signature(
                str(normalized_updates.get("failure_signature") or "")
            ) or None
        gate = normalized_updates.get("last_gate")
        if not gate:
            for candidate in (
                "coverage_after", "coverage_before", "test_status",
                "build_status", "generation_status",
            ):
                if candidate in normalized_updates:
                    gate = candidate.removesuffix("_status")
                    break
        if gate:
            normalized_updates["last_gate"] = str(gate)
        normalized_updates["updated_at"] = datetime.now(timezone.utc).isoformat()

        updated = 0
        for checkpoint in checkpoints:
            if not isinstance(checkpoint, dict):
                continue
            if checkpoint.get("source_file") != source_file:
                continue
            if checkpoint.get("source_sha256") != source_sha256:
                continue
            if checkpoint.get("chunk_id") != chunk_id:
                continue
            checkpoint.update(normalized_updates)
            updated += 1
        return updated

    @staticmethod
    def _source_hash_for_context(ctx: UnitTestContext, source_file: str) -> Optional[str]:
        """Resolve the hash of the original source content in the context."""
        contents = getattr(ctx, "source_contents", {}) or {}
        content = contents.get(source_file)
        if content is None:
            basename = os.path.basename(source_file)
            for key, value in contents.items():
                if os.path.basename(str(key)) == basename:
                    content = value
                    break
        if content is None:
            return None
        return hashlib.sha256(
            str(content).encode("utf-8", errors="replace")
        ).hexdigest()

    @staticmethod
    def _generated_output_sha256(test: GeneratedTest) -> Optional[str]:
        """Hash generated artifacts so checkpoint evidence is auditable."""
        parts = (
            getattr(test, "test_content", "") or "",
            getattr(test, "test_header_content", "") or "",
            getattr(test, "mock_content", "") or "",
            getattr(test, "mock_header_content", "") or "",
            getattr(test, "stub_content", "") or "",
            getattr(test, "stub_header_content", "") or "",
        )
        if not any(parts):
            return None
        digest = hashlib.sha256()
        for part in parts:
            encoded = str(part).encode("utf-8", errors="replace")
            digest.update(len(encoded).to_bytes(8, "big"))
            digest.update(encoded)
        return digest.hexdigest()

    @staticmethod
    def _reload_cli_outputs_from_disk(
        test: GeneratedTest,
        file_paths: dict[str, Any],
    ) -> list[str]:
        """Reload CLI-written artifacts before the backend performs its final save."""
        reloaded: list[str] = []
        for path_key, content_field in ARTIFACT_FIELDS:
            artifact_path = file_paths.get(path_key)
            if not artifact_path or not os.path.isfile(artifact_path):
                continue
            try:
                content = Path(artifact_path).read_text(encoding="utf-8")
            except (OSError, UnicodeError) as exc:
                logger.warning(
                    "Could not reload CLI-written artifact '%s': %s",
                    artifact_path,
                    exc,
                )
                continue
            setattr(test, content_field, content)
            reloaded.append(str(artifact_path))
        return reloaded

    def _record_large_file_test_result(
        self,
        ctx: UnitTestContext,
        generated_tests: list[GeneratedTest],
        test_output: str,
        test_count: int,
        failed_cases: list[str],
    ) -> None:
        """Persist the test-run gate for each large source file."""
        if not (test_output or test_count or failed_cases):
            return
        status = "failed" if failed_cases else "passed"
        signature = None
        if failed_cases:
            signature = self._normalize_failure_signature(
                "test failures: " + ", ".join(str(item) for item in failed_cases[:10])
            )
        for test in generated_tests:
            self._update_large_file_checkpoints(
                ctx,
                test.source_file,
                source_sha256=self._source_hash_for_context(ctx, test.source_file),
                test_status=status,
                failure_signature=signature if signature else None,
                last_gate="test",
            )

    @staticmethod
    def _first_incomplete_large_chunk(
        ctx: UnitTestContext,
        source_file: str,
        source_sha256: str,
    ) -> Optional[dict[str, Any]]:
        """Return the first checkpoint that still needs generation evidence."""
        checkpoints = [
            item for item in (getattr(ctx, "large_file_checkpoints", []) or [])
            if item.get("source_file") == source_file
            and item.get("source_sha256") == source_sha256
        ]
        for checkpoint in sorted(
            checkpoints,
            key=lambda item: int(item.get("line_start") or 0),
        ):
            if not (
                checkpoint.get("generation_status", "passed" if checkpoint.get("build_status") == "passed" else "pending") == "passed"
                and
                checkpoint.get("build_status") == "passed"
                and checkpoint.get("test_status") == "passed"
                and checkpoint.get("coverage_after") is not None
            ):
                return checkpoint
        return None

    def _collect_function_excerpt(
        self,
        lines: list[str],
        functions: list[dict[str, Any]],
        function_index: int,
        max_lines: int = 120,
    ) -> tuple[int, int, str]:
        start_line = max(int(functions[function_index].get("line") or 1), 1)
        if function_index + 1 < len(functions):
            next_line = max(int(functions[function_index + 1].get("line") or start_line), start_line + 1)
            end_line = min(next_line - 1, start_line + max_lines - 1, len(lines))
        else:
            end_line = min(start_line + max_lines - 1, len(lines))
        excerpt = "\n".join(lines[start_line - 1:end_line])
        return start_line, end_line, excerpt

    @staticmethod
    def _large_source_score_function(signature: str, excerpt: str, target_name: Optional[str], name: str) -> int:
        lowered = excerpt.lower()
        score = 0
        if target_name and name == target_name:
            score += 1000
        if not signature.lstrip().startswith("static "):
            score += 250
        score += 20 * sum(lowered.count(keyword) for keyword in ("if", "switch", "case", "else"))
        score += 10 * sum(lowered.count(keyword) for keyword in ("for", "while", "return"))
        score += 40 * sum(lowered.count(keyword) for keyword in ("error", "fail", "timeout", "null", "invalid"))
        return score

    def _build_large_file_test_strategy(
        self,
        functions: list[dict[str, Any]],
        scored_functions: list[tuple[int, int, dict[str, Any], str]],
        call_counts: Counter,
        branch_lines: list[str],
    ) -> tuple[list[str], list[str]]:
        """Build a deterministic, skill-aligned test plan for oversized sources.

        Long files are generated from bounded excerpts, so the model also needs an
        explicit coverage map. The map is derived from source structure and
        contains no source text, keeping the prompt compact while making every
        function and dependency actionable.
        """
        if not functions:
            return [], [
                "No function definitions were detected; inspect the complete source before generating tests.",
                "Use the gtest-generator skill matrix: normal, boundary, error, dependency, and state-reset cases.",
            ]

        # Checkpoints follow source order so ranges are stable across retries;
        # the separate function-group strategy still carries score-based
        # prioritization for the model.
        ranked_indexes = [
            index for _, index, _, _ in sorted(
                scored_functions, key=lambda item: item[1]
            )
        ]
        groups: list[str] = []
        max_group_functions = self._LARGE_SOURCE_MAX_GROUPS * self._LARGE_SOURCE_FUNCTIONS_PER_GROUP
        for group_number, offset in enumerate(
            range(0, min(len(ranked_indexes), max_group_functions), self._LARGE_SOURCE_FUNCTIONS_PER_GROUP),
            1,
        ):
            group_indexes = ranked_indexes[offset:offset + self._LARGE_SOURCE_FUNCTIONS_PER_GROUP]
            entries: list[str] = []
            for index in group_indexes:
                item = functions[index]
                name = str(item.get("name") or "unknown")
                signature = str(item.get("signature") or name).strip()
                line = int(item.get("line") or 0)
                excerpt = next(
                    (excerpt for _, candidate, _, excerpt in scored_functions if candidate == index),
                    "",
                )
                lowered = excerpt.lower()
                focus: list[str] = ["normal behavior"]
                if any(token in lowered for token in ("if", "switch", "case", "else")):
                    focus.append("branch boundaries")
                if any(token in lowered for token in ("error", "fail", "invalid", "null", "timeout")):
                    focus.append("error and invalid inputs")
                if any(token in lowered for token in ("static", "state", "volatile", "cache")):
                    focus.append("state reset in teardown")
                called = [
                    call for call, _count in call_counts.most_common(20)
                    if re.search(rf"\b{re.escape(call)}\s*\(", excerpt)
                ]
                if called:
                    focus.append("mock interactions: " + ", ".join(called[:4]))
                entries.append(f"{name} (L{line}): {', '.join(focus)}; signature: {signature}")
            if entries:
                groups.append(f"Group {group_number}: " + " | ".join(entries))

        matrix = [
            "1. Normal path: at least one behavior assertion for every public function.",
            "2. Boundary path: zero, null, minimum, maximum, overflow, and repeated-call inputs where applicable.",
            "3. Error path: dependency failures, timeout, invalid state, and each detected error return.",
            "4. Dependency path: strict mock expectations for external calls; do not mock the unit under test.",
            "5. State path: exercise transitions and restore static/global state in TearDown.",
        ]
        if not branch_lines:
            matrix.append("6. Branch hints were not detected; inspect each selected function before finalizing coverage.")
        return groups, matrix

    def _build_large_file_chunk_manifest(
        self,
        functions: list[dict[str, Any]],
        scored_functions: list[tuple[int, int, dict[str, Any], str]],
        call_counts: Counter,
        source_line_count: int,
        source_sha256: str,
    ) -> list[dict[str, Any]]:
        """Build a deterministic, resumable manifest for oversized sources."""
        if not functions:
            return []

        # The manifest is the durable navigation map and must remain in source
        # order. Ranking is used for prompt excerpts only; using it here would
        # make resume order unstable and could skip an earlier incomplete range.
        ranked_indexes = [
            index for _, index, _, _ in sorted(
                scored_functions, key=lambda item: item[1]
            )
        ]
        manifest: list[dict[str, Any]] = []
        for offset in range(
            0,
            len(ranked_indexes),
            self._LARGE_SOURCE_FUNCTIONS_PER_GROUP,
        ):
            indexes = ranked_indexes[offset:offset + self._LARGE_SOURCE_FUNCTIONS_PER_GROUP]
            if not indexes:
                continue
            ranges: list[tuple[int, int]] = []
            entries: list[dict[str, Any]] = []
            for index in indexes:
                item = functions[index]
                start_line = max(int(item.get("line") or 1), 1)
                if index + 1 < len(functions):
                    end_line = max(start_line, int(functions[index + 1].get("line") or start_line) - 1)
                else:
                    end_line = source_line_count
                end_line = min(max(end_line, start_line), source_line_count)
                ranges.append((start_line, end_line))
                name = str(item.get("name") or "unknown")
                excerpt = next(
                    (excerpt for _, candidate, _, excerpt in scored_functions if candidate == index),
                    "",
                )
                direct_calls = [
                    call for call, _count in call_counts.most_common(20)
                    if re.search(rf"\b{re.escape(call)}\s*\(", excerpt)
                ]
                entries.append({
                    "name": name,
                    "signature": str(item.get("signature") or name).strip(),
                    "line_start": start_line,
                    "line_end": end_line,
                    "direct_calls": direct_calls[:8],
                })
            manifest.append({
                "chunk_id": f"chunk-{len(manifest) + 1:02d}",
                "source_sha256": source_sha256,
                "line_start": min(start for start, _ in ranges),
                "line_end": max(end for _, end in ranges),
                "functions": entries,
                "test_names": [],
                "generation_status": "pending",
                "build_status": "pending",
                "test_status": "pending",
                "coverage_before": None,
                "coverage_after": None,
                "output_sha256": None,
                "failure_signature": None,
                "updated_at": None,
                "last_gate": None,
            })
        return manifest

    def _prepare_large_source_context(
        self,
        file_path: str,
        content: str,
        ctx: UnitTestContext,
        function_name: Optional[str] = None,
        generation_path: str = "api",
        source_real_path: str = "",
    ) -> tuple[str, str, Optional[dict[str, Any]]]:
        source = content or ""
        if len(source) < self._LARGE_SOURCE_CONTEXT_THRESHOLD:
            return source, "", None

        lines = source.splitlines()
        source_sha256 = hashlib.sha256(source.encode("utf-8", errors="replace")).hexdigest()
        functions = parse_functions_regex(source)
        function_names = {str(item.get("name", "")) for item in functions if item.get("name")}
        ignored_calls = {
            "if", "for", "while", "switch", "return", "sizeof", "case", "do", "else",
            "static_cast", "reinterpret_cast", "const_cast",
        }
        call_counts = Counter(
            call for call in parse_calls_regex(source)
            if call not in ignored_calls and call not in function_names
        )
        top_calls = [f"{name}({count})" for name, count in call_counts.most_common(40)]

        include_lines = [
            line.strip() for line in lines
            if line.lstrip().startswith("#include")
        ][:40]
        define_lines = [
            line.strip() for line in lines
            if line.lstrip().startswith("#define")
        ][:60]

        state_lines: list[str] = []
        for line in lines:
            stripped = line.strip()
            if not stripped or "(" in stripped:
                continue
            if (
                stripped.startswith(("static ", "volatile ", "const "))
                and stripped.endswith(";")
            ):
                state_lines.append(stripped[:180])
            if len(state_lines) >= 60:
                break

        branch_pattern = re.compile(
            r"\b(if|else\s+if|switch|case|default|for|while)\b"
            r"|\breturn\s+(NULL|false|true|[A-Z0-9_]*(ERR|ERROR|FAIL|INVALID)[A-Z0-9_]*|-?\d+)"
            r"|\bgoto\b|\bbreak\s*;|\bcontinue\s*;",
            re.IGNORECASE,
        )
        branch_lines: list[str] = []
        for idx, line in enumerate(lines, 1):
            stripped = line.strip()
            if branch_pattern.search(stripped):
                branch_lines.append(f"L{idx}: {stripped[:180]}")
            if len(branch_lines) >= self._LARGE_SOURCE_MAX_BRANCH_LINES:
                break

        scored_functions: list[tuple[int, int, dict[str, Any], str]] = []
        for index, item in enumerate(functions):
            _, _, excerpt = self._collect_function_excerpt(lines, functions, index, max_lines=120)
            name = str(item.get("name", ""))
            signature = str(item.get("signature", ""))
            score = self._large_source_score_function(signature, excerpt, function_name, name)
            scored_functions.append((score, index, item, excerpt))

        selected_indexes: list[int] = []
        if function_name:
            for _, index, item, _ in scored_functions:
                if item.get("name") == function_name:
                    selected_indexes.append(index)
                    break
        for index in range(min(8, len(functions))):
            if index not in selected_indexes:
                selected_indexes.append(index)
        for _, index, _, _ in sorted(scored_functions, key=lambda item: (-item[0], item[1])):
            if index not in selected_indexes:
                selected_indexes.append(index)
            if len(selected_indexes) >= self._LARGE_SOURCE_MAX_EXCERPTS:
                break
        selected_indexes = sorted(selected_indexes)

        prompt_segments: list[str] = [
            "/* Backend-selected excerpt for a large source file.",
            "   The complete source is too large for high-quality direct prompting.",
            "   Use the large source analysis section as the priority map. */",
            "",
        ]
        if include_lines:
            prompt_segments.extend(["/* Includes */", *include_lines, ""])
        if define_lines:
            prompt_segments.extend(["/* Key macros */", *define_lines, ""])
        if state_lines:
            prompt_segments.extend(["/* Static/global state candidates */", *state_lines, ""])

        selected_function_names: list[str] = []
        for index in selected_indexes:
            item = functions[index]
            name = str(item.get("name", ""))
            start_line, end_line, excerpt = self._collect_function_excerpt(lines, functions, index, max_lines=120)
            segment = (
                f"\n/* Function excerpt: {name} lines {start_line}-{end_line} */\n"
                f"{excerpt}\n"
            )
            current_size = len("\n".join(prompt_segments))
            if current_size + len(segment) > self._LARGE_SOURCE_PROMPT_CHARS:
                break
            prompt_segments.append(segment)
            selected_function_names.append(name)

        function_groups, test_matrix = self._build_large_file_test_strategy(
            functions=functions,
            scored_functions=scored_functions,
            call_counts=call_counts,
            branch_lines=branch_lines,
        )
        chunk_manifest = self._build_large_file_chunk_manifest(
            functions=functions,
            scored_functions=scored_functions,
            call_counts=call_counts,
            source_line_count=len(lines),
            source_sha256=source_sha256,
        )

        if not selected_function_names:
            head_budget = min(6000, max(1, len(source) * 3 // 5))
            tail_budget = min(4000, max(1, len(source) // 5))
            prompt_content = (
                source[:head_budget]
                + "\n\n/* Middle of oversized file omitted by backend. */\n\n"
                + source[-tail_budget:]
            )
        else:
            prompt_content = "\n".join(prompt_segments)

        if len(prompt_content) > self._LARGE_SOURCE_PROMPT_CHARS:
            prompt_content = (
                prompt_content[:self._LARGE_SOURCE_PROMPT_CHARS]
                + "\n\n/* Oversized excerpt truncated by backend. */\n"
            )

        function_inventory = [
            f"L{item.get('line', 0)}: {item.get('signature') or item.get('name')}"
            for item in functions[:self._LARGE_SOURCE_MAX_FUNCTIONS]
        ]
        if len(functions) > self._LARGE_SOURCE_MAX_FUNCTIONS:
            function_inventory.append(
                f"... {len(functions) - self._LARGE_SOURCE_MAX_FUNCTIONS} additional functions omitted from inventory."
            )

        large_file_context = "\n".join([
            (
                f"Large-file mode is active for {file_path}: original source has "
                f"{len(source)} characters, at or above the "
                f"{self._LARGE_SOURCE_CONTEXT_THRESHOLD} character threshold."
            ),
            (
                f"Resolved source path: {source_real_path.replace(chr(92), '/')}"
                if source_real_path
                else "Resolved source path: unavailable; use the supplied source identifier."
            ),
            f"Source identity: sha256={source_sha256}; lines={len(lines)}",
            "Reason full-file prompting degrades quality: the model must spread attention across unrelated code, so branch conditions, dependency mocks, static state transitions, and target function boundaries are not prioritized.",
            "Backend improvement applied: the prompt now uses a compact priority map plus selected source excerpts instead of sending the complete source text as the main generation context.",
            "Generation requirements for this large file:",
            "- Treat the selected excerpts as the primary implementation context.",
            "- Use the function inventory to choose meaningful behavior-level tests, not placeholder smoke tests.",
            "- Prioritize public functions, branches, error returns, boundary checks, and dependency interactions.",
            "- Build mocks around the dependency calls listed below and restore modified static/global state in teardown.",
            "- Process chunks in manifest order; read only the current inclusive line range plus minimal declarations.",
            "- After each chunk, write and read back outputs, build, run tests, and update its checkpoint fields.",
            "- Resume from the first chunk whose build or test status is not successful; do not regenerate completed chunks.",
            "",
            f"Detected functions: {len(functions)}",
            "Selected function excerpts: " + (", ".join(selected_function_names) or "(none)"),
            "Top dependency or helper calls: " + (", ".join(top_calls) or "(none detected)"),
            "",
            "Function inventory:",
            *function_inventory,
            "",
            "Branch and error-path hints:",
            *(branch_lines or ["(none detected)"]),
            "",
            "Skill-guided test matrix (gtest-generator):",
            *test_matrix,
            "",
            "Generation plan by function group:",
            *(function_groups or ["(no groups generated)"]),
            "",
            "Chunk manifest (checkpoint schema):",
            *[
                (
                    f"{chunk['chunk_id']}: lines=L{chunk['line_start']}-L{chunk['line_end']}; "
                    f"functions={', '.join(item['name'] for item in chunk['functions'])}; "
                    "generation=pending; build=pending; test=pending; "
                    "coverage_after=null; failure_signature=null"
                )
                for chunk in chunk_manifest
            ],
        ])

        diagnostic = {
            "source_file": file_path,
            "source_real_path": source_real_path,
            "generation_path": generation_path,
            "threshold_chars": self._LARGE_SOURCE_CONTEXT_THRESHOLD,
            "original_chars": len(source),
            "prompt_chars": len(prompt_content),
            "functions_detected": len(functions),
            "selected_functions": selected_function_names,
            "top_calls": [name for name, _ in call_counts.most_common(20)],
            "branch_hint_count": len(branch_lines),
            "function_groups": function_groups,
            "source_sha256": source_sha256,
            "source_line_count": len(lines),
            "chunk_manifest": chunk_manifest,
            "test_matrix": test_matrix,
            # Keep the original strategy label for downstream consumers; the
            # richer manifest is exposed separately for resumable execution.
            "strategy": "gtest-generator/function-groups-v1",
            "checkpoint_strategy": "gtest-generator/function-groups-v2-checkpointed",
            "reason": "Large source files dilute LLM attention when passed as raw full-text prompts.",
            "improvement": "Backend selected a structured priority map, bounded function groups, source identity, and resumable chunk checkpoints.",
        }
        self._record_large_file_checkpoints(ctx, diagnostic)
        active_chunk = self._first_incomplete_large_chunk(ctx, file_path, source_sha256)
        if active_chunk:
            ctx.large_file_active_chunk_id = str(active_chunk.get("chunk_id") or "")
            diagnostic["active_chunk_id"] = ctx.large_file_active_chunk_id
            diagnostic["active_chunk_line_start"] = active_chunk.get("line_start")
            diagnostic["active_chunk_line_end"] = active_chunk.get("line_end")
            large_file_context += (
                "\n\nActive resumable chunk: "
                f"{ctx.large_file_active_chunk_id}, "
                f"lines L{active_chunk.get('line_start')}-L{active_chunk.get('line_end')}. "
                "Read and verify this range first; preserve completed chunk outputs."
            )
            line_start = max(1, int(active_chunk.get("line_start") or 1))
            line_end = min(len(lines), int(active_chunk.get("line_end") or len(lines)))
            active_source = "\n".join(lines[line_start - 1:line_end])
            prompt_content = "\n".join([
                "/* Large-file active chunk. */",
                f"/* Source: {file_path}; lines {line_start}-{line_end}. */",
                *include_lines,
                *define_lines,
                active_source,
            ])[:self._LARGE_SOURCE_PROMPT_CHARS]
        else:
            ctx.large_file_active_chunk_id = None
            diagnostic["active_chunk_id"] = None
        self._record_large_file_diagnostic(ctx, diagnostic)
        logger.info(
            "[UnitTest] Large source context applied: "
            f"file={file_path}, path={generation_path}, original_chars={len(source)}, "
            f"prompt_chars={len(prompt_content)}, functions={len(functions)}"
        )
        return prompt_content, large_file_context, diagnostic

    def _update_compact_context_from_cli_result(
        self,
        ctx: UnitTestContext,
        result: dict[str, Any],
        phase: str,
    ) -> None:
        output = str(result.get("output", ""))
        summary = self._extract_compact_context(output)
        if summary:
            ctx.compact_context = summary
            self._persist_compact_context(ctx, phase, summary)
            self._persist_latest_compact_context(ctx, summary)
            logger.info(f"[CTX] Compact context updated: phase={phase}, chars={len(summary)}")
            return
        logger.info(f"[CTX] No compact context found in CLI output: phase={phase}, output_chars={len(output)}")

    # ========== Public interface ==========

    async def execute(self, task: str, context: AgentContext) -> UnitTestResult:  # type: ignore[override]
        """Execute the complete unit test generation flow, return UnitTestResult."""
        task_id = context.task_id
        token = self._begin_token_tracking(task_id)
        try:
            result = await super().execute(task, context)
            usage = self._token_usage_snapshot(task_id)
            runtime = {}
            get_runtime = getattr(self._monitor, "get_runtime_snapshot", None)
            if callable(get_runtime):
                try:
                    runtime = get_runtime() or {}
                except Exception as exc:
                    logger.debug(f"[CLI] Runtime telemetry unavailable: {exc}")
            if isinstance(result, UnitTestResult):
                result.data = dict(result.data or {})
                result.data.setdefault("token_usage", usage)
                if runtime:
                    result.data.setdefault("tool_failure_summary", runtime)
                return result
            return UnitTestResult(
                task_id=result.task_id,
                status=result.status,
                message=result.message,
                data={
                    **(result.data or {}),
                    "token_usage": usage,
                    **({"tool_failure_summary": runtime} if runtime else {}),
                },
                errors=result.errors,
                started_at=result.started_at,
                completed_at=result.completed_at,
                duration_ms=result.duration_ms,
            )
        finally:
            self._finish_token_tracking(task_id, token)

    async def stream_execute(  # type: ignore[override]
        self,
        task: str,
        context: AgentContext,
    ) -> AsyncIterator[UnitTestStreamChunk]:
        """Stream test generation process."""
        import asyncio

        task_id = context.task_id
        chunk_queue: deque[UnitTestStreamChunk] = deque()

        stage_map = {
            "fetch":     (5,  "fetch",    "Fetching source files"),
            "ast":       (15, "ast",      "Analyzing AST structure"),
            "layer":     (20, "layer",    "Detecting architecture layer"),
            "framework": (25, "framework","Selecting test framework"),
            "generate":  (45, "generate", "Generating test code"),
            "mock":      (60, "mock",     "Generating mock code"),
            "compile":   (75, "compile",  "Compiling test"),
            "run":       (85, "run",      "Running tests"),
            "coverage":  (92, "coverage", "Collecting coverage"),
            "report":    (98, "report",   "Generating report"),
        }

        def _on_progress(update):
            stage = update.stage
            progress, stage_key, default_msg = stage_map.get(
                stage, (update.progress, stage, update.message)
            )
            chunk_queue.append(UnitTestStreamChunk(
                task_id=task_id, stage=stage_key, progress=progress,
                message=update.message or default_msg, data=update.details,
                token_usage=self._token_usage_snapshot(task_id),
            ))

        self._progress_callbacks.setdefault(task_id, []).append(_on_progress)
        exec_task = asyncio.create_task(self.execute(task, context))
        try:
            while not exec_task.done() or chunk_queue:
                while chunk_queue:
                    yield chunk_queue.popleft()
                if not exec_task.done():
                    await asyncio.sleep(0.05)

            result = await exec_task
            final_data: dict[str, Any] = {}
            if isinstance(result, UnitTestResult):
                final_data = {
                    "total_coverage": result.total_coverage,
                    "tests_generated": len(result.generated_tests),
                    "iterations_used": result.iterations_used,
                    "token_usage": (result.data or {}).get(
                        "token_usage", self._token_usage_snapshot(task_id)
                    ),
                }
            yield UnitTestStreamChunk(
                task_id=task_id, stage="report",
                progress=100 if result.status == AgentStatus.COMPLETED else -1,
                message=result.message, data=final_data, is_final=True,
                status=result.status.value,
                token_usage=final_data.get("token_usage"),
            )
        finally:
            callbacks = self._progress_callbacks.get(task_id, [])
            with suppress(ValueError):
                callbacks.remove(_on_progress)
            if not callbacks:
                self._progress_callbacks.pop(task_id, None)
            if not exec_task.done():
                exec_task.cancel()
            with suppress(asyncio.CancelledError):
                await exec_task

    async def generate_for_file(
        self, source_path: str, options: GenerateOptions = None,
    ) -> GeneratedTest:
        """Generate test code for a single source file (simplified interface,
        calls LLM directly without going through the full workflow)."""
        opts = options or GenerateOptions()
        ctx = UnitTestContext(
            source_files=[source_path], test_framework=opts.framework,
            coverage_target=opts.coverage_target, enable_mock=opts.enable_mock,
            compile_verify=opts.compile_verify,
        )
        token = self._begin_token_tracking(ctx.task_id)
        try:
            result = await self._process_task_linear(
                f"Generate tests for {source_path}", ctx
            )
        finally:
            self._finish_token_tracking(ctx.task_id, token)
        if isinstance(result, UnitTestResult) and result.generated_tests:
            return result.generated_tests[0]
        return GeneratedTest(
            source_file=source_path,
            test_file=source_path.replace(".c", "_test.cpp").replace(".h", "_test.cpp"),
            test_content="", compile_success=False,
        )

    async def fix_compile_errors(
        self, test_code: str, errors: list[CompileError], max_attempts: int = 3,
        project_root: str = ".", layer: str = "hal", platform: str = "stm32u3",
        profile: str = "mingw",
        test_header: str = "", mock_impl: str = "", mock_header: str = "",
        file_paths: dict[str, str] | None = None,
    ) -> FixResult:
        """Automatically fix compilation errors (supports multiple files)."""
        current_code = test_code
        current_content = {
            "test_impl": test_code,
            "test_header": test_header,
            "mock_impl": mock_impl,
            "mock_header": mock_header,
        }
        changes: list[str] = []
        qbs_context = resolve_qbs_build_context(project_root, layer, platform)
        qbs_path = qbs_context["project_path"]
        qbs_file = qbs_context["qbs_file"]
        products = qbs_context["products"]

        has_multi_file = any([test_header, mock_impl, mock_header])

        for attempt in range(1, max_attempts + 1):
            if not errors:
                break

            # Build prompt: multi-file if we have extra files, single-file otherwise
            if has_multi_file:
                prompt = build_multi_file_fix_prompt(current_content, errors, file_paths)
            else:
                error_text = "\n".join(
                    f"{e.file}:{e.line}:{e.column}: {e.severity}: {e.message}" for e in errors
                )
                prompt = (
                    "Fix the following compilation errors in this C++ unit test code.\n\n"
                    f"Errors:\n{error_text}\n\n"
                    f"Current code:\n```cpp\n{current_code}\n```\n\n"
                    "Return only the corrected complete source file."
                )

            try:
                response = await self._llm.generate(
                    [{"role": "system", "content": SYSTEM_PROMPT},
                     {"role": "user", "content": prompt}],
                    temperature=0.2,
                    max_tokens=131072,
                    **self._llm_call_options(),
                )
                if has_multi_file:
                    parsed = parse_and_split_test_output(response.content)
                    updated = False
                    for key in ("test_impl", "test_header", "mock_impl", "mock_header"):
                        new_val = parsed.get(key, "")
                        if new_val and new_val != current_content[key]:
                            current_content[key] = new_val
                            updated = True
                    if updated:
                        current_code = current_content["test_impl"]
                        changes.append(f"Attempt {attempt}: applied multi-file LLM fix")
                else:
                    fixed = self._extract_code_block(response.content) or response.content
                    if fixed != current_code:
                        current_code = fixed
                        current_content["test_impl"] = fixed
                        changes.append(f"Attempt {attempt}: applied LLM fix")

                if not changes or not changes[-1].startswith(f"Attempt {attempt}"):
                    continue  # LLM returned same code, skip verify

                # Save to disk before compile verification
                if file_paths:
                    save_test_files_to_project(current_content, file_paths)

                build_kwargs: dict = dict(
                    project_path=qbs_path, profile=profile,
                    configuration="debug", products=products,
                )
                if qbs_file:
                    build_kwargs["project_file"] = qbs_file
                compile_result = await self._mcp.call_tool("qbs_build", **build_kwargs)
                if compile_result.success:
                    return FixResult(
                        success=True, fixed_code=current_code,
                        changes_made=changes, attempts_used=attempt,
                        fixed_content=current_content,
                    )
                # Re-parse errors for next iteration
                stderr = compile_result.data.get("stderr", "") if compile_result.data else ""
                new_errors = []
                for e in (compile_result.data.get("errors") or []) if compile_result.data else []:
                    new_errors.append(CompileError(
                        file=e.get("file", ""), line=e.get("line", 0),
                        column=e.get("column", 0), message=e.get("message", ""),
                    ))
                if not new_errors and stderr.strip():
                    new_errors = [CompileError(file="", line=0, column=0,
                                               message=stderr.strip()[:2000])]
                errors = new_errors
            except Exception as e:
                logger.warning(f"fix_compile_errors attempt {attempt} failed: {e}")
        return FixResult(
            success=False, fixed_code=current_code,
            changes_made=changes, attempts_used=max_attempts,
            fixed_content=current_content,
        )

    async def fetch_source_from_repo(
        self, repo: str, file_paths: list[str], branch: str = "main",
    ) -> list[SourceFile]:
        """Fetch remote repository source files via Bitbucket MCP."""
        source_files: list[SourceFile] = []
        for path in file_paths:
            try:
                result = await self._mcp.call_tool("bb_get_file",
                    repo=repo, path=path, ref=branch,
                )
                if result.success:
                    source_files.append(SourceFile(
                        path=path, content=result.data.get("content", ""),
                        repo=repo, branch=branch,
                    ))
            except Exception as e:
                logger.warning(f"Could not fetch {path} from {repo}: {e}")
        return source_files

    # ========== BaseAgent abstract method implementation ==========

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, UnitTestContext):
            raise ValidationError("UnitTestAgent requires UnitTestContext")
        ctx = context
        if not ctx.source_files and not ctx.source_contents:
            raise ValidationError("At least one source file is required")
        if len(ctx.source_files) > self._MAX_SOURCE_FILES:
            raise ValidationError(
                f"A maximum of {self._MAX_SOURCE_FILES} source files is allowed"
            )
        normalized_paths: list[str] = []
        for item in ctx.source_files:
            if isinstance(item, (list, tuple)):
                if len(item) != 2 or not isinstance(item[0], str) or not isinstance(item[1], str):
                    raise ValidationError("Source file entries must be paths or (path, content) pairs")
                path, content = item[0].strip(), item[1]
                if not path:
                    raise ValidationError("Source file paths must be non-empty and valid")
                if path not in ctx.source_contents:
                    ctx.source_contents[path] = content
            elif isinstance(item, str):
                path = item.strip()
            else:
                raise ValidationError("Source file entries must be strings")
            if not path or "\x00" in path or len(path) > 4096:
                raise ValidationError("Source file paths must be non-empty and valid")
            normalized_paths.append(path)
        if len(set(normalized_paths)) != len(normalized_paths):
            raise ValidationError("Source file paths must be unique")
        ctx.source_files = normalized_paths
        if max(len(normalized_paths), len(ctx.source_contents)) > self._MAX_SOURCE_FILES:
            raise ValidationError(
                f"A maximum of {self._MAX_SOURCE_FILES} source files is allowed"
            )

        total_chars = 0
        for path, content in ctx.source_contents.items():
            if not isinstance(path, str) or not path.strip():
                raise ValidationError("Source content keys must be non-empty paths")
            if not isinstance(content, str):
                raise ValidationError("Source content values must be strings")
            if len(content) > self._MAX_SOURCE_FILE_CHARS:
                raise ValidationError(
                    f"Source file content must not exceed {self._MAX_SOURCE_FILE_CHARS} characters"
                )
            total_chars += len(content)
        if total_chars > self._MAX_SOURCE_TOTAL_CHARS:
            raise ValidationError("Combined source content exceeds the configured size limit")

        if ctx.framework not in ("gtest", "unity"):
            raise ValidationError(f"Invalid framework: {ctx.framework}")
        layer = str(ctx.layer or "").strip().lower()
        if layer not in self._ALLOWED_LAYERS:
            raise ValidationError(f"Invalid layer: {ctx.layer}")
        if layer != ctx.layer:
            ctx.layer = layer
        if ctx.build_profile not in self._ALLOWED_BUILD_PROFILES:
            raise ValidationError(f"Invalid build profile: {ctx.build_profile}")
        if ctx.generation_method not in self._ALLOWED_GENERATION_METHODS:
            raise ValidationError(f"Invalid generation method: {ctx.generation_method}")
        for field_name, value in (
            ("coverage_target", ctx.coverage_target),
            ("branch_coverage_target", ctx.branch_coverage_target),
            ("function_coverage_target", ctx.function_coverage_target),
        ):
            if not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
                raise ValidationError(f"{field_name} must be between 0 and 1")
        for field_name, value in (
            ("max_iterations", ctx.max_iterations),
            ("coverage_max_iterations", ctx.coverage_max_iterations),
        ):
            if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= 10:
                raise ValidationError(f"{field_name} must be between 1 and 10")
        if not isinstance(ctx.platform, str) or not ctx.platform.strip() or len(ctx.platform) > 128:
            raise ValidationError("platform must be a non-empty string")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        """CLI mode uses linear pipeline directly; non-CLI mode uses LangGraph workflow."""
        ctx: UnitTestContext = context  # type: ignore[assignment]
        task_id = ctx.task_id
        self._is_cancelled(task_id)

        # CLI mode: linear pipeline directly, CLI has built-in tool capabilities (read/write, compile, fix)
        # LangGraph workflow uses CLI as text generator, wastes CLI capability and is prone to parsing failures
        if ctx.generation_method == "cli":
            logger.info("CLI mode: using linear pipeline directly (CLI has built-in tools)")
            return await self._process_task_linear(task, context)

        source_files: list[str] = []
        source_contents: dict[str, str] = dict(ctx.source_contents)
        for item in ctx.source_files:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                source_files.append(item[0])
                source_contents.setdefault(item[0], item[1])
            else:
                source_files.append(item)

        if any(
            len(content or "") >= self._LARGE_SOURCE_CONTEXT_THRESHOLD
            for content in source_contents.values()
        ):
            logger.info(
                "[UnitTest] Source at or above 5k detected; using the linear pipeline "
                "for structured source analysis and bounded prompt context"
            )
            return await self._process_task_linear(task, context)

        async def progress_bridge(progress: int, stage: str, message: str):
            await self._report_progress(task_id, progress, stage, message)

        workflow = UnitTestWorkflow(
            llm_bridge=self._llm,
            mcp_client=self._mcp,
            fetch_source_fn=self.fetch_source_from_repo,
            fix_compile_errors_fn=self.fix_compile_errors,
            progress_fn=progress_bridge,
            max_retries=ctx.max_iterations,
            max_llm_calls=8,
        )
        compiled = workflow.build()
        if compiled is None:
            logger.warning("langgraph unavailable, falling back to linear pipeline")
            self._is_cancelled(task_id)
            return await self._process_task_linear(task, context)

        initial_state = UnitTestState({
            "source_files": source_files,
            "source_content": source_contents,
            "source_path_map": dict(ctx.source_path_map),
            "repo_slug": ctx.repo or "firmware",
            "branch": ctx.branch,
            "project_root": ctx.output_dir or ".",
            "output_dir": ctx.output_dir or "",
            "test_framework": ctx.framework,
            "target_coverage": ctx.target_coverage,
            "target_branch_coverage": ctx.target_branch_coverage,
            "target_function_coverage": ctx.target_function_coverage,
            "enable_mock": ctx.enable_mock,
            "compile_verify": ctx.compile_verify,
            "metadata": dict(ctx.metadata),
            "max_iterations": ctx.max_iterations,
            "coverage_max_iterations": ctx.coverage_max_iterations,
            "coverage_improvement_count": 0,
            "coverage_stagnant_count": 0,
            "coverage_last_signature": "",
            "build_profile": ctx.build_profile,
            "platform": ctx.platform,
            "detected_layer": ctx.layer,
        })

        try:
            try:
                final_state = await compiled.ainvoke(
                    initial_state,
                    config={"recursion_limit": 80},
                )
            except TypeError as e:
                if "unexpected keyword argument 'config'" not in str(e):
                    raise
                final_state = await compiled.ainvoke(initial_state)
        except RuntimeError as e:
            if "LLM call limit reached" in str(e):
                logger.error(f"Workflow terminated: {e}, falling back to linear pipeline")
                self._is_cancelled(task_id)
                return await self._process_task_linear(task, context)
            raise

        if final_state is None:
            logger.warning("Workflow returned None state, falling back to linear pipeline")
            self._is_cancelled(task_id)
            return await self._process_task_linear(task, context)

        result = UnitTestWorkflow.map_state_to_result(final_state, task_id)

        if ctx.output_dir and result.generated_tests:
            await self._report_progress(task_id, 99, "save", "Saving test files to project")
            save_failures: list[dict[str, Any]] = []
            for test in result.generated_tests:
                if not test.test_content:
                    continue
                _wf_real = (
                    ctx.source_path_map.get(test.source_file)
                    or ctx.source_path_map.get(os.path.basename(test.source_file))
                    or (test.source_file if os.path.isabs(test.source_file) else None)
                )
                _wf_root = self._resolve_context_project_root(ctx, _wf_real)
                file_paths = generate_file_paths(
                    source_filename=test.source_file,
                    layer=ctx.layer,
                    project_root=_wf_root,
                    platform=ctx.platform,
                    source_path=_wf_real or test.source_file,
                    source_content=self._source_content_for_test(test, ctx),
                )
                file_paths = filter_mock_paths(file_paths, ctx.enable_mock)
                headers = generate_header_templates(file_paths, enable_mock=ctx.enable_mock)
                test.test_header_content = test.test_header_content or headers["test_header"]
                test.mock_header_content = test.mock_header_content or headers["mock_header"]
                self._clear_disabled_mock_content(test, ctx)
                test_content_map = {
                    "test_impl": test.test_content,
                    "test_header": test.test_header_content or "",
                    "mock_impl": test.mock_content or "",
                    "mock_header": test.mock_header_content or "",
                    "stub_impl": test.stub_content or "",
                    "stub_header": test.stub_header_content or "",
                }
                save_result = save_test_files_to_project(test_content_map, file_paths)
                for item in save_result.get("success", []):
                    logger.info(f"Saved: {item['path']}")
                for item in save_result.get("failed", []):
                    logger.warning(f"Failed to save: {item}")
                    save_failures.append(item)
            if save_failures:
                result.data = dict(result.data or {})
                result.data["save_failures"] = save_failures
                result.message = (
                    f"{result.message}; {len(save_failures)} generated file(s) could not be saved"
                )

        return result

    async def _process_task_linear(self, task: str, context: AgentContext) -> AgentResult:
        ctx: UnitTestContext = context  # type: ignore[assignment]
        task_id = ctx.task_id
        generated_tests: list[GeneratedTest] = []
        save_failures: list[dict[str, Any]] = []
        iterations_used = 0

        # Infer the real project root once for the entire linear pipeline.
        # ctx.output_dir may point to the source file directory (e.g. stm32u3/), not the project root (e.g. platformkit/).
        _linear_real_path = next(
            (v for v in ctx.source_path_map.values() if v and os.path.isabs(v)),
            None
        )
        _project_root = self._resolve_context_project_root(ctx, _linear_real_path)
        if ctx.metadata.get("driver_task_id"):
            _linear_inferred = _project_root
        else:
            from .paths import find_project_root_for_source
            _linear_inferred = find_project_root_for_source(_linear_real_path) if _linear_real_path else None
        logger.info(f"[ProjectRoot] linear pipeline project_root='{_project_root}' "
                    f"(inferred={bool(_linear_inferred)}, output_dir='{ctx.output_dir}')")
        header_search_root = _project_root

        await self._report_progress(task_id, 5, "fetch", "Fetching source files")
        source_contents = dict(ctx.source_contents)
        for file_path in ctx.source_files:
            if file_path not in source_contents:
                try:
                    result = await self._mcp.call_tool("bb_get_file",
                        repo=ctx.repo or "firmware", path=file_path, ref=ctx.branch,
                    )
                    if result.success:
                        source_contents[file_path] = result.data.get("content", "")
                except Exception:
                    logger.warning(f"Could not read file {file_path} via MCP, skipping")

        total_files = len(source_contents)
        if total_files == 0:
            return UnitTestResult(
                task_id=task_id, status=AgentStatus.FAILED,
                message="No source files to process",
            )

        if (ctx.layer or "").strip().lower() == "auto":
            sample_file = next(iter(source_contents.keys()))
            # Use the real source path from source_path_map if available;
            # otherwise fall back to the bare filename (browser upload scenario).
            real_source_path = (
                ctx.source_path_map.get(sample_file)
                or ctx.source_path_map.get(os.path.basename(sample_file))
                or sample_file
            )
            # If no project root was found (_linear_inferred is None), the file is
            # a standalone file outside any known project. Filename-based heuristics
            # (e.g. "hal" in "hal-adc.c") are misleading here because they reflect
            # the vendor HAL prefix in the filename, not the actual code layer.
            # Use 'common' to route to a neutral test scaffold.
            if _linear_inferred is None:
                detected_layer = "common"
                logger.info(
                    f"[Layer] Standalone file (no project root) → layer='common' "
                    f"for source '{sample_file}' (real_path='{real_source_path}')"
                )
            else:
                detected_layer = detect_layer_from_filename(
                    filename=os.path.basename(sample_file),
                    layer_hint=None,
                    source_path=real_source_path,
                )
                logger.info(
                    f"[Layer] Auto-detected layer='{detected_layer}' "
                    f"from source '{sample_file}' (real_path='{real_source_path}')"
                )
            ctx.layer = detected_layer

        # --- CLI Team mode: multi-file parallel generation ---
        if ctx.generation_method == "cli" and total_files > 1:
            # Headers are never independent generation targets:
            # - a header whose implementation is also uploaded is consumed by
            #   that implementation's own module (avoids a duplicate module)
            # - a header with no implementation in the batch has nothing
            #   testable to link against ("declared but not defined" rule);
            #   tests for it can only mock the module itself and break the
            #   single test product for every other module.
            # Headers still reach the tree via the scaffold and remain include
            # /dependency context for the implementation modules.
            generation_sources: dict[str, str] = {}
            for _fp_header, _content_header in source_contents.items():
                _name = os.path.basename(_fp_header)
                if not _name.lower().endswith((".h", ".hpp")):
                    generation_sources[_fp_header] = _content_header
                    continue
                _stem = os.path.splitext(_name)[0]
                _has_impl = any(
                    os.path.splitext(os.path.basename(_other))[0] == _stem
                    and _other.lower().endswith((".c", ".cpp", ".cc"))
                    for _other in source_contents
                )
                logger.info(
                    f"[Team] Skipping header '{_name}' as generation target: "
                    + (
                        "implementation also uploaded (module generated from it)"
                        if _has_impl
                        else "no implementation in upload batch (nothing testable)"
                    )
                )
            if not generation_sources:
                raise ValueError(
                    "No implementation file (.c/.cpp) in the upload batch: "
                    "unit tests can only be generated for modules that have "
                    "an implementation to compile and cover"
                )
            await self._report_progress(
                task_id, 20, "generate",
                f"CLI Team mode: generating tests for {len(generation_sources)} file(s) in parallel"
            )
            # First collect context for all files
            all_file_paths: dict[str, dict] = {}
            all_context: dict[str, dict] = {}
            for file_path, content in generation_sources.items():
                src_filename = os.path.basename(file_path)
                module_name = os.path.splitext(src_filename)[0]
                if ctx.layer == "app":
                    for prefix in ("app-", "app_"):
                        if module_name.startswith(prefix):
                            module_name = module_name[len(prefix):]
                            break
                else:
                    for prefix in (f"{ctx.layer}-", "hal-", "driver-"):
                        if module_name.startswith(prefix):
                            module_name = module_name[len(prefix):]
                            break

                # 🚀 Performance optimization: parallelize independent lookup operations
                # Use asyncio.to_thread() to run synchronous functions in thread pool in parallel
                # Original sequential time: ~40s, after optimization expected: ~15s (62.5% speedup)
                logger.info(f"[Parallel] Preparing context for {file_path} in parallel (team mode)")

                try:
                    should_scan_existing_mocks = (ctx.enable_mock and ctx.layer != "common" and _linear_inferred is not None)
                    if not should_scan_existing_mocks:
                        logger.info(
                            f"[Parallel] Skip existing mock scan for {file_path} "
                            f"(layer={ctx.layer}, inferred_root={bool(_linear_inferred)})"
                        )

                    # First parallel batch: independent lookup operations (no dependencies)
                    header_content, vendor_api_ref, existing_mock_ref = await asyncio.gather(
                        # Task 1: Find header file (~10s)
                        asyncio.to_thread(
                            find_and_read_header_file,
                            src_filename, header_search_root, ctx.layer
                        ),
                        # Task 2: Find Vendor API definitions (~5s)
                        asyncio.to_thread(
                            find_vendor_hal_api_definitions,
                            ctx.output_dir or ".", ctx.layer, module_name, ctx.platform
                        ),
                        # Task 3: Find existing Mock files (~15s)
                        (
                            asyncio.to_thread(
                                find_existing_mock_files,
                                ctx.output_dir or ".", ctx.platform, module_name, ctx.layer
                            )
                            if should_scan_existing_mocks
                            else asyncio.sleep(0, result="")
                        ),
                    )

                    # 🚀 Prompt optimization: smart filter API reference
                    # Extract called functions from source file, keep only relevant API definitions
                    if vendor_api_ref:
                        called_functions = extract_called_functions(content, ctx.layer)
                        vendor_api_ref = filter_relevant_apis(vendor_api_ref, called_functions)
                        logger.info(f"✂️ [API Filter] Optimized API reference for {file_path} (team mode)")

                    # Second serial batch: lookups that depend on first batch results
                    dependent_headers = find_dependent_hal_headers(
                        header_content, header_search_root, ctx.layer
                    ) if header_content else ""

                    # Third serial batch: Mock dependency analysis (HAL layer only)
                    mock_dep_guidance = ""
                    if ctx.enable_mock and ctx.layer == "hal" and ctx.output_dir:
                        ext_calls = analyze_source_external_hal_calls(content, module_name)
                        if ext_calls:
                            missing = find_missing_mock_files(ext_calls, ctx.output_dir, ctx.platform)
                            for info in missing:
                                create_external_mock_file(info, ctx.output_dir, ctx.platform)
                            mock_dep_guidance = generate_mock_dependency_guidance(
                                ext_calls, ctx.output_dir, ctx.platform, module_name,
                            )

                    logger.info(f"[Parallel] Context preparation completed for {file_path} (team mode)")

                except Exception as e:
                    logger.error(f"[Parallel] Context preparation failed: {e}")
                    raise

                # Infer project root from the real absolute source path
                _tm_real_path = (
                    ctx.source_path_map.get(file_path)
                    or ctx.source_path_map.get(os.path.basename(file_path))
                    or (file_path if os.path.isabs(file_path) else None)
                )
                _tm_project_root = self._resolve_context_project_root(ctx, _tm_real_path)

                fp = generate_file_paths(
                    source_filename=file_path, layer=ctx.layer,
                    project_root=_tm_project_root,
                    platform=ctx.platform,
                    source_path=_tm_real_path or file_path,
                )
                all_file_paths[file_path] = fp
                all_context[file_path] = {
                    "header": header_content, "deps": dependent_headers,
                    "vendor": vendor_api_ref, "mock": existing_mock_ref,
                    "guidance": mock_dep_guidance,
                }

            team_results = await self._generate_tests_via_cli_team(
                generation_sources, ctx, all_file_paths, all_context,
            )
            if not ctx.enable_mock:
                for team_test in team_results:
                    self._clear_disabled_mock_content(team_test, ctx)
            generated_tests.extend(team_results)

            # Fallback ungenerated files in team to single-file CLI or API
            team_generated = {t.source_file for t in team_results}
            for file_path, content in generation_sources.items():
                if file_path in team_generated:
                    continue
                logger.info(f"[CLI-TEAM] Fallback to single-file for {file_path}")
                fp = all_file_paths[file_path]
                actx = all_context[file_path]
                test = await self._generate_test_via_cli(
                    file_path, content, ctx, fp,
                    header_content=actx.get("header", ""),
                    dependent_headers=actx.get("deps", ""),
                    vendor_api_ref=actx.get("vendor", ""),
                    existing_mock_ref=actx.get("mock", ""),
                    mock_dependency_guidance=actx.get("guidance", ""),
                )
                if test is None:
                    test = await self._generate_test_for_file(
                        file_path, content, ctx,
                        header_content=actx.get("header", ""),
                        dependent_headers=actx.get("deps", ""),
                        vendor_api_ref=actx.get("vendor", ""),
                        existing_mock_ref=actx.get("mock", ""),
                        mock_dependency_guidance=actx.get("guidance", ""),
                    )
                generated_tests.append(test)
        else:
            # --- Single-file mode (original logic) ---
            # A lone header upload has no implementation to compile and cover.
            if total_files == 1 and next(iter(source_contents), "").lower().endswith(
                (".h", ".hpp")
            ):
                raise ValueError(
                    "The upload contains only a header file: unit tests can "
                    "only be generated for modules with an implementation "
                    "(.c/.cpp) to compile and cover"
                )
            for idx, (file_path, content) in enumerate(source_contents.items()):
                self._is_cancelled(task_id)
                progress = int(15 + (idx / total_files) * 40)
                await self._report_progress(
                    task_id, progress, "generate",
                    f"Generating tests for {file_path} ({idx+1}/{total_files})"
                )

                src_filename = os.path.basename(file_path)
                module_name = os.path.splitext(src_filename)[0]
                if ctx.layer == "app":
                    for prefix in ("app-", "app_"):
                        if module_name.startswith(prefix):
                            module_name = module_name[len(prefix):]
                            break
                else:
                    for prefix in (f"{ctx.layer}-", "hal-", "driver-"):
                        if module_name.startswith(prefix):
                            module_name = module_name[len(prefix):]
                            break

                # 🚀 Performance optimization: parallel independent lookup operations
                # Wrap sync functions to thread pool using asyncio.to_thread()
                # Original serial time: ~40s, optimized: ~15s (62.5% speedup)
                logger.info(f"[Parallel] Preparing context for {file_path} in parallel")

                try:
                    should_scan_existing_mocks = (ctx.enable_mock and ctx.layer != "common" and _linear_inferred is not None)
                    if not should_scan_existing_mocks:
                        logger.info(
                            f"[Parallel] Skip existing mock scan for {file_path} "
                            f"(layer={ctx.layer}, inferred_root={bool(_linear_inferred)})"
                        )

                    # Batch 1 parallel: independent lookup operations (no dependencies)
                    header_content, vendor_api_ref, existing_mock_ref = await asyncio.gather(
                        # Task 1: find header file (~10s)
                        asyncio.to_thread(
                            find_and_read_header_file,
                            src_filename, ctx.output_dir or ".", ctx.layer
                        ),
                        # Task 2: find Vendor API definitions (~5s)
                        asyncio.to_thread(
                            find_vendor_hal_api_definitions,
                            ctx.output_dir or ".", ctx.layer, module_name, ctx.platform
                        ),
                        # Task 3: find existing Mock files (~15s)
                        (
                            asyncio.to_thread(
                                find_existing_mock_files,
                                ctx.output_dir or ".", ctx.platform, module_name, ctx.layer
                            )
                            if should_scan_existing_mocks
                            else asyncio.sleep(0, result="")
                        ),
                    )

                    # 🚀 Prompt optimization: intelligent API reference filtering
                    # Extract called functions from source, keep only relevant API definitions
                    if vendor_api_ref:
                        called_functions = extract_called_functions(content, ctx.layer)
                        vendor_api_ref = filter_relevant_apis(vendor_api_ref, called_functions)
                        logger.info(f"✂️ [API Filter] Optimized API reference for {file_path}")

                    # Batch 2 serial: lookups depending on batch 1 results
                    dependent_headers = find_dependent_hal_headers(
                        header_content, ctx.output_dir or ".", ctx.layer
                    ) if header_content else ""

                    # Batch 3 serial: Mock dependency analysis (HAL layer only)
                    mock_dep_guidance = ""
                    if ctx.enable_mock and ctx.layer == "hal" and ctx.output_dir:
                        ext_calls = analyze_source_external_hal_calls(content, module_name)
                        if ext_calls:
                            missing = find_missing_mock_files(ext_calls, ctx.output_dir, ctx.platform)
                            for info in missing:
                                create_external_mock_file(info, ctx.output_dir, ctx.platform)
                            mock_dep_guidance = generate_mock_dependency_guidance(
                                ext_calls, ctx.output_dir, ctx.platform, module_name,
                            )

                    logger.info(f"[Parallel] Context preparation completed for {file_path}")

                except Exception as e:
                    logger.error(f"[Parallel] Context preparation failed: {e}")
                    raise

                # Infer project root from the real absolute path to avoid ctx.output_dir pointing to the source file directory
                _fp_real_path = (
                    ctx.source_path_map.get(file_path)
                    or ctx.source_path_map.get(os.path.basename(file_path))
                    or (file_path if os.path.isabs(file_path) else None)
                )
                _fp_project_root = self._resolve_context_project_root(ctx, _fp_real_path)

                fp = generate_file_paths(
                    source_filename=file_path, layer=ctx.layer,
                    project_root=_fp_project_root,
                    platform=ctx.platform,
                    source_path=_fp_real_path or file_path,
                )

                test: Optional[GeneratedTest] = None
                if ctx.generation_method == "cli":
                    logger.info(f"[CLI] Generating tests via Claude CLI for {file_path}")
                    logger.info(
                        f"[CLI] Target paths platform={fp.get('platform', ctx.platform)}: "
                        f"test={fp.get('test_impl_path')}, mock={fp.get('mock_impl_path')}"
                    )
                    test = await self._generate_test_via_cli(
                        file_path, content, ctx, fp,
                        header_content=header_content,
                        dependent_headers=dependent_headers,
                        vendor_api_ref=vendor_api_ref,
                        existing_mock_ref=existing_mock_ref,
                        mock_dependency_guidance=mock_dep_guidance,
                    )

                if test is None:
                    if ctx.generation_method == "cli":
                        logger.info(f"[CLI] Falling back to LLM API for {file_path}")
                    test = await self._generate_test_for_file(
                        file_path, content, ctx,
                        header_content=header_content,
                        dependent_headers=dependent_headers,
                        vendor_api_ref=vendor_api_ref,
                        existing_mock_ref=existing_mock_ref,
                        mock_dependency_guidance=mock_dep_guidance,
                    )
                    if ctx.enable_mock:
                        await self._report_progress(
                            task_id, progress + 5, "mock",
                            f"Generating mock for {file_path} ({idx+1}/{total_files})"
                        )
                        mock_impl, mock_header = await self._generate_mock_for_file(
                            file_path, content, ctx
                        )
                        test.mock_content = mock_impl
                        test.mock_header_content = mock_header

                if test is not None and not ctx.enable_mock:
                    self._clear_disabled_mock_content(test, ctx)
                generated_tests.append(test)

        # Persist generation evidence before the build gate.  A long source is
        # considered generated only when the parsed test artifact is non-empty;
        # the output hash makes resume decisions auditable and prevents stale
        # files from being mistaken for newly generated content.
        for generated_test in generated_tests:
            output_hash = self._generated_output_sha256(generated_test)
            if output_hash:
                self._update_large_file_checkpoints(
                    ctx,
                    generated_test.source_file,
                    source_sha256=self._source_hash_for_context(ctx, generated_test.source_file),
                    generation_status="passed",
                    output_sha256=output_hash,
                    last_gate="generation",
                )

        # Parsing is a distinct workflow node.  The CLI and API generators
        # both return structured GeneratedTest objects, so emit an explicit
        # event after generation rather than leaving the frontend to infer the
        # state from the later build stage.
        if generated_tests:
            await self._report_progress(
                task_id,
                50,
                "parse",
                f"Parsed generated test output ({len(generated_tests)} file(s))",
            )

        if ctx.layer == "app":
            offending_tests = [
                test.source_file
                for test in generated_tests
                if self._generated_test_has_app_libs_reference(test)
            ]
            if offending_tests:
                logger.warning(
                    "APP layer generated artifacts reference libs/platformkit; "
                    "continuing with warning: {}",
                    ", ".join(offending_tests),
                )

        # App-layer QBS projects are isolated per task.  Prepare the target
        # before any compile or CLI verification so the compiler sees exactly
        # the generated source/test/mock set and no stale aggregate entries.
        if ctx.compile_verify and ctx.layer == "app" and generated_tests and _project_root:
            await self._report_progress(
                task_id, 53, "qbs_config", "Preparing isolated App QBS target"
            )
            self._prepare_app_qbs_target(generated_tests, ctx, _project_root)

        iterations_used = 1

        # Determine if CLI succeeded for all tests — skip redundant Phase 3/4.
        # When CLI exits 0, it has already: written files, updated QBS config,
        # compiled, and run tests. Phase 5 (_collect_real_coverage) will
        # independently rebuild + run + gcov, so Phase 3/4 are not needed.
        if not ctx.compile_verify:
            for test in generated_tests:
                test.compile_success = False

        cli_all_compiled = (
            ctx.compile_verify
            and ctx.generation_method == "cli"
            and generated_tests
            and all(t.compile_success for t in generated_tests)
        )
        # Verify CLI's compile claim with an actual QBS build.
        # CLI exit_code=0 does not guarantee compilation succeeded
        # (e.g. missing QBS file, timeout before compile step).
        if cli_all_compiled:
            if not _project_root:
                # Cannot verify without a project root — conservatively fall through to Phase 3
                logger.warning(
                    "[Phase-Skip] _project_root is None, cannot verify CLI compile "
                    "— falling through to Phase 3"
                )
                for t in generated_tests:
                    t.compile_success = False
                cli_all_compiled = False
            else:
                verify_result = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: run_qbs_build(
                        layer=ctx.layer,
                        platform=ctx.platform,
                        project_root=_project_root,
                        build_profile=ctx.build_profile,
                        qbs_project_path=ctx.qbs_project_path,
                        qbs_file=ctx.qbs_file,
                        product_name=(ctx.qbs_products or [None])[0],
                    ),
                )
                if verify_result.get("success"):
                    for t in generated_tests:
                        t.compile_success = True
                        t.compile_error = ""
                        t.compile_error_code = None
                    logger.info(
                        f"[Phase-Skip] CLI compile verified for all {len(generated_tests)} tests, "
                        "skipping Phase 3 (compile) and Phase 4 (run)"
                    )
                else:
                    logger.warning(
                        f"[Phase-Skip] CLI claimed compile success but verification FAILED: "
                        f"{verify_result.get('error')}"
                    )

                    # Always reset compile_success on verification failure
                    # This prevents false positives when CLI claims success but QBS build failed
                    for t in generated_tests:
                        t.compile_success = False
                        t.compile_error = verify_result.get("output") or verify_result.get("error") or "QBS verification failed"
                        t.compile_error_code = verify_result.get("error_code")
                    cli_all_compiled = False

                    if not verify_result.get("retryable", True):
                        logger.error(
                            "[Phase-Skip] QBS verification failed with a non-retryable "
                            f"precondition error: code={verify_result.get('error_code')}, "
                            f"error={verify_result.get('error')}"
                        )
                    elif ctx.layer == "app":
                        # APP layer: backend must NOT rewrite test_app.qbs; CLI owns project
                        # mutation. Fall through to Phase 3 so _autonomous_fix can handle
                        # the failure with full CLI context.
                        logger.info(
                            "[Phase-Skip][APP] Skipping backend QBS repair — "
                            "falling through to Phase 3 for CLI-driven fix"
                        )
                    else:
                        # Non-APP layers: attempt lightweight backend QBS config repair
                        if _project_root:
                            for test in generated_tests:
                                try:
                                    # Get real source path for accurate platform detection
                                    _real_src = (
                                        ctx.source_path_map.get(test.source_file)
                                        or ctx.source_path_map.get(os.path.basename(test.source_file))
                                        or (test.source_file if os.path.isabs(test.source_file) else None)
                                    )
                                    file_paths = generate_file_paths(
                                        source_filename=test.source_file,
                                        layer=ctx.layer,
                                        project_root=_project_root,
                                        platform=ctx.platform,
                                        source_path=_real_src,
                                    )
                                    module_name = file_paths.get("module_name", "")
                                    if not module_name:
                                        base = os.path.splitext(os.path.basename(test.source_file))[0]
                                        for prefix in (
                                            "controller-", "controller_", "ctrl-", "ctrl_",
                                            "driver-", "driver_", "hal-", "hal_", "app-", "app_",
                                        ):
                                            if base.startswith(prefix):
                                                base = base[len(prefix):]
                                                break
                                        module_name = base
                                    qbs_options = {"enable_mock": False} if not ctx.enable_mock else {}
                                    update_qbs_config(
                                        module_name=module_name,
                                        layer=ctx.layer,
                                        platform=ctx.platform,
                                        project_root=_project_root,
                                        **qbs_options,
                                    )
                                except Exception as e:
                                    logger.warning(f"QBS config repair failed for {test.source_file}: {e}")
                            # Re-verify after repair
                            retry_result = await asyncio.get_event_loop().run_in_executor(
                                None,
                                lambda: run_qbs_build(
                                    layer=ctx.layer,
                                    platform=ctx.platform,
                                    project_root=_project_root,
                                    build_profile=ctx.build_profile,
                                    qbs_project_path=ctx.qbs_project_path,
                                    qbs_file=ctx.qbs_file,
                                    product_name=(ctx.qbs_products or [None])[0],
                                ),
                            )
                            if retry_result.get("success"):
                                for t in generated_tests:
                                    t.compile_success = True
                                    t.compile_error = ""
                                    t.compile_error_code = None
                                cli_all_compiled = True
                                logger.info(
                                    "[Phase-Skip] QBS config repair succeeded, skipping Phase 3/4"
                                )
                            else:
                                logger.warning(
                                    f"[Phase-Skip] QBS config repair failed: "
                                    f"{retry_result.get('error')} — falling through to Phase 3"
                                )
                                for t in generated_tests:
                                    t.compile_success = False
                                    t.compile_error = retry_result.get("output") or retry_result.get("error") or "QBS verification failed"
                                    t.compile_error_code = retry_result.get("error_code")
                                cli_all_compiled = False
                        else:
                            for t in generated_tests:
                                t.compile_success = False
                            cli_all_compiled = False
                    # APP layer unconditionally falls through without setting cli_all_compiled
                    if ctx.layer == "app":
                        for t in generated_tests:
                            t.compile_success = False
                        cli_all_compiled = False

        # Phase 3: Compile & fix
        # When CLI succeeded AND post-CLI build verification passed (cli_all_compiled),
        # skip — CLI already updated QBS, compiled, and verified.
        # Phase 5 (_collect_real_coverage) will independently rebuild for .gcno generation.
        if cli_all_compiled:
            await self._report_progress(task_id, 55, "qbs_config", "QBS config already updated by CLI")
            await self._report_progress(task_id, 60, "compile", "Compilation already done by CLI")
            await self._report_progress(
                task_id,
                75,
                "run",
                "Tests already executed and verified by CLI",
            )
        elif ctx.compile_verify and ctx.output_dir:
            # When verification failed, all tests with compile_success=False need to go through compilation
            if ctx.generation_method == "cli":
                api_tests = [t for t in generated_tests if not t.compile_success]
            else:
                api_tests = [t for t in generated_tests if not t.compile_success]
            if api_tests:
                logger.info(f"[Phase3] Starting auto-fix for {len(api_tests)} failed tests")
                # Update QBS config before compile
                # APP layer is excluded: backend must not dynamically rewrite test_app.qbs
                # (prefix mutation with multiple source dirs causes path corruption).
                # Only non-APP layers run backend update_qbs_config in this path.
                if hasattr(ctx, "auto_update_qbs") and ctx.auto_update_qbs and ctx.layer != "app":
                    await self._report_progress(task_id, 55, "qbs_config", "Updating QBS configuration")
                    for test in generated_tests:
                        module_name = getattr(test, "source_file", "<unknown>")
                        try:
                            # Get real source path for accurate platform detection
                            _real_src = (
                                ctx.source_path_map.get(test.source_file)
                                or ctx.source_path_map.get(os.path.basename(test.source_file))
                                or (test.source_file if os.path.isabs(test.source_file) else None)
                            )
                            file_paths = generate_file_paths(
                                source_filename=test.source_file,
                                layer=ctx.layer,
                                project_root=_project_root,
                                platform=ctx.platform,
                                source_path=_real_src,
                            )
                            module_name = file_paths.get("module_name", "")
                            if not module_name:
                                base = os.path.splitext(os.path.basename(test.source_file))[0]
                                module_name = base.replace(f"{ctx.layer}-", "").replace("hal-", "")
                            qbs_options = {"enable_mock": False} if not ctx.enable_mock else {}
                            update_qbs_config(
                                module_name=module_name,
                                layer=ctx.layer,
                                platform=ctx.platform,
                                project_root=_project_root,
                                **qbs_options,
                            )
                        except Exception as e:
                            logger.warning(f"update_qbs_config failed for {module_name}: {e}")
                elif hasattr(ctx, "auto_update_qbs") and ctx.auto_update_qbs and ctx.layer == "app":
                    await self._report_progress(task_id, 55, "qbs_config", "Ensuring APP QBS template exists")
                    from .qbs import _ensure_app_qbs_file
                    for test in generated_tests:
                        try:
                            _ensure_app_qbs_file(_project_root)
                        except Exception as e:
                            logger.warning(f"[APP] _ensure_app_qbs_file failed: {e}")

                await self._report_progress(task_id, 60, "compile", "Compiling generated tests")
                generated_tests, iterations_used = await self._compile_and_fix_tests(
                    generated_tests, ctx, task_id, project_root=_project_root,
                )
            else:
                logger.info("[Phase3] No tests need compilation")
        else:
            logger.warning(
                f"[Phase3] Skipped compile: compile_verify={ctx.compile_verify}, "
                f"output_dir={ctx.output_dir}"
            )

        # Phase 4: Run tests
        # When CLI succeeded, collect the executed test summary as well so
        # final reports still include test_count/failed_cases/test_output.
        # Phase 5 (_collect_real_coverage) may run them again for .gcda generation.
        test_output = ""
        test_count = 0
        failed_cases: list[str] = []
        if cli_all_compiled:
            await self._report_progress(task_id, 75, "run", "Collecting test results from CLI-verified build")
            test_output, test_count, failed_cases = await self._run_compiled_tests(
                ctx.output_dir, ctx, task_id
            )
            self._record_large_file_test_result(
                ctx, generated_tests, test_output, test_count, failed_cases
            )
            if not test_output and test_count == 0 and not failed_cases:
                logger.warning(
                    "[Phase4] CLI verified build succeeded but test summary could not be collected; "
                    "preserving CLI-run status without overwriting with synthetic counts"
                )
                test_output = "Tests already run by CLI; summary unavailable from backend rerun."
        elif ctx.compile_verify and ctx.output_dir and any(t.compile_success for t in generated_tests):
            # Phase 4: Run tests using qbs.run_test_executable which has smart path detection
            # Don't hardcode paths - let run_test_executable find the executable
            await self._report_progress(task_id, 75, "run", "Running tests")
            test_output, test_count, failed_cases = await self._run_compiled_tests(
                ctx.output_dir, ctx, task_id
            )
            self._record_large_file_test_result(
                ctx, generated_tests, test_output, test_count, failed_cases
            )

            # If test execution failed (no executable found), reset compile_success flags
            if test_count == 0 and not test_output:
                logger.warning(
                    "[Phase4] Test execution returned no results - executable may not exist. "
                    "Resetting compile_success flags."
                )
                for t in generated_tests:
                    t.compile_success = False
        else:
            compile_ok = [t.compile_success for t in generated_tests]
            logger.warning(
                f"[Phase4] Skipped run: compile_verify={ctx.compile_verify}, "
                f"output_dir={ctx.output_dir}, compile_success={compile_ok}"
            )

        if _has_real_test_failures(failed_cases) and _project_root and generated_tests:
            logger.warning(
                f"[Phase4][{ctx.layer}] Runtime tests failed after compilation; "
                f"attempting repair for {len(failed_cases)} failed case(s)"
            )
            failure_signature = tuple(sorted(failed_cases))
            consecutive_no_progress = 0
            for repair_attempt in range(1, max(1, ctx.max_iterations) + 1):
                await self._report_progress(
                    task_id,
                    80,
                    "autonomous_fix",
                    f"Repairing runtime test failures ({repair_attempt}/{ctx.max_iterations})",
                )
                repair_targets = [
                    (test, _filter_failed_cases_for_test(failed_cases, test))
                    for test in generated_tests
                    if test.test_content
                ]
                owner_targets = [item for item in repair_targets if item[1]]
                if owner_targets:
                    repair_targets = owner_targets
                elif repair_targets:
                    logger.info(
                        "[Phase4] Failed tests could not be assigned to a file; "
                        "trying the first generated test file"
                    )
                    repair_targets = [(repair_targets[0][0], list(failed_cases))]

                repaired_any = False
                for test, cases_for_file in repair_targets:
                    real_source = (
                        ctx.source_path_map.get(test.source_file)
                        or ctx.source_path_map.get(os.path.basename(test.source_file))
                        or (test.source_file if os.path.isabs(test.source_file) else None)
                    )
                    file_paths = generate_file_paths(
                        source_filename=os.path.basename(test.source_file),
                        layer=ctx.layer,
                        project_root=_project_root,
                        platform=ctx.platform,
                        source_path=real_source,
                        source_content=self._source_content_for_test(test, ctx),
                    )
                    repaired_any = await self._autonomous_fix_failed_tests(
                        test,
                        ctx,
                        file_paths,
                        cases_for_file,
                        test_output,
                        _project_root,
                    )
                    if repaired_any:
                        break

                if not repaired_any:
                    logger.warning(
                        f"[Phase4][{ctx.layer}] Runtime-test repair made no changes"
                    )
                    break

                repair_build_result = await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: run_qbs_build(
                        layer=ctx.layer,
                        platform=ctx.platform,
                        project_root=_project_root,
                        build_profile=ctx.build_profile,
                        qbs_project_path=ctx.qbs_project_path,
                        qbs_file=ctx.qbs_file,
                        product_name=(ctx.qbs_products or [None])[0],
                    ),
                )
                self._persist_qbs_compile_log(
                    ctx,
                    repair_build_result,
                    phase=f"runtime_test_repair_attempt_{repair_attempt}",
                    metadata={"project_root": _project_root},
                )
                repair_build_ok = bool(repair_build_result.get("success"))
                for test in generated_tests:
                    test.compile_success = repair_build_ok
                if not repair_build_ok:
                    logger.warning(
                        f"[Phase4][{ctx.layer}] Rebuild after runtime-test repair failed: "
                        f"{repair_build_result.get('error')}"
                    )
                    break

                test_output, test_count, failed_cases = await self._run_compiled_tests(
                    _project_root, ctx, task_id
                )
                self._record_large_file_test_result(
                    ctx, generated_tests, test_output, test_count, failed_cases
                )
                if not failed_cases and test_count > 0:
                    logger.info(
                        f"[Phase4][{ctx.layer}] Runtime-test repair passed; continuing to coverage"
                    )
                    break

                new_signature = tuple(sorted(failed_cases))
                if new_signature == failure_signature:
                    consecutive_no_progress += 1
                else:
                    consecutive_no_progress = 0
                    failure_signature = new_signature
                if consecutive_no_progress >= 2:
                    logger.warning(
                        f"[Phase4][{ctx.layer}] Runtime-test repair stopped making progress "
                        f"after {repair_attempt} attempt(s); retaining {len(failed_cases)} failure(s)"
                    )
                    break

        # Phase 5: Real coverage collection via gcov
        total_coverage = 0.0
        total_branch_coverage = 0.0
        total_function_coverage = 0.0
        coverage_data: dict = {}
        coverage_failed = False
        def _apply_coverage_data(data: dict, *, baseline: bool = False) -> None:
            nonlocal total_coverage, total_branch_coverage, total_function_coverage
            total_coverage = data.get("line_coverage", 0.0)
            total_branch_coverage = data.get("branch_coverage", 0.0)
            total_function_coverage = data.get("function_coverage", 0.0)
            per_file = data.get("per_file", {})
            for test in generated_tests:
                _src = os.path.normpath(test.source_file)
                file_cov = (
                    per_file.get(_src)
                    or per_file.get(test.source_file)
                    or per_file.get(os.path.basename(_src))
                    or {}
                )
                test.coverage = file_cov.get("line_coverage", 0.0)
                test.branch_coverage = file_cov.get("branch_coverage", 0.0)
                test.function_coverage = file_cov.get("function_coverage", 0.0)
                test.gcov_data = file_cov
                # A valid gcov result closes the coverage gate for every
                # checkpoint covered by this generated artifact.  The first
                # valid measurement is retained as the baseline; subsequent
                # measurements are written as the after value.
                if data.get("lines_total", 0) > 0 and not coverage_failed:
                    line_value = file_cov.get("line_coverage", total_coverage)
                    coverage_updates: dict[str, Any] = {
                        "coverage_after": line_value,
                        "last_gate": "coverage",
                    }
                    if baseline:
                        coverage_updates["coverage_before"] = line_value
                    self._update_large_file_checkpoints(
                        ctx,
                        test.source_file,
                        source_sha256=self._source_hash_for_context(ctx, test.source_file),
                        **coverage_updates,
                    )

        if ctx.compile_verify and ctx.output_dir and any(t.compile_success for t in generated_tests):
            # Collect coverage - run_test_executable already verified executable exists
            await self._report_progress(task_id, 85, "coverage", "Collecting coverage data")
            coverage_data = await self._collect_real_coverage(
                list(source_contents.keys()), ctx, project_root=_project_root
            )
            if coverage_data.get("coverage_build_failed"):
                coverage_repaired = False
                if not coverage_data.get("coverage_build_retryable", True):
                    logger.error(
                        "[COV] Coverage build precondition failed and cannot be repaired by "
                        f"generated-code changes: code={coverage_data.get('coverage_build_error_code')}, "
                        f"error={coverage_data.get('coverage_build_error')}"
                    )
                else:
                    for repair_attempt in range(1, ctx.max_iterations + 1):
                        error_msg = coverage_data.get("coverage_build_error", "Unknown error")
                        logger.warning(
                            f"[COV] Coverage QBS rebuild failed; entering repair attempt "
                            f"{repair_attempt}/{ctx.max_iterations}: {error_msg}"
                        )
                        await self._report_progress(
                            task_id, 85, "autonomous_fix",
                            f"Repairing coverage build failure (attempt {repair_attempt}/{ctx.max_iterations})"
                        )

                        repaired_any = False
                        for test in generated_tests:
                            if not test.test_content:
                                continue
                            real_src = (
                                ctx.source_path_map.get(test.source_file)
                                or ctx.source_path_map.get(os.path.basename(test.source_file))
                                or (test.source_file if os.path.isabs(test.source_file) else None)
                            )
                            file_paths = generate_file_paths(
                                source_filename=os.path.basename(test.source_file),
                                layer=ctx.layer,
                                project_root=_project_root,
                                platform=ctx.platform,
                                source_path=real_src,
                            )
                            repaired = await self._autonomous_fix_coverage_build(
                                test, ctx, file_paths, coverage_data, _project_root
                            )
                            repaired_any = repaired_any or repaired
                            if repaired:
                                break

                        if not repaired_any:
                            continue

                        coverage_data = await self._collect_real_coverage(
                            list(source_contents.keys()), ctx, project_root=_project_root
                        )
                        if not coverage_data.get("coverage_build_failed"):
                            coverage_repaired = True
                            break

                if coverage_repaired:
                    _apply_coverage_data(coverage_data, baseline=True)
                    coverage_failed = False
                else:
                    coverage_failed = True
            else:
                _apply_coverage_data(coverage_data, baseline=True)
        else:
            compile_ok = [t.compile_success for t in generated_tests]
            logger.warning(
                f"[Phase5] Skipped coverage: output_dir={ctx.output_dir}, "
                f"compile_success={compile_ok}"
            )

        # Phase 6: Coverage improvement loop
        coverage_iteration = 0
        coverage_stop_reason = "not_needed"
        coverage_content_modified = False  # Track if Phase 6 modifies any test content
        coverage_no_change_retries = 0
        max_cov_iterations = ctx.coverage_max_iterations
        if coverage_failed and not coverage_data.get("coverage_build_retryable", True):
            max_cov_iterations = 0
            coverage_stop_reason = "coverage_build_failed"
        coverage_plans_by_file: dict[str, list[dict[str, Any]]] = {}
        coverage_uncovered_before: dict[str, dict[str, Any]] = {}
        for baseline_test in generated_tests:
            baseline_gcov = baseline_test.gcov_data or {}
            baseline_source = source_contents.get(baseline_test.source_file, "")
            if not baseline_source:
                baseline_source = source_contents.get(os.path.basename(baseline_test.source_file), "")
            coverage_plans_by_file[baseline_test.source_file] = self._build_coverage_plan(
                baseline_source, baseline_gcov,
            )
            coverage_uncovered_before[baseline_test.source_file] = {
                "functions": list(baseline_gcov.get("uncovered_functions", [])),
                "lines": list(baseline_gcov.get("uncovered_lines", [])),
            }

        # Guard: if gcov returned 0 total lines AND all coverage is 0, measurement is broken.
        # Try to repair coverage build first so iteration can still run.
        total_coverage_valid = total_coverage > 0 or total_branch_coverage > 0 or total_function_coverage > 0
        if (coverage_data.get("lines_total", 0) == 0
                and not total_coverage_valid
                and any(t.compile_success for t in generated_tests)
                and coverage_data.get("coverage_build_retryable", True)):
            logger.warning(
                "[COV] gcov returned 0 total lines and no coverage data — coverage measurement broken, "
                "trying coverage build repair before iteration"
            )
            coverage_repaired = False
            for repair_attempt in range(1, ctx.max_iterations + 1):
                await self._report_progress(
                    task_id, 86, "autonomous_fix",
                    f"Repairing coverage measurement (attempt {repair_attempt}/{ctx.max_iterations})"
                )
                repaired_any = False
                for test in generated_tests:
                    if not test.test_content:
                        continue
                    real_src = (
                        ctx.source_path_map.get(test.source_file)
                        or ctx.source_path_map.get(os.path.basename(test.source_file))
                        or (test.source_file if os.path.isabs(test.source_file) else None)
                    )
                    file_paths = generate_file_paths(
                        source_filename=os.path.basename(test.source_file),
                        layer=ctx.layer,
                        project_root=_project_root,
                        platform=ctx.platform,
                        source_path=real_src,
                    )
                    repaired = await self._autonomous_fix_coverage_build(
                        test, ctx, file_paths, coverage_data, _project_root
                    )
                    repaired_any = repaired_any or repaired
                    if repaired:
                        break

                if not repaired_any:
                    continue

                coverage_data = await self._collect_real_coverage(
                    list(source_contents.keys()), ctx, project_root=_project_root
                )
                if not coverage_data.get("coverage_build_failed"):
                    _apply_coverage_data(coverage_data, baseline=False)
                    coverage_failed = False
                    coverage_repaired = True
                    break

            if not coverage_repaired:
                coverage_failed = True
                max_cov_iterations = 0

        # Detect if source files have branches using gcov data (authoritative source)
        # If gcov reports 0 total branches, exempt branch coverage check
        branches_total = coverage_data.get("branches_total", 0)
        source_has_branches = branches_total > 0
        functions_total = coverage_data.get("functions_total", 0)
        source_has_functions = functions_total > 0
        
        if not source_has_branches:
            logger.info(
                "[COV] No branches detected by gcov (branches_total=0) — exempting branch coverage check. "
                f"Branch coverage: {total_branch_coverage:.1f}% (will be ignored)"
            )
        else:
            logger.info(
                f"[COV] Source has {branches_total} branches detected by gcov — branch coverage will be checked"
            )

        if source_has_functions:
            logger.info(
                f"[COV] Source has {functions_total} functions detected by gcov; "
                "function coverage will be checked"
            )
        else:
            logger.info(
                "[COV] No function summaries detected by gcov; "
                "function coverage will be ignored"
            )

        # Build coverage check condition
        # Line coverage: always check
        needs_line_improvement = total_coverage < ctx.target_coverage
        # Branch coverage: only check if source has branches (per gcov)
        needs_branch_improvement = (
            source_has_branches
            and total_branch_coverage < ctx.target_branch_coverage
        )
        # Function coverage is enforceable only when gcov emits function summaries.
        needs_function_improvement = (
            source_has_functions
            and total_function_coverage < ctx.target_function_coverage
        )

        # The coverage run is the authoritative source for the test report
        # when the initial QBS/MCP invocation cannot expose JSON details.
        # Preserve its per-test failures so the final result never reports a
        # false all-green status for a non-zero GTest failure count.
        if coverage_data.get("total"):
            test_count = max(test_count, int(coverage_data.get("total") or 0))
            test_output = test_output or "Coverage test execution completed."
        if coverage_data.get("passed") is not None and coverage_data.get("total"):
            failed_cases = list(coverage_data.get("failed_cases") or failed_cases)

        while ((needs_line_improvement or needs_branch_improvement or needs_function_improvement)
               and coverage_iteration < max_cov_iterations
               and any(t.compile_success for t in generated_tests)
               and ctx.output_dir):

            coverage_iteration += 1
            
            # Build progress message based on what needs improvement
            progress_parts = []
            if needs_line_improvement:
                progress_parts.append(f"line={total_coverage:.1f}% → {ctx.target_coverage:.1f}%")
            if needs_branch_improvement:
                progress_parts.append(f"branch={total_branch_coverage:.1f}% → {ctx.target_branch_coverage:.1f}%")
            if needs_function_improvement:
                progress_parts.append(f"function={total_function_coverage:.1f}% → {ctx.target_function_coverage:.1f}%")
            
            # Keep stage progress within the API's documented 0-100 range even
            # when the final coverage iteration is number five or higher.
            stage_progress = min(99, 82 + coverage_iteration * 4)
            await self._report_progress(
                task_id, stage_progress, "coverage_improve",
                f"Improving coverage: {', '.join(progress_parts)} "
                f"(iteration {coverage_iteration}/{max_cov_iterations})"
            )
            logger.info(
                f"[COV] Coverage improvement iteration {coverage_iteration}: "
                f"{', '.join(progress_parts)}"
            )

            improved_any = False
            for test in generated_tests:
                if not test.compile_success:
                    continue
                
                # Check if this test needs improvement (respecting branch exemption)
                test_needs_line = test.coverage < ctx.target_coverage
                test_needs_branch = (
                    source_has_branches
                    and test.branch_coverage < ctx.target_branch_coverage
                )
                test_functions_total = (test.gcov_data or {}).get(
                    "functions_total",
                    functions_total if len(generated_tests) == 1 else 0,
                )
                test_needs_function = (
                    test_functions_total > 0
                    and test.function_coverage < ctx.target_function_coverage
                )
                
                if not (test_needs_line or test_needs_branch or test_needs_function):
                    continue

                # Get real source path for accurate platform detection
                _real_src = (
                    ctx.source_path_map.get(test.source_file)
                    or ctx.source_path_map.get(os.path.basename(test.source_file))
                    or (test.source_file if os.path.isabs(test.source_file) else None)
                )
                fp = generate_file_paths(
                    source_filename=test.source_file,
                    layer=ctx.layer,
                    project_root=_project_root,
                    platform=ctx.platform,
                    source_path=_real_src,
                )
                test_gcov = test.gcov_data or {}
                # Use the weakest enforced metric in the CLI prompt. Passing
                # line coverage alone (often already above target) makes the
                # model incorrectly conclude that branch/function gaps need
                # no work.
                prompt_coverage = min(
                    [test.coverage]
                    + ([test.branch_coverage] if source_has_branches else [])
                    + ([test.function_coverage] if test_gcov.get("functions_total", functions_total) > 0 else [])
                )
                source_for_plan = source_contents.get(test.source_file, "")
                if not source_for_plan:
                    source_for_plan = source_contents.get(os.path.basename(test.source_file), "")
                coverage_plans_by_file[test.source_file] = self._build_coverage_plan(
                    source_for_plan, test_gcov,
                )
                coverage_uncovered_before.setdefault(test.source_file, {
                    "functions": list(test_gcov.get("uncovered_functions", [])),
                    "lines": list(test_gcov.get("uncovered_lines", [])),
                })

                # Always use CLI for coverage improvement — LLM API fallback is unreliable
                # (no file-write capability, no compile verification loop)
                if ctx.generation_method == "cli":
                    result = await self._improve_coverage_via_cli(
                        test, ctx, fp, test_gcov
                    )
                    # === Solution 3 & H: Distinguish tool failures from real stagnation, support no_code_change retry ===
                    if result.get("success"):
                        improved_any = True
                        coverage_content_modified = True
                    else:
                        failure_reason = result.get("failure_reason", "unknown")
                        if failure_reason in ["tool_error", "tool_budget", "permission_error", "no_source_context", "auth", "quota", "budget_exceeded"]:
                            # Infrastructure/CLI failures cannot be fixed by
                            # another coverage prompt. Stop this iteration and
                            # preserve the last authoritative coverage result;
                            # a later resume can retry with fresh tooling.
                            coverage_stop_reason = f"coverage_{failure_reason}"
                            logger.warning(
                                f"[COV] Stopping coverage loop for {test.source_file}: "
                                f"{failure_reason}"
                            )
                            break
                        # Tool failures/permission errors/missing context don't count as improvement attempts
                        if failure_reason in ["tool_error", "tool_budget", "permission_error", "no_source_context"]:
                            logger.warning(
                                f"[COV] CLI coverage improvement failed for {test.source_file}: {failure_reason}, "
                                "not counting as improvement attempt"
                            )
                        elif failure_reason == "no_code_change":
                            # === Solution F & H: no_code_change triggers force retry ===
                            logger.warning(
                                f"[COV] CLI succeeded but no code changes for {test.source_file}, "
                                "retrying with force_modify=True"
                            )
                            # Second attempt: use more aggressive prompt to force modification
                            retry_result = await self._improve_coverage_via_cli(
                                test, ctx, fp, test_gcov, force_modify=True
                            )
                            coverage_no_change_retries += 1
                            if retry_result.get("success"):
                                improved_any = True
                                coverage_content_modified = True
                                logger.info(
                                    f"[COV] Force modify retry succeeded for {test.source_file}"
                                )
                            else:
                                logger.warning(
                                    f"[COV] Force modify retry also failed for {test.source_file}: "
                                    f"{retry_result.get('failure_reason', 'unknown')}"
                                )
                        else:
                            logger.warning(
                                f"[COV] CLI coverage improvement failed for {test.source_file}: {failure_reason}"
                            )
                else:
                    logger.warning(
                        f"[COV] Skipping coverage improvement for {test.source_file}: "
                        "generation_method is not 'cli' — LLM API fallback disabled"
                    )

            if not improved_any and coverage_stop_reason.startswith("coverage_"):
                logger.info("[COV] Infrastructure failure recorded; leaving coverage loop resumable")
                break
            if not improved_any:
                logger.info("[COV] No coverage improvement made, stopping loop")
                coverage_stop_reason = "no_change"
                break

            # Re-run tests and re-collect coverage
            test_output, test_count, failed_cases = await self._run_compiled_tests(
                ctx.output_dir, ctx, task_id
            )
            self._record_large_file_test_result(
                ctx, generated_tests, test_output, test_count, failed_cases
            )
            prev_coverage = total_coverage
            prev_branch_coverage = total_branch_coverage
            prev_function_coverage = total_function_coverage
            coverage_data = await self._collect_real_coverage(
                list(source_contents.keys()), ctx, project_root=_project_root
            )
            if coverage_data.get("coverage_build_failed"):
                error_msg = coverage_data.get("coverage_build_error", "Unknown error")
                if not coverage_data.get("coverage_build_retryable", True):
                    logger.error(
                        "[COV] Coverage build precondition failed after improvement; "
                        f"skipping repair: code={coverage_data.get('coverage_build_error_code')}, "
                        f"error={error_msg}"
                    )
                    coverage_failed = True
                    coverage_stop_reason = "coverage_build_failed"
                    break
                logger.warning(
                    f"[COV] Coverage QBS rebuild failed after improvement; attempting repair: {error_msg}"
                )
                repaired = False
                for repair_attempt in range(1, ctx.max_iterations + 1):
                    await self._report_progress(
                        task_id, 86, "autonomous_fix",
                        f"Repairing coverage build after improvement (attempt {repair_attempt}/{ctx.max_iterations})"
                    )
                    repair_any = False
                    for test in generated_tests:
                        if not test.test_content:
                            continue
                        real_src = (
                            ctx.source_path_map.get(test.source_file)
                            or ctx.source_path_map.get(os.path.basename(test.source_file))
                            or (test.source_file if os.path.isabs(test.source_file) else None)
                        )
                        file_paths = generate_file_paths(
                            source_filename=os.path.basename(test.source_file),
                            layer=ctx.layer,
                            project_root=_project_root,
                            platform=ctx.platform,
                            source_path=real_src,
                        )
                        fixed = await self._autonomous_fix_coverage_build(
                            test, ctx, file_paths, coverage_data, _project_root
                        )
                        repair_any = repair_any or fixed
                        if fixed:
                            break

                    if not repair_any:
                        continue

                    coverage_data = await self._collect_real_coverage(
                        list(source_contents.keys()), ctx, project_root=_project_root
                    )
                    if not coverage_data.get("coverage_build_failed"):
                        repaired = True
                        break

                if repaired:
                    _apply_coverage_data(coverage_data, baseline=False)
                    coverage_failed = False
                else:
                    coverage_failed = True
                    coverage_stop_reason = "coverage_build_failed"
                    break
            else:
                prev_coverage = total_coverage
                prev_branch_coverage = total_branch_coverage
                prev_function_coverage = total_function_coverage
                _apply_coverage_data(coverage_data, baseline=False)

            logger.info(
                f"[COV] After iteration {coverage_iteration}: "
                f"line={prev_coverage:.1f}% → {total_coverage:.1f}%, "
                f"branch={prev_branch_coverage:.1f}% → {total_branch_coverage:.1f}%, "
                f"function={prev_function_coverage:.1f}% → {total_function_coverage:.1f}%"
            )

            # Re-evaluate coverage needs after this iteration
            needs_line_improvement = total_coverage < ctx.target_coverage
            needs_branch_improvement = (
                source_has_branches
                and total_branch_coverage < ctx.target_branch_coverage
            )
            needs_function_improvement = (
                source_has_functions
                and total_function_coverage < ctx.target_function_coverage
            )

            # Stagnation detection: if no relevant coverage metric improved, stop
            line_stagnant = total_coverage <= prev_coverage
            branch_stagnant = total_branch_coverage <= prev_branch_coverage
            function_stagnant = total_function_coverage <= prev_function_coverage
            
            # Only consider metrics that are being checked
            relevant_stagnant = True
            if needs_line_improvement:
                relevant_stagnant = relevant_stagnant and line_stagnant
            if needs_branch_improvement:
                relevant_stagnant = relevant_stagnant and branch_stagnant
            if needs_function_improvement:
                relevant_stagnant = relevant_stagnant and function_stagnant
            
            if relevant_stagnant and coverage_iteration > 1:
                logger.info(
                    f"[COV] Coverage stagnant (line={total_coverage:.1f}%, "
                    f"branch={total_branch_coverage:.1f}%{' (exempted)' if not source_has_branches else ''}, "
                    f"function={total_function_coverage:.1f}%) "
                    f"for 2 iterations, stopping loop"
                )
                break

            # Guard: if re-collected coverage has 0 total lines, keep iterating until max attempts.
            if coverage_data.get("lines_total", 0) == 0 and total_coverage == 0.0:
                logger.warning(
                    "[COV] gcov returned 0 total lines after improvement — "
                    "continuing until coverage iteration budget is exhausted"
                )

        iterations_used += coverage_iteration
        if not (needs_line_improvement or needs_branch_improvement or needs_function_improvement):
            coverage_stop_reason = "target_met"
        elif not coverage_stop_reason or coverage_stop_reason == "not_needed":
            coverage_stop_reason = (
                "iteration_limit" if coverage_iteration >= max_cov_iterations else "no_change"
            )

        # Phase 7: Save generated test files to project directory.
        # When CLI succeeded and Phase 6 did not modify content, skip —
        # CLI already wrote all files to disk.
        for generated_test in generated_tests:
            self._clear_disabled_mock_content(generated_test, ctx)
        saved_files: list[str] = []
        if ctx.output_dir and generated_tests:
            if cli_all_compiled and not coverage_content_modified:
                logger.info(
                    "[Phase7] Skipping save — CLI already wrote files "
                    "and no coverage improvement modified content"
                )
                for test in generated_tests:
                    _real_src = (
                        ctx.source_path_map.get(test.source_file)
                        or ctx.source_path_map.get(os.path.basename(test.source_file))
                        or (test.source_file if os.path.isabs(test.source_file) else None)
                    )
                    file_paths = generate_file_paths(
                        source_filename=test.source_file,
                        layer=ctx.layer,
                        project_root=_project_root,
                        platform=ctx.platform,
                        source_path=_real_src,
                    )
                    for path_key in (
                        "test_impl_path",
                        "test_header_path",
                        "mock_impl_path",
                        "mock_header_path",
                        "test_access_impl_path",
                        "stub_impl_path",
                        "stub_header_path",
                    ):
                        generated_path = file_paths.get(path_key)
                        if (
                            (ctx.enable_mock or not path_key.startswith("mock_"))
                            and
                            generated_path
                            and os.path.isfile(generated_path)
                            and generated_path not in saved_files
                        ):
                            saved_files.append(generated_path)
                            logger.info(f"Recorded CLI-written file: {generated_path}")
                await self._report_progress(task_id, 98, "save", "Files already saved by CLI")
            else:
                await self._report_progress(task_id, 98, "save", "Saving test files to project")
                for test in generated_tests:
                    if not test.test_content:
                        continue
                    # Get real source path for accurate platform detection
                    _real_src = (
                        ctx.source_path_map.get(test.source_file)
                        or ctx.source_path_map.get(os.path.basename(test.source_file))
                        or (test.source_file if os.path.isabs(test.source_file) else None)
                    )
                    file_paths = generate_file_paths(
                        source_filename=test.source_file,
                        layer=ctx.layer,
                        project_root=_project_root,
                        platform=ctx.platform,
                        source_path=_real_src,
                        source_content=self._source_content_for_test(test, ctx),
                    )
                    if ctx.generation_method == "cli":
                        reloaded_paths = self._reload_cli_outputs_from_disk(
                            test, file_paths
                        )
                        if reloaded_paths:
                            logger.info(
                                "[Phase7] Reloaded %d CLI-written artifact(s) from disk",
                                len(reloaded_paths),
                            )
                        self._clear_disabled_mock_content(test, ctx)
                    # Auto-generate header templates if missing
                    file_paths = filter_mock_paths(file_paths, ctx.enable_mock)
                    headers = generate_header_templates(file_paths, enable_mock=ctx.enable_mock)
                    test.test_header_content = test.test_header_content or headers["test_header"]
                    test.mock_header_content = test.mock_header_content or headers["mock_header"]

                    self._clear_disabled_mock_content(test, ctx)
                    test_content_map = {
                        "test_impl": test.test_content,
                        "test_header": test.test_header_content or "",
                        "mock_impl": test.mock_content or "",
                        "mock_header": test.mock_header_content or "",
                        "stub_impl": test.stub_content or "",
                        "stub_header": test.stub_header_content or "",
                    }
                    save_result = save_test_files_to_project(test_content_map, file_paths)
                    for item in save_result.get("success", []):
                        saved_files.append(item["path"])
                        logger.info(f"Saved: {item['path']}")
                    for item in save_result.get("failed", []):
                        logger.warning(f"Failed to save: {item}")
                        save_failures.append(item)

        await self._report_progress(task_id, 99, "report", "Generating report")

        # Merge the final coverage test report into the workflow summary.
        # This is necessary because QBS' text runner may omit failed case
        # details while the JSON report contains them.
        if coverage_data.get("total"):
            test_count = max(test_count, int(coverage_data.get("total") or 0))
            test_output = test_output or "Coverage test execution completed."
            failed_cases = list(coverage_data.get("failed_cases") or failed_cases)

        coverage_failed = coverage_failed or coverage_data.get("coverage_build_failed", False)
        coverage_uncovered_after = {
            test.source_file: {
                "functions": list((test.gcov_data or {}).get("uncovered_functions", [])),
                "lines": list((test.gcov_data or {}).get("uncovered_lines", [])),
            }
            for test in generated_tests
        }
        for test in generated_tests:
            source_for_plan = source_contents.get(test.source_file, "")
            if not source_for_plan:
                source_for_plan = source_contents.get(os.path.basename(test.source_file), "")
            coverage_plans_by_file[test.source_file] = self._build_coverage_plan(
                source_for_plan, test.gcov_data or {},
            )
        all_compiled = (
            all(test.compile_success for test in generated_tests)
            if generated_tests and ctx.compile_verify
            else None
        )
        compilation_failed = all_compiled is False
        first_compile_failure = next(
            (test for test in generated_tests if not test.compile_success),
            None,
        )
        static_quality = summarize_generated_test_quality(generated_tests)
        # A verified CLI run is authoritative for the generated artifact.  The
        # backend may only have a lightweight placeholder representation (for
        # example when the CLI wrote the real files directly), so do not turn
        # that representation into a second failure gate.
        static_quality_failed = (
            not static_quality["passed"]
            and not cli_all_compiled
        )
        # A successful compiler invocation is not a successful unit-test run.
        # The task must remain failed whenever any executed case failed, even
        # if the CLI exited with code 0 and produced a positive prose summary.
        tests_executed = bool(test_output or test_count or failed_cases)
        # ``failed_cases`` is the canonical execution signal here.  A runner
        # may report only a total count (without a passed count), so deriving
        # failures as ``total - passed`` would turn an otherwise valid run
        # into a false failure when the coverage pass did not emit aggregates.
        test_failures = len(failed_cases)
        # CLI verification includes the CLI-owned test execution.  A backend
        # rerun is used to enrich the response with counts and failed case
        # names, but its result must not overwrite the already verified CLI
        # status (especially when the rerun cannot reproduce the CLI context).
        tests_failed = (
            tests_executed
            and test_failures > 0
            and not cli_all_compiled
        )
        # Unit-test execution and coverage optimization are separate gates.
        # A coverage/tooling failure must not turn an otherwise passing GTest
        # run into a failed unit-test task; expose it as a resumable status in
        # the result data instead.
        result_failed = compilation_failed or tests_failed or static_quality_failed
        incomplete_large_chunks = [
            item for item in ctx.large_file_checkpoints
            if item.get("generation_status") != "passed"
            or item.get("build_status") != "passed"
            or item.get("test_status") != "passed"
            or item.get("coverage_after") is None
        ]
        result_failed = result_failed or (
            bool(incomplete_large_chunks) and not (tests_executed and not tests_failed)
        )
        result_status = AgentStatus.FAILED if result_failed else AgentStatus.COMPLETED
        if compilation_failed:
            compile_error = first_compile_failure.compile_error if first_compile_failure else ""
            result_message = compile_error or "QBS compilation failed"
        elif tests_failed:
            result_message = f"{test_failures} unit test(s) failed"
        elif coverage_failed:
            result_message = "Unit tests passed; coverage optimization is pending and can be resumed"
        elif static_quality_failed:
            result_message = "Generated tests failed static quality validation"
        elif incomplete_large_chunks:
            result_message = (
                "Unit tests passed; large-file coverage workflow is pending; "
                f"resume from {incomplete_large_chunks[0].get('chunk_id')}"
            )
        elif not ctx.compile_verify:
            result_message = (
                f"Generated {len(generated_tests)} test files; compilation, tests, "
                "and coverage were not requested"
            )
        else:
            result_message = f"Generated {len(generated_tests)} test files, coverage: {total_coverage:.1f}%"

        if coverage_failed:
            total_coverage = 0.0
            total_branch_coverage = 0.0
            total_function_coverage = 0.0
            for test in generated_tests:
                test.coverage = 0.0
                test.branch_coverage = 0.0
                test.function_coverage = 0.0
                test.gcov_data = {"coverage_unavailable": True}

        coverage_available = bool(
            not coverage_failed and coverage_data.get("lines_total", 0) > 0
        )
        coverage_targets_met = None
        if coverage_available:
            coverage_targets_met = (
                total_coverage >= ctx.target_coverage
                and (
                    not source_has_branches
                    or total_branch_coverage >= ctx.target_branch_coverage
                )
                and (
                    not source_has_functions
                    or total_function_coverage >= ctx.target_function_coverage
                )
            )

        return UnitTestResult(
            task_id=task_id, status=result_status,
            message=result_message,
            data={
                "files_processed": total_files,
                "tests_generated": len(generated_tests),
                "coverage": total_coverage,
                "branch_coverage": total_branch_coverage,
                "function_coverage": total_function_coverage,
                "lines_executed": coverage_data.get("lines_executed", 0),
                "lines_total": coverage_data.get("lines_total", 0),
                "branches_executed": coverage_data.get("branches_executed", 0),
                "branches_total": coverage_data.get("branches_total", 0),
                "functions_executed": coverage_data.get("functions_executed", 0),
                "functions_total": coverage_data.get("functions_total", 0),
                "test_count": test_count,
                "test_output": test_output,
                "failed_cases": failed_cases,
                "test_cases": coverage_data.get("test_cases", []),
                "total": coverage_data.get("total", 0),
                "passed": coverage_data.get("passed", 0),
                "large_file_diagnostics": list(ctx.large_file_diagnostics),
                "large_file_checkpoints": list(ctx.large_file_checkpoints),
                "large_file_active_chunk_id": ctx.large_file_active_chunk_id,
                "large_file_incomplete_chunks": [
                    item.get("chunk_id") for item in incomplete_large_chunks
                ],
                "coverage_iteration": coverage_iteration,
                "coverage_improvement_attempts": coverage_iteration,
                "coverage_improvement_max": max_cov_iterations,
                "coverage_target_met": (
                    bool(coverage_targets_met) if ctx.compile_verify else None
                ),
                "coverage_stop_reason": coverage_stop_reason,
                "coverage_skill_applied": bool(applied_skill_names(ctx, "coverage_improve")),
                "coverage_skill_names": applied_skill_names(ctx, "coverage_improve"),
                "coverage_plan": coverage_plans_by_file,
                "uncovered_functions_before": {
                    path: value.get("functions", [])
                    for path, value in coverage_uncovered_before.items()
                },
                "uncovered_lines_before": {
                    path: value.get("lines", [])
                    for path, value in coverage_uncovered_before.items()
                },
                "coverage_content_modified": coverage_content_modified,
                "coverage_no_change_retries": coverage_no_change_retries,
                "uncovered_functions_after": {
                    path: value.get("functions", [])
                    for path, value in coverage_uncovered_after.items()
                },
                "uncovered_lines_after": {
                    path: value.get("lines", [])
                    for path, value in coverage_uncovered_after.items()
                },
                "generated_tests": [
                    {"source_file": t.source_file, "test_file": t.test_file,
                     "test_content": t.test_content, "mock_content": t.mock_content,
                     "coverage": t.coverage, "compile_success": t.compile_success,
                     "compile_error": t.compile_error,
                     "compile_error_code": t.compile_error_code,
                     "compile_retryable": t.compile_retryable}
                    for t in generated_tests
                ],
                # Add explicit compilation summary
                "compilation_summary": {
                    "total_tests": len(generated_tests),
                    "compiled_successfully": (
                        sum(1 for t in generated_tests if t.compile_success)
                        if ctx.compile_verify else None
                    ),
                    "compilation_failed": (
                        sum(1 for t in generated_tests if not t.compile_success)
                        if ctx.compile_verify else None
                    ),
                    "all_compiled": (
                        all(t.compile_success for t in generated_tests)
                        if generated_tests and ctx.compile_verify else None
                    ),
                },
                "quality_gate": {
                    "compilation_requested": ctx.compile_verify,
                    "compilation_passed": all_compiled,
                    "tests_executed": tests_executed,
                    "tests_passed": not failed_cases if tests_executed else None,
                    "coverage_available": coverage_available,
                    "coverage_targets_met": coverage_targets_met,
                    "static_quality_passed": static_quality["passed"],
                    "static_quality_score": static_quality["score"],
                    "quality_reports": static_quality["reports"],
                    "quality_blockers": static_quality["blockers"],
                    "quality_warnings": static_quality["warnings"],
                },
                "saved_files": saved_files,
                "save_failures": save_failures,
                "output_dir": _project_root,
                "build_failed": compilation_failed,
                "build_error": first_compile_failure.compile_error if first_compile_failure else "",
                "build_error_code": first_compile_failure.compile_error_code if first_compile_failure else None,
                "build_retryable": first_compile_failure.compile_retryable if first_compile_failure else None,
                "coverage_build_failed": coverage_failed,
                "coverage_build_error": coverage_data.get("coverage_build_error", ""),
                "coverage_build_error_code": coverage_data.get("coverage_build_error_code"),
                "coverage_build_retryable": coverage_data.get("coverage_build_retryable"),
                "coverage_build_output": coverage_data.get("coverage_build_output", ""),
                "token_usage": {
                    "input_tokens": self._total_input_tokens,
                    "output_tokens": self._total_output_tokens,
                    "total_tokens": self._total_tokens,
                    "cache_creation_input_tokens": self._total_cache_creation_tokens,
                    "cache_read_input_tokens": self._total_cache_read_tokens,
                },
            },
            generated_tests=generated_tests,
            total_coverage=total_coverage,
            iterations_used=iterations_used,
        )

    async def _compile_and_fix_tests(
        self, generated_tests: list[GeneratedTest], ctx: "UnitTestContext", task_id: str,
        project_root: str | None = None,
    ) -> tuple[list[GeneratedTest], int]:
        """Compile generated test files, fix with LLM on failure (multi-file), supports 3-level escalation."""
        iterations = 1
        project_root = project_root or ctx.output_dir or "."

        # The QBS product builds every module's registered files at once, and
        # update_qbs_config registers ALL modules before this loop starts.
        # Materializing per test would make the first module's build fail with
        # phantom "File ... does not exist" resolve errors for the not-yet-
        # written modules, burning repair budget on a nonexistent problem.
        # Write every generated test's files up front so the first compile of
        # any module sees a complete project.
        for test in generated_tests:
            if not test.test_content:
                continue
            _pre_real_source = (
                ctx.source_path_map.get(test.source_file)
                or ctx.source_path_map.get(os.path.basename(test.source_file))
                or (test.source_file if os.path.isabs(test.source_file) else None)
            )
            _pre_fp = generate_file_paths(
                source_filename=os.path.basename(test.source_file),
                layer=ctx.layer,
                project_root=project_root,
                platform=ctx.platform,
                source_path=_pre_real_source,
            )
            _pre_content = {
                "test_impl": test.test_content,
                "test_header": getattr(test, "test_header_content", "") or "",
                "mock_impl": getattr(test, "mock_content", "") or "",
                "mock_header": getattr(test, "mock_header_content", "") or "",
            }
            _pre_missing = [
                _pre_fp[path_key]
                for path_key, content_key in (
                    ("test_impl_path", "test_impl"),
                    ("test_header_path", "test_header"),
                    ("mock_impl_path", "mock_impl"),
                    ("mock_header_path", "mock_header"),
                )
                if _pre_fp.get(path_key) and _pre_content.get(content_key)
                and not os.path.isfile(_pre_fp[path_key])
            ]
            if _pre_missing:
                logger.info(
                    f"[QBS] Pre-materializing {len(_pre_missing)} generated file(s) "
                    f"for the whole product before per-module compile: {_pre_missing}"
                )
                save_test_files_to_project(_pre_content, _pre_fp)

        for test in generated_tests:
            if not test.test_content:
                continue

            # Get real source path for accurate platform detection
            _real_source_path = (
                ctx.source_path_map.get(test.source_file)
                or ctx.source_path_map.get(os.path.basename(test.source_file))
                or (test.source_file if os.path.isabs(test.source_file) else None)
            )

            # Build file_paths for save-before-verify
            fp = generate_file_paths(
                source_filename=os.path.basename(test.source_file),
                layer=ctx.layer,
                project_root=project_root,
                platform=ctx.platform,
                source_path=_real_source_path,
            )

            prev_error_count = 0
            autonomous_attempts = 0
            seen_compile_states: set[tuple[str, str]] = set()

            # Compile failures such as missing embedded ABI types often need
            # several edit/build cycles. Give CLI repair a larger action
            # budget while retaining deterministic repeated-state detection.
            max_compile_attempts = max(ctx.max_iterations, 20) if ctx.generation_method == "cli" else ctx.max_iterations
            for attempt in range(1, max_compile_attempts + 1):
                # Save current content to disk before compile. Generation can
                # return content in memory without writing the project tree,
                # while update_qbs_config already registered the files in the
                # QBS project — compiling then fails with "File ... does not
                # exist". Materialize any missing file up front; on later
                # attempts always re-save so CLI/LLM edits take effect.
                content_map = {
                    "test_impl": test.test_content,
                    "test_header": getattr(test, "test_header_content", "") or "",
                    "mock_impl": getattr(test, "mock_content", "") or "",
                    "mock_header": getattr(test, "mock_header_content", "") or "",
                }
                missing_files = [
                    fp[path_key]
                    for path_key, content_key in (
                        ("test_impl_path", "test_impl"),
                        ("test_header_path", "test_header"),
                        ("mock_impl_path", "mock_impl"),
                        ("mock_header_path", "mock_header"),
                    )
                    if fp.get(path_key) and content_map.get(content_key)
                    and not os.path.isfile(fp[path_key])
                ]
                if attempt > 1 or missing_files:
                    if missing_files:
                        logger.info(
                            f"[QBS] Materializing {len(missing_files)} generated file(s) "
                            f"missing before compile: {missing_files}"
                        )
                    save_test_files_to_project(content_map, fp)

                compile_result = await self._do_compile(
                    test.test_content, project_root,
                    layer=ctx.layer, platform=ctx.platform, profile=ctx.build_profile,
                    qbs_project_path=ctx.qbs_project_path,
                    qbs_file=ctx.qbs_file,
                    qbs_products=ctx.qbs_products,
                )
                test.compile_success = compile_result.success
                test.compile_error = compile_result.output
                test.compile_error_code = compile_result.error_code
                test.compile_retryable = compile_result.retryable
                if compile_result.success:
                    source_hash = self._source_hash_for_context(ctx, test.source_file)
                    self._update_large_file_checkpoints(
                        ctx,
                        test.source_file,
                        source_sha256=source_hash,
                        build_status="passed",
                        output_sha256=self._generated_output_sha256(test),
                        last_gate="build",
                    )
                    break
                failure_signature = self._normalize_failure_signature(
                    self._compile_error_signature(compile_result.errors)
                    or compile_result.output
                )
                self._update_large_file_checkpoints(
                    ctx,
                    test.source_file,
                    source_sha256=self._source_hash_for_context(ctx, test.source_file),
                    build_status="failed",
                    failure_signature=failure_signature or None,
                    last_gate="build",
                )
                if not compile_result.retryable:
                    logger.error(
                        f"[QBS] Non-retryable compilation precondition failure for "
                        f"{test.source_file}: code={compile_result.error_code}, "
                        f"error={compile_result.output}"
                    )
                    break
                if not compile_result.errors:
                    continue

                curr_error_count = len(compile_result.errors)
                error_regressed = (prev_error_count > 0 and curr_error_count > prev_error_count)
                prev_error_count = curr_error_count

                # Keep retrying only while either the diagnostic or generated
                # files change. This prevents a failed CLI repair (for example,
                # an unavailable Claude executable) from being invoked forever
                # against the same compiler output.
                compile_signature = self._compile_error_signature(compile_result.errors)
                content_signature = self._generated_test_signature(test)
                compile_state = (compile_signature, content_signature)
                if compile_state in seen_compile_states:
                    logger.error(
                        "[QBS] Repeated compile failure with unchanged generated files; "
                        f"stopping repair for {test.source_file}"
                    )
                    test.compile_retryable = False
                    test.compile_error_code = "repeated_compile_failure"
                    break
                seen_compile_states.add(compile_state)

                # Phase 3 on CLI-recovered path: use autonomous CLI fix directly
                max_autonomous_attempts = max(1, max_compile_attempts)
                if autonomous_attempts < max_autonomous_attempts:
                    await self._report_progress(
                        task_id, 70, "autonomous_fix",
                        f"Escalating to autonomous fix (attempt {autonomous_attempts + 1}/{max_autonomous_attempts})"
                    )
                    content_before_fix = self._generated_test_signature(test)
                    success = await self._autonomous_fix(test, ctx, fp, compile_result.errors)
                    autonomous_attempts += 1
                    if success:
                        verification = await self._do_compile(
                            test.test_content, project_root,
                            layer=ctx.layer, platform=ctx.platform, profile=ctx.build_profile,
                            qbs_project_path=ctx.qbs_project_path,
                            qbs_file=ctx.qbs_file,
                            qbs_products=ctx.qbs_products,
                        )
                        test.compile_success = verification.success
                        test.compile_error = verification.output
                        test.compile_error_code = verification.error_code
                        test.compile_retryable = verification.retryable
                        if verification.success:
                            break
                        if not verification.retryable:
                            logger.error(
                                f"[QBS] Autonomous fix could not satisfy build preconditions for "
                                f"{test.source_file}: code={verification.error_code}, "
                                f"error={verification.output}"
                            )
                            break
                        if (
                            self._generated_test_signature(test) == content_before_fix
                            and self._compile_error_signature(verification.errors)
                            == compile_signature
                        ):
                            logger.error(
                                "[QBS] Autonomous repair produced no change and the "
                                "same compiler diagnostic remains; stopping"
                            )
                            test.compile_retryable = False
                            test.compile_error_code = "repeated_compile_failure"
                            break
                    elif self._generated_test_signature(test) == content_before_fix:
                        logger.error(
                            "[QBS] Autonomous repair failed without changing generated "
                            "files; stopping duplicate CLI attempts"
                        )
                        test.compile_retryable = False
                        test.compile_error_code = "repeated_compile_failure"
                        break
                    continue
                else:
                    # Autonomous repair exhausted after meaningful attempts.
                    break
        return generated_tests, iterations

    @staticmethod
    def _compile_error_signature(errors: list[CompileError]) -> str:
        """Return a stable signature for compiler diagnostics."""
        entries = [
            f"{e.file}:{e.line}:{e.column}:{e.severity}:{e.message.strip()}"
            for e in errors
        ]
        return "\n".join(sorted(entries))

    @staticmethod
    def _generated_test_signature(test: GeneratedTest) -> str:
        """Hash all generated artifacts so no-op repairs are detected."""
        parts = (
            test.test_content or "",
            getattr(test, "test_header_content", "") or "",
            getattr(test, "mock_content", "") or "",
            getattr(test, "mock_header_content", "") or "",
            getattr(test, "stub_content", "") or "",
            getattr(test, "stub_header_content", "") or "",
        )
        digest = hashlib.sha256()
        for part in parts:
            digest.update(part.encode("utf-8", errors="replace"))
            digest.update(b"\0")
        return digest.hexdigest()

    async def _autonomous_fix(
        self, test: GeneratedTest, ctx: "UnitTestContext",
        file_paths: dict[str, str], errors: list[CompileError],
    ) -> bool:
        """Level 2: Claude CLI autonomous fix for compile errors."""
        try:
            import asyncio
            artifact_snapshot = await asyncio.to_thread(snapshot_cli_artifacts, file_paths)
            from pathlib import Path
            from app.utils.claude_cli_monitor import ClaudeCliMonitor
            from .prompts import build_autonomous_fix_prompt, build_autonomous_fix_system_prompt
            from .paths import find_project_root_for_source as _find_root_fix

            # Infer project root from the real absolute source path
            _inferred_root = None
            _real_src = None
            _src_file = test.source_file if hasattr(test, 'source_file') else None
            if _src_file:
                _real_src = (
                    ctx.source_path_map.get(_src_file)
                    or ctx.source_path_map.get(os.path.basename(_src_file))
                    or (_src_file if os.path.isabs(_src_file) else None)
                )
                if _real_src:
                    _inferred_root = _find_root_fix(_real_src)
            project_root = _inferred_root or ctx.output_dir or "."

            # Resolve coverage context for the prompt
            coverage_target_pct = ctx.target_coverage  # 0-100
            current_coverage = test.coverage  # 0-100
            source_code = ""
            if coverage_target_pct > 0 and current_coverage < coverage_target_pct:
                src_path = file_paths.get("source_path", "")
                if src_path and os.path.isfile(src_path):
                    with open(src_path, "r", encoding="utf-8") as f:
                        source_code = f.read()

            monitor = self._monitor
            # Verified SUT reference files (real paths + inline contents) so the
            # repair CLI reads ground truth instead of guessing header paths
            # and inventing identifiers the real headers never declared.
            reference_files: dict[str, str] = {}
            _contents = getattr(ctx, "source_contents", None) or {}
            for _name, _real_path in (ctx.source_path_map or {}).items():
                if not _real_path:
                    continue
                _content = _contents.get(_name) or _contents.get(
                    os.path.basename(_real_path), ""
                )
                reference_files[_real_path] = _content or ""
            _src_for_ref = file_paths.get("source_path") or _real_src or ""
            if _src_for_ref and _src_for_ref not in reference_files:
                reference_files[_src_for_ref] = ""
            task_prompt = build_autonomous_fix_prompt(
                errors=errors, file_paths=file_paths, project_root=project_root,
                layer=ctx.layer, platform=ctx.platform, build_profile=ctx.build_profile,
                coverage_target=coverage_target_pct,
                current_coverage=current_coverage,
                source_code=source_code,
                qbs_project_path=ctx.qbs_project_path or "",
                qbs_file=ctx.qbs_file or "",
                qbs_product=(ctx.qbs_products or [""])[0],
                reference_files=reference_files,
            )
            system_prompt = build_autonomous_fix_system_prompt(
                file_paths, project_root,
                coverage_target=coverage_target_pct,
                current_coverage=current_coverage,
                source_code=source_code,
                qbs_project_path=ctx.qbs_project_path or "",
                qbs_file=ctx.qbs_file or "",
                qbs_product=(ctx.qbs_products or [""])[0],
                reference_files=reference_files,
            )
            task_prompt += "\n\n" + await prepare_unittest_skills(
                self, ctx, "compile_repair", file_paths=file_paths,
                source_path=file_paths.get("source_path") or _real_src or "",
                large_file_mode=bool(ctx.large_file_active_chunk_id)
                or len(source_code) >= self._LARGE_SOURCE_CONTEXT_THRESHOLD,
                compile_errors=errors,
            )

            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))

            allowed_dirs = self._build_cli_allowed_dirs(project_root, file_paths, ctx.platform)

            # Resolve the CLI model from current settings
            _cli_model = self._llm_selection.model

            _task_id = ctx.task_id if hasattr(ctx, 'task_id') else None
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=_cli_model,
                    working_dir=Path(project_root),
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=_task_id,
                    upstream_provider=self._llm_selection.provider,
                    unbounded_runtime=True,
                    max_tool_calls=self._CLI_REPAIR_TOOL_LIMIT,
                ),
            )

            self._accumulate_cli_token_usage(result.get("token_usage"))
            await self._log_cli_usage(result, _cli_model, "compile_fix")

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0
            raise_if_cli_cancelled(result, _task_id)
            changed = await asyncio.to_thread(reload_cli_artifacts, test, file_paths, artifact_snapshot)
            return succeeded or changed  # The caller always verifies with QBS.
        except SkillPreparationError:
            raise
        except Exception as e:
            logger.warning(f"_autonomous_fix failed: {e}")
            return False

    async def _autonomous_fix_coverage_build(
        self,
        test: GeneratedTest,
        ctx: "UnitTestContext",
        file_paths: dict[str, str],
        coverage_data: dict,
        project_root: str,
    ) -> bool:
        """Use Claude CLI to repair QBS coverage rebuild failures."""
        try:
            import asyncio
            artifact_snapshot = await asyncio.to_thread(snapshot_cli_artifacts, file_paths)
            from pathlib import Path
            from app.utils.claude_cli_monitor import ClaudeCliMonitor

            monitor = self._monitor
            task_prompt = build_autonomous_coverage_fix_prompt(
                error_message=coverage_data.get("coverage_build_error", "Unknown error"),
                build_output=coverage_data.get("coverage_build_output", ""),
                file_paths=file_paths,
                project_root=project_root,
                layer=ctx.layer,
                platform=ctx.platform,
                build_profile=ctx.build_profile,
                qbs_project_path=ctx.qbs_project_path or "",
                qbs_file=ctx.qbs_file or "",
                qbs_product=(ctx.qbs_products or [""])[0],
            )
            system_prompt = (
                "You are an expert C/C++ embedded firmware developer. "
                "Fix only the QBS coverage build blocker. Keep changes minimal and verify with QBS."
            )
            task_prompt += "\n\n" + await prepare_unittest_skills(
                self, ctx, "coverage_repair", file_paths=file_paths,
                build_output=coverage_data.get("coverage_build_output") or coverage_data.get("coverage_build_error", ""),
                large_file_mode=bool(ctx.large_file_active_chunk_id),
            )

            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))
            allowed_dirs = self._build_cli_allowed_dirs(project_root, file_paths, ctx.platform)
            _cli_model = self._llm_selection.model
            _task_id = ctx.task_id if hasattr(ctx, 'task_id') else None
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=_cli_model,
                    working_dir=Path(project_root),
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=_task_id,
                    upstream_provider=self._llm_selection.provider,
                    unbounded_runtime=True,
                    max_tool_calls=self._CLI_REPAIR_TOOL_LIMIT,
                ),
            )

            self._accumulate_cli_token_usage(result.get("token_usage"))
            await self._log_cli_usage(result, _cli_model, "coverage_build_fix")

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0
            raise_if_cli_cancelled(result, _task_id)
            changed = await asyncio.to_thread(reload_cli_artifacts, test, file_paths, artifact_snapshot)
            return succeeded or changed  # The caller rebuilds and measures coverage.
        except SkillPreparationError:
            raise
        except Exception as e:
            logger.warning(f"_autonomous_fix_coverage_build failed: {e}")
            return False

    async def _autonomous_fix_failed_tests(
        self,
        test: GeneratedTest,
        ctx: "UnitTestContext",
        file_paths: dict[str, str],
        failed_cases: list[str],
        test_output: str,
        project_root: str,
    ) -> bool:
        """Use the project CLI to repair generated tests that fail at runtime."""
        try:
            import asyncio
            from pathlib import Path
            from app.utils.claude_cli_monitor import ClaudeCliMonitor

            include_optional_artifacts = ctx.layer != "hal"
            paths_info = "\n".join(
                f"- {key}: {value}"
                for key, value in file_paths.items()
                if value and (include_optional_artifacts or not key.startswith("stub_"))
            )
            task_prompt = build_test_failure_fix_prompt(
                failed_tests=failed_cases,
                test_output=test_output,
                previous_test_content=test.test_content or "",
            )
            task_prompt += (
                "\n\nFiles that may need coordinated edits:\n"
                f"{paths_info}\n\n"
                f"Project root: {project_root}\n"
                f"Layer: {ctx.layer}\n"
                f"Platform: {ctx.platform}\n"
                f"Build profile: {ctx.build_profile}\n\n"
                "Rules:\n"
                "- Edit only generated test, mock, or stub files, not production source.\n"
                "- Fix incorrect expectations, enum values, missing ON_CALL defaults, and test state setup.\n"
                "- Do not delete passing tests to make the executable pass.\n"
                "- Rebuild with QBS and run the unit executable before returning.\n"
            )
            system_prompt = (
                "You are an expert embedded C/C++ GoogleTest developer. "
                "Repair generated unit tests so they pass without weakening production behavior."
            )

            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))
            allowed_dirs = self._build_cli_allowed_dirs(
                project_root,
                file_paths,
                ctx.platform,
            )
            cli_model = self._llm_selection.model
            artifact_snapshot = await asyncio.to_thread(snapshot_cli_artifacts, file_paths)
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=cli_model,
                    working_dir=Path(project_root),
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=ctx.task_id or None,
                    upstream_provider=self._llm_selection.provider,
                    unbounded_runtime=True,
                    max_tool_calls=self._CLI_REPAIR_TOOL_LIMIT,
                ),
            )

            self._accumulate_cli_token_usage(result.get("token_usage"))
            await self._log_cli_usage(result, cli_model, "failed_test_fix")

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0
            raise_if_cli_cancelled(result, ctx.task_id)
            modified_artifact = await asyncio.to_thread(
                reload_cli_artifacts, test, file_paths, artifact_snapshot,
            )
            if modified_artifact and not succeeded:
                logger.warning(
                    f"[Phase4][{ctx.layer}] CLI ended after changing generated artifacts; "
                    "rebuilding and running the tests to verify those edits"
                )

            return succeeded or modified_artifact
        except Exception as exc:
            logger.warning(f"_autonomous_fix_failed_tests failed: {exc}")
            return False

    async def _log_cli_usage(self, result: dict, model: str, phase: str) -> None:
        """Log phase diagnostics; the shared monitor records usage exactly once."""
        logger.debug(
            "CLI phase completed: phase={}, model={}, exit_code={}",
            phase, model, result.get("exit_code"),
        )

    def _build_cli_allowed_dirs(
        self,
        project_root: str,
        file_paths: dict[str, str] | None = None,
        platform: str | None = None,
    ) -> list[str]:
        """Build allowed directories for Claude CLI project and platform files."""
        allowed_dirs: list[str] = [project_root]
        for v in (file_paths or {}).values():
            if v and os.path.dirname(v):
                d = os.path.dirname(v)
                if d not in allowed_dirs:
                    allowed_dirs.append(d)

        platform_lower = (platform or "").lower()
        if platform_lower == "stm32u5":
            reference_dirs = [
                os.path.join(project_root, "tests", "mocks", "stm32u3", "platform-mocks", "inc"),
                os.path.join(project_root, "tests", "mocks", "stm32u3", "platform-mocks", "src"),
                os.path.join(project_root, "libs", "platformkit", "tests", "mocks", "stm32u3", "platform-mocks", "inc"),
                os.path.join(project_root, "libs", "platformkit", "tests", "mocks", "stm32u3", "platform-mocks", "src"),
            ]
            for ref_dir in reference_dirs:
                if os.path.isdir(ref_dir) and ref_dir not in allowed_dirs:
                    allowed_dirs.append(ref_dir)
                    logger.info(f"[CLI] Added stm32u3 mock reference dir for stm32u5: {ref_dir}")

        return allowed_dirs

    @staticmethod
    def _source_content_for_test(
        test: GeneratedTest,
        ctx: "UnitTestContext",
    ) -> str:
        """Resolve source content across uploaded and repository path forms."""
        source_candidates = [
            test.source_file,
            os.path.basename(test.source_file),
            ctx.source_path_map.get(test.source_file, ""),
            ctx.source_path_map.get(os.path.basename(test.source_file), ""),
        ]
        for candidate in source_candidates:
            if candidate and candidate in ctx.source_contents:
                return ctx.source_contents[candidate]

        source_basename = os.path.basename(test.source_file)
        basename_matches = [
            content
            for path, content in ctx.source_contents.items()
            if os.path.basename(path) == source_basename
        ]
        if len(basename_matches) == 1:
            return basename_matches[0]

        for candidate in source_candidates:
            if candidate and os.path.isfile(candidate):
                try:
                    return Path(candidate).read_text(encoding="utf-8", errors="replace")
                except OSError as exc:
                    logger.warning(f"[VALIDATION] Unable to read source for {test.test_file}: {exc}")
        return ""

    def _validate_generated_test(
        self,
        test: GeneratedTest,
        ctx: "UnitTestContext",
    ) -> GeneratedTestValidation:
        result = validate_generated_test(
            test.test_content,
            self._source_content_for_test(test, ctx),
        )
        test.validation_errors = list(result.errors)
        if not result.valid:
            logger.error(
                f"[VALIDATION] Rejected {test.test_file}: {'; '.join(result.errors)}"
            )
        return result

    def _build_validation_failure_result(
        self,
        generated_tests: list[GeneratedTest],
        task_id: str,
        project_root: str,
    ) -> UnitTestResult:
        validation_errors = {
            test.test_file: list(getattr(test, "validation_errors", []))
            for test in generated_tests
            if getattr(test, "validation_errors", [])
        }
        first_error = next(iter(validation_errors.values()), ["unknown validation error"])
        return UnitTestResult(
            task_id=task_id,
            status=AgentStatus.FAILED,
            message=f"Generated test validation failed: {first_error[0]}",
            data={
                "files_processed": len(generated_tests),
                "tests_generated": len(generated_tests),
                "coverage": 0.0,
                "branch_coverage": 0.0,
                "function_coverage": 0.0,
                "test_count": 0,
                "test_output": "",
                "failed_cases": [],
                "generated_test_validation_errors": validation_errors,
                "generated_tests": [
                    {
                        "source_file": test.source_file,
                        "test_file": test.test_file,
                        "test_content": test.test_content,
                        "mock_content": test.mock_content,
                        "coverage": 0.0,
                        "compile_success": False,
                    }
                    for test in generated_tests
                ],
                "compilation_summary": {
                    "total_tests": len(generated_tests),
                    "compiled_successfully": 0,
                    "compilation_failed": len(generated_tests),
                    "all_compiled": False,
                },
                "saved_files": [],
                "output_dir": project_root,
                "token_usage": self.get_live_token_usage(),
            },
            generated_tests=generated_tests,
            total_coverage=0.0,
            iterations_used=1,
        )

    def _app_qbs_entry(
        self,
        test: GeneratedTest,
        ctx: "UnitTestContext",
        project_root: str,
    ) -> dict[str, str]:
        """Build the path record consumed by the task-scoped App QBS target."""
        real_source = (
            ctx.source_path_map.get(test.source_file)
            or ctx.source_path_map.get(os.path.basename(test.source_file))
            or (test.source_file if os.path.isabs(test.source_file) else "")
        )
        file_paths = generate_file_paths(
            source_filename=os.path.basename(test.source_file),
            layer=ctx.layer,
            project_root=project_root,
            platform=ctx.platform,
            source_path=real_source or test.source_file,
            source_content=self._source_content_for_test(test, ctx),
        )
        entry = filter_mock_paths(file_paths, ctx.enable_mock)
        entry["source_path"] = real_source or str(Path(project_root) / test.source_file)
        return entry

    @staticmethod
    def _generated_test_has_app_libs_reference(test: GeneratedTest) -> bool:
        """Return whether an APP-layer generated artifact references libs/platformkit."""
        return any(
            contains_app_forbidden_libs_reference(content or "")
            for content in (
                test.test_content,
                test.test_header_content,
                test.mock_content,
                test.mock_header_content,
                test.stub_content,
                test.stub_header_content,
            )
        )

    def _prepare_app_qbs_target(
        self,
        generated_tests: list[GeneratedTest],
        ctx: "UnitTestContext",
        project_root: str,
    ) -> dict[str, Any] | None:
        """Persist generated App files and prepare an isolated QBS target.

        This is intentionally called before the first compile attempt.  API
        generation keeps artifacts in memory until the save phase, while QBS
        needs the files to exist when it resolves the project.
        """
        if ctx.layer != "app" or not generated_tests or not project_root:
            return None
        entries: list[dict[str, str]] = []
        for test in generated_tests:
            if not test.test_content:
                continue
            entry = self._app_qbs_entry(test, ctx, project_root)
            entries.append(entry)
            self._clear_disabled_mock_content(test, ctx)
            headers = generate_header_templates(entry, enable_mock=ctx.enable_mock)
            test.test_header_content = test.test_header_content or headers["test_header"]
            test.mock_header_content = test.mock_header_content or headers["mock_header"]
            save_test_files_to_project(
                {
                    "test_impl": test.test_content,
                    "test_header": test.test_header_content or "",
                    "mock_impl": test.mock_content or "",
                    "mock_header": test.mock_header_content or "",
                    "stub_impl": test.stub_content or "",
                    "stub_header": test.stub_header_content or "",
                },
                entry,
            )
        if not entries:
            return None
        try:
            target = create_isolated_app_qbs_file(project_root, entries, ctx.task_id)
        except Exception as exc:
            logger.warning(f"[QBS][app] Failed to create isolated target: {exc}")
            return None
        ctx.qbs_project_path = target["project_path"]
        ctx.qbs_file = target["qbs_file"]
        ctx.qbs_products = list(target.get("products") or [target["product_name"]])
        logger.info(
            f"[QBS][app] Using isolated target product={target['product_name']} "
            f"file={target['qbs_file']}"
        )
        for diagnostic in target.get("diagnostics", []):
            logger.warning(f"[QBS][app] Isolated target diagnostic: {diagnostic}")
        return target

    async def _generate_test_via_cli(
        self, file_path: str, content: str, ctx: "UnitTestContext",
        file_paths: dict[str, str],
        header_content: str = "",
        dependent_headers: str = "",
        vendor_api_ref: str = "",
        existing_mock_ref: str = "",
        mock_dependency_guidance: str = "",
    ) -> Optional[GeneratedTest]:
        """CLI-first: use Claude CLI to generate, compile, and verify tests."""
        try:
            import asyncio
            from pathlib import Path
            from app.utils.claude_cli_monitor import ClaudeCliMonitor

            file_paths = dict(file_paths)
            file_paths = filter_mock_paths(file_paths, ctx.enable_mock)

            # Prefer inferring the real project root from the source file absolute path (looking for markers like libs/platformkit).
            # ctx.output_dir may point to the source file directory instead of the project root, causing incorrect path concatenation.
            # file_path may be just a filename (not absolute); resolve via source_path_map to get the real absolute path.
            _real_path = (
                ctx.source_path_map.get(file_path)
                or ctx.source_path_map.get(os.path.basename(file_path))
                or (file_path if os.path.isabs(file_path) else None)
            )
            project_root = self._resolve_context_project_root(ctx, _real_path)

            # Use the detected platform from file_paths (ground truth from source path)
            # instead of ctx.platform (user input, may be incorrect)
            detected_platform = file_paths.get('platform', ctx.platform)
            include_optional_artifacts = should_include_optional_artifacts(
                ctx.layer,
                content,
            )
            if include_optional_artifacts and file_paths.get("test_impl_path"):
                source_stem = Path(_real_path or file_path).stem
                file_paths["test_access_impl_path"] = str(
                    Path(file_paths["test_impl_path"]).parent
                    / f"{source_stem}_test_access.c"
                )
            else:
                file_paths.pop("test_access_impl_path", None)
            prompt_file_paths = {
                key: value for key, value in file_paths.items()
                if not key.startswith("stub_")
            }

            # Prepare QBS only when this task requested compilation. App
            # targets are task-scoped so the CLI never compiles unrelated
            # modules left in the aggregate test_app.qbs.
            qbs_target: dict[str, Any] | None = None
            qbs_prepared = False
            if not ctx.compile_verify:
                logger.info("[QBS] Skipping build configuration because compilation is disabled")
            elif ctx.layer == "app":
                try:
                    qbs_target = create_isolated_app_qbs_file(
                        project_root,
                        [{**file_paths, "source_path": _real_path or file_path}],
                        ctx.task_id,
                    )
                    ctx.qbs_project_path = qbs_target["project_path"]
                    ctx.qbs_file = qbs_target["qbs_file"]
                    ctx.qbs_products = list(qbs_target.get("products") or [])
                    qbs_prepared = True
                except Exception as exc:
                    logger.warning(f"[QBS][app] Isolated target unavailable; using canonical target: {exc}")
                    _ensure_app_qbs_file(project_root, file_path)
            elif ctx.layer == "common":
                common_qbs = configure_common_qbs_target(
                    project_root,
                    _real_path or file_path,
                    file_paths,
                )
                qbs_prepared = bool(common_qbs.get("success"))
                if qbs_prepared:
                    ctx.qbs_project_path = str(Path(common_qbs["qbs_file"]).parent)
                    ctx.qbs_file = common_qbs["qbs_file"]
                    ctx.qbs_products = ["test-common"]
                else:
                    logger.warning(
                        f"[QBS][common] Backend target preparation failed: {common_qbs.get('error')}"
                    )
            elif ctx.layer == "hal":
                from .qbs import _ensure_hal_qbs_file
                _ensure_hal_qbs_file(project_root, detected_platform)

            if ctx.layer not in {"app", "common"}:
                qbs_options = {"enable_mock": False} if not ctx.enable_mock else {}
                qbs_update = update_qbs_config(
                    module_name=file_paths.get("module_name", ""),
                    layer=ctx.layer,
                    platform=detected_platform,
                    project_root=project_root,
                    **qbs_options,
                )
                qbs_prepared = bool(qbs_update.get("success"))
                if qbs_prepared and qbs_update.get("qbs_file"):
                    ctx.qbs_file = qbs_update["qbs_file"]
                    ctx.qbs_project_path = str(Path(ctx.qbs_file).parent)

            prompt_content, large_file_context, _ = self._prepare_large_source_context(
                file_path=file_path,
                content=content,
                ctx=ctx,
                generation_path="cli",
                source_real_path=_real_path or "",
            )
            skill_prompt = await prepare_unittest_skills(
                self, ctx, "generate", file_paths=file_paths,
                source_path=_real_path or "",
                large_file_mode=bool(large_file_context),
            )
            task_prompt = build_cli_generation_prompt(
                source_file=file_path,
                source_content=prompt_content,
                file_paths=prompt_file_paths,
                project_root=project_root,
                source_real_path=_real_path or "",
                layer=ctx.layer,
                platform=detected_platform,
                build_profile=ctx.build_profile,
                coverage_target=ctx.target_coverage,
                header_content=header_content,
                dependent_headers=dependent_headers,
                vendor_api_ref=vendor_api_ref,
                existing_mock_ref=existing_mock_ref,
                mock_dependency_guidance=mock_dependency_guidance,
                skill_prompt=skill_prompt,
                previous_context_summary=ctx.compact_context,
                large_file_context=large_file_context,
                qbs_project_path=ctx.qbs_project_path or "",
                qbs_file=ctx.qbs_file or "",
                qbs_products=ctx.qbs_products,
                qbs_prepared=qbs_prepared,
                compile_verify=ctx.compile_verify,
                enable_mock=ctx.enable_mock,
            )
            system_prompt = build_cli_generation_system_prompt(
                prompt_file_paths, project_root,
                layer=ctx.layer,
                coverage_target=ctx.target_coverage,
                large_file_mode=bool(large_file_context),
                compile_verify=ctx.compile_verify,
                enable_mock=ctx.enable_mock,
            )

            await self._report_progress(
                ctx.task_id,
                33,
                "generate",
                f"Running CLI generation for {os.path.basename(file_path)}",
                details={
                    "skill_applied": bool(skill_prompt),
                    "skill_names": applied_skill_names(ctx, "generate"),
                    "source_real_path": _real_path or "",
                    "large_file_mode": bool(large_file_context),
                },
            )

            monitor = self._monitor
            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))

            allowed_dirs = self._build_cli_allowed_dirs(project_root, file_paths, detected_platform)
            if _real_path:
                source_dir = str(Path(_real_path).resolve().parent)
                if source_dir not in allowed_dirs:
                    allowed_dirs.append(source_dir)

            import time as _time
            cli_start_time = _time.time()

            # Resolve the CLI model from current settings
            _cli_model = self._llm_selection.model

            _task_id = ctx.task_id if hasattr(ctx, 'task_id') else None
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=_cli_model,
                    working_dir=Path(project_root),
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=_task_id,
                    upstream_provider=self._llm_selection.provider,
                    unbounded_runtime=True,
                    max_tool_calls=self._CLI_GENERATION_TOOL_LIMIT,
                    agent_teams=False,
                ),
            )

            self._update_compact_context_from_cli_result(ctx, result, "generate")

            self._accumulate_cli_token_usage(result.get("token_usage"))
            await self._log_cli_usage(result, _cli_model, "generate")

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0


            access_path = file_paths.get("test_access_impl_path", "")
            if ctx.layer == "app" and access_path and os.path.isfile(access_path):
                try:
                    qbs_target = create_isolated_app_qbs_file(
                        project_root,
                        [{**file_paths, "source_path": _real_path or file_path}],
                        ctx.task_id,
                    )
                    ctx.qbs_project_path = qbs_target["project_path"]
                    ctx.qbs_file = qbs_target["qbs_file"]
                    ctx.qbs_products = list(
                        qbs_target.get("products") or [qbs_target["product_name"]]
                    )
                except Exception as exc:
                    logger.warning(
                        f"[QBS][app] Failed to register test-access translation unit: {exc}"
                    )

            if not succeeded:
                logger.warning(f"_generate_test_via_cli failed: exit_code={result.get('exit_code')}")
                recovered = self._try_recover_cli_files(
                    file_paths, cli_start_time, source_file=file_path,
                )
                if recovered is not None:
                    self._clear_disabled_mock_content(recovered, ctx)
                    logger.info(
                        f"[CLI-RECOVER] Recovered test files from disk "
                        f"despite CLI failure (exit_code={result.get('exit_code')})"
                    )
                    return recovered
                if result.get("failure_category") in {"quota", "auth"}:
                    raise TerminalCliFailure(
                        result.get("error")
                        or "The configured LLM provider rejected the CLI request"
                    )
                if result.get("failure_category") in {
                    "path_failure",
                    "tool_loop",
                    "invalid_tool_arguments",
                    "command_parse_failure",
                    "tool_protocol_failure",
                    "tool_budget",
                }:
                    # These failures are deterministic CLI/workspace contract
                    # failures. Starting a second LLM request with the same
                    # prompt only repeats the bad path and burns tokens.
                    raise TerminalCliFailure(
                        result.get("error")
                        or "Claude CLI stopped after a deterministic workspace/tool failure"
                    )
                return None

            # Re-read generated files from disk
            test = GeneratedTest(
                source_file=file_path,
                test_file=os.path.basename(file_paths.get("test_impl_path", "")),
                test_content="",
                compile_success=False,  # Will be verified by post-CLI QBS build
                coverage=0.0,  # Real coverage collected later
            )
            for attr, path_key in [
                ("test_content", "test_impl_path"),
                ("test_header_content", "test_header_path"),
                ("mock_content", "mock_impl_path"),
                ("mock_header_content", "mock_header_path"),
            ]:
                fpath = file_paths.get(path_key, "")
                if fpath:
                    exists = os.path.isfile(fpath)
                    logger.info(f"[CLI] Check disk: {path_key}={fpath} exists={exists}")
                    if exists:
                        with open(fpath, "r", encoding="utf-8") as f:
                            setattr(test, attr, f.read())
            if include_optional_artifacts:
                access_path = file_paths.get("test_access_impl_path", "")
                if access_path and os.path.isfile(access_path):
                    with open(access_path, "r", encoding="utf-8") as f:
                        test.stub_content = f.read()
            # If CLI wrote test_content to disk, mark as compile_success=True
            # so the outer cli_all_compiled path triggers QBS verification.
            if test.test_content:
                test.compile_success = True

            if not test.test_content:
                # CLI wrote files but not found on disk, try extracting from stream-json output
                cli_output = result.get("output", "")
                if cli_output:
                    from .output_parser import parse_and_split_test_output
                    from .parsers import detect_truncation

                    # Diagnostics: log stream-json line count and types per line
                    raw_lines = [l.strip() for l in cli_output.splitlines() if l.strip()]
                    line_types = []
                    for rl in raw_lines:
                        try:
                            m = json.loads(rl)
                            t = m.get('type', '?')
                            # Record content item types
                            item_types = []
                            for it in m.get('message', {}).get('content', []):
                                if isinstance(it, dict):
                                    it_type = it.get('type', '?')
                                    if it_type == 'tool_use':
                                        it_type += f":{it.get('name', '?')}"
                                    item_types.append(it_type)
                            line_types.append(f"{t}[{','.join(item_types)}]" if item_types else t)
                        except Exception:
                            line_types.append("non-json")
                    logger.debug(f"[CLI] stream-json lines={len(raw_lines)}, types={line_types}")

                    text_parts = []
                    # Extract Write tool_use content from stream-json (CLI uses Write tool to write files,
                    # code is in tool_use.input, not in text)
                    write_tool_files: dict[str, str] = {}  # {file_path: content}
                    for line in cli_output.splitlines():
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            msg = json.loads(line)
                            if msg.get('type') == 'assistant':
                                for item in msg.get('message', {}).get('content', []):
                                    if not isinstance(item, dict):
                                        continue
                                    if item.get('type') == 'text':
                                        text_parts.append(item.get('text', ''))
                                    elif item.get('type') == 'tool_use' and item.get('name') == 'Write':
                                        tool_input = item.get('input', {})
                                        wp = tool_input.get('file_path', '')
                                        wc = tool_input.get('content', '')
                                        if wp and wc and len(wc) > 50:
                                            write_tool_files[wp] = wc
                            elif msg.get('type') == 'result':
                                result_text = msg.get('result', '')
                                if isinstance(result_text, str) and result_text.strip():
                                    text_parts.append(result_text)
                        except (json.JSONDecodeError, AttributeError):
                            continue

                    # Priority: recover files by path matching from Write tool_use
                    if write_tool_files:
                        logger.info(f"[CLI] Found {len(write_tool_files)} Write tool calls in stream-json")
                        for wp, wc in write_tool_files.items():
                            wp_norm = os.path.normpath(wp)
                            for attr, path_key in [
                                ("test_content", "test_impl_path"),
                                ("test_header_content", "test_header_path"),
                                ("mock_content", "mock_impl_path"),
                                ("mock_header_content", "mock_header_path"),
                            ]:
                                expected = file_paths.get(path_key, "")
                                if not expected:
                                    continue
                                expected_norm = os.path.normpath(expected)
                                # Path matching: exact match or filename match
                                if (wp_norm == expected_norm
                                        or os.path.basename(wp_norm) == os.path.basename(expected_norm)):
                                    setattr(test, attr, wc)
                                    logger.info(f"[CLI] Recovered {attr} from Write tool: {os.path.basename(wp)} ({len(wc)} chars)")
                                    # Also write to disk
                                    os.makedirs(os.path.dirname(expected), exist_ok=True)
                                    with open(expected, "w", encoding="utf-8") as f:
                                        f.write(wc)
                                    break
                        if test.test_content:
                            test.compile_success = True  # CLI wrote file; outer QBS verify decides final state

                    # Fallback: parse from assistant text (when CLI outputs code text directly)
                    if not test.test_content:
                        extracted_text = ''.join(text_parts)
                        if extracted_text and len(extracted_text) > 200:
                            logger.info(f"[CLI] Parsing test content from CLI text output ({len(extracted_text)} chars)")
                            logger.debug(f"[CLI] Text preview (first 500): {extracted_text[:500]}")
                            logger.debug(f"[CLI] Text preview (last 500): {extracted_text[-500:]}")
                            parsed = parse_and_split_test_output(extracted_text, "gtest")
                            if parsed.get("test_impl"):
                                test.test_content = parsed["test_impl"]
                                test.test_header_content = parsed.get("test_header", "")
                                test.mock_content = parsed.get("mock_impl", "")
                                test.mock_header_content = parsed.get("mock_header", "")
                                test.compile_success = True  # CLI wrote file; outer QBS verify decides final state
                                # Write to disk
                                for attr, path_key in [
                                    ("test_content", "test_impl_path"),
                                    ("test_header_content", "test_header_path"),
                                    ("mock_content", "mock_impl_path"),
                                    ("mock_header_content", "mock_header_path"),
                                ]:
                                    content = getattr(test, attr, "")
                                    fpath = file_paths.get(path_key, "")
                                    if content and fpath:
                                        os.makedirs(os.path.dirname(fpath), exist_ok=True)
                                        with open(fpath, "w", encoding="utf-8") as f:
                                            f.write(content)
                                        logger.info(f"[CLI] Saved parsed file: {fpath}")

            if not test.test_content:
                logger.warning("_generate_test_via_cli: no test content generated")
                return None

            self._clear_disabled_mock_content(test, ctx)
            return test
        except (TerminalCliFailure, SkillPreparationError):
            raise
        except Exception as e:
            logger.warning(f"_generate_test_via_cli failed: {e}")
            return None

    async def _generate_tests_via_cli_team(
        self,
        source_contents: dict[str, str],
        ctx: "UnitTestContext",
        file_paths_map: dict[str, dict[str, str]],
        context_map: dict[str, dict],
    ) -> list[GeneratedTest]:
        """CLI Team mode: pass all source files at once, CLI spawns multiple agents to process in parallel.

        Args:
            source_contents: {file_path: source_content}
            file_paths_map: {file_path: file_paths_dict}
            context_map: {file_path: {header, deps, vendor, mock, guidance}}

        Returns:
            List of successfully generated GeneratedTest
        """
        try:
            import asyncio
            import time as _time
            from pathlib import Path
            from app.utils.claude_cli_monitor import ClaudeCliMonitor
            from .prompts import build_cli_team_generation_prompt, build_cli_team_system_prompt

            # Infer the real project root from any source file's absolute path.
            # Keys in source_contents may be bare filenames; resolve via source_path_map to get the real absolute path.
            _first_src = next(iter(source_contents), None)
            _real_first = None
            if _first_src:
                _real_first = (
                    ctx.source_path_map.get(_first_src)
                    or ctx.source_path_map.get(os.path.basename(_first_src))
                    or (_first_src if os.path.isabs(_first_src) else None)
                )
            project_root = self._resolve_context_project_root(ctx, _real_first)

            file_paths_map = {key: filter_mock_paths(value, ctx.enable_mock) for key, value in file_paths_map.items()}
            prepared_source_contents: dict[str, str] = {}
            prepared_context_map: dict[str, dict[str, Any]] = {}
            team_large_file_mode = False
            for source_file, source_content in source_contents.items():
                source_real_path = (
                    ctx.source_path_map.get(source_file)
                    or ctx.source_path_map.get(os.path.basename(source_file))
                    or (source_file if os.path.isabs(source_file) else "")
                )
                prompt_content, large_file_context, _ = self._prepare_large_source_context(
                    file_path=source_file,
                    content=source_content,
                    ctx=ctx,
                    generation_path="cli-team",
                    source_real_path=source_real_path,
                )
                prepared_source_contents[source_file] = prompt_content
                prepared_context = dict(context_map.get(source_file, {}))
                prepared_context["source_filename"] = os.path.basename(source_file)
                prepared_context["source_real_path"] = source_real_path
                prepared_context["source_original_chars"] = len(source_content or "")
                prepared_context["source_prompt_chars"] = len(prompt_content or "")
                if large_file_context:
                    team_large_file_mode = True
                    prepared_context["large_file_context"] = large_file_context
                prepared_context_map[source_file] = prepared_context

            task_prompt = build_cli_team_generation_prompt(
                source_files=prepared_source_contents,
                file_paths_map=file_paths_map,
                project_root=project_root,
                layer=ctx.layer,
                platform=ctx.platform,
                build_profile=ctx.build_profile,
                coverage_target=ctx.target_coverage,
                context_map=prepared_context_map,
                enable_mock=ctx.enable_mock,
                skill_prompt=await prepare_unittest_skills(
                    self, ctx, "generate",
                    large_file_mode=team_large_file_mode,
                ),
            )
            system_prompt = build_cli_team_system_prompt(
                project_root=project_root,
                layer=ctx.layer,
                coverage_target=ctx.target_coverage,
                n_files=len(source_contents),
                large_file_mode=team_large_file_mode,
            )

            monitor = self._monitor
            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))

            # Collect all directories needing access
            allowed_dirs = [project_root]
            for fp_dict in file_paths_map.values():
                for d in self._build_cli_allowed_dirs(project_root, fp_dict, ctx.platform):
                    if d not in allowed_dirs:
                        allowed_dirs.append(d)
            for source_file in source_contents:
                source_real_path = (
                    ctx.source_path_map.get(source_file)
                    or ctx.source_path_map.get(os.path.basename(source_file))
                    or (source_file if os.path.isabs(source_file) else "")
                )
                if source_real_path:
                    source_dir = str(Path(source_real_path).resolve().parent)
                    if source_dir not in allowed_dirs:
                        allowed_dirs.append(source_dir)

            cli_start_time = _time.time()

            # Resolve the CLI model from current settings
            _cli_model = self._llm_selection.model

            _task_id = ctx.task_id if hasattr(ctx, 'task_id') else None
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=_cli_model,
                    working_dir=Path(project_root),
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=_task_id,
                    upstream_provider=self._llm_selection.provider,
                    unbounded_runtime=True,
                    max_tool_calls=self._CLI_GENERATION_TOOL_LIMIT * max(1, len(source_contents)),
                    agent_teams=False,
                ),
            )

            self._accumulate_cli_token_usage(result.get("token_usage"))
            await self._log_cli_usage(result, _cli_model, "team-generate")

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0

            if not succeeded:
                logger.warning(f"_generate_tests_via_cli_team failed: exit_code={result.get('exit_code')}")

            # Pre-extract Write tool_use content from stream-json for recovery when disk read fails
            write_tool_files: dict[str, str] = {}
            cli_output = result.get("output", "")
            if cli_output:
                for line in cli_output.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        if msg.get('type') == 'assistant':
                            for item in msg.get('message', {}).get('content', []):
                                if (isinstance(item, dict)
                                        and item.get('type') == 'tool_use'
                                        and item.get('name') == 'Write'):
                                    ti = item.get('input', {})
                                    wp = ti.get('file_path', '')
                                    wc = ti.get('content', '')
                                    if wp and wc and len(wc) > 50:
                                        write_tool_files[wp] = wc
                    except (json.JSONDecodeError, AttributeError):
                        continue
                if write_tool_files:
                    logger.info(f"[CLI-TEAM] Pre-extracted {len(write_tool_files)} Write tool calls from stream-json")

            # Read all generated files from disk
            generated_tests: list[GeneratedTest] = []
            for file_path, fp in file_paths_map.items():
                test = GeneratedTest(
                    source_file=file_path,
                    test_file=os.path.basename(fp.get("test_impl_path", "")),
                    test_content="",
                    compile_success=succeeded,
                    coverage=0.0,
                )
                for attr, path_key in [
                    ("test_content", "test_impl_path"),
                    ("test_header_content", "test_header_path"),
                    ("mock_content", "mock_impl_path"),
                    ("mock_header_content", "mock_header_path"),
                ]:
                    fpath = fp.get(path_key, "")
                    if fpath and os.path.isfile(fpath):
                        with open(fpath, "r", encoding="utf-8") as f:
                            setattr(test, attr, f.read())

                # Recover from Write tool_use when disk read fails
                if not test.test_content and write_tool_files:
                    for attr, path_key in [
                        ("test_content", "test_impl_path"),
                        ("test_header_content", "test_header_path"),
                        ("mock_content", "mock_impl_path"),
                        ("mock_header_content", "mock_header_path"),
                    ]:
                        expected = fp.get(path_key, "")
                        if not expected or getattr(test, attr, ""):
                            continue
                        expected_norm = os.path.normpath(expected)
                        for wp, wc in write_tool_files.items():
                            wp_norm = os.path.normpath(wp)
                            if (wp_norm == expected_norm
                                    or os.path.basename(wp_norm) == os.path.basename(expected_norm)):
                                setattr(test, attr, wc)
                                os.makedirs(os.path.dirname(expected), exist_ok=True)
                                with open(expected, "w", encoding="utf-8") as f:
                                    f.write(wc)
                                logger.info(f"[CLI-TEAM] Recovered {attr} from Write tool: {os.path.basename(wp)} ({len(wc)} chars)")
                                break
                    if test.test_content:
                        test.compile_success = False

                if test.test_content:
                    generated_tests.append(test)
                    logger.info(f"[CLI-TEAM] Generated test for {file_path}")
                else:
                    # Attempt recovery
                    recovered = self._try_recover_cli_files(fp, cli_start_time, source_file=file_path)
                    if recovered:
                        generated_tests.append(recovered)
                        logger.info(f"[CLI-TEAM] Recovered test for {file_path}")
                    else:
                        logger.warning(f"[CLI-TEAM] No test generated for {file_path}")

            if (
                not succeeded
                and result.get("failure_category") in {"quota", "auth"}
                and len(generated_tests) < len(source_contents)
            ):
                raise TerminalCliFailure(
                    result.get("error")
                    or "The configured LLM provider rejected the CLI request"
                )
            if (
                not succeeded
                and result.get("failure_category") in {
                    "path_failure",
                    "tool_loop",
                    "invalid_tool_arguments",
                    "command_parse_failure",
                    "tool_protocol_failure",
                    "tool_budget",
                }
                and len(generated_tests) < len(source_contents)
            ):
                raise TerminalCliFailure(
                    result.get("error")
                    or "Claude CLI stopped after a deterministic workspace/tool failure"
                )

            return generated_tests
        except (TerminalCliFailure, SkillPreparationError):
            raise
        except Exception as e:
            logger.warning(f"_generate_tests_via_cli_team failed: {e}")
            return []

    def _try_recover_cli_files(
        self,
        file_paths: dict[str, str],
        cli_start_time: float,
        source_file: str = "",
    ) -> Optional[GeneratedTest]:
        """Attempt to recover generated files from disk after CLI failure.

        CLI tool execution order: Write/Edit to disk → result returned to model → turn ends flush stdout.
        So even if CLI is killed or pipe output lost, files may already be on disk.

        Check conditions:
        1. test_impl_path file exists
        2. File modification time is after CLI start time (exclude old files)
        3. File content is non-empty and contains TEST macro (has actual code)
        """
        test_impl_path = file_paths.get("test_impl_path", "")
        if not test_impl_path or not os.path.isfile(test_impl_path):
            logger.info("[CLI-RECOVER] No test impl file on disk, cannot recover")
            return None

        mtime = os.path.getmtime(test_impl_path)
        if mtime < cli_start_time:
            logger.info(
                f"[CLI-RECOVER] Test impl file is stale "
                f"(mtime={mtime:.0f} < cli_start={cli_start_time:.0f}), skip"
            )
            return None

        try:
            with open(test_impl_path, "r", encoding="utf-8") as f:
                test_content = f.read()
        except Exception as e:
            logger.warning(f"[CLI-RECOVER] Failed to read {test_impl_path}: {e}")
            return None

        if len(test_content) < 100 or "TEST" not in test_content:
            logger.info(
                f"[CLI-RECOVER] Test impl too short or no TEST macro "
                f"({len(test_content)} chars), skip"
            )
            return None

        logger.info(
            f"[CLI-RECOVER] Found valid test impl on disk "
            f"({len(test_content)} chars, mtime={mtime:.0f})"
        )

        test = GeneratedTest(
            source_file=source_file,
            test_file=os.path.basename(test_impl_path),
            test_content=test_content,
            compile_success=False,  # Compilation not verified yet, handled in Phase 3
            coverage=0.0,
        )
        for attr, path_key in [
            ("test_header_content", "test_header_path"),
            ("mock_content", "mock_impl_path"),
            ("mock_header_content", "mock_header_path"),
        ]:
            fpath = file_paths.get(path_key, "")
            if fpath and os.path.isfile(fpath):
                fmtime = os.path.getmtime(fpath)
                if fmtime >= cli_start_time:
                    try:
                        with open(fpath, "r", encoding="utf-8") as f:
                            setattr(test, attr, f.read())
                    except Exception as e:
                        logger.warning(f"[CLI-RECOVER] Failed to read {fpath}: {e}")

        access_path = file_paths.get("test_access_impl_path", "")
        if access_path and os.path.isfile(access_path):
            try:
                if os.path.getmtime(access_path) >= cli_start_time:
                    with open(access_path, "r", encoding="utf-8") as f:
                        test.stub_content = f.read()
            except OSError as exc:
                logger.warning(f"[CLI-RECOVER] Failed to read {access_path}: {exc}")

        return test

    async def _collect_real_coverage(
        self, source_files: list[str], ctx: "UnitTestContext",
        project_root: str | None = None,
    ) -> dict:
        """Run test executable (to generate .gcda) then collect gcov coverage."""
        import asyncio
        from .paths import find_project_root_for_source as _find_root_cov

        inferred_root = None
        if not project_root:
            for src in source_files:
                real_src = (
                    ctx.source_path_map.get(src)
                    or ctx.source_path_map.get(os.path.basename(src))
                    or (src if os.path.isabs(src) else None)
                )
                if real_src:
                    inferred_root = _find_root_cov(real_src)
                    if inferred_root:
                        break

        project_root = project_root or inferred_root or ctx.output_dir or "."
        try:
            # Rebuild to regenerate .gcno files with current machine paths
            # (cross-machine .gcno files contain stale source paths, causing gcov to fail)
            build_result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: run_qbs_build(
                    layer=ctx.layer,
                    platform=ctx.platform,
                    project_root=project_root,
                    build_profile=ctx.build_profile,
                    enable_coverage=True,
                    qbs_project_path=getattr(ctx, "qbs_project_path", None),
                    qbs_file=getattr(ctx, "qbs_file", None),
                    product_name=(getattr(ctx, "qbs_products", None) or [None])[0],
                ),
            )
            if build_result.get("success"):
                logger.info("[COV] QBS rebuild succeeded — .gcno files regenerated")
            else:
                error_msg = build_result.get('error', 'Unknown error')
                logger.warning(f"[COV] QBS full rebuild failed: {error_msg}")
                logger.warning("[COV] Skipping existing gcov artifacts because coverage rebuild failed")
                if build_result.get("output"):
                    logger.debug(f"[COV] QBS build output: {build_result.get('output')[:2000]}")
                self._persist_qbs_build_failure(ctx, build_result)
                return {
                    "success": False,
                    "coverage_build_failed": True,
                    "coverage_build_error": error_msg,
                    "coverage_build_error_code": build_result.get("error_code"),
                    "coverage_build_retryable": bool(build_result.get("retryable", True)),
                    "coverage_build_output": build_result.get("output", ""),
                    "line_coverage": 0.0,
                    "branch_coverage": 0.0,
                    "function_coverage": 0.0,
                    "lines_total": 0,
                    "lines_executed": 0,
                    "branches_total": 0,
                    "branches_executed": 0,
                    "functions_total": 0,
                    "functions_executed": 0,
                    "per_file": {},
                }

            # Run test executable to ensure .gcda files are fresh
            test_result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: run_test_executable(
                    layer=ctx.layer,
                    platform=ctx.platform,
                    project_root=project_root,
                    build_profile=ctx.build_profile,
                    qbs_project_path=getattr(ctx, "qbs_project_path", None),
                    qbs_file=getattr(ctx, "qbs_file", None),
                    product_name=(getattr(ctx, "qbs_products", None) or [None])[0],
                ),
            )
            if not test_result.get("success"):
                logger.warning(f"Test execution failed: {test_result.get('error')}")

            # Collect gcov coverage
            coverage_data = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: collect_gcov_coverage(
                    source_files=source_files,
                    layer=ctx.layer,
                    platform=ctx.platform,
                    project_root=project_root,
                    build_profile=ctx.build_profile,
                    qbs_project_path=getattr(ctx, "qbs_project_path", None),
                    qbs_file=getattr(ctx, "qbs_file", None),
                    product_name=(getattr(ctx, "qbs_products", None) or [None])[0],
                ),
            )

            # Merge test execution data into coverage_data (regardless of success/failure)
            coverage_data["test_cases"] = test_result.get("test_cases", [])
            coverage_data["total"] = test_result.get("total", 0)
            coverage_data["passed"] = test_result.get("passed", 0)
            coverage_data["failed"] = test_result.get("failed", 0)
            coverage_data["failed_cases"] = test_result.get("failed_cases", [])
            if test_result.get("test_cases"):
                logger.info(
                    f"[COV] Test execution: {test_result.get('passed', 0)}/{test_result.get('total', 0)} passed, "
                    f"{len(test_result.get('test_cases', []))} test cases collected"
                )

            logger.info(
                f"[COV] gcov coverage: {coverage_data.get('line_coverage', 0):.1f}% "
                f"({coverage_data.get('lines_executed', 0)}/{coverage_data.get('lines_total', 0)} lines)"
            )
            return coverage_data
        except Exception as e:
            logger.warning(f"_collect_real_coverage failed: {e}")
            return {"success": False, "line_coverage": 0.0, "per_file": {}}

    async def _improve_coverage_via_cli(
        self, test: GeneratedTest, ctx: "UnitTestContext",
        file_paths: dict[str, str], coverage_data: dict,
        force_modify: bool = False,
    ) -> dict:
        """Use Claude CLI to improve test coverage based on gcov data.
        
        Args:
            force_modify: If True, use a more aggressive prompt that demands code modification
        
        Returns:
            dict with keys:
                - success: bool
                - failure_reason: str (one of: tool_error, permission_error, no_source_context,
                                      no_code_change, no_coverage_gain, unknown)
                - files_modified: bool
        """
        try:
            import asyncio
            import hashlib
            from pathlib import Path
            from uuid import uuid4
            from app.utils.claude_cli_monitor import ClaudeCliMonitor
            from .prompts import compact_large_file_context

            # Infer project root from the real absolute source path
            from .paths import find_project_root_for_source as _find_root_cov
            _inferred_root = None
            _src_file = test.source_file if hasattr(test, 'source_file') else None
            
            # === Solution 4: Pre-validation - ensure source file is accessible ===
            _real_src = None
            if _src_file:
                _real_src = (
                    ctx.source_path_map.get(_src_file)
                    or ctx.source_path_map.get(os.path.basename(_src_file))
                    or (_src_file if os.path.isabs(_src_file) else None)
                )
                if _real_src:
                    _inferred_root = _find_root_cov(_real_src)
            
            # Pre-validation: source file must be parseable and exist
            if not _real_src:
                logger.warning(
                    f"[COV] Coverage improve skipped for {_src_file}: "
                    "source file path not resolvable from source_path_map"
                )
                return {"success": False, "failure_reason": "no_source_context", "files_modified": False}
            
            if not os.path.isfile(_real_src):
                logger.warning(
                    f"[COV] Coverage improve skipped for {_src_file}: "
                    f"resolved source file does not exist: {_real_src}"
                )
                return {"success": False, "failure_reason": "no_source_context", "files_modified": False}
            
            project_root = _inferred_root or ctx.output_dir or "."
            
            # === Complete Fix D: Pre-read source file and uncovered code excerpts ===
            source_content = ""
            uncovered_code_excerpts = ""
            try:
                with open(_real_src, "r", encoding="utf-8", errors="ignore") as f:
                    source_lines = f.readlines()
                    source_content = "".join(source_lines)
                    
                    # Extract code excerpts for uncovered lines
                    uncovered_lines = coverage_data.get("uncovered_lines", [])
                    if uncovered_lines and source_lines:
                        excerpts = []
                        for line_num in uncovered_lines[:50]:  # Limit to 50 lines max
                            if 1 <= line_num <= len(source_lines):
                                # Extract context: 2 lines before and after
                                start = max(1, line_num - 2)
                                end = min(len(source_lines), line_num + 2)
                                context = "".join(
                                    f"{'>' if i == line_num else ' '} {i:4d} | {source_lines[i-1]}"
                                    for i in range(start, end + 1)
                                )
                                excerpts.append(f"Lines {start}-{end} (uncovered: {line_num}):\n{context}")
                        uncovered_code_excerpts = "\n\n".join(excerpts[:10])  # Max 10 excerpts
            except Exception as e:
                logger.warning(f"[COV] Failed to read source file {_real_src}: {e}")
                return {"success": False, "failure_reason": "no_source_context", "files_modified": False}

            coverage_plan = self._build_coverage_plan(source_content, coverage_data)
            _coverage_source_excerpt, large_file_context, _ = self._prepare_large_source_context(
                file_path=test.source_file,
                content=source_content,
                ctx=ctx,
                generation_path="coverage-cli",
                source_real_path=_real_src,
            )
            active_chunk = None
            if large_file_context and ctx.large_file_active_chunk_id:
                active_chunk = next(
                    (
                        item for item in ctx.large_file_checkpoints
                        if item.get("source_file") == test.source_file
                        and item.get("chunk_id") == ctx.large_file_active_chunk_id
                    ),
                    None,
                )
            if active_chunk:
                chunk_start = int(active_chunk.get("line_start") or 1)
                chunk_end = int(active_chunk.get("line_end") or len(source_lines))
                chunk_functions = {
                    str(item.get("name") or "")
                    for item in active_chunk.get("functions", [])
                    if isinstance(item, dict)
                }
                coverage_data = dict(coverage_data)
                coverage_data["uncovered_lines"] = [
                    line for line in coverage_data.get("uncovered_lines", [])
                    if chunk_start <= int(line) <= chunk_end
                ]
                coverage_data["uncovered_functions"] = [
                    name for name in coverage_data.get("uncovered_functions", [])
                    if str(name) in chunk_functions
                ]
                coverage_plan = [
                    item for item in coverage_plan
                    if item.get("function") in chunk_functions
                    or any(
                        chunk_start <= int(line) <= chunk_end
                        for line in item.get("uncovered_lines", [])
                    )
                ]
                excerpts = []
                for line_num in coverage_data["uncovered_lines"][:20]:
                    start = max(chunk_start, int(line_num) - 2)
                    end = min(chunk_end, int(line_num) + 2)
                    excerpt = "".join(
                        f"{'>' if i == int(line_num) else ' '} {i:4d} | {source_lines[i-1]}"
                        for i in range(start, end + 1)
                    )
                    excerpts.append(
                        f"Lines {start}-{end} (uncovered: {line_num}):\n{excerpt}"
                    )
                uncovered_code_excerpts = "\n\n".join(excerpts)
            # The long-file builder already provides bounded excerpts and a
            # checkpoint manifest. Do not inject the raw 5k prefix as a second
            # competing context; normal-sized files keep the useful excerpt.
            prompt_source_excerpt = (
                ""
                if large_file_context
                else source_content[:5000]
            )
            skill_prompt = await prepare_unittest_skills(
                self, ctx, "coverage_improve", file_paths=file_paths,
                source_path=_real_src or "", coverage_data=coverage_data,
                large_file_mode=bool(large_file_context),
            )
            # Coverage turns are independent repair attempts. Keep the
            # actionable context, but do not resend a full skill/diagnostic
            # history on every attempt.
            # The stage-specific skill is already concise; never cut its contract.
            large_file_context = compact_large_file_context(large_file_context, 12000)
            previous_context_summary = compact_large_file_context(ctx.compact_context, 5000)
            prompt_metrics = [float(coverage_data.get("line_coverage", test.coverage) or test.coverage)]
            if int(coverage_data.get("branches_total") or 0) > 0:
                prompt_metrics.append(float(coverage_data.get("branch_coverage", test.branch_coverage) or test.branch_coverage))
            if int(coverage_data.get("functions_total") or 0) > 0:
                prompt_metrics.append(float(coverage_data.get("function_coverage", test.function_coverage) or test.function_coverage))
            prompt_coverage = min(prompt_metrics)

            artifact_snapshot = await asyncio.to_thread(snapshot_cli_artifacts, file_paths)

            # === Solution 1 & 2 & G: Build enhanced prompt ===
            # Use the detected platform from file_paths (ground truth from source path)
            detected_platform = file_paths.get('platform', ctx.platform)

            if force_modify:
                # Use more aggressive second-attempt prompt
                from .prompts import build_force_modify_coverage_prompt
                task_prompt = build_force_modify_coverage_prompt(
                    source_file=test.source_file,
                    file_paths=file_paths,
                    project_root=project_root,
                    layer=ctx.layer,
                    platform=detected_platform,
                    build_profile=ctx.build_profile,
                    coverage_target=ctx.target_coverage,
                    current_coverage=prompt_coverage,
                    uncovered_lines=coverage_data.get("uncovered_lines", []),
                    uncovered_functions=coverage_data.get("uncovered_functions", []),
                    real_source_path=_real_src,
                    source_content_excerpt=prompt_source_excerpt,
                    uncovered_code_excerpts=uncovered_code_excerpts,
                    previous_context_summary=previous_context_summary,
                    skill_prompt=skill_prompt,
                    coverage_plan=coverage_plan,
                    large_file_context=large_file_context,
                    qbs_project_path=ctx.qbs_project_path or "",
                    qbs_file=ctx.qbs_file or "",
                    qbs_products=ctx.qbs_products,
                )
            else:
                # Use regular prompt
                task_prompt = build_cli_coverage_improvement_prompt(
                    source_file=test.source_file,
                    file_paths=file_paths,
                    project_root=project_root,
                    layer=ctx.layer,
                    platform=detected_platform,
                    build_profile=ctx.build_profile,
                    coverage_target=ctx.target_coverage,
                    current_coverage=prompt_coverage,
                    uncovered_lines=coverage_data.get("uncovered_lines", []),
                    uncovered_functions=coverage_data.get("uncovered_functions", []),
                    real_source_path=_real_src,  # Added: real source file path
                    source_content_excerpt=prompt_source_excerpt,
                    uncovered_code_excerpts=uncovered_code_excerpts,  # Added: uncovered code excerpts
                    previous_context_summary=previous_context_summary,
                    skill_prompt=skill_prompt,
                    coverage_plan=coverage_plan,
                    large_file_context=large_file_context,
                    qbs_project_path=ctx.qbs_project_path or "",
                    qbs_file=ctx.qbs_file or "",
                    qbs_products=ctx.qbs_products,
                )
            system_prompt = build_cli_generation_system_prompt(
                file_paths, project_root,
                layer=ctx.layer,
                coverage_target=ctx.target_coverage,
                large_file_mode=bool(large_file_context),
            )

            monitor = self._monitor
            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))

            allowed_dirs = self._build_cli_allowed_dirs(project_root, file_paths, detected_platform)
            if _real_src:
                source_dir = str(Path(_real_src).parent)
                if source_dir not in allowed_dirs:
                    allowed_dirs.append(source_dir)

            _cli_model = self._llm_selection.model

            _task_id = ctx.task_id if hasattr(ctx, 'task_id') else None
            # Do not resume the entire generation transcript for every
            # coverage repair. A fresh child session keeps the task/session
            # registry resumable while preventing prompt growth across dozens
            # of coverage tool turns.
            coverage_session_id = str(uuid4())
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=_cli_model,
                    working_dir=Path(project_root),
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=_task_id,
                    upstream_provider=self._llm_selection.provider,
                    claude_session_id=coverage_session_id,
                    resume_session=False,
                    # Coverage work on a large-file chunk may require several
                    # focused build/test cycles. Keep this as an action budget
                    # (not a wall-clock timeout) and allow up to 20x the
                    # previous chunk budget before yielding for resume.
                    max_tool_calls=160 if active_chunk else 24,
                    unbounded_runtime=True,
                ),
            )

            self._update_compact_context_from_cli_result(ctx, result, "coverage_improve")

            self._accumulate_cli_token_usage(result.get("token_usage"))
            await self._log_cli_usage(result, _cli_model, "coverage_improve")

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0
            raise_if_cli_cancelled(result, _task_id)
            files_modified = await asyncio.to_thread(
                reload_cli_artifacts, test, file_paths, artifact_snapshot,
            )
            if files_modified:
                logger.info("[COV] CLI edits are ready for build and coverage verification")
                return {
                    "success": True, "failure_reason": "", "files_modified": True,
                    "verification_required": True,
                    "cli_completed": succeeded,
                    "cli_failure_category": result.get("failure_category"),
                }
            if succeeded:
                return {"success": False, "failure_reason": "no_code_change", "files_modified": False}

            output = result.get("output", "")
            if result.get("failure_category") in {"tool_budget", "auth", "quota", "budget_exceeded"}:
                failure_reason = result["failure_category"]
            elif "tool_use_error" in output or "Invalid pages parameter" in output:
                failure_reason = "tool_error"
            elif "allowed file list" in output or "not provided in your allowed" in output:
                failure_reason = "permission_error"
            else:
                failure_reason = "unknown"

            logger.warning(
                f"[COV] CLI coverage improvement failed for {test.source_file}: {failure_reason}"
            )
            return {"success": False, "failure_reason": failure_reason, "files_modified": False}
        except SkillPreparationError:
            raise
        except Exception as e:
            logger.warning(f"_improve_coverage_via_cli failed: {e}")
            return {"success": False, "failure_reason": "unknown", "files_modified": False}

    @staticmethod
    def _qbs_environment_error(output: str) -> str | None:
        """Return a description when build output shows a toolchain/environment
        failure rather than a code defect; None when output looks like a
        normal compile diagnostic.

        Missing profiles or a missing qbs binary cannot be fixed by editing
        generated tests, so the repair loop must not burn CLI iterations on
        them.
        """
        lowered = (output or "").lower()
        if "does not exist" in lowered and "profile" in lowered:
            return "QBS profile is not registered in the build settings"
        for marker, description in (
            ("no profile defined", "no default QBS profile is configured"),
            ("no default profile", "no default QBS profile is configured"),
            ("qbs cli not found", "QBS command-line tool is not available"),
            ("command not found", "QBS command-line tool is not available"),
        ):
            if marker in lowered:
                return description
        return None

    async def _do_compile(
        self, test_content: str, project_root: str,
        layer: str = "hal", platform: str = "stm32u3", profile: str = "mingw",
        qbs_project_path: str | None = None,
        qbs_file: str | None = None,
        qbs_products: list[str] | None = None,
    ) -> CompileResult:
        """Call qbs_build to compile and return CompileResult."""
        qbs_context = validate_qbs_build_context(project_root, layer, platform)
        if qbs_project_path:
            qbs_context.update({
                "project_path": qbs_project_path,
                "qbs_file": qbs_file or qbs_context.get("qbs_file"),
                "products": list(qbs_products or qbs_context.get("products") or []),
                "ready": Path(qbs_project_path).is_dir()
                and (not qbs_file or Path(qbs_file).is_file()),
            })
        if not qbs_context.get("ready"):
            return CompileResult(
                success=False,
                output=str(qbs_context.get("error") or "QBS build context is not ready"),
                error_code=qbs_context.get("error_code"),
                retryable=bool(qbs_context.get("retryable", False)),
            )
        qbs_path = qbs_context["project_path"]
        qbs_file = qbs_context["qbs_file"]
        products = qbs_context["products"]
        try:
            kwargs: dict = dict(
                project_path=qbs_path, profile=profile, configuration="debug",
                products=products,
            )
            if qbs_file:
                kwargs["project_file"] = qbs_file
            result = await self._mcp.call_tool("qbs_build", **kwargs)
            if result.success:
                return CompileResult(success=True, output=result.data.get("stdout", ""))
            stderr = result.data.get("stderr", "")
            stdout = result.data.get("stdout", "")
            error_code = result.data.get("error_code")
            retryable = bool(result.data.get("retryable", True))
            output = "\n".join(part for part in (stderr, stdout) if part)
            # Environment/toolchain failures (missing profile, missing qbs) are
            # not code defects: mark them non-retryable so _compile_and_fix_tests
            # fails fast instead of spending CLI repair iterations on them.
            environment_error = self._qbs_environment_error(output)
            if environment_error:
                logger.error(
                    f"[QBS] Environment failure, skipping code repair: {environment_error}"
                )
                return CompileResult(
                    success=False,
                    output=f"{output}\n(Environment error: {environment_error})",
                    error_code="qbs_environment_error",
                    retryable=False,
                )
            error_blocks = parse_qbs_build_errors(output)
            errors = self._parse_gcc_errors(output) if not error_blocks else []
            # Convert QBS error blocks (list[str]) to CompileError objects
            # so the fix branch in _compile_and_fix_tests is entered.
            if not errors and error_blocks:
                errors = [CompileError(file="", line=0, column=0,
                                       message=block[:2000])
                          for block in error_blocks]
            # Fallback: if both parsers return empty but stderr has content,
            # create a catch-all CompileError so the fix branch is entered.
            if not errors and not error_blocks and output.strip():
                errors = [CompileError(file="", line=0, column=0,
                                        message=output.strip()[:2000])]
            return CompileResult(
                success=False,
                output=output,
                errors=errors,
                error_code=error_code,
                retryable=retryable,
            )
        except Exception as e:
            logger.warning(f"_do_compile failed: {e}")
            return CompileResult(success=False, output=str(e))

    async def _run_compiled_tests(
        self, project_root: str, ctx: "UnitTestContext", task_id: str,
    ) -> tuple[str, int, list[str]]:
        """Run the compiled tests."""
        profile = ctx.build_profile if hasattr(ctx, "build_profile") else "mingw"
        platform = ctx.platform if hasattr(ctx, "platform") else "stm32u3"
        layer = ctx.layer if hasattr(ctx, "layer") else "hal"
        qbs_context = resolve_qbs_build_context(project_root, layer, platform)
        qbs_path = getattr(ctx, "qbs_project_path", None) or qbs_context["project_path"]
        products = list(getattr(ctx, "qbs_products", None) or qbs_context.get("products") or [])
        test_filter = products[0] if products else f"test-{layer}"
        try:
            result = await self._mcp.call_tool("qbs_run_tests",
                project_path=qbs_path, profile=profile,
                filter=test_filter,
                products=products,
                project_file=getattr(ctx, "qbs_file", None),
            )
            data = result.data or {}
            # A GTest summary does not establish process success: teardown or
            # the execution wrapper can still fail after passing test cases.
            stdout = "\n".join(
                part for part in (data.get("stdout"), data.get("stderr"), result.error) if part
            )
            test_count, failed_cases = self._parse_test_results(stdout)
            if test_count > 0 and not failed_cases and (
                not result.success or data.get("returncode") not in (0, None)
            ):
                failed_cases.append(
                    f"{_TEST_EXECUTION_FAILURE_PREFIX}: test process failed "
                    f"with exit code {data.get('returncode')}"
                )
            logger.info(
                f"[Phase4] qbs_run_tests rc={data.get('returncode')}, "
                f"parsed {test_count} test(s), {len(failed_cases)} failed case(s)"
            )
            if test_count == 0 and data.get("returncode") not in (0, None):
                logger.warning(
                    "[Phase4] qbs_run_tests returned no GTest summary, "
                    f"output tail: {(stdout or '').strip()[-300:]!r}"
                )
                # `qbs run` can fail on wrapper-level issues (e.g. build-graph
                # lock held right after a CLI repair build) while the test
                # binary itself is healthy. Run the built executable directly
                # so runtime failures still reach the repair loop.
                import asyncio as _aio
                direct = await _aio.get_event_loop().run_in_executor(
                    None,
                    lambda: run_test_executable(
                        layer=layer,
                        platform=platform,
                        project_root=project_root,
                        build_profile=profile,
                        qbs_project_path=qbs_path,
                        qbs_file=getattr(ctx, "qbs_file", None),
                        product_name=(products[0] if products else None),
                    ),
                )
                if direct.get("total"):
                    test_count = int(direct["total"])
                    failed_cases = list(dict.fromkeys([
                        *(direct.get("failed_cases") or []),
                        *_test_failure_cases_from_result(direct),
                    ]))
                    stdout = direct.get("output") or stdout
                    logger.info(
                        f"[Phase4] Direct execution fallback parsed {test_count} "
                        f"test(s), {len(failed_cases)} failed case(s)"
                    )
            return stdout, test_count, failed_cases
        except Exception as e:
            logger.warning(f"_run_compiled_tests failed: {e}")
            return "", 0, []

    async def _parse_coverage_from_output(
        self, test_output: str, source_files: list[str],
    ) -> float:
        return parse_coverage_from_output(test_output, source_files)

    def _parse_gcc_errors(self, stderr: str) -> list[CompileError]:
        return parse_gcc_errors(stderr)

    def _parse_test_results(self, stdout: str) -> tuple[int, list[str]]:
        return parse_test_results(stdout)

    # ========== LangGraph workflow delegation ==========

    def _build_workflow(self):
        """Build LangGraph workflow (for test compatibility)."""
        wf = UnitTestWorkflow(
            llm_bridge=self._llm, mcp_client=self._mcp,
            fetch_source_fn=self.fetch_source_from_repo,
            fix_compile_errors_fn=self.fix_compile_errors,
            max_llm_calls=8,
        )
        return wf.build()

    def _should_retry_compile(self, state: UnitTestState) -> str:
        """Compile retry condition check (for test compatibility)."""
        wf = UnitTestWorkflow(
            llm_bridge=self._llm, mcp_client=self._mcp,
            fetch_source_fn=self.fetch_source_from_repo,
            fix_compile_errors_fn=self.fix_compile_errors,
            max_llm_calls=8,
        )
        return wf.should_retry_compile(state)

    # ========== Private helper methods ==========

    def _get_skill_body_for_layer(self, layer: str, large_file_mode: bool = False) -> str:
        """Get skill body from SkillRegistry matching the current layer.

        Matches by naming convention: unittest-bsp, unittest-midware, etc.
        The generic gtest-generator skill is combined with the layer skill.
        The long-file reference is injected only for large sources; layer
        rulebooks remain excluded because their essential invariants already
        live in the layer skill body. Returns an empty string when no registry
        or matching skill is available.
        """
        if not self._skill_registry:
            return ""
        from app.skills.prompt_builder import SkillPromptBuilder
        skills = self._skill_registry.get_skills_for_agent(self.agent_type)
        layer_aliases = {
            "hal": ["unittest-bsp"],
            "driver": ["unittest-bsp"],
            "midware_controller": ["unittest-midware"],
            "midware_driver": ["unittest-midware"],
            "app": ["unittest-app"],
            "common": ["unittest-common"],
        }
        candidate_names = layer_aliases.get(layer, [f"unittest-{layer}"])

        selected = next((skill for skill in skills if skill.name in candidate_names), None)
        generic = next((skill for skill in skills if skill.name == "gtest-generator"), None)
        if selected or generic:
            builder = SkillPromptBuilder()
            prompts: list[str] = []

            def build_skill_prompt(skill, **options):
                import inspect

                parameters = inspect.signature(builder.build_skill_body_prompt).parameters
                supported = {key: value for key, value in options.items() if key in parameters}
                return builder.build_skill_body_prompt(skill, **supported)

            if generic:
                logger.info("[Skill] Selected generic skill 'gtest-generator'")
                generic_references = (
                    generic.get_reference_files_for_layer(layer)
                    if large_file_mode
                    else []
                )
                prompts.append(build_skill_prompt(
                    generic,
                    layer=layer,
                    reference_mode="inline",
                    reference_files=generic_references,
                ))
            if selected and selected is not generic:
                logger.info(
                    f"[Skill] Selected skill '{selected.name}' for layer '{layer}'"
                )
                prompts.append(build_skill_prompt(
                    selected,
                    layer=layer,
                    reference_mode="omit",
                    reference_files=[],
                ))
            return "\n\n".join(prompts)
        logger.info(f"[Skill] No matched skill for layer '{layer}'")
        return ""

    def _get_skill_names_for_layer(self, layer: str) -> list[str]:
        """Return the concrete skills applied to a layer for result telemetry."""
        if not self._skill_registry:
            return []
        skills = self._skill_registry.get_skills_for_agent(self.agent_type)
        layer_aliases = {
            "hal": ["unittest-bsp"],
            "driver": ["unittest-bsp"],
            "midware_controller": ["unittest-midware"],
            "midware_driver": ["unittest-midware"],
            "app": ["unittest-app"],
            "common": ["unittest-common"],
        }
        selected_names = layer_aliases.get(layer, [f"unittest-{layer}"])
        names = []
        if any(skill.name == "gtest-generator" for skill in skills):
            names.append("gtest-generator")
        names.extend(skill.name for skill in skills if skill.name in selected_names)
        return list(dict.fromkeys(names))

    def _build_coverage_plan(
        self, source_content: str, coverage_data: dict[str, Any], max_functions: int = 80,
    ) -> list[dict[str, Any]]:
        """Map gcov gaps to source functions and prescribe behavior cases.

        gcov reports line numbers and function names independently. This small
        mapping gives the CLI an actionable plan while keeping prompts bounded.
        """
        uncovered_lines = sorted({int(line) for line in coverage_data.get("uncovered_lines", []) if str(line).isdigit()})
        uncovered_names = [str(name) for name in coverage_data.get("uncovered_functions", []) if name]
        functions = parse_functions_regex(source_content or "")[:max_functions]
        function_lines = [(str(item.get("name") or "unknown"), int(item.get("line") or 0)) for item in functions]
        names = list(dict.fromkeys(uncovered_names))
        plan: dict[str, dict[str, Any]] = {
            name: {"function": name, "uncovered_lines": [], "branch_cases": []}
            for name in names
        }
        for line in uncovered_lines:
            owner = "__file_scope__"
            owner_line = -1
            for name, start_line in function_lines:
                if start_line <= line and start_line >= owner_line:
                    owner, owner_line = name, start_line
            plan.setdefault(owner, {"function": owner, "uncovered_lines": [], "branch_cases": []})
            plan[owner]["uncovered_lines"].append(line)

        branch_total = int(coverage_data.get("branches_total") or 0)
        branch_executed = int(coverage_data.get("branches_executed") or 0)
        branch_gap = max(0, branch_total - branch_executed)
        if branch_gap:
            branch_cases = ["taken", "not-taken", "boundary/error"]
            for item in plan.values():
                item["branch_cases"] = branch_cases[: max(2, min(3, branch_gap))]
        return list(plan.values())[:max_functions]

    def _analyze_with_libclang(
        self, file_path: str, content: str, ctx: "UnitTestContext",
    ) -> dict[str, str]:
        """Run LibClang analysis, return guidance text for prompt injection.

        Returns:
            {'mock_guidance': str, 'naming_guidance': str}
            Empty dictionary when libclang is unavailable or analysis fails.
        """
        result: dict[str, str] = {'mock_guidance': '', 'naming_guidance': ''}

        if not LibClangAnalyzer.is_available():
            return result

        try:
            import re as _re
            hal_headers = _re.findall(
                r'#include\s+[<"]([^>"]*hal[^>"]*\.h)[>"]', content,
            )
            if not hal_headers or not ctx.output_dir:
                return result

            header_path = self._resolve_header_path(
                hal_headers[0], ctx.output_dir, ctx.platform,
            )
            if not header_path:
                return result

            include_paths = self._get_include_paths(ctx.output_dir, ctx.platform)
            hal_symbols = LibClangAnalyzer.analyze_symbols_in_header(
                header_path, include_paths=include_paths,
            )
            if not hal_symbols:
                return result

            mock_candidates = LibClangAnalyzer.identify_mock_candidates(
                file_path, hal_symbols, include_paths=include_paths,
            )
            result['mock_guidance'] = LibClangAnalyzer.generate_mock_guidance(
                mock_candidates, hal_symbols,
            )

            module_name = os.path.splitext(os.path.basename(file_path))[0]
            if ctx.layer == "app":
                for prefix in ("app-", "app_"):
                    if module_name.startswith(prefix):
                        module_name = module_name[len(prefix):]
                        break
            else:
                for prefix in ('hal-', 'driver-', 'ctrl-', 'app-'):
                    if module_name.startswith(prefix):
                        module_name = module_name[len(prefix):]
                        break

            existing_mocks = LibClangAnalyzer.scan_project_mock_objects(
                ctx.output_dir, ctx.platform,
            )
            result['naming_guidance'] = LibClangAnalyzer.generate_mock_naming_guidance(
                existing_mocks, module_name,
            )
        except Exception as e:
            logger.debug(f"LibClang analysis skipped for {file_path}: {e}")

        return result

    def _resolve_header_path(
        self, header_name: str, project_root: str, platform: str,
    ) -> Optional[str]:
        """Resolve HAL header filename to absolute path in project."""
        from pathlib import Path
        search_dirs = [
            Path(project_root) / "libs" / "platformkit" / "bsp" / "hal" / platform / "inc",
            Path(project_root) / "libs" / "platformkit" / "bsp" / "hal" / "inc",
            Path(project_root) / "bsp" / "hal" / platform / "inc",
            Path(project_root) / "bsp" / "hal" / "inc",
        ]
        for d in search_dirs:
            candidate = d / header_name
            if candidate.exists():
                return str(candidate)
        return None

    def _get_include_paths(self, project_root: str, platform: str) -> list[str]:
        """Return list of include paths required for libclang parsing."""
        from pathlib import Path
        root = Path(project_root)
        candidates = [
            root / "libs" / "platformkit" / "bsp" / "hal" / platform / "inc",
            root / "libs" / "platformkit" / "bsp" / "hal" / "inc",
            root / "libs" / "platformkit" / "tests" / "mocks" / platform / "platform-mocks" / "inc",
        ]
        return [str(p) for p in candidates if p.exists()]

    async def _generate_test_for_file(
        self, file_path: str, content: str, ctx: "UnitTestContext",
        function_name: Optional[str] = None,
        compile_errors: Optional[list[dict]] = None,
        header_content: str = "",
        dependent_headers: str = "",
        vendor_api_ref: str = "",
        existing_mock_ref: str = "",
        mock_dependency_guidance: str = "",
    ) -> GeneratedTest:
        """Generate test .cpp and .h for single file (or function), inject layer rules, skill, clang, context."""
        scope = f"function `{function_name}`" if function_name else "all functions"
        # LibClang analysis
        clang_info = self._analyze_with_libclang(file_path, content, ctx)
        clang_guidance = (
            clang_info.get('mock_guidance', '')
            + clang_info.get('naming_guidance', '')
        )

        # Get real source path for accurate platform detection
        _real_src = (
            ctx.source_path_map.get(file_path)
            or ctx.source_path_map.get(os.path.basename(file_path))
            or (file_path if os.path.isabs(file_path) else None)
        )

        # Get target filenames
        file_paths = generate_file_paths(
            os.path.basename(file_path), ctx.layer, ctx.output_dir, ctx.platform,
            source_path=_real_src,
            source_content=content,
        )
        test_filename = file_paths.get("test_file", "")
        test_header_filename = file_paths.get("test_header", "")
        prompt_content, large_file_context, _ = self._prepare_large_source_context(
            file_path=file_path,
            content=content,
            ctx=ctx,
            function_name=function_name,
            generation_path="api",
            source_real_path=_real_src or "",
        )
        skill_prompt = await prepare_unittest_skills(
            self, ctx, "generate", file_paths=file_paths, source_path=_real_src or "",
            large_file_mode=bool(large_file_context),
        )
        if file_paths.get("test_access_impl_path"):
            mock_dependency_guidance = (
                f"{mock_dependency_guidance}\n"
                "The source defines file-scope static functions. If direct internal "
                "coverage is needed, return a test-only C access translation unit at "
                f"{file_paths['test_access_impl_path']}. Include the source with a "
                "controlled linkage adapter; the backend registers this file in the "
                "isolated QBS target and excludes the production source from that target."
            )

        prompt = build_generation_prompt(
            file_path=file_path, content=prompt_content, layer=ctx.layer,
            framework=ctx.framework, target_coverage=ctx.target_coverage,
            source_real_path=_real_src or "",
            scope=scope, compile_errors=compile_errors,
            skill_prompt=skill_prompt,
            test_filename=test_filename,
            test_header_filename=test_header_filename,
            clang_guidance=clang_guidance,
            header_content=header_content,
            dependent_hal_headers=dependent_headers,
            vendor_api_ref=vendor_api_ref,
            existing_mock_ref=existing_mock_ref,
            mock_dependency_guidance=mock_dependency_guidance,
            large_file_context=large_file_context,
        )
        if not ctx.enable_mock:
            prompt += "\nMock generation is disabled. Return only test artifacts without mock files or mock includes. Report unavailable dependencies.\n"
        response = await self._llm.generate(
            [{"role": "system", "content": SYSTEM_PROMPT},
             {"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=131072,
            **self._llm_call_options(),
        )

        # Use multi-strategy parser
        parsed = parse_and_split_test_output(response.content, ctx.framework)
        from .parsers import extract_named_code_blocks
        named_blocks = extract_named_code_blocks(response.content)
        test_access_content = next(
            (
                code
                for name, code in named_blocks.items()
                if name.replace("\\", "/").lower().endswith("_test_access.c")
            ),
            "",
        )
        test_impl = parsed.get("test_impl", "")
        test_header = parsed.get("test_header", "")

        # Fallback to named code blocks if multi-strategy parser didn't find test_impl
        if not test_impl:
            for name, code in named_blocks.items():
                if name == test_filename or (name.endswith('.cpp') and not test_impl):
                    test_impl = code
                elif name == test_header_filename or (name.endswith('.h') and not test_header):
                    test_header = code
            if not test_impl:
                test_impl = named_blocks.get("_default") or self._extract_code_block(response.content) or ""
            if not test_impl.strip():
                raise ValueError("No unit test implementation was generated; the model returned no test source")

        # Apply deterministic fixes
        parsed_content = {
            "test_impl": test_impl,
            "test_header": test_header or "",
            "mock_impl": parsed.get("mock_impl", ""),
            "mock_header": parsed.get("mock_header", ""),
        }
        parsed_content = fix_cpp_syntax_errors(parsed_content)
        if ctx.enable_mock:
            parsed_content = fix_mock_header_includes(parsed_content, file_paths)
        else:
            parsed_content["mock_impl"] = parsed_content["mock_header"] = ""
        parsed_content = trim_generated_code_structure(parsed_content)

        test_file = file_path.replace(".c", "_test.cpp").replace(".h", "_test.cpp")
        return GeneratedTest(
            source_file=file_path, test_file=test_file,
            test_content=parsed_content["test_impl"],
            test_header_content=parsed_content["test_header"] or None,
            mock_content=parsed_content["mock_impl"] or None,
            mock_header_content=parsed_content["mock_header"] or None,
            stub_content=test_access_content or None,
            coverage=0.0,  # Real coverage collected via gcov after test execution
        )

    async def _generate_mock_for_file(
        self, file_path: str, content: str, ctx: "UnitTestContext",
    ) -> tuple[Optional[str], Optional[str]]:
        """Generate mock .cpp and .h for single file.

        Returns:
            (mock_impl, mock_header) — either may be None.
        """
        import re
        external_calls = self._parse_calls_regex(content)
        related_headers = re.findall(r'#include\s+"([^"]+\.h)"', content)
        if not external_calls:
            return None, None

        # LibClang analysis
        clang_info = self._analyze_with_libclang(file_path, content, ctx)
        clang_guidance = (
            clang_info.get('mock_guidance', '')
            + clang_info.get('naming_guidance', '')
        )

        # Get real source path for accurate platform detection
        _real_src = (
            ctx.source_path_map.get(file_path)
            or ctx.source_path_map.get(os.path.basename(file_path))
            or (file_path if os.path.isabs(file_path) else None)
        )

        # Get target filenames
        file_paths = generate_file_paths(
            os.path.basename(file_path), ctx.layer, ctx.output_dir, ctx.platform,
            source_path=_real_src,
        )
        mock_filename = file_paths.get("mock_file", "")
        mock_header_filename = file_paths.get("mock_header", "")

        mock_framework = "cmock" if ctx.layer in ("hal", "driver") else "fff"
        skill_prompt = await prepare_unittest_skills(
            self, ctx, "mock", file_paths=file_paths, source_path=_real_src or "",
            large_file_mode=len(content or "") >= self._LARGE_SOURCE_CONTEXT_THRESHOLD,
        )
        prompt = build_mock_prompt(
            external_calls, mock_framework, related_headers,
            skill_prompt=skill_prompt,
            mock_filename=mock_filename,
            mock_header_filename=mock_header_filename,
            clang_guidance=clang_guidance,
        )
        try:
            response = await self._llm.generate(
                [{"role": "system", "content": SYSTEM_PROMPT},
                 {"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=131072,
                **self._llm_call_options(),
            )

            from .parsers import extract_named_code_blocks
            blocks = extract_named_code_blocks(response.content)

            mock_impl = None
            mock_header = None
            for name, code in blocks.items():
                if name == mock_filename or (name.endswith('.cpp') and mock_impl is None):
                    mock_impl = code
                elif name == mock_header_filename or (name.endswith('.h') and mock_header is None):
                    mock_header = code

            if mock_impl is None:
                mock_impl = blocks.get("_default") or self._extract_code_block(response.content) or response.content

            return mock_impl, mock_header
        except Exception as e:
            logger.warning(f"_generate_mock_for_file failed for {file_path}: {e}")
            return None, None

    def _extract_code_block(self, text: str) -> Optional[str]:
        return extract_code_block(text)

    def _infer_layer_from_paths(self, source_files: list[str], functions: list[dict]) -> str:
        return infer_layer_from_paths(source_files, functions)

    def _parse_functions_regex(self, content: str) -> list[dict]:
        return parse_functions_regex(content)

    def _parse_calls_regex(self, content: str) -> list[str]:
        return parse_calls_regex(content)
