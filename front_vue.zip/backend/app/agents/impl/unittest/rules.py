"""
@file _unittest_rules.py
@author caoshwen
@brief Embedded unit test rules (internal module).

CODE_STYLE_RULES + LAYER_TESTING_RULES (hal/driver/midware/controller/app).
Migrated from original unittest_agent, provides layer rules for zero-config test generation.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""

# Applied to all code generation (test & production code)
CODE_STYLE_RULES = """## Code Style Guidelines (Embedded & Streamlined)

### File Header (MUST appear before #include)
```cpp
/**
 * @file <filename>
 * @author <author>
 * @brief <single sentence with period>
 *
 * @version 0.1
 * @date YYYY-MM-DD
 *
 * @copyright Copyright (c) 2025 relivercao@gmail.com
 * All rights reserved.
 *
 */
```

### Include Order (CRITICAL - After file header)
For test files, follow this order:
1. **Self header** (for .cpp: corresponding .h file)
2. **Google Test/Mock headers**: `<gtest/gtest.h>`, `<gmock/gmock.h>`
3. **Mock headers**: `"mock-stm32-hal-<module>.h"`
4. **Project headers** (in extern "C" block): `"hal-<module>.h"`
5. **C/C++ standard library**: `<stdint.h>`, `<stdbool.h>`

Example for test file:
```cpp
#include "tc-hal-gpio.h"          /** Self header */
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "mock-stm32-hal-gpio.h"  /** Mock header */

extern "C" {
#include "hal-gpio.h"             /** HAL header */
#include "hal-err.h"
}
```

### Naming Conventions (Critical)
- **Types**: snake_lower with `_t` suffix (e.g., `gpio_instance_t`, `charger_info_t`)
- **Global functions (C)**: `layer_component_action` (e.g., `hal_gpio_initialize`, `driver_charger_get_faults`)
- **Static functions**: Module abbreviation prefix (e.g., `gpio_cfg_apply`)
- **Macros/Constants**: UPPER_SNAKE (e.g., `BQ2562X_VBUS_TYPE_DCP`, `MAX_TASKS`)
- **Local variables**: short snake_lower (e.g., `idx`, `count`, `temp_val`)
- **Enums**: Domain prefix + value (e.g., `hal_err_none`, `hal_err_failed`)
- **Files**: `layer-module[-sub].c|h` (e.g., `hal-gpio.c`, `driver-charger.c`)

### Formatting Rules
- **Indent**: 4 spaces (no tabs)
- **Line length**: Soft limit 120 chars; break before operator
- **Braces**: K&R style, opening brace same line: `void f(void) {`
- **Spacing**: One space after keyword, no space before `(` in calls: `if (x)` / `func(x)`
- **No trailing spaces, no multiple blank lines**
- **Ternary**: Only for trivial single-line: `mode = flag ? 1 : 0;`

### Comments & Documentation
- **Doxygen blocks for API**: `/** @brief ... */`
- **@brief**: Single sentence ending with period, blank line after
- **File header**: Blank line after copyright / "All rights reserved."
- **No `//` comments, no commented-out code**
- **Allowed**: Rationale for constraints, hardware errata with `@note`

### Error Handling
- Return explicit domain error enum (`hal_err_*`, `drv_err_*`) or `bool`
- **Never return raw HAL vendor codes above HAL layer**
- **Validate all input pointers** (null check first)
- Validate numeric ranges before hardware write
- Propagate first failure; no silent fall-through

### Functions & Structure
- Prefer < 80 LOC; refactor if > 120 LOC or > 3 nested levels
- Early returns encouraged to reduce nesting
- Use `static` for internal linkage; declare before first use
- **Avoid recursion, dynamic allocation in embedded layers**
- Use fixed-width types: `uint8_t`, `int32_t`
- Replace magic numbers with macro or enum constant

### Concurrency & Interrupts
- ISRs: minimal logic, set flags, enqueue events, **never block**
- Protect shared state with atomic or critical section macros
- **No dynamic allocation in ISR**
- ISR names follow vendor signature, remain `extern "C"` if C++

### Register / Bit Manipulation
- Always use macros: `SET_BIT`, `CLEAR_BIT`, `READ_BIT`, `WRITE_REG`
- Never hardcode bit shifts if macro/enum exists
- Document concurrency assumptions for read-modify-write

### Dependency Rules
- **HAL**: May use CMSIS/Vendor, MUST NOT depend on Driver/Controller
- **Driver**: May use HAL, MUST NOT depend on Controller/App
- **Controller**: May use Driver/Midware, MUST NOT access HAL directly
- **Midware**: May use HAL/Drivers, MUST NOT depend on App UI

### Forbidden Patterns
- Trailing `//` comments, commented-out blocks
- Implicit switch fall-through (unless `/* fallthrough */`)
- Global mutable state without prefix/accessor
- Mixing tabs and spaces
- Shadowing outer scope variables
"""

# Layer-specific testing rules (refined from rulebooks)
# These rules are embedded to provide zero-config test generation
LAYER_TESTING_RULES: dict[str, str] = {
    "hal": """## HAL Layer Testing Rules (Critical Guidelines)

### File Naming Convention (MUST FOLLOW)
- Test implementation: `tc-hal-<module>.cpp` (e.g., tc-hal-pwr.cpp, tc-hal-gpio.cpp)
- Test header: `tc-hal-<module>.h`
- Mock header: `mock-<platform>-hal-<module>.h` (CRITICAL: Use platform prefix)
  - STM32: `mock-stm32-hal-<module>.h` (stm32u3, stm32u5)
  - Realtek: `mock-rtl-hal-<module>.h` (rtl8722fam)
  - Nordic: `mock-nrf-hal-<module>.h` (nrf52, nrf53)
- Mock implementation: `mock-<platform>-hal-<module>.cpp`

### CRITICAL: Avoid Multiple Definition Linker Errors
**NEVER define the same HAL function in multiple mock files!**
Each HAL function should be mocked in EXACTLY ONE file based on its module ownership:

| Function Pattern | Belongs To | Mock File |
|-----------------|-----------|-----------|
| `HAL_NVIC_*` | Cortex/NVIC | `mock-stm32-hal-cortex.cpp` |
| `HAL_EXTI_*` | EXTI | `mock-stm32-hal-exti.cpp` |
| `HAL_GPIO_*` | GPIO | `mock-stm32-hal-gpio.cpp` |
| `HAL_PWR_*` | PWR | `mock-stm32-hal-pwr.cpp` |
| `HAL_RCC_*` | RCC | `mock-stm32-hal-rcc.cpp` |
| `HAL_UART_*` | UART | `mock-stm32-hal-uart.cpp` |
| `HAL_I2C_*` | I2C | `mock-stm32-hal-i2c.cpp` |
| `HAL_SPI_*` | SPI | `mock-stm32-hal-spi.cpp` |
| `HAL_TIM_*` | TIM | `mock-stm32-hal-tim.cpp` |
| `HAL_ADC_*` | ADC | `mock-stm32-hal-adc.cpp` |

### CRITICAL: Mock Scope — Mock Only DEPENDENCIES, Never the Module Under Test
The real module source (e.g. `hal-key.c`) is ALWAYS compiled into the test
binary as the coverage target. The mock files for a module
(`mock-<platform>-hal-<module>.h/.cpp`) must contain MOCK implementations ONLY
for functions the module CALLS but does NOT define — its external
dependencies: vendor HAL APIs (`HAL_*`) and sibling module APIs
(`hal_<dep>_*`, e.g. `hal_gpio_*` for a key module that calls GPIO).
- NEVER define the module under test's own API (`hal_<module>_*`) in its mock
  files — the real implementation is linked in, and a mock definition collides
  with it (`multiple definition of 'hal_<module>_*'` at link time).
- Functions declared in headers but not defined in the provided sources are
  NOT testable: do not call them from tests and do not invent definitions.
- A mock class models ONE dependency, never the module under test: a key
  module that calls `hal_gpio_*` gets `MockStm32HalGpio` (its MOCK_METHODs
  mirror the `hal_gpio_*` functions), and the mock .cpp defines those C
  functions forwarding to the global instance. There is NO mock class for the
  key module itself — tests call `hal_key_init()`/`hal_key_read()` directly.
- The global mock instance declared `extern` in a mock header MUST be defined
  in that same mock module's .cpp; an extern that no .cpp defines is a link
  error, and a mock variable name that follows no convention (e.g.
  `hal_key_gpio_mock`) is a hallucination — use `<platform>_<dep>_mock`.
- Self-check before finishing: (1) every EXPECT_CALL method name is a
  MOCK_METHOD in the included mock header; (2) every macro/constant used
  (e.g. `HAL_GPIO_LEVEL_HIGH`) exists verbatim in the provided headers —
  check spelling character by character; (3) every extern mock variable is
  defined in exactly one mock .cpp.

### CRITICAL: Macros vs Functions (DO NOT MOCK MACROS!)
**NEVER use MOCK_METHOD for HAL macros!**
- `__HAL_*` (double underscore prefix) = MACRO -> DO NOT MOCK
- `HAL_*` (single prefix with return type) = FUNCTION -> OK to mock

### Mock Object Naming (CRITICAL)
- Use GLOBAL VARIABLE pattern (NOT pointer):
  ```cpp
  extern Mock<Platform>Hal<Module> <platform>_<module>_mock;
  ```
- Platform-specific examples:
  - STM32: `extern MockStm32HalPwr stm32_pwr_mock;`
  - Realtek: `extern MockRtlHalGpio rtl_gpio_mock;`
  - Nordic: `extern MockNrfHalUart nrf_uart_mock;`

### Test Structure Requirements
- Use Google Test framework with TEST_F macro
- Test fixture class: Inherits from `::testing::Test`
- SetUp: Initialize mocks, call `testing::Mock::VerifyAndClearExpectations(&mock)` at end
- TearDown: Clean up resources, reset mock states
- Each test case: Follow AAA pattern (Arrange, Act, Assert)

### CRITICAL: Never Leak Mock Objects (Coverage Killer)
A mock object still alive at process exit makes gmock print
`ERROR: N leaked mock object(s) found at program exit` — and that failure
path SKIPS gcov's exit dump, so NO .gcda coverage files are written and
measured coverage silently becomes 0%. Rules:
- Create mocks as fixture members or stack objects in SetUp; never `new` a
  mock without a matching `delete` in TearDown
- A test that creates or uses a mock must let it be destroyed before the
  test ends (do not store mocks in static/global pointers mid-test)
- If a global mock must outlive tests intentionally, call
  `testing::Mock::AllowLeak(&mock)` in SetUp — but prefer destruction

### STM32U3 Hardware Constraints (CRITICAL!)
- **GPIO Ports**: Only GPIOA-GPIOE. DO NOT use GPIOF, GPIOG, GPIOH!
- **UART**: USART1-3, UART4-5, LPUART1. No UART6-8.
- **SPI**: SPI1-3 only. No SPI4-6.
- **I2C**: I2C1-4 only. No I2C5-6.

### HAL Error Codes (Use ONLY these!)
```c
hal_err_none = 0, hal_err_failed = -1, hal_err_invalid_pointer = -2,
hal_err_invalid_argument = -3, hal_err_not_initialized = -4,
hal_err_timeout = -5, hal_err_malloced_failed = -6,
hal_err_busy = -7, hal_err_not_supported = -8
```

### Test Coverage Goals
- Line coverage: >= 90%, Branch coverage: >= 75%
- Test normal operation, error handling, NULL pointers, boundary conditions

### Layer Dependencies (NEVER VIOLATE!)
- HAL -> Vendor SDK only (STM32 HAL, CMSIS)
- Tests MUST call through public interface (function pointer structs like `hal_gpio.*`)

### Critical Test Rules
- Initialize ALL struct members (NEVER leave uninitialized)
- Set mock expectations for ALL external calls
- Use `/** ... */` comments ONLY, NEVER use `//` comments
- NEVER modify source files under test
- NEVER mock macros starting with `__HAL_*`
- extern "C" declarations MUST be at FILE TOP, NEVER inside TEST_F body
""",

    "driver": """## Driver Layer Testing Rules (Critical Guidelines)

### File Naming Convention (MUST FOLLOW)
- Test implementation: `tc-driver-<module>.cpp` (e.g., tc-driver-uart.cpp)
- Test header: `tc-driver-<module>.h`
- Mock header: `mock-hal-<module>.h` (CRITICAL: Use 'hal' prefix, NOT 'stm32-hal')
- Mock implementation: `mock-hal-<module>.cpp`

### Mock Object Naming (CRITICAL)
- Use POINTER pattern with new/delete:
  ```cpp
  class DriverTest : public ::testing::Test {
  protected:
      void SetUp() override { mock_hal_<module> = new MockHal<Module>(); }
      void TearDown() override { delete mock_hal_<module>; mock_hal_<module> = nullptr; }
      MockHal<Module>* mock_hal_<module>;
  };
  ```

### Test Structure Requirements
- Use Google Test framework with TEST_F macro
- Mock dependencies: HAL layer functions only
- Test driver API: initialization, configuration, data transfer, error handling
- Include stress testing: repeated calls, resource exhaustion scenarios

### Test Coverage Goals
- Line coverage: >= 80%, Branch coverage: >= 70%
- Focus on driver state transitions, concurrent access, edge cases

### Driver Layer Dependency Rules (CRITICAL!)
- Drivers depend on HAL only (NEVER call vendor SDK directly)
- Drivers MUST NOT depend on Controller or Application layer
- Use `/** ... */` comments ONLY, NEVER use `//` comments
- NEVER modify driver source files
""",

    "midware": """## Middleware Layer Testing Rules (Critical Guidelines)

### File Naming Convention (MUST FOLLOW)
- Controller: `tc-controller-<module>.cpp` or `tc-ctrl-<module>.cpp`
- Service: `tc-service-<module>.cpp` or `tc-svc-<module>.cpp`
- Protocol: `tc-protocol-<module>.cpp` or `tc-proto-<module>.cpp`
- Manager: `tc-manager-<module>.cpp` or `tc-mgr-<module>.cpp`

### Mock Object Naming (CRITICAL)
- Use pointer pattern with new/delete like driver layer
- Special logging mock: `g_mock_<component>_log` (global variable)
- Mock dependencies from lower layers (driver/HAL) and peer components

### Component-Specific Testing Focus
- **Controller**: Business logic, state transitions, command validation, error recovery
- **Service**: API contracts, thread safety, resource limits, graceful degradation
- **Protocol**: Packet parsing, CRC validation, sequence numbers, retransmission logic
- **Manager**: Initialization order, dependency injection, lifecycle events, cleanup

### Common Midware Patterns to Test
- State Machines: all transitions, invalid transitions, edge cases
- Message Queues: queue full, empty, overflow, underflow
- Callbacks: registration, invocation, parameter passing, error callbacks
- Timers/Timeouts: time advancement, timeout expiry, timer cancellation

### Test Coverage Goals
- Line coverage: >= 75%, Branch coverage: >= 65%
- Focus on business logic, state transitions, error recovery, callback handling

### Dependency Rules (CRITICAL!)
- Controllers depend on Midware/BSP Drivers (NEVER call HAL directly)
- Use `/** ... */` comments ONLY, NEVER use `//` comments
- NEVER modify controller source files
""",

    "midware_controller": """## Midware Controller Layer Testing Rules (Critical Guidelines)

### File Naming Convention (MUST FOLLOW)
- Test implementation: `tc-controller-<module>.cpp`
- Test header: `tc-controller-<module>.h`
- Mock implementation: `mock-driver-<module>.cpp`
- Mock header: `mock-driver-<module>.h`

### Mock Object Naming (CRITICAL)
- Use GLOBAL OBJECT mock pattern for controller dependency mocks
- Mock lower-level driver interfaces used by the controller under test
- Special logging mock may use `g_mock_<component>_log` when required by the module

### Test Structure Requirements
- Use Google Test framework with TEST_F macro
- Call only public controller functions declared in the header under test
- `*_IRQHandler()` functions may be declared and invoked directly when required by module behavior
- For modules that require initialization, call `initialize()` before testing initialized-state interfaces, except when explicitly testing pre-initialization behavior

### Test Coverage Goals
- Line coverage: >= 75%, Branch coverage: >= 65%
- Focus on business logic, state transitions, command validation, error recovery, and callback handling

### Dependency Rules (CRITICAL!)
- Controllers depend on Midware/BSP Drivers (NEVER call HAL directly)
- Use `/** ... */` comments ONLY, NEVER use `//` comments
- NEVER modify controller source files or production headers under test
- Generated files must stay under `tests/unit/midware/controllers/` and `tests/mocks/midware/controllers/`
""",

    "midware_driver": """## Midware Driver Layer Testing Rules (Critical Guidelines)

### File Naming Convention (MUST FOLLOW)
- Test implementation: `tc-driver-<module>.cpp`
- Test header: `tc-driver-<module>.h`
- Mock implementation: `mock-driver-<module>-type0.cpp`
- Mock header: `mock-driver-<module>-type0.h`

### Mock Object Naming (CRITICAL)
- Mock only the lower-level dependency interfaces used by the midware driver under test
- Do NOT mock the public APIs exported by the source file under test itself
- Use the exact backend-provided generated filenames and paths when they differ for a specific module

### Test Structure Requirements
- Use Google Test framework with TEST_F macro
- Call only public driver functions declared in the header under test
- `*_IRQHandler()` functions may be declared and invoked directly when required by module behavior
- For modules that require initialization, call `initialize()` before testing initialized-state interfaces, except when explicitly testing pre-initialization behavior

### Test Coverage Goals
- Line coverage: >= 80%, Branch coverage: >= 70%
- Focus on initialization paths, configuration behavior, error propagation, repeated calls, and boundary conditions

### Dependency Rules (CRITICAL!)
- Drivers depend on HAL/low-level interfaces only; do NOT depend on controller or application layers
- Use `/** ... */` comments ONLY, NEVER use `//` comments
- NEVER modify driver source files or production headers under test
- Generated files must stay under `tests/unit/midware/drivers/` and `tests/mocks/midware/drivers/`
""",

    "controller": """## Controller Layer Testing Rules (Alias for Midware Controller Layer)

Note: Controller is part of the Midware layer. Use `tc-controller-<module>.cpp` naming.
Refer to Midware Controller layer rules for complete guidelines.

### Quick Reference for Controller Components
- Test naming: `tc-controller-<module>.cpp`
- Mock dependencies: `mock-driver-<module>.h`
- Mock pattern: global object mock style
- Special mock: `g_mock_controller_log` (global variable) when required by the module
- Coverage target: >= 75% line, >= 65% branch
""",

    "app": """## Application Layer Testing Rules (Critical Guidelines)

### File Naming Convention (MUST FOLLOW)
- Test implementation: `tc-app-<module>.cpp` or `tc-<module>-test.cpp`
- Test header: `tc-app-<module>.h`
- Mock headers: Multiple mocks for controllers, drivers, middleware services

### Mock Object Naming
- Use pointer pattern with new/delete
- Mock all lower layers: controllers, services, middleware components

### Test Structure Requirements
- Use Google Test framework with TEST_F macro
- Test application features: user interactions, business workflows, data processing
- Mock ALL external dependencies: controllers, middleware, OS services
- Include scenario-based tests: complete user workflows, error recovery flows
- Test concurrency: multi-threading, task synchronization, message passing

### Test Coverage Goals
- Line coverage: >= 70%, Branch coverage: >= 60%
- Focus on feature completeness, user scenarios, error handling, integration points
""",
}


def get_layer_rules(layer: str) -> str:
    """Get testing rules text for specified layer."""
    if layer in LAYER_TESTING_RULES:
        return LAYER_TESTING_RULES[layer]
    if layer.startswith("midware_"):
        return LAYER_TESTING_RULES.get("midware", "")
    return ""


def get_code_style_rules() -> str:
    """Get code style rules text."""
    return CODE_STYLE_RULES
