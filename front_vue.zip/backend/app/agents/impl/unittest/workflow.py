"""
@file _unittest_workflow.py
@author caoshwen
@brief UnitTestAgent LangGraph 17-node workflow (internal module).

fetch_source -> analyze_ast -> detect_layer -> check_external_mocks ->
select_framework -> generate_test -> generate_mock -> parse_output ->
  parse_output ──[complete]──→ save_files -> update_qbs_config -> compile_test
  parse_output ──[incomplete]──→ generate_test (retry, max 3)
  compile_test ──[success]──→ run_test
  compile_test ──[retry]──→ handle_errors -> compile_test
  compile_test ──[max_retry]──→ finalize
  run_test ──[success]──→ collect_coverage
  run_test ──[retry]──→ generate_test (test failure retry, max 3)
  collect_coverage ──[done]──→ finalize
  collect_coverage ──[improve]──→ generate_test (coverage improvement)
  finalize -> END

@version 3.3
@date 2026-03-10

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import hashlib
import os
import re
from pathlib import Path
from typing import Any, Dict

from loguru import logger

from .types import (
    CompileError,
    GeneratedTest,
    SourceFile,
    UnitTestResult,
    UnitTestState,
)
from .parsers import (
    parse_gcc_errors,
    parse_qbs_build_errors,
    parse_qbs_warnings_structured,
    parse_test_results,
    parse_coverage_from_output,
    parse_branch_coverage_from_output,
    parse_function_coverage_from_output,
    extract_code_block,
    analyze_source_ast,
    infer_layer_from_paths,
    detect_truncation,
    validate_parsed_completeness,
)
from .prompts import (
    SYSTEM_PROMPT,
    build_system_prompt,
    build_generation_prompt,
    build_fix_prompt,
    build_mock_prompt,
    build_two_phase_prompt,
    build_coverage_improvement_prompt,
    build_test_failure_fix_prompt,
)
from .qbs import (
    resolve_qbs_build_context,
    resolve_qbs_project_path,
    resolve_qbs_file_path,
    validate_qbs_build_context,
    update_qbs_config,
)
from app.core.config import get_resolved_cli_path, resolve_agent_llm_selection
from .output_parser import parse_and_split_test_output
from .fixers import fix_cpp_syntax_errors, fix_mock_header_includes, apply_fixit_rules, trim_generated_code_structure
from .external_mocks import (
    analyze_source_external_hal_calls,
    analyze_source_midware_calls,
    find_missing_mock_files,
    create_external_mock_file,
    generate_mock_dependency_guidance,
)
from .paths import (
    generate_file_paths,
    filter_mock_paths,
    save_test_files_to_project,
    find_and_read_header_file,
    find_dependent_hal_headers,
    find_vendor_hal_api_definitions,
    find_existing_mock_files,
    find_project_root_for_source,
)

from app.agents.base import AgentStatus


class UnitTestWorkflow:
    """LangGraph 17-node workflow wrapper.

    Accepts llm_bridge / mcp_client / fetch_source_fn on construction,
    node methods access these dependencies via self.
    """

    def __init__(self, llm_bridge, mcp_client, fetch_source_fn, fix_compile_errors_fn,
                 progress_fn=None, max_retries: int = 3, max_llm_calls: int = 8):
        self._llm = llm_bridge
        self._mcp = mcp_client
        self._fetch_source_from_repo = fetch_source_fn
        self._fix_compile_errors = fix_compile_errors_fn
        self._progress_fn = progress_fn
        self._max_retries = max_retries
        self._max_llm_calls = max_llm_calls
        self._llm_call_count = 0
        self._llm_selection = resolve_agent_llm_selection("unittest")

    async def _report(self, progress: int, stage: str, message: str) -> None:
        """Report progress to Agent layer (if callback registered)."""
        if self._progress_fn:
            await self._progress_fn(progress, stage, message)

    async def _llm_generate(self, prompt, **kwargs):
        """LLM call with global call count protection. Throws exception to force loop termination on limit exceeded.

        Force use of claude_cli provider because test code generation requires large token output;
        max_tokens limits of APIs like Turing are insufficient to generate complete test files.
        """
        self._llm_call_count += 1
        if self._llm_call_count > self._max_llm_calls:
            raise RuntimeError(
                f"LLM call limit reached ({self._max_llm_calls}). "
                f"Workflow terminated to prevent infinite retry loops."
            )
        logger.info(f"LLM call #{self._llm_call_count}/{self._max_llm_calls}")
        kwargs.setdefault("provider", self._llm_selection.runtime_provider)
        kwargs.setdefault("model", self._llm_selection.model)
        kwargs.setdefault("upstream_provider", self._llm_selection.provider)
        kwargs.setdefault("max_tokens", 131072)
        # UnitTest generation is a durable background workflow. The bridge
        # must not abort an otherwise active CLI/LLM call because of a fixed
        # wall-clock budget. QBS and cancellation checks still control the
        # workflow explicitly.
        kwargs.setdefault("unbounded_runtime", True)
        return await self._llm.generate(prompt, **kwargs)

    def build(self):
        """Build UnitTest LangGraph workflow (17 nodes · v3.3)"""
        try:
            from langgraph.graph import StateGraph, START, END
        except ImportError:
            logger.warning("langgraph not installed; workflow unavailable")
            return None

        workflow = StateGraph(UnitTestState)

        # 17 nodes + autonomous_fix
        workflow.add_node("fetch_source",         self._node_fetch_source)
        workflow.add_node("analyze_ast",          self._node_analyze_ast)
        workflow.add_node("detect_layer",         self._node_detect_layer)
        workflow.add_node("check_external_mocks", self._node_check_external_mocks)
        workflow.add_node("select_framework",     self._node_select_framework)
        workflow.add_node("generate_test",        self._node_generate_test)
        workflow.add_node("generate_mock",        self._node_generate_mock)
        workflow.add_node("parse_output",         self._node_parse_output)
        workflow.add_node("save_files",           self._node_save_files)
        workflow.add_node("update_qbs_config",    self._node_update_qbs_config)
        workflow.add_node("compile_test",         self._node_compile_test)
        workflow.add_node("handle_errors",        self._node_handle_errors)
        workflow.add_node("autonomous_fix",       self._node_autonomous_fix)
        workflow.add_node("run_test",             self._node_run_test)
        workflow.add_node("collect_coverage",     self._node_collect_coverage)
        workflow.add_node("finalize",             self._node_finalize)

        # Linear edges
        workflow.add_edge(START,                  "fetch_source")
        workflow.add_edge("fetch_source",         "analyze_ast")
        workflow.add_edge("analyze_ast",          "detect_layer")
        workflow.add_edge("detect_layer",         "check_external_mocks")
        workflow.add_edge("check_external_mocks", "select_framework")
        workflow.add_edge("select_framework",     "generate_test")
        workflow.add_edge("generate_test",        "generate_mock")
        workflow.add_edge("generate_mock",        "parse_output")

        # parse_output → conditional: complete/incomplete/failed
        workflow.add_conditional_edges(
            "parse_output",
            self._should_retry_parse,
            {
                "complete":   "save_files",
                "incomplete": "generate_test",
                "failed":     "finalize",
            },
        )
        workflow.add_conditional_edges(
            "save_files",
            self._should_verify_build,
            {"verify": "update_qbs_config", "skip": "finalize"},
        )
        workflow.add_edge("update_qbs_config",    "compile_test")

        # compile_test → conditional: success/retry/autonomous_fix/max_retry
        workflow.add_conditional_edges(
            "compile_test",
            self.should_retry_compile,
            {
                "retry":          "handle_errors",
                "success":        "run_test",
                "autonomous_fix": "autonomous_fix",
                "max_retry":      "finalize",
            },
        )
        workflow.add_edge("handle_errors",        "compile_test")

        # autonomous_fix → conditional: verify/fallback/fail
        workflow.add_conditional_edges(
            "autonomous_fix",
            self._check_autonomous_fix_result,
            {
                "verify":   "compile_test",
                "fallback": "handle_errors",
                "fail":     "finalize",
            },
        )

        # run_test → conditional: success/retry/fail
        workflow.add_conditional_edges(
            "run_test",
            self._should_retry_test,
            {
                "success": "collect_coverage",
                "retry":   "generate_test",
                "fail":    "collect_coverage",
            },
        )

        # collect_coverage → conditional: done/improve
        workflow.add_conditional_edges(
            "collect_coverage",
            self._should_improve_coverage,
            {
                "done":    "finalize",
                "improve": "generate_test",
            },
        )
        workflow.add_edge("finalize",             END)

        return workflow.compile()

    def _can_attempt_autonomous_fix(self, state: UnitTestState) -> bool:
        """Return whether autonomous fix has enough deterministic context to run."""
        if state.get("compile_retryable") is False:
            return False
        compile_errors = state.get("compile_errors", [])
        if not compile_errors:
            return False
        source_files = state.get("source_files", [])
        if not source_files:
            return False
        output_dir = state.get("output_dir")
        project_root = state.get("project_root")
        return bool(output_dir or project_root)

    def should_retry_compile(self, state: UnitTestState) -> str:
        """3-level compile retry routing:
        1. success → done
        2. retry_count < 2 → LLM fix (handle_errors)
        3. autonomous_fix_count < 2 → Claude CLI autonomous fix
        4. all exhausted → give up
        Error regression (more errors than before) → skip to autonomous_fix.
        """
        if state.get("compile_success"):
            return "success"
        if state.get("compile_retryable") is False:
            return "max_retry"
        if state.get("compile_state_repeated"):
            logger.error(
                "[compile] Repeated compiler diagnostics with unchanged generated "
                "artifacts; skipping another repair call"
            )
            return "max_retry"

        retry_count = state.get("retry_count", 0)
        autonomous_fix_count = state.get("autonomous_fix_count", 0)

        # Error regression detection: if current errors > previous, escalate
        prev_error_count = state.get("prev_compile_error_count", 0)
        curr_error_count = len(state.get("compile_errors", []))
        error_regressed = (retry_count > 0 and prev_error_count > 0
                           and curr_error_count > prev_error_count)

        if not error_regressed and retry_count < 2:
            return "retry"
        if autonomous_fix_count < 2 and self._can_attempt_autonomous_fix(state):
            return "autonomous_fix"
        return "max_retry"

    def _should_retry_parse(self, state: UnitTestState) -> str:
        """Parse completeness condition check"""
        missing = state.get("missing_file_pattern", "complete")
        parse_retries = state.get("parse_retry_count", 0)
        if missing == "complete":
            return "complete"
        if parse_retries >= 1:
            logger.warning(f"Parse retry limit reached ({parse_retries}), proceeding with partial output")
            return "complete"
        return "incomplete"

    @staticmethod
    def _should_verify_build(state: UnitTestState) -> str:
        """Skip all build and coverage nodes when verification is disabled."""
        return "verify" if state.get("compile_verify", True) else "skip"

    def _should_retry_test(self, state: UnitTestState) -> str:
        """Test failure retry condition check"""
        if state.get("test_passed"):
            return "success"
        test_retries = state.get("test_retry_count", 0)
        failed_cases = state.get("failed_cases", [])
        if failed_cases and test_retries < 2:
            return "retry"
        return "fail"

    def _should_improve_coverage(self, state: UnitTestState) -> str:
        """Route coverage improvement while progress is possible.

        Coverage improvement is deliberately bounded by the configured
        iteration budget, not by wall-clock time.  A repeated coverage
        signature means the generated tests did not change the measured
        result, so the graph must finish instead of repeatedly invoking the
        CLI with the same context.
        """
        line_cov = state.get("line_coverage", 0.0)
        branch_cov = state.get("branch_coverage", 0.0)
        function_cov = state.get("function_coverage", 0.0)
        
        # Get target coverage from state (default to 90% line, 85% branch, 90% function if not set)
        target_line_cov = state.get("target_coverage", 90.0)
        target_branch_cov = state.get("target_branch_coverage", 85.0)
        target_function_cov = state.get("target_function_coverage", 90.0)
        
        # Only improve if at least one coverage type is below target and we have coverage data
        all_above_target = (
            (line_cov >= target_line_cov or line_cov == 0.0)
            and (branch_cov >= target_branch_cov or branch_cov == 0.0)
            and (function_cov >= target_function_cov or function_cov == 0.0)
        )
        
        if all_above_target:
            return "done"

        max_iterations = max(0, int(state.get("coverage_max_iterations", 5) or 0))
        attempted = int(state.get("coverage_improvement_count", 0) or 0)
        if attempted == 0 and state.get("coverage_improvement_attempted"):
            attempted = 1
        if attempted >= max_iterations:
            logger.info(
                "Coverage target not met after {} improvement attempt(s); finishing workflow",
                attempted,
            )
            return "done"

        # If gcov did not expose detailed targets, a previous test artifact is
        # still actionable: the prompt can ask the model to inspect the source
        # and measured coverage.  Only stop when there is no artifact to edit.
        if (
            not (state.get("uncovered_functions") or state.get("uncovered_lines"))
            and not (state.get("parsed_test_code") or state.get("generated_test_code"))
        ):
            return "done"

        if int(state.get("coverage_stagnant_count", 0) or 0) > 0:
            logger.info("Coverage signature repeated; finishing improvement loop")
            return "done"
        return "improve"

    async def _node_fetch_source(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ①: Fetch source file content, use pre-loaded content when available。"""
        await self._report(5, "fetch", "Fetching source files")
        source_files = state.get("source_files", [])
        repo = state.get("repo_slug", "firmware")
        branch = state.get("branch", "develop")

        source_content: dict[str, str] = dict(state.get("source_content", {}))
        source_path_map: dict[str, str] = dict(state.get("source_path_map", {}))
        project_root = state.get("project_root", ".")
        effective_project_root = project_root
        metadata = state.get("metadata", {})

        isolated_driver_output = bool(
            metadata.get("driver_task_id") and not state.get("compile_verify", True)
        )
        if isolated_driver_output:
            effective_project_root = metadata.get("driver_output_dir") or project_root

        absolute_source_path = next(
            (
                path for path in source_path_map.values()
                if path and os.path.isabs(path)
            ),
            None,
        )
        if absolute_source_path and not isolated_driver_output:
            inferred_root = find_project_root_for_source(absolute_source_path)
            if inferred_root:
                effective_project_root = inferred_root

        missing = [f for f in source_files if f not in source_content]
        if missing:
            fetched = await self._fetch_source_from_repo(repo, missing, branch)
            for f in fetched:
                source_content[f.path] = f.content

        related_headers: list[str] = []
        for content in source_content.values():
            for inc in re.findall(r'#include\s+"([^"]+\.h)"', content):
                related_headers.append(inc)

        try:
            tree_result = await self._mcp.call_tool("bb_get_tree", **{
                "repo": repo,
                "path": effective_project_root,
            })
            file_tree = tree_result.data if tree_result.success else {}
        except Exception as e:
            logger.warning(f"_fetch_source file tree failed: {e}")
            file_tree = {}

        return {
            "source_content": source_content,
            "file_tree": file_tree,
            "related_headers": list(set(related_headers)),
            "project_root": effective_project_root,
        }

    async def _node_analyze_ast(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ②: Parse source AST using libclang。"""
        await self._report(15, "ast", "Analyzing AST structure")
        source_content: dict[str, str] = state.get("source_content", {})
        all_functions: list[dict] = []
        all_dependencies: list[str] = []
        all_external_calls: list[str] = []

        for path, content in source_content.items():
            analysis = analyze_source_ast(path, content)
            all_functions.extend(analysis.functions)
            all_dependencies.extend(analysis.dependencies)
            all_external_calls.extend(analysis.external_calls)

        return {
            "ast_analysis": {
                "functions": all_functions,
                "dependencies": list(set(all_dependencies)),
                "external_calls": list(set(all_external_calls)),
            },
            "functions": all_functions,
            "dependencies": list(set(all_dependencies)),
            "external_calls": list(set(all_external_calls)),
        }

    async def _node_detect_layer(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ③: Detect architecture layer from AST analysis and path rules, collect context。"""
        await self._report(20, "layer", "Detecting architecture layer")
        source_files: list[str] = state.get("source_files", [])
        source_content: dict[str, str] = state.get("source_content", {})
        functions: list[dict] = state.get("functions", [])

        layer = infer_layer_from_paths(source_files, functions)
        layer_context = {
            "layer": layer,
            "mock_strategy": "cmock" if layer in ("hal", "driver") else "gmock",
            "test_prefix": f"{layer}_",
        }

        # Gather header content and dependent headers
        project_root = state.get("project_root", ".")
        platform = state.get("platform", "stm32u3")
        header_content = ""
        dependent_headers = ""
        vendor_api_ref = ""
        existing_mock_ref = ""

        for src_path in source_files:
            src_filename = os.path.basename(src_path)
            hdr = find_and_read_header_file(src_filename, project_root, layer)
            if hdr:
                header_content += hdr
                dep = find_dependent_hal_headers(hdr, project_root, layer)
                if dep:
                    dependent_headers += dep

            module_name = os.path.splitext(src_filename)[0]
            for prefix in (f"{layer}-", "hal-", "driver-"):
                if module_name.startswith(prefix):
                    module_name = module_name[len(prefix):]
                    break

            vapi = find_vendor_hal_api_definitions(project_root, layer, module_name, platform)
            if vapi:
                vendor_api_ref += vapi

            emock = find_existing_mock_files(project_root, platform, module_name)
            if emock:
                existing_mock_ref += emock

        return {
            "detected_layer": layer,
            "layer_context": layer_context,
            "header_content": header_content,
            "dependent_headers": dependent_headers,
            "vendor_api_ref": vendor_api_ref,
            "existing_mock_ref": existing_mock_ref,
        }

    async def _node_check_external_mocks(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ③b: Detect cross-module dependencies, create missing mock files. Supports HAL and midware layers。"""
        await self._report(22, "external_mocks", "Checking external mock dependencies")
        detected_layer = state.get("detected_layer", "hal")
        source_content: dict[str, str] = state.get("source_content", {})
        project_root = state.get("project_root", ".")
        platform = state.get("platform", "stm32u3")

        external_mocks_created: list[str] = []
        external_mocks_existed: list[str] = []
        external_mock_modules: list[str] = []
        mock_dependency_guidance = ""

        supported_layers = ("hal", "driver", "midware_controller", "midware_driver")
        if not state.get("enable_mock", True) or detected_layer not in supported_layers:
            return {
                "external_mocks_created": external_mocks_created,
                "external_mocks_existed": external_mocks_existed,
                "external_mock_modules": external_mock_modules,
                "mock_dependency_guidance": mock_dependency_guidance,
            }

        is_midware = detected_layer.startswith("midware_")

        for src_path, content in source_content.items():
            src_filename = os.path.basename(src_path)
            module_name = os.path.splitext(src_filename)[0]
            for prefix in ("controller-", "ctrl-", "hal-", "driver-"):
                if module_name.startswith(prefix):
                    module_name = module_name[len(prefix):]
                    break

            if is_midware:
                ext_calls = analyze_source_midware_calls(content, module_name)
            elif detected_layer == "driver":
                # Driver layer: detect HAL dependencies for mock ownership analysis
                ext_calls = analyze_source_external_hal_calls(content, module_name)
            else:
                # HAL layer: detect external HAL calls
                ext_calls = analyze_source_external_hal_calls(content, module_name)

            if not ext_calls:
                continue

            external_mock_modules.extend(ext_calls.keys())

            if is_midware:
                # Midware: record dependencies for LLM prompt context
                for dep_name, funcs in ext_calls.items():
                    external_mocks_existed.append(dep_name)
                dep_list = ", ".join(
                    f"`{dep}` ({len(funcs)} calls)"
                    for dep, funcs in ext_calls.items()
                )
                mock_dependency_guidance += (
                    f"\n## Midware Dependencies Detected\n\n"
                    f"Module `{module_name}` depends on: {dep_list}\n\n"
                    f"**Mock these dependencies using GMock MOCK_METHOD pattern.**\n"
                    f"**Use pointer pattern with new/delete in test fixture.**\n"
                )
            elif detected_layer == "driver":
                # Driver: record dependencies and emit ownership guidance
                for dep_name, funcs in ext_calls.items():
                    external_mocks_existed.append(dep_name)
                dep_list = ", ".join(
                    f"`{dep}` ({len(funcs)} calls)"
                    for dep, funcs in ext_calls.items()
                )
                mock_dependency_guidance += (
                    f"\n## Driver HAL Dependencies Detected\n\n"
                    f"Driver `{module_name}` depends on HAL modules: {dep_list}\n\n"
                    f"**Mock Ownership Rule**: If this driver's mock file (e.g., `mock-hal-{module_name}.cpp`) "
                    f"defines global HAL interface objects (like `hal_gpio`) that are already provided by "
                    f"another mock file, REMOVE the duplicate definition.\n"
                    f"**REUSE existing HAL mocks** (e.g., `mock-hal-gpio.cpp`) instead of redefining them.\n"
                    f"**Multiple definition linker errors** indicate overlapping mock ownership.\n"
                )
            else:
                missing = find_missing_mock_files(ext_calls, project_root, platform)
                for info in missing:
                    result = create_external_mock_file(info, project_root, platform)
                    if result.get("success"):
                        external_mocks_created.append(info["module"])
                    else:
                        logger.warning(
                            f"Failed to create mock for {info['module']}: "
                            f"{result.get('error')}"
                        )

                for mod in ext_calls:
                    if mod not in [m["module"] for m in missing]:
                        external_mocks_existed.append(mod)

                guidance = generate_mock_dependency_guidance(
                    ext_calls, project_root, platform, module_name,
                )
                if guidance:
                    mock_dependency_guidance += guidance

        return {
            "external_mocks_created": external_mocks_created,
            "external_mocks_existed": external_mocks_existed,
            "external_mock_modules": list(set(external_mock_modules)),
            "mock_dependency_guidance": mock_dependency_guidance,
        }

    async def _node_select_framework(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ④: Automatically select test and mock framework based on layer and project configuration。"""
        await self._report(25, "framework", "Selecting test framework")
        detected_layer: str = state.get("detected_layer", "hal")

        if detected_layer in ("hal", "driver"):
            test_framework = "unity"
            mock_framework = "cmock"
        else:
            test_framework = "gtest"
            mock_framework = "fff"

        framework_config = {
            "test_framework": test_framework,
            "mock_framework": mock_framework,
            "extra_cflags": ["--coverage", "-g", "-O0"],
            "extra_ldflags": (
                ["-lgtest", "-lgtest_main", "-lpthread"]
                if test_framework == "gtest"
                else ["-lunity"]
            ),
        }
        return {
            "test_framework": test_framework,
            "mock_framework": mock_framework,
            "framework_config": framework_config,
        }

    async def _node_generate_test(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑤: Call LLM to generate test code, inject layer rules, skills, clang analysis, context。"""
        await self._report(45, "generate", "Generating test code")
        source_content: dict[str, str] = state.get("source_content", {})
        detected_layer: str = state.get("detected_layer", "hal")
        test_framework: str = state.get("test_framework", "gtest")
        compile_errors: list[dict] = state.get("compile_errors", [])
        project_root: str = state.get("project_root", ".")
        platform: str = state.get("platform", "stm32u3")

        # Context from detect_layer and check_external_mocks
        header_content: str = state.get("header_content", "")
        dependent_headers: str = state.get("dependent_headers", "")
        vendor_api_ref: str = state.get("vendor_api_ref", "")
        existing_mock_ref: str = state.get("existing_mock_ref", "")
        mock_dependency_guidance: str = state.get("mock_dependency_guidance", "")
        skill_prompt: str = state.get("skill_prompt", "")
        clang_guidance: str = state.get("clang_guidance", "")
        project_context: str = state.get("project_context", "")

        # Test failure retry: inject failure info
        failed_cases = state.get("failed_cases", [])
        test_retry_count = state.get("test_retry_count", 0)
        previous_test_content = state.get("parsed_test_code", "")

        if failed_cases and test_retry_count > 0 and previous_test_content:
            test_output = state.get("test_output", "")
            prompt = build_test_failure_fix_prompt(
                failed_tests=failed_cases,
                test_output=test_output,
                previous_test_content=previous_test_content,
            )
            response = await self._llm_generate(
                [{"role": "system", "content": build_system_prompt(detected_layer)},
                 {"role": "user", "content": prompt}],
                temperature=0.2,
            )
            return {
                "generated_test_code": response.content,
                "llm_response": response.content,
                "test_retry_count": test_retry_count + 1,
            }

        # Coverage improvement: inject uncovered info.  The count is persisted
        # in graph state so multiple meaningful iterations are allowed up to
        # the configured limit.
        coverage_attempts = int(state.get("coverage_improvement_count", 0) or 0)
        if coverage_attempts == 0 and state.get("coverage_improvement_attempted"):
            coverage_attempts = 1
        coverage_max = max(0, int(state.get("coverage_max_iterations", 5) or 0))
        if coverage_attempts < coverage_max:
            uncovered_funcs = state.get("uncovered_functions", [])
            uncovered_lines = state.get("uncovered_lines", [])
            if previous_test_content:
                first_src = next(iter(source_content.values()), "")
                prompt = build_coverage_improvement_prompt(
                    uncovered_functions=uncovered_funcs,
                    uncovered_lines=[(l, l) for l in uncovered_lines],
                    previous_test_content=previous_test_content,
                    source_code=first_src,
                )
                response = await self._llm_generate(
                    [{"role": "system", "content": build_system_prompt(detected_layer)},
                     {"role": "user", "content": prompt}],
                    temperature=0.3,
                )
                return {
                    "generated_test_code": response.content,
                    "llm_response": response.content,
                    "coverage_improvement_attempted": True,
                    "coverage_improvement_count": coverage_attempts + 1,
                }

        # Normal generation with full context injection
        prompts: list[str] = []
        for file_path, content in source_content.items():
            file_paths = generate_file_paths(
                os.path.basename(file_path), detected_layer, project_root, platform,
                source_path=file_path,
            )
            test_filename = file_paths.get("test_file", "")
            test_header_filename = file_paths.get("test_header", "")

            prompts.append(build_generation_prompt(
                file_path=file_path,
                content=content,
                layer=detected_layer,
                framework=test_framework,
                target_coverage=85.0,
                compile_errors=compile_errors if compile_errors else None,
                skill_prompt=skill_prompt,
                test_filename=test_filename,
                test_header_filename=test_header_filename,
                clang_guidance=clang_guidance,
                header_content=header_content,
                dependent_hal_headers=dependent_headers,
                vendor_api_ref=vendor_api_ref,
                existing_mock_ref=existing_mock_ref,
                mock_dependency_guidance=mock_dependency_guidance,
                project_context=project_context,
            ))

        prompt = "\n\n".join(prompts)
        if not state.get("enable_mock", True):
            prompt += "\nMock generation is disabled. Return only test artifacts, without mock files or mock includes. Report unavailable dependencies.\n"
        response = await self._llm_generate(
            [
                {"role": "system", "content": build_system_prompt(detected_layer)},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
        )
        return {
            "generated_test_code": response.content,
            "llm_response": response.content,
        }

    async def _node_generate_mock(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑥: Generate Mock/Stub code based on external dependency list, inject skill and clang guidance。"""
        await self._report(60, "mock", "Generating mock code")
        external_calls: list[str] = state.get("external_calls", [])
        mock_framework: str = state.get("mock_framework", "fff")
        related_headers: list[str] = state.get("related_headers", [])
        skill_prompt: str = state.get("skill_prompt", "")
        clang_guidance: str = state.get("clang_guidance", "")
        project_root: str = state.get("project_root", ".")
        platform: str = state.get("platform", "stm32u3")
        detected_layer: str = state.get("detected_layer", "hal")

        if not state.get("enable_mock", True) or not external_calls:
            return {"mock_code": "", "mock_headers": []}

        # Get mock filenames for prompt
        source_files = state.get("source_files", [])
        mock_filename = ""
        mock_header_filename = ""
        if source_files:
            file_paths = generate_file_paths(
                os.path.basename(source_files[0]), detected_layer, project_root, platform,
                source_path=source_files[0],
            )
            mock_filename = file_paths.get("mock_file", "")
            mock_header_filename = file_paths.get("mock_header", "")

        prompt = build_mock_prompt(
            external_calls, mock_framework, related_headers,
            skill_prompt=skill_prompt,
            mock_filename=mock_filename,
            mock_header_filename=mock_header_filename,
            clang_guidance=clang_guidance,
        )
        detected_layer: str = state.get("detected_layer", "hal")
        response = await self._llm_generate(
            [
                {"role": "system", "content": build_system_prompt(detected_layer)},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
        )
        mock_headers = re.findall(r'#include\s+"([^"]+)"', response.content)
        return {"mock_code": response.content, "mock_headers": mock_headers}

    async def _node_parse_output(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑦: Use multi-strategy parser to separate LLM output, includes truncation detection and completeness validation。"""
        raw_test: str = state.get("generated_test_code", "")
        raw_mock: str = state.get("mock_code", "")
        test_framework: str = state.get("test_framework", "gtest")

        # Combine test + mock output for unified parsing
        combined = raw_test
        if raw_mock:
            combined += "\n\n" + raw_mock

        # Truncation detection
        is_truncated = detect_truncation(combined)
        if is_truncated:
            logger.warning("[parse_output] Truncation detected in LLM output")

        # Multi-strategy parse
        parsed = parse_and_split_test_output(combined, test_framework)
        if not state.get("enable_mock", True):
            parsed["mock_impl"] = parsed["mock_header"] = ""

        # Completeness validation
        is_complete, missing_pattern = validate_parsed_completeness(parsed)

        # Save successful content for recovery
        previous = state.get("previous_successful_content", {})
        if parsed.get("test_impl") and len(parsed["test_impl"]) > 100:
            previous["test_impl"] = parsed["test_impl"]
            previous["test_header"] = parsed.get("test_header", "")
        if parsed.get("mock_impl") and len(parsed["mock_impl"]) > 50:
            previous["mock_impl"] = parsed["mock_impl"]
            previous["mock_header"] = parsed.get("mock_header", "")

        parse_retry_count = state.get("parse_retry_count", 0)
        if not is_complete:
            parse_retry_count += 1
            logger.warning(
                f"[parse_output] Incomplete parse (pattern={missing_pattern}, "
                f"retry={parse_retry_count})"
            )

        return {
            "parsed_test_code": parsed.get("test_impl", ""),
            "parsed_test_header": parsed.get("test_header", ""),
            "parsed_mock_code": parsed.get("mock_impl", ""),
            "parsed_mock_header": parsed.get("mock_header", ""),
            "parsed_headers": re.findall(
                r'#include\s+[<"]([^>"]+)[>"]', parsed.get("test_impl", ""),
            ),
            "missing_file_pattern": missing_pattern,
            "parse_retry_count": parse_retry_count,
            "previous_successful_content": previous,
        }

    async def _node_save_files(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑦b: Apply deterministic fixes and save files to project directory。"""
        await self._report(68, "save", "Applying fixes and saving files")

        parsed_content = {
            "test_impl": state.get("parsed_test_code", ""),
            "test_header": state.get("parsed_test_header", ""),
            "mock_impl": state.get("parsed_mock_code", ""),
            "mock_header": state.get("parsed_mock_header", ""),
        }

        # Step 1: Deterministic syntax fixes
        parsed_content = fix_cpp_syntax_errors(parsed_content)

        # Step 2: Fix mock header includes
        source_files = state.get("source_files", [])
        project_root = state.get("project_root", ".")
        detected_layer = state.get("detected_layer", "hal")
        platform = state.get("platform", "stm32u3")

        if source_files:
            file_paths = generate_file_paths(
                os.path.basename(source_files[0]), detected_layer, project_root, platform,
                source_path=source_files[0],
            )
            if state.get("enable_mock", True):
                parsed_content = fix_mock_header_includes(parsed_content, file_paths)

        if not state.get("enable_mock", True):
            parsed_content["mock_impl"] = parsed_content["mock_header"] = ""

        # Step 3: Trim trailing LLM commentary
        parsed_content = trim_generated_code_structure(parsed_content)

        # Step 4: Save to project
        saved_files: list[str] = []
        output_dir = state.get("output_dir", "")
        if output_dir and source_files:
            for src in source_files:
                fp = generate_file_paths(
                    os.path.basename(src), detected_layer, output_dir, platform,
                    source_path=src,
                )
                fp = filter_mock_paths(fp, state.get("enable_mock", True))
                save_result = save_test_files_to_project(parsed_content, fp)
                for item in save_result.get("success", []):
                    saved_files.append(item["path"])
                    logger.info(f"Saved: {item['path']}")
                for item in save_result.get("failed", []):
                    logger.warning(f"Failed to save: {item}")

        return {
            "parsed_test_code": parsed_content["test_impl"],
            "parsed_test_header": parsed_content["test_header"],
            "parsed_mock_code": parsed_content["mock_impl"],
            "parsed_mock_header": parsed_content["mock_header"],
            "saved_files": saved_files,
        }

    async def _node_update_qbs_config(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑧: Update QBS configuration file, register test/mock files in .qbs。"""
        await self._report(70, "qbs_config", "Updating QBS configuration")
        project_root: str = state.get("project_root", ".")
        detected_layer: str = state.get("detected_layer", "hal")
        platform: str = state.get("platform", "stm32u3")
        source_files: list[str] = state.get("source_files", [])

        qbs_path = resolve_qbs_project_path(project_root, detected_layer, platform)
        qbs_updated = False
        qbs_ready = True

        for src in source_files:
            file_paths = generate_file_paths(
                os.path.basename(src),
                detected_layer,
                project_root,
                platform,
                source_path=src,
            )
            module_name = file_paths.get("module_name", "")
            if not module_name:
                base = os.path.splitext(os.path.basename(src))[0]
                for prefix in (
                    "controller-", "controller_", "ctrl-", "ctrl_",
                    "driver-", "driver_", "hal-", "hal_", "app-", "app_",
                ):
                    if base.startswith(prefix):
                        base = base[len(prefix):]
                        break
                module_name = base
            # APP layer passes the relative path only so backend can ensure the
            # canonical template exists; backend must not dynamically rewrite
            # Application sources.prefix.
            source_relative_path = src if detected_layer == "app" else None
            try:
                qbs_options = {}
                if not bool(state.get("enable_mock", True)):
                    qbs_options["enable_mock"] = False
                update_result = update_qbs_config(
                    module_name=module_name,
                    layer=detected_layer,
                    platform=platform,
                    project_root=project_root,
                    source_relative_path=source_relative_path,
                    **qbs_options,
                )
                qbs_ready = qbs_ready and bool(update_result.get("success", False))
                qbs_updated = qbs_updated or bool(update_result.get("has_changes", False))
            except Exception as e:
                qbs_ready = False
                logger.warning(f"update_qbs_config failed for {module_name}: {e}")

        preflight = validate_qbs_build_context(project_root, detected_layer, platform)
        qbs_path = preflight["project_path"]
        build_context = preflight
        if not preflight.get("ready"):
            # The MCP QBS server can own a remote or mounted firmware workspace
            # that is not visible to this API process. Preserve the diagnostic,
            # but still ask the server to resolve the project.
            logger.warning(
                f"[QBS] Local build-context preflight is unavailable: "
                f"code={preflight.get('error_code')}, error={preflight.get('error')}"
            )
        try:
            profile = state.get("build_profile", "mingw")
            resolve_result = await self._mcp.call_tool(
                "qbs_resolve",
                project_path=qbs_path,
                profile=profile,
            )
            if not resolve_result.success:
                qbs_ready = False
        except Exception as e:
            qbs_ready = False
            logger.warning(f"qbs_resolve failed: {e}")

        return {
            "qbs_project_path": qbs_path,
            "qbs_file": build_context.get("qbs_file"),
            "qbs_products": build_context.get("products", []),
            "qbs_updated": qbs_updated,
            "qbs_ready": qbs_ready,
            "qbs_error": preflight.get("error"),
            "qbs_error_code": preflight.get("error_code"),
            "qbs_retryable": preflight.get("retryable", True),
        }

    async def _node_compile_test(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑨: Trigger compilation via QBS MCP, apply deterministic fixes before compilation。"""
        retry = state.get("retry_count", 0)
        msg = f"Compiling test (attempt {retry + 1})" if retry else "Compiling test"
        await self._report(75, "compile", msg)

        project_root: str = state.get("project_root", ".")
        detected_layer: str = state.get("detected_layer", "hal")
        platform: str = state.get("platform", "stm32u3")
        profile: str = state.get("build_profile", "mingw")
        state_qbs_path = state.get("qbs_project_path", "")
        state_qbs_file = state.get("qbs_file")
        previous_compile_state = state.get("compile_state_signature", "")

        def _compile_failure_payload(
            *, errors: list[dict], output: str, error_code: Any,
            retryable: bool, content_overrides: dict[str, str] | None = None,
            **extra: Any,
        ) -> dict[str, Any]:
            signature = self._compile_state_signature(errors, state, content_overrides)
            payload: dict[str, Any] = {
                "compile_success": False,
                "compile_errors": errors,
                "compile_output": output,
                "compile_error_code": error_code,
                "compile_retryable": retryable,
                "compile_state_signature": signature,
                "compile_state_repeated": bool(previous_compile_state and signature == previous_compile_state),
            }
            payload.update(extra)
            return payload
        if state_qbs_path:
            build_context = {
                "ready": Path(state_qbs_path).is_dir()
                and (not state_qbs_file or Path(state_qbs_file).is_file()),
                "project_path": state_qbs_path,
                "qbs_file": state_qbs_file,
                "product_name": "",
                "products": state.get("qbs_products", []),
                "error": None,
                "error_code": None,
                "retryable": True,
            }
            if not Path(state_qbs_path).is_dir():
                build_context.update({
                    "error": f"QBS project directory not found: {state_qbs_path}",
                    "error_code": "qbs_project_directory_missing",
                    "retryable": False,
                })
            elif state_qbs_file and not Path(state_qbs_file).is_file():
                build_context.update({
                    "error": f"QBS project file not found: {state_qbs_file}",
                    "error_code": "qbs_project_file_missing",
                    "retryable": False,
                })
        else:
            build_context = validate_qbs_build_context(project_root, detected_layer, platform)
        if not build_context.get("ready"):
            # qbs_build is executed by the MCP server and may target a mounted
            # firmware workspace that is not present in the API process. Keep
            # the preflight diagnostic, but allow the server to perform the
            # authoritative build attempt.
            logger.warning(
                "[QBS] Local build-context preflight unavailable; delegating to MCP: %s",
                build_context.get("error"),
            )
        qbs_path: str = state.get("qbs_project_path", "") or build_context["project_path"]
        qbs_file = state.get("qbs_file") or build_context["qbs_file"]
        products = state.get("qbs_products") or build_context.get("products") or [
            {
                "hal": "test-hal",
                "driver": "test-driver",
                "midware_controller": "test-controller",
                "midware_driver": "test-midware-drivers",
                "app": "test-app",
                "common": "test-common",
            }.get(detected_layer, f"test-{detected_layer}")
        ]

        # On retry, save current state content to disk before compile
        if retry > 0:
            source_files = state.get("source_files", [])
            if source_files:
                fp = generate_file_paths(
                    source_filename=os.path.basename(source_files[0]),
                    layer=detected_layer, project_root=project_root, platform=platform,
                )
                content_map = {
                    "test_impl": state.get("parsed_test_code", ""),
                    "test_header": state.get("parsed_test_header", ""),
                    "mock_impl": state.get("parsed_mock_code", ""),
                    "mock_header": state.get("parsed_mock_header", ""),
                }
                fp = filter_mock_paths(fp, state.get("enable_mock", True))
                save_test_files_to_project(content_map, fp)

        try:
            build_kwargs: dict = dict(
                project_path=qbs_path,
                profile=profile,
                configuration="debug",
                products=products,
            )
            if qbs_file:
                build_kwargs["project_file"] = qbs_file
            result = await self._mcp.call_tool("qbs_build", **build_kwargs)
            stdout = result.data.get("stdout", "") if result.data else ""
            stderr = result.data.get("stderr", "") if result.data else ""
            warning_lines = list(result.data.get("warnings") or []) if result.data else []
            if not warning_lines:
                warning_lines = parse_qbs_warnings_structured(f"{stdout}\n{stderr}")
            if result.success and not warning_lines:
                return {
                    "compile_success": True,
                    "compile_errors": [],
                    "compile_output": stdout,
                    "compile_error_code": None,
                    "compile_retryable": True,
                    "compile_state_signature": "",
                    "compile_state_repeated": False,
                }
            if warning_lines:
                warning_messages = [
                    item.message if isinstance(item, CompileError) else str(item)
                    for item in warning_lines
                ]
                return _compile_failure_payload(
                    errors=[
                        {
                            "file": item.file,
                            "line": item.line,
                            "column": item.column,
                            "message": item.message,
                            "severity": "warning",
                        }
                        if isinstance(item, CompileError)
                        else {"message": str(item), "severity": "warning"}
                        for item in warning_lines
                    ],
                    output="\n".join(warning_messages),
                    error_code=result.data.get("error_code") if result.data else None,
                    retryable=bool(result.data.get("retryable", True)) if result.data else True,
                )
            error_code = result.data.get("error_code")
            retryable = bool(result.data.get("retryable", True))
            error_blocks = parse_qbs_build_errors(stderr)
            errors = parse_gcc_errors(stderr) if not error_blocks else []
            compile_errors = [
                {"file": e.file, "line": e.line, "column": e.column,
                 "message": e.message, "severity": e.severity}
                for e in errors
            ] if errors else [
                {"message": block} for block in error_blocks
            ]
            # Fallback: raw stderr as a single error when parsers return empty
            if not compile_errors and stderr.strip():
                compile_errors = [{"message": stderr.strip()[:2000]}]

            # Apply deterministic fixit rules on compile errors
            if compile_errors:
                parsed_content = {
                    "test_impl": state.get("parsed_test_code", ""),
                    "test_header": state.get("parsed_test_header", ""),
                    "mock_impl": state.get("parsed_mock_code", ""),
                    "mock_header": state.get("parsed_mock_header", ""),
                }
                structured = {"errors": errors, "summary": {
                    "multiple_definitions": [],
                    "undefined_references": [],
                }}
                fixed_content, fixes = apply_fixit_rules(parsed_content, structured)
                if fixes:
                    logger.info(f"[compile_test] Applied {len(fixes)} deterministic fixes")
                    return _compile_failure_payload(
                        errors=compile_errors,
                        output=stderr,
                        error_code=error_code,
                        retryable=retryable,
                        content_overrides=fixed_content,
                        prev_compile_error_count=len(compile_errors),
                        parsed_test_code=fixed_content["test_impl"],
                        parsed_test_header=fixed_content["test_header"],
                        parsed_mock_code=fixed_content["mock_impl"],
                        parsed_mock_header=fixed_content["mock_header"],
                    )

            return _compile_failure_payload(
                errors=compile_errors,
                output=stderr,
                error_code=error_code,
                retryable=retryable,
                prev_compile_error_count=len(compile_errors),
            )
        except Exception as e:
            logger.warning(f"_compile_test failed: {e}")
            return _compile_failure_payload(
                errors=[{"message": str(e)}],
                output="",
                error_code="compile_exception",
                retryable=True,
            )

    @staticmethod
    def _compile_state_signature(
        errors: list[dict], state: UnitTestState,
        content_overrides: dict[str, str] | None = None,
    ) -> str:
        """Hash diagnostics and generated artifacts for no-op retry detection."""
        diagnostic_text = "\n".join(
            f"{item.get('file', '')}:{item.get('line', 0)}:{item.get('column', 0)}:"
            f"{item.get('severity', 'error')}:{item.get('message', '')}"
            for item in errors
        )
        content_keys = (
            ("parsed_test_code", "test_impl"),
            ("parsed_test_header", "test_header"),
            ("parsed_mock_code", "mock_impl"),
            ("parsed_mock_header", "mock_header"),
        )
        content_text = "\0".join(
            str((content_overrides or {}).get(alias, state.get(state_key, "")) or "")
            for state_key, alias in content_keys
        )
        return hashlib.sha256(
            (diagnostic_text + "\0" + content_text).encode("utf-8", errors="replace")
        ).hexdigest()

    async def _node_handle_errors(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑨: Parse compile errors, call LLM to generate fix patches (multi-file)。"""
        raw_errors: list[dict] = state.get("compile_errors", [])
        errors = [
            CompileError(
                file=e.get("file", ""),
                line=e.get("line", 0),
                column=e.get("column", 0),
                message=e.get("message", ""),
                severity=e.get("severity", "error"),
            )
            for e in raw_errors
        ]
        project_root = state.get("project_root", ".")
        detected_layer = state.get("detected_layer", "hal")
        platform = state.get("platform", "stm32u3")
        profile = state.get("build_profile", "mingw")

        # Build file_paths for save-before-verify
        source_files = state.get("source_files", [])
        fp = None
        if source_files:
            fp = generate_file_paths(
                source_filename=os.path.basename(source_files[0]),
                layer=detected_layer, project_root=project_root, platform=platform,
            )

        # fix_compile_errors also calls LLM internally, counted against global call limit
        self._llm_call_count += 1
        if self._llm_call_count > self._max_llm_calls:
            raise RuntimeError(
                f"LLM call limit reached ({self._max_llm_calls}). "
                f"Workflow terminated to prevent infinite retry loops."
            )
        logger.info(f"LLM call #{self._llm_call_count}/{self._max_llm_calls} (fix_compile_errors)")

        fix_result = await self._fix_compile_errors(
            test_code=state.get("parsed_test_code", ""),
            errors=errors,
            max_attempts=1,
            project_root=project_root,
            layer=detected_layer,
            platform=platform,
            profile=profile,
            test_header=state.get("parsed_test_header", ""),
            mock_impl=state.get("parsed_mock_code", ""),
            mock_header=state.get("parsed_mock_header", ""),
            file_paths=fp,
        )
        result: dict = {
            "parsed_test_code": fix_result.fixed_code,
            "retry_count": state.get("retry_count", 0) + 1,
        }
        # Write back all 4 files from fix result
        if fix_result.fixed_content:
            if fix_result.fixed_content.get("test_header"):
                result["parsed_test_header"] = fix_result.fixed_content["test_header"]
            if fix_result.fixed_content.get("mock_impl"):
                result["parsed_mock_code"] = fix_result.fixed_content["mock_impl"]
            if fix_result.fixed_content.get("mock_header"):
                result["parsed_mock_header"] = fix_result.fixed_content["mock_header"]
        return result

    async def _node_autonomous_fix(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑩: Claude CLI autonomous fix (Level 2 escalation)。"""
        await self._report(80, "autonomous_fix", "Escalating to Claude CLI autonomous fix")

        _state_project_root: str = state.get("project_root", ".")
        detected_layer: str = state.get("detected_layer", "hal")
        platform: str = state.get("platform", "stm32u3")
        profile: str = state.get("build_profile", "mingw")
        source_files = state.get("source_files", [])
        raw_errors = state.get("compile_errors", [])
        autonomous_fix_count = state.get("autonomous_fix_count", 0)

        # Infer the real project root from the source file absolute path to avoid state["project_root"] pointing to the source file directory
        from .paths import find_project_root_for_source as _find_root
        _inferred_root = None
        if source_files and os.path.isabs(source_files[0]):
            _inferred_root = _find_root(source_files[0])
        project_root: str = _inferred_root or _state_project_root

        # Build file paths
        fp = {}
        if source_files:
            fp = generate_file_paths(
                source_filename=os.path.basename(source_files[0]),
                layer=detected_layer, project_root=project_root, platform=platform,
            )

        # Build errors list
        errors = [
            CompileError(
                file=e.get("file", ""), line=e.get("line", 0),
                column=e.get("column", 0), message=e.get("message", ""),
                severity=e.get("severity", "error"),
            )
            for e in raw_errors
        ]

        try:
            from app.utils.claude_cli_monitor import ClaudeCliMonitor
            from .prompts import build_autonomous_fix_prompt, build_autonomous_fix_system_prompt

            monitor = ClaudeCliMonitor()

            # Resolve coverage context
            coverage_target_pct = state.get("target_coverage", 0.0)
            current_coverage = state.get("line_coverage", 0.0)
            source_content: dict[str, str] = state.get("source_content", {})
            source_code = next(iter(source_content.values()), "")

            # Verified SUT reference files (real paths + inline contents) so
            # the repair CLI reads ground truth instead of guessing paths.
            reference_files: dict[str, str] = {}
            _path_map = dict(state.get("source_path_map", {}))
            for _name, _real_path in _path_map.items():
                if not _real_path:
                    continue
                _content = source_content.get(_name) or source_content.get(
                    os.path.basename(_real_path), ""
                )
                reference_files[str(_real_path)] = _content or ""

            task_prompt = build_autonomous_fix_prompt(
                errors=errors, file_paths=fp, project_root=project_root,
                layer=detected_layer, platform=platform, build_profile=profile,
                coverage_target=coverage_target_pct,
                current_coverage=current_coverage,
                source_code=source_code,
                qbs_project_path=state.get("qbs_project_path", ""),
                qbs_file=state.get("qbs_file", ""),
                qbs_product=(state.get("qbs_products") or [""])[0],
                reference_files=reference_files,
            )
            system_prompt = build_autonomous_fix_system_prompt(
                fp, project_root,
                coverage_target=coverage_target_pct,
                current_coverage=current_coverage,
                source_code=source_code,
                qbs_project_path=state.get("qbs_project_path", ""),
                qbs_file=state.get("qbs_file", ""),
                qbs_product=(state.get("qbs_products") or [""])[0],
                reference_files=reference_files,
            )

            # Ensure project permissions
            from pathlib import Path
            ClaudeCliMonitor.ensure_project_permissions(Path(project_root))

            # Build allowed dirs
            allowed_dirs = [project_root]
            for v in fp.values():
                if v and os.path.dirname(v):
                    d = os.path.dirname(v)
                    if d not in allowed_dirs:
                        allowed_dirs.append(d)

            _cli_model = self._llm_selection.model

            _task_id = state.get("task_id")
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: monitor.execute_with_prodding(
                    cli_path=get_resolved_cli_path(),
                    prompt=task_prompt,
                    system_prompt=system_prompt,
                    model=_cli_model,
                    working_dir=Path(project_root),
                    timeout=900,
                    bypass_permissions=True,
                    allowed_dirs=allowed_dirs,
                    task_id=_task_id,
                    upstream_provider=self._llm_selection.provider,
                    unbounded_runtime=True,
                ),
            )

            succeeded = result.get("status") == "success" and result.get("exit_code", -1) == 0
            logger.info(f"[autonomous_fix] status={result.get('status')}, "
                        f"exit_code={result.get('exit_code')}")

            # Re-read files from disk after autonomous fix
            updated_state: dict = {
                "autonomous_fix_count": autonomous_fix_count + 1,
                "autonomous_fix_succeeded": succeeded,
            }
            if succeeded:
                for key, path_key in [
                    ("parsed_test_code", "test_impl_path"),
                    ("parsed_test_header", "test_header_path"),
                    ("parsed_mock_code", "mock_impl_path"),
                    ("parsed_mock_header", "mock_header_path"),
                ]:
                    fpath = fp.get(path_key, "")
                    if fpath and os.path.isfile(fpath):
                        with open(fpath, "r", encoding="utf-8") as f:
                            updated_state[key] = f.read()

            return updated_state

        except Exception as e:
            logger.warning(f"_node_autonomous_fix failed: {e}")
            return {
                "autonomous_fix_count": autonomous_fix_count + 1,
                "autonomous_fix_succeeded": False,
            }

    def _check_autonomous_fix_result(self, state: UnitTestState) -> str:
        """Route after autonomous fix: verify / fallback / fail."""
        if state.get("autonomous_fix_succeeded"):
            return "verify"
        if state.get("retry_count", 0) < 5:
            return "fallback"
        return "fail"

    async def _node_run_test(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑪: Execute tests via qbs_run_tests, capture result, supports failed retry。"""
        await self._report(85, "run", "Running tests")
        project_root: str = state.get("project_root", ".")
        detected_layer: str = state.get("detected_layer", "hal")
        platform: str = state.get("platform", "stm32u3")
        profile: str = state.get("build_profile", "mingw")
        qbs_path: str = state.get("qbs_project_path", "") or resolve_qbs_project_path(
            project_root, detected_layer, platform
        )
        products = state.get("qbs_products") or []
        test_filter = products[0] if products else f"test-{detected_layer}"
        test_retry_count = state.get("test_retry_count", 0)

        try:
            result = await self._mcp.call_tool("qbs_run_tests",
                project_path=qbs_path,
                profile=profile,
                filter=test_filter,
            )
            data = result.data or {}
            output = "\n".join(
                part for part in (data.get("stdout"), data.get("stderr"), result.error) if part
            )
            test_count, failed_cases = parse_test_results(output)
            return {
                "test_passed": (
                    result.success and data.get("returncode", 0) == 0
                    and test_count > 0 and not failed_cases
                ),
                "test_output": output,
                "test_count": test_count,
                "failed_cases": failed_cases,
                "test_retry_count": test_retry_count,
            }
        except Exception as e:
            logger.warning(f"_run_test failed: {e}")
            return {
                "test_passed": False,
                "test_output": str(e),
                "test_count": 0,
                "failed_cases": [],
                "test_retry_count": test_retry_count,
            }

    async def _node_collect_coverage(self, state: UnitTestState) -> Dict[str, Any]:
        """Node: Parse gcov coverage data from qbs_run_tests output."""
        await self._report(92, "coverage", "Collecting coverage")
        test_output: str = state.get("test_output", "")
        source_files: list[str] = state.get("source_files", [])
        line_cov = parse_coverage_from_output(test_output, source_files)
        branch_cov = parse_branch_coverage_from_output(test_output)
        func_cov = parse_function_coverage_from_output(test_output)
        signature = f"{line_cov:.4f}|{branch_cov:.4f}|{func_cov:.4f}"
        previous_signature = state.get("coverage_last_signature")
        stagnant_count = int(state.get("coverage_stagnant_count", 0) or 0)
        if previous_signature and previous_signature == signature:
            stagnant_count += 1
        else:
            stagnant_count = 0
        return {
            "coverage_data": test_output,
            "line_coverage": line_cov,
            "branch_coverage": branch_cov,
            "function_coverage": func_cov,
            "coverage_last_signature": signature,
            "coverage_stagnant_count": stagnant_count,
        }

    async def _node_finalize(self, state: UnitTestState) -> Dict[str, Any]:
        """Node ⑮: Summarize test results, coverage data, generate final report and statistics。"""
        await self._report(98, "report", "Generating report")
        line_cov: float = state.get("line_coverage", 0.0)
        branch_cov: float = state.get("branch_coverage", 0.0)
        func_cov: float = state.get("function_coverage", 0.0)
        test_count: int = state.get("test_count", 0)
        failed_cases: list = state.get("failed_cases", [])
        compile_success: bool = state.get("compile_success", False)
        test_passed: bool = state.get("test_passed", False)
        verification_required = state.get("compile_verify", True)
        saved_files: list[str] = state.get("saved_files", [])

        metrics = {
            "compilation_requested": verification_required,
            "compile_success": compile_success if verification_required else None,
            "test_passed": test_passed if verification_required else None,
            "test_count": test_count if verification_required else None,
            "failed_count": len(failed_cases) if verification_required else None,
            "line_coverage": line_cov if verification_required else None,
            "branch_coverage": branch_cov if verification_required else None,
            "function_coverage": func_cov if verification_required else None,
            "retry_count": state.get("retry_count", 0),
            "parse_retry_count": state.get("parse_retry_count", 0),
            "test_retry_count": state.get("test_retry_count", 0),
            "external_mocks_created": state.get("external_mocks_created", []),
            "saved_files": saved_files,
            "coverage_improvement_attempts": int(state.get("coverage_improvement_count", 0) or 0),
            "coverage_improvement_max": int(state.get("coverage_max_iterations", 5) or 0),
            "coverage_target_met": (
                None if not verification_required else (
                line_cov >= state.get("target_coverage", 90.0)
                and (not state.get("target_branch_coverage") or branch_cov >= state.get("target_branch_coverage", 85.0))
                and (not state.get("target_function_coverage") or func_cov >= state.get("target_function_coverage", 90.0))
                )
            ),
            "coverage_stop_reason": (
                "not_requested" if not verification_required else "target_met" if (
                    line_cov >= state.get("target_coverage", 90.0)
                    and (not state.get("target_branch_coverage") or branch_cov >= state.get("target_branch_coverage", 85.0))
                    and (not state.get("target_function_coverage") or func_cov >= state.get("target_function_coverage", 90.0))
                ) else (
                    "stagnant" if state.get("coverage_stagnant_count", 0) else "iteration_limit"
                )
            ),
        }
        final_report = (
            f"# Unit Test Report\n\n"
            f"- Compile: {('OK' if compile_success else 'FAIL') if verification_required else 'Not requested'}\n"
            f"- Tests: {f'{test_count - len(failed_cases)}/{test_count} passed' if verification_required else 'Not run'}\n"
            f"- Line coverage: {f'{line_cov:.1f}%' if verification_required else 'Not collected'}\n"
            f"- Branch coverage: {f'{branch_cov:.1f}%' if verification_required else 'Not collected'}\n"
            f"- Function coverage: {f'{func_cov:.1f}%' if verification_required else 'Not collected'}\n"
            f"- Files saved: {len(saved_files)}\n"
        )

        return {
            "saved_files": saved_files,
            "metrics": metrics,
            "final_report": final_report,
            "coverage": line_cov if verification_required else None,
            "test_count": test_count if verification_required else None,
        }

    @staticmethod
    def map_state_to_result(state: UnitTestState, task_id: str) -> UnitTestResult:
        """Convert final state without discarding build or execution failures."""
        source_content: dict[str, str] = state.get("source_content", {})
        parsed_test = state.get("parsed_test_code", "")
        parsed_test_header = state.get("parsed_test_header", "")
        parsed_mock = state.get("parsed_mock_code", "") if state.get("enable_mock", True) else ""
        parsed_mock_header = state.get("parsed_mock_header", "") if state.get("enable_mock", True) else ""
        verification_required = state.get("compile_verify", True)
        compile_ok = state.get("compile_success", False)
        line_cov = state.get("line_coverage", 0.0)
        test_count = state.get("test_count", 0)
        failed_cases = state.get("failed_cases", [])
        retry_count = state.get("retry_count", 0)
        saved_files = state.get("saved_files", [])

        generated_tests: list[GeneratedTest] = []
        for src_path in source_content if parsed_test.strip() else ():
            base = os.path.splitext(os.path.basename(src_path))[0]
            test_file = f"{base}_test.cpp"
            generated_tests.append(GeneratedTest(
                source_file=src_path,
                test_file=test_file,
                test_content=parsed_test,
                test_header_content=parsed_test_header or None,
                mock_content=parsed_mock or None,
                mock_header_content=parsed_mock_header or None,
                coverage=line_cov,
                compile_success=compile_ok,
            ))

        failure_message = ""
        if not generated_tests:
            failure_message = "No test files generated"
        elif verification_required and not compile_ok:
            failure_message = "QBS compilation failed"
        elif failed_cases:
            failure_message = f"{len(failed_cases)} unit test(s) failed"
        elif verification_required and test_count <= 0:
            failure_message = "No unit tests were executed"
        elif verification_required and not state.get("test_passed"):
            failure_message = "Unit test execution verification failed"

        status = AgentStatus.FAILED if failure_message else AgentStatus.COMPLETED
        message = failure_message or (
            (
                f"Generated {len(generated_tests)} test files, coverage: {line_cov:.1f}%"
                if verification_required
                else f"Generated {len(generated_tests)} test files; compilation, tests, and coverage were not requested"
            )
        )

        return UnitTestResult(
            task_id=task_id,
            status=status,
            message=message,
            data={
                "files_processed": len(source_content),
                "tests_generated": len(generated_tests),
                "coverage": line_cov if verification_required else None,
                "test_count": test_count if verification_required else None,
                "compile_success": compile_ok if verification_required else None,
                "compile_output": state.get("compile_output", ""),
                "compile_errors": state.get("compile_errors", []),
                "test_passed": state.get("test_passed") if verification_required else None,
                "test_output": state.get("test_output", ""),
                "failed_cases": failed_cases,
                "saved_files": saved_files,
                "external_mocks_created": state.get("external_mocks_created", []),
                "generated_tests": [
                    {"source_file": t.source_file, "test_file": t.test_file,
                     "test_content": t.test_content, "mock_content": t.mock_content,
                     "coverage": t.coverage, "compile_success": t.compile_success}
                    for t in generated_tests
                ],
            },
            generated_tests=generated_tests,
            total_coverage=line_cov,
            iterations_used=retry_count + 1,
        )
