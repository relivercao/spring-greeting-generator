"""
@file qbs.py
@author caoshwen
@brief QBS configuration management module (internal).

QBS project path resolution and .qbs configuration updates
(uncommenting entries / adding test files).
Migrated from update_qbs_config / run_qbs_build in the original unittest_agent copy.py.

@version 3.2
@date 2026-03-10

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
import hashlib
import fnmatch
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger


# ========== QBS path resolution ==========

QBS_ERROR_PROJECT_ROOT_MISSING = "qbs_project_root_missing"
QBS_ERROR_PROJECT_DIR_MISSING = "qbs_project_directory_missing"
QBS_ERROR_PROJECT_FILE_MISSING = "qbs_project_file_missing"
QBS_ERROR_RESOLVE_FAILED = "qbs_resolve_failed"
QBS_ERROR_BUILD_FAILED = "qbs_build_failed"
QBS_ERROR_TIMEOUT = "qbs_timeout"
QBS_ERROR_TOOL_MISSING = "qbs_tool_missing"
QBS_ERROR_EXCEPTION = "qbs_exception"
QBS_WARNING_RE = re.compile(r"(?im)^.*\bwarning:\s+.*$")
_APP_UNSAFE_BRIDGE_WARNING_RE = re.compile(
    r"(?im)^.*\bwarning:\s+.*(?:"
    r"implicit declaration of function|"
    r"initialization makes pointer from integer|"
    r"assignment makes pointer from integer|"
    r"returning .* from a function with return type .* pointer"
    r").*$"
)
APP_FORBIDDEN_PLATFORMKIT_RE = re.compile(
    r"(?:^|/)libs/platformkit(?:/|$)", re.IGNORECASE
)

# Candidate QBS file paths for each layer (ordered by priority)
# Note: the top-level project file (tests-platformkit.qbs) must be used,
# not a subproject file directly.
# Subproject files (e.g., test-hal-stm32u3.qbs) rely on gmock module
# definitions provided by the top-level project file.
# Passing a subproject file directly via -f may cause:
# "Dependency 'gmock' not found".
# Layer -> candidate QBS path list (priority order, supports {platform}).
# For HAL layer, always use the top-level project file (tests-platformkit.qbs).
# Platform-specific subproject files depend on module imports defined by the top-level
# project and will fail when passed directly via -f (e.g. gmock dependency resolution).
_QBS_CANDIDATES: dict[str, list[str]] = {
    "hal": [
        "libs/platformkit/project/test/qbs/tests-platformkit.qbs",
    ],
    "driver": [
        "libs/platformkit/project/test/qbs/test-driver/test-driver-{platform}.qbs",  # fix: add back test-driver/ subdirectory
        "libs/platformkit/project/test/qbs/test-driver/test-driver.qbs",  # added: fallback without platform suffix
        "libs/platformkit/project/test/qbs/tests-platformkit.qbs",
    ],
    "midware_controller": [
        "libs/platformkit/project/test/qbs/test-midware/test-controller-{platform}.qbs",  # fix: add back subdirectory
        "libs/platformkit/project/test/qbs/test-midware/test-controller.qbs",  # added
        "libs/platformkit/project/test/qbs/tests-platformkit.qbs",
    ],
    "midware_driver": [
        "libs/platformkit/project/test/qbs/test-midware/test-drivers-{platform}.qbs",  # fix: add back subdirectory
        "libs/platformkit/project/test/qbs/test-midware/test-drivers.qbs",  # added
        "libs/platformkit/project/test/qbs/tests-platformkit.qbs",
    ],
    "app": [
        "projects/test/qbs/test_app.qbs",
    ],
}

_QBS_PRODUCT_MAP: dict[str, str] = {
    "hal": "test-hal",
    "driver": "test-driver",
    "midware_controller": "test-controller",
    "midware_driver": "test-midware-drivers",
    "app": "test-app",
    "common": "test-common",
}

QBS_BUILD_TIMEOUT_SECONDS = 600


_TEST_PROCESS_CRASH_RETURN_CODES = {
    134, 136, 137, 139, 0xC0000005, -1073741819, 0xC00000FD, -1073741571,
}


def _is_test_process_crash_returncode(returncode: Optional[int]) -> bool:
    """Return whether an executable return code represents a process crash."""
    if returncode is None or returncode == 0:
        return False
    if returncode in _TEST_PROCESS_CRASH_RETURN_CODES or returncode < 0:
        return True
    return returncode >= 0xC0000000


def parse_qbs_warnings(output: str) -> list[str]:
    """Extract unique compiler/QBS warning lines from combined output."""
    warnings: list[str] = []
    for match in QBS_WARNING_RE.finditer(output or ""):
        warning = match.group(0).strip()
        if warning and warning not in warnings:
            warnings.append(warning)
    return warnings


def parse_app_unsafe_bridge_warnings(output: str) -> list[str]:
    """Extract unsafe implicit-declaration warnings from APP bridge sources."""
    unsafe: list[str] = []
    for match in _APP_UNSAFE_BRIDGE_WARNING_RE.finditer(output or ""):
        warning = match.group(0).strip()
        normalized = warning.replace("\\", "/")
        if ("tests/stubs" in normalized or "_test_" in warning) and warning not in unsafe:
            unsafe.append(warning)
    return unsafe


def _qbs_quote_path(path: str | Path) -> str:
    """Return a QBS-safe path literal using forward slashes."""
    value = str(path).replace("\\", "/")
    return value.replace('"', '\\"')


_CONCRETE_STM32_PATTERN = re.compile(
    r"(STM32[A-Z][A-Z0-9]{3,5}xx)",
    re.IGNORECASE,
)


def _normalize_stm32_define(value: str) -> str:
    """Normalize a concrete STM32 device macro while preserving the lowercase suffix."""
    return value[:-2].upper() + "xx"


def _discover_explicit_target_defines(
    root: Path,
    file_entries: list[dict[str, str]],
) -> tuple[list[str], list[str]]:
    """Discover concrete MCU defines only from explicit project configuration evidence."""
    evidence_files: set[Path] = set()
    for entry in file_entries:
        for key in ("source_path", "test_impl_path", "test_header_path"):
            value = entry.get(key, "")
            if value:
                evidence_files.add(Path(value))

    config_patterns = (
        "*.qbs",
        "*.mk",
        "CMakeLists.txt",
        "Makefile",
        ".cproject",
        "*config*.h",
    )
    for child in root.iterdir():
        if child.is_file() and any(fnmatch.fnmatch(child.name, pattern) for pattern in config_patterns):
            evidence_files.add(child)

    filename_candidates: set[str] = set()
    skipped_dirs = {
        ".git",
        ".qbs",
        "build",
        "debug",
        "release",
        "default",
        "vendor",
        "vendorhal",
        "third-party",
        "node_modules",
    }
    for search_root in (root / "apps", root / "projects", root / "bsp"):
        if not search_root.is_dir():
            continue
        for current_root, dir_names, file_names in os.walk(search_root):
            dir_names[:] = [name for name in dir_names if name.lower() not in skipped_dirs]
            for name in file_names:
                path = Path(current_root) / name
                if any(fnmatch.fnmatch(name, pattern) for pattern in config_patterns):
                    evidence_files.add(path)
                filename_candidates.update(_CONCRETE_STM32_PATTERN.findall(name))

    candidates: set[str] = set()
    for path in evidence_files:
        normalized = str(path).replace("\\", "/").lower()
        if any(part in normalized for part in ("/vendor/", "/third-party/", "/build/", "/default/")):
            continue
        try:
            if not path.is_file() or path.stat().st_size > 2_000_000:
                continue
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for match in _CONCRETE_STM32_PATTERN.findall(text):
            if re.search(
                rf"(?:-D|#\s*define\s+|[\"']){re.escape(match)}\b",
                text,
                re.IGNORECASE,
            ):
                candidates.add(_normalize_stm32_define(match))

    # Startup and linker-script filenames are also explicit target evidence.
    candidates.update(_normalize_stm32_define(match) for match in filename_candidates)

    diagnostics: list[str] = []
    if len(candidates) == 1:
        return sorted(candidates), diagnostics
    if not candidates:
        diagnostics.append(
            "No concrete STM32 device macro was found in project QBS, build flags, config headers, startup files, or linker filenames"
        )
    else:
        diagnostics.append(
            "Conflicting STM32 device macros were found: " + ", ".join(sorted(candidates))
        )
    return [], diagnostics


def create_isolated_app_qbs_file(
    project_root: str,
    file_entries: list[dict[str, str]],
    task_id: str | None = None,
) -> dict[str, Any]:
    """Create an isolated App-layer QBS target for one unit-test task.

    The historical ``test_app.qbs`` is an aggregate target.  Every generated
    test was appended to that target, so a later task compiled unrelated
    production sources, mocks and overwrite headers in the same translation
    unit.  That makes otherwise valid tests fail with duplicate symbols and
    incompatible typedefs.  This helper creates a task-scoped target that
    contains only the requested source/test/mock files while leaving the
    user's canonical QBS file untouched.

    ``file_entries`` accepts dictionaries returned by ``generate_file_paths``
    (the keys ``source_path``, ``test_impl_path``, ``test_header_path``,
    ``mock_impl_path`` and ``mock_header_path`` are used).  Absolute paths are
    intentional: the isolated project may live below ``projects/test/qbs``
    and must not depend on fragile relative-prefix calculations.
    """
    root = Path(project_root).resolve()
    qbs_root = root / "projects" / "test" / "qbs"
    # QBS stores its build graph inside the build directory.  Keep each task
    # in its own directory so a graph created for one generated project file
    # can never be restored for another task.
    isolated_root = qbs_root / ".macode"
    isolated_root.mkdir(parents=True, exist_ok=True)

    canonical_items: list[str] = []
    normalized_entries: list[dict[str, str]] = []
    for entry in file_entries:
        normalized_entry = dict(entry)
        source_value = entry.get("source_path", "")
        test_value = entry.get("test_impl_path", "")
        if source_value and test_value:
            source_path = Path(source_value).resolve()
            access_path = Path(test_value).resolve().parent / f"{source_path.stem}_test_access.c"
            if access_path.is_file():
                try:
                    access_text = access_path.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    access_text = ""
                include_pattern = rf'#include\s+["<]{re.escape(source_path.name)}[">]'
                if re.search(include_pattern, access_text):
                    normalized_entry["source_path"] = str(access_path)
                    normalized_entry["production_source_path"] = str(source_path)
                    logger.info(
                        "[QBS][app] Using test access translation unit: "
                        f"{access_path}"
                    )
        normalized_entries.append(normalized_entry)
    file_entries = normalized_entries

    for entry in file_entries:
        for key in (
            "source_path",
            "test_impl_path",
            "test_header_path",
            "mock_impl_path",
            "mock_header_path",
        ):
            value = entry.get(key, "")
            if value:
                canonical_items.append(os.path.normcase(os.path.abspath(value)))
    identity = "\0".join([task_id or "", *sorted(set(canonical_items))])
    digest = hashlib.sha256(identity.encode("utf-8", errors="replace")).hexdigest()[:12]
    module_hint = "app"
    if file_entries:
        module_hint = file_entries[0].get("module_name", "app") or "app"
    module_hint = re.sub(r"[^A-Za-z0-9_-]+", "-", module_hint).strip("-") or "app"
    product_name = f"macode-test-app-{module_hint}-{digest}"
    # Keep the build directory short. QBS appends the product and object hash
    # below this directory; using the product name at both levels can exceed
    # the Windows toolchain path limit for otherwise valid project paths.
    task_root = isolated_root / digest
    task_root.mkdir(parents=True, exist_ok=True)
    qbs_file = task_root / "test.qbs"

    # Keep include paths broad enough for normal firmware headers, but never
    # add the aggregate overwrite-inc directory.  Its module-specific mock
    # headers are the source of cross-module typedef/macro collisions; a task
    # target should use the real headers plus the generated mock include dir.
    include_dirs: list[Path] = []
    preferred_dirs = [
        root / "tests" / "mocks" / "inc",
        root / "tests" / "unit",
        root / "apps",
        root / "bsp",
        root / "managers",
        root / "libs",
        root,
    ]
    for entry in file_entries:
        for key in ("source_path", "test_impl_path", "test_header_path", "mock_impl_path", "mock_header_path"):
            value = entry.get(key, "")
            if value:
                preferred_dirs.append(Path(value).resolve().parent)

    # Add existing include-like directories below the project.  Do not walk
    # tool/build trees; those can contain thousands of generated directories.
    for base in (root / "apps", root / "bsp", root / "libs", root / "managers", root / "tests"):
        if not base.is_dir():
            continue
        try:
            for candidate in base.rglob("*"):
                if not candidate.is_dir() or candidate.name.lower() in {"build", "debug", "release", ".qbs", ".git"}:
                    continue
                if candidate.name.lower() in {"inc", "include", "headers", "src", "portable"}:
                    preferred_dirs.append(candidate)
                # FreeRTOS and vendor ports keep headers such as portmacro.h in
                # a toolchain-specific directory that is not named inc/include.
                if (candidate / "portmacro.h").is_file() or (candidate / "FreeRTOSConfig.h").is_file():
                    preferred_dirs.append(candidate)
        except OSError:
            continue

    for directory in preferred_dirs:
        try:
            resolved = directory.resolve()
        except OSError:
            continue
        if not resolved.is_dir() or "overwrite-inc" in str(resolved).lower():
            continue
        if resolved not in include_dirs:
            include_dirs.append(resolved)

    # Host tests need platform/runtime stubs even when MCU headers exist.
    # Copy only the platform allowlist, including transitive stub dependencies;
    # the aggregate directory also contains incompatible business-module mocks.
    overlay_dir = task_root / "includes" / digest
    if overlay_dir.exists():
        shutil.rmtree(overlay_dir)
    overlay_dir.mkdir(parents=True, exist_ok=True)
    overwrite_dir = root / "tests" / "mocks" / "overwrite-inc"
    if overwrite_dir.is_dir():
        safe_names = {
            "FreeRTOS.h",
            "task.h",
            "timers.h",
            "queue.h",
            "semphr.h",
            "event_groups.h",
            "stream_buffer.h",
            "message_buffer.h",
            "list.h",
            "gpio.h",
            "trace.h",
            # RTC is included by apps/Core/Inc/rtc.h through engine.c. Keep
            # the authoritative test ABI overlay ahead of production headers.
            "rtc.h",
        }
        safe_names.update(path.name for path in overwrite_dir.glob("stm32*.h") if path.is_file())
        required_stub_names = {name for name in safe_names if (overwrite_dir / name).is_file()}
        for name in sorted(required_stub_names):
            source = overwrite_dir / name
            target = overlay_dir / name
            if source.is_file() and (
                not target.exists() or target.read_bytes() != source.read_bytes()
            ):
                shutil.copyfile(source, target)
        if any(overlay_dir.iterdir()):
            include_dirs.insert(0, overlay_dir)

    # A number of firmware sources include queue.h/task.h directly.  The
    # upstream FreeRTOS headers intentionally reject that order unless
    # FreeRTOS.h was included first, which previously produced a cascade of
    # misleading type errors and caused the CLI to retry the same build.
    # Force-include the task-scoped stub when it is available so preprocessing
    # is deterministic without modifying production sources.
    force_include = overlay_dir / "FreeRTOS.h"
    force_include_flag = (
        f', "-include", "stdint.h", "-include", "{_qbs_quote_path(force_include)}"'
        if force_include.is_file()
        else ""
    )

    # Some projects keep SCP public headers outside a conventional include
    # directory.  Add the exact external-interface directory when present.
    for candidate in (
        root / "libs" / "third-party" / "midware" / "libs" / "scp" / "external-interface",
        root / "libs" / "third-party" / "midware" / "libs" / "scp" / "inc",
    ):
        if candidate.is_dir() and candidate not in include_dirs:
            include_dirs.append(candidate)

    # Locate the sibling gmock project used by the existing templates.
    _ensure_gmock_extracted(str(root))
    gmock_candidates = [
        root / "libs" / "gmock" / "gmock-lib.qbs",
        root.parent / "gmock" / "gmock-lib.qbs",
    ]
    gmock_qbs = next((candidate for candidate in gmock_candidates if candidate.is_file()), None)
    if gmock_qbs is None:
        raise FileNotFoundError(f"gmock-lib.qbs not found below {root}")

    target_defines, diagnostics = _discover_explicit_target_defines(root, file_entries)

    source_paths: list[str] = []
    test_paths: list[str] = []
    mock_paths: list[str] = []
    test_header_paths: list[str] = []
    mock_header_paths: list[str] = []
    for entry in file_entries:
        if entry.get("source_path"):
            source_paths.append(_qbs_quote_path(entry["source_path"]))
        if entry.get("test_impl_path"):
            test_paths.append(_qbs_quote_path(entry["test_impl_path"]))
        if entry.get("test_header_path"):
            test_header_paths.append(_qbs_quote_path(entry["test_header_path"]))
        if entry.get("mock_impl_path"):
            mock_paths.append(_qbs_quote_path(entry["mock_impl_path"]))
        if entry.get("mock_header_path"):
            mock_header_paths.append(_qbs_quote_path(entry["mock_header_path"]))

    def _array(values: list[str]) -> str:
        return ",\n".join(f'            "{item}"' for item in dict.fromkeys(values))

    content = f'''// Generated task-scoped QBS target. Do not edit by hand.
// Task: {task_id or "unspecified"}
import qbs

Project {{
    references: ["{_qbs_quote_path(gmock_qbs)}"]

    Application {{
        name: "{product_name}"
        Depends {{ name: "cpp" }}
        Depends {{ name: "gmock" }}
        cpp.executableSuffix: qbs.targetOS.contains("windows") ? ".exe" : ""
        cpp.dynamicLibraries: ["gcov"]
        cpp.cFlags: ["-fprofile-arcs", "-ftest-coverage"{force_include_flag}]
        cpp.cxxFlags: ["-fprofile-arcs", "-ftest-coverage"{force_include_flag}]
        cpp.defines: ["UNIT_TEST"{''.join(', "' + value + '"' for value in target_defines)}]
        cpp.includePaths: [
{_array([_qbs_quote_path(path) for path in include_dirs])}
        ]

        Group {{
            name: "Unit test executable"
            fileTagsFilter: "application"
            qbs.install: true
            qbs.installDir: "tests/"
        }}
        Group {{
            name: "Source under test"
            files: [
{_array(source_paths)}
            ]
        }}
        Group {{
            name: "Generated test sources"
            files: [
{_array(test_paths)}
            ]
        }}
        Group {{
            name: "Generated test headers"
            files: [
{_array(test_header_paths)}
            ]
        }}
        Group {{
            name: "Generated mock sources"
            files: [
{_array(mock_paths)}
            ]
        }}
        Group {{
            name: "Generated mock headers"
            files: [
{_array(mock_header_paths)}
            ]
        }}
    }}
}}
'''
    if not qbs_file.exists() or qbs_file.read_text(encoding="utf-8") != content:
        qbs_file.write_text(content, encoding="utf-8")
    return {
        "project_path": str(task_root),
        "qbs_file": str(qbs_file),
        "product_name": product_name,
        "products": [product_name],
        "defines": target_defines,
        "diagnostics": diagnostics,
    }


def isolate_app_qbs_to_sources(
    project_root: str,
    source_paths: list[str],
    *,
    platform: str = "stm32u3",
    include_optional_artifacts: bool = False,
    coverage_mode: bool = False,
    task_id: str | None = None,
) -> dict[str, Any]:
    """Create an isolated APP QBS target for the supplied source files.

    This preserves the Mabot compatibility API while using OmniAgent's
    task-scoped target implementation instead of rewriting the aggregate file.
    """
    from .paths import generate_file_paths

    entries: list[dict[str, str]] = []
    for source_path in source_paths:
        source = Path(source_path)
        real_source = str(source if source.is_absolute() else Path(project_root) / source)
        paths = generate_file_paths(
            source_filename=source.name,
            layer="app",
            project_root=project_root,
            platform=platform,
            source_path=real_source,
        )
        entries.append({**paths, "source_path": real_source})
    if not entries:
        return {
            "success": False,
            "qbs_file": "",
            "changes": [],
            "has_changes": False,
            "error": "No APP source paths supplied for QBS isolation",
        }

    target = create_isolated_app_qbs_file(project_root, entries, task_id)
    return {
        "success": True,
        "qbs_file": target.get("qbs_file", ""),
        "qbs_project_path": target.get("project_path", ""),
        "product_name": target.get("product_name", ""),
        "changes": target.get("diagnostics", []),
        "has_changes": True,
        "error": None,
        "target": target,
    }


def _compute_qbs_relative_prefix(qbs_dir: Path, target_relative_path: str) -> str:
    """Compute POSIX-style relative prefix from qbs dir to a project-relative target."""
    target_path = Path(target_relative_path)
    try:
        prefix = os.path.relpath(target_path, qbs_dir)
    except ValueError:
        prefix = str(target_path)
    return prefix.replace("\\", "/").rstrip("/") + "/"


def set_qbs_platform_type(project_root: str, platform: str) -> bool:
    """Update the platformType property in tests-platformkit.qbs to the target platform.

    Args:
        project_root: Project root path
        platform: Target platform name (e.g., "stm32u5")

    Returns:
        True if updated successfully, False otherwise
    """
    from .paths import is_platformkit_subrepo
    if is_platformkit_subrepo(project_root):
        # project_root is already platformkit subrepo root, no need for libs/platformkit prefix
        qbs_file = Path(project_root) / "project" / "test" / "qbs" / "tests-platformkit.qbs"
    else:
        # project_root is top-level project root, needs libs/platformkit prefix
        qbs_file = Path(project_root) / "libs" / "platformkit" / "project" / "test" / "qbs" / "tests-platformkit.qbs"

    if not qbs_file.exists():
        logger.warning(f"[QBS] tests-platformkit.qbs not found: {qbs_file}")
        return False

    if not platform:
        logger.warning(f"[QBS] platform is None, cannot update platformType in {qbs_file}")
        return False

    try:
        content = qbs_file.read_text(encoding="utf-8")
        original_content = content

        # Regex replace platformType property
        # Matches: property string platformType: "stm32u3" or similar variants
        pattern = r'(property\s+string\s+platformType:\s*)"[^"]*"'
        replacement = rf'\1"{platform.lower()}"'
        
        updated_content = re.sub(pattern, replacement, content)
        
        if updated_content == original_content:
            logger.warning(f"[QBS] platformType not found or already set to {platform} in {qbs_file}")
            return False
        
        qbs_file.write_text(updated_content, encoding="utf-8")
        logger.info(f"[QBS] Updated platformType to '{platform}' in {qbs_file}")
        return True
        
    except Exception as e:
        logger.error(f"[QBS] Failed to update platformType: {e}")
        return False


def _ensure_hal_qbs_file(
    project_root: str,
    platform: str = "stm32u3",
) -> Optional[str]:
    """Ensure HAL-layer build uses the top-level tests-platformkit.qbs.

    HAL subproject qbs files rely on module imports (for example gmock) defined by
    the top-level project file, so build/resolve must target tests-platformkit.qbs.
    This helper only ensures platformType is updated and returns the top-level file.
    """
    from .paths import is_platformkit_subrepo
    if is_platformkit_subrepo(project_root):
        qbs_dir = Path(project_root) / "project" / "test" / "qbs"
    else:
        # Check if project_root itself is platformkit (has .git and is the project root)
        # by checking if project/test/qbs/tests-platformkit.qbs exists directly
        candidate_direct = Path(project_root) / "project" / "test" / "qbs" / "tests-platformkit.qbs"
        if candidate_direct.exists():
            # project_root itself is platformkit -> use directly
            qbs_dir = Path(project_root) / "project" / "test" / "qbs"
        else:
            # normal top-level project with platformkit under libs/
            qbs_dir = Path(project_root) / "libs" / "platformkit" / "project" / "test" / "qbs"
    generic_qbs = qbs_dir / "tests-platformkit.qbs"

    if not generic_qbs.exists():
        # Minimal platformkit checkouts and isolated test fixtures may only
        # provide the platform-specific product file. Keep that layout
        # usable while preferring the top-level project whenever it exists.
        fallback = qbs_dir / "test-hal" / f"test-hal-{(platform or 'stm32u3').lower()}.qbs"
        if fallback.exists():
            logger.warning(
                "[QBS][hal] Top-level qbs not found; using platform product file: {}",
                fallback,
            )
            return str(fallback)
        logger.warning(f"[QBS][hal] Top-level qbs not found: {generic_qbs}")
        return None

    # Ensure gmock is extracted before build - top-level project references libs/gmock
    if not _ensure_gmock_extracted(project_root):
        logger.warning("[QBS][hal] gmock is unavailable; continue so QBS can report the dependency error")

    set_qbs_platform_type(project_root, platform)
    logger.info(f"[QBS][hal] Using top-level qbs for HAL build: {generic_qbs}")
    return str(generic_qbs)


def _resolve_hal_qbs_dir(project_root: str) -> Path:
    """Resolve the directory containing the platformkit test QBS files."""
    from .paths import is_platformkit_subrepo
    root = Path(project_root)
    direct = root / "project" / "test" / "qbs"
    if is_platformkit_subrepo(project_root) or (direct / "tests-platformkit.qbs").exists():
        return direct
    return root / "libs" / "platformkit" / "project" / "test" / "qbs"


def _resolve_hal_platform_qbs_file(
    project_root: str,
    platform: str = "stm32u3",
) -> Optional[str]:
    """Resolve an existing platform-specific HAL QBS file."""
    candidate = _resolve_hal_qbs_dir(project_root) / "test-hal" / f"test-hal-{(platform or 'stm32u3').lower()}.qbs"
    return str(candidate) if candidate.exists() else None


_HAL_SCAFFOLD_TOP_LEVEL_QBS = """\
import qbs

Project {{
    property string platformType: "{platform}"

    references: [
        "../../../../gmock/gmock-lib.qbs",
    ]

    CppApplication {{
        name: "test-hal"
        type: ["application", "autotest"]
        consoleApplication: true

        Depends {{ name: "cpp" }}
        Depends {{ name: "gmock" }}

        cpp.cxxLanguageVersion: "c++17"
        cpp.executableSuffix: qbs.targetOS.contains("windows") ? ".exe" : ""

        cpp.dynamicLibraries: ["gcov"]
        cpp.cFlags: ["-fprofile-arcs", "-ftest-coverage", "-Wno-sign-compare"]
        cpp.cxxFlags: ["-fprofile-arcs", "-ftest-coverage"]

        cpp.includePaths: [
            "../../../../../libs/platformkit/bsp/hal/" + project.platformType + "/",
            "../../../tests/mocks/" + project.platformType + "/overwrite-inc/",
            "../../../tests/mocks/" + project.platformType + "/platform-mocks/inc/",
            "../../../tests/unit/bsp/hal/" + project.platformType + "/",
        ]

        Group {{
            name: "HAL source files"
            prefix: "../../../../../libs/platformkit/bsp/hal/" + project.platformType + "/"
            files: [
            ]
        }}

        Group {{
            name: "Test case sources"
            prefix: "../../../tests/unit/bsp/hal/" + project.platformType + "/"
            files: [
            ]
        }}

        Group {{
            name: "Test mock sources"
            prefix: "../../../tests/mocks/" + project.platformType + "/platform-mocks/src/"
            files: [
            ]
        }}

        Group {{
            name: "Test mock include"
            prefix: "../../../tests/mocks/" + project.platformType + "/platform-mocks/inc/"
            files: [
            ]
        }}

        Group {{
            name: "Unit test executable"
            fileTagsFilter: "application"
            qbs.install: true
            qbs.installDir: "tests/"
        }}
    }}
}}
"""

_HAL_SCAFFOLD_PRODUCT_QBS = """\
//
// Qbs project file for HAL layer unit tests (scaffolded for uploaded sources).
// Standalone product kept for platform derivation and minimal-checkout
// fallback; the top-level tests-platformkit.qbs carries the same product.
//
import qbs

Project {{
    references: [
        "../../../../../gmock/gmock-lib.qbs",
    ]

    CppApplication {{
        name: "test-hal"
        type: ["application", "autotest"]
        consoleApplication: true

        Depends {{ name: "cpp" }}
        Depends {{ name: "gmock" }}

        cpp.cxxLanguageVersion: "c++17"
        cpp.executableSuffix: qbs.targetOS.contains("windows") ? ".exe" : ""

        cpp.dynamicLibraries: ["gcov"]
        cpp.cFlags: ["-fprofile-arcs", "-ftest-coverage", "-Wno-sign-compare"]
        cpp.cxxFlags: ["-fprofile-arcs", "-ftest-coverage"]

        cpp.includePaths: [
            "../../../../../../libs/platformkit/bsp/hal/{platform}/",
            "../../../../tests/mocks/{platform}/overwrite-inc/",
            "../../../../tests/mocks/{platform}/platform-mocks/inc/",
            "../../../../tests/unit/bsp/hal/{platform}/",
        ]

    Group {{
        name: "HAL source files"
        prefix: "../../../../../../libs/platformkit/bsp/hal/{platform}/"
        files: [
        ]
    }}

    Group {{
        name: "Test case sources"
        prefix: "../../../../tests/unit/bsp/hal/{platform}/"
        files: [
        ]
    }}

    Group {{
        name: "Test mock sources"
        prefix: "../../../../tests/mocks/{platform}/platform-mocks/src/"
        files: [
        ]
    }}

    Group {{
        name: "Test mock include"
        prefix: "../../../../tests/mocks/{platform}/platform-mocks/inc/"
        files: [
        ]
    }}

        Group {{
            name: "Unit test executable"
            fileTagsFilter: "application"
            qbs.install: true
            qbs.installDir: "tests/"
        }}
    }}
}}
"""

_SCAFFOLD_MODULE_PREFIXES = (
    "hal-", "hal_", "driver-", "driver_",
    "controller-", "controller_", "ctrl-", "ctrl_", "app-", "app_",
)


def _scaffold_module_name(source_path: str) -> str:
    """Derive the bare module name from an uploaded source file name.

    Mirrors the prefix stripping in paths.py so scaffolded file names match
    the entries update_qbs_config enables (e.g. ``hal-pwr.c`` -> ``pwr``).
    """
    stem = Path(source_path).stem
    for prefix in _SCAFFOLD_MODULE_PREFIXES:
        if stem.startswith(prefix):
            return stem[len(prefix):]
    return stem


def ensure_uploaded_project_skeleton(
    project_root: str,
    source_files: Optional[list[str]] = None,
    layer: str = "hal",
    platform: str = "stm32u3",
) -> bool:
    """Scaffold a minimal platformkit tree for uploaded-file HAL tasks.

    Repo-based tasks already provide ``libs/platformkit/project/test/qbs``;
    tasks that only upload loose .c/.h files have nothing there, so the QBS
    build context validation always fails with PROJECT_DIR_MISSING. This
    materializes the canonical layout the pipeline expects:

      libs/platformkit/bsp/hal/<platform>/                     uploaded sources
      libs/platformkit/project/test/qbs/tests-platformkit.qbs  top-level project
      libs/platformkit/project/test/qbs/test-hal/test-hal-<platform>.qbs product
      libs/platformkit/tests/unit/bsp/hal/<platform>/          generated tests
      libs/platformkit/tests/mocks/<platform>/...              generated mocks

    Returns True when the qbs project is present after the call. No-op when
    the qbs directory already exists (real repositories are untouched).
    """
    if layer != "hal":
        return False

    root = Path(project_root)
    qbs_dir = root / "libs" / "platformkit" / "project" / "test" / "qbs"
    if (qbs_dir / "tests-platformkit.qbs").exists():
        logger.debug(f"[QBS][scaffold] QBS project already present at {qbs_dir}; skip")
        return True

    platform_key = (platform or "stm32u3").lower()
    try:
        hal_src_dir = root / "libs" / "platformkit" / "bsp" / "hal" / platform_key
        product_dir = qbs_dir / "test-hal"
        test_dir = root / "libs" / "platformkit" / "tests" / "unit" / "bsp" / "hal" / platform_key
        mocks_base = root / "libs" / "platformkit" / "tests" / "mocks" / platform_key
        for directory in (
            hal_src_dir,
            product_dir,
            test_dir,
            mocks_base / "platform-mocks" / "inc",
            mocks_base / "platform-mocks" / "src",
            mocks_base / "overwrite-inc",
        ):
            directory.mkdir(parents=True, exist_ok=True)

        (qbs_dir / "tests-platformkit.qbs").write_text(
            _HAL_SCAFFOLD_TOP_LEVEL_QBS.format(platform=platform_key),
            encoding="utf-8",
        )
        (product_dir / f"test-hal-{platform_key}.qbs").write_text(
            _HAL_SCAFFOLD_PRODUCT_QBS.format(platform=platform_key),
            encoding="utf-8",
        )

        # Stage uploaded sources into the HAL source group prefix. The .c/.cpp
        # rename to "hal-<module>.<ext>" matches the file entry that
        # update_qbs_config enables for the detected module; headers keep
        # their original names so the sources' own #include lines resolve.
        copied: list[str] = []
        root_resolved = root.resolve()
        for source in source_files or []:
            src = Path(source)
            if not src.is_file():
                continue
            try:
                src.resolve().relative_to(root_resolved)
                continue  # already inside the project tree
            except ValueError:
                pass
            if src.suffix.lower() in (".c", ".cpp"):
                dest = hal_src_dir / (
                    f"hal-{_scaffold_module_name(str(src))}{src.suffix.lower()}"
                )
            else:
                dest = hal_src_dir / src.name
            shutil.copyfile(src, dest)
            copied.append(dest.name)

        _ensure_gmock_extracted(str(root))
        logger.info(
            f"[QBS][scaffold] Created platformkit skeleton at {root} "
            f"(platform={platform_key}, sources copied: {copied})"
        )
        return True
    except Exception as exc:
        logger.warning(f"[QBS][scaffold] Failed to scaffold platformkit skeleton: {exc}")
        return False


def _ensure_app_qbs_file(project_root: str, source_relative_path: Optional[str] = None) -> Optional[str]:
    """Ensure app-layer qbs exists under projects/test/qbs using the shared template.

    APP layer intentionally keeps ``Application sources.prefix`` fixed to
    ``../../../``. Backend is only responsible for ensuring the canonical
    template exists; it must not dynamically rewrite the prefix based on a
    single source file, because APP scenarios may include sources from multiple
    directories and a mutable prefix can corrupt the project.

    Args:
        project_root: Project root path
        source_relative_path: Optional source file path relative to project root.
            Kept for API compatibility and diagnostic logging only.

    Returns:
        Path to test_app.qbs file, or None on failure
    """
    qbs_dir = Path(project_root) / "projects" / "test" / "qbs"
    app_qbs = qbs_dir / "test_app.qbs"
    template_qbs = Path(__file__).resolve().parent / "templates" / "test-app.qbs.template"

    qbs_dir.mkdir(parents=True, exist_ok=True)
    if not _ensure_gmock_extracted(project_root):
        logger.warning("[QBS][app] gmock is unavailable; continue creating the canonical template")

    if source_relative_path:
        logger.info(
            "[QBS][app] Backend keeps Application sources.prefix fixed to ../../../; "
            f"skip dynamic prefix rewrite for {source_relative_path}"
        )

    if not app_qbs.exists():
        if not template_qbs.exists():
            logger.warning(f"[QBS][app] Template qbs not found: {template_qbs}")
            return None
        shutil.copyfile(template_qbs, app_qbs)
        logger.info(f"[QBS][app] Created app qbs: {app_qbs}")

    return str(app_qbs)


def _ensure_gmock_extracted(project_root: str) -> bool:
    """Ensure libs/gmock/ exists under project_root, extracting from bin/gmock.zip if needed.

    Args:
        project_root: Project root path
    """
    import zipfile as _zipfile

    # Determine correct gmock location: always place gmock as sibling of platformkit
    project_path = Path(project_root)

    # Case 1: project_root itself IS platformkit
    # platformkit root must have both bsp/ AND tests/ OR directory name is exactly "platformkit"
    is_platformkit_dir = project_path.name.lower() == "platformkit"
    has_bsp_and_tests = (project_path / "bsp").is_dir() and (project_path / "tests").is_dir()
    if is_platformkit_dir and has_bsp_and_tests:
        # platformkit at {parent}/platformkit → gmock at {parent}/gmock
        gmock_dir = project_path.parent / "gmock"
        logger.info(f"[QBS][gmock] project_root is platformkit itself ({project_path}), gmock_dir={gmock_dir} (sibling)")
    # Case 2: platformkit exists at project_root/platformkit
    elif (project_path / "platformkit").is_dir():
        # platformkit at ./platformkit → gmock at ./gmock (sibling)
        gmock_dir = project_path / "gmock"
        logger.info(f"[QBS][gmock] found platformkit at {project_path / 'platformkit'}, gmock_dir={gmock_dir} (sibling)")
    # Case 3: platformkit exists at project_root/libs/platformkit (traditional layout)
    elif (project_path / "libs" / "platformkit").is_dir():
        # platformkit at ./libs/platformkit → gmock at ./libs/gmock (sibling)
        gmock_dir = project_path / "libs" / "gmock"
        logger.info(f"[QBS][gmock] found platformkit at {project_path / 'libs' / 'platformkit'}, gmock_dir={gmock_dir} (sibling)")
    # Case 4: no platformkit found (app/common layer outside platformkit)
    else:
        # Fallback to traditional location inside project
        gmock_dir = project_path / "libs" / "gmock"
        logger.info(f"[QBS][gmock] no platformkit found in project, using fallback gmock_dir={gmock_dir}")

    gmock_expected = gmock_dir / "gmock-lib.qbs"
    if gmock_expected.exists():
        logger.debug(f"[QBS][gmock] gmock already exists at {gmock_expected}, skipping extraction")
        return True

    logger.debug(f"[QBS][gmock] gmock-lib.qbs not found at {gmock_expected}, starting extraction")

    # Search for gmock.zip: first in <project_root>/bin/, then in the workspace-level bin/ directory.
    # qbs.py lives under backend/app/agents/impl/unittest/, so parents[5] resolves to the workspace root.
    candidates = [
        Path(project_root) / "bin" / "gmock.zip",
        Path(__file__).resolve().parents[5] / "bin" / "gmock.zip",
    ]

    for idx, candidate in enumerate(candidates):
        logger.debug(f"[QBS][gmock] Searching for gmock.zip at candidate[{idx}] = {candidate} (exists: {candidate.exists()})")

    zip_path = next((p for p in candidates if p.exists()), None)
    if zip_path is None:
        logger.warning("[QBS][common] gmock.zip not found; gmock dependency may be missing (checked: {})",
                      ", ".join(str(p) for p in candidates))
        return False

    try:
        (gmock_dir.parent).mkdir(parents=True, exist_ok=True)
        with _zipfile.ZipFile(zip_path) as zf:
            # Archives created on Windows may store entry names with backslash
            # separators, which extractall turns into literal file names on
            # Linux. Normalize entry names to forward slashes and extract
            # manually so the tree materializes identically on both OSes.
            target_base = gmock_dir.parent
            for info in zf.infolist():
                name = info.filename.replace("\\", "/")
                parts = [part for part in name.split("/") if part not in ("", ".")]
                if not parts or ".." in parts or name.startswith("/"):
                    continue  # skip empty or unsafe entries
                dest = target_base.joinpath(*parts)
                if info.is_dir() or name.endswith("/"):
                    dest.mkdir(parents=True, exist_ok=True)
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(dest, "wb") as out:
                    shutil.copyfileobj(src, out)
        logger.info(f"[QBS][common] Extracted gmock from {zip_path} to {gmock_dir.parent}")
        if gmock_expected.exists():
            logger.debug(f"[QBS][gmock] Extraction completed successfully, gmock-lib.qbs created at {gmock_expected}")
        else:
            logger.warning(f"[QBS][gmock] Extraction completed but gmock-lib.qbs still not found at {gmock_expected}")
        return True
    except Exception as e:
        logger.warning(f"[QBS][common] Failed to extract gmock: {e}")
        return False


def _ensure_qbs_profile_configured(
    qbs_cmd: str,
    profile: str,
    env: Optional[dict[str, str]] = None,
) -> bool:
    """Check if QBS profile is correctly configured with valid toolchain paths.

    Returns:
        True if profile is correctly configured, False if it needs fixing
    """
    try:
        from app.core.config import get_mingw_bin_dir

        # Get current profile configuration
        result = subprocess.run(
            [qbs_cmd, "config", "--list", f"profiles.{profile}"],
            env=env,
            capture_output=True,
            text=True,
            timeout=10,
        )

        if result.returncode != 0:
            logger.warning(f"[QBS] Failed to read profile '{profile}' configuration")
            return False

        # Check if toolchain paths exist
        config_text = result.stdout
        bundled_mingw = get_mingw_bin_dir()

        # Extract toolchainInstallPath from config
        for line in config_text.split("\n"):
            if "cpp.toolchainInstallPath" in line and ":" in line:
                _, path = line.split(":", 1)
                path = path.strip().strip('"')

                # Check if path exists
                if not Path(path).exists():
                    logger.warning(f"[QBS] Profile '{profile}' toolchain path does not exist: {path}")
                    return False

                # Check if it points to bundled MinGW
                path_normalized = Path(path).resolve()
                bundled_normalized = Path(bundled_mingw).resolve()

                if path_normalized != bundled_normalized:
                    logger.warning(
                        f"[QBS] Profile '{profile}' points to external toolchain: {path}\n"
                        f"      Expected bundled toolchain: {bundled_mingw}"
                    )
                    return False

                logger.info(f"[QBS] Profile '{profile}' is correctly configured")
                return True

        logger.warning(f"[QBS] Profile '{profile}' missing toolchainInstallPath")
        return False

    except Exception as e:
        logger.warning(f"[QBS] Failed to check profile configuration: {e}")
        return False


def _fix_qbs_profile(
    qbs_cmd: str,
    profile: str,
    env: Optional[dict[str, str]] = None,
) -> bool:
    """Fix QBS profile to use bundled MinGW toolchain.

    Returns:
        True if profile was fixed successfully, False otherwise
    """
    try:
        from app.core.config import get_mingw_bin_dir

        mingw_bin = get_mingw_bin_dir()
        if not Path(mingw_bin).exists():
            logger.error(f"[QBS] Bundled MinGW not found at: {mingw_bin}")
            return False

        mingw_bin_posix = mingw_bin.replace("\\", "/")

        # Configuration keys to update
        config_updates = {
            "cpp.toolchainInstallPath": mingw_bin_posix,
            "cpp.compilerPath": f"{mingw_bin_posix}/g++.exe",
            "cpp.archiverPath": f"{mingw_bin_posix}/ar.exe",
            "cpp.assemblerPath": f"{mingw_bin_posix}/as.exe",
            "cpp.nmPath": f"{mingw_bin_posix}/nm.exe",
            "cpp.objcopyPath": f"{mingw_bin_posix}/objcopy.exe",
            "cpp.stripPath": f"{mingw_bin_posix}/strip.exe",
            "cpp.compilerName": "g++.exe",
            "qbs.toolchainType": "mingw",
            "qbs.targetPlatform": "windows",
        }

        logger.info(f"[QBS] Fixing profile '{profile}' to use bundled MinGW: {mingw_bin}")

        success_count = 0
        for key, value in config_updates.items():
            full_key = f"profiles.{profile}.{key}"
            result = subprocess.run(
                [qbs_cmd, "config", full_key, value],
                env=env,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                success_count += 1
            else:
                logger.warning(f"[QBS] Failed to set {full_key}: {result.stderr}")

        if success_count == len(config_updates):
            logger.info(f"[QBS] Successfully fixed profile '{profile}' ({success_count}/{len(config_updates)} keys)")
            return True
        else:
            logger.warning(f"[QBS] Partially fixed profile '{profile}' ({success_count}/{len(config_updates)} keys)")
            return False

    except Exception as e:
        logger.error(f"[QBS] Failed to fix profile '{profile}': {e}")
        return False


def _ensure_common_qbs_file(
    project_root: str,
    source_relative_path: Optional[str] = None,
) -> Optional[str]:
    """Ensure the canonical common-layer test_common.qbs exists.

    Common layer uses a single aggregate QBS entry at
    ``projects/test/qbs/test_common.qbs``. The backend should create that file
    from a shared template instead of generating an ad-hoc minimal project, so
    that first-time creation stays aligned with the real project layout used by
    prompt rules and skills.

    Args:
        project_root: Project root (or standalone file directory).
        source_relative_path: Source file path relative to project_root.
            Kept for diagnostic logging only.

    Returns:
        Path to test_common.qbs, or None on failure.
    """
    qbs_dir = Path(project_root) / "projects" / "test" / "qbs"
    common_qbs = qbs_dir / "test_common.qbs"
    template_qbs = Path(__file__).resolve().parent / "templates" / "test-common.qbs.template"

    qbs_dir.mkdir(parents=True, exist_ok=True)
    if not _ensure_gmock_extracted(project_root):
        logger.warning("[QBS][common] gmock is unavailable; continue creating the canonical template")

    if source_relative_path:
        logger.info(
            "[QBS][common] Backend keeps aggregate common-layer qbs layout fixed; "
            f"skip dynamic prefix rewrite for {source_relative_path}"
        )

    if not common_qbs.exists():
        if not template_qbs.exists():
            logger.warning(f"[QBS][common] Template qbs not found: {template_qbs}")
            return None
        try:
            shutil.copyfile(template_qbs, common_qbs)
            logger.info(f"[QBS][common] Created common qbs from template: {common_qbs}")
        except Exception as e:
            logger.warning(f"[QBS][common] Failed to create {common_qbs}: {e}")
            return None

    return str(common_qbs)


def configure_common_qbs_target(
    project_root: str,
    source_path: str,
    file_paths: dict[str, str],
) -> dict[str, Any]:
    """Populate the common-layer QBS target with exact backend-resolved paths.

    The common template uses three fixed prefixes. Replacing each group's file
    list with the current task's entries prevents stale aggregate entries from
    being compiled and removes the need for the CLI to discover or edit QBS.
    """
    qbs_file_str = _ensure_common_qbs_file(project_root, source_path)
    result: dict[str, Any] = {
        "success": False,
        "qbs_file": qbs_file_str or "",
        "has_changes": False,
        "error": None,
    }
    if not qbs_file_str:
        result["error"] = "Failed to ensure common QBS template"
        return result

    root = Path(project_root).resolve()
    group_roots = {
        "Application sources": root,
        "Common test sources": root / "tests" / "unit" / "common",
        "Common mock sources": root / "tests" / "mocks" / "common",
    }

    def _relative_entry(path_value: str, base: Path) -> str:
        candidate = Path(path_value)
        if not candidate.is_absolute():
            candidate = root / candidate
        try:
            return candidate.resolve().relative_to(base.resolve()).as_posix()
        except ValueError:
            return candidate.name

    group_entries = {
        "Application sources": [_relative_entry(source_path, group_roots["Application sources"])],
        "Common test sources": [
            _relative_entry(file_paths[key], group_roots["Common test sources"])
            for key in ("test_impl_path", "test_header_path")
            if file_paths.get(key)
        ],
        "Common mock sources": [
            _relative_entry(file_paths[key], group_roots["Common mock sources"])
            for key in ("mock_impl_path", "mock_header_path")
            if file_paths.get(key)
        ],
    }

    qbs_file = Path(qbs_file_str)
    try:
        content = qbs_file.read_text(encoding="utf-8")
        original_content = content
        # GMock exports its cpp include paths through Depends. The product's
        # custom includePaths property is not exposed as gmock.includePaths.
        content = content.replace(".concat(gmock.includePaths)", "")
        include_match = re.search(r"cpp\.includePaths:\s*\[", content)
        include_directories = [Path(source_path).resolve().parent]
        include_directories.extend(
            Path(file_paths[key]).resolve().parent
            for key in ("test_header_path", "mock_header_path") if file_paths.get(key)
        )
        include_entries = [
            json.dumps(directory.as_posix()) for directory in dict.fromkeys(include_directories)
            if json.dumps(directory.as_posix()) not in content
        ]
        if include_match and include_entries:
            content = (
                content[:include_match.end()] + "\n            "
                + ",\n            ".join(include_entries) + ","
                + content[include_match.end():]
            )
        for group_name, entries in group_entries.items():
            prefix = "../../../" + group_roots[group_name].relative_to(root).as_posix().strip(".")
            prefix = prefix.rstrip("/") + "/"
            content = re.sub(
                rf'(Group\s*\{{\s*name:\s*"{re.escape(group_name)}"\s*prefix:\s*)"[^"]*"',
                lambda match: match.group(1) + json.dumps(prefix), content,
            )
            group_pattern = (
                rf'(Group\s*\{{\s*name:\s*"{re.escape(group_name)}"'
                r'[^}]*?files:\s*\[)([^\]]*?)(\])'
            )
            group_match = re.search(group_pattern, content, re.DOTALL)
            if not group_match:
                result["error"] = f"QBS group not found: {group_name}"
                return result
            normalized_entries = list(dict.fromkeys(entry for entry in entries if entry))
            files_section = ""
            if normalized_entries:
                files_section = "\n" + "".join(
                    f'                "{entry}",\n' for entry in normalized_entries
                ) + "            "
            content = (
                content[: group_match.start(2)]
                + files_section
                + content[group_match.end(2) :]
            )

        result["has_changes"] = content != original_content
        if result["has_changes"]:
            qbs_file.write_text(content, encoding="utf-8")
        result["success"] = True
        logger.info(
            f"[QBS][common] Prepared task target at {qbs_file} "
            f"with {sum(len(entries) for entries in group_entries.values())} entries"
        )
        return result
    except Exception as exc:
        result["error"] = f"Failed to configure common QBS target: {exc}"
        logger.error(result["error"])
        return result


def resolve_qbs_project_path(project_root: str, layer: str = "hal", platform: str = "stm32u3") -> str:
    """Resolve the QBS project directory path (the argument for qbs build -d).

    Three scenarios:
    - Scenario 1 (platformkit sub-repo root): project_root/project/test/qbs/
    - Scenario 2 (project root, app/common layer): project_root/projects/test/qbs/
    - Scenario 2 (project root, hal/driver/midware layer): project_root/libs/platformkit/project/test/qbs/
    - Scenario 3 (standalone file): keep the expected layer-specific path and let callers verify existence

    Returns:
        Absolute path string of the QBS project directory.
    """
    from .paths import is_platformkit_subrepo
    if is_platformkit_subrepo(project_root):
        # Scenario 1: platformkit sub-repo root, QBS is at project/test/qbs/
        return str(Path(project_root) / "project" / "test" / "qbs")

    if layer in ("app", "common"):
        return str(Path(project_root) / "projects" / "test" / "qbs")

    return str(Path(project_root) / "libs" / "platformkit" / "project" / "test" / "qbs")


def resolve_qbs_build_root(
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
) -> str:
    """Resolve the canonical build root for the selected QBS project."""
    qbs_project_dir = Path(resolve_qbs_project_path(project_root, layer, platform))
    if layer == "app":
        return str(qbs_project_dir / ".qbs-build-app")
    if layer == "common":
        return str(qbs_project_dir / ".qbs-build-common")
    return str(qbs_project_dir)


def resolve_qbs_build_dir(
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
) -> str:
    """Resolve the default configuration directory under the QBS build root."""
    return str(Path(resolve_qbs_build_root(project_root, layer, platform)) / "default")


def validate_app_qbs_no_forbidden_libs(project_root: str) -> dict[str, Any]:
    """Report APP QBS references to the platformkit repository."""
    app_qbs = Path(project_root) / "projects" / "test" / "qbs" / "test_app.qbs"
    result: dict[str, Any] = {
        "valid": True,
        "qbs_file": str(app_qbs),
        "violations": [],
        "warnings": [],
    }
    if not app_qbs.exists():
        return result
    try:
        content = app_qbs.read_text(encoding="utf-8")
    except OSError as exc:
        result["valid"] = False
        result["violations"] = [f"Failed to read {app_qbs}: {exc}"]
        return result
    for line in content.splitlines():
        if APP_FORBIDDEN_PLATFORMKIT_RE.search(line.replace("\\", "/")):
            reference = line.strip()
            result["violations"].append(reference)
            result["warnings"].append(f"APP QBS references libs/platformkit: {reference}")
    return result


def resolve_qbs_file_path(
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
) -> Optional[str]:
    """Find the .qbs file path for the corresponding layer.

    Returns:
        Absolute path to .qbs file, or None if not found.
    """
    # Ensure platform is not None
    if not platform:
        platform = "stm32u3"
        logger.warning(f"[QBS] platform is None, defaulting to {platform}")

    # common layer: auto-create and return test_common.qbs
    if layer == "common":
        return _ensure_common_qbs_file(project_root)

    from .paths import is_platformkit_subrepo
    if is_platformkit_subrepo(project_root):
        # Scenario 1: platformkit sub-repo root, use top-level tests-platformkit.qbs
        full = Path(project_root) / "project" / "test" / "qbs" / "tests-platformkit.qbs"
        if full.exists():
            # Ensure gmock is extracted at sibling level (parallel to platformkit)
            if not _ensure_gmock_extracted(project_root):
                logger.warning(
                    f"[QBS][{layer}] gmock is unavailable; continue resolving the QBS project"
                )
            if layer == "hal":
                try:
                    set_qbs_platform_type(project_root, platform)
                except Exception:
                    pass
            return str(full)

    candidates = _QBS_CANDIDATES.get(layer, _QBS_CANDIDATES["hal"])
    platform_lower = platform.lower()

    # Ensure gmock is extracted before returning - all layers depend on gmock
    if not _ensure_gmock_extracted(project_root):
        logger.warning(
            f"[QBS][{layer}] gmock is unavailable; continue resolving the QBS project"
        )

    for template in candidates:
        rel = template.format(platform=platform_lower)
        full = Path(project_root) / rel
        if full.exists():
            return str(full)
    
    # If platform-specific HAL QBS doesn't exist in expected location, try to create it from stm32u3 template
    # This ensures the file exists for the top-level project to include it
    if layer == "hal" and platform_lower != "stm32u3":
        # Check if stm32u3 template exists
        template_rel = f"libs/platformkit/project/test/qbs/test-hal/test-hal-stm32u3.qbs"
        template_full = Path(project_root) / template_rel
        target_rel = f"libs/platformkit/project/test/qbs/test-hal/test-hal-{platform_lower}.qbs"
        target_full = Path(project_root) / target_rel
        # Only create if target doesn't exist yet (don't overwrite existing files)
        if template_full.exists() and not target_full.exists():
            try:
                target_full.parent.mkdir(parents=True, exist_ok=True)
                # Read template content and replace platform-specific paths
                content = template_full.read_text(encoding="utf-8")

                # Replace test/mock paths (these follow platform naming)
                updated_content = content.replace(
                    "../../../../tests/mocks/stm32u3/",
                    f"../../../../tests/mocks/{platform_lower}/"
                )
                updated_content = updated_content.replace(
                    "../../../../tests/unit/bsp/hal/stm32u3/",
                    f"../../../../tests/unit/bsp/hal/{platform_lower}/"
                )

                # Replace HAL source prefix (but NOT vendorhal paths)
                # Only replace the HAL source Group prefix, not vendorhal include paths
                updated_content = re.sub(
                    r'(Group\s*\{\s*name:\s*"HAL source files"\s*prefix:\s*"../../../../../../libs/platformkit/bsp/hal/)stm32u3/',
                    rf'\1{platform_lower}/',
                    updated_content
                )

                # IMPORTANT: Do NOT replace vendorhal paths - different platforms use different SDK structures
                # STM32U3 uses Realtek Ameba SDK, STM32U5 uses ST HAL, etc.
                # The vendorhal include paths should be manually configured per platform

                target_full.write_text(updated_content, encoding="utf-8")
                logger.info(f"[QBS][hal] Created platform-specific QBS {target_rel} from stm32u3 template (test/mock paths replaced, vendorhal preserved)")
            except Exception as e:
                logger.warning(f"[QBS][hal] Failed to create {target_rel} from template: {e}")
                # continue to fallback even if creation fails, don't return the created file
    
    # For HAL layer, always return the top-level tests-platformkit.qbs
    # as explained in the header comment - subproject files depend on gmock from top-level
    if layer == "hal":
        return _ensure_hal_qbs_file(project_root, platform)
    
    return None


def resolve_qbs_build_context(
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
) -> dict[str, Any]:
    """Resolve canonical QBS project/build context for unittest flows."""
    # Ensure platform is not None
    if not platform:
        platform = "stm32u3"
        logger.warning(f"[QBS] platform is None, defaulting to {platform}")

    qbs_project_path = resolve_qbs_project_path(project_root, layer, platform)
    qbs_file = resolve_qbs_file_path(project_root, layer, platform)

    # HAL layer products use generic product names (e.g., test-hal)
    # Platform differentiation is handled by QBS file references
    # Other layers use generic product names
    base_product_name = _QBS_PRODUCT_MAP.get(layer, f"test-{layer}") if layer else ""
    product_name = base_product_name

    products = [product_name] if product_name else []
    return {
        "project_path": qbs_project_path,
        "qbs_file": qbs_file,
        "product_name": product_name,
        "products": products,
    }


def validate_qbs_build_context(
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
) -> dict[str, Any]:
    """Validate the canonical QBS build context before invoking tools or repair loops."""
    root = Path(project_root)
    base_result: dict[str, Any] = {
        "ready": False,
        "project_path": resolve_qbs_project_path(project_root, layer, platform),
        "qbs_file": None,
        "product_name": _QBS_PRODUCT_MAP.get(layer, f"test-{layer}") if layer else "",
        "products": [],
        "error": None,
        "error_code": None,
        "retryable": False,
    }

    if not root.is_dir():
        base_result.update({
            "error": f"Firmware project root not found: {root}",
            "error_code": QBS_ERROR_PROJECT_ROOT_MISSING,
        })
        return base_result

    qbs_dir = Path(base_result["project_path"])
    if layer not in ("app", "common") and not qbs_dir.is_dir():
        base_result.update({
            "error": (
                f"Required QBS project directory is missing: {qbs_dir}. "
                "Restore the firmware repository QBS files before retrying."
            ),
            "error_code": QBS_ERROR_PROJECT_DIR_MISSING,
        })
        return base_result

    build_context = resolve_qbs_build_context(project_root, layer, platform)
    base_result.update(build_context)
    qbs_dir = Path(build_context["project_path"])
    if not qbs_dir.is_dir():
        base_result.update({
            "error": (
                f"Required QBS project directory is missing: {qbs_dir}. "
                "Restore the firmware repository QBS files before retrying."
            ),
            "error_code": QBS_ERROR_PROJECT_DIR_MISSING,
        })
        return base_result

    qbs_file = build_context.get("qbs_file")
    if not qbs_file or not Path(qbs_file).is_file():
        base_result.update({
            "error": (
                f"Required QBS project file is missing for layer '{layer}' in {qbs_dir}. "
                "Restore or initialize the layer QBS project before retrying."
            ),
            "error_code": QBS_ERROR_PROJECT_FILE_MISSING,
        })
        return base_result

    base_result.update({"ready": True, "retryable": True})
    return base_result


# ========== QBS config update ==========

def _build_files_to_enable(
    module_name: str,
    layer: str,
    platform: str,
    external_mock_modules: Optional[list[str]] = None,
    source_relative_path: Optional[str] = None,
    enable_mock: bool = True,
) -> tuple[list[str], dict[str, str]]:
    """Build list of files to enable in QBS config and their Group mappings.

    Args:
        module_name: Module name (e.g., ``pwr`` from ``hal-pwr.c``)
        layer: Code layer (hal / driver / controller / app)
        platform: Target platform (stm32u3 / rtl8722fam / nrf52)
        external_mock_modules: List of external mock module names to enable
        source_relative_path: Source file path relative to project root (required for APP layer)

    Returns:
        Tuple of (files_to_enable, file_to_group)
    """
    if layer == "hal":
        source_file = f"hal-{module_name}.c"
        test_impl = f"tc-hal-{module_name}.cpp"
        test_header = f"tc-hal-{module_name}.h"
        if platform and "rtl" in platform.lower():
            mock_impl = f"mock-ameba-{module_name}.cpp"
            mock_header = f"mock-ameba-{module_name}.h"
        elif platform and "stm32" in platform.lower():
            mock_impl = f"mock-stm32-hal-{module_name}.cpp"
            mock_header = f"mock-stm32-hal-{module_name}.h"
        elif platform and "nrf" in platform.lower():
            mock_impl = f"mock-nrf-{module_name}.cpp"
            mock_header = f"mock-nrf-{module_name}.h"
        else:
            pfx = platform if platform else "stm32"
            mock_impl = f"mock-{pfx}-{module_name}.cpp"
            mock_header = f"mock-{pfx}-{module_name}.h"
    elif layer == "driver":
        source_file = f"driver-{module_name}.c"
        test_impl = f"driver-{module_name}/tc-driver-{module_name}.cpp"
        test_header = f"driver-{module_name}/tc-driver-{module_name}.h"
        mock_impl = f"mock-hal-{module_name}.cpp"
        mock_header = f"mock-hal-{module_name}.h"
    elif layer == "midware_controller":
        source_file = f"controller-{module_name}.c"
        test_impl = f"tc-controller-{module_name}.cpp"
        test_header = f"tc-controller-{module_name}.h"
        mock_impl = f"mock-driver-{module_name}.cpp"
        mock_header = f"mock-driver-{module_name}.h"
    elif layer == "midware_driver":
        source_file = f"driver-{module_name}.c"
        test_impl = f"tc-driver-{module_name}.cpp"
        test_header = f"tc-driver-{module_name}.h"
        mock_impl = f"mock-driver-{module_name}-type0.cpp"
        mock_header = f"mock-driver-{module_name}-type0.h"
    elif layer == "app":
        # APP layer keeps ``Application sources.prefix`` fixed to ``../../../``.
        # Therefore source entries must use full project-relative paths when known,
        # instead of mutating the Group prefix to match a single module directory.
        if source_relative_path:
            source_file = source_relative_path.replace("\\", "/")

            # Extract app layer subdirectory structure to match paths.py logic
            from .paths import extract_app_layer_subdir
            app_subdir = extract_app_layer_subdir(source_relative_path, module_name)

            if app_subdir:
                # Use extracted subdirectory structure
                # Examples: bsp/usb/tc-app-usb.cpp, midware/protocol/tc-app-mqtt.cpp
                test_impl = f"{app_subdir}/tc-app-{module_name}.cpp"
                test_header = f"{app_subdir}/tc-app-{module_name}.h"
            else:
                # Fallback to app-<module> for flat files
                test_impl = f"app-{module_name}/tc-app-{module_name}.cpp"
                test_header = f"app-{module_name}/tc-app-{module_name}.h"
        else:
            source_file = f"app-{module_name}.c"
            test_impl = f"app-{module_name}/tc-app-{module_name}.cpp"
            test_header = f"app-{module_name}/tc-app-{module_name}.h"
        mock_impl = f"mock-{module_name}.cpp"
        mock_header = f"mock-{module_name}.h"
    else:
        source_file = f"{module_name}.c"
        test_impl = f"tc-{module_name}.cpp"
        test_header = f"tc-{module_name}.h"
        mock_impl = f"mock-{module_name}.cpp"
        mock_header = f"mock-{module_name}.h"

    files = [source_file, test_impl, test_header]

    is_midware = layer.startswith("midware_")
    if layer == "app":
        source_group = "Application sources"
        test_group = "App test sources"
        mock_group = "App mock sources"
    else:
        source_group = "Midware source files" if is_midware else "HAL source files"
        test_group = "Test case sources"
        mock_group = "Test mock sources"

    group_map = {
        source_file: source_group,
        test_impl: test_group,
        test_header: test_group,
    }
    if enable_mock:
        files.extend((mock_impl, mock_header))
        group_map[mock_impl] = mock_group
        group_map[mock_header] = "Test mock include"
    if enable_mock and layer == "app":
        group_map[mock_header] = "App mock include"

    if enable_mock and external_mock_modules and layer == "hal":
        for ext in external_mock_modules:
            if platform and platform.startswith("stm32"):
                ext_impl = f"mock-stm32-hal-{ext}.cpp"
                ext_hdr = f"mock-stm32-hal-{ext}.h"
            else:
                pfx = platform if platform else "stm32"
                ext_impl = f"mock-{pfx}-hal-{ext}.cpp"
                ext_hdr = f"mock-{pfx}-hal-{ext}.h"
            if ext_impl not in files:
                files.append(ext_impl)
                group_map[ext_impl] = "Test mock sources"
            if ext_hdr not in files:
                files.append(ext_hdr)
                group_map[ext_hdr] = "Test mock include"

    return files, group_map


def _build_include_paths_to_enable(
    module_name: str,
    layer: str,
    project_root: str,
) -> list[str]:
    """Build include paths that must exist in cpp.includePaths for the module."""
    if layer != "driver":
        return []

    from .paths import is_platformkit_subrepo

    if is_platformkit_subrepo(project_root):
        return [
            f"../../../../bsp/drivers/driver-{module_name}/inc/",
        ]
    return [
        f"../../../../../../libs/platformkit/bsp/drivers/driver-{module_name}/inc/",
    ]


def update_qbs_config(
    module_name: str,
    layer: str,
    platform: str,
    project_root: str,
    external_mock_modules: Optional[list[str]] = None,
    source_relative_path: Optional[str] = None,
    enable_mock: bool = True,
) -> dict[str, Any]:
    """Update QBS config file to uncomment or add test-related files.

    Args:
        module_name: Module name (e.g., ``pwr`` from ``hal-pwr.c``)
        layer: Code layer (hal / driver / controller / app)
        platform: Target platform (stm32u3 / rtl8722fam / nrf52)
        project_root: Project root path
        external_mock_modules: List of external mock module names to enable
        source_relative_path: Source file path relative to project root (required for APP layer)

    Returns:
        ``{"success": bool, "qbs_file": str, "changes": list, "has_changes": bool, "error": str|None}``
    """
    result: dict[str, Any] = {
        "success": False,
        "qbs_file": None,
        "changes": [],
        "has_changes": False,
        "error": None,
    }

    if layer == "app":
        # APP layer backend fallback is restricted to template initialization only.
        # Do not dynamically repair/append entries here; CLI owns project mutation
        # in CLI mode, while backend remains a verifier/recovery layer.
        app_qbs = _ensure_app_qbs_file(project_root, source_relative_path)
        result["qbs_file"] = app_qbs or ""
        result["success"] = app_qbs is not None
        result["has_changes"] = False
        result["error"] = None if app_qbs is not None else "Failed to ensure app qbs template"
        logger.info("[QBS][app] Skip backend QBS repair/update; template ensure only")
        return result

    qbs_file_str = resolve_qbs_file_path(project_root, layer, platform)
    if qbs_file_str is None:
        logger.info(f"[QBS] QBS file not found for layer '{layer}', skipping")
        result["qbs_file"] = ""
        return result

    qbs_file = Path(qbs_file_str)
    result["qbs_file"] = str(qbs_file)

    try:
        qbs_content = qbs_file.read_text(encoding="utf-8")
        original_content = qbs_content
    except Exception as e:
        result["error"] = f"Failed to read QBS file: {e}"
        logger.error(result["error"])
        return result

    files_to_enable, file_to_group = _build_files_to_enable(
        module_name, layer, platform, external_mock_modules, source_relative_path,
        enable_mock=enable_mock,
    )

    def _entry_state(target: str) -> str:
        pat_commented = rf'(?m)^\s*//\s*"{re.escape(target)}",?\s*$'
        pat_commented_full_path = rf'(?m)^\s*//\s*"[^"]*/{re.escape(target)}",?\s*$'
        pat_active = rf'(?m)^\s*"{re.escape(target)}",?\s*$'
        if re.search(pat_commented, qbs_content) or re.search(pat_commented_full_path, qbs_content):
            return "commented"
        if re.search(pat_active, qbs_content):
            return "active"
        # Detect CLI-written full-path entries like "apps/non-secure/usb/src/app-usb.c"
        # that end with the same relative path — treat them as already present to avoid
        # appending a duplicate entry that causes path doubling.
        pat_full_path = rf'(?m)^\s*"[^"]*/{re.escape(target)}",?\s*$'
        if re.search(pat_full_path, qbs_content):
            return "full_path"
        return "missing"

    def _replace_entry(old_target: str, new_target: str) -> bool:
        nonlocal qbs_content
        patterns = [
            rf'(?m)^(\s*)//\s*"{re.escape(old_target)}"(,?\s*)$',
            rf'(?m)^(\s*)//\s*"[^"]*/{re.escape(old_target)}"(,?\s*)$',
            rf'(?m)^(\s*)"{re.escape(old_target)}"(,?\s*)$',
            rf'(?m)^(\s*)"[^"]*/{re.escape(old_target)}"(,?\s*)$',
        ]
        for pattern in patterns:
            new_content, count = re.subn(pattern, rf'\1"{new_target}"\2', qbs_content, count=1)
            if count:
                qbs_content = new_content
                return True
        return False

    def _remove_entry(target: str) -> bool:
        nonlocal qbs_content
        patterns = [
            rf'(?m)^\s*//\s*"{re.escape(target)}",?\s*\n?',
            rf'(?m)^\s*//\s*"[^"]*/{re.escape(target)}",?\s*\n?',
            rf'(?m)^\s*"{re.escape(target)}",?\s*\n?',
            rf'(?m)^\s*"[^"]*/{re.escape(target)}",?\s*\n?',
        ]
        removed = False
        for pattern in patterns:
            new_content, count = re.subn(pattern, '', qbs_content)
            if count:
                qbs_content = new_content
                removed = True
        return removed

    include_paths_to_enable = _build_include_paths_to_enable(module_name, layer, project_root)

    include_paths_match = re.search(
        r'(cpp\.includePaths:\s*\[)(.*?)(\]\s*\.concat\s*\(\s*gmock\.includePaths\s*\))',
        qbs_content,
        re.DOTALL,
    )
    if not include_paths_match and include_paths_to_enable:
        logger.warning(
            f"[QBS] cpp.includePaths block not found in expected format for {qbs_file}; "
            "skipping include-path repair"
        )
    if include_paths_match:
        include_section = include_paths_match.group(2)
        include_entries = re.findall(r'"([^"]+)"', include_section)
        for include_path in include_paths_to_enable:
            if include_path in include_entries:
                continue
            insert_after = None
            for entry in include_entries:
                if entry.lower() < include_path.lower():
                    insert_after = entry
                else:
                    break
            if insert_after:
                ins_pat = rf'((?:\s*)"{re.escape(insert_after)}",?\s*\n)'
                new_include_section = re.sub(
                    ins_pat,
                    f'\\1        "{include_path}",\n',
                    include_section,
                    count=1,
                )
            else:
                if include_section.strip():
                    new_include_section = f'\n        "{include_path}",{include_section}'
                else:
                    new_include_section = f'\n        "{include_path}",\n'
            qbs_content = (
                qbs_content[: include_paths_match.start()]
                + include_paths_match.group(1)
                + new_include_section
                + include_paths_match.group(3)
                + qbs_content[include_paths_match.end() :]
            )
            include_section = new_include_section
            include_entries.append(include_path)
            include_entries.sort(key=str.lower)
            result["changes"].append(
                {"include_path": include_path, "action": "add_include_path"}
            )
            logger.info(f"[QBS] Added include path '{include_path}'")

    # A build entry for a file that does not exist on disk fails the whole
    # product (tests generated for a header-only module such as hal-gpio.h
    # have no hal-gpio.c implementation). Gate only the SOURCE entry on
    # disk presence — test/mock entries are materialized from in-memory CLI
    # content later inside the compile loop, so they are not on disk yet at
    # this point.
    source_entry = files_to_enable[0] if files_to_enable else None
    _existing_basenames: Optional[set] = None

    def _entry_exists_on_disk(filename: str) -> bool:
        nonlocal _existing_basenames
        if not project_root:
            return True
        # Full project-relative entries resolve directly against the root.
        if "/" in filename:
            return os.path.isfile(os.path.join(project_root, filename))
        if _existing_basenames is None:
            names: set = set()
            walk_root = os.path.join(project_root, "libs", "platformkit")
            if not os.path.isdir(walk_root):
                walk_root = project_root
            skip_dirs = {"default", "release", ".qbs", "node_modules", ".git", "__pycache__"}
            for root, dirs, disk_files in os.walk(walk_root):
                dirs[:] = [d for d in dirs if d not in skip_dirs]
                names.update(disk_files)
            _existing_basenames = names
        return filename in _existing_basenames

    for filename in files_to_enable:
        entry_state = _entry_state(filename)
        legacy_driver_entry = None
        duplicate_owner_entry = None

        if filename == source_entry and not _entry_exists_on_disk(filename):
            if entry_state == "missing":
                logger.info(
                    f"[QBS] Skipping source entry '{filename}': file not on disk "
                    f"(header-only module has no implementation to compile)"
                )
                result["changes"].append(
                    {"file": filename, "action": "skip_missing_source"}
                )
                continue
            if entry_state in {"active", "full_path"} and _remove_entry(filename):
                logger.info(
                    f"[QBS] Removed source entry '{filename}': active in QBS "
                    f"but file not on disk"
                )
                result["changes"].append(
                    {"file": filename, "action": "remove_missing_source"}
                )
                continue

        if layer == "driver":
            legacy_driver_entry = filename.rsplit("/", 1)[-1] if "/" in filename else filename.replace("mock-hal-", "mock-driver-")

            # Check for duplicate mock ownership: if current driver's mock-hal-{module}.cpp
            # conflicts with an external HAL mock that already provides those symbols
            if external_mock_modules and filename.startswith("mock-hal-"):
                for ext_mod in external_mock_modules:
                    # If current module's mock file might duplicate an external HAL mock
                    ext_mock_file = f"mock-hal-{ext_mod}.cpp"
                    if ext_mock_file != filename and _entry_state(ext_mock_file) in {"active", "full_path", "commented"}:
                        # Check if current file is the conflicting one that should be removed
                        duplicate_owner_entry = filename
                        logger.info(
                            f"[QBS] Detected potential duplicate ownership: "
                            f"'{filename}' may conflict with external mock '{ext_mock_file}'"
                        )
                        break

        if duplicate_owner_entry:
            # Remove the duplicate mock source that conflicts with external HAL mock
            if _remove_entry(duplicate_owner_entry):
                result["changes"].append(
                    {
                        "file": duplicate_owner_entry,
                        "action": "remove",
                        "reason": f"duplicate_ownership_conflicts_with_external_mock",
                    }
                )
                logger.info(f"[QBS] Removed duplicate owner '{duplicate_owner_entry}' due to external mock conflict")
            continue

        if legacy_driver_entry and legacy_driver_entry != filename:
            legacy_state = _entry_state(legacy_driver_entry)
            if entry_state in {"active", "full_path", "commented"} and legacy_state in {"active", "commented", "full_path"}:
                if _remove_entry(legacy_driver_entry):
                    result["changes"].append(
                        {"file": legacy_driver_entry, "action": "remove", "replaced_by": filename}
                    )
                legacy_state = "missing"
            if entry_state == "missing" and legacy_state in {"active", "commented", "full_path"}:
                if _replace_entry(legacy_driver_entry, filename):
                    if _remove_entry(legacy_driver_entry):
                        result["changes"].append(
                            {"file": legacy_driver_entry, "action": "remove", "replaced_by": filename}
                        )
                    result["changes"].append(
                        {"file": filename, "action": "replace", "from": legacy_driver_entry}
                    )
                    continue

        if entry_state == "active" or entry_state == "full_path":
            pass  # already present (relative or full-path form), skip
        elif entry_state == "commented":
            if filename == source_entry and not _entry_exists_on_disk(filename):
                logger.info(f"[QBS] Keeping '{filename}' commented: file not on disk")
                result["changes"].append(
                    {"file": filename, "action": "skip_missing_source"}
                )
            else:
                qbs_content = re.sub(
                    rf'(?m)^(\s*)//\s*"{re.escape(filename)}"(,?\s*)$',
                    rf'\1"{filename}"\2',
                    qbs_content,
                    count=1,
                )
                result["changes"].append({"file": filename, "action": "uncomment"})
        else:
            group_name = file_to_group.get(filename)
            if group_name:
                group_pat = (
                    rf'(Group\s*\{{\s*name:\s*"{re.escape(group_name)}"'
                    r'[^}]*?files:\s*\[)([^\]]*?)(\])'
                )
                group_match = re.search(group_pat, qbs_content, re.DOTALL)
                if group_match:
                    files_section = group_match.group(2)
                    file_entries = re.findall(r'(?://\s*)?"([^"]+)"', files_section)
                    insert_after = None
                    for entry in file_entries:
                        if entry.lower() < filename.lower():
                            insert_after = entry
                        else:
                            break
                    if insert_after:
                        ins_pat = rf'((?://\s*)?"{re.escape(insert_after)}",?\s*\n)'
                        new_section = re.sub(
                            ins_pat,
                            f'\\1            "{filename}",\n',
                            files_section,
                            count=1,
                        )
                    else:
                        if files_section.strip():
                            new_section = f'\n            "{filename}",{files_section}'
                        else:
                            new_section = f'\n            "{filename}",\n        '
                    qbs_content = (
                        qbs_content[: group_match.start()]
                        + group_match.group(1)
                        + new_section
                        + group_match.group(3)
                        + qbs_content[group_match.end() :]
                    )
                    result["changes"].append(
                        {"file": filename, "action": "add", "group": group_name}
                    )
                    logger.info(f"[QBS] Added '{filename}' to group '{group_name}'")

    result["has_changes"] = qbs_content != original_content

    if result["has_changes"]:
        try:
            qbs_file.write_text(qbs_content, encoding="utf-8")
            result["success"] = True
            logger.info(f"[QBS] Updated {qbs_file}: {len(result['changes'])} changes")
        except Exception as e:
            result["error"] = f"Failed to write QBS file: {e}"
            logger.error(result["error"])
            return result
    else:
        result["success"] = True
        logger.info(f"[QBS] No changes needed for {qbs_file}")

    return result


def _is_stale_build_graph_error(stderr: str) -> bool:
    """Return True when stderr indicates a stale/corrupted QBS build graph or profile mismatch."""
    stderr_lower = (stderr or "").lower()
    return (
        "cannot use stored build graph" in stderr_lower
        or "stored build graph" in stderr_lower and "cannot be found" in stderr_lower
        or "build graph" in stderr_lower and "cannot be found" in stderr_lower
        or "stored build graph" in stderr_lower and "incompatible" in stderr_lower
        or "build graph" in stderr_lower and "incompatible" in stderr_lower
        or "build graph restore" in stderr_lower and "failed" in stderr_lower
        or "stored build graph" in stderr_lower and "project file" in stderr_lower and "input file" in stderr_lower
        or "restoring build graph from disk" in stderr_lower and "input file is" in stderr_lower
        # Profile mismatch detection
        or ("current profile is" in stderr_lower and "but profile" in stderr_lower and "was used when last building" in stderr_lower)
        or ("profile" in stderr_lower and "was used when last building" in stderr_lower and "use" in stderr_lower and "resolve" in stderr_lower)
        # Toolchain path errors (cached invalid compiler paths)
        or "could not find selected c++ compiler" in stderr_lower
        or "could not find selected c compiler" in stderr_lower
        or ("ensure that the compiler is properly installed" in stderr_lower and "cpp.toolchaininstallpath" in stderr_lower)
    )


def _is_build_graph_lock_error(stderr: str) -> bool:
    """Return whether QBS reports a build graph lock held by another process."""
    stderr_lower = (stderr or "").lower()
    return "cannot lock build graph file" in stderr_lower and "already locked" in stderr_lower


def _extract_lock_holder_pid(stderr: str) -> Optional[int]:
    """Extract the process id reported as the QBS build graph lock holder."""
    match = re.search(
        r"already locked by\s+'?[^']*'?\s*\(pid\s+(\d+)\)",
        stderr or "",
        re.IGNORECASE,
    )
    return int(match.group(1)) if match else None


def _pid_is_running(pid: int) -> bool:
    """Best-effort check for a live process without raising platform-specific errors."""
    if not pid:
        return False
    try:
        if os.name == "nt":
            import ctypes

            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if not handle:
                return False
            ctypes.windll.kernel32.CloseHandle(handle)
            return True
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _find_build_graph_lock_file(qbs_build_root: Path) -> Optional[Path]:
    """Locate a QBS build graph lock file below the selected build root."""
    candidates = (
        qbs_build_root / "default" / "default.bg.lock",
        qbs_build_root / "default.bg.lock",
    )
    for candidate in candidates:
        if candidate.exists():
            return candidate
    try:
        return next(qbs_build_root.rglob("*.bg.lock"), None)
    except OSError:
        return None


def _task_process_env(task_id: Optional[str]) -> Optional[dict[str, str]]:
    """Return a subprocess environment carrying an exact task owner marker."""
    if not task_id:
        return None
    env = os.environ.copy()
    env["FWDEV_TASK_ID"] = str(task_id)
    env["UNITTEST_TASK_ID"] = str(task_id)
    return env


def _run_qbs_with_lock_retry(
    cmd: list[str],
    *,
    cwd: str,
    env: Optional[dict[str, str]] = None,
    timeout: int = QBS_BUILD_TIMEOUT_SECONDS,
    qbs_build_root: Optional[Path] = None,
    max_attempts: int = 4,
) -> subprocess.CompletedProcess:
    """Run QBS and recover stale build graph locks when possible."""
    delays = (2, 5, 10, 15)
    last_result: Optional[subprocess.CompletedProcess] = None
    for attempt in range(max(1, max_attempts)):
        last_result = subprocess.run(
            cmd,
            cwd=cwd,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        if last_result.returncode == 0 or not _is_build_graph_lock_error(last_result.stderr):
            return last_result

        holder_pid = _extract_lock_holder_pid(last_result.stderr)
        logger.warning(
            "[QBS][lock] Build graph lock contention (attempt {}/{}; holder PID={})",
            attempt + 1,
            max_attempts,
            holder_pid,
        )
        if qbs_build_root is not None and holder_pid and not _pid_is_running(holder_pid):
            lock_file = _find_build_graph_lock_file(qbs_build_root)
            if lock_file is not None:
                try:
                    lock_file.unlink()
                    logger.info("[QBS][lock] Removed stale lock file: {}", lock_file)
                    continue
                except OSError as exc:
                    logger.warning("[QBS][lock] Could not remove stale lock file {}: {}", lock_file, exc)
        if attempt + 1 < max_attempts:
            import time

            time.sleep(delays[min(attempt, len(delays) - 1)])
    assert last_result is not None
    return last_result


# ========== QBS build execution ==========

def run_qbs_build(
    layer: str,
    platform: str,
    project_root: str,
    build_profile: str = "mingw",
    enable_coverage: bool = False,
    qbs_project_path: str | None = None,
    qbs_file: str | None = None,
    product_name: str | None = None,
    task_id: str | None = None,
) -> Dict[str, Any]:
    """Run QBS build with automatic cleanup for corrupted build graph and fallback.

    Args:
        layer: Code layer (hal/driver/controller/app)
        platform: Target platform
        project_root: Project root path
        build_profile: Build profile (default: mingw)
        enable_coverage: Enable coverage instrumentation (adds -fprofile-arcs -ftest-coverage)

    Returns:
        {success, build_dir, output, errors, error}
    """
    result: Dict[str, Any] = {
        "success": False,
        "build_dir": None,
        "output": "",
        "errors": [],
        "error": None,
        "error_code": None,
        "retryable": False,
        "project_path": None,
    }
    process_env = _task_process_env(task_id)

    build_context = validate_qbs_build_context(project_root, layer, platform)
    if qbs_project_path:
        build_context.update({
            "project_path": qbs_project_path,
            "qbs_file": qbs_file or build_context.get("qbs_file"),
            "product_name": product_name or build_context.get("product_name", ""),
            "products": [product_name] if product_name else build_context.get("products", []),
            "ready": Path(qbs_project_path).is_dir()
            and (not qbs_file or Path(qbs_file).is_file()),
            "error": None,
            "error_code": None,
        })
    result["project_path"] = build_context.get("project_path")
    if not build_context.get("ready"):
        result["error"] = build_context.get("error")
        result["error_code"] = build_context.get("error_code")
        result["retryable"] = bool(build_context.get("retryable", False))
        return result

    qbs_file = build_context["qbs_file"]
    product_name = build_context["product_name"]
    qbs_dir = Path(build_context["project_path"])
    result["retryable"] = True

    # Windows executable lookup does not use the child process's PATH. Resolve
    # the executable explicitly while preserving the configured build profile.
    from app.core.config import get_qbs_bin_dir, get_resolved_qbs_path

    qbs_cmd = get_resolved_qbs_path()
    qbs_bin_dir = Path(get_qbs_bin_dir())
    if process_env is None:
        process_env = os.environ.copy()
    if qbs_bin_dir.is_dir():
        current_path = process_env.get("PATH", "")
        process_env["PATH"] = os.pathsep.join(
            part for part in (str(qbs_bin_dir), current_path) if part
        )
    logger.info("[QBS] Using resolved executable: {}", qbs_cmd)

    # Coverage flags to add to both resolve and build commands
    coverage_flags = []
    if enable_coverage:
        logger.info("[QBS] Enabling coverage instrumentation (gcov)")
        # Note: Coverage flags are already defined in the QBS project file (test_common.qbs)
        # The project file contains: cpp.cFlags: ["-fprofile-arcs", "-ftest-coverage"]
        # We only need to set debug info and disable optimization
        coverage_flags = [
            "modules.cpp.debugInformation:true",
            "modules.cpp.optimization:none",
        ]
    
    # When coverage flags are added, must run 'qbs resolve' first to reconfigure
    if enable_coverage:
        logger.info("[QBS] Running qbs resolve with coverage flags...")
        resolve_cmd = [qbs_cmd, "resolve", "-d", str(qbs_dir), f"profile:{build_profile}"]
        if qbs_file:
            resolve_cmd.extend(["-f", qbs_file])
        # Note: Don't add product filter to resolve, only to build
        resolve_cmd.extend(coverage_flags)
        
        try:
            resolve_result = subprocess.run(
                resolve_cmd, cwd=str(qbs_dir),
                env=process_env,
                capture_output=True, text=True,
                encoding="utf-8", errors="replace",
                timeout=QBS_BUILD_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            result["error"] = "QBS resolve timeout (300s)"
            result["error_code"] = QBS_ERROR_TIMEOUT
            return result
        except FileNotFoundError:
            result["error"] = "QBS command not found"
            result["error_code"] = QBS_ERROR_TOOL_MISSING
            result["retryable"] = False
            return result
        except Exception as exc:
            result["error"] = f"QBS resolve exception: {exc}"
            result["error_code"] = QBS_ERROR_EXCEPTION
            return result
        result["output"] += f"[RESOLVE-COVERAGE]\n{resolve_result.stdout}\n{resolve_result.stderr}\n"
        
        if resolve_result.returncode != 0:
            logger.error(f"[QBS] Resolve with coverage flags failed: {resolve_result.stderr[:500]}")
            # Don't fail immediately - try to proceed with build, which has fallback logic
            logger.warning("[QBS] Continuing to build despite resolve failure...")
    
    build_cmd = [qbs_cmd, "build", f"profile:{build_profile}"]
    if qbs_file:
        build_cmd.extend(["-f", qbs_file])
    if product_name:
        build_cmd.extend(["-p", product_name])
    build_cmd.extend(coverage_flags)

    try:
        build_result = _run_qbs_with_lock_retry(
            build_cmd,
            cwd=str(qbs_dir),
            env=process_env,
            timeout=QBS_BUILD_TIMEOUT_SECONDS,
            qbs_build_root=qbs_dir,
        )
        result["output"] += f"[BUILD]\n{build_result.stdout}\n{build_result.stderr}\n"

        # Auto-clean corrupted/stale build graph (including cross-machine path mismatch)
        stderr_text = build_result.stderr or ""
        stale_graph = _is_stale_build_graph_error(stderr_text)
        if stale_graph:
            logger.warning("[QBS] Corrupted build graph detected, cleaning entire build directory and retrying...")
            # Clean all potential build directories to ensure fresh start
            build_dirs_to_clean = [
                qbs_dir / "default",
                qbs_dir / "debug",
                qbs_dir / "release",
                qbs_dir / ".qbs",
            ]
            # Also add profile-specific directories
            for profile in ["mingw", "gcc", "clang", "msvc", "stm32"]:
                build_dirs_to_clean.extend([
                    qbs_dir / f"build-{platform}-{profile}",
                    qbs_dir / f"build-{layer}-{profile}",
                ])

            cleaned_any = False
            for build_dir in build_dirs_to_clean:
                if build_dir.exists():
                    try:
                        shutil.rmtree(build_dir)
                        logger.info(f"[QBS] Cleaned: {build_dir}")
                        cleaned_any = True
                    except Exception as e:
                        logger.warning(f"[QBS] Clean failed for {build_dir}: {e}")

            if not cleaned_any:
                logger.warning("[QBS] No build directories were cleaned")

            # Rebuild directly after cleanup. QBS resolves the fresh graph as part of build.
            logger.info("[QBS] Rebuilding after build graph cleanup...")
            # QBS 3.3 has no --clean-build option.  The stale graph was
            # removed above, so rerun the original command against a fresh
            # build directory.
            build_result = _run_qbs_with_lock_retry(
                list(build_cmd),
                cwd=str(qbs_dir),
                env=process_env,
                timeout=QBS_BUILD_TIMEOUT_SECONDS,
                qbs_build_root=qbs_dir,
            )
            result["output"] += f"[REBUILD]\n{build_result.stdout}\n{build_result.stderr}\n"

        # Fall back to full build when product does not exist
        if build_result.returncode != 0:
            stderr_lower = (build_result.stderr or "").lower()
            if "unknown product" in stderr_lower or "no product" in stderr_lower or "no such product" in stderr_lower:
                logger.warning(f"[QBS] Product '{product_name}' not found, building all")
                fallback_cmd = [qbs_cmd, "build", f"profile:{build_profile}"]
                if qbs_file:
                    fallback_cmd.extend(["-f", qbs_file])
                # Add coverage flags to fallback build as well
                fallback_cmd.extend(coverage_flags)
                build_result = subprocess.run(
                    fallback_cmd,
                    cwd=str(qbs_dir), env=process_env,
                    capture_output=True, text=True,
                    encoding="utf-8", errors="replace",
                    timeout=QBS_BUILD_TIMEOUT_SECONDS,
                )
                result["output"] += f"[FALLBACK]\n{build_result.stdout}\n{build_result.stderr}\n"

        if build_result.returncode != 0:
            from .parsers import parse_qbs_build_errors
            result["errors"] = parse_qbs_build_errors(build_result.stderr)
            first_error = result["errors"][0] if result["errors"] else build_result.stderr
            result["error"] = f"QBS build failed: {first_error[:1000]}"
            result["error_code"] = QBS_ERROR_BUILD_FAILED
            logger.error(f"[QBS] {result['error']}")
            return result

        result["success"] = True
        result["build_dir"] = str(qbs_dir / "default")

    except subprocess.TimeoutExpired:
        result["error"] = "QBS build timeout (300s)"
        result["error_code"] = QBS_ERROR_TIMEOUT
    except FileNotFoundError:
        result["error"] = "QBS command not found"
        result["error_code"] = QBS_ERROR_TOOL_MISSING
        result["retryable"] = False
    except Exception as e:
        result["error"] = f"QBS build exception: {e}"
        result["error_code"] = QBS_ERROR_EXCEPTION

    return result


_TEST_RUN_TIMEOUT_SECONDS = 60
_MAX_TIMEOUT_EXCLUDED_TESTS = 8
_GTEST_RUN_LINE_RE = re.compile(r"^\[\s+RUN\s+\]\s+(\S+)", re.MULTILINE)
_GTEST_COMPLETION_LINE_RE = re.compile(r"^\[\s+(?:OK|FAILED)\s+\]", re.MULTILINE)


def _extract_hanging_test(partial_output: str) -> Optional[str]:
    """Identify the test whose body was active when output stopped."""
    matches = list(_GTEST_RUN_LINE_RE.finditer(partial_output or ""))
    if not matches:
        return None
    last_run = matches[-1]
    if _GTEST_COMPLETION_LINE_RE.search(partial_output, last_run.end()):
        return None
    return last_run.group(1)


def _run_gtest_attempt(
    cmd: list[str],
    cwd: str,
    env: dict[str, str],
    timeout_s: int,
) -> tuple[Optional[int], str, str, bool]:
    """Run one GoogleTest process and preserve output when its deadline expires."""
    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    try:
        stdout, stderr = proc.communicate(timeout=timeout_s)
        return proc.returncode, stdout or "", stderr or "", False
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            stdout, stderr = proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            stdout, stderr = "", ""
        return None, stdout or "", stderr or "", True


def run_test_executable(
    layer: str,
    platform: str,
    project_root: str,
    build_profile: str = "mingw",
    qbs_project_path: str | None = None,
    qbs_file: str | None = None,
    product_name: str | None = None,
) -> Dict[str, Any]:
    """Run GTest executable, supporting JSON output and text fallback.

    Args:
        layer: Code layer (hal / driver / controller / app)
        platform: Target platform
        project_root: Project root path
        build_profile: Build profile

    Returns:
        ``{success, passed, failed, total, skipped, duration_ms, test_cases, output, error}``
    """
    result: Dict[str, Any] = {
        "success": False,
        "executable": None,
        "total": 0,
        "passed": 0,
        "failed": 0,
        "skipped": 0,
        "duration_ms": 0,
        "test_cases": [],
        "output": "",
        "stderr": "",
        "error": None,
        "returncode": None,
        "failure_kind": None,
    }

    from .paths import is_platformkit_subrepo
    libs_qbs_dir = Path(project_root) / "libs" / "platformkit" / "project" / "test" / "qbs"
    subrepo_qbs_dir = Path(project_root) / "project" / "test" / "qbs"
    projects_qbs_dir = Path(project_root) / "projects" / "test" / "qbs"

    # APP layer uses a standalone QBS project, not platformkit
    if layer == "app":
        app_qbs_dir = projects_qbs_dir
        if app_qbs_dir.exists():
            qbs_dir = app_qbs_dir
            primary_build_dir = app_qbs_dir / ".qbs-build-app" / "default"
            if not primary_build_dir.exists():
                primary_build_dir = app_qbs_dir / "default"
        else:
            qbs_dir = libs_qbs_dir
            primary_build_dir = qbs_dir / "default"
    elif layer == "common":
        common_qbs_dir = projects_qbs_dir
        if common_qbs_dir.exists():
            qbs_dir = common_qbs_dir
            primary_build_dir = common_qbs_dir / "default"
        else:
            qbs_dir = libs_qbs_dir
            primary_build_dir = qbs_dir / "default"
    elif is_platformkit_subrepo(project_root):
        qbs_dir = subrepo_qbs_dir
        primary_build_dir = qbs_dir / "default"
    else:
        qbs_dir = libs_qbs_dir
        primary_build_dir = qbs_dir / "default"
        # Also check for debug build directory
        debug_build_dir = qbs_dir / "debug"
        if debug_build_dir.exists() and not primary_build_dir.exists():
            primary_build_dir = debug_build_dir

    build_context = resolve_qbs_build_context(project_root, layer, platform)
    if qbs_project_path:
        build_context.update({
            "project_path": qbs_project_path,
            "qbs_file": qbs_file or build_context.get("qbs_file"),
            "product_name": product_name or build_context.get("product_name", ""),
            "products": [product_name] if product_name else build_context.get("products", []),
        })
        # A task-scoped project owns its build graph and artifacts.
        qbs_dir = Path(qbs_project_path)
        primary_build_dir = qbs_dir / "default"
    product_name = build_context.get("product_name", "")

    layer_exe_map = {
        "hal": "test-hal.exe",
        "driver": "test-driver.exe",
        "midware_controller": "test-controller.exe",
        "midware_driver": "test-drivers.exe",
        "app": "test-app.exe",
        "common": "test-common.exe",
    }
    if layer not in layer_exe_map:
        result["error"] = f"Unknown layer: {layer}"
        return result

    exe_candidates: List[str] = []
    if product_name:
        exe_candidates.extend([f"{product_name}.exe", product_name])
    legacy_exe_name = layer_exe_map[layer]
    legacy_exe_stem = Path(legacy_exe_name).stem
    for candidate_name in [legacy_exe_name, legacy_exe_stem]:
        if candidate_name not in exe_candidates:
            exe_candidates.append(candidate_name)

    legacy_build_dirs: List[Path] = [
        qbs_dir / f"build-{platform}-{build_profile}",
        qbs_dir / f"build-{layer}-{build_profile}",
    ]
    if layer == "midware_driver":
        legacy_build_dirs.insert(0, qbs_dir / f"build-drivers-{build_profile}")

    exe_path: Optional[Path] = None
    
    # Check both default and debug build directories
    build_dirs_to_check = [primary_build_dir]
    if primary_build_dir.name == "default":
        debug_dir = primary_build_dir.parent / "debug"
        if debug_dir.exists():
            build_dirs_to_check.append(debug_dir)
    elif primary_build_dir.name == "debug":
        default_dir = primary_build_dir.parent / "default"
        if default_dir.exists():
            build_dirs_to_check.append(default_dir)
    
    for exe_name in exe_candidates:
        candidate_paths: List[Path] = []
        
        # Check all build directories (default, debug, etc.)
        for build_dir in build_dirs_to_check:
            candidate_paths.extend([
                build_dir / "install-root" / "tests" / exe_name,
            ])
            if product_name:
                candidate_paths.extend(build_dir.glob(f"{product_name}.*/{exe_name}"))
        
        # Check legacy build directories
        for build_dir in legacy_build_dirs:
            candidate_paths.extend([
                build_dir / build_profile / exe_name,
                build_dir / exe_name,
                build_dir / "bin" / exe_name,
            ])
        candidate_paths.append(qbs_dir / exe_name)

        for candidate in candidate_paths:
            if isinstance(candidate, Path) and candidate.exists():
                # Ensure it's a file, not a directory
                if not candidate.is_file():
                    continue
                # On Windows, verify it has .exe extension or is executable
                if os.name == 'nt' and not str(candidate).lower().endswith('.exe'):
                    continue
                exe_path = candidate
                logger.info(f"[TEST] Found executable at: {exe_path}")
                break
        if exe_path is not None:
            break

    # If still not found, do a wildcard search in install-root/tests directories
    if exe_path is None:
        logger.info(f"[TEST] Candidate names failed, searching for any test executable in build directories...")
        for build_dir in build_dirs_to_check:
            tests_dir = build_dir / "install-root" / "tests"
            if tests_dir.exists() and tests_dir.is_dir():
                # Find all .exe files in tests directory
                exe_files = list(tests_dir.glob("*.exe"))
                if exe_files:
                    # Prefer files matching the layer pattern (e.g., test-hal-*.exe)
                    layer_pattern = f"test-{layer}*.exe" if layer != "midware_driver" else "test-driver*.exe"
                    matching = [f for f in exe_files if f.match(layer_pattern)]
                    if matching:
                        exe_path = matching[0]
                        logger.info(f"[TEST] Found executable via wildcard search: {exe_path}")
                        break
                    # Fallback: use any .exe file found
                    exe_path = exe_files[0]
                    logger.info(f"[TEST] Found executable (fallback): {exe_path}")
                    break
    
    if exe_path is None:
        exe_path = primary_build_dir / "install-root" / "tests" / legacy_exe_name

    build_dir = exe_path.parent if exe_path.exists() else primary_build_dir
    result["executable"] = str(exe_path)

    if not exe_path.exists():
        result["error"] = f"Test executable not found: {exe_path}"
        logger.warning(f"[TEST] Executable not found: {exe_path}")
        return result
    
    # Additional validation
    if exe_path.is_dir():
        result["error"] = f"Path is a directory, not an executable: {exe_path}"
        logger.error(f"[TEST] Path is a directory: {exe_path}")
        return result
    
    if not os.access(str(exe_path), os.X_OK):
        result["error"] = f"File exists but is not executable: {exe_path}"
        logger.error(f"[TEST] File not executable (permissions issue): {exe_path}")
        return result

    try:
        logger.info(f"[TEST] Running test executable: {exe_path}")
        logger.debug(f"[TEST] Executable size: {exe_path.stat().st_size} bytes")
        json_output_file = build_dir / "test_results.json"

        # Remove stale results
        if json_output_file.exists():
            try:
                json_output_file.unlink()
            except OSError:
                pass

        # Ensure bundled MinGW bin directory is in PATH so test executable can find runtime DLLs
        from app.core.config import get_mingw_bin_dir, get_qbs_bin_dir
        env = os.environ.copy()
        prepend_paths = []
        
        mingw_bin_dir = get_mingw_bin_dir()
        qbs_bin_dir = get_qbs_bin_dir()
        
        if mingw_bin_dir and os.path.isdir(mingw_bin_dir):
            prepend_paths.append(mingw_bin_dir)
        if qbs_bin_dir and os.path.isdir(qbs_bin_dir):
            prepend_paths.append(qbs_bin_dir)
        
        if prepend_paths:
            current_path = env.get("PATH", "")
            path_items = current_path.split(os.pathsep) if current_path else []
            new_paths = [p for p in prepend_paths if p not in path_items]
            if new_paths:
                new_path = os.pathsep.join(new_paths)
                if current_path:
                    new_path += os.pathsep + current_path
                env["PATH"] = new_path

        timeout_excluded: list[str] = []
        timed_out = False
        returncode: Optional[int] = None
        stdout = ""
        stderr = ""
        while True:
            test_cmd = [str(exe_path), f"--gtest_output=json:{json_output_file}"]
            if timeout_excluded:
                test_cmd.append("--gtest_filter=-" + ":-".join(timeout_excluded))
            returncode, stdout, stderr, timed_out = _run_gtest_attempt(
                test_cmd, str(build_dir), env, _TEST_RUN_TIMEOUT_SECONDS
            )
            if not timed_out:
                break
            hanging = _extract_hanging_test(f"{stdout}\n{stderr}")
            logger.error(
                "[TEST] Execution timeout after %ss; hanging test: %s",
                _TEST_RUN_TIMEOUT_SECONDS,
                hanging or "unidentified",
            )
            if hanging is None or hanging in timeout_excluded:
                result["error"] = (
                    f"Test execution timeout ({_TEST_RUN_TIMEOUT_SECONDS}s); "
                    "hanging test could not be identified from partial output"
                )
                result["failure_kind"] = "execution_timeout"
                break
            timeout_excluded.append(hanging)
            if json_output_file.exists():
                try:
                    json_output_file.unlink()
                except OSError:
                    pass
            if len(timeout_excluded) >= _MAX_TIMEOUT_EXCLUDED_TESTS:
                result["error"] = (
                    f"Too many hanging tests ({len(timeout_excluded)}); "
                    "stopped isolating further timeouts"
                )
                result["failure_kind"] = "execution_timeout"
                break

        result["returncode"] = returncode
        result["exit_code"] = returncode
        result["stderr"] = stderr
        result["output"] = stdout if not stderr else f"{stdout}\n[stderr]\n{stderr}".strip()

        # Windows uses 0xC0000135 when the executable cannot load a runtime
        # DLL (usually MinGW libstdc++/libgcc). Report this as an actionable
        # environment failure instead of an unexplained zero-test failure.
        if returncode in (-1073741515, 0xC0000135):
            result["error_code"] = "runtime_dependency_missing"
            result["error"] = (
                "Test executable could not start because a runtime DLL is missing "
                "(Windows status 0xC0000135). Add the compiler runtime bin directory "
                "to PATH before running tests."
            )
            result["success"] = False
            logger.error("[TEST] Runtime dependency missing for %s", exe_path)
            return result

        if timed_out:
            result["success"] = False
        elif json_output_file.exists():
            try:
                json_data = json.loads(json_output_file.read_text(encoding="utf-8"))
                result["total"] = json_data.get("tests", 0)
                result["failed"] = json_data.get("failures", 0)
                result["passed"] = result["total"] - result["failed"]
                result["failed_cases"] = []
                result["duration_ms"] = _parse_time_to_ms(json_data.get("time", "0"))

                for suite in json_data.get("testsuites", []):
                    suite_name = suite.get("name", "Unknown")
                    for tc in suite.get("testsuite", []):
                        tc_name = tc.get("name", "Unknown")
                        status = tc.get("status", "RUN")
                        failures = tc.get("failures") or []
                        # GoogleTest reports status=RUN even for completed tests;
                        # the presence of a failures array is the authoritative
                        # per-test result.
                        passed = not failures and status not in {"FAILED", "ERROR"}
                        if not passed:
                            result["failed_cases"].append(
                                f"{suite_name}.{tc_name}" if suite_name else tc_name
                            )
                        result["test_cases"].append({
                            "suite": suite_name,
                            "name": tc_name,
                            "status": status,
                            "time_ms": _parse_time_to_ms(tc.get("time", "0")),
                            "passed": passed,
                        })

                # A valid JSON report can still represent failed tests.
                result["success"] = returncode == 0 and result["failed"] == 0
                if not result["success"]:
                    result["error"] = (
                        f"Test executable exited with code {returncode}; "
                        f"{result['failed']} of {result['total']} tests failed"
                    )
                logger.info(f"[TEST] Tests passed: {result['passed']}/{result['total']}")
            except json.JSONDecodeError:
                logger.warning("[TEST] Failed to parse JSON output, falling back to text")
                result["success"] = returncode == 0
                result.update(_parse_gtest_text_output(stdout))
                if not result["success"]:
                    result["error"] = (
                        f"Test executable exited with code {returncode}: "
                        f"{(stderr or stdout)[-1000:]}"
                    )
        else:
            result["success"] = returncode == 0
            result.update(_parse_gtest_text_output(stdout))
            if not result["success"]:
                result["error"] = (
                    f"Test executable exited with code {returncode}: "
                    f"{(stderr or stdout)[-1000:]}"
                )

        if timeout_excluded:
            result["output"] = (
                f"{result['output']}\n[TIMEOUT-ISOLATION] Hanging tests marked as failed and excluded "
                f"(limit {_TEST_RUN_TIMEOUT_SECONDS}s each):\n"
                + "\n".join(f"- {name} (execution timeout)" for name in timeout_excluded)
            ).strip()
            if not timed_out:
                for name in timeout_excluded:
                    suite_name, _, case_name = name.partition(".")
                    result["test_cases"].append({
                        "suite": suite_name or "Unknown",
                        "name": case_name or name,
                        "status": "TIMEOUT",
                        "time_ms": _TEST_RUN_TIMEOUT_SECONDS * 1000,
                        "passed": False,
                    })
                result["total"] = max(
                    int(result.get("total") or 0),
                    int(result.get("passed") or 0) + int(result.get("failed") or 0),
                ) + len(timeout_excluded)
                result["failed"] = int(result.get("failed") or 0) + len(timeout_excluded)
                result["success"] = False
                result["failure_kind"] = "execution_timeout"
                if not result.get("error"):
                    result["error"] = (
                        f"{len(timeout_excluded)} test(s) timed out: "
                        + ", ".join(timeout_excluded)
                    )

        # A GTest binary that exits non-zero on failures skips gcov's exit
        # dump, so failing suites leave no .gcda files at all (verified
        # empirically: passing runs flush .gcda, failing runs write none).
        # Re-run each passing case ON ITS OWN: generated suites are often
        # order-dependent, so a bulk passing-only filter can still fail (and
        # one failure suppresses the whole dump). Per-test runs accumulate
        # .gcda across every case that passes in isolation.
        passing_cases = [
            f"{tc.get('suite')}.{tc.get('name')}"
            for tc in result.get("test_cases", [])
            if tc.get("passed") and tc.get("status") != "TIMEOUT"
        ]
        if not timed_out and result.get("failed") and passing_cases:
            flushed = 0
            for case in passing_cases:
                flush_cmd = [str(exe_path), f"--gtest_filter={case}"]
                try:
                    flush_proc = subprocess.run(
                        flush_cmd,
                        cwd=str(build_dir),
                        env=env,
                        capture_output=True,
                        timeout=_TEST_RUN_TIMEOUT_SECONDS,
                    )
                    if flush_proc.returncode == 0:
                        flushed += 1
                except (subprocess.TimeoutExpired, OSError):
                    logger.warning("[TEST] Coverage flush re-run failed for {}", case)
            logger.info(
                "[TEST] Coverage flush re-run: {}/{} passing case(s) exited cleanly "
                "and flushed .gcda",
                flushed,
                len(passing_cases),
            )

    except FileNotFoundError:
        result["error"] = f"Executable not found or not runnable: {exe_path}"
        logger.error(f"[TEST] Executable not runnable: {exe_path}")
    except Exception as e:
        result["error"] = f"Test execution exception: {e}"
        logger.error(f"[TEST] Execution exception: {e}")

    return result


def _coverage_artifact_signature(path: Path) -> tuple[int, int]:
    """Return a lightweight signature used to distinguish fresh gcov output."""
    try:
        stat = path.stat()
        return stat.st_mtime_ns, stat.st_size
    except OSError:
        return 0, 0


def _snapshot_gcov_artifacts(build_dir: Path) -> dict[str, tuple[int, int]]:
    """Snapshot existing gcov reports before invoking gcov."""
    return {
        str(path.resolve()): _coverage_artifact_signature(path)
        for path in build_dir.rglob("*.gcov")
    }


def _read_gcov_source(gcov_file: Path) -> Optional[str]:
    """Read the source identity embedded in a gcov report header."""
    try:
        with gcov_file.open("r", encoding="utf-8", errors="ignore") as stream:
            for _ in range(20):
                line = stream.readline()
                if not line:
                    break
                match = re.match(r"\s*-:\s*0:Source:(.+)", line)
                if match:
                    return match.group(1).strip()
    except OSError:
        return None
    return None


def _coverage_source_matches(reported_source: str, expected_source: str) -> bool:
    """Match gcov source headers against absolute and project-relative paths."""
    reported = reported_source.strip().replace("\\", "/").lower().rstrip("/")
    expected = expected_source.strip().replace("\\", "/").lower().rstrip("/")
    if not reported or not expected:
        return False
    if reported.rsplit("/", 1)[-1] != expected.rsplit("/", 1)[-1]:
        return False
    if "/" not in expected:
        return True
    return (
        reported == expected
        or reported.endswith(f"/{expected}")
        or expected.endswith(f"/{reported}")
    )


def _is_non_target_coverage_artifact(path: Path, source_stem: str) -> bool:
    """Exclude test, mock, and stub reports from production-source coverage."""
    name = path.name.lower()
    stem = source_stem.lower()
    return stem in name and name.startswith(("mock-", "tc-", "stub-"))


def _find_best_coverage_artifact(
    build_dir: Path,
    source_file: str,
    previous_snapshot: Optional[dict[str, tuple[int, int]]] = None,
    generated_paths: Optional[set[str]] = None,
) -> tuple[Optional[Path], Optional[str]]:
    """Find a fresh gcov artifact whose source header matches the requested file."""
    source_name = Path(source_file).name
    source_stem = Path(source_file).stem
    generated_keys: set[str] = set()
    for raw_path in generated_paths or set():
        try:
            generated_keys.add(str(Path(raw_path).resolve()).casefold())
        except OSError:
            generated_keys.add(str(raw_path).casefold())
    candidates = []
    for path in build_dir.rglob("*.gcov"):
        if _is_non_target_coverage_artifact(path, source_stem):
            continue
        resolved_path = str(path.resolve())
        if previous_snapshot is not None:
            was_generated = resolved_path.casefold() in generated_keys
            if (
                previous_snapshot.get(resolved_path) == _coverage_artifact_signature(path)
                and not was_generated
            ):
                continue
        reported_source = _read_gcov_source(path)
        if not reported_source or not _coverage_source_matches(reported_source, source_file):
            continue
        candidates.append(path)
    if not candidates:
        return None, None

    def _score(path: Path) -> tuple[int, int, float]:
        name_lower = path.name.lower()
        score = 0
        if name_lower.endswith(f"{source_name.lower()}.gcov"):
            score += 4
        if source_name.lower() in name_lower:
            score += 3
        if source_stem.lower() in name_lower:
            score += 2
        if "#" in path.name:
            score += 1
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        return (score, len(name_lower), mtime)

    ranked = sorted(candidates, key=_score, reverse=True)
    best = ranked[0]
    best_score = _score(best)
    if best_score[0] <= 0:
        return None, None

    if len(ranked) > 1 and _score(ranked[1]) == best_score:
        return None, f"Ambiguous coverage artifacts for {source_name}"

    return best, None


def _parse_gcov_generated_paths(output: str, cwd: Path) -> set[str]:
    """Extract gcov report paths explicitly created by the current invocation."""
    generated: set[str] = set()
    pattern = r"Creating\s+['\"]([^'\"]+\.gcov)['\"]"
    for match in re.finditer(pattern, output or "", re.IGNORECASE):
        raw_path = Path(match.group(1))
        path = raw_path if raw_path.is_absolute() else cwd / raw_path
        try:
            generated.add(str(path.resolve()))
        except OSError:
            generated.add(str(path))
    return generated


def _coverage_report_matches_gcov_summary(report: Dict[str, Any], gcov_output: str) -> bool:
    """Verify an unchanged report against this gcov run's summary."""
    summary = _parse_gcov_text_output(gcov_output)
    summary_lines = summary.get("lines_total", 0)
    if not summary_lines or report.get("lines_total", 0) != summary_lines:
        return False
    if abs(float(report.get("line_coverage", 0.0)) - float(summary.get("line_coverage", 0.0))) > 0.01:
        return False
    summary_branches = summary.get("branches_total", 0)
    if summary_branches and (
        report.get("branches_total", 0) != summary_branches
        or abs(float(report.get("branch_coverage", 0.0)) - float(summary.get("branch_coverage", 0.0))) > 0.01
    ):
        return False
    return True


def _coverage_data_score(path: Path, source_file: str) -> int:
    """Rank gcda files, preferring the source or its test-only access adapter."""
    source_name = Path(source_file).name.lower()
    source_stem = Path(source_file).stem.lower()
    name = path.name.lower()
    score = 0
    if name == f"{source_name}.gcda":
        score += 100
    if source_stem in name:
        score += 30
    if "test_access" in name or "test-access" in name:
        score += 35
    if "mock" in name or name.startswith("tc-"):
        score -= 50
    if name.endswith(".c.gcda"):
        score += 5
    return score


def _gcov_output_mentions_source(output: str, source_file: str) -> bool:
    """Return true only when gcov reports the requested source file."""
    source_name = re.escape(Path(source_file).name)
    return bool(re.search(rf"(?im)^File\s+['\"][^'\"]*{source_name}['\"]", output or ""))


def _gcov_artifact_matches_source(gcov_file: Path, source_file: str) -> bool:
    """Validate a gcov artifact using its Source header."""
    expected = Path(source_file).name.lower()
    try:
        with gcov_file.open("r", encoding="utf-8", errors="ignore") as handle:
            for _ in range(12):
                line = handle.readline()
                if not line:
                    break
                normalized = line.strip()
                if normalized.lower().startswith("-:    0:source:"):
                    return Path(normalized.split(":", 3)[-1].strip()).name.lower() == expected
    except OSError:
        return False
    return False


def _resolve_gcov_executable(build_profile: str) -> Path:
    """Use gcov from the compiler profile that produced the coverage files."""
    from app.core.config import get_mingw_bin_dir, get_resolved_qbs_path

    executable = "gcov.exe" if os.name == "nt" else "gcov"
    try:
        profile = subprocess.run(
            [get_resolved_qbs_path(), "config", "--list", f"profiles.{build_profile}"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
        )
        if profile.returncode == 0:
            properties = {}
            for line in profile.stdout.splitlines():
                key, separator, value = line.partition(":")
                if separator:
                    properties[key.strip()] = value.strip().strip('"')
            prefix = f"profiles.{build_profile}.cpp."
            compiler = properties.get(prefix + "compilerPath")
            directory = properties.get(prefix + "toolchainInstallPath")
            toolchain = Path(compiler).parent if compiler else Path(directory) if directory else None
            if toolchain:
                tool_prefix = properties.get(prefix + "toolchainPrefix", "")
                for name in (tool_prefix + executable, executable):
                    candidate = toolchain / name
                    if candidate.is_file():
                        return candidate
    except (OSError, subprocess.SubprocessError) as exc:
        logger.warning("[COV] Cannot resolve compiler profile: {}", exc)

    bundled = Path(get_mingw_bin_dir()) / executable
    return bundled if bundled.is_file() else Path(shutil.which(executable) or executable)


def analyze_gcov_coverage(
    source_file: str,
    layer: str,
    platform: str,
    project_root: str,
    build_profile: str = "mingw",
    qbs_project_path: str | None = None,
    qbs_file: str | None = None,
    product_name: str | None = None,
) -> Dict[str, Any]:
    """Run gcov and parse coverage data.

    Args:
        source_file: Source file path (e.g. "hal-pwr.c")
        layer: Code layer
        platform: Target platform
        project_root: Project root path
        build_profile: Build profile

    Returns:
        ``{success, line_coverage, branch_coverage, lines_executed, lines_total,
          uncovered_lines, uncovered_functions, gcov_file, error}``
    """
    result: Dict[str, Any] = {
        "success": False,
        "line_coverage": 0.0,
        "branch_coverage": 0.0,
        "function_coverage": 0.0,
        "lines_executed": 0,
        "lines_total": 0,
        "branches_executed": 0,
        "branches_total": 0,
        "functions_executed": 0,
        "functions_total": 0,
        "uncovered_lines": [],
        "uncovered_functions": [],
        "gcov_file": None,
        "error": None,
        "diagnostic": None,
        "qbs_project_path": qbs_project_path,
        "qbs_file": qbs_file,
        "product_name": product_name,
    }

    from .paths import is_platformkit_subrepo
    libs_qbs_dir = Path(project_root) / "libs" / "platformkit" / "project" / "test" / "qbs"
    subrepo_qbs_dir = Path(project_root) / "project" / "test" / "qbs"

    if qbs_project_path:
        qbs_dir = Path(qbs_project_path)
        build_dir = qbs_dir / "default"
        if not qbs_dir.is_dir():
            result["error"] = f"QBS project directory not found: {qbs_dir}"
            result["diagnostic"] = "qbs_project_directory_missing"
            return result
        if qbs_file and not Path(qbs_file).is_file():
            result["error"] = f"QBS project file not found: {qbs_file}"
            result["diagnostic"] = "qbs_project_file_missing"
            return result
    # APP layer uses a standalone QBS project under projects/test/qbs
    elif layer == "app":
        app_qbs_dir = Path(project_root) / "projects" / "test" / "qbs"
        if app_qbs_dir.exists():
            qbs_dir = app_qbs_dir
            # Try .qbs-build-app/default first, then plain default
            build_dir = app_qbs_dir / ".qbs-build-app" / "default"
            if not build_dir.exists():
                build_dir = app_qbs_dir / "default"
        else:
            qbs_dir = libs_qbs_dir
            build_dir = qbs_dir / "default"
    elif layer == "common":
        common_qbs_dir = Path(project_root) / "projects" / "test" / "qbs"
        if common_qbs_dir.exists():
            qbs_dir = common_qbs_dir
            build_dir = common_qbs_dir / "default"
        else:
            qbs_dir = libs_qbs_dir
            build_dir = qbs_dir / "default"
    elif is_platformkit_subrepo(project_root):
        # Scenario 1: project_root IS the platformkit sub-repo root
        qbs_dir = subrepo_qbs_dir
        build_dir = qbs_dir / "default"
    else:
        qbs_dir = libs_qbs_dir

        # Primary: profile:mingw → default/
        build_dir = qbs_dir / "default"

        if not build_dir.exists():
            # Legacy build directory patterns
            legacy_patterns = {
                "hal": f"build-{platform}-{build_profile}",
                "driver": f"build-driver-{build_profile}",
                "midware_controller": f"build-controller-{build_profile}",
                "midware_driver": f"build-drivers-{build_profile}",
            }
            legacy_name = legacy_patterns.get(layer)
            if legacy_name:
                legacy_dir = qbs_dir / legacy_name
                if legacy_dir.exists():
                    build_dir = legacy_dir
                    logger.info(f"[COV] Using legacy build directory: {build_dir}")

    if not build_dir.exists():
        for configuration_name in ("debug", "release"):
            configuration_dir = qbs_dir / configuration_name
            if configuration_dir.exists():
                build_dir = configuration_dir
                logger.info(
                    f"[COV] Using QBS configuration directory: {build_dir}"
                )
                break

    if not build_dir.exists():
        result["error"] = f"Build directory not found: {build_dir}"
        logger.warning(f"[COV] Build directory not found: {build_dir}")
        return result

    source_filename = Path(source_file).name
    source_stem = Path(source_file).stem

    try:
        logger.info(f"[COV] Running gcov for {source_filename}...")

        gcov_full_path = _resolve_gcov_executable(build_profile)

        # Find .gcda files in build_dir
        gcda_files = list(build_dir.rglob(f"*{source_filename}.gcda"))
        if not gcda_files:
            base_name = source_filename.rsplit(".", 1)[0]
            gcda_files = list(build_dir.rglob(f"*{base_name}*.gcda"))

        # If not found in default/, try debug/ directory
        if not gcda_files:
            debug_dir = qbs_dir / "debug"
            if debug_dir.exists() and debug_dir != build_dir:
                logger.info(f"[COV] No .gcda files in {build_dir.name}/, trying debug/")
                gcda_files = list(debug_dir.rglob(f"*{source_filename}.gcda"))
                if not gcda_files:
                    gcda_files = list(debug_dir.rglob(f"*{base_name}*.gcda"))
                if gcda_files:
                    build_dir = debug_dir
                    logger.info(f"[COV] Found .gcda files in debug/ directory")

        if not gcda_files:
            # Add diagnostic logging to help troubleshoot .gcda file location issues
            logger.warning(f"[COV] No .gcda files found for {source_filename}")
            logger.info(f"[COV] Searched in: {build_dir}")
            all_gcda = list(build_dir.rglob("*.gcda"))
            if all_gcda:
                logger.info(f"[COV] Found {len(all_gcda)} .gcda files in build dir: {[f.name for f in all_gcda[:10]]}")
            else:
                logger.warning(f"[COV] No .gcda files exist in build directory at all")

            result["error"] = f"No coverage data (.gcda) found for {source_filename}"
            return result

        ranked_gcda = sorted(
            gcda_files,
            key=lambda path: (_coverage_data_score(path, source_filename), path.stat().st_mtime),
            reverse=True,
        )
        gcov_result = None
        gcda_file = None
        last_result = None
        previous_gcov_snapshot = _snapshot_gcov_artifacts(build_dir)
        generated_gcov_paths: set[str] = set()
        for candidate in ranked_gcda:
            logger.debug(f"[COV] Trying gcda candidate: {candidate}")
            gcov_cmd = [str(gcov_full_path), "-b", "-f", str(candidate), "-o", str(candidate.parent)]
            candidate_result = subprocess.run(
                gcov_cmd, cwd=str(build_dir),
                capture_output=True, text=True,
                encoding="utf-8", errors="replace",
                timeout=30,
            )
            last_result = candidate_result
            if candidate_result.returncode != 0:
                continue

            candidate_output = "\n".join((candidate_result.stdout, candidate_result.stderr))
            candidate_generated = _parse_gcov_generated_paths(candidate_output, candidate.parent)
            artifact, _ = _find_best_coverage_artifact(
                build_dir,
                source_file,
                previous_snapshot=None,
                generated_paths=candidate_generated,
            )
            if _gcov_output_mentions_source(candidate_result.stdout, source_filename) or (
                artifact is not None and _gcov_artifact_matches_source(artifact, source_filename)
            ):
                gcov_result = candidate_result
                gcda_file = candidate
                generated_gcov_paths = candidate_generated
                logger.debug(f"[COV] Selected gcda file: {gcda_file}")
                break

        if gcov_result is None:
            if last_result is not None and last_result.returncode != 0:
                result["error"] = f"gcov failed: {last_result.stderr}"
            else:
                result["error"] = f"gcov produced no artifact for {source_filename}"
                result["diagnostic"] = "coverage_source_not_found"
            logger.error(f"[COV] {result['error']}")
            return result

        if gcov_result.returncode == 0:
            logger.debug(f"[COV] gcov stdout: {gcov_result.stdout[:500]}")

            # Find generated .gcov file (QBS/gcov may hash path separators in filenames)
            gcov_file, ambiguity_error = _find_best_coverage_artifact(
                build_dir,
                source_file,
                previous_gcov_snapshot,
                generated_paths=generated_gcov_paths,
            )
            if gcov_file is None and ambiguity_error is None:
                gcov_file, ambiguity_error = _find_best_coverage_artifact(
                    gcda_file.parent,
                    source_file,
                    previous_gcov_snapshot,
                    generated_paths=generated_gcov_paths,
                )

            if gcov_file is None and ambiguity_error is None and not generated_gcov_paths:
                fallback_file, fallback_error = _find_best_coverage_artifact(
                    build_dir,
                    source_file,
                    previous_snapshot=None,
                )
                if fallback_file is None and fallback_error is None:
                    fallback_file, fallback_error = _find_best_coverage_artifact(
                        gcda_file.parent,
                        source_file,
                        previous_snapshot=None,
                    )
                if fallback_error:
                    ambiguity_error = fallback_error
                elif fallback_file is not None:
                    fallback_metrics = _parse_gcov_file(fallback_file)
                    if _coverage_report_matches_gcov_summary(
                        fallback_metrics,
                        gcov_result.stdout,
                    ):
                        gcov_file = fallback_file

            if ambiguity_error:
                result["error"] = ambiguity_error
                result["diagnostic"] = "ambiguous_artifacts"
                logger.warning(f"[COV] {ambiguity_error}")
                return result

            if gcov_file is not None:
                result["gcov_file"] = str(gcov_file)
                parsed = _parse_gcov_file(gcov_file)
                result.update(parsed)
                function_data = _parse_gcov_function_output(gcov_result.stdout)
                if function_data["functions_total"] == 0 and gcda_file is not None:
                    json_function_data = _collect_gcov_function_coverage(
                        gcov_full_path,
                        gcda_file,
                        source_file,
                    )
                    if json_function_data["functions_total"] > 0:
                        function_data = json_function_data
                result.update({
                    "function_coverage": function_data["function_coverage"],
                    "functions_executed": function_data["functions_executed"],
                    "functions_total": function_data["functions_total"],
                })
                result["uncovered_functions"] = sorted(set(
                    result.get("uncovered_functions", [])
                    + function_data["uncovered_functions"]
                ))
                function_data = _parse_gcov_function_output(gcov_result.stdout)
                if function_data["functions_total"] == 0 and gcda_file is not None:
                    json_function_data = _collect_gcov_function_coverage(
                        gcov_full_path,
                        gcda_file,
                        source_file,
                    )
                    if json_function_data["functions_total"] > 0:
                        function_data = json_function_data
                result.update({
                    "function_coverage": function_data["function_coverage"],
                    "functions_executed": function_data["functions_executed"],
                    "functions_total": function_data["functions_total"],
                })
                result["uncovered_functions"] = sorted(set(
                    result.get("uncovered_functions", [])
                    + function_data["uncovered_functions"]
                ))
                # If .gcov file parsed but returned 0 lines, fallback to stdout
                if result["lines_total"] == 0:
                    logger.warning(
                        f"[COV] .gcov file parsed but lines_total=0, "
                        f"falling back to stdout parsing"
                    )
                    stdout_parsed = _parse_gcov_text_output(gcov_result.stdout)
                    if stdout_parsed.get("lines_total", 0) > 0:
                        result.update(stdout_parsed)
                    else:
                        result["error"] = f"Coverage measurement unavailable for {source_filename}"
                        result["diagnostic"] = "zero_line_gcov"
                        logger.warning(f"[COV] {result['error']}")
                        return result
                result["success"] = True
                logger.info(
                    f"[COV] gcov coverage: {result['line_coverage']:.1f}% "
                    f"({result['lines_executed']}/{result['lines_total']} lines)"
                )
            else:
                # No .gcov file found — log what gcov actually created for debugging
                all_gcov = list(build_dir.rglob("*.gcov"))
                logger.warning(
                    f"[COV] No matching .gcov file found for {source_filename}. "
                    f"gcov created {len(all_gcov)} files under {build_dir}: "
                    f"{[str(f.relative_to(build_dir)) for f in all_gcov[:5]]}"
                )
                # Fallback: parse gcov text output
                result.update(_parse_gcov_text_output(gcov_result.stdout))
                result["success"] = True
                logger.info(
                    f"[COV] gcov coverage (from stdout): {result['line_coverage']:.1f}% "
                    f"({result['lines_executed']}/{result['lines_total']} lines)"
                )
        else:
            result["error"] = f"gcov failed: {gcov_result.stderr}"
            logger.error(f"[COV] gcov failed: {gcov_result.stderr}")

    except subprocess.TimeoutExpired:
        result["error"] = "gcov timeout (30s)"
        logger.error("[COV] gcov timeout")
    except FileNotFoundError:
        result["error"] = "gcov command not found"
        logger.error("[COV] gcov command not found")
    except Exception as e:
        result["error"] = f"Coverage analysis exception: {e}"
        logger.error(f"[COV] Exception: {e}")

    return result


def collect_gcov_coverage(
    source_files: list[str],
    layer: str,
    platform: str,
    project_root: str,
    build_profile: str = "mingw",
    qbs_project_path: str | None = None,
    qbs_file: str | None = None,
    product_name: str | None = None,
) -> Dict[str, Any]:
    """Run gcov for multiple source files and aggregate coverage data.

    Args:
        source_files: List of source file relative paths
            (e.g. ["libs/platformkit/bsp/hal/stm32u3/hal-pwr.c"])
        layer: Code layer
        platform: Target platform
        project_root: Project root path
        build_profile: Build profile

    Returns:
        ``{success, line_coverage, uncovered_lines, uncovered_functions, per_file: {path: gcov_result}}``
    """
    total_executed = 0
    total_lines = 0
    total_branches_executed = 0
    total_branches_total = 0
    total_functions_executed = 0
    total_functions_total = 0
    total_calls_executed = 0
    total_calls_total = 0
    all_uncovered_lines: list[int] = []
    all_uncovered_functions: list[str] = []
    per_file: Dict[str, Dict[str, Any]] = {}
    any_success = False
    first_error: str | None = None
    first_diagnostic: str | None = None

    for src in source_files:
        src_filename = Path(src).name
        gcov_result = analyze_gcov_coverage(
            source_file=src_filename,
            layer=layer,
            platform=platform,
            project_root=project_root,
            build_profile=build_profile,
            qbs_project_path=qbs_project_path,
            qbs_file=qbs_file,
            product_name=product_name,
        )
        per_file[src] = gcov_result

        if gcov_result.get("success"):
            any_success = True
            total_executed += gcov_result.get("lines_executed", 0)
            total_lines += gcov_result.get("lines_total", 0)
            total_branches_executed += gcov_result.get("branches_executed", 0)
            total_branches_total += gcov_result.get("branches_total", 0)
            functions_total = gcov_result.get("functions_total")
            functions_executed = gcov_result.get("functions_executed")
            if functions_total is None:
                functions_total = gcov_result.get("calls_total", 0)
                functions_executed = gcov_result.get("calls_executed", 0)
            total_functions_executed += functions_executed or 0
            total_functions_total += functions_total or 0
            total_calls_executed += gcov_result.get("calls_executed", 0)
            total_calls_total += gcov_result.get("calls_total", 0)
            all_uncovered_lines.extend(gcov_result.get("uncovered_lines", []))
            all_uncovered_functions.extend(gcov_result.get("uncovered_functions", []))
        else:
            if first_error is None:
                first_error = gcov_result.get("error")
            if first_diagnostic is None:
                first_diagnostic = gcov_result.get("diagnostic")

    line_coverage = (total_executed / total_lines * 100) if total_lines > 0 else 0.0
    branch_coverage = (total_branches_executed / total_branches_total * 100) if total_branches_total > 0 else 0.0
    function_coverage = (
        total_functions_executed / total_functions_total * 100
        if total_functions_total > 0
        else 0.0
    )

    return {
        "success": any_success,
        "line_coverage": line_coverage,
        "branch_coverage": branch_coverage,
        "function_coverage": function_coverage,
        "lines_executed": total_executed,
        "lines_total": total_lines,
        "branches_executed": total_branches_executed,
        "branches_total": total_branches_total,
        "functions_executed": total_functions_executed,
        "functions_total": total_functions_total,
        "calls_executed": total_calls_executed,
        "calls_total": total_calls_total,
        "uncovered_lines": all_uncovered_lines,
        "uncovered_functions": all_uncovered_functions,
        "per_file": per_file,
        "error": first_error,
        "diagnostic": first_diagnostic,
    }


# ========== Internal helper functions ==========

def _parse_time_to_ms(time_str: str) -> int:
    """Parse GTest time string into milliseconds.

    Supported formats: "0.119s", "119ms", "0", "3ms", "1.5s"
    """
    if not time_str:
        return 0
    time_str = str(time_str).strip()
    try:
        if time_str.endswith("s") and not time_str.endswith("ms"):
            return int(float(time_str[:-1]) * 1000)
        if time_str.endswith("ms"):
            return int(time_str[:-2])
        return int(float(time_str))
    except (ValueError, TypeError):
        return 0


def _parse_gtest_text_output(output: str) -> Dict[str, Any]:
    """Parse GTest text output (fallback when JSON is unavailable)."""
    result: Dict[str, Any] = {"total": 0, "passed": 0, "failed": 0}

    total_match = re.search(r"\[==========\] (\d+) tests? from", output)
    if total_match:
        result["total"] = int(total_match.group(1))

    passed_match = re.search(r"\[\s+PASSED\s+\] (\d+) tests?", output)
    if passed_match:
        result["passed"] = int(passed_match.group(1))

    failed_match = re.search(r"\[\s+FAILED\s+\] (\d+) tests?", output)
    if failed_match:
        result["failed"] = int(failed_match.group(1))
    else:
        result["failed"] = result["total"] - result["passed"]

    return result


def _parse_gcov_file(gcov_file: Path) -> Dict[str, Any]:
    """Parse .gcov file and extract coverage data."""
    result: Dict[str, Any] = {
        "lines_executed": 0,
        "lines_total": 0,
        "line_coverage": 0.0,
        "branches_executed": 0,
        "branches_total": 0,
        "branch_coverage": 0.0,
        "calls_total": 0,
        "calls_executed": 0,
        "uncovered_lines": [],
        "uncovered_functions": [],
    }

    try:
        file_size = gcov_file.stat().st_size
        logger.debug(f"[COV] Parsing .gcov file: {gcov_file} ({file_size} bytes)")

        current_func = ""
        with open(gcov_file, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                # Function tracking
                func_match = re.match(r"\s*-:\s*0:Function:(\w+)", line)
                if func_match:
                    current_func = func_match.group(1)

                # Parse branch/call lines BEFORE the colon-split check,
                # because branch/call lines have no ':' separator and
                # would be skipped by the len(parts) < 2 guard.
                # Format: "branch  0 taken 5" or "branch  1 never executed"
                # Format: "call    0 returned 100%"
                stripped = line.strip()
                if stripped.startswith("branch"):
                    result["branches_total"] += 1
                    if "taken" in stripped and "taken 0%" not in stripped:
                        result["branches_executed"] += 1
                    continue
                if stripped.startswith("call"):
                    result["calls_total"] += 1
                    if "returned" in stripped:
                        result["calls_executed"] += 1
                    continue

                # gcov format: execution_count:line_number:source_code
                parts = line.split(":", 2)
                if len(parts) < 2:
                    continue

                exec_count = parts[0].strip()
                line_num = parts[1].strip()

                if exec_count == "-" or not line_num.isdigit():
                    continue

                result["lines_total"] += 1

                if exec_count in ("#####", "====="):
                    result["uncovered_lines"].append(int(line_num))
                    if current_func and current_func not in result["uncovered_functions"]:
                        result["uncovered_functions"].append(current_func)
                elif exec_count.isdigit() and int(exec_count) > 0:
                    result["lines_executed"] += 1

        if result["lines_total"] > 0:
            result["line_coverage"] = (result["lines_executed"] / result["lines_total"]) * 100.0
        if result["branches_total"] > 0:
            result["branch_coverage"] = (result["branches_executed"] / result["branches_total"]) * 100.0

        logger.debug(
            f"[COV] _parse_gcov_file result: "
            f"lines={result['lines_executed']}/{result['lines_total']}, "
            f"branches={result['branches_executed']}/{result['branches_total']}, "
            f"calls={result['calls_executed']}/{result['calls_total']}, "
            f"coverage={result['line_coverage']:.1f}%"
        )

    except Exception as e:
        logger.warning(f"[COV] Failed to parse .gcov file: {e}")

    return result


def _parse_gcov_text_output(output: str) -> Dict[str, Any]:
    """Parse gcov text output (fallback when .gcov file is unavailable)."""
    result: Dict[str, Any] = {
        "line_coverage": 0.0,
        "branch_coverage": 0.0,
        "lines_executed": 0,
        "lines_total": 0,
        "branches_executed": 0,
        "branches_total": 0,
        "function_coverage": 0.0,
        "functions_executed": 0,
        "functions_total": 0,
        "uncovered_functions": [],
    }

    line_match = re.search(r"Lines executed:(\d+(?:\.\d+)?)% of (\d+)", output)
    if line_match:
        result["line_coverage"] = float(line_match.group(1))
        result["lines_total"] = int(line_match.group(2))
        result["lines_executed"] = int(result["lines_total"] * result["line_coverage"] / 100.0)

    branch_match = re.search(r"Branches executed:(\d+\.\d+)% of (\d+)", output)
    if branch_match:
        result["branch_coverage"] = float(branch_match.group(1))
        result["branches_total"] = int(branch_match.group(2))
        result["branches_executed"] = int(result["branches_total"] * result["branch_coverage"] / 100.0)

    result.update(_parse_gcov_function_output(output))

    return result


def _parse_gcov_json_function_coverage(
    coverage_json: Dict[str, Any],
    source_file: str,
) -> Dict[str, Any]:
    """Parse GCC JSON coverage output and return target-source function metrics."""
    result: Dict[str, Any] = {
        "function_coverage": 0.0,
        "functions_executed": 0,
        "functions_total": 0,
        "uncovered_functions": [],
    }
    if not isinstance(coverage_json, dict):
        return result

    target_path = str(source_file or "").replace("\\", "/").casefold()
    target_name = Path(target_path).name
    for file_entry in coverage_json.get("files", []):
        if not isinstance(file_entry, dict):
            continue
        reported_path = str(file_entry.get("file") or "").replace("\\", "/").casefold()
        reported_name = Path(reported_path).name
        if not (
            reported_path == target_path
            or reported_name == target_name
            or reported_path.endswith(f"/{target_path}")
        ):
            continue

        for function in file_entry.get("functions", []):
            if not isinstance(function, dict):
                continue
            name = function.get("demangled_name") or function.get("name") or "<anonymous>"
            try:
                execution_count = int(function.get("execution_count", 0) or 0)
            except (TypeError, ValueError):
                execution_count = 0
            result["functions_total"] += 1
            if execution_count > 0:
                result["functions_executed"] += 1
            else:
                result["uncovered_functions"].append(str(name))
        break

    if result["functions_total"] > 0:
        result["function_coverage"] = (
            result["functions_executed"] / result["functions_total"] * 100.0
        )
    return result


def _parse_gcov_function_coverage(
    intermediate_output: str,
    source_file: str,
) -> Dict[str, Any]:
    """Parse real function execution counts from legacy gcov intermediate data."""
    result: Dict[str, Any] = {
        "function_coverage": 0.0,
        "functions_executed": 0,
        "functions_total": 0,
        "uncovered_functions": [],
    }
    if not intermediate_output:
        return result

    target_name = Path(source_file).name.lower()
    target_active = False
    for raw_line in intermediate_output.splitlines():
        line = raw_line.strip()
        if line.startswith("file:"):
            reported_name = Path(line.removeprefix("file:").replace("\\", "/")).name.lower()
            target_active = reported_name == target_name
            continue
        if not target_active or not line.startswith("function:"):
            continue
        fields = line.removeprefix("function:").split(",", 2)
        if len(fields) != 3:
            continue
        try:
            execution_count = int(fields[1])
        except ValueError:
            continue
        function_name = fields[2]
        result["functions_total"] += 1
        if execution_count > 0:
            result["functions_executed"] += 1
        else:
            result["uncovered_functions"].append(function_name)

    if result["functions_total"]:
        result["function_coverage"] = (
            result["functions_executed"] / result["functions_total"] * 100.0
        )
    return result


def _collect_gcov_function_coverage(
    gcov_executable: Path,
    gcda_file: Path,
    source_file: str,
) -> Dict[str, Any]:
    """Run gcov intermediate mode for GCC versions that emit JSON coverage."""
    import tempfile

    empty_result = _parse_gcov_function_coverage("", source_file)
    try:
        with tempfile.TemporaryDirectory(prefix="unittest-gcov-functions-") as temp_dir:
            intermediate_result = subprocess.run(
                [
                    str(gcov_executable),
                    "-i",
                    str(gcda_file),
                    "-o",
                    str(gcda_file.parent),
                ],
                cwd=temp_dir,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if intermediate_result.returncode != 0:
                logger.warning(
                    "[COV] gcov intermediate function analysis failed: {}",
                    intermediate_result.stderr[:BUILD_ERROR_PREVIEW_CHARS],
                )
                return empty_result

            intermediate_files = list(Path(temp_dir).glob("*.gcov.json.gz"))
            intermediate_files.extend(Path(temp_dir).glob("*.gcov.json"))
            intermediate_files.extend(Path(temp_dir).glob("*.gcov"))
            for intermediate_file in intermediate_files:
                if intermediate_file.name.endswith(".json.gz"):
                    import gzip

                    with gzip.open(intermediate_file, "rt", encoding="utf-8") as stream:
                        parsed = _parse_gcov_json_function_coverage(
                            json.load(stream), source_file
                        )
                elif intermediate_file.name.endswith(".json"):
                    parsed = _parse_gcov_json_function_coverage(
                        json.loads(intermediate_file.read_text(encoding="utf-8")),
                        source_file,
                    )
                else:
                    parsed = _parse_gcov_function_coverage(
                        intermediate_file.read_text(encoding="utf-8", errors="ignore"),
                        source_file,
                    )
                if parsed["functions_total"] > 0:
                    return parsed
    except Exception as exc:
        logger.warning("[COV] Function coverage analysis failed: {}", exc)
    return empty_result


def _parse_gcov_function_output(output: str) -> Dict[str, Any]:
    """Parse per-function execution summaries emitted by ``gcov -f``."""
    function_percentages: dict[str, float] = {}
    pattern = re.compile(
        r"Function\s+'([^']+)'\s*\r?\nLines executed:(\d+(?:\.\d+)?)% of \d+"
    )
    for match in pattern.finditer(output or ""):
        function_percentages[match.group(1)] = float(match.group(2))

    functions_total = len(function_percentages)
    functions_executed = sum(
        1 for percentage in function_percentages.values() if percentage > 0.0
    )
    function_coverage = (
        functions_executed / functions_total * 100.0
        if functions_total > 0
        else 0.0
    )
    return {
        "function_coverage": function_coverage,
        "functions_executed": functions_executed,
        "functions_total": functions_total,
        "uncovered_functions": sorted(
            name
            for name, percentage in function_percentages.items()
            if percentage == 0.0
        ),
    }
