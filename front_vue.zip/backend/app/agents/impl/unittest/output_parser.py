"""
@file       output_parser.py
@brief      Multi-strategy output parser for LLM-generated test code.

            Extracts test_impl, test_header, mock_impl, mock_header from
            raw LLM output using 7+ strategies tried in priority order.

@author     caoshwen
@version    3.2
@date       2026-03-10
"""

import re
from pathlib import Path
from typing import Dict

from loguru import logger


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _is_mock_filename(name_lower: str) -> bool:
    """Determine whether a filename (lowercase) is a mock file.

    Supported naming formats:
      mock-stm32-hal-uart.cpp   (with hal infix)
      mock-stm32-uart.cpp       (without hal infix, vendor-module format)
      mock-hal-uart.cpp         (general hal prefix)
      mock-ameba-uart.cpp       (other vendors)
      mock_hal_uart.cpp         (underscore format)
    """
    return bool(
        re.search(r'mock[_-][a-z0-9]', name_lower) and
        name_lower.startswith('mock')
    )


def _is_test_filename(text_lower: str) -> bool:
    """Return whether text contains a canonical generated test filename."""
    return bool(re.search(r'\btc-[a-z0-9][\w-]*\.(?:cpp|h)\b', text_lower))


def _is_stub_filename(text_lower: str) -> bool:
    """Return whether text contains a generated stub or APP carrier filename."""
    return bool(re.search(r'\bstub-[a-z0-9][\w-]*\.(?:cpp|c|h)\b', text_lower))


def _artifact_key_from_filename(text_lower: str) -> str:
    """Map a generated filename marker to its parser result key."""
    first_line = text_lower.split("\n", 1)[0]
    first_line = re.sub(r'^\s*//\s*(?:file:\s*)?', '', first_line).strip()
    is_header = first_line.endswith('.h') or '.h' in first_line
    is_cpp = first_line.endswith('.cpp') or '.cpp' in first_line
    if _is_mock_filename(first_line):
        return 'mock_header' if is_header else 'mock_impl' if is_cpp else ''
    if _is_stub_filename(first_line):
        if first_line.endswith('.h'):
            return 'stub_header'
        return 'stub_impl' if first_line.endswith(('.c', '.cpp')) else ''
    if _is_test_filename(first_line):
        return 'test_header' if is_header else 'test_impl' if is_cpp else ''
    return ''


def _has_required_files(result: Dict[str, str]) -> bool:
    """Return whether the core test and mock artifacts are present."""
    return all(
        result.get(key)
        for key in ('test_impl', 'test_header', 'mock_impl', 'mock_header')
    )


# ---------------------------------------------------------------------------
# Phase-specific parsers
# ---------------------------------------------------------------------------

def _parse_phase1_test_only(output: str, framework: str = "gtest") -> Dict[str, str]:
    """Phase 1 dedicated parser: accept only test_header / test_impl, discard any mock content.

    Prevent model out-of-phase output (mock files output in Phase 1) from polluting Phase 2 context.
    """
    full = parse_and_split_test_output(output, framework)
    result = {
        "test_impl":   full.get("test_impl", ""),
        "test_header": full.get("test_header", ""),
        "mock_impl":   "",   # Force clear: Phase 1 should not produce mock
        "mock_header": "",   # Force clear: Phase 1 should not produce mock
    }
    discarded = []
    if full.get("mock_impl"):
        discarded.append(f"mock_impl ({len(full['mock_impl'])} chars)")
    if full.get("mock_header"):
        discarded.append(f"mock_header ({len(full['mock_header'])} chars)")
    if discarded:
        logger.warning(
            f"   [Phase1 parser] Discarded out-of-phase content: {', '.join(discarded)}"
        )
    return result


def _parse_phase2_mock_only(output: str, framework: str = "gtest") -> Dict[str, str]:
    """Phase 2 dedicated parser: accept only mock_header / mock_impl, discard any test file content.

    Prevent model from re-outputting Phase 1 test files causing parser to overwrite Phase 1 result with Phase 2 version.
    """
    full = parse_and_split_test_output(output, framework)
    result = {
        "test_impl":   "",   # Force clear: Phase 2 should not produce test
        "test_header": "",   # Force clear: Phase 2 should not produce test
        "mock_impl":   full.get("mock_impl", ""),
        "mock_header": full.get("mock_header", ""),
    }
    discarded = []
    if full.get("test_impl"):
        discarded.append(f"test_impl ({len(full['test_impl'])} chars)")
    if full.get("test_header"):
        discarded.append(f"test_header ({len(full['test_header'])} chars)")
    if discarded:
        logger.warning(
            f"   [Phase2 parser] Discarded out-of-phase content: {', '.join(discarded)}"
        )
    return result


# ---------------------------------------------------------------------------
# Main 7-strategy parser
# ---------------------------------------------------------------------------

def parse_and_split_test_output(output: str, framework: str = "gtest") -> Dict[str, str]:
    """Parse LLM-generated output, separate content for different files.

    Args:
        output: raw output generated by LLM
        framework: test framework (gtest/unity)

    Returns:
        dictionary containing content for each file:
        {
            'test_impl':   'Test implementation code',
            'test_header': 'Test header code',
            'mock_impl':   'Mock implementation code',
            'mock_header': 'Mock header code'
        }
    """
    logger.debug(f"Starting parse_and_split_test_output (output length: {len(output)} chars)")
    logger.debug(f"   Output preview (first 500 chars):\n{output[:500]}")

    result: Dict[str, str] = {
        'test_impl': '',
        'test_header': '',
        'mock_impl': '',
        'mock_header': '',
        'stub_impl': '',
        'stub_header': '',
    }

    # ======================================================================
    # Strategy -2: XML <file name="..."> tags (preferred structured protocol)
    # ======================================================================
    xml_file_pattern = r'<file\s+name="([^"]+)">\s*\n?(.*?)</file>'
    xml_matches = re.findall(xml_file_pattern, output, re.DOTALL)
    if xml_matches:
        logger.info(f"   Strategy -2: Found {len(xml_matches)} <file> XML blocks")
        for filename, content in xml_matches:
            filename_lower = filename.lower().strip()
            content = content.strip()
            if not content:
                continue
            key = _artifact_key_from_filename(filename_lower)
            if key:
                result[key] = content
                continue
            # Keep the historical fallback for vendor-specific filenames.
            is_mock = 'mock' in filename_lower
            is_header = filename_lower.endswith('.h')
            is_cpp = filename_lower.endswith('.cpp')
            if is_mock:
                if is_header and not result['mock_header']:
                    result['mock_header'] = content
                elif is_cpp and not result['mock_impl']:
                    result['mock_impl'] = content
            else:
                if is_header and not result['test_header']:
                    result['test_header'] = content
                elif is_cpp and not result['test_impl']:
                    result['test_impl'] = content
        # If at least test_impl was parsed, return immediately (skip remaining strategies)
        if result['test_impl']:
            logger.info(f"   Strategy -2: Parsed files: {[k for k, v in result.items() if v]}")
            return _cleanup_parsed_content(result)

    # ======================================================================
    # Strategy -1: HALF-FILE RECOVERY (Handle unclosed <write_to_file> tags)
    # ======================================================================
    write_tool_pattern = (
        r'<write_to_file>\s*<path>(.*?)</path>\s*<content>'
        r'(.*?)(?:</content>\s*</write_to_file>|$)'
    )
    write_tool_matches = re.findall(write_tool_pattern, output, re.DOTALL | re.IGNORECASE)

    if write_tool_matches:
        logger.info(f"   Strategy -1: Found {len(write_tool_matches)} <write_to_file> blocks (including potentially unclosed)")

        for idx, (file_path, content) in enumerate(write_tool_matches, 1):
            file_path = file_path.strip()
            content = content.strip()

            # Detect if this was an unclosed tag
            was_unclosed = not output[output.find(content) + len(content):].lstrip().startswith('</content>')
            if was_unclosed:
                logger.warning(f"   Block {idx}: UNCLOSED tag detected, treating EOF as closing (file: {Path(file_path).name})")
                content_lines = content.split('\n')
                code_lines = []
                for line in content_lines:
                    stripped = line.strip()
                    if stripped and not stripped.startswith(('✅', '##', 'I have', 'All ', 'The ', 'This ')):
                        code_lines.append(line)
                    elif stripped.startswith(('✅', '##', 'I have', 'All ', 'The ', 'This ')):
                        logger.debug(f"      Trimmed trailing commentary: {stripped[:60]}...")
                        break
                content = '\n'.join(code_lines).strip()

            # Map file path to result keys
            filename_lower = Path(file_path).name.lower()
            if _is_stub_filename(filename_lower):
                if filename_lower.endswith(('.c', '.cpp')):
                    result['stub_impl'] = content
                elif filename_lower.endswith('.h'):
                    result['stub_header'] = content
            elif 'tc-hal-' in filename_lower or 'tc-driver-' in filename_lower or 'tc-app-' in filename_lower:
                if filename_lower.endswith('.cpp'):
                    result['test_impl'] = content
                    logger.info(f"      Recovered test_impl: {Path(file_path).name} ({len(content)} chars, unclosed={was_unclosed})")
                elif filename_lower.endswith('.h'):
                    result['test_header'] = content
                    logger.info(f"      Recovered test_header: {Path(file_path).name} ({len(content)} chars, unclosed={was_unclosed})")
            elif _is_mock_filename(filename_lower):
                if filename_lower.endswith('.cpp'):
                    result['mock_impl'] = content
                    logger.info(f"      Recovered mock_impl: {Path(file_path).name} ({len(content)} chars, unclosed={was_unclosed})")
                elif filename_lower.endswith('.h'):
                    result['mock_header'] = content
                    logger.info(f"      Recovered mock_header: {Path(file_path).name} ({len(content)} chars, unclosed={was_unclosed})")

        # If Strategy -1 recovered all 4 files, return immediately
        if _has_required_files(result):
            logger.info("   Strategy -1: Successfully recovered all 4 files from <write_to_file> tags")
            return result
        else:
            missing = [k for k, v in result.items() if not v]
            logger.warning(f"   Strategy -1: Partial recovery, missing: {missing}. Trying other strategies...")

    # ======================================================================
    # Strategy 0: Handle Markdown header format (## File N: ...)
    # ======================================================================
    # Format A: ## File 1: tc-hal-exti.cpp (description)
    # Format B: ## File 1: Test Implementation (tc-hal-exti.cpp)
    md_pattern_a = (
        r'##\s*File\s*\d+:\s*'
        r'((?:tc-(?:hal|driver|app)-|mock-(?:stm32-)?(?:hal|driver)-|mock-|stub-)\w+\.(?:cpp|c|h))'
        r'(?:\s*[^\n]*)?\n+```(?:cpp|c\+\+|c|h)?\s*\n(.*?)```'
    )
    md_pattern_b = (
        r'##\s*File\s*\d+:\s*[^(\n]+\('
        r'((?:tc-(?:hal|driver|app)-|mock-(?:stm32-)?(?:hal|driver)-|mock-|stub-)\w+\.(?:cpp|c|h))'
        r'\)\s*\n+```(?:cpp|c\+\+|c|h)?\s*\n(.*?)```'
    )

    md_matches = re.findall(md_pattern_a, output, re.DOTALL | re.IGNORECASE)
    if not md_matches:
        md_matches = re.findall(md_pattern_b, output, re.DOTALL | re.IGNORECASE)
        if md_matches:
            logger.debug("Strategy 0: Using Format B (filename in parentheses)")

    if md_matches:
        logger.debug(f"Strategy 0: Found {len(md_matches)} files via Markdown headers")
        for filename, content in md_matches:
            filename_lower = filename.lower()
            content = content.strip()

            if 'tc-hal-' in filename_lower or 'tc-driver-' in filename_lower or 'tc-app-' in filename_lower:
                if filename_lower.endswith('.cpp'):
                    if not result['test_impl']:
                        result['test_impl'] = content
                        logger.debug(f"   Found test_impl: {filename} ({len(content)} chars)")
                elif filename_lower.endswith('.h'):
                    if not result['test_header']:
                        result['test_header'] = content
                        logger.debug(f"   Found test_header: {filename} ({len(content)} chars)")
            elif _is_mock_filename(filename_lower):
                if filename_lower.endswith('.cpp'):
                    if not result['mock_impl']:
                        result['mock_impl'] = content
                        logger.debug(f"   Found mock_impl: {filename} ({len(content)} chars)")
                elif filename_lower.endswith('.h'):
                    if not result['mock_header']:
                        result['mock_header'] = content
                        logger.debug(f"   Found mock_header: {filename} ({len(content)} chars)")
            elif _is_stub_filename(filename_lower):
                if filename_lower.endswith(('.cpp', '.c')):
                    result['stub_impl'] = content
                elif filename_lower.endswith('.h'):
                    result['stub_header'] = content

    if _has_required_files(result):
        logger.debug("Strategy 0: Successfully parsed all 4 files via Markdown headers")
        return result
    else:
        missing = [k for k, v in result.items() if not v]
        logger.debug(f"Strategy 0: Partial success, missing: {missing}")

    # ======================================================================
    # Strategy 1: Look for explicit file markers
    # ======================================================================
    file_markers = [
        # HAL layer test file
        (r'//\s*(?:File:\s*)?tc-hal-.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'test_impl'),
        (r'//\s*(?:File:\s*)?tc-hal-.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'test_header'),
        # Driver layer test file
        (r'//\s*(?:File:\s*)?tc-driver-.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'test_impl'),
        (r'//\s*(?:File:\s*)?tc-driver-.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'test_header'),
        # APP layer test file
        (r'//\s*(?:File:\s*)?tc-app-.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'test_impl'),
        (r'//\s*(?:File:\s*)?tc-app-.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'test_header'),
        # HAL layer Mock files (STM32 platform, with hal infix)
        (r'//\s*(?:File:\s*)?mock-stm32-hal-.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_impl'),
        (r'//\s*(?:File:\s*)?mock-stm32-hal-.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_header'),
        # HAL layer Mock file (STM32 platform, without hal infix, e.g. mock-stm32-uart)
        (r'//\s*(?:File:\s*)?mock-stm32-(?!hal)\w+.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_impl'),
        (r'//\s*(?:File:\s*)?mock-stm32-(?!hal)\w+.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_header'),
        # General Mock file (mock-hal- prefix)
        (r'//\s*(?:File:\s*)?mock-hal-.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_impl'),
        (r'//\s*(?:File:\s*)?mock-hal-.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_header'),
        # Other vendor mock files (mock-ameba-, mock-nrf-, etc.)
        (r'//\s*(?:File:\s*)?mock-(?!stm32|hal)\w+-\w+.*?\.cpp\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_impl'),
        (r'//\s*(?:File:\s*)?mock-(?!stm32|hal)\w+-\w+.*?\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-)|$)', 'mock_header'),
        (r'//\s*(?:File:\s*)?stub-[\w-]+\.(?:cpp|c)\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-|stub-)|$)', 'stub_impl'),
        (r'//\s*(?:File:\s*)?stub-[\w-]+\.h\s*\n(.*?)(?=//\s*(?:File:|tc-|mock-|stub-)|$)', 'stub_header'),
    ]

    for pattern, file_type in file_markers:
        matches = re.findall(pattern, output, re.DOTALL | re.IGNORECASE)
        if matches and not result[file_type]:
            result[file_type] = matches[0].strip()

    # Early cleanup: Remove markdown artifacts but KEEP file markers for parsing
    output_cleaned = output
    output_cleaned = re.sub(r'^#{1,6}\s+.*$', '', output_cleaned, flags=re.MULTILINE)
    output_cleaned = re.sub(r'^\s*[-*+]\s+.*$', '', output_cleaned, flags=re.MULTILINE)

    # ======================================================================
    # Strategy 2: Extract code blocks from markdown
    # ======================================================================
    code_blocks = re.findall(r'```(?:cpp|c\+\+|c|h)?\s*\n(.*?)```', output_cleaned, re.DOTALL)

    # ======================================================================
    # Strategy 2.5: Single block contains all files — split by file markers
    # ======================================================================
    if code_blocks and len(code_blocks) == 1:
        single_block = code_blocks[0]

        if single_block.count('// tc-') + single_block.count('// mock-') >= 2:
            file_sections = re.split(r'(?=//\s*(?:File:\s*)?(?:tc-|mock-))', single_block)

            for section in file_sections:
                if not section.strip():
                    continue

                first_line = section.split('\n')[0].lower() if '\n' in section else section.lower()

                if not result['test_header'] and ('tc-hal-' in first_line or 'tc-driver-' in first_line or 'tc-app-' in first_line) and '.h' in first_line:
                    result['test_header'] = section.strip()
                elif not result['test_impl'] and ('tc-hal-' in first_line or 'tc-driver-' in first_line or 'tc-app-' in first_line) and '.cpp' in first_line:
                    result['test_impl'] = section.strip()
                elif not result['mock_header'] and ('mock-stm32-hal-' in first_line or 'mock-hal-' in first_line) and '.h' in first_line:
                    result['mock_header'] = section.strip()
                elif not result['mock_impl'] and ('mock-stm32-hal-' in first_line or 'mock-hal-' in first_line) and '.cpp' in first_line:
                    result['mock_impl'] = section.strip()

            if all(result.values()):
                logger.debug("Successfully split single block into 4 files")
                logger.debug(
                    f"Parsing results: test_impl={len(result['test_impl'])} chars, "
                    f"test_header={len(result['test_header'])} chars, "
                    f"mock_impl={len(result['mock_impl'])} chars, "
                    f"mock_header={len(result['mock_header'])} chars"
                )
                return result

    # ======================================================================
    # Strategy 3: No code blocks — split by file markers in plain text
    # ======================================================================
    if not code_blocks:
        sections = re.split(r'(?=//\s*(?:File:\s*)?(?:tc-|mock-))', output)
        for section in sections:
            section_lower = section.lower()
            if not result['mock_header'] and _is_mock_filename(section_lower) and \
               (section_lower.endswith('.h\n') or '#ifndef' in section or '#pragma once' in section or 'MOCK_METHOD' in section):
                result['mock_header'] = section.strip()
            elif not result['mock_impl'] and _is_mock_filename(section_lower) and \
                 section_lower.endswith('.cpp\n'):
                result['mock_impl'] = section.strip()
            elif not result['test_header'] and ('tc-hal-' in section_lower or 'tc-driver-' in section_lower or 'tc_driver_' in section_lower or 'tc_hal_' in section_lower or 'tc-app-' in section_lower or 'tc_app_' in section_lower) and \
                 (section_lower.endswith('.h\n') or '#ifndef' in section or '#pragma once' in section or 'class ' in section):
                result['test_header'] = section.strip()
            elif not result['test_impl'] and ('tc-hal-' in section_lower or 'tc-driver-' in section_lower or 'tc_driver_' in section_lower or 'tc_hal_' in section_lower or 'tc-app-' in section_lower or 'tc_app_' in section_lower or 'TEST_F(' in section or 'TEST(' in section):
                result['test_impl'] = section.strip()

        if not any(result.values()):
            logger.warning("Strategy 3: No files parsed from output, marking as parse failure")
        return result

    # ======================================================================
    # Strategy 4: Analyze each code block with enhanced detection
    # ======================================================================
    for idx, block in enumerate(code_blocks):
        block_lower = block.lower()
        block_lines = block.split('\n')[:5]

        # Check for file name in comments at the start of the block
        file_hint = None
        for line in block_lines:
            if '//' in line:
                line_lower = line.lower()
                if _is_mock_filename(line_lower) and '.h' in line_lower:
                    file_hint = 'mock_header'
                    break
                elif _is_mock_filename(line_lower) and '.cpp' in line_lower:
                    file_hint = 'mock_impl'
                    break
                elif ('tc-hal-' in line_lower or 'tc-driver-' in line_lower or 'tc-app-' in line_lower) and '.h' in line_lower:
                    file_hint = 'test_header'
                    break
                elif ('tc-hal-' in line_lower or 'tc-driver-' in line_lower or 'tc-app-' in line_lower) and '.cpp' in line_lower:
                    file_hint = 'test_impl'
                    break

        if file_hint and not result[file_hint]:
            result[file_hint] = block
            continue

        # Content-based detection (priority order)

        # 1. Mock header — has MOCK_METHOD or gmock/gmock.h
        if not result['mock_header'] and ('MOCK_METHOD' in block or 'gmock/gmock.h' in block):
            result['mock_header'] = block
            continue

        # 2. Test header — has class declaration with public ::testing::Test
        if not result['test_header'] and (
            ('class' in block and '::testing::Test' in block) or
            ('class' in block and 'public' in block and 'test' in block_lower)
        ):
            result['test_header'] = block
            continue

        # 3. Mock implementation
        if not result['mock_impl'] and (
            _is_mock_filename(block_lower) and
            ('#pragma once' not in block and '#ifndef' not in block) and
            ('return' in block or '{' in block)
        ):
            result['mock_impl'] = block
            continue

        # 4. Test implementation — has TEST_F/TEST macros
        if not result['test_impl'] and ('TEST_F(' in block or 'TEST(' in block):
            result['test_impl'] = block
            continue

        # 5. Header guard detection — likely a header file
        if '#pragma once' in block or '#ifndef' in block or '#define' in block[:200]:
            if 'MOCK_METHOD' in block or 'gmock' in block_lower:
                if not result['mock_header']:
                    result['mock_header'] = block
            elif not result['test_header']:
                result['test_header'] = block
            continue

        # 6. Default — if has gtest include and TEST_F, it's test implementation
        if 'gtest/gtest.h' in block and not result['test_impl']:
            result['test_impl'] = block
            continue

    # Fallback: single block with TEST_F
    if code_blocks and len(code_blocks) == 1 and 'TEST_F(' in code_blocks[0] and not result['test_impl']:
        result['test_impl'] = code_blocks[0]

    # Final fallback: nothing parsed — put everything in test_impl
    if not any(result.values()):
        result['test_impl'] = output

    # ==================================================================
    # Markdown artifact cleanup
    # ==================================================================
    result = _cleanup_parsed_content(result)

    # Log parsing results
    logger.debug(
        f"Parsing results: test_impl={len(result['test_impl'])} chars, "
        f"test_header={len(result['test_header'])} chars, "
        f"mock_impl={len(result['mock_impl'])} chars, "
        f"mock_header={len(result['mock_header'])} chars"
    )

    # Diagnostic logging for empty / too-small files
    for key, content in result.items():
        if not content or len(content) < 50:
            logger.warning(f"Parse Warning: {key} is empty or too small ({len(content)} chars)")
            if 'test' in key.lower():
                has_test_marker = bool(re.search(r'tc-(?:hal|driver)-\w+\.(?:cpp|h)', output, re.IGNORECASE))
                has_test_f = 'TEST_F(' in output
                logger.debug(f"   Diagnostics for {key}: has_file_marker={has_test_marker}, has_TEST_F={has_test_f}")
            elif 'mock' in key.lower():
                has_mock_marker = bool(re.search(r'mock-(?:stm32-)?(?:hal|driver)-\w+\.(?:cpp|h)', output, re.IGNORECASE))
                has_mock_method = 'MOCK_METHOD' in output
                logger.debug(f"   Diagnostics for {key}: has_file_marker={has_mock_marker}, has_MOCK_METHOD={has_mock_method}")

    # ==================================================================
    # PROTOCOL FALLBACK STRATEGY
    # ==================================================================
    missing_files = [k for k, v in result.items() if not v or len(v) < 50]
    if missing_files:
        logger.warning(f"Attempting protocol fallback for {len(missing_files)} missing files: {missing_files}")
        result = _protocol_fallback(result, missing_files, output)

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _cleanup_parsed_content(result: Dict[str, str]) -> Dict[str, str]:
    """Remove markdown artifacts from all parsed content blocks."""
    for key in result:
        if not result[key]:
            continue
        content = result[key]

        # Remove code block markers
        content = re.sub(r'^```(?:cpp|c\+\+|c|h)?\s*\n?', '', content, flags=re.MULTILINE)
        content = re.sub(r'\n?```\s*$', '', content)
        content = re.sub(r'\n?```\s*\n', '\n', content)

        # Remove markdown headers
        content = re.sub(r'^#{1,6}\s+.*$', '', content, flags=re.MULTILINE)

        # Remove markdown bullet points (but NOT Doxygen "* " lines)
        content = re.sub(r'^\s*[-+]\s+\*\*.*?\*\*:.*$', '', content, flags=re.MULTILINE)
        content = re.sub(r'^\s*\d+\.\s+\*\*.*?\*\*:.*$', '', content, flags=re.MULTILINE)
        content = re.sub(r'^\s*[-+]\s+(?!\*).*$', '', content, flags=re.MULTILINE)

        # Remove markdown bold only in non-C++ lines
        lines = content.split('\n')
        cleaned_lines = []
        for line in lines:
            if not re.match(
                r'^\s*(//|/\*|\*|#|extern|class|void|int|uint|namespace|using|TEST_F|EXPECT_|MOCK_)',
                line.strip(),
            ):
                line = re.sub(r'\*\*(.*?)\*\*', r'\1', line)
            cleaned_lines.append(line)
        content = '\n'.join(cleaned_lines)

        # Remove LLM commentary
        if 'The generated' in content or 'This provides' in content or 'Coverage includes' in content:
            code_lines = []
            in_commentary = False
            for line in content.split('\n'):
                if re.match(r'^(The |This |Coverage |Note:|Important:)', line.strip()):
                    in_commentary = True
                elif re.match(r'^(#include|class |extern |void |int |namespace |using |//|/\*|\s*$|[{}])', line.strip()):
                    in_commentary = False
                if not in_commentary:
                    code_lines.append(line)
            content = '\n'.join(code_lines)

        # Remove extra blank lines (more than 2 consecutive)
        content = re.sub(r'\n{3,}', '\n\n', content)

        # Fix truly incomplete comment blocks
        content = re.sub(
            r'^\s*/\s*\n(\s*\n)*\s*\*/\s*$', '/**\n */', content, flags=re.MULTILINE
        )

        # Fix standalone "/" that should be "/**"
        fixed_lines = []
        all_lines = content.split('\n')
        for i, line in enumerate(all_lines):
            stripped = line.strip()
            if stripped == '/' and i > 0:
                prev_line = all_lines[i - 1].strip() if i > 0 else ''
                next_line = all_lines[i + 1].strip() if i < len(all_lines) - 1 else ''
                if (not prev_line or prev_line.startswith('#include') or prev_line.endswith('}')) and next_line != '*/':
                    fixed_lines.append('/**')
                else:
                    fixed_lines.append(line)
            else:
                fixed_lines.append(line)
        content = '\n'.join(fixed_lines)

        result[key] = content.strip()

    return result


def _protocol_fallback(
    result: Dict[str, str],
    missing_files: list,
    output: str,
) -> Dict[str, str]:
    """Attempt to recover missing files from code blocks when protocol markers are absent."""
    all_code_blocks = re.findall(r'```(?:cpp|c\+\+|c|h)?\s*\n(.*?)```', output, re.DOTALL)

    for key in missing_files:
        recovered = False

        if key == 'mock_impl' and 'MOCK_METHOD' in output:
            for block in all_code_blocks:
                if 'MOCK_METHOD' in block and ('#include "mock-' in block or 'class ' in block):
                    result[key] = block.strip()
                    logger.info(f"   Protocol fallback: Recovered {key} from code block ({len(block)} chars)")
                    recovered = True
                    break

        elif key == 'mock_header' and ('class ' in output and 'Mock' in output):
            for block in all_code_blocks:
                if ('Mock' in block and 'class ' in block) or ('#ifndef MOCK_' in block):
                    result[key] = block.strip()
                    logger.info(f"   Protocol fallback: Recovered {key} from code block ({len(block)} chars)")
                    recovered = True
                    break

        elif key == 'test_impl' and 'TEST_F(' in output:
            for block in all_code_blocks:
                if 'TEST_F(' in block and '#include' in block:
                    result[key] = block.strip()
                    logger.info(f"   Protocol fallback: Recovered {key} from code block ({len(block)} chars)")
                    recovered = True
                    break

        elif key == 'test_header' and ('class ' in output and 'Test ' in output):
            for block in all_code_blocks:
                if 'Test' in block and 'class ' in block and ('protected:' in block or 'public:' in block):
                    result[key] = block.strip()
                    logger.info(f"   Protocol fallback: Recovered {key} from code block ({len(block)} chars)")
                    recovered = True
                    break

        if not recovered:
            logger.warning(f"   Protocol fallback: Could not recover {key}")

    still_missing = [k for k, v in result.items() if not v or len(v) < 50]
    if len(still_missing) < len(missing_files):
        logger.info(f"   Protocol fallback recovered {len(missing_files) - len(still_missing)}/{len(missing_files)} files")
    if still_missing:
        logger.warning(f"   Still missing after fallback: {still_missing}")

    return result
