"""
@file _unittest_prompts.py
@author caoshwen
@brief UnitTestAgent LLM prompt builder (internal module).

SYSTEM_PROMPT + layer rule injection + compile error feedback + mock guidance.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pathlib import Path
from typing import Optional

from .rules import get_code_style_rules, get_layer_rules
from .paths import filter_mock_paths


# Team prompts contain several files. Keep per-file diagnostics bounded so the
# total prompt remains predictable even when every source is oversized.
MAX_TEAM_LARGE_CONTEXT_CHARS = 9000


def compact_large_file_context(context: str, max_chars: int = MAX_TEAM_LARGE_CONTEXT_CHARS) -> str:
    """Keep the beginning and strategy tail of a large-file diagnostic."""
    value = str(context or "")
    if len(value) <= max_chars:
        return value
    marker = "\n... (large-file diagnostics compacted for multi-file generation) ...\n"
    if max_chars <= len(marker):
        return value[:max_chars]
    available = max(0, max_chars - len(marker))
    head_chars = available // 3
    tail_chars = available - head_chars
    return value[:head_chars] + marker + value[-tail_chars:]


COMPACT_CONTEXT_BEGIN = "=== UNITTEST_COMPACT_CONTEXT_BEGIN ==="
COMPACT_CONTEXT_END = "=== UNITTEST_COMPACT_CONTEXT_END ==="


def build_compact_context_instruction() -> str:
    return (
        "\n\n--- Compact Context Summary Requirement ---\n"
        "At the end of your response, output a compact context summary between:\n"
        f"{COMPACT_CONTEXT_BEGIN}\n"
        "and\n"
        f"{COMPACT_CONTEXT_END}\n\n"
        "Rules:\n"
        "- Maximum 3000 characters.\n"
        "- Include only facts useful for future compile fixes or coverage improvement.\n"
        "- Include generated files, fixture/test design, mock design, compile/test fixes, "
        "coverage status, failed attempts, and next best targets.\n"
        "- Do not include full source code.\n"
        "- Use stable file paths, function names, fixture names, and mock names.\n"
    )


def format_previous_compact_context(compact_context: str) -> str:
    compact_context = (compact_context or "").strip()
    if not compact_context:
        return ""
    return (
        "\n--- Previous Compact Context ---\n"
        "Previous compact context from earlier CLI calls:\n"
        f"{compact_context}\n\n"
        "You must respect this context:\n"
        "- Do not repeat failed attempts listed above.\n"
        "- Preserve working test/mock design unless clearly necessary.\n"
        "- Prefer minimal edits that improve uncovered paths.\n"
    )


TEST_QUALITY_CONTRACT = """Mandatory test quality contract:
- Give every test a unique, descriptive name tied to one behavior.
- Include at least one meaningful assertion in every test case.
- Cover normal behavior, boundary values, and error paths when applicable.
- Use explicit mock expectations for observable dependency interactions.
- Use fixtures for shared setup and restore modified global state in teardown.
- Treat the source file and its public headers as the behavioral ground truth; do not invent enum values, event IDs, callback signatures, or state transitions.
- Never declare a source-static function or variable as an ordinary extern symbol from a separate translation unit. That has internal linkage and will fail at link time.
- Prefer public APIs. If internal coverage is required, create a test-only access translation unit that includes the source with a controlled linkage adapter, register that adapter in QBS, and do not link the production source a second time.
- In C++ tests, pass the declared enum constants (or explicit static_cast to the enum type), not arbitrary integers.
- After every compile failure, classify the root cause (preprocess, compile, link, or test fixture), make a meaningful change, and re-run the build. Do not repeat an identical edit for an unchanged diagnostic.
- Do not emit TODO, FIXME, placeholder, disabled, skipped, or assertion-free tests."""


SYSTEM_PROMPT = f"""You are a firmware unit test generation expert.
You generate high-quality C/C++ unit tests for embedded firmware code.

Rules:
- Use the specified test framework (GTest or Unity)
- Generate comprehensive tests covering edge cases, boundary values, and error paths
- Create proper mocks for hardware dependencies
- Follow MISRA C guidelines where applicable
- Include setup/teardown fixtures
- Target the specified code coverage percentage

{TEST_QUALITY_CONTRACT}

Output format: Return the complete test source file content."""


def build_system_prompt(layer: str) -> str:
    """Build the system prompt with layer rules and code style guidance.

    Place the rules in the system message instead of the user message,
    so the system prompt can be cached during retries and reduce token usage.
    """
    parts = [SYSTEM_PROMPT]
    layer_rules = get_layer_rules(layer)
    if layer_rules:
        parts.append(f"\n--- Layer-Specific Testing Rules ---\n{layer_rules}")
    style_rules = get_code_style_rules()
    if style_rules:
        parts.append(f"\n--- Code Style Rules ---\n{style_rules}")
    return "\n".join(parts)


def build_generation_prompt(
    file_path: str,
    content: str,
    layer: str,
    framework: str,
    target_coverage: float,
    source_real_path: str = "",
    scope: str = "all functions",
    compile_errors: Optional[list[dict]] = None,
    skill_prompt: str = "",
    test_filename: str = "",
    test_header_filename: str = "",
    clang_guidance: str = "",
    header_content: str = "",
    dependent_hal_headers: str = "",
    vendor_api_ref: str = "",
    existing_mock_ref: str = "",
    mock_dependency_guidance: str = "",
    project_context: str = "",
    large_file_context: str = "",
) -> str:
    """Build the test generation prompt, injecting layer rules and compile error feedback.

    Args:
        file_path: Source file path
        content: Source file content
        layer: Architecture layer (hal/driver/middleware/controller/app)
        framework: Test framework (gtest/unity)
        target_coverage: Target coverage percentage (0-100)
        source_real_path: Resolved source path supplied by the client
        scope: Test scope description
        compile_errors: Previous round of compile errors (for fix iterations)
        skill_prompt: Skill instructions
        test_filename: Test implementation filename (used for two-file output instructions)
        test_header_filename: Test header filename
        clang_guidance: LibClang analysis guidance text
        header_content: Header file content corresponding to the source file
        dependent_hal_headers: typedef/struct/enum definitions from dependent HAL headers
        vendor_api_ref: Vendor API signature references
        existing_mock_ref: Existing mock file references
        mock_dependency_guidance: Cross-module mock dependency guidance
        project_context: Project context information
        large_file_context: Backend-generated context for oversized source files
    """

    normalized_file_path = file_path.replace("\\", "/")
    normalized_real_path = source_real_path.replace("\\", "/") if source_real_path else ""
    source_path_line = f"Source file path: {normalized_real_path}\n" if normalized_real_path else ""

    parts = [
        f"Generate unit tests for the following {layer} layer C/C++ file.\n"
        f"Source file name: {normalized_file_path.split('/')[-1]}\n"
        f"{source_path_line}"
        f"Framework: {framework}\n"
        f"Target coverage: {target_coverage}%\n"
        f"Scope: {scope}\n",
        f"\n--- Mandatory Test Quality Contract ---\n{TEST_QUALITY_CONTRACT}\n",
    ]

    # Inject skill instructions (project-level detailed rules)
    if skill_prompt:
        parts.append(f"\n--- Skill Instructions ---\n{skill_prompt}\n")

    # Inject LibClang analysis guidance
    if clang_guidance:
        parts.append(f"\n--- LibClang Analysis ---\n{clang_guidance}\n")

    # Inject header file content
    if header_content:
        parts.append(f"\n--- Header File ---\n```c\n{header_content}\n```\n")

    # Inject dependent HAL header structure definitions
    if dependent_hal_headers:
        parts.append(f"\n{dependent_hal_headers}\n")

    # Inject vendor API signature references
    if vendor_api_ref:
        parts.append(f"\n{vendor_api_ref}\n")

    # Inject existing mock file references
    if existing_mock_ref:
        parts.append(f"\n{existing_mock_ref}\n")

    # Inject cross-module mock dependency guidance
    if mock_dependency_guidance:
        parts.append(f"\n--- Mock Dependency Guidance ---\n{mock_dependency_guidance}\n")

    # Inject project context
    if project_context:
        parts.append(f"\n--- Project Context ---\n{project_context}\n")

    # Inject oversized source analysis before the source code block.
    if large_file_context:
        parts.append(
            "\n--- Large Source Analysis (Use This as the Priority Map) ---\n"
            f"{large_file_context}\n"
            "\n--- Large-File Generation Procedure ---\n"
            "Generate tests chunk by chunk using the listed checkpoint manifest. Keep one shared fixture and one mock ownership model, merge chunks into the requested output files, and after each chunk write/read back, build, run tests, and update its checkpoint. Resume from the first incomplete chunk and do not replace uncovered chunks with placeholder smoke tests. Use the backend-injected long-file workflow snapshot when available.\n"
        )

    # Inject compile error feedback
    if compile_errors:
        error_text = "\n".join(
            f"  - {e.get('file', '')}:{e.get('line', 0)}: {e.get('message', '')}"
            for e in compile_errors
        )
        parts.append(
            f"\n--- Previous Compile Errors (MUST FIX) ---\n{error_text}\n"
            "Please fix these errors in the generated test code.\n"
        )

    parts.append(f"\nFile: {file_path}\n```c\n{content}\n```\n")

    if test_filename and test_header_filename:
        # Derive mock filenames from the test filename
        mock_header_fn = test_filename.replace("tc-", "mock-").replace(".cpp", ".h")
        mock_impl_fn = test_filename.replace("tc-", "mock-")
        if "stm32" not in mock_header_fn and "hal-" in mock_header_fn:
            mock_header_fn = mock_header_fn.replace("mock-hal-", "mock-stm32-hal-")
            mock_impl_fn = mock_impl_fn.replace("mock-hal-", "mock-stm32-hal-")
        parts.append(
            f"**OUTPUT FORMAT (STRICT — follow exactly):**\n"
            f"Wrap each file in XML tags. Do NOT use markdown code blocks.\n\n"
            f"<file name=\"{test_filename}\">\n"
            f"...complete test implementation code...\n"
            f"</file>\n\n"
            f"<file name=\"{test_header_filename}\">\n"
            f"...complete test header code...\n"
            f"</file>\n\n"
            f"<file name=\"{mock_header_fn}\">\n"
            f"...complete mock header with MOCK_METHOD declarations...\n"
            f"</file>\n\n"
            f"<file name=\"{mock_impl_fn}\">\n"
            f"...complete mock implementation with C wrapper functions...\n"
            f"</file>\n\n"
            f"Do NOT include any text outside the <file> tags.\n"
        )
    else:
        parts.append("Generate the complete test file.")

    return "\n".join(parts)


def build_two_phase_prompt(
    source_code: str,
    file_path: str,
    layer: str,
    framework: str,
    target_coverage: float,
    file_paths: dict,
    header_content: str = "",
    dependent_hal_headers: str = "",
    vendor_api_ref: str = "",
    existing_mock_ref: str = "",
    mock_dependency_guidance: str = "",
    skill_prompt: str = "",
    clang_guidance: str = "",
    project_context: str = "",
) -> tuple[str, str]:
    """Build a two-phase generation prompt to prevent output truncation.

    Phase 1: Generate only test files (tc-*.h + tc-*.cpp)
    Phase 2: Generate only mock files (mock-*.h + mock-*.cpp), injecting Phase 1 output as context

    Args:
        source_code: Source file content
        file_path: Source file path
        layer: Architecture layer
        framework: Test framework
        target_coverage: Target coverage
        file_paths: Path dictionary returned by generate_file_paths
        other args: Same as build_generation_prompt

    Returns:
        (phase1_prompt, phase2_prompt_template)
        phase2_prompt_template contains the {phase1_output} placeholder
    """

    layer_rules = get_layer_rules(layer)
    style_rules = get_code_style_rules()

    test_file = file_paths.get("test_file", "")
    test_header = file_paths.get("test_header", "")
    mock_file = file_paths.get("mock_file", "")
    mock_header = file_paths.get("mock_header", "")

    # Shared context section
    context_parts: list[str] = []
    if layer_rules:
        context_parts.append(f"--- Layer-Specific Testing Rules ---\n{layer_rules}")
    if style_rules:
        context_parts.append(f"--- Code Style Rules ---\n{style_rules}")
    if skill_prompt:
        context_parts.append(f"--- Skill Instructions ---\n{skill_prompt}")
    if clang_guidance:
        context_parts.append(f"--- LibClang Analysis ---\n{clang_guidance}")
    if header_content:
        context_parts.append(f"--- Header File ---\n```c\n{header_content}\n```")
    if dependent_hal_headers:
        context_parts.append(dependent_hal_headers)
    if vendor_api_ref:
        context_parts.append(vendor_api_ref)
    if existing_mock_ref:
        context_parts.append(existing_mock_ref)
    if mock_dependency_guidance:
        context_parts.append(f"--- Mock Dependency Guidance ---\n{mock_dependency_guidance}")
    if project_context:
        context_parts.append(f"--- Project Context ---\n{project_context}")

    shared_context = "\n\n".join(context_parts)

    # Phase 1: Generate only test files
    phase1 = (
        f"Generate ONLY the test files for the following {layer} layer C/C++ file.\n"
        f"Framework: {framework}\n"
        f"Target coverage: {target_coverage}%\n\n"
        f"{shared_context}\n\n"
        f"File: {file_path}\n```c\n{source_code}\n```\n\n"
        f"**OUTPUT INSTRUCTIONS — Phase 1 (TEST FILES ONLY):**\n"
        f"Generate EXACTLY 2 files in separate code blocks:\n"
        f"1. `{test_file}` — the complete test implementation (.cpp)\n"
        f"2. `{test_header}` — the test header (.h)\n\n"
        f"**DO NOT generate mock files in this phase.**\n"
        f"Label each code block:\n"
        f"```cpp\n// {test_file}\n...code...\n```\n"
        f"```cpp\n// {test_header}\n...code...\n```\n"
    )

    # Phase 2: Generate only mock files (template containing the {phase1_output} placeholder)
    phase2_template = (
        f"Generate ONLY the mock files for the following {layer} layer C/C++ file.\n"
        f"Framework: {framework}\n\n"
        f"{shared_context}\n\n"
        f"File: {file_path}\n```c\n{source_code}\n```\n\n"
        f"**The test files have already been generated (Phase 1 output below):**\n"
        f"```\n{{phase1_output}}\n```\n\n"
        f"**OUTPUT INSTRUCTIONS — Phase 2 (MOCK FILES ONLY):**\n"
        f"Generate EXACTLY 2 files in separate code blocks:\n"
        f"1. `{mock_file}` — the complete mock implementation (.cpp)\n"
        f"2. `{mock_header}` — the mock header (.h)\n\n"
        f"**DO NOT generate test files in this phase.**\n"
        f"Label each code block:\n"
        f"```cpp\n// {mock_file}\n...code...\n```\n"
        f"```cpp\n// {mock_header}\n...code...\n```\n"
    )

    return phase1, phase2_template


def build_coverage_improvement_prompt(
    uncovered_functions: list[str],
    uncovered_lines: list[tuple[int, int]],
    previous_test_content: str,
    source_code: str,
) -> str:
    """Build the coverage improvement prompt.

    Args:
        uncovered_functions: List of uncovered function names
        uncovered_lines: List of uncovered line ranges [(start, end), ...]
        previous_test_content: Previously generated test code
        source_code: Source file content
    """
    parts = ["Improve the test coverage for the following source code.\n"]

    if uncovered_functions:
        func_list = ", ".join(uncovered_functions)
        parts.append(f"**Uncovered functions**: {func_list}\n")

    if uncovered_lines:
        ranges = [f"L{s}-L{e}" if s != e else f"L{s}" for s, e in uncovered_lines]
        parts.append(f"**Uncovered line ranges**: {', '.join(ranges)}\n")

    parts.append(
        "\n**Previous test code (for reference — add more tests, do not remove existing ones):**\n"
        f"```cpp\n{previous_test_content[:6000]}\n```\n"
    )
    parts.append(f"\n**Source code:**\n```c\n{source_code}\n```\n")
    parts.append(
        "\nGenerate additional test cases to cover the uncovered functions and lines. "
        "Return the COMPLETE updated test file (including all previous tests)."
    )
    return "\n".join(parts)


def build_test_failure_fix_prompt(
    failed_tests: list[str],
    test_output: str,
    previous_test_content: str,
) -> str:
    """Build the prompt for fixing failed tests.

    Args:
        failed_tests: List of failed test case names
        test_output: Test execution output
        previous_test_content: Current test code
    """
    failed_list = "\n".join(f"  - {t}" for t in failed_tests)
    return (
        "The following unit tests are failing. Fix them and return the corrected test file.\n\n"
        f"**Failed tests:**\n{failed_list}\n\n"
        f"**Test execution output:**\n```\n{test_output[:4000]}\n```\n\n"
        f"**Current test code:**\n```cpp\n{previous_test_content[:8000]}\n```\n\n"
        "Fix the failing tests. Return the COMPLETE corrected test file."
    )


def build_fix_prompt(
    test_code: str,
    errors: list[dict],
) -> str:
    """Build the compile error fix prompt."""
    error_text = "\n".join(
        f"  - {e.get('file', '')}:{e.get('line', 0)}:{e.get('column', 0)}: "
        f"{e.get('severity', 'error')}: {e.get('message', '')}"
        for e in errors
    )
    return (
        "The following test code has compile errors. Fix them and return the corrected code.\n\n"
        f"Errors:\n{error_text}\n\n"
        f"Test code:\n```cpp\n{test_code}\n```\n\n"
        "Return the complete fixed test file."
    )


def build_mock_prompt(
    external_calls: list[str],
    mock_framework: str,
    related_headers: list[str],
    skill_prompt: str = "",
    mock_filename: str = "",
    mock_header_filename: str = "",
    clang_guidance: str = "",
) -> str:
    """Build the mock code generation prompt."""
    calls_text = ", ".join(external_calls) if external_calls else "(none detected)"
    headers_text = ", ".join(related_headers) if related_headers else "(none)"
    parts = [
        f"Generate mock implementations for the following external function calls.\n"
        f"Mock framework: {mock_framework}\n"
        f"External calls to mock: {calls_text}\n"
        f"Related headers: {headers_text}\n",
    ]
    if skill_prompt:
        parts.append(f"\n--- Skill Instructions ---\n{skill_prompt}\n")
    if clang_guidance:
        parts.append(f"\n--- LibClang Analysis ---\n{clang_guidance}\n")

    if mock_filename and mock_header_filename:
        parts.append(
            f"Generate TWO files in separate code blocks:\n"
            f"1. `{mock_filename}` — the complete mock implementation (.cpp) "
            f"with mock object definitions and C wrapper functions\n"
            f"2. `{mock_header_filename}` — the mock header (.h) with include guards, "
            f"MOCK_METHOD class declarations, and extern mock object declarations\n\n"
            f"Label each code block with the filename on the first line as a comment:\n"
            f"```cpp\n// {mock_filename}\n...code...\n```\n"
            f"```cpp\n// {mock_header_filename}\n...code...\n```\n"
        )
    else:
        parts.append("Generate the complete mock header and implementation files.")
    return "\n".join(parts)


def build_multi_file_fix_prompt(
    file_contents: dict[str, str],
    errors: list,
    file_paths: dict[str, str] | None = None,
) -> str:
    """Build a prompt that sends all 4 files + compile errors to LLM for multi-file fix.

    Args:
        file_contents: dict with keys test_impl, test_header, mock_impl, mock_header
        errors: list of CompileError or dicts with 'message' key
        file_paths: optional dict mapping keys to actual file paths (for context)
    """
    parts = [
        "Fix the following compilation errors. The project has 4 source files "
        "that must be consistent with each other. Return ALL files that need changes.\n"
        "First classify each diagnostic as preprocess, compile, link, or test-fixture failure and identify its root cause. "
        "Never fix a source-static linkage error by adding an extern declaration in another translation unit; use a test-only access adapter or a public API test.\n"
    ]

    # Error listing
    error_lines = []
    for e in errors:
        if hasattr(e, "file"):
            error_lines.append(f"{e.file}:{e.line}:{e.column}: {e.severity}: {e.message}")
        elif isinstance(e, dict):
            error_lines.append(e.get("message", str(e)))
        else:
            error_lines.append(str(e))
    parts.append(f"Compilation errors:\n```\n" + "\n".join(error_lines) + "\n```\n")

    # File contents
    labels = {
        "test_impl": "Test Implementation (.cpp)",
        "test_header": "Test Header (.h)",
        "mock_impl": "Mock Implementation (.cpp)",
        "mock_header": "Mock Header (.h)",
    }
    for key, label in labels.items():
        content = file_contents.get(key, "")
        if not content:
            continue
        path_hint = ""
        if file_paths and file_paths.get(key):
            path_hint = f" — {file_paths[key]}"
        parts.append(f"### {label}{path_hint}\n```cpp\n{content}\n```\n")

    parts.append(
        "Return the corrected files using labeled code blocks. "
        "Use a comment on the first line to identify each file:\n"
        "```cpp\n// tc-xxx.cpp\n...corrected code...\n```\n"
        "```cpp\n// tc-xxx.h\n...corrected code...\n```\n"
        "```cpp\n// mock-xxx.cpp\n...corrected code...\n```\n"
        "```cpp\n// mock-xxx.h\n...corrected code...\n```\n"
        "Only include files that actually need changes. "
        "Each file must be complete (not a diff)."
    )
    return "\n".join(parts)


def _build_cli_read_safety_rules(*, large_file_mode: bool = False) -> str:
    """Return shared guardrails for Claude CLI file reads.

    Large-file mode gets a bounded-range rule; normal files keep the simpler
    single-read guidance and are not forced through chunking.
    """
    chunk_rule = (
        "- Large-file mode: use the backend source index and inclusive chunk line ranges; "
        "read only the active range plus minimal declarations, and do not reread completed chunks\n"
        if large_file_mode
        else "- Normal-sized source: read the resolved source once and reuse that context\n"
    )
    return (
        "Read safety rules:\n"
        "- Read only text source/config/build files relevant to this task\n"
        "- Read only the resolved source file under test, generated test/mock files, and the exact QBS file already selected for this task\n"
        "- Do NOT speculate about other files, directories, or archives when a read fails; stop and use the known paths only\n"
        "- Do NOT read binary files, executables, archives, images, or .gcda/.gcno artifacts\n"
        "- Forbidden examples: .rar, .zip, .7z, .tar, .exe, .dll, .so, .a, .o, .obj, .gcda, .gcno\n"
        "- Do NOT use PDF page arguments unless you are reading an actual .pdf file\n"
        "- Do NOT pass page arguments when reading normal source files\n"
        "- Never send pages=\"\" or any empty page argument\n"
        "- Do not run gcov or inspect coverage artifacts; after the CLI finishes, the backend collects coverage with the toolchain matching the selected QBS profile\n"
        "Build verification rules:\n"
        "- Redirect each build's complete stdout and stderr to a log in the task build directory, and capture the build exit code immediately\n"
        "- Never pipe a running build into head, tail, grep, or another command; inspect the saved log after the build finishes\n"
        "- A successful log-reading command or CLI exit does not prove compilation; require the actual build exit code and target executable\n"
        "- Check qbs help before changing command options; qbs build has no --clean-build option, and qbs clean accepts neither -f nor profile assignments\n"
        "- Use the task's platform header overlay for host tests; never add the aggregate overwrite-inc directory or suppress MCU pointer errors with -fpermissive\n"
        "- Match FreeRTOS typedefs and callback signatures exactly; undefine function-like timer macros before declaring mock methods\n"
        "- Report build-output decoding or tool configuration failures as infrastructure errors, not source-file encoding errors\n"
        f"{chunk_rule}"
    )


def build_autonomous_fix_system_prompt(
    file_paths: dict[str, str],
    project_root: str,
    *,
    coverage_target: float = 0.0,
    current_coverage: float = 0.0,
    branch_coverage_target: float = 0.0,
    current_branch_coverage: float = 0.0,
    function_coverage_target: float = 0.0,
    current_function_coverage: float = 0.0,
    source_code: str = "",
    qbs_project_path: str = "",
    qbs_file: str = "",
    qbs_product: str = "",
    reference_files: dict[str, str] | None = None,
) -> str:
    """System prompt for Claude CLI autonomous fix session.

    When *coverage_target* > 0 and *current_coverage* < *coverage_target*,
    the prompt instructs Claude CLI to also add test cases to close the gap.
    """
    paths_info = "\n".join(f"  - {k}: {v}" for k, v in file_paths.items() if v)
    reference_block = _build_reference_block(reference_files)

    need_coverage_boost = (
        (coverage_target > 0 and current_coverage < coverage_target)
        or (branch_coverage_target > 0 and current_branch_coverage < branch_coverage_target)
        or (function_coverage_target > 0 and current_function_coverage < function_coverage_target)
    )

    qbs_info = ""
    if qbs_project_path or qbs_file or qbs_product:
        qbs_info = (
            "\nTask-scoped QBS target (authoritative; do not fall back to the aggregate target):\n"
            f"  Project directory: {qbs_project_path}\n"
            f"  Project file: {qbs_file}\n"
            f"  Product: {qbs_product}\n"
        )

    base = (
        "You are an expert C/C++ embedded firmware developer. "
        "Your task is to fix compilation errors in unit test files "
        "for a QBS-based project.\n\n"
        f"Project root: {project_root}\n"
        f"{qbs_info}"
        f"Files:\n{paths_info}\n\n"
        f"{reference_block}"
        "Identifiers in test/mock code must match the reference source files "
        "verbatim; never invent API names.\n\n"
        "You have full access to read, edit, and write files, "
        "and run shell commands. "
        "Use the QBS build system to verify your fixes compile successfully.\n\n"
        "File writing rules:\n"
        "- Check all listed output paths in one shell existence command\n"
        "- Create missing output files directly; do not call Read on a missing path\n"
        "- Read each existing output at most once before Edit or Write\n"
        f"{_build_cli_read_safety_rules()}"
    )

    if need_coverage_boost:
        coverage_info = []
        if coverage_target > 0:
            coverage_info.append(f"  Current line coverage : {current_coverage:.1f}%")
            coverage_info.append(f"  Target line coverage  : {coverage_target:.1f}%")
        if branch_coverage_target > 0:
            coverage_info.append(f"  Current branch coverage : {current_branch_coverage:.1f}%")
            coverage_info.append(f"  Target branch coverage  : {branch_coverage_target:.1f}%")
        if function_coverage_target > 0:
            coverage_info.append(f"  Current function coverage : {current_function_coverage:.1f}%")
            coverage_info.append(f"  Target function coverage  : {function_coverage_target:.1f}%")
        
        base += (
            f"\nAfter fixing all compilation errors, you MUST also improve "
            f"test coverage.\n"
            + "\n".join(coverage_info) + "\n\n"
            "Read the source file under test, identify untested functions "
            "and branches, then add new TEST_F cases to the test .cpp file. "
            "Ensure the new tests compile and pass.\n"
            "Do NOT remove or weaken existing tests."
        )
    else:
        base += (
            "Focus on fixing the compilation errors. "
            "Do not change the test logic."
        )

    return base


def build_autonomous_coverage_fix_prompt(
    error_message: str,
    build_output: str,
    file_paths: dict[str, str],
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
    build_profile: str = "mingw",
    qbs_project_path: str = "",
    qbs_file: str = "",
    qbs_product: str = "",
) -> str:
    """Build the task prompt for Claude CLI coverage build repair."""
    paths_info = "\n".join(f"  - {k}: {v}" for k, v in file_paths.items() if v)
    qbs_cmd = "qbs build"
    if qbs_project_path:
        # Compute posix paths before the f-string: f-string expressions
        # cannot contain backslashes on Python 3.11
        project_posix = str(qbs_project_path).replace("\\", "/")
        qbs_cmd += f" -d {project_posix}"
    if qbs_file:
        file_posix = str(qbs_file).replace("\\", "/")
        qbs_cmd += f" -f {file_posix}"
    if qbs_product:
        qbs_cmd += f" -p {qbs_product}"
    qbs_cmd += f" profile:{build_profile}"
    target_info = ""
    if qbs_project_path or qbs_file or qbs_product:
        target_info = (
            "\nTask-scoped QBS target (authoritative):\n"
            f"  Project directory: {qbs_project_path}\n"
            f"  Project file: {qbs_file}\n"
            f"  Product: {qbs_product}\n"
        )
    return (
        "Fix the QBS build so coverage can be collected.\n\n"
        f"Build error:\n```\n{error_message}\n```\n\n"
        f"Build output:\n```\n{build_output[:8000]}\n```\n\n"
        f"Files to inspect:\n{paths_info}\n\n"
        f"Project root: {project_root}\n"
        f"{target_info}"
        f"Layer: {layer}\n"
        f"Platform: {platform}\n"
        f"Build profile: {build_profile}\n\n"
        "Steps:\n"
        "1. Read the relevant QBS and source files\n"
        "2. Fix the build configuration or generated code that prevents coverage rebuild\n"
        f"3. Re-run QBS build with coverage enabled using `{qbs_cmd}`\n"
        "4. Keep the change minimal and do not weaken tests\n"
        "5. Verify the build result; report the blocker if the repair budget is exhausted\n"
        f"\n{_build_cli_read_safety_rules()}\n"
    )


# Inline budget for reference source files in repair prompts: uploaded SUT
# headers are small, but a runaway upload must not blow up the prompt.
_MAX_REFERENCE_INLINE_CHARS = 8000


def _build_reference_block(reference_files: dict[str, str] | None) -> str:
    """Render verified SUT paths (plus small inline contents) for repair prompts.

    Without this block the repair CLI guesses header paths (wrong-path Reads
    burn attempts and trip the deterministic-loop guard) and invents API names
    the real headers never declared.
    """
    if not reference_files:
        return ""
    header_lines = [
        "--- Reference source files (verified to exist; ground truth for identifiers) ---",
        "Every identifier used in test/mock code must exist in these files.",
        "When a diagnostic says an identifier is undeclared, find the real name here.",
    ]
    inlined: list[str] = []
    budget = _MAX_REFERENCE_INLINE_CHARS
    for path, content in reference_files.items():
        if not path:
            continue
        path_fwd = str(path).replace("\\", "/")
        if not content:
            header_lines.append(f"  - {path_fwd} (read this file for the exact API)")
        elif len(content) <= budget:
            budget -= len(content)
            inlined.append(f"/* ===== {path_fwd} ===== */\n{content}")
        else:
            inlined.append(
                f"/* ===== {path_fwd} (truncated) ===== */\n{content[:max(budget, 0)]}"
            )
            budget = 0
    block = "\n".join(header_lines) + "\n"
    if inlined:
        block += "\n```c\n" + "\n\n".join(inlined) + "\n```\n"
    return block


def build_autonomous_fix_prompt(
    errors: list,
    file_paths: dict[str, str],
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
    build_profile: str = "mingw",
    *,
    coverage_target: float = 0.0,
    current_coverage: float = 0.0,
    source_code: str = "",
    qbs_project_path: str = "",
    qbs_file: str = "",
    qbs_product: str = "",
    reference_files: dict[str, str] | None = None,
) -> str:
    """Build the task prompt for Claude CLI autonomous fix.

    When *coverage_target* > 0 and *current_coverage* < *coverage_target*,
    extra steps are appended asking Claude CLI to add test cases.
    """
    # Error listing
    error_lines = []
    for e in errors:
        if hasattr(e, "file"):
            error_lines.append(f"{e.file}:{e.line}:{e.column}: {e.severity}: {e.message}")
        elif isinstance(e, dict):
            error_lines.append(e.get("message", str(e)))
        else:
            error_lines.append(str(e))
    error_text = "\n".join(error_lines)

    # File paths
    paths_info = "\n".join(f"  - {k}: {v}" for k, v in file_paths.items() if v)

    # Verified SUT reference files (paths + inline contents)
    reference_block = _build_reference_block(reference_files)

    # QBS build command for verification
    from .qbs import resolve_qbs_project_path, resolve_qbs_file_path
    qbs_dir = qbs_project_path or resolve_qbs_project_path(project_root, layer, platform)
    qbs_file = qbs_file or resolve_qbs_file_path(project_root, layer, platform)
    # Use forward slashes for all paths in prompt to avoid Windows backslash escaping issues
    qbs_dir_forward = str(qbs_dir).replace('\\', '/')
    qbs_cmd = f"qbs build -d {qbs_dir_forward}"
    if qbs_file:
        qbs_file_forward = str(qbs_file).replace('\\', '/')
        qbs_cmd += f" -f {qbs_file_forward}"
    if qbs_product:
        qbs_cmd += f" -p {qbs_product}"
    qbs_cmd += f" profile:{build_profile}"

    target_info = ""
    if qbs_project_path or qbs_product:
        target_info = (
            "\nTask-scoped QBS target (authoritative; never use the aggregate target):\n"
            f"  Project directory: {qbs_dir}\n"
            f"  Project file: {qbs_file}\n"
            f"  Product: {qbs_product}\n"
        )

    # Layer rules give the repair CLI the same invariants the generation
    # run had (mock scope, naming, link-collision rules) — without them a
    # "multiple definition" link error gets patched blind.
    layer_rules = get_layer_rules(layer)
    layer_rules_block = f"\n--- Layer Rules ---\n{layer_rules}\n" if layer_rules else ""

    need_coverage_boost = (
        coverage_target > 0 and current_coverage < coverage_target
    )

    # --- base steps: fix compilation errors ---
    prompt = (
        f"Fix the compilation errors in the following unit test files.\n\n"
        f"Compilation errors:\n```\n{error_text}\n```\n\n"
        f"Files to fix:\n{paths_info}\n\n"
        f"{reference_block}"
        f"{target_info}"
        f"{layer_rules_block}"
        f"Steps:\n"
        f"1. Read each file listed above\n"
        f"2. Classify each diagnostic as preprocess, compile, link, or test-fixture failure and state the root cause before editing\n"
        f"3. Edit the files to fix the root cause; do not paper over an unresolved symbol with an invented declaration\n"
        f"4. Verify by running: `{qbs_cmd}`\n"
        f"5. If compilation still fails, compare the new diagnostics with the previous ones and make a materially different fix\n"
        f"6. If the diagnostics and generated files are unchanged, stop and report the blocking root cause instead of invoking another CLI repair\n"
    )

    # --- extra steps: improve coverage ---
    if need_coverage_boost:
        prompt += (
            f"\nAfter compilation succeeds, improve test coverage:\n"
            f"6. Read the source file under test to identify all public functions "
            f"and branches\n"
            f"7. Compare with existing TEST_F cases — find untested functions "
            f"and uncovered branches\n"
            f"8. Add new TEST_F cases to the test .cpp file to cover them "
            f"(keep existing tests intact)\n"
            f"9. Add any new mock expectations needed in the mock files\n"
            f"10. Rebuild with `{qbs_cmd}` to verify the new tests compile\n\n"
            f"Coverage context:\n"
            f"  Current coverage : {current_coverage:.1f}%\n"
            f"  Target coverage  : {coverage_target:.1f}%\n"
        )
        if source_code:
            # Truncate to avoid blowing up the prompt
            src_preview = source_code[:6000]
            if len(source_code) > 6000:
                src_preview += "\n... (truncated)"
            prompt += (
                f"\nSource file under test:\n```c\n{src_preview}\n```\n"
            )

    prompt += (
        f"\nImportant:\n"
        f"- Ensure all #include paths are correct for the project structure\n"
        f"- Mock headers must declare all symbols used by the test implementation\n"
        f"- The test header must include the correct mock headers\n"
        f"- The reference source files above are the ONLY valid source of API identifiers; "
        f"never invent function, macro, enum, or variable names\n"
        f"- Mock only the dependencies the module under test calls; the module's own "
        f"public functions are the test entry points and must never be mocked\n"
        f"- Every extern mock instance declared in a mock header must be defined in "
        f"exactly one mock .cpp, which also defines the dependency's C functions "
        f"forwarding to that instance\n"
        f"- Check all listed output paths in one shell existence command\n"
        f"- Create missing output files directly; do not call Read on a missing path\n"
        f"- Read each existing output at most once before Edit or Write\n"
        f"- Read only the listed test/mock files, the reference source files above, "
        f"the resolved source file under test, and the exact QBS file selected by "
        f"the backend when coverage work is explicitly required\n"
        f"- If a Read fails, do not guess alternate files or archives; use only the known paths returned by the backend\n"
        f"- Do NOT read binary artifacts such as .gcda, .gcno, executables, libraries, images, or archives\n"
        f"- Forbidden examples include .rar, .zip, .7z, .tar, .exe, .dll, .so, .a, .o, .obj\n"
        f"- Do NOT use page arguments with Read unless reading a real PDF\n"
        f"- Never send pages=\"\" or any empty page argument\n"
        f"- Do NOT inspect unrelated qbs files or broad project trees\n"
    )
    if not need_coverage_boost:
        prompt += (
            f"\n- Fix only compilation errors, do not change test logic"
        )

    return prompt


# ========== CLI-First Pipeline Prompts ==========


def build_cli_generation_system_prompt(
    file_paths: dict[str, str],
    project_root: str,
    layer: str = "hal",
    coverage_target: float = 80.0,
    large_file_mode: bool = False,
    compile_verify: bool = True,
    enable_mock: bool = True,
) -> str:
    """System prompt for Claude CLI test generation session."""
    file_paths = filter_mock_paths(file_paths, enable_mock)
    paths_info = "\n".join(f"  - {k}: {v}" for k, v in file_paths.items() if v)
    size_mode_guidance = (
        "Large-file mode is active. The task prompt already contains the selected "
        "long-file workflow and layer skill contract. Follow its function-group "
        "and checkpoint contract without reading the source Skill files again.\n"
        if large_file_mode
        else "Normal-sized mode is active. The long-file workflow does not apply. "
        "Use the backend-injected generic and layer Skill snapshot without reading "
        "the source Skill files again.\n"
    )
    mock_guidance = (
        "Generate mock files for hardware dependencies.\n"
        if enable_mock
        else "Do not generate mock files or mock headers; the caller explicitly disabled mock generation.\n"
    )
    verification_guidance = (
        "Generate high-quality GTest unit tests, compile them "
        "with QBS, and ensure all tests pass.\n"
        f"Target line coverage: {coverage_target:.1f}%\n"
        if compile_verify
        else "Generate only the requested artifacts. Do not update QBS files. Do not compile, run tests, or collect coverage.\n"
    )

    return (
        "You are an expert C/C++ embedded firmware developer specializing in "
        "unit test generation for embedded systems.\n\n"
        f"Project root: {project_root}\n"
        f"Layer: {layer}\n"
        f"Target files:\n{paths_info}\n"
        "\nBackend output path contract (HIGHEST PRIORITY):\n"
        "- Every output path listed under Target files is authoritative.\n"
        "- Write, edit, read back, and register the generated artifact at exactly "
        "that path.\n"
        "- Do not create an alternate test or mock directory, even when a skill, "
        "reference, existing QBS entry, or example shows a different layout.\n"
        "- Derive QBS Group entries from these exact paths relative to the Group "
        "prefix; never derive a new output path from a filename example.\n"
        f"\nSkill execution contract:\n{size_mode_guidance}"
        "You have full access to read, edit, and write files, and run shell "
        f"commands. {verification_guidance}\n"
        f"{mock_guidance}{TEST_QUALITY_CONTRACT}\n\n"
        "File writing rules:\n"
        "- Check every target output path in one shell existence check before reading outputs\n"
        "- A missing output is an expected first-generation state; create its parent directory and use Write directly\n"
        "- Do not call Read on a missing output path and do not spend another model turn confirming the same absence\n"
        "- Read each existing output at most once before Edit or Write\n"
        f"{_build_cli_read_safety_rules(large_file_mode=large_file_mode)}"
    )


def build_cli_generation_prompt(
    source_file: str,
    source_content: str,
    file_paths: dict[str, str],
    project_root: str,
    source_real_path: str = "",
    layer: str = "hal",
    platform: str = "stm32u3",
    build_profile: str = "mingw",
    coverage_target: float = 80.0,
    header_content: str = "",
    dependent_headers: str = "",
    vendor_api_ref: str = "",
    existing_mock_ref: str = "",
    mock_dependency_guidance: str = "",
    skill_prompt: str = "",
    previous_context_summary: str = "",
    large_file_context: str = "",
    qbs_project_path: str = "",
    qbs_file: str = "",
    qbs_products: list[str] | None = None,
    qbs_prepared: bool = False,
    compile_verify: bool = True,
    enable_mock: bool = True,
) -> str:
    """Build the task prompt for Claude CLI test generation.

    Instructs Claude CLI to use injected skills, read source, write tests, compile, fix, and run tests.
    """
    from .qbs import resolve_qbs_project_path, resolve_qbs_file_path

    file_paths = filter_mock_paths(file_paths, enable_mock)
    paths_info = "\n".join(f"  - {k}: {v}" for k, v in file_paths.items() if v)
    qbs_cmd = ""
    if compile_verify:
        qbs_dir = qbs_project_path or resolve_qbs_project_path(project_root, layer, platform)
        qbs_file = qbs_file or resolve_qbs_file_path(project_root, layer, platform)
        # Use forward slashes for all paths in prompt to avoid Windows backslash escaping issues
        qbs_dir_forward = str(qbs_dir).replace('\\', '/')
        qbs_cmd = f"qbs build -d {qbs_dir_forward}"
        if qbs_file:
            qbs_file_forward = str(qbs_file).replace('\\', '/')
            qbs_cmd += f" -f {qbs_file_forward}"
        if qbs_products:
            qbs_cmd += f" -p {qbs_products[0]}"
        qbs_cmd += f" profile:{build_profile}"

    # Layer rules
    layer_rules = get_layer_rules(layer)
    style_rules = get_code_style_rules()

    src_preview = source_content[:8000]
    if len(source_content) > 8000:
        src_preview += "\n... (truncated)"
    source_filename = source_file.replace("\\", "/").split("/")[-1]
    normalized_source_path = source_real_path.replace("\\", "/") if source_real_path else ""
    large_file_read_rule = (
        "- In large-file mode, use the backend source index and inclusive chunk line ranges; "
        "read only the current chunk plus minimal declarations and do not reread completed chunks\n"
        if large_file_context
        else "- For a normal-sized source, read the resolved source once and reuse that context; do not repeatedly reload it\n"
    )
    source_path_line = (
        f"Source absolute path: {normalized_source_path}\n"
        if normalized_source_path
        else ""
    )

    source_interface_rules = (
        "\n**SOURCE INTERFACE CONTRACT:**\n"
        "- A standalone .c file may have no matching .h. Never invent or include a header merely from the source basename.\n"
        "- Include only headers that actually exist. If no public header exists, derive exact declarations from the real C definitions and use extern \"C\" declarations in the test header. Link the original .c exactly once as C.\n"
        "- Never replace the source implementation or redefine its functions inside tests or mocks. For static internals, use the supported test-access translation unit without duplicate compilation.\n"
        "- If the original source itself needs unavailable project headers, report the exact missing dependency; do not fabricate firmware types or behavior.\n"
    )

    coverage_line = (
        f"Target coverage: {coverage_target:.1f}%\n"
        if compile_verify else "Coverage measurement: disabled\n"
    )
    mock_rule = (
        "- Generate mock files when required by the source dependencies.\n"
        if enable_mock
        else "- Mock generation is disabled. Do not create, edit, or register mock files.\n"
    )
    prompt = (
        f"Generate unit tests for the following {layer} layer source file.\n\n"
        f"Source filename: {source_filename}\n"
        f"Source identifier: {source_file}\n"
        f"{source_path_line}"
        f"Platform: {platform}\n"
        f"{coverage_line}"
        f"Test framework: GTest + GMock\n{mock_rule}\n"
        f"Output files (CRITICAL - write to EXACTLY these paths):\n{paths_info}\n\n"
    )
    prompt += format_previous_compact_context(previous_context_summary)
    prompt += source_interface_rules
    if qbs_prepared:
        prompt += (
            "\n**BACKEND-PREPARED QBS TARGET:**\n"
            f"- Project directory: {qbs_dir}\n"
            f"- Project file: {qbs_file}\n"
            f"- Product: {(qbs_products or [''])[0]}\n"
            "- The backend already populated this target with the exact source, test, and mock paths. Run the build directly; do not read or edit the QBS file unless QBS reports that a listed path is missing.\n"
        )

    if normalized_source_path:
        if large_file_context:
            prompt += (
                "\n**SOURCE READ STEP (MANDATORY — LARGE-FILE MODE):**\n"
                f"- Use this resolved source path as ground truth: {normalized_source_path}\n"
                "- Use the backend source identity and indexed chunk manifest as the source-of-truth checkpoint. Read only the current inclusive chunk range plus minimal declarations needed by that chunk; do not load the complete large source into a model turn.\n"
                "- Use the real file as implementation ground truth.\n"
                "- Use the backend-selected excerpt and analysis as the priority map; do not infer the source from similarly named files elsewhere.\n"
            )
        else:
            prompt += (
                "\n**SOURCE READ STEP (MANDATORY):**\n"
                f"- Read the complete source file from: {normalized_source_path}\n"
                "- Use the real file as implementation ground truth.\n"
                "- Use the backend-selected excerpt and analysis only as a priority map.\n"
                "- Do not infer the source from similarly named files elsewhere in the repository.\n"
                f"{large_file_read_rule}"
            )

    if large_file_context:
        prompt += (
            "\n--- Large Source Analysis (Use This as the Priority Map) ---\n"
            f"{large_file_context}\n"
            "\n--- Large-File Generation Procedure ---\n"
            "Process the chunk manifest in order. For each chunk, read only its inclusive line range, add normal, boundary, error, dependency, and state-reset cases to the same output files, then write/read back, build, run tests, and update the checkpoint. Preserve completed chunks and resume from the first incomplete chunk.\n"
            "The backend-injected Skill snapshot contains the selected long-file workflow reference. Use that snapshot directly and do not read the source reference file again.\n"
        )
    else:
        prompt += (
            "\nNormal-sized mode is active. Process the source directly and do not load "
            "the long-file workflow reference.\n"
        )
    
    prompt += f"Source code:\n```c\n{src_preview}\n```\n"

    if header_content:
        h_preview = header_content[:4000]
        prompt += f"\nHeader file:\n```c\n{h_preview}\n```\n"
    if dependent_headers:
        prompt += f"\n{dependent_headers}\n"
    if vendor_api_ref:
        prompt += f"\n{vendor_api_ref}\n"
    if enable_mock and existing_mock_ref:
        prompt += f"\n{existing_mock_ref}\n"
    if enable_mock and mock_dependency_guidance:
        prompt += f"\n{mock_dependency_guidance}\n"
    if layer_rules:
        prompt += f"\n--- Layer Rules ---\n{layer_rules}\n"
    if style_rules:
        prompt += f"\n--- Code Style ---\n{style_rules}\n"
    if skill_prompt:
        prompt += f"\n--- Skill Instructions ---\n{skill_prompt}\n"

    # HAL layer platform-specific SDK header guidance
    if layer == "hal" and platform:
        overwrite_inc_dir = file_paths.get("overwrite_inc_dir", "")
        if overwrite_inc_dir:
            # Dynamically find SDK source path
            sdk_source = ""
            sdk_name = f"sdk-{platform.lower()}"

            # Search in project_root/libs/ first
            candidate = Path(project_root) / "libs" / sdk_name
            if candidate.exists():
                sdk_source = str(candidate)
            else:
                # Search in parent directories (for platformkit sub-repo case)
                current = Path(project_root).resolve()
                for parent in [current] + list(current.parents):
                    candidate = parent / "libs" / sdk_name
                    if candidate.exists():
                        sdk_source = str(candidate)
                        break

            prompt += (
                f"\n--- Platform SDK Headers (CRITICAL for {platform.upper()}) ---\n"
                f"The platform SDK headers MUST be placed in: {overwrite_inc_dir}\n\n"
                f"IMPORTANT: Different platforms use different SDK structures:\n"
                f"- STM32U3 uses Realtek Ameba SDK (vendorhal/component/...)\n"
                f"- STM32U5 uses ST official HAL library (stm32u5xx_hal_*.h)\n"
                f"- RTL8722FAM uses Realtek SDK\n\n"
            )

            if sdk_source and platform.lower() == "stm32u5":
                prompt += (
                    f"For {platform.upper()}, you MUST copy SDK headers from the reference SDK:\n"
                    f"SDK source location: {sdk_source}\n\n"
                    f"Required headers to copy:\n"
                    f"1. CMSIS headers from: {sdk_source}/CMSIS/Device/ST/STM32U5xx/Include/\n"
                    f"   - stm32u5xx.h (main device header)\n"
                    f"   - stm32u5*xx.h (specific device variants like stm32u585xx.h)\n"
                    f"   - system_stm32u5xx.h\n\n"
                    f"2. HAL headers from: {sdk_source}/STM32U5xx_HAL_Driver/Inc/\n"
                    f"   - stm32u5xx_hal.h\n"
                    f"   - stm32u5xx_hal_def.h\n"
                    f"   - stm32u5xx_hal_pwr.h (for PWR module)\n"
                    f"   - stm32u5xx_hal_pwr_ex.h (extended PWR functions)\n"
                    f"   - stm32u5xx_hal_cortex.h\n"
                    f"   - stm32u5xx_hal_rcc.h\n"
                    f"   - stm32u5xx_hal_rcc_ex.h\n"
                    f"   - Other module-specific headers as needed\n\n"
                    f"Copy process:\n"
                    f"1. Create directory: {overwrite_inc_dir}\n"
                    f"2. Use Bash tool to copy headers: cp {sdk_source}/CMSIS/Device/ST/STM32U5xx/Include/*.h {overwrite_inc_dir}/\n"
                    f"3. Copy HAL headers: cp {sdk_source}/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal*.h {overwrite_inc_dir}/\n"
                    f"4. Verify all required headers are present\n\n"
                    f"The QBS file already includes this directory in cpp.includePaths.\n"
                )
            else:
                prompt += (
                    f"For {platform.upper()}, you MUST:\n"
                    f"1. Create the directory: {overwrite_inc_dir}\n"
                    f"2. Place ALL platform-specific SDK headers there\n"
                    f"3. These headers override the real SDK headers during testing\n"
                    f"4. Mock files should include these headers, NOT the real vendor SDK headers\n\n"
                    f"The QBS file already includes this directory in cpp.includePaths.\n"
                )

    if layer == "app" and compile_verify and enable_mock:
        _fp = file_paths
        prompt += (
            "\n--- App Layer Output Path Contract (HIGHEST PRIORITY) ---\n"
            "The backend already resolved the canonical output locations. These "
            "paths override every generic path example in skills and references.\n"
            f"- Test implementation: {_fp.get('test_impl_path', '')}\n"
            f"- Test header: {_fp.get('test_header_path', '')}\n"
            f"- Mock implementation: {_fp.get('mock_impl_path', '')}\n"
            f"- Mock header: {_fp.get('mock_header_path', '')}\n"
            "Write and edit only these exact artifact paths. Do not create a shorter "
            "tests/unit/<module> or tests/unit/app-<module> alternative.\n"
            "When updating App test sources in QBS, compute the entry from the exact "
            "test path relative to tests/unit/.\n"
            "\n--- App Layer Internal Function Testing (CRITICAL) ---\n"
            "Source-static functions and variables have internal linkage and are not visible to a separate C++ test translation unit. Never add ordinary extern declarations for them.\n\n"
            "1. Prefer testing each behavior through the public API and callbacks exported by the production header.\n"
            "2. If direct internal coverage is essential, create a test-only C access translation unit (for example tests/mocks/src/<module>_test_access.c) that includes the source after applying a controlled linkage adapter. Register that adapter in the exact QBS target and omit the production source from that target to avoid duplicate definitions.\n"
            "3. Declare only the adapter's exported functions and state in the C++ test file, with signatures copied from the source/header.\n"
            "4. Generate test cases for all reachable internal behaviors:\n"
            "   - Callback functions (timer, interrupt, event)\n"
            "   - Helper functions (wrappers, converters, validators)\n"
            "   - Internal logic functions (state machine, statistics)\n\n"
            "5. For charging modules, MUST include:\n"
            "   - VBUS monitor callback tests (test_vbus_monitor_cable_in/out)\n"
            "   - CC detection tests (test_cc_detect_3A, test_cc_detect_1_5A)\n"
            "   - Charge start/stop tests (test_chrg_start_charing, test_chrg_stop_charging)\n"
            "   - Interrupt callback tests (test_chrg_state_update_callback, etc.)\n"
            "   - Input/output wrapper tests (test_input_max_current_wrapper, etc.)\n\n"
            "6. Coverage target: >= 90% line coverage\n"
            "   - Use the adapter strategy above for source-static coverage\n"
            "   - Test all branches by varying mock return values\n"
            "   - Do NOT report \"limitations\" or \"cannot test\" in coverage summary\n"
            "   - Report actual coverage and specific uncovered lines only\n\n"
            "\n--- App QBS Rules (CRITICAL) ---\n"
            f"- The backend-selected QBS project file is: {qbs_file or (str(Path(project_root) / 'projects/test/qbs/test_app.qbs'))}\n"
            f"- Build directory: {qbs_dir}\n"
            "- Use the backend-selected task-scoped QBS file exactly; do not switch to an aggregate target\n"
            "- Do NOT create or edit files under libs/platformkit/project/test/qbs/\n"
            "- Do NOT modify tests-platformkit.qbs\n"
            "- Do NOT read tests-platformkit.qbs or any qbs file under libs/platformkit/project/test/qbs/ for reference\n"
            "- If the selected QBS file is missing, report the precondition error; do not invent another QBS layout\n"
            "- Only generate or update files under tests/unit and tests/mocks\n"
            "\n"
            "CRITICAL - QBS File Update Required:\n"
            f"After generating test files, update the selected QBS file ({qbs_file or (str(Path(project_root) / 'projects/test/qbs/test_app.qbs'))}) only when the backend has not already populated it.\n"
            "\n"
            "**CRITICAL - PRESERVE EXISTING ENTRIES:**\n"
            "- A task-scoped QBS file contains only this task's source/test/mock files; never append unrelated module entries\n"
            "- Preserve existing entries in the selected file when they belong to this task\n"
            "- Never modify the canonical aggregate test_app.qbs from a task-scoped run\n"
            "- If a files array is empty ([]), populate it with your paths\n"
            "- If a files array has entries, ADD your paths to the end of the array\n"
            "\n"
            "Example - Correct behavior:\n"
            "  Existing: files: ['app-main/tc-app-controller-sys.cpp']\n"
            "  After:    files: ['app-main/tc-app-controller-sys.cpp',  // PRESERVED\n"
            "                    'app-main/tc-app-controller-wdg.cpp']  // ADDED\n"
            "\n"
            "The selected task-scoped file already has the required file groups. Verify the exact paths before compiling:\n"
            "\n"
            "1. Read the existing test_app.qbs file carefully\n"
            "2. For each Group block, check if files: [] is empty or contains existing entries:\n"
            "   - Group 'Application sources' (prefix: '../../../')\n"
            "   - Group 'App test sources' (prefix: '../../../tests/unit/')\n"
            "   - Group 'App mock sources' (prefix: '../../../tests/mocks/src/')\n"
            "   - Group 'App mock include' (prefix: '../../../tests/mocks/inc/')\n"
            "3. For EMPTY arrays: Add your generated file paths\n"
            "4. For NON-EMPTY arrays: **APPEND** your paths, keeping all existing entries\n"
            "5. Add the generated file paths relative to each Group's prefix:\n"
            "   - Application sources: add the source .c file path relative to project root\n"
            "   - App test sources: add test .cpp files relative to tests/unit/\n"
            "   - App mock sources: add mock .cpp files relative to tests/mocks/src/\n"
            "   - App mock include: add mock .h files relative to tests/mocks/inc/\n"
            "6. Also add the test entry point file (e.g., tests/unit/app/tc-main.cpp) to 'App test sources'\n"
            "7. NEVER remove or replace existing file paths - only ADD new ones\n"
            "\n"
            "Coverage collection rules:\n"
            "- Do not locate coverage artifacts or run gcov. After the CLI finishes, "
            "the backend collects coverage using the toolchain matching the selected QBS profile.\n"
            "\n"
            "Example: If source is apps/p1-alpha-rtos/src/app-main.c:\n"
            "  Group 'Application sources' files: ['apps/p1-alpha-rtos/src/app-main.c']\n"
            "  Group 'App test sources' files: ['app-main/tc-app-main.cpp', 'app/tc-main.cpp']\n"
            "  Group 'App mock sources' files: ['mock-logtask.cpp', 'mock-event-user.cpp', 'mock-message-broker.cpp']\n"
            "  Group 'App mock include' files: ['mock-logtask.h', 'mock-event-user.h', 'mock-message-broker.h']\n"
            "\n"
            "Without this step, the QBS build will fail with 'undefined reference to WinMain' because no source files are linked.\n"
        )
    elif layer == "common":
        _fp = file_paths
        prompt += (
            "\n--- Common Layer File Path Rules (CRITICAL) ---\n"
            "You MUST write each output file to EXACTLY the path listed in 'Output files' above.\n"
            "Do NOT invent, rename, shorten, or relocate any file. The exact required names are:\n"
            f"  test impl  : {_fp.get('test_impl_path', '')}\n"
            f"  test header: {_fp.get('test_header_path', '')}\n"
            + (f"  mock impl  : {_fp.get('mock_impl_path', '')}\n"
               f"  mock header: {_fp.get('mock_header_path', '')}\n" if enable_mock else "")
            + "- Use the canonical names from the output manifest\n"
            "- Do NOT use shortened names like tc-adc.cpp; always use the full canonical name (for example tc-common-adc.cpp)\n"
            "- The only allowed QBS file is: "
            f"{project_root}/projects/test/qbs/test_common.qbs\n"
            "- Do NOT create any module-specific .qbs file such as tests/unit/<module>/test-common-<module>.qbs\n"
            "- Do NOT create any platformkit-specific directory or qbs file\n"
            "- Only generate or update files under tests/unit/common/<module>/, tests/mocks/common/, and tests/mocks/overwrite-inc/ when overwrite headers are needed\n"
            "- If projects/test/qbs/test_common.qbs is missing, assume the backend will create it from template before compilation, and that template already includes tests/mocks/overwrite-inc in cpp.includePaths\n"
            "- Common layer uses a single aggregate qbs entry; do not switch to any other qbs layout when fixing compile failures\n"
        )
    steps_text = (
        f"\nSteps:\n"
        f"1. Analyze the source code to identify all functions and branches\n"
        f"2. Write the test .cpp file with TEST_F cases covering all functions\n"
        f"3. Write the test .h file with the test fixture class\n"
        + ("4. Write the mock .h file with MOCK_METHOD declarations\n"
           "5. Write the mock .cpp file with C wrapper functions\n" if enable_mock else
           "4. Do not generate mock files. Use the original source dependencies; report unavailable dependencies.\n")
    )

    if not compile_verify:
        steps_text += (
            "6. Do not update QBS files. Do not compile, run tests, or collect coverage; report the generated files.\n\n"
        )
    elif layer == "app" and not qbs_prepared and enable_mock:
        steps_text += (
            f"6. Update the QBS file to include all generated files (see 'QBS File Update Required' above)\n"
            f"7. Compile with: `{qbs_cmd}`\n"
            f"8. If compilation fails, fix errors and retry\n"
            f"9. Run the test executable to verify all tests pass\n\n"
        )
    else:
        steps_text += (
            f"6. Compile with: `{qbs_cmd}`\n"
            f"7. If compilation fails, fix errors and retry\n"
            f"8. Run the test executable to verify all tests pass\n\n"
        )

    prompt += steps_text
    verification_rules = (
        f"- Target {coverage_target:.1f}% line coverage\n"
        "- Do not locate coverage artifacts or run gcov; the backend collects coverage with the toolchain matching the selected QBS profile\n"
        if compile_verify
        else "- Do not modify QBS files or run build, test, or coverage commands\n"
    )
    prompt += (
        f"Important:\n"
        f"- Write files directly to the paths listed above\n"
        + ("- Ensure mock function signatures match the real HAL API exactly\n"
           "- Use StrictMock to catch unexpected calls\n" if enable_mock else "")
        +
        f"- Cover edge cases, boundary values, and error paths\n"
        f"{verification_rules}"
        f"{TEST_QUALITY_CONTRACT}\n"
    )

    if layer == "app" and not qbs_prepared and enable_mock:
        prompt += (
            f"- CRITICAL: Update test_app.qbs to populate all empty files: [] arrays before compiling\n"
        )

    prompt += (
        f"\n"
        f"Efficiency rules (CRITICAL):\n"
        f"- Use the Write tool (not Edit) to create new files in one shot\n"
        f"- Check all output paths with one shell existence check before reading any output file\n"
        f"- Missing output files are expected during first generation; create parent directories and Write them directly\n"
        f"- Do not call Read on a missing output path; this avoids one full model round trip per absent file\n"
        f"- Read each existing output at most once before Edit or Write\n"
        f"- Do NOT search/explore the project beyond the source file and its direct headers\n"
        f"- Do NOT read register definition files or vendor HAL headers unless compilation fails\n"
        f"- Maximum 24 tool calls total. If approaching the limit, write the focused change immediately and stop exploring\n"
        f"- If compilation fails, fix and retry at most 3 times\n"
        f"- Only mark the task complete after compilation passes. If still failing after 3 retries, exit with a non-zero status — do NOT output broken code as a success\n"
        f"- NEVER use 'cd dir && command' compound Bash commands. Always use absolute paths\n"
        f"- For normal-sized files, read the resolved source once. For large-file mode, use only the backend-indexed chunk ranges and do not repeatedly read the full file\n"
        f"- Do NOT use TaskOutput or Task tools — they are not available in this context\n"
    )

    prompt += build_compact_context_instruction()

    return prompt


def build_cli_coverage_improvement_prompt(
    source_file: str,
    file_paths: dict[str, str],
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
    build_profile: str = "mingw",
    coverage_target: float = 80.0,
    current_coverage: float = 0.0,
    uncovered_lines: Optional[list[int]] = None,
    uncovered_functions: Optional[list[str]] = None,
    real_source_path: Optional[str] = None,
    source_content_excerpt: str = "",
    uncovered_code_excerpts: str = "",
    previous_context_summary: str = "",
    skill_prompt: str = "",
    coverage_plan: Optional[list[dict]] = None,
    large_file_context: str = "",
    qbs_project_path: str = "",
    qbs_file: str = "",
    qbs_products: list[str] | None = None,
) -> str:
    """Build prompt for Claude CLI to improve test coverage based on gcov data."""
    from .qbs import resolve_qbs_project_path, resolve_qbs_file_path

    # Coverage repair is called repeatedly. Keep each request bounded even
    # when the source, Skill, and prior CLI transcript are large. The active
    # source path and uncovered line/function lists remain authoritative; the
    # compacted sections are supporting context only.
    skill_prompt = compact_large_file_context(skill_prompt, 8000)
    previous_context_summary = compact_large_file_context(previous_context_summary, 5000)
    large_file_context = compact_large_file_context(large_file_context, 12000)
    if coverage_plan and len(coverage_plan) > 40:
        coverage_plan = list(coverage_plan[:40])

    paths_info = "\n".join(f"  - {k}: {v}" for k, v in file_paths.items() if v)
    qbs_dir = qbs_project_path or resolve_qbs_project_path(project_root, layer, platform)
    qbs_file = qbs_file or resolve_qbs_file_path(project_root, layer, platform)
    # Use forward slashes for all paths in prompt to avoid Windows backslash escaping issues
    qbs_dir_forward = str(qbs_dir).replace('\\', '/')
    qbs_cmd = f"qbs build -d {qbs_dir_forward}"
    if qbs_file:
        qbs_file_forward = str(qbs_file).replace('\\', '/')
        qbs_cmd += f" -f {qbs_file_forward}"
    if qbs_products:
        qbs_cmd += f" -p {qbs_products[0]}"
    qbs_cmd += f" profile:{build_profile}"

    uncov_fn_text = ", ".join(uncovered_functions) if uncovered_functions else "(none)"
    uncov_ln_text = ""
    if uncovered_lines:
        # Group into ranges for readability
        ranges = []
        start = uncovered_lines[0]
        end = start
        for ln in uncovered_lines[1:]:
            if ln == end + 1:
                end = ln
            else:
                ranges.append(f"L{start}-L{end}" if start != end else f"L{start}")
                start = end = ln
        ranges.append(f"L{start}-L{end}" if start != end else f"L{start}")
        uncov_ln_text = ", ".join(ranges)
    else:
        uncov_ln_text = "(none)"

    gap = coverage_target - current_coverage
    
    # === Solution 1 & Solution 2: Add source file path and content excerpt ===
    source_context = ""
    if real_source_path:
        if large_file_context:
            source_context += (
                f"\n**CRITICAL: Resolved source path (LARGE-FILE MODE)**:\n{real_source_path}\n"
                "Use the backend-indexed chunk line range as the read boundary; do not load the complete source into the prompt.\n\n"
            )
        else:
            source_context += f"\n**CRITICAL: Source file absolute path (YOU MUST READ THIS FIRST)**:\n{real_source_path}\n\n"
    
    if source_content_excerpt:
        excerpt_label = (
            "Backend-selected source index and chunk context"
            if large_file_context
            else "Source file excerpt (first 5000 chars)"
        )
        source_context += f"**{excerpt_label}**:\n```c\n{source_content_excerpt}\n```\n\n"
    
    if uncovered_code_excerpts:
        source_context += f"**Uncovered code excerpts**:\n{uncovered_code_excerpts}\n\n"
    
    previous_context = format_previous_compact_context(previous_context_summary)

    large_file_section = ""
    coverage_read_steps = (
        "1. Use the resolved source path and the backend chunk manifest; read only the current inclusive chunk range plus minimal declarations\n"
        "2. Then read the existing generated test/mock files and exact QBS file\n"
        if large_file_context
        else "1. FIRST read EXACTLY the backend-provided source file absolute path shown above\n"
        "2. Then read the existing generated test/mock files and exact QBS file\n"
    )
    if large_file_context:
        large_file_section = (
            "\n--- Large Source Checkpoint Contract ---\n"
            f"{large_file_context}\n"
            "Process the chunk manifest in order. Read only the current inclusive line range plus minimal declarations. "
            "After each focused test change, write/read back the authoritative files, build, run tests, and update the chunk checkpoint. "
            "Resume from the first incomplete chunk and stop on a repeated deterministic failure signature or unchanged hashes; do not use a wall-clock timeout.\n"
        )

    # Keep the coverage work deterministic: gcov gaps are grouped into a small
    # per-function plan so the CLI can implement tests instead of merely
    # describing uncovered line numbers.
    plan_text = "(none)"
    if coverage_plan:
        plan_lines = []
        for item in coverage_plan:
            function = str(item.get("function") or "unknown")
            lines = item.get("uncovered_lines") or []
            branches = item.get("branch_cases") or []
            line_text = ", ".join(f"L{int(line)}" for line in lines) if lines else "(function-level gap)"
            branch_text = ", ".join(str(case) for case in branches) if branches else "normal + boundary/error paths"
            plan_lines.append(f"- {function}: lines={line_text}; required cases={branch_text}")
        plan_text = "\n".join(plan_lines)

    # Hoisted before the f-string block: f-string expressions cannot
    # contain backslashes on Python 3.11
    skill_section = (
        "--- Applied Skill Instructions ---\n" + skill_prompt + "\n"
        if skill_prompt
        else ""
    )

    return (
        f"Improve test coverage for: {source_file}\n\n"
        f"{previous_context}"
        f"Current coverage: {current_coverage:.1f}%\n"
        f"Target coverage: {coverage_target:.1f}%\n"
        f"**Coverage gap: {gap:.1f}% — YOU MUST CLOSE THIS GAP**\n\n"
        f"Uncovered functions: {uncov_fn_text}\n"
        f"Uncovered lines: {uncov_ln_text}\n\n"
        f"Structured coverage plan (follow in order):\n{plan_text}\n\n"
        f"{source_context}"
        f"{large_file_section}"
        f"Files:\n{paths_info}\n\n"
        f"Task-scoped QBS target (authoritative): project={qbs_dir}; file={qbs_file}; product={(qbs_products or [''])[0]}\n\n"
        f"SKILL-DRIVEN COVERAGE MATRIX (MANDATORY):\n"
        f"- Every uncovered function gets at least one direct behavior test.\n"
        f"- Every uncovered branch gets both the positive and negative outcome, including error codes and invalid/boundary inputs.\n"
        f"- External calls must be isolated with strict mocks; restore global/static state in TearDown.\n"
        f"- Prefer callback/timer/interrupt invocation through the public API or a test-visible access wrapper.\n"
        f"- Preserve every existing test and assertion; use globally unique test names and never create duplicate TEST/TEST_F definitions.\n"
        f"- Coverage must not regress: run the full test suite and compare line/branch/function metrics with the baseline before declaring success.\n"
        f"- Do not stop at analysis: write, compile, execute, and re-check coverage.\n"
        f"{skill_section}"
        f"MANDATORY REQUIREMENTS (NON-NEGOTIABLE):\n"
        f"- You MUST cover uncovered static behavior through the public API or a test-only access translation unit\n"
        f"- Add focused TEST_F cases for uncovered behavior (normally 1-5 per iteration); do not pad the file with redundant tests.\n"
        f"- If a path is already covered, improve fixtures or parameterize an existing test instead of adding a duplicate.\n"
        f"- You MUST NOT exit without writing meaningful coverage-oriented code changes\n"
        f"- You MUST target the uncovered functions and lines listed above\n"
        f"- For source-static functions, never add ordinary extern declarations in a separate test translation unit:\n"
        f"  * Prefer a public API path that invokes the internal behavior.\n"
        f"  * If that is impossible, add a test-only C access translation unit that includes the source with controlled linkage, export only adapter symbols, and register the adapter in QBS instead of the production source.\n"
        f"  * Declare and call only those adapter symbols from the C++ tests.\n"
        f"  * Test all branches with different mock configurations\n"
        f"  * Example:\n"
        f"    ```cpp\n"
        f"    TEST_F(Test, test_static_function) {{\n"
        f"        EXPECT_CALL(mock, dependency()).WillOnce(Return(OK));\n"
        f"        static_function();\n"
        f"        EXPECT_EQ(get_state(), EXPECTED);\n"
        f"    }}\n"
        f"    ```\n"
        f"- Even if some code seems hard to test, you MUST try creative approaches:\n"
        f"  * Test callback functions through their public registration path or an access adapter\n"
        f"  * Test state machines: drive through ALL state transitions systematically\n"
        f"    - Test each state's processing logic with different commands\n"
        f"    - Test transitions from every state to every possible next state\n"
        f"    - Include rare/error transition paths (not just the happy path)\n"
        f"    - Use different input command types to trigger different state changes\n"
        f"  * Test error paths by forcing error conditions with mocks\n"
        f"  * Test edge cases and boundary conditions\n"
        f"  * For hardware/mock dependencies:\n"
        f"    - Configure mocks to return ALL possible combinations of input values\n"
        f"    - Don't only test the happy path (success case)\n"
        f"    - Test edge values, out-of-range values, error return codes\n"
        f"    - For ADC/voltage/current readings: test boundary values that trigger different branches\n"
        f"\n"
        f"SPECIAL STRATEGIES FOR COMMON PATTERNS:\n"
        f"1. **Charging/Power Management Modules** (bank-charge, battery, power):\n"
        f"   - Test complete charging flow: idle → detecting → precharging → charging → charged\n"
        f"   - Test charge source detection: USB types (SDP/CDP/DCP), current limits (0.5A/1.5A/3A)\n"
        f"   - Test VBUS monitoring: cable plug/unplug events, debounce logic\n"
        f"   - Test CC pin detection: ADC voltage readings for Type-C current capability\n"
        f"   - Test timeout scenarios: charge timeout, detection timeout, low-current timeout\n"
        f"   - Test temperature zones: cold/cool/normal/warm/hot recharge logic\n"
        f"   - Test timer callbacks: start timers and manually trigger callbacks\n"
        f"   - Test interrupt callbacks: simulate hardware interrupts by calling callbacks directly\n"
        f"\n"
        f"2. **Timer-Based Modules** (with FreeRTOS timers or periodic callbacks):\n"
        f"   - Call timer start functions (e.g., xxx_monitor_start())\n"
        f"   - Manually invoke timer callbacks to simulate timer expiration\n"
        f"   - Test different timer intervals and repetition counts\n"
        f"   - Test timer stop/restart scenarios\n"
        f"\n"
        f"3. **Event-Driven Modules** (with callbacks or interrupt handlers):\n"
        f"   - Invoke static callback behavior through public registration or an access adapter\n"
        f"   - Test all possible event types and combinations\n"
        f"   - Test callback registration and deregistration\n"
        f"   - Test callback execution order and reentrancy\n"
        f"\n"
        f"4. **ADC/Sensor Modules** (voltage, current, temperature readings):\n"
        f"   - Mock ADC readings at critical thresholds\n"
        f"   - Test boundary values that trigger state changes\n"
        f"   - Test filtering/averaging logic with noisy data\n"
        f"   - Test calibration and conversion formulas\n"
        f"\n"
        f"5. **Communication Protocol Modules** (I2C, SPI, UART):\n"
        f"   - Test complete transaction sequences\n"
        f"   - Test error recovery: NAK, timeout, CRC errors\n"
        f"   - Test buffer overflow/underflow conditions\n"
        f"   - Test multi-byte read/write operations\n"
        f"\n"
        f"- Do NOT just analyze and report — you must WRITE CODE\n"
        f"- Do NOT give up easily — try multiple approaches if needed\n"
        f"- If you cannot reach the target in one iteration, get as close as possible\n\n"
        f"Steps:\n"
        f"{coverage_read_steps}"
        f"3. Identify ALL uncovered code paths, especially:\n"
        f"   - Callback functions (0% coverage)\n"
        f"   - State transition logic\n"
        f"   - Error handling branches\n"
        f"   - Boundary conditions\n"
        f"   - Timer callbacks and periodic functions\n"
        f"   - Interrupt handlers\n"
        f"   - Detection/monitoring flows\n"
        f"4. Add focused TEST_F cases targeting the uncovered areas (normally 1-5 per iteration). Examples:\n"
        f"   \n"
        f"   // Example 1: Test charge source detection flow\n"
        f"   TEST_F(ModuleTest, ChargeSourceDetection) {{\n"
        f"       // Setup: Mock VBUS present\n"
        f"       EXPECT_CALL(mock_gpio, read_vbus()).WillOnce(Return(HIGH));\n"
        f"       // Trigger detection\n"
        f"       module_cmd_handler(CMD_DETECT_SOURCE);\n"
        f"       // Mock ADC for CC pin voltage\n"
        f"       EXPECT_CALL(mock_adc, read_cc1()).WillOnce(Return(VOLTAGE_1_5A));\n"
        f"       // Verify source type detected\n"
        f"       EXPECT_EQ(get_source_type(), SOURCE_USB_1_5A);\n"
        f"   }}\n"
        f"   \n"
        f"   // Example 2: Test complete state machine flow\n"
        f"   TEST_F(ModuleTest, FullChargingCycle) {{\n"
        f"       // State 1: idle → detecting\n"
        f"       module_cmd_handler(CMD_START_DETECT);\n"
        f"       EXPECT_EQ(get_state(), STATE_DETECTING);\n"
        f"       // State 2: detecting → charging\n"
        f"       module_cmd_handler(CMD_START_CHARGE);\n"
        f"       EXPECT_EQ(get_state(), STATE_CHARGING);\n"
        f"       // State 3: charging → charged (simulate full)\n"
        f"       EXPECT_CALL(mock_battery, get_voltage()).WillOnce(Return(4200));\n"
        f"       module_update();  // Trigger state check\n"
        f"       EXPECT_EQ(get_state(), STATE_CHARGED);\n"
        f"   }}\n"
        f"   \n"
        f"   // Example 3: Test timer callback\n"
        f"   TEST_F(ModuleTest, VbusMonitorCallback) {{\n"
        f"       // Start monitoring\n"
        f"       module_start_vbus_monitor();\n"
        f"       // Manually trigger timer callback\n"
        f"       extern void vbus_monitor_callback(void *arg);\n"
        f"       vbus_monitor_callback(NULL);\n"
        f"       // Verify monitoring logic executed\n"
        f"       EXPECT_TRUE(monitor_was_called);\n"
        f"   }}\n"
        f"   \n"
        f"   // Example 4: Test timeout scenario\n"
        f"   TEST_F(ModuleTest, ChargeTimeout) {{\n"
        f"       start_charging();\n"
        f"       // Simulate time passing beyond timeout\n"
        f"       advance_time_ms(CHARGE_TIMEOUT_MS + 1000);\n"
        f"       module_update();\n"
        f"       // Verify timeout handling\n"
        f"       EXPECT_EQ(get_state(), STATE_TIMEOUT_ERROR);\n"
        f"   }}\n"
        f"   \n"
        f"   // Example 5: Test boundary condition\n"
        f"   TEST_F(ModuleTest, TemperatureRecharge) {{\n"
        f"       // Setup: charging in cold zone\n"
        f"       EXPECT_CALL(mock_temp, get_temperature()).WillOnce(Return(TEMP_COLD));\n"
        f"       module_cmd_handler(CMD_START_CHARGE);\n"
        f"       // Verify cold zone charging parameters\n"
        f"       EXPECT_EQ(get_charge_current(), COLD_ZONE_CURRENT);\n"
        f"   }}\n"
        f"   \n"
        f"5. For callback functions, create tests that:\n"
        f"   - Use public callbacks or adapter-exported symbols; do not import source-static symbols with ordinary extern\n"
        f"   - Verify the callback's side effects (state changes, mock calls)\n"
        f"   - Test all branches within the callback\n"
        f"   - Test with different input parameters and mock return values\n"
        f"6. Add any new mock expectations needed\n"
        f"7. Do NOT remove or weaken existing tests\n"
        f"8. **CRITICAL - Avoid Duplicate Definitions**:\n"
        f"   - Do NOT redefine enums, structs, or typedefs already in the source header\n"
        f"   - Do NOT redefine mock objects (hal_*, controller_*, driver_*) already in other mock files\n"
        f"   - Read the source header file first to check what types are already defined\n"
        f"   - If you need a type, include the header that defines it instead of redefining\n"
        f"   - Example of WRONG approach:\n"
        f"     ```cpp\n"
        f"     // tc-app-driver-lp5813.cpp - WRONG!\n"
        f"     typedef enum {{  // Already defined in driver-lp5813.h\n"
        f"         APU_NO_PAUSE_TIME = 0x00,\n"
        f"         APU_0_P_09_S = 0x01,\n"
        f"     }} APU_TIME_SET;\n"
        f"     ```\n"
        f"   - Example of CORRECT approach:\n"
        f"     ```cpp\n"
        f"     // tc-app-driver-lp5813.cpp - CORRECT!\n"
        f"     // APU_TIME_SET is already defined in driver-lp5813.h (included via test header)\n"
        f"     // Just use it directly, no need to redefine\n"
        f"     ```\n"
        f"9. Compile with: `{qbs_cmd}`\n"
        f"10. If compilation fails, fix and retry\n"
        f"11. Run the test executable to verify all tests pass\n"
        f"12. Verify coverage improved significantly (aim for at least +10%)\n\n"
        f"Efficiency rules (CRITICAL):\n"
        f"- You MUST read the backend-provided absolute source path first before any edit\n"
        f"- Read only the resolved source file under test, existing generated test/mock files, and the exact QBS file selected by the backend\n"
        f"- NEVER use find/search/glob to discover alternate source paths\n"
        f"- NEVER guess alternate files, infer new paths, or explore sibling directories\n"
        f"- If a Read fails, do not guess alternate files or archives; use only the known backend-provided paths\n"
        f"- Never use Read with pages unless the file is an actual PDF\n"
        f"- Never send pages=\"\" or any empty page argument\n"
        f"- Do NOT read archives or binary artifacts such as .rar, .zip, .7z, .tar, .gcda, .gcno, .exe, .dll, .so, .a, .o, .obj\n"
        f"- Check all listed output paths in one shell existence command\n"
        f"- Create missing output files directly; do not call Read on a missing path\n"
        f"- Read each existing output at most once before Edit or Write\n"
        f"- NEVER use 'cd dir && command' compound Bash commands. Always use absolute paths\n"
        f"- For normal-sized files, read the resolved source once. For large-file mode, read only backend-indexed chunk ranges and do not repeatedly load the full source\n"
        f"- Maximum 40 tool calls total. If approaching the limit, write remaining files immediately\n"
        f"- If compilation fails, fix and retry at most 3 times\n"
        f"- Only mark the task complete after compilation passes. If still failing after 3 retries, exit with a non-zero status — do NOT output broken code as a success\n"
        f"{build_compact_context_instruction()}"
    )


def build_force_modify_coverage_prompt(
    source_file: str,
    file_paths: dict[str, str],
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
    build_profile: str = "mingw",
    coverage_target: float = 80.0,
    current_coverage: float = 0.0,
    uncovered_lines: Optional[list[int]] = None,
    uncovered_functions: Optional[list[str]] = None,
    real_source_path: Optional[str] = None,
    source_content_excerpt: str = "",
    uncovered_code_excerpts: str = "",
    previous_context_summary: str = "",
    skill_prompt: str = "",
    coverage_plan: Optional[list[dict]] = None,
    large_file_context: str = "",
    qbs_project_path: str = "",
    qbs_file: str = "",
    qbs_products: list[str] | None = None,
) -> str:
    """Build a more aggressive prompt that forces code modification when previous attempt made no changes."""
    
    # Reuse base prompt
    base_prompt = build_cli_coverage_improvement_prompt(
        source_file=source_file,
        file_paths=file_paths,
        project_root=project_root,
        layer=layer,
        platform=platform,
        build_profile=build_profile,
        coverage_target=coverage_target,
        current_coverage=current_coverage,
        uncovered_lines=uncovered_lines,
        uncovered_functions=uncovered_functions,
        real_source_path=real_source_path,
        source_content_excerpt=source_content_excerpt,
        uncovered_code_excerpts=uncovered_code_excerpts,
        previous_context_summary=previous_context_summary,
        skill_prompt=skill_prompt,
        coverage_plan=coverage_plan,
        large_file_context=large_file_context,
        qbs_project_path=qbs_project_path,
        qbs_file=qbs_file,
        qbs_products=qbs_products,
    )
    
    # Add more aggressive force modification requirements
    force_section = (
        "\n\n"
        "=== CRITICAL RETRY INSTRUCTIONS - PREVIOUS ATTEMPT FAILED ===\n"
        "Your previous attempt FAILED because you did NOT modify any files.\n"
        "This retry has STRICTER requirements:\n\n"
        "MANDATORY ACTIONS (NO EXCEPTIONS):\n"
        "1. You MUST modify at least ONE of these files:\n"
        f"   - {file_paths.get('test_impl_path', '')}\n"
        f"   - {file_paths.get('test_header_path', '')}\n"
        f"   - {file_paths.get('mock_impl_path', '')}\n"
        f"   - {file_paths.get('mock_header_path', '')}\n\n"
        "2. You MUST use Edit or Write tool to make actual code changes\n"
        "3. You MUST NOT only analyze, explain, or request corrections\n"
        "4. If you think the current test file has problems, you MUST FIX those problems directly\n"
        "5. If the fixture is wrong, MODIFY the fixture\n"
        "6. If mock expectations are insufficient, MODIFY the mock expectations\n"
        "7. If test design is flawed, REWRITE the test design in the file\n"
        "8. You MUST add or modify focused coverage-oriented test cases (normally 1-5)\n"
        "9. Preserve baseline coverage and all existing tests; do not introduce duplicate test names.\n"
        "10. Do NOT stop to explain what needs fixing - JUST FIX IT\n"
        "11. A response without file modifications will be treated as FAILURE\n\n"
        "FORBIDDEN RESPONSES:\n"
        "- Do NOT say 'I need one critical correction before...'\n"
        "- Do NOT say 'the current test file needs to be fixed first'\n"
        "- Do NOT only provide analysis or recommendations\n"
        "- Do NOT ask for permission to modify files\n"
        "- Do NOT stop after identifying problems\n\n"
        "REMEMBER: Your goal is to INCREASE coverage from "
        f"{current_coverage:.1f}% toward {coverage_target:.1f}%, not to explain why it's hard.\n"
        "You MUST leave this retry with actual code changes saved to disk.\n"
    )
    
    return base_prompt + force_section


# ========== CLI Team (Multi-Agent Parallel) Prompts ==========


def build_cli_team_generation_prompt(
    source_files: dict[str, str],
    file_paths_map: dict[str, dict[str, str]],
    project_root: str,
    layer: str = "hal",
    platform: str = "stm32u3",
    build_profile: str = "mingw",
    coverage_target: float = 80.0,
    context_map: dict[str, dict] | None = None,
    skill_prompt: str = "",
    enable_mock: bool = True,
) -> str:
    """Build the CLI Team mode prompt, instructing the CLI to use the Agent tool to process multiple source files in parallel.

    Args:
        source_files: {file_path: source_content}
        file_paths_map: {file_path: {test_file, test_header, mock_file, ...}}
        project_root: Project root directory
        layer: Architecture layer
        platform: Platform
        build_profile: Build profile
        coverage_target: Target coverage
        context_map: {file_path: {header, deps, vendor, mock, guidance}}
        skill_prompt: Skill instructions
    """
    from .qbs import resolve_qbs_project_path, resolve_qbs_file_path

    context_map = context_map or {}
    layer_rules = get_layer_rules(layer)
    style_rules = get_code_style_rules()

    qbs_dir = resolve_qbs_project_path(project_root, layer, platform)
    qbs_file = resolve_qbs_file_path(project_root, layer, platform)
    # Use forward slashes for all paths in prompt to avoid Windows backslash escaping issues
    qbs_dir_forward = str(qbs_dir).replace('\\', '/')
    qbs_cmd = f"qbs build -d {qbs_dir_forward}"
    if qbs_file:
        qbs_file_forward = str(qbs_file).replace('\\', '/')
        qbs_cmd += f" -f {qbs_file_forward}"
    qbs_cmd += f" profile:{build_profile}"

    # Build the task description for each file
    file_tasks: list[str] = []
    for i, (file_path, content) in enumerate(source_files.items(), 1):
        fp = filter_mock_paths(file_paths_map.get(file_path, {}), enable_mock)
        paths_info = "\n".join(f"    - {k}: {v}" for k, v in fp.items() if v)
        ctx = context_map.get(file_path, {})

        source_filename = str(ctx.get("source_filename") or file_path.replace("\\", "/").split("/")[-1])
        source_real_path = str(ctx.get("source_real_path") or "").replace("\\", "/")
        task_desc = f"### Task {i}: {source_filename}\n"
        task_desc += f"  Source identifier: {file_path}\n"
        if source_real_path:
            task_desc += f"  Source absolute path (read this file first): {source_real_path}\n"
        if ctx.get("source_original_chars"):
            task_desc += (
                f"  Source size: {ctx['source_original_chars']} chars; "
                f"backend excerpt: {ctx.get('source_prompt_chars', len(content))} chars\n"
            )
        task_desc += f"  Output files:\n{paths_info}\n"

        src_preview = content[:6000]
        if len(content) > 6000:
            src_preview += "\n... (truncated)"
        task_desc += f"  Source code ({len(content)} chars):\n```c\n{src_preview}\n```\n"

        if ctx.get("large_file_context"):
            task_desc += (
                "  Large Source Analysis (priority map):\n"
                f"{compact_large_file_context(ctx['large_file_context'])}\n"
                "  Use the backend-injected long-file workflow snapshot; do not read the source reference file again.\n"
            )

        if ctx.get("header"):
            task_desc += f"  Header:\n```c\n{ctx['header'][:3000]}\n```\n"
        if ctx.get("deps"):
            task_desc += f"  {ctx['deps'][:2000]}\n"
        if ctx.get("vendor"):
            task_desc += f"  {ctx['vendor'][:2000]}\n"
        if ctx.get("mock"):
            task_desc += f"  {ctx['mock'][:2000]}\n"
        if ctx.get("guidance"):
            task_desc += f"  {ctx['guidance'][:1000]}\n"

        file_tasks.append(task_desc)

    n = len(source_files)
    prompt = (
        f"You have {n} source files to generate unit tests for.\n"
        f"Use the Agent tool to spawn {n} background agents IN PARALLEL "
        f"(all in a single message with multiple tool calls).\n\n"
        f"Each agent should independently:\n"
        + ("1. Write the 4 test/mock files (test .cpp, test .h, mock .h, mock .cpp)\n" if enable_mock
           else "1. Write only the test .cpp and .h files. Mock generation is disabled; do not create, edit, or register mock files.\n")
        +
        f"2. Compile with: `{qbs_cmd}`\n"
        f"3. Fix compile errors (max 3 retries)\n"
        f"4. Run the test executable\n\n"
        f"Project root: {project_root}\n"
        f"Layer: {layer} | Platform: {platform} | Framework: GTest + GMock\n"
        f"Target coverage: {coverage_target:.1f}%\n\n"
    )

    if layer_rules:
        prompt += f"--- Layer Rules ---\n{layer_rules}\n\n"
    if style_rules:
        prompt += f"--- Code Style ---\n{style_rules}\n\n"
    if skill_prompt:
        prompt += f"--- Skill Instructions ---\n{skill_prompt}\n\n"

    prompt += "--- File Tasks ---\n\n"
    prompt += "\n".join(file_tasks)

    prompt += (
        f"\n\n--- Agent Spawn Instructions ---\n"
        f"For EACH task above, call the Agent tool with:\n"
        f"- description: \"test <filename>\"\n"
        f"- prompt: the task details (source code, output paths, context)\n"
        f"- run_in_background: true\n"
        f"- mode: \"bypassPermissions\"\n\n"
        f"Spawn ALL {n} agents in a SINGLE message (parallel tool calls).\n"
        f"Then wait for all agents to complete using TaskOutput.\n"
        f"Finally, report which files were successfully generated.\n\n"
        f"{_build_cli_read_safety_rules(large_file_mode=any(bool(item.get('large_file_context')) for item in context_map.values()))}"
        f"Efficiency rules:\n"
        f"- Each agent should use Write tool to create files in one shot\n"
        f"- Check all assigned output paths in one shell existence command\n"
        f"- For missing output files: create parent directories and use Write directly\n"
        f"- For existing output files: read each file at most once before Edit or Write\n"
        f"- Each agent max 35 tool calls\n"
        f"- If compilation fails after 3 retries, save whatever was generated\n"
        f"- If you encounter \"Build graph does not yet exist\" or any other build graph error, just clean the build directory and rebuild - this is not a code error\n"
    )

    return prompt


def build_cli_team_system_prompt(
    project_root: str,
    layer: str = "hal",
    coverage_target: float = 80.0,
    n_files: int = 1,
    large_file_mode: bool = False,
) -> str:
    """System prompt for Team mode."""
    skill_guidance = (
        "Large-file mode is active; the task prompt includes the selected long-file workflow and layer skill contract.\n"
        if large_file_mode
        else "Normal-sized mode is active; the task prompt includes the selected generic and layer Skill snapshot.\n"
    )

    return (
        "You are a test generation coordinator for embedded firmware.\n"
        f"Project root: {project_root}\n"
        f"Layer: {layer}\n"
        f"Target coverage: {coverage_target:.1f}%\n"
        f"{skill_guidance}"
        "Use the injected Skill snapshot directly and do not read the source Skill files again.\n"
        f"You have {n_files} source files to process.\n"
        "Use the Agent tool to spawn background agents for parallel execution.\n"
        "Each agent writes test files, compiles, and fixes errors independently.\n"
        "You have full file system access. Use bypassPermissions mode.\n\n"
        "File writing rules:\n"
        "- Check all assigned output paths in one shell existence command\n"
        "- For missing output files: create parent directories and use Write directly\n"
        "- For existing output files: read each file at most once before Edit or Write\n"
        f"{_build_cli_read_safety_rules(large_file_mode=large_file_mode)}"
    )
