"""Semantic validation for generated GoogleTest implementations."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.core.c_source import mask_c_non_code

from .parsers import parse_functions_regex


_TEST_MACRO_PATTERN = re.compile(r"\bTEST(?:_F|_P)?\s*\(")
_VERIFICATION_PATTERN = re.compile(
    r"\b(?:EXPECT|ASSERT)_[A-Z0-9_]+\s*\(|"
    r"\b(?:ON_CALL|EXPECT_CALL|ADD_FAILURE|FAIL|SUCCEED)\s*\("
)
_TRIVIAL_VERIFICATION_PATTERNS = (
    re.compile(r"\bEXPECT_TRUE\s*\(\s*true\s*\)", re.IGNORECASE),
    re.compile(r"\bASSERT_TRUE\s*\(\s*true\s*\)", re.IGNORECASE),
    re.compile(r"\bSUCCEED\s*\(\s*\)", re.IGNORECASE),
)
_EXTERN_C_BLOCK_PATTERN = re.compile(
    r"extern\s+\"C\"\s*\{.*?\}",
    re.DOTALL,
)
_INITIALIZER_START_PATTERN = re.compile(
    r"\b(?P<object>[A-Za-z_]\w*)\s*(?:\[[^\]]*\]\s*)?=\s*\{"
)
_DESIGNATED_FUNCTION_PATTERN = re.compile(
    r"\.\s*(?P<field>[A-Za-z_]\w*)\s*=\s*&?\s*"
    r"(?P<function>[A-Za-z_]\w*)\b"
)
_NESTED_INITIALIZER_START_PATTERN = re.compile(
    r"\.\s*(?P<field>[A-Za-z_]\w*)\s*=\s*\{"
)
_POSITIONAL_FUNCTION_PATTERN = re.compile(r"^&?(?P<function>[A-Za-z_]\w*)$")
_RUNTIME_FUNCTION_ASSIGNMENT_PATTERN = re.compile(
    r"\b(?P<object>[A-Za-z_]\w*)\s*(?:\.|->)\s*"
    r"(?P<field>[A-Za-z_]\w*)\s*=\s*&?\s*"
    r"(?P<function>[A-Za-z_]\w*)\b"
)
_INTERFACE_OBJECT_CALL_PATTERN = re.compile(
    r"\b(?P<object>[A-Za-z_]\w*)\s*(?:\[[^\]]+\]\s*)?"
    r"(?:\.|->)\s*"
    r"(?P<field>[A-Za-z_]\w*(?:\s*(?:\.|->)\s*[A-Za-z_]\w*)?)\s*\("
)


@dataclass(frozen=True)
class GeneratedTestValidation:
    """Result of checking whether generated test code is meaningful."""

    valid: bool
    errors: list[str] = field(default_factory=list)
    source_functions: list[str] = field(default_factory=list)
    referenced_functions: list[str] = field(default_factory=list)


def _strip_comments(content: str) -> str:
    return mask_c_non_code(content, keep_literals=True)


def _extract_source_functions(source_content: str) -> list[str]:
    without_comments = _strip_comments(source_content or "")
    return sorted(
        {
            str(function.get("name", "")).strip()
            for function in parse_functions_regex(without_comments)
            if str(function.get("name", "")).strip()
        }
    )


def _find_matching_brace(content: str, opening_index: int) -> int | None:
    depth = 0
    for index in range(opening_index, len(content)):
        character = content[index]
        if character == "{":
            depth += 1
        elif character == "}":
            depth -= 1
            if depth == 0:
                return index
    return None


def _split_top_level_initializer_items(initializer_body: str) -> list[str]:
    """Split initializer body on commas that are not inside nested braces."""
    items: list[str] = []
    item_start = 0
    depth = 0
    for index, character in enumerate(initializer_body):
        if character in "({[":
            depth += 1
        elif character in ")}]" and depth > 0:
            depth -= 1
        elif character == "," and depth == 0:
            items.append(initializer_body[item_start:index].strip())
            item_start = index + 1
    tail = initializer_body[item_start:].strip()
    if tail:
        items.append(tail)
    return items


def _normalize_field_path(field_path: str) -> str:
    return re.sub(r"\s*(?:\.|->)\s*", ".", field_path.strip())


def _extract_interface_bindings(
    source_content: str,
    source_functions: list[str],
) -> list[tuple[str, str, str]]:
    """Return ``(object, field, function)`` initializer interface bindings.

    ``field`` is empty when a legacy positional table, such as
    ``api = { initialize_impl, deinitialize_impl }``, exposes source functions
    through the object but the field names are only available in headers.
    """
    without_comments = _strip_comments(source_content or "")
    source_function_set = set(source_functions)
    bindings: set[tuple[str, str, str]] = set()

    for initializer in _INITIALIZER_START_PATTERN.finditer(without_comments):
        opening_index = initializer.end() - 1
        closing_index = _find_matching_brace(without_comments, opening_index)
        if closing_index is None:
            continue

        initializer_body = without_comments[opening_index + 1 : closing_index]
        for nested in _NESTED_INITIALIZER_START_PATTERN.finditer(initializer_body):
            nested_opening_index = nested.end() - 1
            nested_closing_index = _find_matching_brace(
                initializer_body,
                nested_opening_index,
            )
            if nested_closing_index is None:
                continue

            nested_body = initializer_body[
                nested_opening_index + 1 : nested_closing_index
            ]
            for assignment in _DESIGNATED_FUNCTION_PATTERN.finditer(nested_body):
                function_name = assignment.group("function")
                if function_name not in source_function_set:
                    continue
                bindings.add(
                    (
                        initializer.group("object"),
                        f"{nested.group('field')}.{assignment.group('field')}",
                        function_name,
                    )
                )
        for assignment in _DESIGNATED_FUNCTION_PATTERN.finditer(initializer_body):
            function_name = assignment.group("function")
            if function_name not in source_function_set:
                continue
            bindings.add(
                (
                    initializer.group("object"),
                    assignment.group("field"),
                    function_name,
                )
            )
        for item in _split_top_level_initializer_items(initializer_body):
            if "=" in item:
                continue
            positional_function = _POSITIONAL_FUNCTION_PATTERN.match(item)
            if not positional_function:
                continue
            function_name = positional_function.group("function")
            if function_name not in source_function_set:
                continue
            bindings.add((initializer.group("object"), "", function_name))
    for assignment in _RUNTIME_FUNCTION_ASSIGNMENT_PATTERN.finditer(without_comments):
        function_name = assignment.group("function")
        if function_name not in source_function_set:
            continue
        bindings.add(
            (
                assignment.group("object"),
                assignment.group("field"),
                function_name,
            )
        )

    return sorted(bindings)


def _find_referenced_functions(
    test_content: str,
    source_functions: list[str],
    interface_bindings: list[tuple[str, str, str]],
) -> list[str]:
    without_comments = _strip_comments(test_content)
    without_declarations = _EXTERN_C_BLOCK_PATTERN.sub("", without_comments)
    without_declarations = re.sub(
        r"(?m)^\s*extern\b[^;]*;\s*$",
        "",
        without_declarations,
    )
    without_declarations = mask_c_non_code(without_declarations)
    referenced_functions = {
        function_name
        for function_name in source_functions
        if re.search(
            rf"\b{re.escape(function_name)}\s*\(",
            without_declarations,
        )
    }
    interface_calls = [
        (call.group("object"), _normalize_field_path(call.group("field")))
        for call in _INTERFACE_OBJECT_CALL_PATTERN.finditer(without_declarations)
    ]
    for object_name, field_name, function_name in interface_bindings:
        if field_name:
            if (object_name, field_name) in interface_calls:
                referenced_functions.add(function_name)
            continue
        if any(call_object == object_name for call_object, _ in interface_calls):
            referenced_functions.add(function_name)

    return sorted(referenced_functions)


def _has_meaningful_verification(test_content: str) -> bool:
    test_content = mask_c_non_code(test_content)
    verification_matches = list(_VERIFICATION_PATTERN.finditer(test_content))
    if not verification_matches:
        return False

    without_trivial = test_content
    for pattern in _TRIVIAL_VERIFICATION_PATTERNS:
        without_trivial = pattern.sub("", without_trivial)
    return _VERIFICATION_PATTERN.search(without_trivial) is not None


def validate_generated_test(
    test_content: str,
    source_content: str,
    *,
    minimum_size: int = 80,
) -> GeneratedTestValidation:
    """Reject empty, placeholder, or source-disconnected test code."""
    content = test_content or ""
    errors: list[str] = []
    source_functions = _extract_source_functions(source_content)
    interface_bindings = _extract_interface_bindings(
        source_content,
        source_functions,
    )
    referenced_functions = _find_referenced_functions(
        content,
        source_functions,
        interface_bindings,
    )

    if len(content.strip()) < minimum_size:
        errors.append(
            f"test implementation is too small ({len(content.strip())} characters)"
        )
    if not _TEST_MACRO_PATTERN.search(mask_c_non_code(content)):
        errors.append("test implementation contains no TEST, TEST_F, or TEST_P case")
    if not _has_meaningful_verification(content):
        errors.append("test implementation contains no meaningful verification")
    if source_functions and not referenced_functions:
        errors.append("test implementation does not call a target source function")

    return GeneratedTestValidation(
        valid=not errors,
        errors=errors,
        source_functions=source_functions,
        referenced_functions=referenced_functions,
    )
