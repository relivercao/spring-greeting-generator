import qbs

StaticLibrary {
    name: "gmock"

    Depends { name: "cpp" }

    property stringList includePaths: [
        sourceDirectory + "/googlemock/include",
        sourceDirectory + "/googletest/include",
    ]

    cpp.cxxLanguageVersion: "c++17"
    cpp.defines: ["GTEST_HAS_PTHREAD=0"]
    cpp.includePaths: includePaths.concat([
        sourceDirectory + "/googlemock",
        sourceDirectory + "/googletest",
    ])

    files: [
        "googlemock/src/gmock-all.cc",
        "googlemock/src/gmock_main.cc",
        "googletest/src/gtest-all.cc",
    ]

    Export {
        Depends { name: "cpp" }
        cpp.defines: ["GTEST_HAS_PTHREAD=0"]
        cpp.includePaths: exportingProduct.includePaths
    }
}
