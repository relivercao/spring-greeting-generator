"""Trusted read-only capabilities for unit-test skill collaboration."""

import asyncio
import hashlib
from dataclasses import asdict, is_dataclass
from pathlib import Path

from app.skills.runtime import SkillStageContext
from .parsers import parse_qbs_build_errors


async def artifact_manifest(context: SkillStageContext) -> dict:
    """Inspect only explicit task-owned artifacts, never paths supplied by a skill."""
    def inspect():
        artifacts = []
        for role, value in context.inputs.get("file_paths", {}).items():
            if not value or role not in {
                "source_path", "test_impl_path", "test_header_path",
                "mock_impl_path", "mock_header_path", "qbs_file",
            }:
                continue
            path = Path(value)
            if not path.is_absolute():
                artifacts.append({"role": role, "path": str(path), "state": "unresolved"})
                continue
            item = {"role": role, "path": str(path), "state": "missing"}
            if path.is_file():
                with path.open("rb") as handle:
                    digest = hashlib.file_digest(handle, "sha256").hexdigest()
                item.update(state="present", bytes=path.stat().st_size, sha256=digest)
            artifacts.append(item)
        return {"artifacts": artifacts, "validation": "snapshot_only"}

    return await asyncio.to_thread(inspect)


async def compiler_diagnostics(context: SkillStageContext) -> dict:
    raw_errors = context.inputs.get("compile_errors") or []
    diagnostics = []
    for error in raw_errors:
        item = asdict(error) if is_dataclass(error) else error
        diagnostics.append(item if isinstance(item, dict) else {"message": str(item)})
    if not diagnostics:
        diagnostics = [{"message": message} for message in parse_qbs_build_errors(
            context.inputs.get("build_output") or ""
        )]
    # Keep the causal diagnostic first; the full build log stays in the task.
    first = diagnostics[0] if diagnostics else None
    return {"first_diagnostic": first, "diagnostics": diagnostics[:20], "total": len(diagnostics)}


async def coverage_gaps(context: SkillStageContext) -> dict:
    data = context.inputs.get("coverage_data") or {}
    return {
        "line_coverage": data.get("line_coverage"),
        "branch_coverage": data.get("branch_coverage"),
        "function_coverage": data.get("function_coverage"),
        "uncovered_functions": list(data.get("uncovered_functions") or []),
        "uncovered_line_count": len(data.get("uncovered_lines") or []),
        "target": context.inputs.get("target_coverage"),
        "active_chunk_id": context.inputs.get("active_chunk_id") or None,
        "validation": "agent_supplied_measurement_not_independently_verified",
    }


UNITTEST_CAPABILITIES = {
    "artifact_manifest": artifact_manifest,
    "compiler_diagnostics": compiler_diagnostics,
    "coverage_gaps": coverage_gaps,
}


async def prepare_unittest_skills(
    agent, ctx, stage: str, *, file_paths: dict | None = None,
    source_path: str = "", large_file_mode: bool = False,
    compile_errors=None, build_output: str = "", coverage_data=None,
) -> str:
    paths = dict(file_paths or {})
    if source_path:
        paths["source_path"] = source_path
    if ctx.qbs_file:
        paths["qbs_file"] = ctx.qbs_file
    prepared = await agent._prepare_stage_skills(
        ctx, stage, layer=ctx.layer, large_file_mode=large_file_mode,
        scope=paths.get("source_path") or paths.get("test_impl_path") or "task",
        inputs={
            "file_paths": paths, "compile_errors": compile_errors or [],
            "build_output": build_output, "coverage_data": coverage_data or {},
            "target_coverage": ctx.target_coverage,
            "active_chunk_id": ctx.large_file_active_chunk_id,
        },
        capabilities=UNITTEST_CAPABILITIES,
    )
    return prepared.prompt


def applied_skill_names(ctx, stage: str) -> list[str]:
    return list(dict.fromkeys(
        skill["name"] for trace in ctx.metadata.get("skill_runtime", [])
        if trace["stage"] == stage and trace.get("status") == "prepared"
        for skill in trace.get("skills", [])
    ))
