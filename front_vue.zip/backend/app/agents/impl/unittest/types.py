"""
@file types.py
@author caoshwen
@brief UnitTestAgent data type definitions.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from dataclasses import dataclass, field
from typing import Any, Optional

from app.agents.base import AgentContext, AgentResult


# ========== Type Definitions ==========

@dataclass
class UnitTestContext(AgentContext):
    """Unit test context"""
    source_files: list[str] = field(default_factory=list)
    source_contents: dict[str, str] = field(default_factory=dict)
    # Maps bare filename -> real absolute/relative source path on the user's machine.
    # Populated by the endpoint when the client sends source_paths_json.
    # Used by the agent to pass a meaningful source_path to detect_layer_from_filename().
    source_path_map: dict[str, str] = field(default_factory=dict)
    layer: str = "hal"              # hal / driver / controller / app
    test_framework: str = "gtest"   # gtest / unity (external documentation field name)
    coverage_target: float = 0.9    # target line coverage (0-1), external documentation field name
    branch_coverage_target: float = 0.8  # target branch coverage (0-1)
    function_coverage_target: float = 0.8  # target function coverage (0-1)
    max_iterations: int = 5
    output_dir: Optional[str] = None
    repo: Optional[str] = None
    branch: str = "develop"
    enable_mock: bool = True
    compile_verify: bool = True
    build_profile: str = "mingw"    # QBS build profile (mingw / host_gcc)
    platform: str = "stm32u3"      # target platform (stm32u3 / rtl8722fam / nrf52)
    auto_update_qbs: bool = True   # whether to automatically update QBS configuration file
    # Task-scoped QBS target.  App-layer tests use an isolated target so
    # unrelated generated mocks cannot contaminate the compilation.
    qbs_project_path: Optional[str] = None
    qbs_file: Optional[str] = None
    qbs_products: list[str] = field(default_factory=list)
    generation_method: str = "api"  # "cli" (primary via endpoint) or "api" (workflow default)
    coverage_max_iterations: int = 5  # maximum iterations for coverage improvement
    compact_context: str = ""
    cli_session_id: str = ""
    rulebook_content: str = ""
    large_file_diagnostics: list[dict[str, Any]] = field(default_factory=list)
    # Resumable checkpoints for sources handled in large-file mode. Each entry
    # is keyed by source hash and chunk id and can be updated by orchestration
    # as build/test evidence becomes available.
    large_file_checkpoints: list[dict[str, Any]] = field(default_factory=list)
    # The first incomplete chunk selected by the deterministic large-file
    # workflow. It is persisted so a resumed task does not restart from the
    # beginning of the source.
    large_file_active_chunk_id: Optional[str] = None

    @property
    def framework(self) -> str:
        """Compatibility for internal nodes using 'framework' field name."""
        return self.test_framework

    @property
    def target_coverage(self) -> float:
        """Compatibility for internal nodes using percentage format (0-100)."""
        return self.coverage_target * 100

    @property
    def target_branch_coverage(self) -> float:
        """Target branch coverage in percentage format (0-100)."""
        return self.branch_coverage_target * 100

    @property
    def target_function_coverage(self) -> float:
        """Target function coverage in percentage format (0-100)."""
        return self.function_coverage_target * 100


@dataclass
class GenerateOptions:
    """Generation options (for simplified interface)"""
    framework: str = "gtest"
    coverage_target: float = 0.9    # target line coverage (0-1), consistent with UnitTestContext
    branch_coverage_target: float = 0.8  # target branch coverage (0-1)
    function_coverage_target: float = 0.8  # target function coverage (0-1)
    enable_mock: bool = True
    compile_verify: bool = True
    function_name: Optional[str] = None


@dataclass
class GeneratedTest:
    """Generated unit test"""
    source_file: str
    test_file: str
    test_content: str
    mock_content: Optional[str] = None
    test_header_content: Optional[str] = None
    mock_header_content: Optional[str] = None
    coverage: float = 0.0
    compile_success: bool = False
    compile_error: str = ""
    compile_error_code: Optional[str] = None
    compile_retryable: bool = True
    gcov_data: Optional[dict] = None  # real coverage data returned by analyze_gcov_coverage()
    stub_content: Optional[str] = None
    stub_header_content: Optional[str] = None
    validation_errors: list[str] = field(default_factory=list)


@dataclass
class CompileError:
    """Compilation error entry"""
    file: str
    line: int
    column: int
    message: str
    severity: str = "error"


@dataclass
class ClassifiedCompileError:
    """Structured compilation error (with phase classification and fix suggestions)"""
    stage: str              # 'preprocess', 'compile', 'link'
    error_type: str         # specific error type
    message: str            # full error message
    file: Optional[str] = None
    line: Optional[int] = None
    column: Optional[int] = None
    symbol: Optional[str] = None       # symbol name (undefined reference / multiple definition)
    expected: Optional[str] = None     # expected type (type mismatch)
    actual: Optional[str] = None       # actual type (type mismatch)
    suggestion: Optional[str] = None   # fix suggestion


@dataclass
class CompileResult:
    """Compilation result"""
    success: bool
    output: str
    errors: list[CompileError] = field(default_factory=list)
    artifact_path: Optional[str] = None
    error_code: Optional[str] = None
    retryable: bool = True


@dataclass
class FixResult:
    """Fix result"""
    success: bool
    fixed_code: str
    changes_made: list[str] = field(default_factory=list)
    attempts_used: int = 1
    fixed_content: dict[str, str] = field(default_factory=dict)  # test_impl/test_header/mock_impl/mock_header


@dataclass
class CoverageReport:
    """Coverage report"""
    line_coverage: float = 0.0
    branch_coverage: float = 0.0
    function_coverage: float = 0.0
    raw_data: Optional[str] = None
    source_files: list[str] = field(default_factory=list)
    uncovered_lines: list[int] = field(default_factory=list)
    uncovered_functions: list[str] = field(default_factory=list)


@dataclass
class SourceFile:
    """Remote source file"""
    path: str
    content: str
    repo: str
    branch: str


@dataclass
class SourceAnalysis:
    """AST source code analysis result"""
    functions: list[dict[str, Any]] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    external_calls: list[str] = field(default_factory=list)
    includes: list[str] = field(default_factory=list)
    layer_hint: str = "unknown"


@dataclass
class UnitTestStreamChunk:
    """Streaming output chunk (unit for SSE push)"""
    task_id: str
    stage: str          # fetch | ast | layer | framework | generate | mock | compile | run | coverage | report
    progress: int       # 0-100
    message: str
    data: Optional[dict[str, Any]] = None
    is_final: bool = False
    status: str = "running"   # running | completed | failed
    token_usage: Optional[dict[str, Any]] = None


@dataclass
class UnitTestResult(AgentResult):
    """Unit test result"""
    generated_tests: list[GeneratedTest] = field(default_factory=list)
    total_coverage: float = 0.0
    iterations_used: int = 0


# ========== LangGraph state definition ==========

class UnitTestState(dict):
    """
    LangGraph workflow state.

    Key name conventions (correspond to node outputs):
      source_files, repo_slug, project_root, branch
      source_content, file_tree, related_headers
      ast_analysis, functions, dependencies, external_calls
      detected_layer, layer_context
      test_framework, mock_framework, framework_config
      generated_test_code, llm_response
      mock_code, mock_headers
      parsed_test_code, parsed_mock_code, parsed_headers
      compile_success, compile_errors, compile_output
      retry_count
      fixed_code
      test_passed, test_output, test_count, failed_cases
      coverage_data, line_coverage, branch_coverage, function_coverage
      saved_files, metrics, final_report
      qbs_project_path, build_profile, platform, qbs_updated
      external_mocks_created: list[str] — modules for which mock files were created
      external_mocks_existed: list[str] — modules with pre-existing mock files
      external_mock_modules: list[str] — all external mock module names
      parse_retry_count: int — number of parse retries due to incomplete output
      missing_file_pattern: str — "missing_mocks_only" / "missing_tests_only" / "missing_all" / "partial"
      test_retry_count: int — number of test failure retries
      previous_successful_content: dict — last successfully parsed content for truncation recovery
      project_context: str — project context (claude.md or auto-generated)
      header_content: str — source header file content
      dependent_headers: str — dependent HAL header typedef/struct/enum definitions
      vendor_api_ref: str — vendor API function signatures
      skill_prompt: str — skill instructions for the current layer
      clang_guidance: str — LibClang analysis guidance text
    """
