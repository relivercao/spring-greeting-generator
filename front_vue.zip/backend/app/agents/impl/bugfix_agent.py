"""Compatibility shim - the BugFixAgent implementation moved to `app.agents.impl.bugfix`.

The bug fix agent now returns a structured analysis and extracts validated
file patches from tagged sections. This module re-exports the previous public
symbols so existing imports keep working.
"""

from app.agents.impl.bugfix import (
    BugAnalysis,
    BugFixAgent,
    BugFixContext,
    BugFixResult,
)

__all__ = [
    "BugFixAgent",
    "BugFixContext",
    "BugAnalysis",
    "BugFixResult",
]
