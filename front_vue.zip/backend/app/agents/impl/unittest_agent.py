"""
@file unittest_agent.py
@author caoshwen
@brief UnitTestAgent - unit test generation with compile-verify loop.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import re
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional

from loguru import logger

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient


SYSTEM_PROMPT = """You are a firmware unit test generation expert.
You generate high-quality C/C++ unit tests for embedded firmware code.

Rules:
- Use the specified test framework (GTest or Unity)
- Generate comprehensive tests covering edge cases, boundary values, and error paths
- Create proper mocks for hardware dependencies
- Follow MISRA C guidelines where applicable
- Include setup/teardown fixtures
- Target the specified code coverage percentage

Output format: Return the complete test source file content."""


# ========== Type Definitions ==========

@dataclass
class UnitTestContext(AgentContext):
    """Unit test context"""
    source_files: list[str] = field(default_factory=list)
    source_contents: dict[str, str] = field(default_factory=dict)
    layer: str = "hal"              # hal / driver / controller / app
    test_framework: str = "gtest"   # gtest / unity (external documentation field name
    coverage_target: float = 0.8    # target coverage (0-1), external documentation field name
    max_iterations: int = 5
    output_dir: Optional[str] = None
    repo: Optional[str] = None
    branch: str = "develop"
    enable_mock: bool = True
    compile_verify: bool = True

    @property
    def framework(self) -> str:
        """Compatibility for internal nodes using 'framework' field name."""
        return self.test_framework

    @property
    def target_coverage(self) -> float:
        """Compatibility for internal nodes using percentage format (0-100)."""
        return self.coverage_target * 100


@dataclass
class GenerateOptions:
    """Generation options (for simplified interface)"""
    framework: str = "gtest"
    coverage_target: float = 0.8    # Target coverage (0-1), consistent with UnitTestContext
    enable_mock: bool = True
    compile_verify: bool = True
    function_name: Optional[str] = None


@dataclass
class GeneratedTest:
    """Generated unit test"""
    source_file: str
    test_file: str
    test_content: str
    mock_content: Optional[str] = None
    coverage: float = 0.0
    compile_success: bool = False


@dataclass
class CompileError:
    """Compilation error entry"""
    file: str
    line: int
    column: int
    message: str
    severity: str = "error"


@dataclass
class CompileResult:
    """Compilation result"""
    success: bool
    output: str
    errors: list[CompileError] = field(default_factory=list)
    artifact_path: Optional[str] = None


@dataclass
class FixResult:
    """Fix result"""
    success: bool
    fixed_code: str
    changes_made: list[str] = field(default_factory=list)
    attempts_used: int = 1


@dataclass
class CoverageReport:
    """Coverage report"""
    line_coverage: float = 0.0
    branch_coverage: float = 0.0
    function_coverage: float = 0.0
    raw_data: Optional[str] = None
    source_files: list[str] = field(default_factory=list)


@dataclass
class SourceFile:
    """Remote source file"""
    path: str
    content: str
    repo: str
    branch: str


@dataclass
class SourceAnalysis:
    """AST source code analysis result"""
    functions: list[dict[str, Any]] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    external_calls: list[str] = field(default_factory=list)
    includes: list[str] = field(default_factory=list)
    layer_hint: str = "unknown"


@dataclass
class UnitTestStreamChunk:
    """Streaming output chunk (unit for SSE push)"""
    task_id: str
    stage: str          # fetch | ast | layer | framework | generate | mock | compile | run | coverage | report
    progress: int       # 0-100
    message: str
    data: Optional[dict[str, Any]] = None
    is_final: bool = False
    status: str = "running"   # running | completed | failed


@dataclass
class UnitTestResult(AgentResult):
    """Unit test result"""
    generated_tests: list[GeneratedTest] = field(default_factory=list)
    total_coverage: float = 0.0
    iterations_used: int = 0


# ========== LangGraph State Definition ==========

class UnitTestState(dict):
    """
    LangGraph workflow state.

    Key naming convention (corresponds to node outputs):
      source_files, repo_slug, project_root, branch
      source_content, file_tree, related_headers
      ast_analysis, functions, dependencies, external_calls
      detected_layer, layer_context
      test_framework, mock_framework, framework_config
      generated_test_code, llm_response
      mock_code, mock_headers
      parsed_test_code, parsed_mock_code, parsed_headers
      compile_success, compile_errors, compile_output
      retry_count
      fixed_code
      test_passed, test_output, test_count, failed_cases
      coverage_data, line_coverage, branch_coverage, function_coverage
      saved_files, metrics, final_report
    """


# ========== UnitTestAgent ==========

class UnitTestAgent(BaseAgent):
    """
    Unit test generation Agent.

    Workflow:
    1. Detect code layer (HAL/Driver/Controller/App)
    2. Analyze source code, identify testable functions
    3. Generate test code via LLM
    4. Compile to verify (QBS MCP)
    5. If compilation fails, iteratively fix
    6. Calculate coverage statistics
    """

    def __init__(self, llm_bridge: LLMBridge, mcp_client: MCPClient, skill_registry=None):
        super().__init__(AgentConfig(agent_type=AgentType.UNITTEST, timeout_seconds=600), skill_registry=skill_registry)
        self._llm = llm_bridge
        self._mcp = mcp_client

    # ========== Public API ==========

    async def execute(self, task: str, context: AgentContext) -> UnitTestResult:  # type: ignore[override]
        """Execute complete unit test generation process, returns UnitTestResult."""
        result = await super().execute(task, context)
        if isinstance(result, UnitTestResult):
            return result
        # Convert to UnitTestResult when base class returns error
        return UnitTestResult(
            task_id=result.task_id,
            status=result.status,
            message=result.message,
            data=result.data,
            errors=result.errors,
            started_at=result.started_at,
            completed_at=result.completed_at,
            duration_ms=result.duration_ms,
        )

    async def stream_execute(  # type: ignore[override]
        self,
        task: str,
        context: AgentContext,
    ) -> AsyncIterator[UnitTestStreamChunk]:
        """Streaming output of test generation process, pushes AST analysis → code generation → compilation → execution → coverage."""
        import asyncio

        task_id = context.task_id
        chunk_queue: list[UnitTestStreamChunk] = []

        # Stage progress mapping
        stage_map = {
            "fetch":     (5,  "fetch",    "Fetching source files"),
            "ast":       (15, "ast",      "Analyzing AST structure"),
            "layer":     (20, "layer",    "Detecting architecture layer"),
            "framework": (25, "framework","Selecting test framework"),
            "generate":  (45, "generate", "Generating test code"),
            "mock":      (60, "mock",     "Generating mock code"),
            "compile":   (75, "compile",  "Compiling test"),
            "run":       (85, "run",      "Running tests"),
            "coverage":  (92, "coverage", "Collecting coverage"),
            "report":    (98, "report",   "Generating report"),
        }

        def _on_progress(update):
            stage = update.stage
            progress, stage_key, default_msg = stage_map.get(
                stage, (update.progress, stage, update.message)
            )
            chunk_queue.append(UnitTestStreamChunk(
                task_id=task_id,
                stage=stage_key,
                progress=progress,
                message=update.message or default_msg,
                data=update.details,
            ))

        self._progress_callbacks.setdefault(task_id, []).append(_on_progress)

        exec_task = asyncio.create_task(self.execute(task, context))

        while not exec_task.done():
            while chunk_queue:
                yield chunk_queue.pop(0)
            await asyncio.sleep(0.05)

        while chunk_queue:
            yield chunk_queue.pop(0)

        self._progress_callbacks.pop(task_id, None)

        result = exec_task.result()
        final_data: dict[str, Any] = {}
        if isinstance(result, UnitTestResult):
            final_data = {
                "total_coverage": result.total_coverage,
                "tests_generated": len(result.generated_tests),
                "iterations_used": result.iterations_used,
            }
        yield UnitTestStreamChunk(
            task_id=task_id,
            stage="report",
            progress=100 if result.status == AgentStatus.COMPLETED else -1,
            message=result.message,
            data=final_data,
            is_final=True,
            status="completed" if result.status == AgentStatus.COMPLETED else "failed",
        )

    async def generate_for_file(
        self,
        source_path: str,
        options: GenerateOptions = None,
    ) -> GeneratedTest:
        """Generate test code for a single source file (simplified interface)."""
        opts = options or GenerateOptions()
        ctx = UnitTestContext(
            source_files=[source_path],
            test_framework=opts.framework,
            coverage_target=opts.coverage_target,
            enable_mock=opts.enable_mock,
            compile_verify=opts.compile_verify,
        )
        result = await self.execute(f"Generate tests for {source_path}", ctx)
        if isinstance(result, UnitTestResult) and result.generated_tests:
            return result.generated_tests[0]
        return GeneratedTest(
            source_file=source_path,
            test_file=source_path.replace(".c", "_test.cpp").replace(".h", "_test.cpp"),
            test_content="",
            compile_success=False,
        )

    async def generate_for_function(
        self,
        source_path: str,
        function_name: str,
        options: GenerateOptions = None,
    ) -> GeneratedTest:
        """Generate test code for specified function."""
        opts = options or GenerateOptions()
        ctx = UnitTestContext(
            source_files=[source_path],
            test_framework=opts.framework,
            coverage_target=opts.coverage_target,
            enable_mock=opts.enable_mock,
            compile_verify=opts.compile_verify,
        )
        # First attempt to fetch source content via MCP, if fails let LLM do its best with empty string
        content = ""
        try:
            result = await self._mcp.call_tool("bb_get_file", repo="firmware", path=source_path)
            if result.success:
                content = result.data.get("content", "")
        except Exception as e:
            logger.warning(f"generate_for_function: could not fetch {source_path}: {e}")
        test = await self._generate_test_for_file(
            source_path, content, ctx, function_name=function_name
        )
        return test

    async def compile_and_run(
        self,
        test_file: str,
        project_root: str,
    ) -> CompileResult:
        """Compile and run the generated test file."""
        try:
            result = await self._mcp.call_tool("qbs_build", **{
                "source_file": test_file,
                "project_root": project_root,
                "toolchain": "host_gcc",
                "defines": {"UNIT_TEST": "1", "TEST_MODE": "1"},
                "extra_cflags": ["--coverage", "-g", "-O0"],
                "extra_ldflags": ["-lgtest", "-lgtest_main", "-lpthread"],
                "build_type": "unittest",
            })
            errors = [
                CompileError(
                    file=e.get("file", test_file),
                    line=e.get("line", 0),
                    column=e.get("column", 0),
                    message=e.get("message", ""),
                    severity=e.get("severity", "error"),
                )
                for e in (result.data.get("errors") or [])
            ] if result.success else []
            return CompileResult(
                success=result.success,
                output=result.data.get("output", "") if result.success else str(result),
                errors=errors,
                artifact_path=result.data.get("artifact_path") if result.success else None,
            )
        except Exception as e:
            logger.warning(f"compile_and_run failed for {test_file}: {e}")
            return CompileResult(success=False, output=str(e))

    async def get_coverage_report(
        self,
        source_files: list[str],
        test_files: list[str],
    ) -> CoverageReport:
        """Generate coverage analysis report."""
        try:
            result = await self._mcp.call_tool("qbs_collect_coverage", **{
                "source_files": source_files,
                "test_files": test_files,
                "format": "lcov",
            })
            if result.success:
                data = result.data or {}
                return CoverageReport(
                    line_coverage=data.get("line_pct", 0.0),
                    branch_coverage=data.get("branch_pct", 0.0),
                    function_coverage=data.get("function_pct", 0.0),
                    raw_data=data.get("raw_data"),
                    source_files=source_files,
                )
        except Exception as e:
            logger.warning(f"get_coverage_report failed: {e}")
        return CoverageReport(source_files=source_files)

    async def fix_compile_errors(
        self,
        test_code: str,
        errors: list[CompileError],
        max_attempts: int = 3,
    ) -> FixResult:
        """Automatically fix compilation errors."""
        current_code = test_code
        changes: list[str] = []

        for attempt in range(1, max_attempts + 1):
            if not errors:
                break

            error_text = "\n".join(
                f"{e.file}:{e.line}:{e.column}: {e.severity}: {e.message}"
                for e in errors
            )
            prompt = (
                "Fix the following compilation errors in this C++ unit test code.\n\n"
                f"Errors:\n{error_text}\n\n"
                f"Current code:\n```cpp\n{current_code}\n```\n\n"
                "Return only the corrected complete source file."
            )
            try:
                response = await self._llm.generate(
                    [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                    temperature=0.2,
                )
                fixed = self._extract_code_block(response.content) or response.content
                if fixed != current_code:
                    changes.append(f"Attempt {attempt}: applied LLM fix")
                    current_code = fixed
                    # recompile after fix
                    compile_result = await self._mcp.call_tool("qbs_build", **{
                        "source_file": current_code,
                        "toolchain": "host_gcc",
                        "defines": {"UNIT_TEST": "1"},
                        "build_type": "unittest",
                    })
                    if compile_result.success:
                        return FixResult(
                            success=True,
                            fixed_code=current_code,
                            changes_made=changes,
                            attempts_used=attempt,
                        )
                    errors = [
                        CompileError(
                            file=e.get("file", ""),
                            line=e.get("line", 0),
                            column=e.get("column", 0),
                            message=e.get("message", ""),
                        )
                        for e in (compile_result.data.get("errors") or [])
                    ]
            except Exception as e:
                logger.warning(f"fix_compile_errors attempt {attempt} failed: {e}")

        return FixResult(
            success=False,
            fixed_code=current_code,
            changes_made=changes,
            attempts_used=max_attempts,
        )

    async def fetch_source_from_repo(
        self,
        repo: str,
        file_paths: list[str],
        branch: str = "main",
    ) -> list[SourceFile]:
        """Fetch remote repository source files via Bitbucket MCP."""
        source_files: list[SourceFile] = []
        try:
            result = await self._mcp.call_tool("bb_get_file_content", **{
                "repo": repo,
                "file_paths": file_paths,
                "branch": branch,
            })
            if result.success:
                for item in result.data.get("files", []):
                    source_files.append(SourceFile(
                        path=item["path"],
                        content=item.get("content", ""),
                        repo=repo,
                        branch=branch,
                    ))
        except Exception as e:
            logger.warning(f"fetch_source_from_repo failed for {repo}: {e}")
            for path in file_paths:
                try:
                    single = await self._mcp.call_tool("bb_get_file", repo=repo, path=path)
                    if single.success:
                        source_files.append(SourceFile(
                            path=path,
                            content=single.data.get("content", ""),
                            repo=repo,
                            branch=branch,
                        ))
                except Exception as inner_e:
                    logger.warning(f"Could not fetch {path} from {repo}: {inner_e}")
        return source_files

    # ========== Protected Internal Interfaces (BaseAgent Abstract Method Implementations) ==========

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, UnitTestContext):
            raise ValidationError("UnitTestAgent requires UnitTestContext")
        ctx = context
        if not ctx.source_files and not ctx.source_contents:
            raise ValidationError("At least one source file is required")
        if ctx.framework not in ("gtest", "unity"):
            raise ValidationError(f"Invalid framework: {ctx.framework}")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx: UnitTestContext = context  # type: ignore[assignment]
        task_id = ctx.task_id

        generated_tests: list[GeneratedTest] = []
        iterations_used = 0

        # ── Phase 1: Get source code content ──────────────────────────────────────
        await self._report_progress(task_id, 5, "fetch", "Fetching source files")
        source_contents = dict(ctx.source_contents)
        for file_path in ctx.source_files:
            if file_path not in source_contents:
                try:
                    result = await self._mcp.call_tool("bb_get_file", repo="firmware", path=file_path)
                    if result.success:
                        source_contents[file_path] = result.data.get("content", "")
                except Exception:
                    logger.warning(f"Could not read file {file_path} via MCP, skipping")

        total_files = len(source_contents)
        if total_files == 0:
            return UnitTestResult(
                task_id=task_id,
                status=AgentStatus.FAILED,
                message="No source files to process",
            )

        # ── Phase 2: Generate test code via LLM ────────────────────────────────────
        for idx, (file_path, content) in enumerate(source_contents.items()):
            self._is_cancelled(task_id)
            progress = int(15 + (idx / total_files) * 40)
            await self._report_progress(
                task_id, progress, "generate",
                f"Generating tests for {file_path} ({idx+1}/{total_files})"
            )
            test = await self._generate_test_for_file(file_path, content, ctx)
            generated_tests.append(test)

        iterations_used = 1

        # ── Phase 3: Compile verification (enabled when compile_verify=True and output_dir is set)
        if ctx.compile_verify and ctx.output_dir and generated_tests:
            self._is_cancelled(task_id)
            await self._report_progress(task_id, 60, "compile", "Compiling generated tests")
            generated_tests, iterations_used = await self._compile_and_fix_tests(
                generated_tests, ctx, task_id
            )

        # ── Phase 4: Run tests ────────────────────────────────────────────
        test_output = ""
        test_count = 0
        failed_cases: list[str] = []
        if ctx.compile_verify and ctx.output_dir and any(t.compile_success for t in generated_tests):
            self._is_cancelled(task_id)
            await self._report_progress(task_id, 80, "run", "Running tests")
            test_output, test_count, failed_cases = await self._run_compiled_tests(
                ctx.output_dir, ctx, task_id
            )

        # ── Phase 5: Coverage statistics ──────────────────────────────────────────
        total_coverage = 0.0
        if test_count > 0:
            self._is_cancelled(task_id)
            await self._report_progress(task_id, 90, "coverage", "Collecting coverage")
            total_coverage = await self._parse_coverage_from_output(
                test_output, list(source_contents.keys())
            )
        elif generated_tests:
            total_coverage = sum(t.coverage for t in generated_tests) / len(generated_tests)

        await self._report_progress(task_id, 97, "report", "Generating report")

        return UnitTestResult(
            task_id=task_id,
            status=AgentStatus.COMPLETED,
            message=f"Generated {len(generated_tests)} test files, coverage: {total_coverage:.1f}%",
            data={
                "files_processed": total_files,
                "tests_generated": len(generated_tests),
                "coverage": total_coverage,
                "test_count": test_count,
                "failed_cases": failed_cases,
                "generated_tests": [
                    {
                        "source_file": t.source_file,
                        "test_file": t.test_file,
                        "test_content": t.test_content,
                        "mock_content": t.mock_content,
                        "coverage": t.coverage,
                        "compile_success": t.compile_success,
                    }
                    for t in generated_tests
                ],
            },
            generated_tests=generated_tests,
            total_coverage=total_coverage,
            iterations_used=iterations_used,
        )

    async def _compile_and_fix_tests(
        self,
        generated_tests: list[GeneratedTest],
        ctx: "UnitTestContext",
        task_id: str,
    ) -> tuple[list[GeneratedTest], int]:
        """Compile generated test files, on failure use LLM to fix, returns updated tests and iteration count."""
        iterations = 1
        for test in generated_tests:
            if not test.test_content:
                continue
            for attempt in range(1, ctx.max_iterations + 1):
                compile_result = await self._do_compile(test.test_content, ctx.output_dir or ".")
                test.compile_success = compile_result.success
                if compile_result.success:
                    break
                if attempt < ctx.max_iterations and compile_result.errors:
                    await self._report_progress(
                        task_id, 60 + attempt * 5, "compile",
                        f"Fixing compile errors (attempt {attempt}/{ctx.max_iterations})"
                    )
                    fix = await self.fix_compile_errors(
                        test.test_content, compile_result.errors, max_attempts=1
                    )
                    test.test_content = fix.fixed_code
                    iterations = max(iterations, attempt + 1)
        return generated_tests, iterations

    async def _do_compile(self, test_content: str, project_root: str) -> CompileResult:
        """Call qbs_build to compile, returns CompileResult."""
        try:
            result = await self._mcp.call_tool("qbs_build",
                project_path=project_root,
                profile="host_gcc",
                configuration="debug",
            )
            if result.success:
                return CompileResult(
                    success=True,
                    output=result.data.get("stdout", ""),
                )
            errors = self._parse_gcc_errors(result.data.get("stderr", ""))
            return CompileResult(success=False, output=result.data.get("stderr", ""), errors=errors)
        except Exception as e:
            logger.warning(f"_do_compile failed: {e}")
            return CompileResult(success=False, output=str(e))

    async def _run_compiled_tests(
        self,
        project_root: str,
        ctx: "UnitTestContext",
        task_id: str,
    ) -> tuple[str, int, list[str]]:
        """Run compiled tests, returns (stdout, test_count, failed_cases)."""
        try:
            result = await self._mcp.call_tool("qbs_run_tests",
                project_path=project_root,
                profile="host_gcc",
            )
            stdout = result.data.get("stdout", "") if result.success else result.data.get("stderr", "")
            test_count, failed_cases = self._parse_test_results(stdout)
            return stdout, test_count, failed_cases
        except Exception as e:
            logger.warning(f"_run_compiled_tests failed: {e}")
            return "", 0, []

    async def _parse_coverage_from_output(
        self,
        test_output: str,
        source_files: list[str],
    ) -> float:
        """Parse line coverage percentage from gcov/gtest stdout, returns 0.0 on parse failure."""
        import re as _re
        # gcov format: "Lines executed:85.71% of 42"
        m = _re.search(r"Lines executed:(\d+(?:\.\d+)?)%", test_output)
        if m:
            return float(m.group(1))
        # lcov format: "lines......: 82.3%"
        m = _re.search(r"lines[.\s]+:\s*(\d+(?:\.\d+)?)%", test_output)
        if m:
            return float(m.group(1))
        return 0.0

    def _parse_gcc_errors(self, stderr: str) -> list[CompileError]:
        """Parse list of compilation errors from GCC stderr."""
        import re as _re
        errors: list[CompileError] = []
        pattern = _re.compile(r"^(.+?):(\d+):(\d+):\s+(error|warning):\s+(.+)$", _re.MULTILINE)
        for m in pattern.finditer(stderr):
            errors.append(CompileError(
                file=m.group(1), line=int(m.group(2)), column=int(m.group(3)),
                severity=m.group(4), message=m.group(5),
            ))
        if not errors and stderr.strip():
            errors.append(CompileError(file="", line=0, column=0, message=stderr.strip()))
        return errors

    def _parse_test_results(self, stdout: str) -> tuple[int, list[str]]:
        """Parse total tests and list of failed cases from GTest stdout."""
        import re as _re
        total = 0
        failed: list[str] = []
        m = _re.search(r"\[\s*PASSED\s*\]\s*(\d+)", stdout)
        if m:
            total += int(m.group(1))
        for fm in _re.finditer(r"\[\s*FAILED\s*\]\s+(\S+)", stdout):
            failed.append(fm.group(1))
            total += 1
        return total, failed

    # ========== Protected Internal Interfaces (LangGraph 12 nodes) ==========

    def _build_workflow(self):
        """Build UnitTest LangGraph workflow (12 nodes · v3.2)

        Flow: fetch_source → analyze_ast → detect_layer → select_framework →
              generate_test → generate_mock → parse_output → compile_test →
              (handle_errors ↔ compile_test retry loop) → run_test →
              collect_coverage → generate_report → END
        """
        try:
            from langgraph.graph import StateGraph, START, END
        except ImportError:
            logger.warning("langgraph not installed; workflow unavailable")
            return None

        workflow = StateGraph(UnitTestState)

        workflow.add_node("fetch_source",     self._fetch_source)
        workflow.add_node("analyze_ast",      self._analyze_ast)
        workflow.add_node("detect_layer",     self._detect_layer)
        workflow.add_node("select_framework", self._select_framework)
        workflow.add_node("generate_test",    self._generate_test)
        workflow.add_node("generate_mock",    self._generate_mock)
        workflow.add_node("parse_output",     self._parse_output)
        workflow.add_node("compile_test",     self._compile_test)
        workflow.add_node("handle_errors",    self._handle_errors)
        workflow.add_node("run_test",         self._run_test)
        workflow.add_node("collect_coverage", self._collect_coverage)
        workflow.add_node("generate_report",  self._generate_report)

        workflow.add_edge(START,              "fetch_source")
        workflow.add_edge("fetch_source",     "analyze_ast")
        workflow.add_edge("analyze_ast",      "detect_layer")
        workflow.add_edge("detect_layer",     "select_framework")
        workflow.add_edge("select_framework", "generate_test")
        workflow.add_edge("generate_test",    "generate_mock")
        workflow.add_edge("generate_mock",    "parse_output")
        workflow.add_edge("parse_output",     "compile_test")

        workflow.add_conditional_edges(
            "compile_test",
            self._should_retry_compile,
            {
                "retry":     "handle_errors",
                "success":   "run_test",
                "max_retry": "generate_report",
            },
        )
        workflow.add_edge("handle_errors",   "compile_test")
        workflow.add_edge("run_test",        "collect_coverage")
        workflow.add_edge("collect_coverage","generate_report")
        workflow.add_edge("generate_report", END)

        return workflow.compile()

    def _should_retry_compile(self, state: UnitTestState) -> str:
        """Compile retry condition check"""
        if state.get("compile_success"):
            return "success"
        if state.get("retry_count", 0) >= 3:
            return "max_retry"
        return "retry"

    async def _fetch_source(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 1: Fetch source file content and file tree via Bitbucket MCP."""
        source_files = state.get("source_files", [])
        repo = state.get("repo_slug", "firmware")
        branch = state.get("branch", "develop")

        files = await self.fetch_source_from_repo(repo, source_files, branch)
        source_content = {f.path: f.content for f in files}

        related_headers: list[str] = []
        for f in files:
            for inc in re.findall(r'#include\s+"([^"]+\.h)"', f.content):
                related_headers.append(inc)

        try:
            tree_result = await self._mcp.call_tool("bb_get_file_tree", **{
                "repo": repo,
                "path": state.get("project_root", "/"),
            })
            file_tree = tree_result.data if tree_result.success else {}
        except Exception as e:
            logger.warning(f"_fetch_source file tree failed: {e}")
            file_tree = {}

        return {
            "source_content": source_content,
            "file_tree": file_tree,
            "related_headers": list(set(related_headers)),
        }

    async def _analyze_ast(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 2: Use libclang to parse source AST, extract function signatures, dependencies, external calls."""
        source_content: dict[str, str] = state.get("source_content", {})
        all_functions: list[dict] = []
        all_dependencies: list[str] = []
        all_external_calls: list[str] = []

        for path, content in source_content.items():
            analysis = self._analyze_source_ast(path, content)
            all_functions.extend(analysis.functions)
            all_dependencies.extend(analysis.dependencies)
            all_external_calls.extend(analysis.external_calls)

        return {
            "ast_analysis": {
                "functions": all_functions,
                "dependencies": list(set(all_dependencies)),
                "external_calls": list(set(all_external_calls)),
            },
            "functions": all_functions,
            "dependencies": list(set(all_dependencies)),
            "external_calls": list(set(all_external_calls)),
        }

    async def _detect_layer(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 3: Detect source file architecture layer based on AST analysis and path rules."""
        source_files: list[str] = state.get("source_files", [])
        functions: list[dict] = state.get("functions", [])

        layer = self._infer_layer_from_paths(source_files, functions)
        layer_context = {
            "layer": layer,
            "mock_strategy": "cmock" if layer in ("hal", "driver") else "fff",
            "test_prefix": f"{layer}_",
        }
        return {"detected_layer": layer, "layer_context": layer_context}

    async def _select_framework(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 4: Automatically select test framework and Mock framework based on layer and project configuration."""
        detected_layer: str = state.get("detected_layer", "hal")

        if detected_layer in ("hal", "driver"):
            test_framework = "unity"
            mock_framework = "cmock"
        else:
            test_framework = "gtest"
            mock_framework = "fff"

        framework_config = {
            "test_framework": test_framework,
            "mock_framework": mock_framework,
            "extra_cflags": ["--coverage", "-g", "-O0"],
            "extra_ldflags": (
                ["-lgtest", "-lgtest_main", "-lpthread"]
                if test_framework == "gtest"
                else ["-lunity"]
            ),
        }
        return {
            "test_framework": test_framework,
            "mock_framework": mock_framework,
            "framework_config": framework_config,
        }

    async def _generate_test(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 5: Call LLM to generate test code based on AST analysis and layer context."""
        source_content: dict[str, str] = state.get("source_content", {})
        functions: list[dict] = state.get("functions", [])
        detected_layer: str = state.get("detected_layer", "hal")
        test_framework: str = state.get("test_framework", "gtest")

        func_list = "\n".join(f"- {f.get('name', '')}({f.get('signature', '')})" for f in functions)
        source_text = "\n\n".join(
            f"// File: {p}\n```c\n{c}\n```" for p, c in source_content.items()
        )

        prompt = (
            f"Generate unit tests for the following {detected_layer} layer C/C++ firmware code.\n"
            f"Framework: {test_framework}\n"
            f"Functions to test:\n{func_list}\n\n"
            f"{source_text}\n\n"
            "Generate the complete test file with setup/teardown and edge cases."
        )
        response = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
        )
        return {
            "generated_test_code": response.content,
            "llm_response": response.content,
        }

    async def _generate_mock(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 6: Generate Mock/Stub code based on external dependency list."""
        external_calls: list[str] = state.get("external_calls", [])
        mock_framework: str = state.get("mock_framework", "fff")
        related_headers: list[str] = state.get("related_headers", [])

        if not external_calls:
            return {"mock_code": "", "mock_headers": []}

        dep_list = "\n".join(f"- {call}" for call in external_calls)
        header_list = "\n".join(f"- {h}" for h in related_headers)
        prompt = (
            f"Generate Mock/Stub code using {mock_framework} for these external dependencies:\n"
            f"{dep_list}\n\n"
            f"Related headers:\n{header_list}\n\n"
            "Return the complete mock source file."
        )
        response = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
        )
        mock_headers = re.findall(r'#include\s+"([^"]+)"', response.content)
        return {"mock_code": response.content, "mock_headers": mock_headers}

    async def _parse_output(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 7: Parse LLM output, separate test code and Mock code, format validation."""
        raw_test: str = state.get("generated_test_code", "")
        raw_mock: str = state.get("mock_code", "")

        parsed_test = self._extract_code_block(raw_test) or raw_test
        parsed_mock = self._extract_code_block(raw_mock) or raw_mock
        parsed_headers = re.findall(r'#include\s+[<"]([^>"]+)[>"]', parsed_test)

        return {
            "parsed_test_code": parsed_test,
            "parsed_mock_code": parsed_mock,
            "parsed_headers": parsed_headers,
        }

    async def _compile_test(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 8: Trigger Host GCC compilation of test code via QBS MCP."""
        project_root: str = state.get("project_root", ".")
        try:
            result = await self._mcp.call_tool("qbs_build",
                project_path=project_root,
                profile="host_gcc",
                configuration="debug",
            )
            if result.success:
                return {
                    "compile_success": True,
                    "compile_errors": [],
                    "compile_output": result.data.get("stdout", ""),
                }
            errors = self._parse_gcc_errors(result.data.get("stderr", ""))
            return {
                "compile_success": False,
                "compile_errors": [{"file": e.file, "line": e.line, "column": e.column, "message": e.message} for e in errors],
                "compile_output": result.data.get("stderr", ""),
            }
        except Exception as e:
            logger.warning(f"_compile_test failed: {e}")
            return {
                "compile_success": False,
                "compile_errors": [{"message": str(e)}],
                "compile_output": "",
            }

    async def _handle_errors(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 9: Parse compilation errors, call LLM to generate fix patch."""
        raw_errors: list[dict] = state.get("compile_errors", [])
        errors = [
            CompileError(
                file=e.get("file", ""),
                line=e.get("line", 0),
                column=e.get("column", 0),
                message=e.get("message", ""),
                severity=e.get("severity", "error"),
            )
            for e in raw_errors
        ]
        fix_result = await self.fix_compile_errors(
            test_code=state.get("parsed_test_code", ""),
            errors=errors,
            max_attempts=1,  # Execute once per node, loop controlled by graph
        )
        return {
            "parsed_test_code": fix_result.fixed_code,
            "retry_count": state.get("retry_count", 0) + 1,
        }

    async def _run_test(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 10: Execute tests via qbs_run_tests, capture results."""
        project_root: str = state.get("project_root", ".")
        try:
            result = await self._mcp.call_tool("qbs_run_tests",
                project_path=project_root,
                profile="host_gcc",
            )
            stdout = result.data.get("stdout", "") if result.success else result.data.get("stderr", "")
            test_count, failed_cases = self._parse_test_results(stdout)
            return {
                "test_passed": result.success and not failed_cases,
                "test_output": stdout,
                "test_count": test_count,
                "failed_cases": failed_cases,
            }
        except Exception as e:
            logger.warning(f"_run_test failed: {e}")
            return {
                "test_passed": False,
                "test_output": str(e),
                "test_count": 0,
                "failed_cases": [],
            }

    async def _collect_coverage(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 11: Parse gcov coverage data from qbs_run_tests output."""
        test_output: str = state.get("test_output", "")
        source_files: list[str] = state.get("source_files", [])
        line_cov = await self._parse_coverage_from_output(test_output, source_files)
        return {
            "coverage_data": test_output,
            "line_coverage": line_cov,
            "branch_coverage": 0.0,   # gcov stdout doesn't contain branch coverage, leave as 0
            "function_coverage": 0.0,
        }

    async def _generate_report(self, state: UnitTestState) -> Dict[str, Any]:
        """Node 12: Aggregate test results, coverage data, generate final report and statistics."""
        line_cov: float = state.get("line_coverage", 0.0)
        branch_cov: float = state.get("branch_coverage", 0.0)
        func_cov: float = state.get("function_coverage", 0.0)
        test_count: int = state.get("test_count", 0)
        failed_cases: list = state.get("failed_cases", [])
        compile_success: bool = state.get("compile_success", False)
        test_passed: bool = state.get("test_passed", False)

        metrics = {
            "compile_success": compile_success,
            "test_passed": test_passed,
            "test_count": test_count,
            "failed_count": len(failed_cases),
            "line_coverage": line_cov,
            "branch_coverage": branch_cov,
            "function_coverage": func_cov,
            "retry_count": state.get("retry_count", 0),
        }
        final_report = (
            f"# Unit Test Report\n\n"
            f"- Compile: {'✓' if compile_success else '✗'}\n"
            f"- Tests: {test_count - len(failed_cases)}/{test_count} passed\n"
            f"- Line coverage: {line_cov:.1f}%\n"
            f"- Branch coverage: {branch_cov:.1f}%\n"
            f"- Function coverage: {func_cov:.1f}%\n"
        )

        saved_files: list[str] = []
        output_dir: str = state.get("output_dir", "")
        if output_dir and state.get("parsed_test_code"):
            for src in state.get("source_files", []):
                import os
                base = os.path.splitext(os.path.basename(src))[0]
                saved_files.append(os.path.join(output_dir, f"{base}_test.cpp"))

        return {
            "saved_files": saved_files,
            "metrics": metrics,
            "final_report": final_report,
            "coverage": line_cov,
            "test_count": test_count,
        }

    # ========== Helper Methods ==========

    def _analyze_source_ast(
        self,
        source_path: str,
        content: str = "",
    ) -> SourceAnalysis:
        """Analyze source AST structure using libclang (called by _analyze_ast node)."""
        functions: list[dict] = []
        dependencies: list[str] = []
        external_calls: list[str] = []
        includes: list[str] = []

        try:
            import clang.cindex as clang  # type: ignore
            index = clang.Index.create()
            tu = index.parse(
                source_path,
                unsaved_files=[(source_path, content)] if content else None,
                args=["-x", "c", "-std=c99"],
            )
            for node in tu.cursor.walk_preorder():
                if node.kind == clang.CursorKind.FUNCTION_DECL and node.is_definition():
                    functions.append({
                        "name": node.spelling,
                        "signature": node.displayname,
                        "line": node.location.line,
                        "return_type": node.result_type.spelling,
                    })
                elif node.kind == clang.CursorKind.CALL_EXPR:
                    callee = node.referenced.spelling if node.referenced else node.spelling
                    if callee:
                        external_calls.append(callee)
                elif node.kind == clang.CursorKind.INCLUSION_DIRECTIVE:
                    includes.append(node.spelling)
                    dependencies.append(node.spelling)
        except (ImportError, Exception):
            # libclang unavailable or parsing failed, fall back to regex parsing
            functions = self._parse_functions_regex(content or "")
            includes = re.findall(r'#include\s+[<"]([^>"]+)[>"]', content or "")
            dependencies = includes
            external_calls = self._parse_calls_regex(content or "")

        layer_hint = self._infer_layer_from_paths([source_path], functions)
        return SourceAnalysis(
            functions=functions,
            dependencies=list(set(dependencies)),
            external_calls=list(set(external_calls)),
            includes=includes,
            layer_hint=layer_hint,
        )

    # ========== Private Helper Methods ==========

    async def _generate_test_for_file(
        self,
        file_path: str,
        content: str,
        ctx: "UnitTestContext",
        function_name: Optional[str] = None,
    ) -> GeneratedTest:
        """Generate tests for a single file (or function)."""
        scope = f"function `{function_name}`" if function_name else "all functions"
        prompt = (
            f"Generate unit tests for the following {ctx.layer} layer C/C++ file.\n"
            f"Framework: {ctx.framework}\n"
            f"Target coverage: {ctx.target_coverage}%\n"
            f"Scope: {scope}\n\n"
            f"File: {file_path}\n"
            f"```c\n{content}\n```\n\n"
            "Generate the complete test file."
        )
        response = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            # max_tokens=8192,  # Using default max tokens
        )
        test_content = self._extract_code_block(response.content) or response.content
        test_file = file_path.replace(".c", "_test.cpp").replace(".h", "_test.cpp")
        return GeneratedTest(
            source_file=file_path,
            test_file=test_file,
            test_content=test_content,
            coverage=ctx.target_coverage * 0.85,  # Estimated coverage
        )

    def _extract_code_block(self, text: str) -> Optional[str]:
        """Extract code block content from LLM response."""
        match = re.search(r"```(?:cpp|c|cxx)?\n(.*?)```", text, re.DOTALL)
        if match:
            return match.group(1).strip()
        return None

    def _infer_layer_from_paths(
        self,
        source_files: list[str],
        functions: list[dict],
    ) -> str:
        """Infer architecture layer based on file paths and function names."""
        combined = " ".join(source_files).lower()
        if any(kw in combined for kw in ("hal", "hardware")):
            return "hal"
        if any(kw in combined for kw in ("driver", "drv")):
            return "driver"
        if any(kw in combined for kw in ("service", "ctrl", "controller")):
            return "service"
        if any(kw in combined for kw in ("app", "application")):
            return "app"
        # Heuristic inference by function name
        func_names = " ".join(f.get("name", "") for f in functions).lower()
        if any(kw in func_names for kw in ("hal_", "gpio_", "uart_", "spi_", "i2c_")):
            return "hal"
        if any(kw in func_names for kw in ("drv_", "driver_")):
            return "driver"
        return "hal"

    def _parse_functions_regex(self, content: str) -> list[dict]:
        """Regex fallback: Extract function declarations from C source code."""
        pattern = re.compile(
            r"(?:[\w\s\*]+?)\s+(\w+)\s*\(([^)]*)\)\s*\{"
        )
        results = []
        for m in pattern.finditer(content):
            name = m.group(1)
            if name not in ("if", "for", "while", "switch", "return"):
                results.append({
                    "name": name,
                    "signature": m.group(0).split("{")[0].strip(),
                    "line": content[: m.start()].count("\n") + 1,
                    "return_type": "",
                })
        return results

    def _parse_calls_regex(self, content: str) -> list[str]:
        """Regex fallback: Extract function calls from C source code."""
        return re.findall(r"\b(\w+)\s*\(", content)
