"""ChatAgent - multi-turn conversation with deterministic intent routing hints."""

from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path
from typing import Any, AsyncIterator, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from app.skills.registry import SkillRegistry

from loguru import logger

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    CancelledException,
    ValidationError,
)
from app.llm.bridge import LLMBridge
from app.llm.base import LLMServerError, LLMStreamChunk
from app.mcp.client import MCPClient
from app.mcp.servers.connected_apps_server import ConnectedAppsMCPServer
from app.services.chat_artifacts import ChatArtifactService, requested_document_format
from app.services.chat_presentations import PRESENTATION_CONTENT_INSTRUCTIONS
from app.services.chat_attachments import ATTACHMENT_INSTRUCTIONS, ATTACHMENT_MARKER, attachment_message
from app.services.app_connections import APP_CATALOG

from .intents import IntentMatch, detect_intent
from .prompts import SYSTEM_PROMPT
from .types import ChatContext, ChatResult
from .app_tools import collect_app_evidence


_PRIVATE_APP_PATTERN = re.compile(
    r"\b(?:" + "|".join(
        re.escape(slug).replace(r"\-", r"[-\s]?") for slug in [*(app["slug"] for app in APP_CATALOG), "feishu", "lark"]
    ) + r")\b",
    re.IGNORECASE,
)
_PRIVATE_VALUE_PATTERN = re.compile(
    r"\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|password|passwd|secret|private[_ -]?key)\b"
    r"\s*[:=]\s*\S+|\bAKIA[0-9A-Z]{16}\b|\bsk-[A-Za-z0-9_-]{20,}\b|"
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    re.IGNORECASE,
)
_CODE_CONTENT_PATTERN = re.compile(
    r"```|~~~|^\s*#include\b|^\s*(?:static\s+)?"
    r"(?:void|int|char|float|double|struct|uint\d+_t)\s+\w+\s*[({;]",
    re.MULTILINE,
)
_MAX_PUBLIC_SEARCH_QUERY_LENGTH = 500


class ChatAgent(BaseAgent):
    """Multi-turn conversation agent.

    Workflow: build history -> generate reply -> detect routing intent with
    confidence -> expose the suggested specialist agent.
    """

    def __init__(
        self,
        llm_bridge: LLMBridge,
        mcp_client: MCPClient,
        skill_registry: Optional["SkillRegistry"] = None,
        artifact_service: Optional[ChatArtifactService] = None,
        connected_apps: Optional[ConnectedAppsMCPServer] = None,
    ):
        super().__init__(
            AgentConfig(
                agent_type=AgentType.CHAT,
                timeout_seconds=300 if connected_apps is not None else 120,
                enable_streaming=True,
            ),
            skill_registry=skill_registry,
        )
        self._llm = llm_bridge
        self._mcp = mcp_client
        self._artifact_service = artifact_service
        self._connected_apps = connected_apps

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, ChatContext):
            raise ValidationError("ChatAgent requires ChatContext")
        if not isinstance(context.message, str) or not context.message.strip():
            raise ValidationError("A nonempty text message is required")
        if not isinstance(context.history, list):
            raise ValidationError("Chat history must be a list of conversation messages")
        for message in context.history:
            if (
                not isinstance(message, dict)
                or message.get("role") not in {"user", "assistant"}
                or not isinstance(message.get("content"), str)
            ):
                raise ValidationError("Chat history must contain only user and assistant text messages")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        assert isinstance(ctx, ChatContext)
        task_id = ctx.task_id
        skill_plan = await self._prepare_agent_skills(
            ctx, "respond", scope="chat", inputs={"history_messages": len(ctx.history)}
        )

        system_prompt = SYSTEM_PROMPT.format(web_search_context="") + self._get_skills_prompt()
        has_attachments = bool(ctx.attachments) or any(
            ATTACHMENT_MARKER in str(item.get("content", "")) for item in ctx.history
        )
        if has_attachments:
            system_prompt += "\n\n" + ATTACHMENT_INSTRUCTIONS
        document_format = self._requested_document_format(ctx.message)
        if document_format:
            system_prompt += (
                "\n\nDraft the requested document content. The application will export the file "
                "and supply its download link. Do not write local files, run scripts, "
                "or invent file paths or download links."
            )
        if skill_plan.prompt:
            system_prompt += "\n\n" + skill_plan.prompt
        app_operations = []
        if self._connected_apps is not None and not has_attachments:
            app_evidence, app_operations = await collect_app_evidence(self, ctx, self._connected_apps)
            system_prompt += "\n\n" + app_evidence
        else:
            system_prompt += "\n\nNo connected application tools are available in this conversation."
        if ctx.enable_web_search and not app_operations and not has_attachments:
            web_context = await self._search_context(ctx.message, ctx.history)
            if web_context:
                system_prompt += "\n\n" + web_context
        self._is_cancelled(task_id)
        messages = [{"role": "system", "content": system_prompt}]
        for msg in ctx.history:
            messages.append({"role": msg["role"], "content": msg["content"]})
        messages.append({"role": "user", "content": attachment_message(ctx.message, ctx.attachments)})

        await self._report_progress(task_id, 30, "thinking", "Processing your message")

        attachment_llm_options = self._attachment_llm_options(ctx.attachments)
        response_text, response_error = await self._generate_response(
            messages,
            app_operations,
            llm_options=attachment_llm_options,
        )
        self._is_cancelled(task_id)

        await self._report_progress(task_id, 90, "done", "Response ready")

        match: IntentMatch = detect_intent(ctx.message)

        result_data = {
            "response": response_text,
            "intent": match.intent,
            "intent_confidence": match.confidence,
            "suggested_agent": match.suggested_agent,
            "app_operations": app_operations,
        }
        if response_error:
            result_data["response_error"] = response_error
        if document_format and response_error:
            response_text += "\n\nDocument creation was not attempted because response generation failed."
            result_data["response"] = response_text
            result_data["document_error"] = "Document generation was not attempted"
        elif document_format:
            try:
                artifact = await self._create_document(
                    ctx,
                    document_format,
                    response_text,
                    llm_options=attachment_llm_options,
                )
                # The first model response is drafting context, not the export result.
                # Report the saved file instead of repeating draft code or capability disclaimers.
                response_text = "Your document is ready. Open the file link below."
                response_text += f"\n\nGenerated document: [{artifact.path}]({artifact.url})"
                result_data["response"] = response_text
                result_data["artifacts"] = [{
                    "id": artifact.artifact_id,
                    "filename": artifact.filename,
                    "path": artifact.path,
                    "url": artifact.url,
                    "download_url": artifact.download_url,
                    "size_bytes": artifact.size_bytes,
                }]
            except CancelledException:
                raise
            except Exception as error:
                logger.exception("Chat document creation failed: {}", error)
                response_text += "\n\nDocument creation failed. Please retry with a shorter document request."
                result_data["response"] = response_text
                result_data["document_error"] = "Document generation failed"

        return ChatResult(
            task_id=task_id,
            status=AgentStatus.COMPLETED,
            message="Chat response generated",
            data={
                **result_data,
            },
            response=response_text,
            intent=match.intent,
            suggested_agent=match.suggested_agent,
        )

    def _attachment_llm_options(self, attachments: list[dict[str, Any]]) -> dict[str, Any]:
        """Force original-file analysis through Claude Code when paths are present."""
        options = self._llm_call_options()
        allowed_dirs = {
            str(Path(str(item["path"])).resolve().parent)
            for item in attachments
            if item.get("path")
        }
        if allowed_dirs:
            options["provider"] = "claude_cli"
            options["allowed_dirs"] = sorted(allowed_dirs)
        return options

    async def _generate_response(
        self,
        messages,
        app_operations,
        *,
        llm_options: Optional[dict[str, Any]] = None,
    ) -> tuple[str, str | None]:
        """Keep observed operation outcomes available if answer synthesis fails."""
        try:
            response = await self._llm.generate(
                messages,
                temperature=0.7,
                max_tokens=4096,
                **(llm_options or self._llm_call_options()),
            )
            if not response.content or not response.content.strip():
                raise LLMServerError(
                    "LLM provider returned an empty response", provider=response.provider, status_code=503,
                )
            return response.content, None
        except CancelledException:
            raise
        except Exception:
            if not app_operations:
                raise
            logger.exception("Chat synthesis failed; preserving recorded app operation outcomes")
            lines = ["Response generation is unavailable. Recorded application operations:"]
            for operation in app_operations:
                outcome = "succeeded" if operation["success"] else "failed or uncertain"
                lines.append(f"- {operation['app']} / {operation['tool']}: {outcome}.")
            lines.append("Remaining work may be incomplete. No operation was retried; check the app before retrying.")
            return "\n".join(lines), "Response generation failed after application operations"

    @staticmethod
    def _requested_document_format(message: str) -> str | None:
        """Return a supported extension only for explicit document-creation requests."""
        return requested_document_format(message)

    async def _create_document(
        self,
        context: ChatContext,
        extension: str,
        answer: str,
        *,
        llm_options: Optional[dict[str, Any]] = None,
    ):
        self._is_cancelled(context.task_id)
        requested_name = re.search(
            r"([A-Za-z0-9_.-]+\.(?:markdown|docx|xlsx|pptx|html|htm|csv|txt|md|doc|xls|ppt))\b",
            context.message,
            re.IGNORECASE,
        )
        default_name = requested_name.group(1) if requested_name else f"chat-document{extension}"
        filename = Path(default_name).with_suffix(extension).name
        generation_prompt = (
            "Create the requested document as a single JSON object, with no Markdown fences or extra text. "
            "Use exactly the requested file extension. Schema: "
            '{"filename":"document.ext","content":"document text"}. '
            "For .xlsx or .xls, content must be a JSON array of arrays representing spreadsheet rows. "
            "For .docx, .doc, .html, .md, .markdown, .txt, and .csv, content must be a string. "
            + (PRESENTATION_CONTENT_INSTRUCTIONS + " " if extension == ".pptx" else "") +
            "Do not include explanations outside the document content.\n\n"
            f"Requested filename: {filename}\nRequested extension: {extension}\n"
            f"User request: {attachment_message(context.message, context.attachments)}\nAssistant response context: {answer}"
        )
        generated = await self._llm.generate(
            [
                {"role": "system", "content": "You create complete, accurate documents and return valid JSON only. Do not write files or run scripts; the application saves the document. " + ATTACHMENT_INSTRUCTIONS},
                {"role": "user", "content": generation_prompt},
            ],
            temperature=0.2,
            max_tokens=8192,
            **(llm_options or self._llm_call_options()),
        )
        self._is_cancelled(context.task_id)
        payload = self._parse_document_payload(generated.content)
        output_name = str(payload.get("filename") or filename)
        if Path(output_name).suffix.lower() != extension.lower():
            output_name = f"{Path(output_name).stem or Path(filename).stem}{extension}"
        service = self._artifact_service or ChatArtifactService.from_settings()
        return await asyncio.to_thread(
            service.save_document,
            user_id=context.user_id or "guest",
            session_id=context.session_id or context.task_id,
            filename=output_name,
            content=payload.get("content", ""),
        )

    @staticmethod
    def _parse_document_payload(content: str) -> dict[str, Any]:
        text = (content or "").strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        payload = json.loads(text)
        if not isinstance(payload, dict) or "content" not in payload:
            raise ValueError("Document generator returned an invalid payload")
        return payload

    async def _search_context(self, message: str, history: list[dict[str, Any]]) -> str:
        """Search public sources for time-sensitive questions before answering."""
        if any(ATTACHMENT_MARKER in str(item.get("content", "")) for item in history):
            return ""
        private_context = " ".join(
            [message] + [
                str(item.get("content", "")) for item in history[-6:]
                if item.get("role") in {"user", "assistant"}
            ]
        )
        if _PRIVATE_APP_PATTERN.search(private_context) or re.search(
            r"\b(?:email|e-mail|inbox|unread)\b"
            r"|[\w.+-]+@[\w.-]+|\u90ae\u4ef6|\u90ae\u7bb1|\u672a\u8bfb|\u6536\u4ef6\u7bb1",
            private_context, re.IGNORECASE,
        ):
            return ""
        # Public search must never receive private conversation history.
        query = message.strip()
        if (
            len(query) > _MAX_PUBLIC_SEARCH_QUERY_LENGTH
            or _PRIVATE_VALUE_PATTERN.search(query)
            or _CODE_CONTENT_PATTERN.search(query)
        ):
            return ""
        try:
            result = await self._mcp.call_tool("external_search_search_web", query=query, max_results=5)
            if not result.success:
                logger.warning("Web search returned no result: {}", result.error)
                return "Web search was attempted but returned no usable results. Do not claim current facts."
            results = (result.data or {}).get("results", [])
            if not results:
                return "Web search was attempted but returned no usable results. Do not claim current facts."
            excerpts = "\n".join(
                f"- {item.get('title', '')}: {item.get('snippet', '')} ({item.get('url', '')})"
                for item in results
            )
            return f"Web search results for: {query}\n{excerpts}"
        except CancelledException:
            raise
        except Exception as error:
            logger.warning("Web search unavailable: {}", error)
            return "Web search was unavailable. Do not claim current facts or imply a search succeeded."

    async def stream_chat(
        self,
        message: str,
        history: list[dict[str, Any]],
        web_search_enabled: bool = True,
    ) -> AsyncIterator[LLMStreamChunk]:
        """Streaming chat interface. Directly streams the LLM output."""
        await self._validate_input("chat", ChatContext(
            message=message, history=history, enable_web_search=web_search_enabled,
        ))
        web_context = await self._search_context(message, history) if web_search_enabled else ""
        system_prompt = SYSTEM_PROMPT.format(web_search_context=web_context) + self._get_skills_prompt()
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend({"role": item["role"], "content": item["content"]} for item in history)
        messages.append({"role": "user", "content": message})

        async for chunk in self._llm.generate_stream(
            messages,
            temperature=0.7,
            max_tokens=4096,
            **self._llm_call_options(),
        ):
            yield chunk

    @staticmethod
    def _detect_intent(message: str) -> str:
        """Backward-compatible string intent detection."""
        return detect_intent(message).intent
