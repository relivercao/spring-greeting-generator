"""ChatAgent package - multi-turn conversation with intent routing."""

from .agent import ChatAgent
from .intents import INTENT_KEYWORDS, SUGGESTED_AGENTS, IntentMatch, detect_intent
from .prompts import SYSTEM_PROMPT
from .types import ChatContext, ChatResult

__all__ = [
    "ChatAgent",
    "ChatContext",
    "ChatResult",
    "SYSTEM_PROMPT",
    "INTENT_KEYWORDS",
    "SUGGESTED_AGENTS",
    "IntentMatch",
    "detect_intent",
]
