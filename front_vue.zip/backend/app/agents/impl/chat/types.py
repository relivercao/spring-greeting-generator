"""Typed inputs and outputs for the conversation agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from app.agents.base import AgentContext, AgentResult


@dataclass
class ChatContext(AgentContext):
    """Conversation context"""

    message: str = ""
    history: list[dict[str, Any]] = field(default_factory=list)
    enable_rag: bool = True
    enable_web_search: bool = True
    attachments: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ChatResult(AgentResult):
    """Conversation result"""

    response: str = ""
    intent: Optional[str] = None        # chat / unittest / driver / bugfix / debug / review / build
    suggested_agent: Optional[str] = None
