"""Deterministic intent detection for routing chat messages.

Keyword matching stays deterministic and cheap: every intent lists strong
phrases (action requests) and weak keywords (topic mentions). A strong match
wins outright; otherwise the intent with the most weak hits is returned with
a reduced confidence so callers can decide whether routing is warranted.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# intent -> (strong phrases, weak keywords)
INTENT_KEYWORDS: dict[str, tuple[list[str], list[str]]] = {
    "unittest": (
        ["generate test", "generate unit test", "write test", "create test case", "add coverage"],
        ["unit test", "test coverage", "mock", "gtest", "unity test", "coverage"],
    ),
    "driver": (
        ["generate driver", "write driver", "create driver"],
        ["driver code", "peripheral driver", "hal driver", "datasheet"],
    ),
    "bugfix": (
        ["fix bug", "fix this bug", "resolve issue", "patch this"],
        ["bug fix", "patch", "regression", "off by one"],
    ),
    "debug": (
        ["analyze crash", "debug this", "why did it crash", "analyze fault"],
        ["crash", "hard fault", "debug", "core dump", "stack trace", "watchdog"],
    ),
    "review": (
        ["review pr", "review my code", "code review this"],
        ["code review", "misra", "code quality", "static analysis"],
    ),
    "build": (
        ["build project", "compile project", "clean build"],
        ["compile", "build error", "linker error", "make"],
    ),
}

# Intent -> routable agent identifier used by the chat orchestration.
SUGGESTED_AGENTS: dict[str, str] = {
    "unittest": "unittest",
    "driver": "driver",
    "bugfix": "bugfix",
    "debug": "debug",
    "review": "review",
    "build": "build",
}

_STRONG_CONFIDENCE = 1.0
_WEAK_CONFIDENCE = 0.6
_WEAK_HINT_CONFIDENCE = 0.4


@dataclass
class IntentMatch:
    """Result of one intent detection pass."""

    intent: str = "chat"
    confidence: float = 0.0
    matched_keywords: list[str] = field(default_factory=list)

    @property
    def suggested_agent(self) -> str | None:
        """The routable agent id for this intent, or None for plain chat."""
        return SUGGESTED_AGENTS.get(self.intent)


def detect_intent(message: str) -> IntentMatch:
    """Detect the routing intent of one chat message."""
    lowered = (message or "").lower()
    if not lowered.strip():
        return IntentMatch()

    weak_hits: dict[str, list[str]] = {}
    for intent, (strong, weak) in INTENT_KEYWORDS.items():
        for phrase in strong:
            if phrase in lowered:
                return IntentMatch(intent=intent, confidence=_STRONG_CONFIDENCE, matched_keywords=[phrase])
        hits = [keyword for keyword in weak if keyword in lowered]
        if hits:
            weak_hits[intent] = hits

    if not weak_hits:
        return IntentMatch()

    best_intent = max(weak_hits, key=lambda intent: len(weak_hits[intent]))
    hits = weak_hits[best_intent]
    confidence = _WEAK_CONFIDENCE if len(hits) > 1 else _WEAK_HINT_CONFIDENCE
    return IntentMatch(intent=best_intent, confidence=confidence, matched_keywords=hits)
