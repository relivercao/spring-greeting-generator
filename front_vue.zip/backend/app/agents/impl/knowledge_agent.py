"""Compatibility shim: the KnowledgeBaseAgent implementation moved to the knowledge/ package."""

from app.agents.impl.knowledge.agent import KnowledgeBaseAgent

__all__ = ["KnowledgeBaseAgent"]
