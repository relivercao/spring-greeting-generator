"""
@file __init__.py
@author caoshwen
@brief Agent implementations module.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from app.agents.impl.unittest import UnitTestAgent
from app.agents.impl.driver import DriverAgent
from app.agents.impl.build import BuildAgent
from app.agents.impl.bugfix import BugFixAgent
from app.agents.impl.debug import DebugAgent
from app.agents.impl.review import ReviewAgent
from app.agents.impl.chat import ChatAgent
from app.agents.impl.image_generation import ImageGenerationAgent
from app.agents.impl.knowledge import KnowledgeBaseAgent
from app.agents.impl.agent_generator import AgentGeneratorAgent
from app.agents.impl.cad import CadAgent

__all__ = [
    "UnitTestAgent",
    "DriverAgent",
    "BuildAgent",
    "BugFixAgent",
    "DebugAgent",
    "ReviewAgent",
    "ChatAgent",
    "KnowledgeBaseAgent",
    "ImageGenerationAgent",
    "AgentGeneratorAgent",
    "CadAgent",
]
