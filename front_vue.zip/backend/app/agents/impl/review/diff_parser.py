"""Parse unified pull-request diffs into reviewable source hunks."""

from __future__ import annotations

import re
import shlex
from pathlib import PurePosixPath, PureWindowsPath


_HUNK_HEADER = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")
_REVIEWABLE_EXTENSIONS = {".c", ".cc", ".cpp", ".h", ".hh", ".hpp", ".s", ".asm"}


def _header_path(line: str) -> str | None:
    """Extract and validate a path from a unified diff file header."""
    try:
        parts = shlex.split(line[4:], posix=True)
    except ValueError:
        return None
    if not parts or parts[0] == "/dev/null":
        return None
    path = parts[0]
    if path.startswith(("a/", "b/")):
        path = path[2:]
    posix = PurePosixPath(path.replace("\\", "/"))
    windows = PureWindowsPath(path)
    if posix.is_absolute() or windows.drive or windows.root or ".." in posix.parts:
        return None
    if posix.suffix.lower() not in _REVIEWABLE_EXTENSIONS:
        return None
    return posix.as_posix()


def parse_unified_diff(diff: str) -> tuple[dict[str, str], dict[str, set[int]], list[str]]:
    """Return reviewable hunks, added target-side lines, and collection warnings."""
    sources: dict[str, list[str]] = {}
    added_lines: dict[str, set[int]] = {}
    warnings: list[str] = []
    path: str | None = None
    hunk_active = False
    old_line = 0
    new_line = 0

    def finish_file() -> None:
        nonlocal path, hunk_active
        path = None
        hunk_active = False

    for line in diff.splitlines():
        if line.startswith("diff --git "):
            finish_file()
            continue
        if not hunk_active and line.startswith("+++ "):
            path = _header_path(line)
            if path is None and line[4:].strip() != "/dev/null":
                warnings.append("Skipped a pull-request file with an unsafe or unsupported path/type")
            continue
        match = _HUNK_HEADER.match(line)
        if match:
            hunk_active = path is not None
            if hunk_active:
                sources.setdefault(path, []).append(line)
                added_lines.setdefault(path, set())
                old_line = int(match.group(1))
                new_line = int(match.group(2))
            continue
        if not hunk_active:
            continue
        if line.startswith("\\"):
            continue
        if line.startswith(" "):
            sources[path].append(f"[context line {new_line}] {line[1:]}")
            old_line += 1
            new_line += 1
        elif line.startswith("+"):
            sources[path].append(f"[added line {new_line}] {line[1:]}")
            added_lines[path].add(new_line)
            new_line += 1
        elif line.startswith("-"):
            sources[path].append(f"[removed old line {old_line}] {line[1:]}")
            old_line += 1
        else:
            hunk_active = False

    review_sources = {
        filename: "\n".join(lines)
        for filename, lines in sources.items()
        if added_lines.get(filename)
    }
    if not review_sources:
        warnings.append("Pull request diff contained no supported firmware source additions")
    return review_sources, added_lines, warnings
