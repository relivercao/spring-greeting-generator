"""ReviewAgent - structured firmware code review orchestration."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from app.agents.base import (
    AgentConfig,
    AgentContext,
    AgentResult,
    AgentStatus,
    AgentType,
    BaseAgent,
    ValidationError,
)
from app.agents.structured_output import StructuredOutputError, parse_json_object
from app.llm.bridge import LLMBridge
from app.mcp.client import MCPClient

from .batching import build_batches
from .collection import ReviewSourceCollector
from .findings import (
    build_summary,
    calculate_score,
    deduplicate_findings,
    normalize_findings,
)
from .prompts import SYSTEM_PROMPT, build_repair_prompt, build_review_prompt
from .report import build_code_diff, build_markdown_report
from .types import VALID_SEVERITIES, ReviewContext, ReviewFinding, ReviewResult
from .validation import validate_findings


class ReviewAgent(BaseAgent):
    """Review uploaded firmware files and return normalized findings.

    Stages: collect -> partition -> review (per batch, with JSON repair) ->
    aggregate -> validate -> report.
    """

    def __init__(self, llm_bridge: LLMBridge, mcp_client: MCPClient, skill_registry=None):
        super().__init__(
            AgentConfig(agent_type=AgentType.REVIEW, timeout_seconds=600, durable_runtime=True),
            skill_registry=skill_registry,
        )
        self._llm = llm_bridge
        self._mcp = mcp_client
        self._collector = ReviewSourceCollector(mcp_client, self._is_cancelled)

    async def _validate_input(self, task: str, context: AgentContext) -> None:
        if not isinstance(context, ReviewContext):
            raise ValidationError("ReviewAgent requires ReviewContext")
        if not context.source_files and not context.source_contents and not context.pr_id and not context.git_repository_path:
            raise ValidationError("Source files, source contents, a Git repository, or a pull request is required")
        if context.review_type not in {"full", "quick", "misra", "security"}:
            raise ValidationError(f"Unsupported review type: {context.review_type}")

    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        ctx = context
        assert isinstance(ctx, ReviewContext)
        task_id = ctx.task_id

        skill_plan = await self._prepare_agent_skills(
            ctx,
            "review",
            scope="review",
            inputs={
                "review_type": ctx.review_type,
                "standards": list(ctx.standards),
                "focus": ctx.focus or "",
            },
        )

        await self._report_progress(task_id, 15, "collect", "Collecting source code")
        source_contents, collection_warnings = await self._collector.collect(ctx)
        if not source_contents:
            details = "; ".join(collection_warnings) or "No readable source code was provided"
            raise ValidationError(details)

        batches = build_batches(source_contents, unnumbered_files=set(ctx.pull_request_files))
        await self._report_progress(
            task_id,
            24,
            "partition",
            f"Prepared {len(batches)} review batch{'es' if len(batches) != 1 else ''}",
            {"batch_count": len(batches), "files": len(source_contents)},
        )
        findings: list[ReviewFinding] = []
        summaries: list[str] = []
        for index, batch in enumerate(batches):
            self._is_cancelled(task_id)
            progress = 25 + int((index / max(len(batches), 1)) * 55)
            await self._report_progress(
                task_id,
                progress,
                "review",
                f"Reviewing source batch {index + 1} of {len(batches)}",
            )
            payload = await self._review_batch(ctx, batch, skill_plan.prompt)
            self._is_cancelled(task_id)
            summaries.append(str(payload.get("summary") or "").strip())
            findings.extend(normalize_findings(payload, batch))

        await self._report_progress(task_id, 85, "aggregate", "Aggregating review findings")
        findings = deduplicate_findings(findings)
        findings, validation_warnings = validate_findings(
            findings,
            source_contents,
            reviewable_lines=ctx.pull_request_added_lines if ctx.pull_request_files else None,
        )
        counts = {
            severity: sum(1 for finding in findings if finding.severity == severity)
            for severity in VALID_SEVERITIES
        }
        score = calculate_score(counts)
        summary = build_summary(source_contents, findings, summaries, collection_warnings)
        code_diff = ctx.pull_request_diff or build_code_diff(source_contents, findings)
        report = build_markdown_report(summary, score, counts, findings, ctx, code_diff)
        result_data = {
            "summary": summary,
            "score": score,
            "counts": counts,
            "findings": [asdict(finding) for finding in findings],
            "files_reviewed": len(source_contents),
            "standards": ctx.standards,
            "review_type": ctx.review_type,
            "warnings": collection_warnings,
            "validation_warnings": validation_warnings,
            "git": ctx.git_metadata,
            "pull_request": {
                "repository": ctx.repo,
                "id": ctx.pr_id,
                "files": ctx.pull_request_files,
                "added_lines": {
                    filename: sorted(lines)
                    for filename, lines in ctx.pull_request_added_lines.items()
                },
            },
            "jira_issues": ctx.jira_issues,
            "jira_query": {
                "project": ctx.jira_project,
                "jql": ctx.jira_jql,
                "issue_keys": ctx.jira_issue_keys,
                "status": ctx.jira_status,
                "max_results": ctx.jira_max_results,
            },
            "code_diff": code_diff,
            "report_markdown": report,
        }
        return ReviewResult(
            task_id=task_id,
            status=AgentStatus.COMPLETED,
            message=f"Code review completed with {len(findings)} findings",
            data=result_data,
            findings=findings,
            summary=summary,
            score=score,
            critical_count=counts["critical"],
            major_count=counts["major"],
            minor_count=counts["minor"],
            info_count=counts["info"],
        )

    async def _review_batch(self, ctx: ReviewContext, batch: dict[str, str], skill_prompt: str = "") -> dict[str, Any]:
        self._is_cancelled(ctx.task_id)
        prompt = build_review_prompt(ctx, batch)
        if skill_prompt:
            prompt = f"{skill_prompt}\n\n{prompt}"
        response = await self._llm.generate(
            [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,
            max_tokens=12_000,
            **self._llm_call_options(),
        )
        self._is_cancelled(ctx.task_id)
        try:
            payload = parse_json_object(response.content)
            normalize_findings(payload, batch)
            return payload
        except StructuredOutputError as error:
            repaired = await self._llm.generate(
                [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": (
                        build_repair_prompt(response.content)
                        + f"\nValidation error: {error}\n"
                        + "Use only filenames from the original reviewed source.\n"
                        + prompt
                    )},
                ],
                temperature=0.0,
                max_tokens=12_000,
                **self._llm_call_options(),
            )
            self._is_cancelled(ctx.task_id)
            payload = parse_json_object(repaired.content)
            normalize_findings(payload, batch)
            return payload
