"""Deterministic post-validation for normalized review findings."""

from __future__ import annotations

import re
from typing import Optional

from .types import ReviewFinding

# Matches a review-batch line prefix such as "    12: code".
_NUMBERED_LINE = re.compile(r"^\s*(\d+):")
_DIFF_LINE = re.compile(r"^\[(?:added|context) line (\d+)\]")


def estimate_line_count(content: str) -> Optional[int]:
    """Estimate the highest source line number inside one batched content.

    Numbered batches report their highest prefix; raw texts (such as diffs)
    fall back to the physical line count.
    """
    highest = 0
    saw_numbered = False
    diff_lines = [int(match.group(1)) for line in content.splitlines() if (match := _DIFF_LINE.match(line))]
    if diff_lines:
        return max(diff_lines)
    for line in content.splitlines():
        match = _NUMBERED_LINE.match(line)
        if match:
            saw_numbered = True
            highest = max(highest, int(match.group(1)))
    if saw_numbered:
        return highest
    return len(content.splitlines())


def validate_findings(
    findings: list[ReviewFinding],
    source_contents: dict[str, str],
    reviewable_lines: dict[str, set[int]] | None = None,
) -> tuple[list[ReviewFinding], list[str]]:
    """Clamp inconsistent line ranges and report validation warnings.

    Follows the deterministic validation style of the driver agent: findings
    are corrected in place where the intent is unambiguous (line ranges beyond
    the end of the file, or end_line before line) and a warning is returned so
    the report can disclose every adjustment.
    """
    warnings: list[str] = []
    validated: list[ReviewFinding] = []
    for finding in findings:
        if finding.file not in source_contents:
            warnings.append(f"{finding.file}: finding did not target a reviewed file; dropped")
            continue
        if reviewable_lines is not None and finding.file in reviewable_lines and finding.line not in reviewable_lines[finding.file]:
            warnings.append(f"{finding.file}: finding did not target an added pull-request line; dropped")
            continue
        limit = estimate_line_count(source_contents.get(finding.file, ""))
        if finding.line is not None and limit and finding.line > limit:
            warnings.append(
                f"{finding.file}: finding line {finding.line} exceeds the file length ({limit}); clamped"
            )
            finding.line = limit
        if finding.end_line is not None and limit and finding.end_line > limit:
            warnings.append(
                f"{finding.file}: finding end_line {finding.end_line} exceeds the file length ({limit}); clamped"
            )
            finding.end_line = limit
        if finding.line is not None and finding.end_line is not None and finding.end_line < finding.line:
            warnings.append(
                f"{finding.file}: finding end_line {finding.end_line} is before line {finding.line}; swapped"
            )
            finding.line, finding.end_line = finding.end_line, finding.line
        if reviewable_lines is not None and finding.file in reviewable_lines and finding.line not in reviewable_lines[finding.file]:
            warnings.append(f"{finding.file}: finding did not target an added pull-request line; dropped")
            continue
        validated.append(finding)
    return validated, warnings
