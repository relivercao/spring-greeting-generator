"""Firmware code review agent package.

Public surface mirrors the former monolithic `review_agent.py` module:
`ReviewAgent` plus its typed context, finding, and result dataclasses, along
with the pure helpers (batching, findings normalization, report rendering,
deterministic validation) that back the agent stages.
"""

from .agent import ReviewAgent
from .batching import build_batches, number_source_lines
from .collection import ReviewSourceCollector
from .findings import (
    build_summary,
    calculate_score,
    canonicalize_severity,
    deduplicate_findings,
    normalize_findings,
)
from .prompts import SYSTEM_PROMPT, build_repair_prompt, build_review_prompt
from .report import build_code_diff, build_markdown_report
from .types import (
    MAX_BATCH_CHARS,
    VALID_SEVERITIES,
    ReviewContext,
    ReviewFinding,
    ReviewResult,
)
from .validation import estimate_line_count, validate_findings

__all__ = [
    "ReviewAgent",
    "ReviewSourceCollector",
    "ReviewContext",
    "ReviewFinding",
    "ReviewResult",
    "MAX_BATCH_CHARS",
    "VALID_SEVERITIES",
    "SYSTEM_PROMPT",
    "build_batches",
    "number_source_lines",
    "normalize_findings",
    "deduplicate_findings",
    "calculate_score",
    "build_summary",
    "canonicalize_severity",
    "build_review_prompt",
    "build_repair_prompt",
    "build_markdown_report",
    "build_code_diff",
    "validate_findings",
    "estimate_line_count",
]
