"""Markdown report and annotated diff rendering for review results."""

from __future__ import annotations

import difflib

from .types import ReviewContext, ReviewFinding


def build_markdown_report(
    summary: str,
    score: float,
    counts: dict[str, int],
    findings: list[ReviewFinding],
    ctx: ReviewContext,
    code_diff: str = "",
) -> str:
    """Render the full review report in Markdown."""
    lines = [
        "# Firmware Code Review",
        "",
        summary,
        "",
        f"- Quality score: {score}/100",
        f"- Review type: {ctx.review_type}",
        f"- Standards: {', '.join(ctx.standards)}",
        f"- Critical: {counts['critical']}",
        f"- Major: {counts['major']}",
        f"- Minor: {counts['minor']}",
        f"- Info: {counts['info']}",
        "",
        "## Findings",
        "",
    ]
    if code_diff:
        lines.extend(["## Code Diff", "", "~~~diff", code_diff.rstrip(), "~~~", ""])
    if ctx.git_metadata:
        lines.extend(["## Git Source", ""])
        lines.extend(
            [
                f"- Repository: `{ctx.git_metadata.get('repository_path', 'Unknown')}`",
                f"- Base: `{ctx.git_metadata.get('base_ref', ctx.git_base_ref)}`",
                f"- Target: `{ctx.git_metadata.get('target_ref', ctx.git_target_ref)}`",
                f"- Include untracked: `{ctx.git_metadata.get('include_untracked', str(ctx.git_include_untracked).lower())}`",
                "",
            ]
        )
    if ctx.pr_id and ctx.repo:
        lines.extend([
            "## Bitbucket Pull Request",
            "",
            f"- Repository: `{ctx.repo}`",
            f"- Pull request: `{ctx.pr_id}`",
            "",
        ])
    if ctx.jira_issues:
        lines.extend(["## Jira Bug Context", ""])
        for issue in ctx.jira_issues:
            key = str(issue.get("key") or issue.get("issue_key") or "Unknown")
            summary_text = str(issue.get("summary") or "").strip()
            status = str(issue.get("status") or "").strip()
            suffix = f" ({status})" if status else ""
            lines.append(f"- {key}{suffix}: {summary_text}")
        lines.append("")
    if not findings:
        lines.append("No actionable findings were reported.")
    for index, finding in enumerate(findings, start=1):
        location = finding.file
        if finding.line:
            location += f":{finding.line}"
        lines.extend(
            [
                f"### {index}. [{finding.severity.upper()}] {finding.title}",
                "",
                f"- Location: `{location}`",
                f"- Rule: {finding.rule or 'Not specified'}",
                f"- Confidence: {finding.confidence:.2f}",
                "",
                finding.description,
                "",
                f"Suggested fix: {finding.suggestion or 'Review and correct the affected logic.'}",
                "",
            ]
        )
    return "\n".join(lines).strip() + "\n"


def build_code_diff(
    source_contents: dict[str, str],
    findings: list[ReviewFinding],
) -> str:
    """Build a reviewable unified diff with finding annotations."""
    blocks: list[str] = []
    findings_by_file: dict[str, list[ReviewFinding]] = {}
    for finding in findings:
        findings_by_file.setdefault(finding.file, []).append(finding)
    for filename, content in source_contents.items():
        if filename.lower().endswith((".diff", ".patch")):
            blocks.append(content.rstrip())
            continue
        lines = content.splitlines()
        diff_lines = list(
            difflib.unified_diff(
                [],
                lines,
                fromfile="/dev/null",
                tofile=f"b/{filename}",
                lineterm="",
            )
        )
        annotations: dict[int, list[str]] = {}
        for finding in findings_by_file.get(filename, []):
            if finding.line:
                annotations.setdefault(finding.line, []).append(
                    f"+// REVIEW [{finding.severity}] {finding.title}: {finding.description}"
                )
        if annotations:
            annotated: list[str] = []
            for index, line in enumerate(lines, start=1):
                annotated.append(f"+{line}")
                annotated.extend(annotations.get(index, []))
            diff_lines = [
                "--- /dev/null",
                f"+++ b/{filename}",
                f"@@ -0,0 +1,{len(annotated)} @@",
                *annotated,
            ]
        blocks.append("\n".join(diff_lines).strip())
    return "\n\n".join(block for block in blocks if block).strip() + ("\n" if blocks else "")
