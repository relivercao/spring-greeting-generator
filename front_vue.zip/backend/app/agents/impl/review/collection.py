"""Source collection for the code review agent (Git, Jira, PR, remote files)."""

from __future__ import annotations

from typing import Any, Callable

from loguru import logger

from app.agents.base import CancelledException

from .diff_parser import parse_unified_diff
from .types import ReviewContext


class ReviewSourceCollector:
    """Collect every readable source text requested by a review context.

    Collection order: inline contents, local Git changes, Jira bug context,
    pull-request diff, then remote repository files. The context is updated in
    place with the fetched Git metadata and Jira issues so downstream stages
    can surface them in the report.
    """

    def __init__(self, mcp_client: Any, check_cancelled: Callable[[str], Any] | None = None):
        self._mcp = mcp_client
        self._check_cancelled = check_cancelled

    async def _call_tool(self, ctx: ReviewContext, name: str, **kwargs: Any) -> Any:
        """Stop before another source read and after an interrupted read."""
        if self._check_cancelled:
            self._check_cancelled(ctx.task_id)
        result = await self._mcp.call_tool(name, **kwargs)
        if self._check_cancelled:
            self._check_cancelled(ctx.task_id)
        return result

    async def collect(self, ctx: ReviewContext) -> tuple[dict[str, str], list[str]]:
        """Return the collected sources plus human-readable warnings."""
        source_contents = {
            name: content
            for name, content in ctx.source_contents.items()
            if name and content.strip()
        }
        warnings: list[str] = []

        await self._collect_git_context(ctx, source_contents, warnings)
        await self._collect_jira_context(ctx, warnings)
        await self._collect_pull_request(ctx, source_contents, warnings)
        await self._collect_remote_files(ctx, source_contents, warnings)
        return source_contents, warnings

    async def _collect_git_context(
        self,
        ctx: ReviewContext,
        source_contents: dict[str, str],
        warnings: list[str],
    ) -> None:
        """Read local Git changes through the registered Git MCP server."""
        if not ctx.git_repository_path:
            return
        try:
            result = await self._call_tool(
                ctx,
                "git_get_diff",
                repository_path=ctx.git_repository_path,
                base_ref=ctx.git_base_ref,
                target_ref=ctx.git_target_ref,
                include_untracked=ctx.git_include_untracked,
            )
            if result.success and isinstance(result.data, dict):
                sources = result.data.get("sources") or {}
                if isinstance(sources, dict):
                    source_contents.update(
                        {str(name): str(content) for name, content in sources.items() if str(content).strip()}
                    )
                metadata = result.data.get("metadata")
                if isinstance(metadata, dict):
                    ctx.git_metadata = metadata
                if not sources:
                    warnings.append("Git diff did not return readable changes")
            else:
                warnings.append(result.error or "Git diff did not return readable changes")
        except CancelledException:
            raise
        except Exception as exc:
            logger.warning(f"Failed to collect local Git diff: {exc}")
            warnings.append(f"Could not collect local Git diff: {exc}")

    async def _collect_jira_context(self, ctx: ReviewContext, warnings: list[str]) -> None:
        """Fetch configured Jira bugs through the authenticated Jira MCP server."""
        if not (ctx.jira_project or ctx.jira_jql or ctx.jira_issue_keys):
            return

        issues: list[dict[str, Any]] = []
        issue_keys = [str(key).strip().upper() for key in ctx.jira_issue_keys if str(key).strip()]
        for issue_key in issue_keys[:100]:
            try:
                result = await self._call_tool(ctx, "jira_get_issue", issue_key=issue_key)
                if result.success and isinstance(result.data, dict):
                    issues.append(dict(result.data))
                else:
                    warnings.append(f"Could not fetch Jira issue {issue_key}")
            except CancelledException:
                raise
            except Exception as exc:
                logger.warning(f"Failed to fetch Jira issue {issue_key}: {exc}")
                warnings.append(f"Could not fetch Jira issue {issue_key}: {exc}")

        if ctx.jira_jql:
            await self._collect_jira_jql(ctx, issues, warnings)
        elif ctx.jira_project:
            await self._collect_jira_project(ctx, issues, warnings)

        unique: dict[str, dict[str, Any]] = {}
        for issue in issues:
            key = str(issue.get("key") or issue.get("issue_key") or "").strip()
            if key:
                unique[key] = issue
        ctx.jira_issues = list(unique.values())[:100]

    async def _collect_jira_jql(
        self,
        ctx: ReviewContext,
        issues: list[dict[str, Any]],
        warnings: list[str],
    ) -> None:
        query = ctx.jira_jql.strip()
        try:
            result = await self._call_tool(
                ctx,
                "jira_search",
                jql=query,
                max_results=max(1, min(int(ctx.jira_max_results), 100)),
                fields=["summary", "description", "status", "priority", "assignee", "created", "updated"],
            )
            if result.success and isinstance(result.data, dict):
                issues.extend(item for item in result.data.get("issues", []) if isinstance(item, dict))
            else:
                warnings.append("Jira JQL search did not return issues")
        except CancelledException:
            raise
        except Exception as exc:
            logger.warning(f"Failed to search Jira with JQL: {exc}")
            warnings.append(f"Could not search Jira with JQL: {exc}")

    async def _collect_jira_project(
        self,
        ctx: ReviewContext,
        issues: list[dict[str, Any]],
        warnings: list[str],
    ) -> None:
        try:
            result = await self._call_tool(
                ctx,
                "jira_get_bugs",
                project=ctx.jira_project.strip(),
                status=(ctx.jira_status or "").strip(),
                max_results=max(1, min(int(ctx.jira_max_results), 100)),
            )
            if result.success and isinstance(result.data, dict):
                issues.extend(item for item in result.data.get("issues", []) if isinstance(item, dict))
            else:
                warnings.append(f"Jira project {ctx.jira_project} did not return bugs")
        except CancelledException:
            raise
        except Exception as exc:
            logger.warning(f"Failed to fetch Jira bugs for {ctx.jira_project}: {exc}")
            warnings.append(f"Could not fetch Jira bugs for {ctx.jira_project}: {exc}")

    async def _collect_pull_request(
        self,
        ctx: ReviewContext,
        source_contents: dict[str, str],
        warnings: list[str],
    ) -> None:
        if not (ctx.pr_id and ctx.repo):
            return
        try:
            diff_result = await self._call_tool(ctx, "bb_get_diff", repo=ctx.repo, pr_id=ctx.pr_id)
            diff = diff_result.data.get("diff") if diff_result.success and isinstance(diff_result.data, dict) else ""
            if diff:
                ctx.pull_request_diff = str(diff)
                sources, added_lines, parse_warnings = parse_unified_diff(ctx.pull_request_diff)
                source_contents.update(sources)
                ctx.pull_request_files = list(sources)
                ctx.pull_request_added_lines = added_lines
                warnings.extend(parse_warnings)
            else:
                warnings.append(f"Pull request {ctx.pr_id} did not return a readable diff")
        except CancelledException:
            raise
        except Exception as exc:
            logger.warning(f"Failed to fetch pull request {ctx.pr_id}: {exc}")
            warnings.append(f"Could not fetch pull request {ctx.pr_id}: {exc}")

    async def _collect_remote_files(
        self,
        ctx: ReviewContext,
        source_contents: dict[str, str],
        warnings: list[str],
    ) -> None:
        for file_path in ctx.source_files:
            if file_path in source_contents:
                continue
            if not ctx.repo:
                warnings.append(f"Skipped remote file without repository configuration: {file_path}")
                continue
            try:
                result = await self._call_tool(ctx, "bb_get_file", repo=ctx.repo, path=file_path)
                if result.success and result.data.get("content"):
                    source_contents[file_path] = result.data["content"]
                else:
                    warnings.append(f"Could not read remote file: {file_path}")
            except CancelledException:
                raise
            except Exception as exc:
                logger.warning(f"Failed to fetch remote file {file_path}: {exc}")
                warnings.append(f"Could not read remote file: {file_path}: {exc}")
