"""Typed inputs and outputs for the firmware code review agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from app.agents.base import AgentContext, AgentResult

# Maximum characters of numbered source text sent to the LLM per batch.
MAX_BATCH_CHARS = 72_000

# Canonical severity levels after alias mapping.
VALID_SEVERITIES = {"critical", "major", "minor", "info"}

# Severity aliases emitted by models mapped onto the canonical levels.
_SEVERITY_ALIASES = {
    "blocker": "critical",
    "high": "major",
    "medium": "minor",
    "low": "info",
    "warning": "minor",
}


@dataclass
class ReviewContext(AgentContext):
    """Code review inputs."""

    source_files: list[str] = field(default_factory=list)
    source_contents: dict[str, str] = field(default_factory=dict)
    pr_id: Optional[int] = None
    repo: Optional[str] = None
    pull_request_diff: str = ""
    pull_request_files: list[str] = field(default_factory=list)
    pull_request_added_lines: dict[str, set[int]] = field(default_factory=dict)
    review_type: str = "full"
    standards: list[str] = field(default_factory=lambda: ["MISRA-C:2012"])
    focus: Optional[str] = None
    require_approval: bool = False
    approval_channels: list[str] = field(default_factory=list)
    approval_recipients: list[str] = field(default_factory=list)
    jira_project: Optional[str] = None
    jira_jql: Optional[str] = None
    jira_issue_keys: list[str] = field(default_factory=list)
    jira_status: Optional[str] = None
    jira_max_results: int = 20
    jira_issues: list[dict[str, Any]] = field(default_factory=list)
    git_repository_path: Optional[str] = None
    git_base_ref: str = "HEAD~1"
    git_target_ref: str = "WORKTREE"
    git_include_untracked: bool = True
    git_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ReviewFinding:
    """One normalized review finding."""

    severity: str
    file: str
    line: Optional[int] = None
    end_line: Optional[int] = None
    title: str = ""
    rule: Optional[str] = None
    description: str = ""
    suggestion: str = ""
    confidence: float = 0.0


@dataclass
class ReviewResult(AgentResult):
    """Structured code review result."""

    findings: list[ReviewFinding] = field(default_factory=list)
    summary: str = ""
    score: float = 0.0
    critical_count: int = 0
    major_count: int = 0
    minor_count: int = 0
    info_count: int = 0


def canonicalize_severity(raw: Any) -> str:
    """Map a model-provided severity string onto the canonical levels."""
    severity = str(raw or "minor").strip().lower()
    severity = _SEVERITY_ALIASES.get(severity, severity)
    if severity not in VALID_SEVERITIES:
        severity = "minor"
    return severity
