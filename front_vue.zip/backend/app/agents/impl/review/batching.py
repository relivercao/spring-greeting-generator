"""Partition review sources into numbered, size-bounded LLM batches."""

from __future__ import annotations

import re

from .types import MAX_BATCH_CHARS


def number_source_lines(content: str) -> str:
    """Prefix every source line with its 1-based line number."""
    return "\n".join(f"{index:6d}: {line}" for index, line in enumerate(content.splitlines(), start=1))


def _line_fragments(line: str, number: int, unnumbered: bool, budget: int) -> list[str]:
    """Split oversized physical lines without changing their source attribution."""
    prefix = "" if unnumbered else f"{number:6d}: "
    if unnumbered:
        match = re.match(r"(\[(?:added|context|removed old) line \d+\] )(.*)", line)
        if match:
            prefix, line = match.groups()
    width = budget - len(prefix) - 1
    if width < 1:
        raise ValueError("Review source filename leaves no room within the batch budget")
    return [prefix + line[start:start + width] for start in range(0, len(line), width)] or [prefix]


def build_batches(
    source_contents: dict[str, str], *, unnumbered_files: set[str] | None = None
) -> list[dict[str, str]]:
    """Split sources into batches that respect the per-prompt character budget.

    Each file is first split into numbered chunks no larger than the budget,
    then chunks are packed together into batches while staying under it.
    """
    units: list[tuple[str, str]] = []
    unnumbered_files = unnumbered_files or set()
    for filename, content in source_contents.items():
        content_budget = MAX_BATCH_CHARS - len(filename) - 32
        lines = content.splitlines()
        current: list[str] = []
        current_size = 0
        for line_number, line in enumerate(lines, start=1):
            for numbered in _line_fragments(line, line_number, filename in unnumbered_files, content_budget):
                if current and current_size + len(numbered) + 1 > content_budget:
                    units.append((filename, "\n".join(current)))
                    current = []
                    current_size = 0
                current.append(numbered)
                current_size += len(numbered) + 1
        if current:
            units.append((filename, "\n".join(current)))

    batches: list[dict[str, str]] = []
    current_batch: dict[str, str] = {}
    current_size = 0
    for filename, content in units:
        unit_size = len(filename) + len(content) + 32
        if current_batch and current_size + unit_size > MAX_BATCH_CHARS:
            batches.append(current_batch)
            current_batch = {}
            current_size = 0
        key = filename
        if key in current_batch:
            current_batch[key] += "\n" + content
        else:
            current_batch[key] = content
        current_size += unit_size
    if current_batch:
        batches.append(current_batch)
    return batches
