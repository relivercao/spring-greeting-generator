"""Normalize, deduplicate, score, and summarize review findings."""

from __future__ import annotations

from typing import Any, Optional

from app.agents.structured_output import StructuredOutputError

from .types import ReviewFinding, canonicalize_severity

# Severity display order used when sorting the final findings list.
SEVERITY_ORDER = {"critical": 0, "major": 1, "minor": 2, "info": 3}

_DEFAULT_CONFIDENCE = 0.75


def normalize_findings(payload: dict[str, Any], batch: dict[str, str]) -> list[ReviewFinding]:
    """Convert one LLM review payload into validated finding objects."""
    raw_findings = payload.get("findings")
    if not isinstance(raw_findings, list):
        raise StructuredOutputError("The review JSON must contain a findings array")
    default_file = next(iter(batch)) if len(batch) == 1 else ""
    normalized: list[ReviewFinding] = []
    for item in raw_findings:
        if not isinstance(item, dict):
            continue
        description = str(item.get("description") or "").strip()
        if not description:
            continue
        severity = canonicalize_severity(item.get("severity"))
        filename = str(item.get("file") or default_file).strip()
        if filename not in batch:
            raise StructuredOutputError("Every finding must name a file from the reviewed batch")
        line = optional_positive_int(item.get("line"))
        end_line = optional_positive_int(item.get("end_line")) or line
        try:
            confidence = max(0.0, min(float(item.get("confidence", _DEFAULT_CONFIDENCE)), 1.0))
        except (TypeError, ValueError):
            confidence = _DEFAULT_CONFIDENCE
        normalized.append(
            ReviewFinding(
                severity=severity,
                file=filename,
                line=line,
                end_line=end_line,
                title=str(item.get("title") or description[:80]).strip(),
                rule=str(item.get("rule") or "").strip() or None,
                description=description,
                suggestion=str(item.get("suggestion") or "").strip(),
                confidence=confidence,
            )
        )
    return normalized


def deduplicate_findings(findings: list[ReviewFinding]) -> list[ReviewFinding]:
    """Drop duplicate findings and sort by severity, file, then line."""
    unique: dict[tuple[str, str, Optional[int], str], ReviewFinding] = {}
    for finding in findings:
        key = (
            finding.severity,
            finding.file,
            finding.line,
            " ".join(finding.description.lower().split()),
        )
        existing = unique.get(key)
        if existing is None or finding.confidence > existing.confidence:
            unique[key] = finding
    return sorted(
        unique.values(),
        key=lambda finding: (
            SEVERITY_ORDER[finding.severity],
            finding.file.lower(),
            finding.line or 0,
        ),
    )


def calculate_score(counts: dict[str, int]) -> float:
    """Compute a 0-100 quality score from the severity counts."""
    penalty = (
        counts["critical"] * 25
        + counts["major"] * 10
        + counts["minor"] * 3
        + counts["info"] * 0.5
    )
    return round(max(0.0, 100.0 - penalty), 1)


def build_summary(
    source_contents: dict[str, str],
    findings: list[ReviewFinding],
    batch_summaries: list[str],
    warnings: list[str],
) -> str:
    """Build the one-paragraph review summary."""
    if findings:
        lead = f"Reviewed {len(source_contents)} files and identified {len(findings)} actionable findings."
    else:
        lead = f"Reviewed {len(source_contents)} files and found no actionable defects in the supplied code."
    details = " ".join(summary for summary in batch_summaries if summary)
    warning_text = f" Collection warnings: {'; '.join(warnings)}" if warnings else ""
    return " ".join(part for part in (lead, details, warning_text) if part).strip()


def optional_positive_int(value: Any) -> Optional[int]:
    """Parse a positive integer, returning None for anything else."""
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None
