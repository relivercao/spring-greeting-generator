"""
@file __init__.py
@author caoshwen
@brief Agent execution layer module initialization.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
