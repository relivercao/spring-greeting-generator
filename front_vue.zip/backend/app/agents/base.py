"""
@file base.py
@author caoshwen
@brief BaseAgent abstract class, providing unified execution lifecycle.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from abc import ABC, abstractmethod
import asyncio
from collections import deque
from contextlib import suppress
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncIterator, Callable, Optional, TYPE_CHECKING

from app.core.task_context import (
    get_current_task_id,
    reset_current_task_id,
    set_current_task_id,
)

if TYPE_CHECKING:
    from app.skills.registry import SkillRegistry
import uuid


class AgentStatus(str, Enum):
    """Agent task status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentType(str, Enum):
    """Agent type enumeration"""
    UNITTEST = "unittest"
    DRIVER = "driver"
    BUILD = "build"
    BUGFIX = "bugfix"
    DEBUG = "debug"
    REVIEW = "review"
    CHAT = "chat"
    KNOWLEDGE = "knowledge"
    IMAGE_GENERATION = "image_generation"
    AGENT_GENERATOR = "agent_generator"
    CAD = "cad"


@dataclass
class AgentConfig:
    """Agent configuration"""
    agent_type: AgentType
    max_retries: int = 3
    timeout_seconds: int = 300
    enable_streaming: bool = True
    durable_runtime: bool = False


@dataclass
class AgentContext:
    """Agent execution context - extended by Agent subclasses"""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    project_root: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ProgressUpdate:
    """Progress update message"""
    task_id: str
    progress: int  # 0-100
    stage: str
    message: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    details: Optional[dict[str, Any]] = None


@dataclass
class AgentResult:
    """Agent execution result - extended by Agent subclasses"""
    task_id: str
    status: AgentStatus
    message: str
    data: Optional[dict[str, Any]] = None
    errors: list[str] = field(default_factory=list)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: Optional[float] = None


class BaseAgent(ABC):
    """
    Unified abstract base class for Agent execution layer.

    All business Agents must inherit from this class and implement the following abstract methods:
    - _process_task(): Core task processing logic
    - _validate_input(): Input validation

    Base class provides:
    - execute(): Complete execution flow (validate -> process -> result)
    - stream_execute(): Streaming execution (with progress push)
    - get_status(): Status query
    - cancel(): Task cancellation

    Design principles:
    - Public methods: no prefix (execute, get_status, cancel)
    - Protected methods: single underscore (_process_task, _validate_input)
    - Private methods: double underscore (__parse_output)
    - Callback methods: on_ prefix (on_progress, on_complete)
    """

    def __init__(self, config: AgentConfig, skill_registry: Optional["SkillRegistry"] = None):
        self._config = config
        self._tasks: dict[str, AgentResult] = {}
        self._progress_callbacks: dict[str, list[Callable]] = {}
        self._cancelled: set[str] = set()
        self._execution_tasks: dict[str, asyncio.Task] = {}
        self._skill_registry = skill_registry
        from app.core.config import resolve_agent_llm_selection
        self._llm_selection = resolve_agent_llm_selection(config.agent_type.value)

    @property
    def agent_type(self) -> AgentType:
        return self._config.agent_type

    def _llm_call_options(self) -> dict[str, Any]:
        """Return the configured runtime options for this Agent's LLM calls."""
        options = {
            "provider": self._llm_selection.runtime_provider,
            "model": self._llm_selection.model,
            "upstream_provider": self._llm_selection.provider,
        }
        task_id = get_current_task_id()
        if task_id:
            options["task_id"] = task_id
        if self._config.durable_runtime:
            options["unbounded_runtime"] = True
        return options

    # ========== Public Interfaces ==========

    async def execute(self, task: str, context: AgentContext) -> AgentResult:
        """
        Execute complete task workflow.

        Args:
            task: Task description
            context: Execution context

        Returns:
            AgentResult: Execution result
        """
        task_id = context.task_id
        started_at = datetime.now(timezone.utc)

        # Initialize task status
        result = AgentResult(
            task_id=task_id,
            status=AgentStatus.RUNNING,
            message="Task is running",
            started_at=started_at,
        )
        self._tasks[task_id] = result
        execution_task = asyncio.current_task()
        if execution_task is not None:
            self._execution_tasks[task_id] = execution_task
        task_context_token = set_current_task_id(task_id)
        from app.core.usage_context import usage_context
        usage_token = usage_context.set({
            "agent_name": self.agent_type.value, "user_id": context.user_id,
            "session_id": context.session_id, "workflow_id": task_id,
        })

        try:
            # Input validation
            await self._validate_input(task, context)

            # Core processing
            result = await self._process_task(task, context)
            result.task_id = task_id
            result.started_at = started_at
            result.completed_at = datetime.now(timezone.utc)
            result.duration_ms = (
                result.completed_at - started_at
            ).total_seconds() * 1000

            if result.status in {AgentStatus.PENDING, AgentStatus.RUNNING}:
                result.status = AgentStatus.COMPLETED

        except ValidationError as e:
            result.status = AgentStatus.FAILED
            result.message = f"Input validation failed: {e}"
            result.errors = [str(e)]
            result.completed_at = datetime.now(timezone.utc)

        except CancelledException:
            result.status = AgentStatus.CANCELLED
            result.message = "Task cancelled"
            result.completed_at = datetime.now(timezone.utc)

        except asyncio.CancelledError:
            result.status = AgentStatus.CANCELLED
            result.message = "Task cancelled"
            result.completed_at = datetime.now(timezone.utc)

        except Exception as e:
            result = await self._handle_error(task_id, e)
            result.started_at = started_at
            result.completed_at = datetime.now(timezone.utc)

        finally:
            reset_current_task_id(task_context_token)
            usage_context.reset(usage_token)

        if result.completed_at is None:
            result.completed_at = datetime.now(timezone.utc)
        result.started_at = result.started_at or started_at
        result.duration_ms = (
            result.completed_at - result.started_at
        ).total_seconds() * 1000
        self._tasks[task_id] = result
        if self._execution_tasks.get(task_id) is execution_task:
            self._execution_tasks.pop(task_id, None)
        self._cancelled.discard(task_id)
        skill_traces = context.metadata.get("skill_runtime", [])
        if skill_traces:
            result.data = {**(result.data or {}), "skill_runtime": skill_traces}
        from app.utils.claude_cli_monitor import cleanup_task_cli
        cleanup_task_cli(
            task_id,
            preserve_cancel_flag=result.status == AgentStatus.CANCELLED,
        )
        return result

    async def stream_execute(
        self,
        task: str,
        context: AgentContext,
    ) -> AsyncIterator[ProgressUpdate]:
        """
        Streaming execution with incremental progress updates.

        Args:
            task: Task description
            context: Execution context

        Yields:
            ProgressUpdate: Progress update messages
        """
        task_id = context.task_id
        progress_queue: deque[ProgressUpdate] = deque()

        # Register progress callback
        def on_progress(update: ProgressUpdate):
            progress_queue.append(update)

        self._progress_callbacks.setdefault(task_id, []).append(on_progress)

        # Start execution
        import asyncio

        exec_task = asyncio.create_task(self.execute(task, context))

        try:
            while not exec_task.done() or progress_queue:
                while progress_queue:
                    yield progress_queue.popleft()
                if not exec_task.done():
                    await asyncio.sleep(0.05)

            result = await exec_task
            terminal_status = result.status
            yield ProgressUpdate(
                task_id=task_id,
                progress=100 if terminal_status == AgentStatus.COMPLETED else -1,
                stage=terminal_status.value,
                message=result.message,
            )
        finally:
            callbacks = self._progress_callbacks.get(task_id, [])
            with suppress(ValueError):
                callbacks.remove(on_progress)
            if not callbacks:
                self._progress_callbacks.pop(task_id, None)
            if not exec_task.done():
                exec_task.cancel()
            with suppress(asyncio.CancelledError):
                await exec_task

    def get_status(self, task_id: str) -> Optional[AgentResult]:
        """Query task status"""
        return self._tasks.get(task_id)

    async def cancel(self, task_id: str) -> bool:
        """
        Cancel a task.

        Returns:
            bool: Whether cancellation was successful
        """
        if task_id in self._tasks:
            task = self._tasks[task_id]
            if task.status == AgentStatus.RUNNING:
                self._cancelled.add(task_id)
                task.status = AgentStatus.CANCELLED
                task.message = "Task cancelled"
                task.completed_at = datetime.now(timezone.utc)
                if task.started_at:
                    task.duration_ms = (
                        task.completed_at - task.started_at
                    ).total_seconds() * 1000
                execution_task = self._execution_tasks.get(task_id)
                from app.utils.claude_cli_monitor import kill_cli_by_task_id
                kill_cli_by_task_id(task_id)
                current_task = asyncio.current_task()
                if execution_task and execution_task is not current_task:
                    execution_task.cancel()
                return True
        return False

    # ========== Protected Interfaces (subclasses must implement) ==========

    @abstractmethod
    async def _process_task(self, task: str, context: AgentContext) -> AgentResult:
        """
        Core task processing logic. Subclasses must implement.

        Args:
            task: Task description
            context: Execution context

        Returns:
            AgentResult: Processing result
        """
        ...

    @abstractmethod
    async def _validate_input(self, task: str, context: AgentContext) -> None:
        """
        Input validation. Throw ValidationError if validation fails.

        Args:
            task: Task description
            context: Execution context

        Raises:
            ValidationError: Input is invalid
        """
        ...

    # ========== Protected Interfaces (optional override) ==========

    async def _report_progress(
        self,
        task_id: str,
        progress: int,
        stage: str,
        message: str,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        """
        Report task progress. Called from within _process_task.

        Args:
            task_id: Task ID
            progress: Progress percentage (0-100)
            stage: Current stage
            message: Progress message
            details: Additional details
        """
        update = ProgressUpdate(
            task_id=task_id,
            progress=progress,
            stage=stage,
            message=message,
            details=details,
        )
        for callback in self._progress_callbacks.get(task_id, []):
            callback(update)

    async def _handle_error(self, task_id: str, error: Exception) -> AgentResult:
        """
        Error handling. Can be overridden for custom error handling logic.

        Args:
            task_id: Task ID
            error: Exception object

        Returns:
            AgentResult: Error result
        """
        error_message = str(error).strip() or error.__class__.__name__
        return AgentResult(
            task_id=task_id,
            status=AgentStatus.FAILED,
            message=f"Task execution failed: {error_message}",
            errors=[error_message],
        )

    def _is_cancelled(self, task_id: str) -> bool:
        """Check if task has been cancelled"""
        if task_id in self._cancelled:
            raise CancelledException(f"Task {task_id} cancelled")
        return False

    def _get_skills_prompt(self) -> str:
        """
        Get formatted skills prompt fragment for current Agent.

        Returns formatted skills section text that can be directly
        appended to system prompt. Returns empty string if there is
        no skill_registry or no available skills.
        """
        if not self._skill_registry:
            return ""
        from app.skills.prompt_builder import SkillPromptBuilder
        skills = self._skill_registry.get_skills_for_agent(self.agent_type)
        if not skills:
            return ""
        builder = SkillPromptBuilder()
        snapshot = builder.build_skills_section(skills)
        return snapshot.prompt

    async def _prepare_stage_skills(
        self, context: AgentContext, stage: str, *, layer: str = "",
        large_file_mode: bool = False, scope: str = "", inputs: dict | None = None,
        capabilities: dict | None = None,
    ):
        """Prepare a task-scoped skill plan without changing workflow gate states."""
        from copy import deepcopy
        from app.skills.runtime import SkillRuntime, SkillStageContext

        self._is_cancelled(context.task_id)
        traces = context.metadata.setdefault("skill_runtime", [])
        previous = next((item for item in traces if item["stage"] == stage and item["scope"] == scope), None)
        trace = {"stage": stage, "scope": scope, "status": "preparing",
                 "attempt": (previous or {}).get("attempt", 0) + 1}
        if previous is not None:
            traces.remove(previous)
        traces.append(trace)
        await self._report_progress(
            context.task_id, 0, "skill_runtime", f"Preparing skills ({stage})",
            details={"skill_runtime": deepcopy(traces)},
        )
        try:
            return await SkillRuntime(self._skill_registry, capabilities).prepare(
                self.agent_type,
                SkillStageContext(context.task_id, stage, layer, large_file_mode, scope, inputs or {}),
                trace,
            )
        finally:
            await self._report_progress(
                context.task_id, 0, "skill_runtime",
                f"Skill preparation: {trace.get('status', 'failed')} ({stage})",
                details={"skill_runtime": deepcopy(traces)},
            )

    async def _prepare_agent_skills(
        self,
        context: AgentContext,
        stage: str,
        *,
        layer: str = "",
        large_file_mode: bool = False,
        scope: str = "agent",
        inputs: dict | None = None,
        capabilities: dict | None = None,
    ):
        """Prepare and cache collaboration guidance for a normal Agent stage.

        This is a small adapter over the stage runtime. It gives every Agent the
        same contract while keeping the Agent responsible for deciding when a
        skill is relevant and where its prompt belongs. Cached prompts are scoped
        to the task context and are never treated as workflow gate evidence.
        """
        prepared = await self._prepare_stage_skills(
            context,
            stage,
            layer=layer,
            large_file_mode=large_file_mode,
            scope=scope,
            inputs=inputs,
            capabilities=capabilities,
        )
        prompts = context.metadata.setdefault("skill_prompts", {})
        prompts[stage] = prepared.prompt
        return prepared

    @staticmethod
    def _stage_skill_prompt(context: AgentContext, stage: str) -> str:
        """Return prepared guidance for a stage, or an empty string."""
        prompts = context.metadata.get("skill_prompts") or {}
        value = prompts.get(stage, "")
        return value if isinstance(value, str) else ""


# ========== Custom Exceptions ==========

class ValidationError(Exception):
    """Input validation error"""
    pass


class CancelledException(Exception):
    """Task cancellation exception"""
    pass


class AgentExecutionError(Exception):
    """Agent execution exception"""
    pass
