"""Repository for payment order persistence and state transitions.

All state-machine mutations are single conditional ``UPDATE`` statements
guarded by the expected current status, so concurrent webhook
deliveries, admin actions, and the expiry task can race safely: exactly
one caller observes ``rowcount == 1``; every other caller gets ``False``
and must re-read the row to decide what to do.  The money aggregates
(powering the recharge limit checks) also live here so every caller
counts on the same rules.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional, Tuple

from sqlalchemy import and_, func, or_, select, update as sa_update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.payment_order import OrderStatus, PaymentOrder
from app.repositories.base import BaseRepository

# Statuses whose pay_amount counts towards the daily recharge limit:
# once the gateway confirms payment the money is committed even while
# the credit is still in flight.
_CHARGED_STATUSES = (
    OrderStatus.COMPLETED,
    OrderStatus.RECHARGING,
    OrderStatus.PAID,
)


# ORM-enabled UPDATE statements must not use the default
# ``synchronize_session='auto'`` (evaluate) strategy: it compares WHERE
# datetimes in Python, and DB-loaded naive values mixed with the
# timezone-aware parameters used throughout the payment services raise
# TypeError.  The ``fetch`` strategy synchronizes via RETURNING instead.
_SYNC_FETCH = {"synchronize_session": "fetch"}


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for UPDATE statements."""

    return datetime.now(timezone.utc)


class PaymentOrderRepository(BaseRepository[PaymentOrder]):
    """CRUD plus order-state-machine transitions for payment orders."""

    model_class = PaymentOrder

    # ==================== Lookup ====================

    async def get_by_out_trade_no(self, out_trade_no: str) -> Optional[PaymentOrder]:
        """Query by the merchant order number allocated at creation."""
        result = await self.session.execute(
            select(PaymentOrder).where(PaymentOrder.out_trade_no == out_trade_no)
        )
        return result.scalar_one_or_none()

    # ==================== Listing / Aggregates ====================

    async def list_paged(
        self,
        user_id: Optional[str] = None,
        status: Optional[str] = None,
        keyword: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Tuple[List[PaymentOrder], int]:
        """
        Query orders with filters and pagination, newest first.

        Args:
            user_id: Restrict to one user's orders (admin listing omits it).
            status: Exact status filter.
            keyword: Fuzzy match on out_trade_no, payment_trade_no or
                the username snapshot.
            date_from / date_to: Inclusive created_at bounds.
            page / page_size: 1-based pagination.

        Returns:
            (items, total) for the requested page.
        """
        filters = []
        if user_id is not None:
            filters.append(PaymentOrder.user_id == user_id)
        if status:
            filters.append(PaymentOrder.status == status)
        if keyword:
            pattern = f"%{keyword}%"
            filters.append(
                or_(
                    PaymentOrder.out_trade_no.like(pattern),
                    PaymentOrder.payment_trade_no.like(pattern),
                    PaymentOrder.username.like(pattern),
                )
            )
        if date_from is not None:
            filters.append(PaymentOrder.created_at >= date_from)
        if date_to is not None:
            filters.append(PaymentOrder.created_at <= date_to)

        total = await self.count(filters=filters)

        query = select(PaymentOrder).order_by(PaymentOrder.created_at.desc())
        for f in filters:
            query = query.where(f)
        query = query.offset(max(page - 1, 0) * page_size).limit(page_size)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total

    async def count_pending(self, user_id: str) -> int:
        """Count a user's orders still awaiting payment."""
        return await self.count(
            filters=[
                PaymentOrder.user_id == user_id,
                PaymentOrder.status == OrderStatus.PENDING,
            ]
        )

    async def sum_today_recharged(self, user_id: str) -> float:
        """Sum pay_amount committed for the user since UTC midnight."""
        midnight = _utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        query = select(func.coalesce(func.sum(PaymentOrder.pay_amount), 0.0)).where(
            PaymentOrder.user_id == user_id,
            PaymentOrder.status.in_(_CHARGED_STATUSES),
            PaymentOrder.created_at >= midnight,
        )
        result = await self.session.execute(query)
        return float(result.scalar() or 0.0)

    # ==================== Bulk Maintenance ====================

    async def expire_pending(self, cutoff_dt: datetime) -> int:
        """
        Bulk-move overdue pending orders to ``expired``.

        Returns:
            Number of rows expired by this sweep.
        """
        result = await self.session.execute(
            sa_update(PaymentOrder)
            .where(
                PaymentOrder.status == OrderStatus.PENDING,
                PaymentOrder.expires_at.is_not(None),
                PaymentOrder.expires_at < cutoff_dt,
            )
            .values(status=OrderStatus.EXPIRED, updated_at=_utcnow())
            .execution_options(**_SYNC_FETCH)
        )
        await self.session.flush()
        return result.rowcount

    # ==================== State Machine ====================

    async def transition_to_paid(
        self,
        order_id: str,
        trade_no: Optional[str],
        pay_amount: float,
        grace_cutoff: datetime,
    ) -> bool:
        """
        Conditionally move an order to ``paid`` (webhook/query entry).

        Allowed from ``pending``, from ``cancelled``, and from ``expired``
        rows still inside the grace window (late-notification recovery).
        Any other current state — or a concurrent winner — leaves the row
        untouched and returns ``False``, which makes repeated callbacks
        idempotent.

        Args:
            order_id: Target order.
            trade_no: Gateway trade number to snapshot.
            pay_amount: Amount actually charged by the gateway.
            grace_cutoff: Earliest ``updated_at`` an expired row may have
                to still qualify for recovery.

        Returns:
            True when this call won the transition.
        """
        now = _utcnow()
        result = await self.session.execute(
            sa_update(PaymentOrder)
            .where(
                PaymentOrder.id == order_id,
                or_(
                    PaymentOrder.status == OrderStatus.PENDING,
                    PaymentOrder.status == OrderStatus.CANCELLED,
                    and_(
                        PaymentOrder.status == OrderStatus.EXPIRED,
                        PaymentOrder.updated_at >= grace_cutoff,
                    ),
                ),
            )
            .values(
                status=OrderStatus.PAID,
                payment_trade_no=trade_no,
                pay_amount=pay_amount,
                paid_at=now,
                updated_at=now,
            )
            .execution_options(**_SYNC_FETCH)
        )
        await self.session.flush()
        return result.rowcount > 0

    async def acquire_fulfillment_lease(
        self,
        order_id: str,
        stale_cutoff: datetime,
    ) -> bool:
        """
        Conditionally claim fulfillment (status -> ``recharging``).

        Allowed from ``paid``, from ``failed`` (retry), and from a
        ``recharging`` row whose lease has gone stale (``updated_at`` at
        or before ``stale_cutoff``), so a crashed worker's order is
        recovered while a live worker's lease is never stolen.

        Returns:
            True when this call holds the lease.
        """
        now = _utcnow()
        result = await self.session.execute(
            sa_update(PaymentOrder)
            .where(
                PaymentOrder.id == order_id,
                or_(
                    PaymentOrder.status == OrderStatus.PAID,
                    PaymentOrder.status == OrderStatus.FAILED,
                    and_(
                        PaymentOrder.status == OrderStatus.RECHARGING,
                        PaymentOrder.updated_at <= stale_cutoff,
                    ),
                ),
            )
            .values(status=OrderStatus.RECHARGING, updated_at=now)
            .execution_options(**_SYNC_FETCH)
        )
        await self.session.flush()
        return result.rowcount > 0

    async def mark_completed(self, order_id: str) -> bool:
        """
        Move a leased order to ``completed`` (balance credited).

        Returns:
            True when the row moved from ``recharging``.
        """
        now = _utcnow()
        result = await self.session.execute(
            sa_update(PaymentOrder)
            .where(PaymentOrder.id == order_id, PaymentOrder.status == OrderStatus.RECHARGING)
            .values(
                status=OrderStatus.COMPLETED,
                completed_at=now,
                updated_at=now,
            )
            .execution_options(**_SYNC_FETCH)
        )
        await self.session.flush()
        return result.rowcount > 0

    async def mark_failed(self, order_id: str, reason: str) -> bool:
        """
        Move an order to ``failed`` after a fulfillment error.

        Allowed from ``recharging`` and ``paid``; the reason is stored on
        the row (truncated to the column width) for the admin retry view.

        Returns:
            True when the row moved.
        """
        now = _utcnow()
        result = await self.session.execute(
            sa_update(PaymentOrder)
            .where(
                PaymentOrder.id == order_id,
                PaymentOrder.status.in_((OrderStatus.RECHARGING, OrderStatus.PAID)),
            )
            .values(
                status=OrderStatus.FAILED,
                failed_at=now,
                failed_reason=(reason or "")[:255],
                updated_at=now,
            )
            .execution_options(**_SYNC_FETCH)
        )
        await self.session.flush()
        return result.rowcount > 0
