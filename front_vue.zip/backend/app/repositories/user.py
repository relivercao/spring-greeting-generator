"""
@file user.py
@author caoshwen
@brief UserRepository - user CRUD operations.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from sqlalchemy import func, or_, select, update as sa_update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.repositories.base import BaseRepository


class UserRepository(BaseRepository[User]):
    model_class = User

    async def get_by_username(self, username: str) -> Optional[User]:
        """Query by username"""
        result = await self.session.execute(
            select(User).where(User.username == username)
        )
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> Optional[User]:
        """Query by email"""
        result = await self.session.execute(
            select(User).where(User.email == email)
        )
        return result.scalar_one_or_none()

    async def get_by_username_or_email(self, login: str) -> Optional[User]:
        """Query by username or email address (login accepts both)."""
        result = await self.session.execute(
            select(User).where(or_(User.username == login, User.email == login))
        )
        return result.scalar_one_or_none()

    async def add_balance(
        self,
        user_id: str,
        delta: float,
        add_to_total: bool = False,
    ) -> Optional[User]:
        """
        Apply a signed balance change atomically via a SQL expression.

        A single UPDATE with column arithmetic (no read-modify-write) so
        concurrent fulfillments and billing deductions never lose
        updates; the new balance is rounded to 2 decimal places in SQL.
        When ``add_to_total`` is set the same delta also accumulates
        into ``total_recharged``.

        Args:
            user_id: Target user.
            delta: Signed CNY change (positive credits, negative debits).
            add_to_total: Also add the delta to ``total_recharged``.

        Returns:
            The refreshed user row (committed), or ``None`` when the
            user does not exist.
        """
        values: Dict[str, Any] = {
            "balance": func.round(User.balance + delta, 2),
            "updated_at": datetime.now(timezone.utc),
        }
        if add_to_total:
            values["total_recharged"] = User.total_recharged + delta

        result = await self.session.execute(
            sa_update(User)
            .where(User.id == user_id)
            .values(**values)
            # 'fetch' keeps the identity map coherent for the computed
            # SQL-expression values (no Python-side evaluation).
            .execution_options(synchronize_session="fetch")
        )
        if result.rowcount == 0:
            return None
        await self.session.commit()

        refreshed = await self.session.execute(
            select(User)
            .where(User.id == user_id)
            .execution_options(populate_existing=True)
        )
        return refreshed.scalar_one_or_none()

    async def set_admin(self, user_id: str, flag: bool) -> Optional[User]:
        """Grant or revoke the admin role."""
        return await self.update(user_id, {"is_admin": flag})

    async def set_level(
        self, user_id: str, level: str, manual: bool
    ) -> Optional[User]:
        """
        Set the membership level and its override mode.

        Args:
            user_id: Target user.
            level: Level key into the payment.levels setting.
            manual: True pins the level (auto-upgrade skips the user);
                False returns the user to automatic tiering.
        """
        return await self.update(
            user_id, {"level": level, "level_manual": manual}
        )

    async def get_active_users(self, limit: int = 100, offset: int = 0):
        """Get list of active users"""
        return await self.get_all(
            filters=[User.is_active == True],
            order_by=User.created_at.desc(),
            limit=limit,
            offset=offset,
        )

    async def deactivate(self, user_id: str) -> Optional[User]:
        """Deactivate user"""
        return await self.update(user_id, {"is_active": False})

    async def activate(self, user_id: str) -> Optional[User]:
        """Activate user"""
        return await self.update(user_id, {"is_active": True})
