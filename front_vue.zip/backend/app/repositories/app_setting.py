"""Repository for the JSON key/value application settings store."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.app_setting import AppSetting
from app.repositories.base import BaseRepository


class AppSettingRepository(BaseRepository[AppSetting]):
    """Reads and upserts JSON blobs keyed by string.

    Note: :class:`AppSetting` is keyed by ``key`` (not ``id``), so only
    the JSON accessors below — not the inherited by-id CRUD — apply.
    """

    model_class = AppSetting

    async def get_json(self, key: str, default: Any = None) -> Any:
        """
        Decode the JSON value stored under ``key``.

        Missing keys and undecodable payloads both fall back to
        ``default`` so callers can treat stored config as best-effort.

        Args:
            key: Setting key, e.g. ``payment.general`` or ``payment.pricing``.
            default: Value returned when the key is absent or corrupt.

        Returns:
            The decoded Python object (usually a dict).
        """
        result = await self.session.execute(
            select(AppSetting).where(AppSetting.key == key)
        )
        row = result.scalar_one_or_none()
        if row is None:
            return default
        try:
            return json.loads(row.value)
        except (TypeError, ValueError):
            return default

    async def set_json(self, key: str, value: Any) -> None:
        """
        Upsert ``value`` as a JSON blob under ``key``.

        Args:
            key: Setting key.
            value: JSON-serializable object to store.
        """
        encoded = json.dumps(value, ensure_ascii=False)
        result = await self.session.execute(
            select(AppSetting).where(AppSetting.key == key)
        )
        row = result.scalar_one_or_none()
        if row is None:
            self.session.add(AppSetting(key=key, value=encoded))
        else:
            row.value = encoded
            row.updated_at = datetime.now(timezone.utc)
        await self.session.flush()
