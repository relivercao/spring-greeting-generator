"""
@file driver_conversation.py
@brief Repository layer for Driver Agent multi-turn conversation state.

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import json
from datetime import datetime, timezone
from typing import Final
from uuid import uuid4

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import GUEST_DATABASE_ID_PREFIX
from app.models.driver_agent import (
    DriverAgentArtifact,
    DriverAgentChatMessage,
    DriverAgentChatSession,
    DriverAgentTask,
    DriverAgentToolResult,
    DEFAULT_DRIVER_MAX_RETRIES,
    DRIVER_AGENT_TYPE,
    DRIVER_INITIAL_STEP,
    DRIVER_TASK_TYPE,
    DriverRepositoryFetchStatus,
    DriverRepositorySource,
    DriverSessionStatus,
    DriverSource,
    DriverSourceParseStatus,
    DriverSourceUploadStatus,
    DriverTaskStatus,
    MAX_DRIVER_SESSION_TITLE_CHARS,
)
from app.utils.token_usage import TokenUsageAccumulator


ACTIVE_TASK_STATUSES = {
    DriverTaskStatus.CREATED.value,
    DriverTaskStatus.RUNNING.value,
    DriverTaskStatus.WAITING_USER.value,
}
VALID_TASK_STATUSES = {status.value for status in DriverTaskStatus}
VALID_SOURCE_PARSE_STATUSES = {status.value for status in DriverSourceParseStatus}
VALID_REPOSITORY_FETCH_STATUSES = {status.value for status in DriverRepositoryFetchStatus}
DEFAULT_MESSAGE_LIMIT = 50
DEFAULT_TOOL_RESULT_LIMIT = 20
TOKEN_USAGE_STATE_KEY = "token_usage"
TOKEN_USAGE_STATUS_STATE_KEY = "token_usage_status"
TOKEN_USAGE_STATUS_ORDER = {
    "pending": 0,
    "unavailable": 1,
    "available": 2,
}


class _UnsetType:
    """Sentinel type for fields that should not be updated."""

    __slots__ = ()


_UNSET: Final = _UnsetType()


class DriverConversationRepository:
    """Repository for Driver Agent multi-turn conversation state in SQLite."""

    def __init__(self, db: AsyncSession, user_id: str | None = None) -> None:
        self.db = db
        self.user_id = user_id

    def _effective_user_id(self, user_id: str | None) -> str | None:
        if self.user_id is not None and user_id not in (None, self.user_id):
            raise ValueError("Resource owner does not match repository user scope")
        return self.user_id if self.user_id is not None else user_id

    # ==================== Session Operations ====================

    async def create_session(self, user_id: str | None, title: str | None) -> DriverAgentChatSession:
        session = DriverAgentChatSession(
            id=f"chat_{uuid4().hex}",
            user_id=self._effective_user_id(user_id),
            title=title[:MAX_DRIVER_SESSION_TITLE_CHARS] if title else None,
            agent_type=DRIVER_AGENT_TYPE,
            status=DriverSessionStatus.ACTIVE.value,
        )
        self.db.add(session)
        await self.db.flush()
        return session

    async def get_session(self, session_id: str) -> DriverAgentChatSession | None:
        statement = select(DriverAgentChatSession).where(DriverAgentChatSession.id == session_id)
        if self.user_id is not None:
            statement = statement.where(DriverAgentChatSession.user_id == self.user_id)
        result = await self.db.execute(statement)
        return result.scalar_one_or_none()

    async def touch_session(self, session_id: str) -> None:
        session = await self.get_session(session_id)
        if session is None:
            return
        session.updated_at = datetime.now(timezone.utc)
        await self.db.flush()

    # ==================== Message Operations ====================

    async def append_message(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: dict | None = None,
    ) -> DriverAgentChatMessage:
        if await self.get_session(session_id) is None:
            raise ValueError("Driver session not found in the current user scope")
        message = DriverAgentChatMessage(
            id=f"msg_{uuid4().hex}",
            session_id=session_id,
            role=role,
            content=content,
            message_metadata=json.dumps(metadata) if metadata else None,
        )
        self.db.add(message)
        await self.touch_session(session_id)
        await self.db.flush()
        return message

    async def list_messages(
        self, session_id: str, limit: int = DEFAULT_MESSAGE_LIMIT
    ) -> list[DriverAgentChatMessage]:
        if await self.get_session(session_id) is None:
            return []
        result = await self.db.execute(
            select(DriverAgentChatMessage)
            .where(DriverAgentChatMessage.session_id == session_id)
            .order_by(desc(DriverAgentChatMessage.created_at))
            .limit(limit)
        )
        messages = list(result.scalars().all())
        # Fetch the most recent N rows efficiently, then return them chronologically.
        return list(reversed(messages))

    # ==================== Task Operations ====================

    async def create_task(
        self,
        session_id: str,
        target_file: str | None = None,
        project_root: str | None = None,
        task_id: str | None = None,
    ) -> DriverAgentTask:
        if await self.get_session(session_id) is None:
            raise ValueError("Driver session not found in the current user scope")
        task = DriverAgentTask(
            id=task_id or f"task_{uuid4().hex}",
            session_id=session_id,
            agent_type=DRIVER_AGENT_TYPE,
            task_type=DRIVER_TASK_TYPE,
            status=DriverTaskStatus.CREATED.value,
            current_step=DRIVER_INITIAL_STEP,
            target_file=target_file,
            project_root=project_root,
            retry_count=0,
            max_retries=DEFAULT_DRIVER_MAX_RETRIES,
            state_data=json.dumps({}),
        )
        self.db.add(task)
        await self.db.flush()
        return task

    async def get_task(self, task_id: str) -> DriverAgentTask | None:
        statement = select(DriverAgentTask).where(DriverAgentTask.id == task_id)
        if self.user_id is not None:
            statement = (
                statement.join(DriverAgentChatSession)
                .where(DriverAgentChatSession.user_id == self.user_id)
            )
        result = await self.db.execute(statement)
        return result.scalar_one_or_none()

    async def get_readable_task(self, task_id: str) -> DriverAgentTask | None:
        """Allow guest-to-guest recovery by task ID for explicit read paths.

        Guest task IDs grant read access, including legacy IDs. They must not
        be shared with untrusted parties. Registered users and write paths
        retain the normal owner scope.
        """
        task = await self.get_task(task_id)
        if task is not None or not (self.user_id or "").startswith(
            GUEST_DATABASE_ID_PREFIX
        ):
            return task
        statement = (
            select(DriverAgentTask)
            .join(DriverAgentChatSession)
            .where(
                DriverAgentTask.id == task_id,
                DriverAgentChatSession.user_id.startswith(GUEST_DATABASE_ID_PREFIX),
            )
        )
        result = await self.db.execute(statement)
        return result.scalar_one_or_none()

    async def get_active_task(self, session_id: str) -> DriverAgentTask | None:
        statement = (
            select(DriverAgentTask)
            .where(DriverAgentTask.session_id == session_id)
            .where(DriverAgentTask.status.in_(ACTIVE_TASK_STATUSES))
            .order_by(desc(DriverAgentTask.updated_at))
            .limit(1)
        )
        if self.user_id is not None:
            statement = (
                statement.join(DriverAgentChatSession)
                .where(DriverAgentChatSession.user_id == self.user_id)
            )
        result = await self.db.execute(statement)
        return result.scalar_one_or_none()

    async def update_task_state(
        self,
        task_id: str,
        status: str,
        current_step: str | None | _UnsetType = _UNSET,
        patch: dict | None = None,
        last_error: str | None | _UnsetType = _UNSET,
    ) -> DriverAgentTask | None:
        if status not in VALID_TASK_STATUSES:
            raise ValueError(f"Invalid driver task status: {status}")
        task = await self.get_task(task_id)
        if task is None:
            return None
        task.status = status
        task.updated_at = datetime.now(timezone.utc)
        if not isinstance(current_step, _UnsetType):
            task.current_step = current_step
        if not isinstance(last_error, _UnsetType):
            task.last_error = last_error
        if patch:
            await self.db.refresh(task, attribute_names=["state_data"])
            existing = self._parse_state_data(task.state_data)
            existing = self._merge_state_patch(existing, patch)
            task.state_data = json.dumps(existing)
        await self.db.flush()
        return task

    @staticmethod
    def _parse_state_data(raw_state: str | None) -> dict:
        if not raw_state:
            return {}
        try:
            parsed = json.loads(raw_state)
        except (TypeError, json.JSONDecodeError):
            return {}
        return parsed if isinstance(parsed, dict) else {}

    @classmethod
    def _merge_state_patch(cls, existing: dict, patch: dict) -> dict:
        merged = dict(existing)
        incoming_token_usage = patch.get(TOKEN_USAGE_STATE_KEY)
        for key, value in patch.items():
            if key in {TOKEN_USAGE_STATE_KEY, TOKEN_USAGE_STATUS_STATE_KEY}:
                continue
            merged[key] = value
        if TOKEN_USAGE_STATE_KEY in patch:
            merged[TOKEN_USAGE_STATE_KEY] = cls._merge_token_usage_snapshot(
                merged.get(TOKEN_USAGE_STATE_KEY),
                incoming_token_usage,
            )
        if TOKEN_USAGE_STATUS_STATE_KEY in patch:
            current_status = str(merged.get(TOKEN_USAGE_STATUS_STATE_KEY) or "pending")
            incoming_status = str(patch.get(TOKEN_USAGE_STATUS_STATE_KEY) or "pending")
            if TOKEN_USAGE_STATUS_ORDER.get(incoming_status, 0) >= TOKEN_USAGE_STATUS_ORDER.get(current_status, 0):
                merged[TOKEN_USAGE_STATUS_STATE_KEY] = incoming_status
        return merged

    @staticmethod
    def _merge_token_usage_snapshot(existing: object, incoming: object) -> dict[str, int]:
        """Merge cumulative snapshots without double-counting polling updates."""
        existing_usage = existing if isinstance(existing, dict) else {}
        incoming_usage = incoming if isinstance(incoming, dict) else {}
        merged = {
            field: max(
                TokenUsageAccumulator.coerce_count(existing_usage.get(field)),
                TokenUsageAccumulator.coerce_count(incoming_usage.get(field)),
            )
            for field in TokenUsageAccumulator.COMPONENT_FIELDS
        }
        component_total = sum(merged.values())
        reported_total = max(
            TokenUsageAccumulator.coerce_count(existing_usage.get("total_tokens")),
            TokenUsageAccumulator.coerce_count(incoming_usage.get("total_tokens")),
        )
        merged["total_tokens"] = component_total if component_total else reported_total
        return merged

    async def increment_retry(self, task_id: str, error: str) -> DriverAgentTask | None:
        task = await self.get_task(task_id)
        if task is None:
            return None
        task.retry_count += 1
        task.last_error = error
        task.updated_at = datetime.now(timezone.utc)
        await self.db.flush()
        return task

    # ==================== Tool Result Operations ====================

    async def add_tool_result(
        self,
        task_id: str,
        session_id: str,
        tool_name: str,
        input_data: dict | None,
        output_data: dict | None,
        status: str,
        error_message: str | None = None,
    ) -> DriverAgentToolResult:
        task = await self.get_task(task_id)
        if task is None or task.session_id != session_id:
            raise ValueError("Driver task and session do not match the current user scope")
        tool_result = DriverAgentToolResult(
            id=f"tr_{uuid4().hex}",
            task_id=task_id,
            session_id=session_id,
            tool_name=tool_name,
            input_data=json.dumps(input_data) if input_data else None,
            output_data=json.dumps(output_data) if output_data else None,
            status=status,
            error_message=error_message,
        )
        self.db.add(tool_result)
        await self.db.flush()
        return tool_result

    async def list_tool_results(
        self, task_id: str, limit: int = DEFAULT_TOOL_RESULT_LIMIT
    ) -> list[DriverAgentToolResult]:
        if await self.get_task(task_id) is None:
            return []
        result = await self.db.execute(
            select(DriverAgentToolResult)
            .where(DriverAgentToolResult.task_id == task_id)
            .order_by(desc(DriverAgentToolResult.created_at))
            .limit(limit)
        )
        return list(reversed(list(result.scalars().all())))

    # ==================== Artifact Operations ====================

    async def add_artifact(
        self,
        task_id: str,
        session_id: str,
        artifact_type: str,
        name: str,
        path: str,
        language: str | None = None,
        content: str | None = None,
        size: int | None = None,
        content_hash: str | None = None,
    ) -> DriverAgentArtifact:
        task = await self.get_task(task_id)
        if task is None or task.session_id != session_id:
            raise ValueError("Driver task and session do not match the current user scope")
        artifact = DriverAgentArtifact(
            id=f"art_{uuid4().hex}",
            task_id=task_id,
            session_id=session_id,
            artifact_type=artifact_type,
            name=name,
            path=path,
            language=language,
            content=content,
            size=size,
            content_hash=content_hash,
        )
        self.db.add(artifact)
        await self.db.flush()
        return artifact

    async def list_artifacts(self, task_id: str) -> list[DriverAgentArtifact]:
        if await self.get_readable_task(task_id) is None:
            return []
        result = await self.db.execute(
            select(DriverAgentArtifact)
            .where(DriverAgentArtifact.task_id == task_id)
            .order_by(DriverAgentArtifact.created_at)
        )
        return list(result.scalars().all())

    # ==================== Source Operations ====================

    async def create_source(
        self,
        user_id: str | None,
        source_type: str,
        name: str,
        size: int,
        extension: str,
        mime_type: str | None = None,
        saved_path: str | None = None,
    ) -> DriverSource:
        source = DriverSource(
            id=f"src_{uuid4().hex}",
            user_id=self._effective_user_id(user_id),
            source_type=source_type,
            name=name,
            size=size,
            extension=extension,
            mime_type=mime_type,
            upload_status=DriverSourceUploadStatus.UPLOADED.value,
            parse_status=DriverSourceParseStatus.PENDING.value,
            saved_path=saved_path,
        )
        self.db.add(source)
        await self.db.flush()
        return source

    async def get_source(self, source_id: str) -> DriverSource | None:
        statement = select(DriverSource).where(DriverSource.id == source_id)
        if self.user_id is not None:
            statement = statement.where(DriverSource.user_id == self.user_id)
        result = await self.db.execute(statement)
        return result.scalar_one_or_none()

    async def update_source_parse_status(
        self,
        source_id: str,
        parse_status: str,
        parsed_content: str | None | _UnsetType = _UNSET,
        parsed_summary: str | None | _UnsetType = _UNSET,
        extra_metadata: str | None | _UnsetType = _UNSET,
    ) -> DriverSource | None:
        """Apply a parse-status transition and flush it.

        Flush only: the transaction boundary belongs to the caller, as it does for
        every other method in this package. DriverSourceService commits each parse
        transition itself because a multi-minute parse has to become visible to the
        independent sessions used by polling requests.
        """
        if parse_status not in VALID_SOURCE_PARSE_STATUSES:
            raise ValueError(f"Invalid driver source parse status: {parse_status}")
        source = await self.get_source(source_id)
        if source is None:
            return None
        source.parse_status = parse_status
        if not isinstance(parsed_content, _UnsetType):
            source.parsed_content = parsed_content
        if not isinstance(parsed_summary, _UnsetType):
            source.parsed_summary = parsed_summary
        if not isinstance(extra_metadata, _UnsetType):
            source.extra_metadata = extra_metadata
        await self.db.flush()
        return source

    async def delete_source(self, source_id: str) -> bool:
        source = await self.get_source(source_id)
        if source is None:
            return False
        await self.db.delete(source)
        await self.db.flush()
        return True

    # ==================== Repository Source Operations ====================

    async def create_repository_source(
        self,
        user_id: str | None,
        repository_url: str,
        branch: str | None = None,
        selected_paths: list[str] | None = None,
    ) -> DriverRepositorySource:
        repo_source = DriverRepositorySource(
            id=f"repo_{uuid4().hex}",
            user_id=self._effective_user_id(user_id),
            repository_url=repository_url,
            branch=branch,
            selected_paths=json.dumps(selected_paths) if selected_paths else None,
            fetch_status=DriverRepositoryFetchStatus.IDLE.value,
        )
        self.db.add(repo_source)
        await self.db.flush()
        return repo_source

    async def get_repository_source(self, source_id: str) -> DriverRepositorySource | None:
        statement = select(DriverRepositorySource).where(DriverRepositorySource.id == source_id)
        if self.user_id is not None:
            statement = statement.where(DriverRepositorySource.user_id == self.user_id)
        result = await self.db.execute(statement)
        return result.scalar_one_or_none()

    async def update_repository_fetch_status(
        self,
        source_id: str,
        fetch_status: str,
        workspace_path: str | None | _UnsetType = _UNSET,
        file_count: int | _UnsetType = _UNSET,
        included_files: list[dict] | None | _UnsetType = _UNSET,
        commit_sha: str | None | _UnsetType = _UNSET,
        message: str | None | _UnsetType = _UNSET,
    ) -> DriverRepositorySource | None:
        if fetch_status not in VALID_REPOSITORY_FETCH_STATUSES:
            raise ValueError(f"Invalid repository fetch status: {fetch_status}")
        repo = await self.get_repository_source(source_id)
        if repo is None:
            return None
        repo.fetch_status = fetch_status
        if not isinstance(workspace_path, _UnsetType):
            repo.workspace_path = workspace_path
        if not isinstance(file_count, _UnsetType):
            repo.file_count = file_count
        if not isinstance(included_files, _UnsetType):
            repo.included_files = json.dumps(included_files) if included_files is not None else None
        if not isinstance(commit_sha, _UnsetType):
            repo.commit_sha = commit_sha
        if not isinstance(message, _UnsetType):
            repo.message = message
        await self.db.flush()
        return repo
