"""Repository for payment provider instance credentials."""

from __future__ import annotations

from typing import List

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.payment_provider import PaymentProviderInstance
from app.repositories.base import BaseRepository


class PaymentProviderRepository(BaseRepository[PaymentProviderInstance]):
    """CRUD for gateway credential sets (create/update via base class).

    The ``config`` column holds a JSON-encoded merchant config including
    the ``pkey`` secret; callers must mask it before returning any row
    over HTTP (the admin schemas do this at validation time).
    """

    model_class = PaymentProviderInstance

    async def list_enabled(self) -> List[PaymentProviderInstance]:
        """List enabled gateways in display order."""
        query = (
            select(PaymentProviderInstance)
            .where(PaymentProviderInstance.is_enabled.is_(True))
            .order_by(PaymentProviderInstance.sort_order.asc())
        )
        result = await self.session.execute(query)
        return list(result.scalars().all())
