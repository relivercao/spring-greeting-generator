"""Repository for the user balance ledger.

:class:`BalanceTransactionRepository` appends signed ledger rows and
pages them back per user.  The ledger is append-only: rows are inserted
by the fulfillment, billing, registration, and admin services and are
never updated or deleted.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.balance_transaction import BalanceTransaction
from app.repositories.base import BaseRepository


class BalanceTransactionRepository(BaseRepository[BalanceTransaction]):
    """Append-only ledger access for user balance changes."""

    model_class = BalanceTransaction

    async def create_row(
        self,
        user_id: str,
        amount: float,
        balance_after: float,
        type: str,
        reference_id: Optional[str] = None,
        description: Optional[str] = None,
        model: Optional[str] = None,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
    ) -> BalanceTransaction:
        """
        Append one ledger entry and return the persisted row.

        Args:
            user_id: Owner of the balance change.
            amount: Signed CNY value (positive credit, negative debit).
            balance_after: Balance snapshot after applying the change.
            type: Ledger category (recharge / usage / admin_adjust /
                signup_bonus / promo_bonus / refund).
            reference_id: Order id, usage log id, redeem code, etc.
            description: Human-readable note shown in the UI.
            model / prompt_tokens / completion_tokens: LLM usage details,
                only meaningful for ``usage`` rows.
        """
        row = BalanceTransaction(
            user_id=user_id,
            amount=amount,
            balance_after=balance_after,
            type=type,
            reference_id=reference_id,
            description=description,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )
        return await self.create(row)

    async def list_paged(
        self,
        user_id: str,
        page: int = 1,
        page_size: int = 20,
    ) -> Tuple[List[BalanceTransaction], int]:
        """Page a user's ledger, newest first."""
        total = await self.count(filters=[BalanceTransaction.user_id == user_id])
        query = (
            select(BalanceTransaction)
            .where(BalanceTransaction.user_id == user_id)
            .order_by(BalanceTransaction.created_at.desc())
            .offset(max(page - 1, 0) * page_size)
            .limit(page_size)
        )
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
