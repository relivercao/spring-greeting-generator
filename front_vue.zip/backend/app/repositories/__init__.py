"""
@file __init__.py
@author caoshwen
@brief Repository layer module initialization and DI exports.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from app.repositories.base import BaseRepository
from app.repositories.user import UserRepository
from app.repositories.session import SessionRepository, MessageRepository
from app.repositories.task import TaskRepository
from app.repositories.llm_usage import LLMUsageLogRepository
from app.repositories.batch import (
    BatchPersistenceError,
    BatchRepository,
    persist_batch_snapshot,
)
from app.repositories.payment_order import PaymentOrderRepository
from app.repositories.recharge_plan import RechargePlanRepository
from app.repositories.payment_provider import PaymentProviderRepository
from app.repositories.balance_transaction import BalanceTransactionRepository
from app.repositories.redeem_code import RedeemCodeRepository
from app.repositories.app_setting import AppSettingRepository
from app.repositories.deps import (
    get_user_repo,
    get_session_repo,
    get_message_repo,
    get_task_repo,
    get_llm_usage_repo,
    get_payment_order_repo,
    get_recharge_plan_repo,
    get_payment_provider_repo,
    get_balance_transaction_repo,
    get_redeem_code_repo,
    get_app_setting_repo,
)

__all__ = [
    "BaseRepository",
    "UserRepository",
    "SessionRepository",
    "MessageRepository",
    "TaskRepository",
    "LLMUsageLogRepository",
    "BatchPersistenceError",
    "BatchRepository",
    "persist_batch_snapshot",
    "PaymentOrderRepository",
    "RechargePlanRepository",
    "PaymentProviderRepository",
    "BalanceTransactionRepository",
    "RedeemCodeRepository",
    "AppSettingRepository",
    "get_user_repo",
    "get_session_repo",
    "get_message_repo",
    "get_task_repo",
    "get_llm_usage_repo",
    "get_payment_order_repo",
    "get_recharge_plan_repo",
    "get_payment_provider_repo",
    "get_balance_transaction_repo",
    "get_redeem_code_repo",
    "get_app_setting_repo",
]
