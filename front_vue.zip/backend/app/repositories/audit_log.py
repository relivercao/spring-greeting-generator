"""
@file audit_log.py
@author caoshwen
@brief Repository for audit log operations.

@version 3.2
@date 2026-07-25

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import Optional, List
from datetime import datetime, timedelta
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_log import AuditLog, AuditResult
from app.repositories.base import BaseRepository


class AuditLogRepository(BaseRepository[AuditLog]):
    """Repository for audit log CRUD operations."""
    
    def __init__(self, session: AsyncSession):
        super().__init__(AuditLog, session)
    
    async def create_log(
        self,
        user_id: str,
        action: str,
        result: str = AuditResult.SUCCESS,
        username: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        error_message: Optional[str] = None,
        details: Optional[dict] = None,
    ) -> AuditLog:
        """Create a new audit log entry."""
        audit_log = AuditLog(
            user_id=user_id,
            username=username,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            ip_address=ip_address,
            user_agent=user_agent,
            result=result,
            error_message=error_message,
            details=details,
        )
        return await self.create(audit_log)
    
    async def get_user_logs(
        self,
        user_id: str,
        limit: int = 100,
        offset: int = 0,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> List[AuditLog]:
        """Get audit logs for a specific user."""
        query = select(AuditLog).where(AuditLog.user_id == user_id)
        
        if start_date:
            query = query.where(AuditLog.timestamp >= start_date)
        if end_date:
            query = query.where(AuditLog.timestamp <= end_date)
        
        query = query.order_by(AuditLog.timestamp.desc()).limit(limit).offset(offset)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_action_logs(
        self,
        action: str,
        limit: int = 100,
        offset: int = 0,
    ) -> List[AuditLog]:
        """Get audit logs for a specific action type."""
        query = (
            select(AuditLog)
            .where(AuditLog.action == action)
            .order_by(AuditLog.timestamp.desc())
            .limit(limit)
            .offset(offset)
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_failed_logs(
        self,
        hours: int = 24,
        limit: int = 100,
    ) -> List[AuditLog]:
        """Get recent failed/denied audit logs."""
        cutoff = datetime.utcnow() - timedelta(hours=hours)
        
        query = (
            select(AuditLog)
            .where(
                and_(
                    AuditLog.timestamp >= cutoff,
                    AuditLog.result.in_([AuditResult.FAILURE, AuditResult.DENIED, AuditResult.ERROR])
                )
            )
            .order_by(AuditLog.timestamp.desc())
            .limit(limit)
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_statistics(
        self,
        start_date: datetime,
        end_date: datetime,
    ) -> dict:
        """Get audit log statistics for a date range."""
        # Total logs
        total_query = select(func.count(AuditLog.id)).where(
            and_(
                AuditLog.timestamp >= start_date,
                AuditLog.timestamp <= end_date,
            )
        )
        total_result = await self.session.execute(total_query)
        total_logs = total_result.scalar() or 0
        
        # By result
        result_query = (
            select(AuditLog.result, func.count(AuditLog.id))
            .where(
                and_(
                    AuditLog.timestamp >= start_date,
                    AuditLog.timestamp <= end_date,
                )
            )
            .group_by(AuditLog.result)
        )
        result_stats = await self.session.execute(result_query)
        by_result = {row[0]: row[1] for row in result_stats}
        
        # By action (top 10)
        action_query = (
            select(AuditLog.action, func.count(AuditLog.id))
            .where(
                and_(
                    AuditLog.timestamp >= start_date,
                    AuditLog.timestamp <= end_date,
                )
            )
            .group_by(AuditLog.action)
            .order_by(func.count(AuditLog.id).desc())
            .limit(10)
        )
        action_stats = await self.session.execute(action_query)
        top_actions = {row[0]: row[1] for row in action_stats}
        
        # Active users (top 10)
        user_query = (
            select(AuditLog.user_id, func.count(AuditLog.id))
            .where(
                and_(
                    AuditLog.timestamp >= start_date,
                    AuditLog.timestamp <= end_date,
                )
            )
            .group_by(AuditLog.user_id)
            .order_by(func.count(AuditLog.id).desc())
            .limit(10)
        )
        user_stats = await self.session.execute(user_query)
        active_users = {row[0]: row[1] for row in user_stats}
        
        return {
            "total_logs": total_logs,
            "by_result": by_result,
            "top_actions": top_actions,
            "active_users": active_users,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
        }
    
    async def cleanup_old_logs(self, days: int = 90) -> int:
        """Delete audit logs older than specified days."""
        cutoff = datetime.utcnow() - timedelta(days=days)
        
        query = select(AuditLog).where(AuditLog.timestamp < cutoff)
        result = await self.session.execute(query)
        old_logs = result.scalars().all()
        
        count = 0
        for log in old_logs:
            await self.delete(log.id)
            count += 1
        
        return count
