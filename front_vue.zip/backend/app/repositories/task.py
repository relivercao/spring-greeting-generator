"""
@file task.py
@author caoshwen
@brief TaskRepository - task CRUD operations.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import Dict, List, Optional, Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.task import Task
from app.repositories.base import BaseRepository


class TaskRepository(BaseRepository[Task]):
    model_class = Task

    async def get_by_user(
        self,
        user_id: str,
        status: Optional[str] = None,
        agent_type: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> List[Task]:
        """Get user task list (sorted by creation time descending)"""
        filters = [Task.user_id == user_id]
        if status:
            filters.append(Task.status == status)
        if agent_type:
            filters.append(Task.agent_type == agent_type)
        return await self.get_all(
            filters=filters,
            order_by=Task.created_at.desc(),
            limit=limit,
            offset=offset,
        )

    async def count_by_user(
        self,
        user_id: str,
        status: Optional[str] = None,
        agent_type: Optional[str] = None,
    ) -> int:
        """Count user tasks"""
        filters = [Task.user_id == user_id]
        if status:
            filters.append(Task.status == status)
        if agent_type:
            filters.append(Task.agent_type == agent_type)
        return await self.count(filters=filters)

    async def get_user_task(self, task_id: str, user_id: str) -> Optional[Task]:
        """Get task belonging to specified user (permission check)"""
        result = await self.session.execute(
            select(Task).where(
                Task.id == task_id,
                Task.user_id == user_id,
            )
        )
        return result.scalar_one_or_none()

    async def get_by_session(self, session_id: str) -> List[Task]:
        """Get all tasks associated with a session"""
        return await self.get_all(
            filters=[Task.session_id == session_id],
            order_by=Task.created_at.desc(),
        )

    async def update_progress(
        self,
        task_id: str,
        progress: int,
        message: str = "",
    ) -> Optional[Task]:
        """Update task progress"""
        updates: Dict[str, Any] = {"progress": progress}
        if message:
            updates["message"] = message
        return await self.update(task_id, updates)

    async def mark_completed(
        self,
        task_id: str,
        result_data: Optional[str] = None,
        duration_ms: Optional[float] = None,
    ) -> Optional[Task]:
        """Mark task as completed"""
        updates: Dict[str, Any] = {"status": "completed", "progress": 100}
        if result_data is not None:
            updates["result_data"] = result_data
        if duration_ms is not None:
            updates["duration_ms"] = duration_ms
        return await self.update(task_id, updates)

    async def mark_failed(
        self,
        task_id: str,
        error_message: str,
        duration_ms: Optional[float] = None,
    ) -> Optional[Task]:
        """Mark task as failed"""
        updates: Dict[str, Any] = {"status": "failed", "error_message": error_message}
        if duration_ms is not None:
            updates["duration_ms"] = duration_ms
        return await self.update(task_id, updates)

    async def get_running_tasks(self, user_id: Optional[str] = None) -> List[Task]:
        """Get all running tasks"""
        filters = [Task.status == "running"]
        if user_id:
            filters.append(Task.user_id == user_id)
        return await self.get_all(
            filters=filters,
            order_by=Task.created_at.desc(),
        )
