"""Repository for invitation and promotional redeem codes."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import or_, select, update as sa_update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.redeem_code import RedeemCode
from app.repositories.base import BaseRepository


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for UPDATE statements."""

    return datetime.now(timezone.utc)


class RedeemCodeRepository(BaseRepository[RedeemCode]):
    """CRUD for redeem codes with atomic usage consumption."""

    model_class = RedeemCode

    async def get_by_code(self, code: str) -> Optional[RedeemCode]:
        """Query by the code string."""
        result = await self.session.execute(
            select(RedeemCode).where(RedeemCode.code == code)
        )
        return result.scalar_one_or_none()

    async def try_use(self, code: str, used_by: str) -> Optional[RedeemCode]:
        """
        Atomically consume one use of a code.

        A single conditional UPDATE bumps ``used_count`` only while the
        code is active, below its usage cap and unexpired, so concurrent
        registrations can never overshoot ``max_uses``.

        Args:
            code: The code string being redeemed.
            used_by: User id consuming the code.

        Returns:
            The refreshed row on success, or ``None`` when the code is
            unknown, inactive, exhausted or expired.
        """
        now = _utcnow()
        result = await self.session.execute(
            sa_update(RedeemCode)
            .where(
                RedeemCode.code == code,
                RedeemCode.is_active.is_(True),
                RedeemCode.used_count < RedeemCode.max_uses,
                or_(
                    RedeemCode.expires_at.is_(None),
                    RedeemCode.expires_at > now,
                ),
            )
            .values(
                used_count=RedeemCode.used_count + 1,
                used_by=used_by,
                used_at=now,
            )
            # 'fetch' avoids the evaluate strategy's in-Python datetime
            # comparison (naive DB values vs timezone-aware parameters).
            .execution_options(synchronize_session="fetch")
        )
        if result.rowcount == 0:
            return None
        await self.session.flush()
        return await self.get_by_code(code)

    async def batch_create(self, rows: List[RedeemCode]) -> List[RedeemCode]:
        """Bulk insert generated codes (admin batch generation)."""
        return await self.bulk_create(rows)
