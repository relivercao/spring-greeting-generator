"""Transactional persistence for queued Batch Unit-Test inputs.

The upload snapshot is finalized before this repository is called.  This
module owns the matching database transaction so a dispatcher can never see a
queue entry whose BatchTask or BatchItems were only partially written.
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any
import uuid

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.batch_contract import BatchItemStatus, BatchTaskStatus
from app.models.batch import (
    BatchItem,
    BatchQueueEntry,
    BatchQueueEntryState,
    BatchTask,
)
from app.services.batch_input_store import (
    BatchInputBatch,
    BatchInputError,
    BatchInputItem,
    BatchInputStore,
)


logger = logging.getLogger(__name__)


class BatchPersistenceError(BatchInputError):
    """Raised when a finalized snapshot cannot be published to the queue."""

    def __init__(self, message: str = "Unable to create batch task") -> None:
        super().__init__("BATCH_SNAPSHOT_FAILED", 500, message)


class BatchRepository:
    """Persist and query batch records using one caller-provided session.

    ``create_from_snapshot`` owns the outer transaction and therefore requires
    a clean session.  Keeping creation on a fresh session is important on
    SQLite: ``BEGIN IMMEDIATE`` must be the first statement so allocation of
    ``queue_seq`` and insertion of the queue row share the same write lock.
    """

    def __init__(self, session: AsyncSession, input_store: BatchInputStore) -> None:
        self.session = session
        self.input_store = input_store

    async def create_from_snapshot(
        self,
        snapshot: BatchInputBatch,
        *,
        user_id: str,
    ) -> BatchTask:
        """Atomically publish one finalized snapshot as queued ORM records.

        All database failures are mapped to ``BATCH_SNAPSHOT_FAILED``.  The
        transaction is rolled back before best-effort deletion of the formal
        snapshot directory.  Startup orphan cleanup remains the fallback if a
        locked file prevents immediate deletion.
        """

        try:
            self._validate_snapshot(snapshot)
        except asyncio.CancelledError:
            # Cancellation before the database transaction still owns the
            # finalized upload directory.  Clean it up, then preserve the
            # cancellation semantics for the caller.
            self._cleanup_snapshot(snapshot)
            raise
        except BatchPersistenceError:
            self._cleanup_snapshot(snapshot)
            raise
        except Exception as exc:
            # A caller may pass a hand-built/partially deserialized snapshot.
            # Do not leak AttributeError/TypeError (or an implementation
            # detail from a custom path object) across the persistence API:
            # every rejected snapshot has the stable business error code and
            # receives the same best-effort cleanup as an ordinary validation
            # failure.
            self._cleanup_snapshot(snapshot)
            raise BatchPersistenceError("Snapshot metadata is invalid") from exc

        if self.session.in_transaction():
            self._cleanup_snapshot(snapshot)
            raise BatchPersistenceError(
                "Batch creation requires a database session without an active transaction"
            )

        committed = False
        try:
            await self._begin_creation_transaction()
            queue_seq = await self._allocate_queue_seq()

            batch_task = BatchTask(
                id=snapshot.batch_task_id,
                user_id=user_id,
                status=BatchTaskStatus.QUEUED.value,
                project_root=_normalized_path(snapshot.project_root),
                cancel_requested=False,
                progress=0,
                version=1,
            )
            batch_task.items = [
                BatchItem(
                    id=item.item_id,
                    batch_task_id=snapshot.batch_task_id,
                    sequence=item.sequence,
                    filename=item.filename,
                    source_path=item.source_path,
                    relative_path=item.relative_path,
                    snapshot_path=item.snapshot_path,
                    content_hash=item.content_hash,
                    status=BatchItemStatus.QUEUED.value,
                    progress=0,
                    resume_required=False,
                )
                for item in snapshot.items
            ]
            batch_task.queue_entry = BatchQueueEntry(
                batch_task_id=snapshot.batch_task_id,
                queue_seq=queue_seq,
                state=BatchQueueEntryState.QUEUED.value,
            )

            self.session.add(batch_task)
            await self.session.flush()
            await self.session.commit()
            committed = True
            return batch_task
        except asyncio.CancelledError:
            await self._rollback_after_failure(snapshot.batch_task_id)
            raise
        except Exception as exc:
            await self._rollback_after_failure(snapshot.batch_task_id)
            if isinstance(exc, BatchPersistenceError):
                raise
            raise BatchPersistenceError() from exc
        finally:
            if not committed:
                self._cleanup_snapshot(snapshot)

    def _validate_snapshot(self, snapshot: BatchInputBatch) -> None:
        """Validate the immutable snapshot contract before touching the DB.

        ``BatchInputStore`` normally creates objects satisfying these rules,
        but keeping the guard at the persistence boundary prevents a malformed
        or hand-built object from publishing an unexecutable queue entry.
        """

        if not isinstance(snapshot, BatchInputBatch):
            raise BatchPersistenceError("Snapshot object is invalid")

        batch_id = snapshot.batch_task_id
        if not _is_uuid4(batch_id):
            raise BatchPersistenceError("Snapshot batch ID is invalid")
        if not isinstance(snapshot.project_root, str) or not snapshot.project_root.strip():
            raise BatchPersistenceError("Snapshot project root is invalid")
        if not snapshot.items:
            raise BatchPersistenceError("Snapshot must contain at least one Item")

        sequences: list[int] = []
        item_ids: set[str] = set()
        project_root = _normalized_path(snapshot.project_root)
        if not os.path.isabs(project_root):
            raise BatchPersistenceError("Snapshot project root must be absolute")
        snapshot_root = _normalized_path(str(self.input_store.snapshot_root))

        for expected_sequence, item in enumerate(snapshot.items):
            if not isinstance(item, BatchInputItem):
                raise BatchPersistenceError(
                    f"Snapshot Item object is invalid at sequence {expected_sequence}"
                )
            if not isinstance(item.item_id, str) or not _is_uuid4(item.item_id):
                raise BatchPersistenceError(
                    f"Snapshot Item ID is invalid at sequence {expected_sequence}"
                )
            if item.item_id in item_ids:
                raise BatchPersistenceError(
                    f"Snapshot Item ID is duplicated: {item.item_id}"
                )
            item_ids.add(item.item_id)

            if isinstance(item.sequence, bool) or not isinstance(item.sequence, int):
                raise BatchPersistenceError(
                    f"Snapshot Item sequence is invalid at index {expected_sequence}"
                )
            sequences.append(item.sequence)
            if item.sequence != expected_sequence:
                raise BatchPersistenceError(
                    "Snapshot Item sequences must be contiguous and ordered from zero"
                )

            if not isinstance(item.filename, str) or not item.filename.strip():
                raise BatchPersistenceError(
                    f"Snapshot filename is invalid at sequence {expected_sequence}"
                )
            if not isinstance(item.source_path, str) or not item.source_path.strip():
                raise BatchPersistenceError(
                    f"Snapshot source path is invalid at sequence {expected_sequence}"
                )
            if not isinstance(item.relative_path, str) or not item.relative_path.strip():
                raise BatchPersistenceError(
                    f"Snapshot relative path is invalid at sequence {expected_sequence}"
                )
            if not isinstance(item.snapshot_path, str) or not item.snapshot_path.strip():
                raise BatchPersistenceError(
                    f"Snapshot content path is invalid at sequence {expected_sequence}"
                )
            if isinstance(item.size, bool) or not isinstance(item.size, int) or item.size < 1:
                raise BatchPersistenceError(
                    f"Snapshot size is invalid at sequence {expected_sequence}"
                )
            if item.content_hash is not None and (
                not isinstance(item.content_hash, str) or not item.content_hash.strip()
            ):
                raise BatchPersistenceError(
                    f"Snapshot content hash is invalid at sequence {expected_sequence}"
                )

            source_path = _normalized_path(item.source_path)
            if not os.path.isabs(source_path):
                raise BatchPersistenceError(
                    f"Snapshot source path must be absolute at sequence {expected_sequence}"
                )
            if not _is_within_path(source_path, project_root):
                raise BatchPersistenceError(
                    f"Snapshot source path is outside project root at sequence {expected_sequence}"
                )
            if not _same_path_component(Path(source_path).name, item.filename):
                raise BatchPersistenceError(
                    f"Snapshot filename does not match source path at sequence {expected_sequence}"
                )
            expected_relative = _normalized_path(os.path.relpath(source_path, project_root))
            if _path_key(expected_relative) != _path_key(_normalized_path(item.relative_path)):
                raise BatchPersistenceError(
                    f"Snapshot relative path does not match project root at sequence {expected_sequence}"
                )

            content_path = _normalized_path(item.snapshot_path)
            try:
                content_relative = Path(content_path).relative_to(Path(snapshot_root))
            except ValueError as exc:
                raise BatchPersistenceError(
                    f"Snapshot content path is outside snapshot root at sequence {expected_sequence}"
                ) from exc
            expected_parts = (batch_id, "items", item.item_id, "content.bin")
            if len(content_relative.parts) != len(expected_parts) or any(
                not _same_path_component(actual, expected)
                for actual, expected in zip(content_relative.parts, expected_parts)
            ):
                raise BatchPersistenceError(
                    f"Snapshot content path identity mismatch at sequence {expected_sequence}"
                )
            path = Path(content_path)
            try:
                if path.is_symlink() or not path.is_file():
                    raise BatchPersistenceError(
                        f"Snapshot content file is missing or unsafe at sequence {expected_sequence}"
                    )
                actual_size = path.stat().st_size
            except BatchPersistenceError:
                raise
            except (OSError, ValueError) as exc:
                raise BatchPersistenceError(
                    f"Snapshot content file cannot be read at sequence {expected_sequence}"
                ) from exc
            if actual_size != item.size:
                raise BatchPersistenceError(
                    f"Snapshot content size mismatch at sequence {expected_sequence}"
                )

        if sequences != list(range(len(snapshot.items))):
            raise BatchPersistenceError(
                "Snapshot Item sequences must be contiguous and ordered from zero"
            )

    async def create_batch(
        self,
        snapshot: BatchInputBatch,
        *,
        user_id: str,
    ) -> BatchTask:
        """Compatibility name for :meth:`create_from_snapshot`."""

        return await self.create_from_snapshot(snapshot, user_id=user_id)

    async def _begin_creation_transaction(self) -> None:
        bind = self.session.get_bind()
        if bind.dialect.name == "sqlite":
            # SQLite has no SELECT ... FOR UPDATE.  Reserving the write lock
            # before MAX(queue_seq) prevents concurrent creators from choosing
            # the same value while keeping the critical section short.
            await self.session.execute(text("BEGIN IMMEDIATE"))
            return
        await self.session.begin()

    async def _allocate_queue_seq(self) -> int:
        current_max = await self.session.scalar(
            select(func.max(BatchQueueEntry.queue_seq))
        )
        return int(current_max or 0) + 1

    async def _rollback_after_failure(self, batch_task_id: str) -> None:
        try:
            await self.session.rollback()
        except Exception:
            logger.exception(
                "Failed to roll back BatchTask creation for %s", batch_task_id
            )

    def _cleanup_snapshot(self, snapshot: BatchInputBatch) -> None:
        try:
            self.input_store.cleanup_snapshot(snapshot)
            # If metadata itself is malformed (for example the batch ID no
            # longer agrees with the directory name), the store cannot derive
            # the owner directory from the BatchInputBatch.  Fall back to the
            # item paths; BatchInputStore still restricts each cleanup to a
            # direct child of the configured snapshot root.
            items = getattr(snapshot, "items", ())
            # A malformed hand-built snapshot may contain ``None`` or a
            # scalar instead of the immutable tuple produced by
            # BatchInputStore.  Cleanup is best effort and must never mask the
            # original validation/persistence error in those cases.
            if items is None or isinstance(items, (str, bytes, bytearray)):
                items = ()
            try:
                item_iter = iter(items)
            except TypeError:
                item_iter = iter(())
            for item in item_iter:
                self.input_store.cleanup_snapshot(item.snapshot_path)
        except Exception:
            logger.exception(
                "Failed to clean finalized snapshot for BatchTask %s",
                getattr(snapshot, "batch_task_id", "<unknown>"),
            )


async def persist_batch_snapshot(
    snapshot: BatchInputBatch,
    *,
    user_id: str,
    input_store: BatchInputStore,
    session_factory: Callable[[], Any] | None = None,
) -> BatchTask:
    """Publish a snapshot using a fresh, repository-owned database session."""

    if session_factory is None:
        from app.core.database import async_session_factory

        session_factory = async_session_factory

    async with session_factory() as session:
        repository = BatchRepository(session, input_store)
        return await repository.create_from_snapshot(snapshot, user_id=user_id)


def _is_uuid4(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError, TypeError):
        return False
    return parsed.version == 4 and str(parsed) == value


def _normalized_path(value: str) -> str:
    """Normalize a path lexically without resolving symlinks."""

    normalized = os.path.normpath(str(value).strip())
    if os.name == "nt":
        drive, tail = os.path.splitdrive(normalized)
        if drive:
            normalized = drive.upper() + tail
        # Keep persisted paths portable/readable while retaining Windows
        # case-insensitive comparison through _path_key.
        normalized = normalized.replace("\\", "/")
    return normalized


def _path_key(value: str) -> str:
    normalized = os.path.normcase(os.path.normpath(value))
    return normalized.casefold() if os.name == "nt" else normalized


def _same_path_component(left: str, right: str) -> bool:
    return str(left).casefold() == str(right).casefold() if os.name == "nt" else left == right


def _is_within_path(path: str, root: str) -> bool:
    try:
        return _path_key(os.path.commonpath([path, root])) == _path_key(root)
    except (ValueError, OSError):
        return False


__all__ = [
    "BatchPersistenceError",
    "BatchRepository",
    "persist_batch_snapshot",
]
