"""
@file session.py
@author caoshwen
@brief SessionRepository - session CRUD operations.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.session import Message, Session
from app.repositories.base import BaseRepository


class SessionRepository(BaseRepository[Session]):
    model_class = Session

    async def get_by_user(
        self,
        user_id: str,
        agent_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> List[Session]:
        """Get user session list (sorted by update time descending)"""
        filters = [Session.user_id == user_id]
        if agent_type:
            filters.append(Session.agent_type == agent_type)
        return await self.get_all(
            filters=filters,
            order_by=Session.updated_at.desc(),
            limit=limit,
            offset=offset,
        )

    async def count_by_user(
        self,
        user_id: str,
        agent_type: Optional[str] = None,
    ) -> int:
        """Count user sessions"""
        filters = [Session.user_id == user_id]
        if agent_type:
            filters.append(Session.agent_type == agent_type)
        return await self.count(filters=filters)

    async def get_with_messages(self, session_id: str) -> Optional[Session]:
        """Get session details (with messages eager loading)"""
        result = await self.session.execute(
            select(Session)
            .where(Session.id == session_id)
            .options(selectinload(Session.messages))
        )
        return result.scalar_one_or_none()

    async def get_user_session(self, session_id: str, user_id: str) -> Optional[Session]:
        """Get session belonging to specified user (permission check)"""
        result = await self.session.execute(
            select(Session).where(
                Session.id == session_id,
                Session.user_id == user_id,
            )
        )
        return result.scalar_one_or_none()

    async def update_summary(self, session_id: str, summary: str) -> Optional[Session]:
        """Update session context summary"""
        return await self.update(session_id, {"summary": summary})

    async def increment_message_count(self, session_id: str) -> Optional[Session]:
        """Increment message count"""
        entity = await self.get_by_id(session_id)
        if entity is None:
            return None
        entity.message_count = (entity.message_count or 0) + 1
        await self.session.flush()
        await self.session.refresh(entity)
        return entity


class MessageRepository(BaseRepository[Message]):
    model_class = Message

    async def get_by_session(
        self,
        session_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Message]:
        """Get session message list (sorted by time ascending)"""
        return await self.get_all(
            filters=[Message.session_id == session_id],
            order_by=Message.created_at.asc(),
            limit=limit,
            offset=offset,
        )

    async def count_by_session(self, session_id: str) -> int:
        """Count session messages"""
        return await self.count(filters=[Message.session_id == session_id])

    async def get_recent_messages(
        self,
        session_id: str,
        limit: int = 10,
    ) -> List[Message]:
        """Get N most recent messages from session (sorted by time descending, for context building)"""
        return await self.get_all(
            filters=[Message.session_id == session_id],
            order_by=Message.created_at.desc(),
            limit=limit,
        )

    async def get_token_total(self, session_id: str) -> int:
        """Count total tokens in session"""
        result = await self.session.execute(
            select(func.sum(Message.token_count))
            .where(Message.session_id == session_id)
        )
        return result.scalar() or 0
