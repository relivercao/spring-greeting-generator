"""SQL-side filtered usage summaries, grouping, and stable pagination."""

from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import case, func, select

from app.models.llm_usage import LLMUsageLog as Usage


def utc_datetime(value):
    if value is None:
        return None
    if value.tzinfo is None:
        return value
    return value.astimezone(timezone.utc).replace(tzinfo=None)


def usage_filters(*, user_id=None, date_from=None, date_to=None, provider=None,
                  model=None, agent_name=None, status=None, workflow_id=None, session_id=None):
    start, end = utc_datetime(date_from), utc_datetime(date_to)
    if start and end and start >= end:
        raise HTTPException(422, "Start time must be before end time")
    filters = []
    for column, value in ((Usage.user_id, user_id), (Usage.provider, provider),
                          (Usage.model, model), (Usage.agent_name, agent_name),
                          (Usage.status, status), (Usage.workflow_id, workflow_id),
                          (Usage.session_id, session_id)):
        if value is not None:
            filters.append(column == value)
    if start:
        filters.append(Usage.created_at >= start)
    if end:
        filters.append(Usage.created_at < end)
    return filters


def aggregates():
    return [
        func.count().label("requests"),
        func.coalesce(func.sum(Usage.total_tokens), 0).label("total_tokens"),
        func.coalesce(func.sum(Usage.prompt_tokens), 0).label("input_tokens"),
        func.coalesce(func.sum(Usage.completion_tokens), 0).label("output_tokens"),
        func.coalesce(func.sum(Usage.cache_read_tokens), 0).label("cache_read_tokens"),
        func.coalesce(func.sum(Usage.cache_write_tokens), 0).label("cache_write_tokens"),
        func.coalesce(func.sum(Usage.cost_usd), 0).label("cost_usd"),
        func.coalesce(func.sum(Usage.charged_cny), 0).label("charged_cny"),
        func.coalesce(func.avg(Usage.latency_ms), 0).label("avg_latency_ms"),
        func.coalesce(func.sum(case((Usage.status == "failed", 1), else_=0)), 0).label("failed_requests"),
        func.coalesce(func.sum(case((Usage.usage_source == "estimated", 1), else_=0)), 0).label("estimated_requests"),
        func.coalesce(func.sum(case((Usage.usage_source.in_(["legacy", "unavailable"]), 1), else_=0)), 0).label("unknown_usage_requests"),
        func.coalesce(func.sum(case((Usage.pricing_source.in_(["legacy", "unpriced"]), 1), else_=0)), 0).label("unpriced_requests"),
    ]


async def report(db, filters, *, page=1, page_size=20, group_by="model"):
    summary = dict((await db.execute(select(*aggregates()).where(*filters))).mappings().one())
    column = {"model": Usage.model, "agent": Usage.agent_name,
              "provider": Usage.provider, "day": func.date(Usage.created_at)}[group_by]
    grouped_query = select(column.label("name"), *aggregates()).where(*filters).group_by(column)
    groups = (await db.execute(grouped_query.order_by(func.sum(Usage.cost_usd).desc(), column).limit(100))).mappings().all()
    rows = (await db.scalars(select(Usage).where(*filters).order_by(
        Usage.created_at.desc(), Usage.id.desc(),
    ).offset((page - 1) * page_size).limit(page_size))).all()
    return dict(summary=summary, groups=[dict(group) for group in groups],
                group_limit=100, items=[serialize_usage(row) for row in rows],
                total=summary["requests"], page=page, page_size=page_size)


def serialize_usage(row):
    # Never expose raw provider errors, prompts, completions, or tool content.
    keys = ("id", "user_id", "workflow_id", "session_id", "agent_name", "provider", "model",
            "prompt_tokens", "completion_tokens", "total_tokens", "cache_read_tokens",
            "cache_write_tokens", "latency_ms", "cost_usd", "charged_cny", "status",
            "usage_source", "pricing_source")
    result = {key: getattr(row, key) for key in keys}
    result["created_at"] = row.created_at.replace(tzinfo=timezone.utc).isoformat()
    return result


async def find_usage(db, usage_id, *, user_id=None):
    query = select(Usage).where(Usage.id == usage_id)
    if user_id is not None:
        query = query.where(Usage.user_id == user_id)
    return await db.scalar(query)


async def usage_transactions(db, row):
    """Match ledger entries by both usage reference and original owner."""
    from app.models.balance_transaction import BalanceTransaction, TransactionType

    return (await db.scalars(select(BalanceTransaction).where(
        BalanceTransaction.reference_id == row.id,
        BalanceTransaction.user_id == row.user_id,
        BalanceTransaction.type == TransactionType.USAGE,
    ).order_by(BalanceTransaction.created_at, BalanceTransaction.id))).all()
