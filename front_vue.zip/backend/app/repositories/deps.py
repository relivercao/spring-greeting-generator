"""
@file deps.py
@author caoshwen
@brief Dependency injection factory functions for repositories.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import AsyncGenerator

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.repositories.user import UserRepository
from app.repositories.session import SessionRepository, MessageRepository
from app.repositories.task import TaskRepository
from app.repositories.llm_usage import LLMUsageLogRepository
from app.repositories.payment_order import PaymentOrderRepository
from app.repositories.recharge_plan import RechargePlanRepository
from app.repositories.payment_provider import PaymentProviderRepository
from app.repositories.balance_transaction import BalanceTransactionRepository
from app.repositories.redeem_code import RedeemCodeRepository
from app.repositories.app_setting import AppSettingRepository


async def get_user_repo(
    db: AsyncSession = Depends(get_db),
) -> UserRepository:
    return UserRepository(db)


async def get_session_repo(
    db: AsyncSession = Depends(get_db),
) -> SessionRepository:
    return SessionRepository(db)


async def get_message_repo(
    db: AsyncSession = Depends(get_db),
) -> MessageRepository:
    return MessageRepository(db)


async def get_task_repo(
    db: AsyncSession = Depends(get_db),
) -> TaskRepository:
    return TaskRepository(db)


async def get_llm_usage_repo(
    db: AsyncSession = Depends(get_db),
) -> LLMUsageLogRepository:
    return LLMUsageLogRepository(db)


async def get_payment_order_repo(
    db: AsyncSession = Depends(get_db),
) -> PaymentOrderRepository:
    return PaymentOrderRepository(db)


async def get_recharge_plan_repo(
    db: AsyncSession = Depends(get_db),
) -> RechargePlanRepository:
    return RechargePlanRepository(db)


async def get_payment_provider_repo(
    db: AsyncSession = Depends(get_db),
) -> PaymentProviderRepository:
    return PaymentProviderRepository(db)


async def get_balance_transaction_repo(
    db: AsyncSession = Depends(get_db),
) -> BalanceTransactionRepository:
    return BalanceTransactionRepository(db)


async def get_redeem_code_repo(
    db: AsyncSession = Depends(get_db),
) -> RedeemCodeRepository:
    return RedeemCodeRepository(db)


async def get_app_setting_repo(
    db: AsyncSession = Depends(get_db),
) -> AppSettingRepository:
    return AppSettingRepository(db)
