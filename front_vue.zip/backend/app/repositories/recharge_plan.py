"""Repository for preset recharge plans."""

from __future__ import annotations

from typing import List

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.recharge_plan import RechargePlan
from app.repositories.base import BaseRepository


class RechargePlanRepository(BaseRepository[RechargePlan]):
    """CRUD for recharge plans plus the storefront listing."""

    model_class = RechargePlan

    async def list_for_sale(self) -> List[RechargePlan]:
        """List plans currently offered on the recharge page."""
        query = (
            select(RechargePlan)
            .where(RechargePlan.for_sale.is_(True))
            .order_by(RechargePlan.sort_order.asc())
        )
        result = await self.session.execute(query)
        return list(result.scalars().all())
