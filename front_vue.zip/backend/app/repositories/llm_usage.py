"""
@file llm_usage.py
@author caoshwen
@brief LLMUsageRepository - LLM usage log CRUD operations.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.llm_usage import LLMUsageLog
from app.repositories.base import BaseRepository


class LLMUsageLogRepository(BaseRepository[LLMUsageLog]):
    model_class = LLMUsageLog

    async def get_by_session(self, session_id: str) -> List[LLMUsageLog]:
        """Get all LLM call records for a session"""
        return await self.get_all(
            filters=[LLMUsageLog.session_id == session_id],
            order_by=LLMUsageLog.created_at.desc(),
        )

    async def get_by_workflow(self, workflow_id: str) -> List[LLMUsageLog]:
        """Get all LLM call records for a workflow"""
        return await self.get_all(
            filters=[LLMUsageLog.workflow_id == workflow_id],
            order_by=LLMUsageLog.created_at.desc(),
        )

    async def get_by_provider(
        self,
        provider: str,
        limit: int = 100,
        offset: int = 0,
    ) -> List[LLMUsageLog]:
        """Query call records by Provider"""
        return await self.get_all(
            filters=[LLMUsageLog.provider == provider],
            order_by=LLMUsageLog.created_at.desc(),
            limit=limit,
            offset=offset,
        )

    async def get_usage_stats(
        self,
        provider: Optional[str] = None,
        agent_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Get usage statistics summary.

        Returns:
            {
                "total_calls": int,
                "total_tokens": int,
                "total_prompt_tokens": int,
                "total_completion_tokens": int,
                "total_cost_usd": float,
                "avg_latency_ms": float,
                "failed_calls": int,
            }
        """
        filters = []
        if provider:
            filters.append(LLMUsageLog.provider == provider)
        if agent_name:
            filters.append(LLMUsageLog.agent_name == agent_name)

        query = select(
            func.count().label("total_calls"),
            func.sum(LLMUsageLog.total_tokens).label("total_tokens"),
            func.sum(LLMUsageLog.prompt_tokens).label("total_prompt_tokens"),
            func.sum(LLMUsageLog.completion_tokens).label("total_completion_tokens"),
            func.sum(LLMUsageLog.cost_usd).label("total_cost_usd"),
            func.avg(LLMUsageLog.latency_ms).label("avg_latency_ms"),
        ).select_from(LLMUsageLog)

        for f in filters:
            query = query.where(f)

        result = await self.session.execute(query)
        row = result.one()

        # Count failed calls
        failed_filters = filters + [LLMUsageLog.status == "failed"]
        failed_count = await self.count(filters=failed_filters)

        return {
            "total_calls": row.total_calls or 0,
            "total_tokens": row.total_tokens or 0,
            "total_prompt_tokens": row.total_prompt_tokens or 0,
            "total_completion_tokens": row.total_completion_tokens or 0,
            "total_cost_usd": round(float(row.total_cost_usd or 0), 6),
            "avg_latency_ms": round(float(row.avg_latency_ms or 0), 2),
            "failed_calls": failed_count,
        }
