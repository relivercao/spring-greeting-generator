"""
@file base.py
@author caoshwen
@brief BaseRepository - generic async CRUD operations.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar

from sqlalchemy import func, select, delete as sa_delete
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import Base

T = TypeVar("T", bound=Base)


class BaseRepository(ABC, Generic[T]):
    """
    Generic base repository.

    Subclasses only need to specify `model_class` to get full CRUD capabilities.
    Add business methods in subclasses for custom queries.

    Usage:
        class UserRepository(BaseRepository[User]):
            model_class = User
    """

    model_class: Type[T]

    def __init__(self, session: AsyncSession):
        self.session = session

    # ==================== Core CRUD Interface ====================

    async def create(self, entity: T) -> T:
        """Create a single entity"""
        self.session.add(entity)
        await self.session.flush()
        await self.session.refresh(entity)
        return entity

    async def get_by_id(self, id: str) -> Optional[T]:
        """Query by primary key"""
        result = await self.session.execute(
            select(self.model_class).where(self.model_class.id == id)
        )
        return result.scalar_one_or_none()

    async def get_all(
        self,
        filters: Optional[List] = None,
        order_by: Optional[Any] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[T]:
        """
        Query list with conditions.

        Args:
            filters: SQLAlchemy where condition list, e.g. [User.is_active == True]
            order_by: Sort condition, e.g. User.created_at.desc()
            limit: Maximum number of results
            offset: Pagination offset
        """
        query = select(self.model_class)

        if filters:
            for f in filters:
                query = query.where(f)

        if order_by is not None:
            query = query.order_by(order_by)

        query = query.offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all())

    async def update(self, id: str, updates: Dict[str, Any]) -> Optional[T]:
        """
        Update fields by primary key.

        Args:
            id: Entity primary key
            updates: Dictionary of fields to update, e.g. {"username": "new_name"}

        Returns:
            Updated entity, None if entity does not exist
        """
        entity = await self.get_by_id(id)
        if entity is None:
            return None

        for key, value in updates.items():
            if hasattr(entity, key):
                setattr(entity, key, value)

        await self.session.flush()
        await self.session.refresh(entity)
        return entity

    async def delete(self, id: str) -> bool:
        """Delete by primary key"""
        entity = await self.get_by_id(id)
        if entity is None:
            return False
        await self.session.delete(entity)
        await self.session.flush()
        return True

    # ==================== Bulk Operations ====================

    async def bulk_create(self, entities: List[T]) -> List[T]:
        """Bulk create"""
        self.session.add_all(entities)
        await self.session.flush()
        for entity in entities:
            await self.session.refresh(entity)
        return entities

    async def bulk_delete(self, ids: List[str]) -> int:
        """Bulk delete, returns number of rows deleted"""
        if not ids:
            return 0
        result = await self.session.execute(
            sa_delete(self.model_class).where(self.model_class.id.in_(ids))
        )
        await self.session.flush()
        return result.rowcount

    # ==================== Query Helpers ====================

    async def count(self, filters: Optional[List] = None) -> int:
        """Count with conditions"""
        query = select(func.count()).select_from(self.model_class)
        if filters:
            for f in filters:
                query = query.where(f)
        result = await self.session.execute(query)
        return result.scalar() or 0

    async def exists(self, id: str) -> bool:
        """Check if entity exists"""
        query = select(func.count()).select_from(self.model_class).where(
            self.model_class.id == id
        )
        result = await self.session.execute(query)
        return (result.scalar() or 0) > 0

    # ==================== Lifecycle ====================

    async def health_check(self) -> Dict[str, Any]:
        """Health check -- execute simple count query to verify connectivity"""
        try:
            total = await self.count()
            return {
                "status": "healthy",
                "table": self.model_class.__tablename__,
                "row_count": total,
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "table": self.model_class.__tablename__,
                "error": str(e),
            }
