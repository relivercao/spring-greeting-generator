﻿"""Runtime dependency checks for the native Docling/OCR stack."""

from __future__ import annotations

import importlib.metadata as metadata
import importlib.util
from typing import Any, Callable

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version


CRITICAL_RUNTIME_REQUIREMENTS: dict[str, str] = {
    "docling": "==2.115.0",
    "docling-core": "==2.86.0",
    "docling-ibm-models": "==3.13.3",
    "docling-parse": "==7.2.0",
    "easyocr": "==1.7.2",
    "rapidocr": "==3.9.1",
    "opencv-python": "==4.13.0.92",
    "torch": "==2.12.1",
    "torchvision": "==0.27.1",
    "transformers": "==5.12.1",
    "accelerate": "==1.14.0",
    "pypdfium2": "==5.11.0",
    "Pillow": ">=12.0.0,<13.0.0",
    "pandas": "==3.0.3",
    "numpy": "==2.4.6",
    "rich": "==15.0.0",
}

CRITICAL_RUNTIME_IMPORTS: dict[str, str] = {
    "docling.document_converter": "DocumentConverter",
    "rapidocr": "RapidOCR",
    "easyocr": "easyocr",
}


def check_docling_runtime(
    required: dict[str, str] | None = None,
    version_lookup: Callable[[str], str] | None = None,
    import_lookup: Callable[[str], Any] | None = None,
) -> dict:
    """Return a deterministic report for the native Docling/OCR dependencies.

    The default runtime check validates both distribution metadata and the
    modules used by the application.  Tests can provide a version or import
    lookup without importing heavyweight ML packages.
    """
    expected = required or CRITICAL_RUNTIME_REQUIREMENTS
    lookup = version_lookup or metadata.version
    packages: dict[str, dict[str, str | bool]] = {}
    imports: dict[str, dict[str, str | bool]] = {}
    problems: list[str] = []

    for distribution, specifier in expected.items():
        try:
            installed = lookup(distribution)
        except metadata.PackageNotFoundError:
            packages[distribution] = {
                "required": specifier,
                "installed": "",
                "ok": False,
            }
            problems.append(f"{distribution} is not installed (required {specifier})")
            continue
        except Exception as exc:
            packages[distribution] = {
                "required": specifier,
                "installed": "",
                "ok": False,
            }
            problems.append(f"{distribution} version lookup failed: {exc}")
            continue

        try:
            matches = Version(installed) in SpecifierSet(specifier)
        except (InvalidSpecifier, InvalidVersion):
            matches = False
        packages[distribution] = {
            "required": specifier,
            "installed": installed,
            "ok": matches,
        }
        if not matches:
            requirement_label = specifier.removeprefix("==")
            problems.append(
                f"{distribution} requires {requirement_label}, installed {installed}"
            )

    # Keep custom version-only checks lightweight for unit tests.  Production
    # startup uses the default importer and therefore catches broken wheels or
    # namespace-package collisions that metadata checks cannot see.
    if import_lookup is not None or (required is None and version_lookup is None):
        for module_name, symbol_name in CRITICAL_RUNTIME_IMPORTS.items():
            try:
                if import_lookup is None:
                    if importlib.util.find_spec(module_name) is None:
                        raise ModuleNotFoundError(module_name)
                else:
                    import_lookup(module_name)
            except Exception as exc:
                imports[module_name] = {
                    "symbol": symbol_name,
                    "ok": False,
                    "error": f"{type(exc).__name__}: {exc}",
                }
                problems.append(
                    f"{module_name} import failed ({type(exc).__name__}: {exc})"
                )
            else:
                imports[module_name] = {"symbol": symbol_name, "ok": True}

    return {
        "ok": not problems,
        "packages": packages,
        "imports": imports,
        "problems": problems,
    }
