"""
@file audit_middleware.py
@author caoshwen
@brief Audit logging middleware for tracking user actions.

@version 3.2
@date 2026-07-25

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
from typing import Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from app.infrastructure.observability.logger import LoggerService
from app.models.audit_log import AuditAction, AuditResult

log = LoggerService.get_logger("audit")


class AuditMiddleware(BaseHTTPMiddleware):
    """
    Middleware to log all user actions to audit_logs table.
    
    Logs:
    - User authentication events
    - API endpoint access
    - Resource modifications
    - Failed/denied requests
    """
    
    # Endpoints that should be audited
    AUDIT_PATHS = {
        "/api/v1/auth/login": AuditAction.USER_LOGIN,
        "/api/v1/auth/logout": AuditAction.USER_LOGOUT,
        "/api/v1/auth/register": AuditAction.USER_REGISTER,
        "/api/v1/chat": AuditAction.CHAT_CREATE,
        "/api/v1/sessions": AuditAction.SESSION_CREATE,
        "/api/v1/settings": AuditAction.SETTINGS_UPDATE,
    }
    
    # Skip audit for these paths
    SKIP_PATHS = {
        "/health",
        "/metrics",
        "/",
        "/docs",
        "/openapi.json",
        "/api/v1/health",
    }
    
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Skip non-auditable paths
        if request.url.path in self.SKIP_PATHS:
            return await call_next(request)
        
        # Skip GET requests to reduce noise (optional, can be configured)
        if request.method == "GET" and not request.url.path.startswith("/api/v1/settings"):
            return await call_next(request)
        
        # Extract user info
        user_id = "anonymous"
        username = "anonymous"
        
        # Try to get user from request state (set by auth dependency)
        if hasattr(request.state, "user"):
            user = request.state.user
            user_id = getattr(user, "id", "anonymous")
            username = getattr(user, "username", "anonymous")
        else:
            # Try to extract from Authorization header
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                try:
                    from app.core.security import decode_token
                    token = auth_header[7:]
                    payload = decode_token(token)
                    user_id = payload.get("user_id", "anonymous")
                    username = payload.get("sub", "anonymous")
                except Exception:
                    pass
        
        # Determine action
        action = self._get_action(request)
        
        # Get IP and user agent
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get("User-Agent")
        
        # Execute request
        start_time = time.time()
        response = await call_next(request)
        duration_ms = (time.time() - start_time) * 1000
        
        # Determine result based on status code
        result = self._get_result(response.status_code)
        
        # Log to audit table (async, non-blocking)
        try:
            await self._log_audit(
                user_id=user_id,
                username=username,
                action=action,
                result=result,
                ip_address=ip_address,
                user_agent=user_agent,
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                duration_ms=duration_ms,
            )
        except Exception as e:
            # Audit logging should not break the request
            log.error("Failed to write audit log", error=str(e))
        
        return response
    
    def _get_action(self, request: Request) -> str:
        """Determine action type from request."""
        path = request.url.path
        method = request.method
        
        # Check exact path match
        if path in self.AUDIT_PATHS:
            return self.AUDIT_PATHS[path]
        
        # Pattern matching for dynamic paths
        if "/api/v1/unittest" in path:
            return "agent.unittest"
        elif "/api/v1/driver" in path:
            return "agent.driver"
        elif "/api/v1/build" in path:
            return "agent.build"
        elif "/api/v1/bugfix" in path:
            return "agent.bugfix"
        elif "/api/v1/debug" in path:
            return "agent.debug"
        elif "/api/v1/review" in path:
            return "agent.review"
        elif "/api/v1/tasks" in path:
            if method == "DELETE":
                return AuditAction.TASK_DELETE
            return AuditAction.TASK_CREATE
        elif "/api/v1/sessions" in path:
            if method == "DELETE":
                return AuditAction.SESSION_DELETE
            return AuditAction.SESSION_CREATE
        
        # Default
        return f"{method.lower()}.{path}"
    
    def _get_result(self, status_code: int) -> str:
        """Determine result from status code."""
        if 200 <= status_code < 300:
            return AuditResult.SUCCESS
        elif status_code == 401 or status_code == 403:
            return AuditResult.DENIED
        elif status_code == 429:
            return AuditResult.DENIED
        elif status_code >= 400:
            return AuditResult.ERROR
        else:
            return AuditResult.SUCCESS
    
    async def _log_audit(
        self,
        user_id: str,
        username: str,
        action: str,
        result: str,
        ip_address: str,
        user_agent: str,
        method: str,
        path: str,
        status_code: int,
        duration_ms: float,
    ) -> None:
        """Write audit log to database."""
        try:
            from app.core.database import async_session_factory
            from app.repositories.audit_log import AuditLogRepository
            
            async with async_session_factory() as session:
                repo = AuditLogRepository(session)
                await repo.create_log(
                    user_id=user_id,
                    username=username,
                    action=action,
                    result=result,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    details={
                        "method": method,
                        "path": path,
                        "status_code": status_code,
                        "duration_ms": round(duration_ms, 2),
                    }
                )
                await session.commit()
        except Exception as e:
            log.error("Failed to create audit log", error=str(e), action=action)
