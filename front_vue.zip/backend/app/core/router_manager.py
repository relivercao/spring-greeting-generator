"""
@file router_manager.py
@brief Manages the Claude Router subprocess lifecycle.

Starts/stops the Claude Router (claude_router.py) as a background process.
The Router converts Anthropic API requests to Turing Platform format,
allowing Claude CLI to use project-configured LLM providers.
"""
import asyncio
import contextlib
import subprocess
import sys
from pathlib import Path

from loguru import logger


_BACKEND_DIR = Path(__file__).parent.parent.parent
_ROUTER_SCRIPT = _BACKEND_DIR / "claude_router.py"
_ROUTER_PYC = _BACKEND_DIR / "claude_router.pyc"


class RouterManager:
    """Manage Claude Router as a subprocess."""

    def __init__(self, settings, monitor_interval_seconds: float = 5.0):
        self._host = settings.CLAUDE_ROUTER_HOST
        self._port = settings.CLAUDE_ROUTER_PORT
        self._process: subprocess.Popen | None = None
        self._monitor_interval_seconds = monitor_interval_seconds
        self._monitor_task: asyncio.Task | None = None
        self._lifecycle_lock = asyncio.Lock()
        self._stopping = False

    async def start(self) -> bool:
        """Start the Router subprocess if not already running."""
        async with self._lifecycle_lock:
            self._stopping = False
            if await self._probe_router():
                logger.info(
                    f"Claude Router already healthy on {self._host}:{self._port}"
                )
                started = True
            else:
                started = await self._launch_router()

            self._ensure_monitor_running()
            return started

    async def stop(self) -> None:
        """Stop monitoring and terminate the Router subprocess owned by this manager."""
        self._stopping = True
        monitor_task = self._monitor_task
        self._monitor_task = None
        if monitor_task and monitor_task is not asyncio.current_task():
            monitor_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await monitor_task

        async with self._lifecycle_lock:
            await self._terminate_owned_process()

    async def restart(self) -> bool:
        """Restart the Router after provider settings change."""
        async with self._lifecycle_lock:
            if self._process is not None:
                await self._terminate_owned_process()
            elif await self._probe_router():
                await self._terminate_router_port_owner()

            started = await self._launch_router()
            self._ensure_monitor_running()
            return started

    async def health_check(self) -> dict:
        """Return Router health information for the aggregated health endpoint."""
        healthy = await self._probe_router()
        process_alive = self._process is not None and self._process.poll() is None
        return {
            "healthy": healthy,
            "host": self._host,
            "port": self._port,
            "managed_process_alive": process_alive,
            "managed_pid": self._process.pid if process_alive else None,
        }

    def _ensure_monitor_running(self) -> None:
        """Create the background health monitor once per manager lifecycle."""
        if self._stopping:
            return
        if self._monitor_task is None or self._monitor_task.done():
            self._monitor_task = asyncio.create_task(
                self._monitor_loop(),
                name="claude-router-monitor",
            )

    async def _monitor_loop(self) -> None:
        """Recover the Router whenever its health endpoint becomes unavailable."""
        while not self._stopping:
            await asyncio.sleep(self._monitor_interval_seconds)
            if self._stopping:
                break
            await self._recover_router_if_needed()

    async def _recover_router_if_needed(self) -> bool:
        """Start a fresh Router process when the active instance is unhealthy."""
        if await self._probe_router():
            return True

        async with self._lifecycle_lock:
            if await self._probe_router():
                return True

            logger.warning(
                f"Claude Router unavailable on {self._host}:{self._port}; restarting"
            )
            await self._terminate_owned_process()
            started = await self._launch_router()
            if not started:
                logger.error(
                    f"Claude Router recovery failed on {self._host}:{self._port}"
                )
            return started

    async def _launch_router(self) -> bool:
        """Launch a Router subprocess and wait until its health endpoint is ready."""
        if self._process is not None and self._process.poll() is None:
            return await self._probe_router()

        router_entry = _ROUTER_PYC if _ROUTER_PYC.exists() else _ROUTER_SCRIPT
        if not router_entry.exists():
            logger.warning(f"Router script not found: {router_entry}")
            return False

        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self._process = subprocess.Popen(
            [sys.executable, str(router_entry)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            cwd=str(_BACKEND_DIR),
            creationflags=creation_flags,
        )
        for _ in range(20):
            await asyncio.sleep(0.5)
            if await self._probe_router():
                logger.info(
                    f"Claude Router started on {self._host}:{self._port} "
                    f"(pid={self._process.pid})"
                )
                return True
            if self._process.poll() is not None:
                logger.warning(
                    "Claude Router exited during startup",
                    returncode=self._process.returncode,
                )
                self._process = None
                return False

        logger.warning("Claude Router failed to become healthy within 10s")
        await self._terminate_owned_process()
        return False

    async def _terminate_owned_process(self) -> None:
        """Terminate and reap the Router subprocess started by this manager."""
        process = self._process
        self._process = None
        if process is None or process.poll() is not None:
            return

        process.terminate()
        try:
            await asyncio.to_thread(process.wait, timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            await asyncio.to_thread(process.wait, timeout=5)
        logger.info("Claude Router stopped")

    async def _terminate_router_port_owner(self) -> bool:
        """Terminate an existing Router process that owns the configured port."""
        try:
            import psutil
        except ImportError:
            logger.warning("psutil unavailable; cannot replace existing Claude Router")
            return False

        target_pid = None
        for connection in psutil.net_connections(kind="inet"):
            local_address = getattr(connection, "laddr", None)
            if (
                local_address
                and connection.status == psutil.CONN_LISTEN
                and local_address.port == self._port
            ):
                target_pid = connection.pid
                break

        if not target_pid:
            return True

        try:
            process = psutil.Process(target_pid)
            command_line = " ".join(process.cmdline()).lower()
            if "claude_router.py" not in command_line and "claude_router.pyc" not in command_line:
                logger.warning(
                    "Refusing to terminate a non-Router process on the Router port",
                    pid=target_pid,
                    port=self._port,
                )
                return False

            process.terminate()
            try:
                await asyncio.to_thread(process.wait, timeout=5)
            except psutil.TimeoutExpired:
                process.kill()
                await asyncio.to_thread(process.wait, timeout=5)
            logger.info("Stopped existing Claude Router", pid=target_pid)
            return True
        except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
            logger.warning(
                "Failed to stop existing Claude Router",
                pid=target_pid,
                error=str(exc),
            )
            return False

    async def _probe_router(self) -> bool:
        """Verify that the configured port serves the expected Router health response."""
        try:
            import httpx

            async with httpx.AsyncClient(timeout=1.5) as client:
                response = await client.get(f"http://{self._host}:{self._port}/health")
            if response.status_code != 200:
                return False
            payload = response.json()
            return (
                payload.get("status") == "healthy"
                and payload.get("router") == "claude-router"
            )
        except Exception:
            return False
