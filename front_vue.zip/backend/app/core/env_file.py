"""Read and atomically update the project's environment configuration."""

from __future__ import annotations

import os
import tempfile
import threading
from pathlib import Path

from dotenv import dotenv_values


_ENV_FILE_LOCK = threading.RLock()


def read_env_file(path: Path) -> dict[str, str]:
    """Decode dotenv quoting consistently with application settings reloads."""
    if not path.exists():
        return {}
    return {key: value for key, value in dotenv_values(path, encoding="utf-8").items() if value is not None}


def update_env_file(path: Path, values: dict[str, str]) -> None:
    """Preserve unrelated configuration and reject injected environment lines."""
    with _ENV_FILE_LOCK:
        _update_env_file(path, values)


def _update_env_file(path: Path, values: dict[str, str]) -> None:
    if any("\n" in value or "\r" in value for value in values.values()):
        raise ValueError("Configuration values must use a single line")
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True) if path.exists() else []
    written = set()
    output = []
    for line in lines:
        stripped = line.strip()
        key = stripped.partition("=")[0].strip()
        if not stripped.startswith("#") and "=" in stripped and key in values:
            output.append(f"{key}={values[key]}\n")
            written.add(key)
        else:
            output.append(line)
    if output and not output[-1].endswith("\n"):
        output[-1] += "\n"
    output.extend(f"{key}={value}\n" for key, value in values.items() if key not in written)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as file:
            temporary = Path(file.name)
            file.write("".join(output))
        os.replace(temporary, path)
    finally:
        if temporary and temporary.exists():
            temporary.unlink()
