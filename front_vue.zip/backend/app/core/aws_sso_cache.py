"""
@file aws_sso_cache.py
@author caoshwen
@brief AWS SSO cache management - detect, validate, and refresh SSO credentials.

@version 3.2
@date 2026-04-13

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import configparser
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from loguru import logger


class AWSSSOCache:
    """
    Manages AWS SSO credentials cache.

    Detects token expiration, triggers SSO login, and validates cache files.
    """

    def __init__(self, profile_name: str, region: str = "eu-west-1"):
        self.profile_name = profile_name
        self.region = region
        self.cache_dir = Path.home() / ".aws" / "sso" / "cache"
        self.cli_cache_dir = Path.home() / ".aws" / "cli" / "cache"

    def is_token_valid(self, verify_credentials: bool = True) -> bool:
        """
        Check if current SSO token is valid AND optionally verify real AWS credentials.

        Args:
            verify_credentials: If True, also verify real AWS credentials via aws sts.
                               If False, only check SSO token expiration (faster).

        This method performs two checks:
        1. SSO access token exists and is not expired
        2. (Optional) Real AWS credentials (aws_access_key_id + aws_secret_access_key)
           are available by calling `aws sts get-caller-identity`

        Returns:
            True if SSO token is valid (and credentials if verify_credentials=True), False otherwise.
        """
        try:
            if not self.cache_dir.exists():
                logger.warning("AWS SSO cache directory does not exist")
                return False

            # Get SSO start URL for validation
            sso_start_url = self._get_sso_start_url()
            if not sso_start_url:
                logger.warning("Could not find sso_start_url for profile")
                return False

            # Search all cache files for a valid access token
            cache_files = list(self.cache_dir.glob("*.json"))
            if not cache_files:
                logger.warning("No AWS SSO cache files found")
                return False

            sso_token_valid = False
            for cache_file in cache_files:
                try:
                    with open(cache_file, "r") as f:
                        cache_data = json.load(f)

                    # Check if this file has an accessToken (not just client registration)
                    access_token = cache_data.get("accessToken")
                    if not access_token:
                        continue

                    # Check if startUrl matches our profile's sso_start_url
                    start_url = cache_data.get("startUrl")
                    if start_url and start_url.rstrip('/') != sso_start_url.rstrip('/'):
                        continue

                    # Check expiration
                    expires_at_str = cache_data.get("expiresAt")
                    if not expires_at_str:
                        continue

                    expires_at = datetime.fromisoformat(expires_at_str.replace("UTC", "+00:00").replace("Z", "+00:00"))
                    now = datetime.now(timezone.utc)

                    if now < expires_at:
                        logger.info(f"Found valid AWS SSO access token in {cache_file.name}, expires at {expires_at_str}")
                        sso_token_valid = True
                        break
                    else:
                        logger.warning(f"AWS SSO access token in {cache_file.name} expired at {expires_at_str}")

                except (json.JSONDecodeError, ValueError, KeyError) as e:
                    logger.debug(f"Skipping cache file {cache_file.name}: {e}")
                    continue

            if not sso_token_valid:
                logger.warning("No valid AWS SSO access token found in any cache file")
                return False

            # If verify_credentials is False, return early (fast path for frontend checks)
            if not verify_credentials:
                logger.debug("SSO token valid, skipping credentials verification (fast mode)")
                return True

            # SSO token is valid, now check if real AWS credentials are available
            # by calling `aws sts get-caller-identity --profile <profile>`
            logger.info("SSO token valid, checking real AWS credentials...")
            return self._verify_aws_credentials()

        except Exception as e:
            logger.error(f"Failed to validate AWS SSO token: {e}")
            return False

    def _verify_aws_credentials(self) -> bool:
        """
        Verify that real AWS credentials are available by calling AWS STS.

        This ensures the user has completed the full SSO login flow and
        obtained temporary credentials (aws_access_key_id + aws_secret_access_key).

        Returns:
            True if credentials are valid, False otherwise.
        """
        try:
            aws_cli = self._find_aws_cli()
            if not aws_cli:
                logger.error("AWS CLI not found")
                return False

            # Call: aws sts get-caller-identity --profile <profile>
            # Use 5s timeout to avoid long wait when network/credentials are broken
            result = subprocess.run(
                [aws_cli, "sts", "get-caller-identity", "--profile", self.profile_name],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode == 0:
                logger.info(f"AWS credentials verified successfully for profile '{self.profile_name}'")
                return True
            else:
                logger.warning(f"AWS credentials verification failed: {result.stderr.strip()}")
                return False

        except subprocess.TimeoutExpired:
            logger.error("AWS credentials verification timed out")
            return False
        except Exception as e:
            logger.error(f"Failed to verify AWS credentials: {e}")
            return False

    @staticmethod
    def _find_aws_cli() -> Optional[str]:
        """Locate the AWS CLI executable, checking PATH and common install locations."""
        import shutil
        found = shutil.which("aws")
        if found:
            return found
        candidates = [
            r"C:\Program Files\Amazon\AWSCLIV2\aws.exe",
            r"C:\Program Files (x86)\Amazon\AWSCLIV2\aws.exe",
            "/usr/local/bin/aws",
            "/usr/bin/aws",
        ]
        for c in candidates:
            if os.path.isfile(c):
                return c
        return None

    def trigger_sso_login(self, clear_cache: bool = True) -> dict:
        """
        Trigger AWS SSO login by calling `aws sso login --profile <profile>`.

        This will open the user's browser with Amazon SSO login page.
        The command runs in the background (non-blocking).

        Args:
            clear_cache: If True, clear existing SSO cache before login (default: True)

        Returns:
            dict with status and message:
            - {"status": "success", "message": "..."}
            - {"status": "error", "message": "..."}
        """
        try:
            logger.info(f"Triggering AWS SSO login for profile: {self.profile_name}")

            # Validate that the Profile exists before attempting login
            sso_start_url = self._get_sso_start_url()
            if not sso_start_url:
                logger.error(f"Profile '{self.profile_name}' not found in AWS config")
                return {
                    "status": "error",
                    "message": f"AWS Profile '{self.profile_name}' not found in ~/.aws/config. Please check your configuration.",
                }

            # Check if token is already valid - if so, no need to login again
            # Use fast mode to avoid blocking
            if self.is_token_valid(verify_credentials=False):
                logger.info("AWS SSO token is already valid, skipping login")
                return {
                    "status": "success",
                    "message": "AWS SSO token is already valid. No login required.",
                }

            # Clear existing cache to force fresh authentication
            if clear_cache:
                logger.info("Clearing existing AWS SSO cache before login")
                self._clear_sso_cache()

            # Execute in background: aws sso login --profile <profile>
            # Use Popen to avoid blocking the API response
            aws_cli = self._find_aws_cli()
            if not aws_cli:
                logger.error("AWS CLI not found in PATH or common locations")
                return {
                    "status": "error",
                    "message": "AWS CLI not found. Please install it or add it to PATH.",
                }

            import sys
            if sys.platform == 'win32':
                # Windows: hide the console window
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

                subprocess.Popen(
                    [aws_cli, "sso", "login", "--profile", self.profile_name],
                    startupinfo=startupinfo,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                )
            else:
                # Unix: detach from parent process
                subprocess.Popen(
                    [aws_cli, "sso", "login", "--profile", self.profile_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                )

            logger.info("AWS SSO login process started in background")
            return {
                "status": "success",
                "message": "AWS SSO login triggered. Browser window should open shortly.",
            }

        except FileNotFoundError:
            logger.error("AWS CLI not found. Please install AWS CLI.")
            return {
                "status": "error",
                "message": "AWS CLI not found. Please install it or add it to PATH.",
            }
        except Exception as e:
            logger.error(f"Failed to trigger AWS SSO login: {e}")
            return {
                "status": "error",
                "message": f"Failed to trigger AWS SSO login: {str(e)}",
            }

    def get_cache_status(self) -> dict:
        """
        Get current AWS SSO cache status.

        Returns:
            dict with cache information:
            - exists: bool
            - valid: bool (only checks SSO token expiration, not real credentials)
            - expires_at: str (ISO format) or None
            - profile: str
        """
        cache_file = self._find_latest_cache_file()

        if not cache_file:
            return {
                "exists": False,
                "valid": False,
                "expires_at": None,
                "profile": self.profile_name,
            }

        try:
            with open(cache_file, "r") as f:
                cache_data = json.load(f)

            expires_at = cache_data.get("expiresAt")
            # Use fast mode: only check SSO token expiration, skip aws sts call
            is_valid = self.is_token_valid(verify_credentials=False)

            return {
                "exists": True,
                "valid": is_valid,
                "expires_at": expires_at,
                "profile": self.profile_name,
            }

        except Exception as e:
            logger.error(f"Failed to read cache status: {e}")
            return {
                "exists": True,
                "valid": False,
                "expires_at": None,
                "profile": self.profile_name,
            }

    def _find_latest_cache_file(self) -> Optional[Path]:
        """
        Find the correct AWS SSO cache file for the current profile.

        The cache file name is calculated as SHA1(sso_start_url) based on
        the profile configuration in ~/.aws/config.

        Returns:
            Path to the profile-specific cache file, or None if not found.
        """
        if not self.cache_dir.exists():
            return None

        # Try to get SSO start URL from profile config
        sso_start_url = self._get_sso_start_url()
        if not sso_start_url:
            logger.warning(f"Could not find sso_start_url for profile {self.profile_name}, falling back to latest file")
            # Fallback: return the most recently modified file
            cache_files = list(self.cache_dir.glob("*.json"))
            if not cache_files:
                return None
            return max(cache_files, key=lambda p: p.stat().st_mtime)

        # Calculate the cache file name based on sso_start_url
        cache_filename = hashlib.sha1(sso_start_url.encode('utf-8')).hexdigest() + ".json"
        cache_file = self.cache_dir / cache_filename

        if cache_file.exists():
            logger.info(f"Found profile-specific cache file: {cache_filename}")
            return cache_file
        else:
            logger.warning(f"Profile-specific cache file not found: {cache_filename}")
            # Fallback: return the most recently modified file (likely client registration cache)
            cache_files = list(self.cache_dir.glob("*.json"))
            if not cache_files:
                return None
            latest_file = max(cache_files, key=lambda p: p.stat().st_mtime)
            logger.info(f"Using latest cache file as fallback: {latest_file.name}")
            return latest_file

    def _get_sso_start_url(self) -> Optional[str]:
        """
        Read sso_start_url from ~/.aws/config for the current profile.

        Returns:
            SSO start URL string, or None if not found.
        """
        try:
            config_path = Path.home() / ".aws" / "config"
            if not config_path.exists():
                logger.warning(f"AWS config file not found: {config_path}")
                return None

            config = configparser.ConfigParser()
            config.read(config_path)

            # Profile section name format: "profile <name>" or "default"
            section_name = f"profile {self.profile_name}" if self.profile_name != "default" else "default"

            if section_name not in config:
                logger.warning(f"Profile '{self.profile_name}' not found in AWS config")
                return None

            # First, try to read sso_start_url directly from the profile
            sso_start_url = config[section_name].get("sso_start_url")
            if sso_start_url:
                logger.info(f"Found sso_start_url for profile '{self.profile_name}': {sso_start_url}")
                return sso_start_url

            # If not found, try to read from sso_session reference
            sso_session = config[section_name].get("sso_session")
            if sso_session:
                session_section = f"sso-session {sso_session}"
                if session_section in config:
                    sso_start_url = config[session_section].get("sso_start_url")
                    if sso_start_url:
                        logger.info(f"Found sso_start_url from sso_session '{sso_session}' for profile '{self.profile_name}': {sso_start_url}")
                        return sso_start_url
                else:
                    logger.warning(f"SSO session '{sso_session}' not found in AWS config")

            logger.warning(f"No sso_start_url found for profile '{self.profile_name}'")
            return None

        except Exception as e:
            logger.error(f"Failed to read AWS config: {e}")
            return None

    def clear_sso_cache(self) -> dict:
        """
        Clear all AWS SSO cache files to force fresh authentication.

        Deletes all .json files in ~/.aws/sso/cache/ directory AND
        all cached credentials in ~/.aws/cli/cache/ directory.

        Returns:
            dict with status and message
        """
        try:
            total_cleared = 0

            # Clear SSO token cache
            if self.cache_dir.exists():
                cache_files = list(self.cache_dir.glob("*.json"))
                for cache_file in cache_files:
                    cache_file.unlink()
                    logger.info(f"Deleted SSO cache file: {cache_file.name}")
                    total_cleared += 1
            else:
                logger.info("SSO cache directory does not exist")

            # Clear CLI credential cache (this is where boto3 caches temporary credentials)
            if self.cli_cache_dir.exists():
                cli_cache_files = list(self.cli_cache_dir.glob("*.json"))
                for cache_file in cli_cache_files:
                    cache_file.unlink()
                    logger.info(f"Deleted CLI cache file: {cache_file.name}")
                    total_cleared += 1
            else:
                logger.info("CLI cache directory does not exist")

            if total_cleared == 0:
                logger.info("No cache files found, nothing to clear")
                return {
                    "status": "success",
                    "message": "No cache files to clear",
                }

            logger.info(f"Cleared {total_cleared} cache file(s) total")
            return {
                "status": "success",
                "message": f"Cleared {total_cleared} cache file(s)",
            }

        except Exception as e:
            logger.error(f"Failed to clear SSO cache: {e}")
            return {
                "status": "error",
                "message": f"Failed to clear cache: {str(e)}",
            }

    def _clear_sso_cache(self) -> None:
        """
        Internal method to clear SSO cache (used by trigger_sso_login).
        """
        result = self.clear_sso_cache()
        if result["status"] == "error":
            logger.warning(f"Cache clear failed (non-fatal): {result['message']}")
