"""Keep Driver scratch files off the operating system's shared temp volume."""

import os
import tempfile
from pathlib import Path

from app.core.config import _BACKEND_DIR, get_settings


def get_driver_temp_root() -> Path:
    configured = get_settings().DRIVER_TEMP_DIR
    root = Path(configured).expanduser() if configured else _BACKEND_DIR / "data" / "driver-temp"
    if not root.is_absolute():
        root = _BACKEND_DIR / root
    root = root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def configure_driver_temp_root() -> Path:
    root = get_driver_temp_root()
    root_text = str(root)
    os.environ["TEMP"] = root_text
    os.environ["TMP"] = root_text
    os.environ["TMPDIR"] = root_text
    tempfile.tempdir = root_text
    return root
