"""
@file exceptions.py
@author caoshwen
@brief Custom exception hierarchy for Macode.

@version 3.2
@date 2026-07-25

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from typing import Optional, Any


# ============================================================
# Base Exceptions
# ============================================================

class FWDevAgentError(Exception):
    """Base exception for all Macode errors."""
    
    def __init__(self, message: str, details: Optional[dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


# ============================================================
# Agent Exceptions
# ============================================================

class AgentError(FWDevAgentError):
    """Base exception for agent-related errors."""
    http_code = 500


class AgentTimeoutError(AgentError):
    """Agent execution timeout."""
    http_code = 504
    
    def __init__(self, agent_type: str, timeout_seconds: int):
        super().__init__(
            f"Agent '{agent_type}' execution timeout after {timeout_seconds}s",
            {"agent_type": agent_type, "timeout": timeout_seconds}
        )


class AgentValidationError(AgentError):
    """Invalid agent input or context."""
    http_code = 422
    
    def __init__(self, agent_type: str, validation_errors: list[str]):
        super().__init__(
            f"Agent '{agent_type}' validation failed",
            {"agent_type": agent_type, "errors": validation_errors}
        )


class AgentExecutionError(AgentError):
    """Agent execution failed."""
    http_code = 500
    
    def __init__(self, agent_type: str, error_message: str):
        super().__init__(
            f"Agent '{agent_type}' execution failed: {error_message}",
            {"agent_type": agent_type, "error": error_message}
        )


class AgentNotFoundError(AgentError):
    """Requested agent type not found."""
    http_code = 404
    
    def __init__(self, agent_type: str):
        super().__init__(
            f"Agent type '{agent_type}' not found",
            {"agent_type": agent_type}
        )


# ============================================================
# LLM Provider Exceptions
# ============================================================

class LLMError(FWDevAgentError):
    """Base exception for LLM-related errors."""
    http_code = 503


class LLMProviderError(LLMError):
    """LLM provider failure."""
    
    def __init__(self, provider: str, error_message: str):
        super().__init__(
            f"LLM provider '{provider}' failed: {error_message}",
            {"provider": provider, "error": error_message}
        )


class LLMRateLimitError(LLMError):
    """Rate limit exceeded."""
    http_code = 429
    
    def __init__(self, provider: str, retry_after: Optional[int] = None):
        message = f"Rate limit exceeded for provider '{provider}'"
        if retry_after:
            message += f", retry after {retry_after}s"
        super().__init__(message, {"provider": provider, "retry_after": retry_after})


class LLMConnectionError(LLMError):
    """Cannot connect to LLM provider."""
    http_code = 503
    
    def __init__(self, provider: str, error_message: str):
        super().__init__(
            f"Cannot connect to LLM provider '{provider}': {error_message}",
            {"provider": provider, "error": error_message}
        )


class LLMAuthenticationError(LLMError):
    """LLM provider authentication failed."""
    http_code = 401
    
    def __init__(self, provider: str):
        super().__init__(
            f"Authentication failed for LLM provider '{provider}'",
            {"provider": provider}
        )


class AllProvidersFailedError(LLMError):
    """All LLM providers failed."""
    http_code = 503
    
    def __init__(self, provider_errors: dict[str, str]):
        super().__init__(
            "All LLM providers failed",
            {"provider_errors": provider_errors}
        )


# ============================================================
# Validation Exceptions
# ============================================================

class ValidationError(FWDevAgentError):
    """Base exception for validation errors."""
    http_code = 422


class InputValidationError(ValidationError):
    """Input validation failed."""
    
    def __init__(self, field: str, reason: str):
        super().__init__(
            f"Invalid input for field '{field}': {reason}",
            {"field": field, "reason": reason}
        )


class PromptInjectionError(ValidationError):
    """Prompt injection attempt detected."""
    http_code = 400
    
    def __init__(self, pattern: str):
        super().__init__(
            f"Potential prompt injection detected: {pattern}",
            {"pattern": pattern}
        )


# ============================================================
# Authentication & Authorization Exceptions
# ============================================================

class AuthError(FWDevAgentError):
    """Base exception for authentication/authorization errors."""
    http_code = 401


class InvalidTokenError(AuthError):
    """Invalid or expired JWT token."""
    
    def __init__(self, reason: str = "Invalid token"):
        super().__init__(reason, {})


class InsufficientPermissionsError(AuthError):
    """User lacks required permissions."""
    http_code = 403
    
    def __init__(self, required_permission: str):
        super().__init__(
            f"Insufficient permissions: requires '{required_permission}'",
            {"required_permission": required_permission}
        )


class RateLimitExceededError(AuthError):
    """User rate limit exceeded."""
    http_code = 429
    
    def __init__(self, limit_type: str, limit: int, retry_after: int):
        super().__init__(
            f"Rate limit exceeded: {limit_type} limit of {limit}",
            {"limit_type": limit_type, "limit": limit, "retry_after": retry_after}
        )


# ============================================================
# MCP Tool Exceptions
# ============================================================

class MCPError(FWDevAgentError):
    """Base exception for MCP tool errors."""
    http_code = 503


class MCPServerNotAvailableError(MCPError):
    """MCP server not available."""
    
    def __init__(self, server_name: str):
        super().__init__(
            f"MCP server '{server_name}' is not available",
            {"server_name": server_name}
        )


class MCPToolExecutionError(MCPError):
    """MCP tool execution failed."""
    
    def __init__(self, tool_name: str, error_message: str):
        super().__init__(
            f"MCP tool '{tool_name}' execution failed: {error_message}",
            {"tool_name": tool_name, "error": error_message}
        )


# ============================================================
# Database Exceptions
# ============================================================

class DatabaseError(FWDevAgentError):
    """Base exception for database errors."""
    http_code = 500


class RecordNotFoundError(DatabaseError):
    """Database record not found."""
    http_code = 404
    
    def __init__(self, model: str, record_id: str):
        super().__init__(
            f"{model} with id '{record_id}' not found",
            {"model": model, "id": record_id}
        )


class DuplicateRecordError(DatabaseError):
    """Duplicate record in database."""
    http_code = 409
    
    def __init__(self, model: str, field: str, value: str):
        super().__init__(
            f"Duplicate {model}: {field}='{value}' already exists",
            {"model": model, "field": field, "value": value}
        )


# ============================================================
# Configuration Exceptions
# ============================================================

class ConfigurationError(FWDevAgentError):
    """Configuration error."""
    http_code = 500
    
    def __init__(self, setting: str, reason: str):
        super().__init__(
            f"Configuration error for '{setting}': {reason}",
            {"setting": setting, "reason": reason}
        )


# ============================================================
# Utility Functions
# ============================================================

def get_http_code(exception: Exception) -> int:
    """Get HTTP status code for an exception."""
    if isinstance(exception, FWDevAgentError):
        return getattr(exception, 'http_code', 500)
    return 500


def get_error_details(exception: Exception) -> dict[str, Any]:
    """Get error details from an exception."""
    if isinstance(exception, FWDevAgentError):
        return {
            "error_type": exception.__class__.__name__,
            "message": exception.message,
            "details": exception.details
        }
    return {
        "error_type": "UnknownError",
        "message": str(exception),
        "details": {}
    }
