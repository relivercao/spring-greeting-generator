"""Frozen Batch Unit-Test contract constants.

This module is intentionally side-effect free.  Stage 0 uses it as the
single source for route names, public states, child-state projection and
business error-code vocabulary.  Persistence, dispatch and HTTP handlers are
implemented in later stages and should import these values instead of
redefining string literals.
"""

from enum import Enum
from typing import Final, Mapping


class BatchTaskStatus(str, Enum):
    """Public lifecycle states of a BatchTask."""

    QUEUED = "queued"
    RUNNING = "running"
    DONE = "done"


class BatchItemStatus(str, Enum):
    """Public lifecycle states of a BatchItem."""

    QUEUED = "queued"
    RUNNING = "running"
    PASS = "pass"
    FAIL = "fail"


BATCH_TASK_ROUTE_PREFIX: Final[str] = "/unittest/batch-tasks"
BATCH_QUEUE_ROUTE: Final[str] = "/unittest/batch-queue"
BATCH_CREATE_ROUTE: Final[str] = BATCH_TASK_ROUTE_PREFIX
BATCH_LIST_ROUTE: Final[str] = BATCH_TASK_ROUTE_PREFIX
BATCH_DETAIL_ROUTE_TEMPLATE: Final[str] = f"{BATCH_TASK_ROUTE_PREFIX}/{{batch_task_id}}"
BATCH_CANCEL_ROUTE_TEMPLATE: Final[str] = (
    f"{BATCH_TASK_ROUTE_PREFIX}/{{batch_task_id}}/cancel"
)
BATCH_RESUME_ROUTE_TEMPLATE: Final[str] = (
    f"{BATCH_TASK_ROUTE_PREFIX}/{{batch_task_id}}/resume"
)

# The wire contract accepts only these source extensions in the first batch
# release.  Keep the values lowercase; validation normalizes input first.
BATCH_ALLOWED_EXTENSIONS: Final[frozenset[str]] = frozenset({".c", ".cpp"})

# Batch resource IDs use lowercase UUID v4 strings.  They remain separate
# resources from ordinary child Task IDs even though both use the existing
# UUID wire shape; this keeps the existing UUID-only download routes safe.
BATCH_ID_FORMAT: Final[str] = "uuid-v4"
BATCH_ID_VERSION: Final[int] = 4
BATCH_ID_PATTERN: Final[str] = (
    r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
)

# Child Unit-Test status -> public BatchItem status projection.
CHILD_STATUS_TO_ITEM_STATUS: Final[Mapping[str, str]] = {
    "completed": BatchItemStatus.PASS.value,
    "failed": BatchItemStatus.FAIL.value,
    "cancelled": BatchItemStatus.FAIL.value,
    # A paused child remains an active BatchItem and exposes the resume flags.
    "paused": BatchItemStatus.RUNNING.value,
}

# Codes returned by batch HTTP validation/lookup endpoints.
BATCH_HTTP_ERROR_CODES: Final[frozenset[str]] = frozenset(
    {
        "BATCH_TASK_EMPTY",
        "BATCH_FILE_PATHS_MISMATCH",
        "BATCH_FILE_TYPE_UNSUPPORTED",
        "BATCH_SOURCE_PATH_INVALID",
        "BATCH_PROJECT_ROOT_UNRESOLVABLE",
        "BATCH_FILES_NOT_IN_SAME_PROJECT",
        "BATCH_PAYLOAD_TOO_LARGE",
        "BATCH_SNAPSHOT_FAILED",
        "BATCH_TASK_NOT_FOUND",
        "BATCH_TASK_NOT_RESUMABLE",
    }
)

# Codes persisted on an Item (or surfaced by a resume operation).  Runtime
# errors are deliberately kept out of the HTTP validation namespace: a batch
# detail/list request remains HTTP 200 after a task has been accepted.
BATCH_ITEM_ERROR_CODES: Final[frozenset[str]] = frozenset(
    {
        "AWS_AUTH_REQUIRED",
        "PROVIDER_AUTH_REQUIRED",
        "AWS_PROFILE_INVALID",
        "AWS_SSO_NOT_COMPLETED",
        "AUTH_BLOCK_TIMEOUT",
        "RUNNER_FAILED",
        "CHILD_STATUS_UNKNOWN",
        "SNAPSHOT_INVALID",
        "BACKEND_RESTART",
    }
)

# Backwards-compatible aggregate used by early Stage 0 consumers/tests.
BATCH_ERROR_CODES: Final[frozenset[str]] = (
    BATCH_HTTP_ERROR_CODES | BATCH_ITEM_ERROR_CODES
)

# Batch-level terminal reasons are intentionally narrower than Item reasons.
# A failed quality gate or runner does not make the BatchTask itself abnormal;
# it is represented by the Item and the aggregate counts.  Normal completion
# (including a batch containing failed Items) has a null reason.
BATCH_TERMINAL_REASONS: Final[frozenset[str]] = frozenset(
    {"CANCELLED", "BACKEND_RESTART"}
)

# Optional resume is feature-gated.  When disabled, no resume route is
# registered and a runtime authentication block fails the current Item
# immediately; BATCH_AUTH_BLOCK_TIMEOUT_SECONDS applies once resume is enabled.
BATCH_RESUME_DEFAULT_ENABLED: Final[bool] = False

# A normal completion has no terminal reason.  Item-level SNAPSHOT_INVALID and
# BACKEND_RESTART stay attached to their Item; BACKEND_RESTART additionally
# becomes the batch-level reason only when startup reconciliation finalizes an
# interrupted batch as a whole (restart semantics: finalize, never resume).
NORMAL_TERMINAL_REASON: Final[None] = None
