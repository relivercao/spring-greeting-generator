"""
@file config.py
@author caoshwen
@brief Application configuration based on pydantic-settings.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Iterable, Literal, Optional
from functools import lru_cache
from pathlib import Path
from dataclasses import dataclass
import json
import platform as _platform
import shutil as _shutil

# Backend root directory (where this config.py lives: app/core/ -> backend/)
_BACKEND_DIR = Path(__file__).parent.parent.parent

DEFAULT_CLI_TASK_HARD_TIMEOUT_SECONDS = 8 * 60 * 60
DEFAULT_CLAUDE_CODE_MAX_TOKENS = 900_000
DEFAULT_CLAUDE_CODE_MAX_OUTPUT_TOKENS = 65_536
DEFAULT_CLAUDE_CODE_UNKNOWN_MODEL_CONTEXT_WINDOW = 200_000
DEFAULT_UNITTEST_MAX_ITERATIONS = 5
DEFAULT_UNITTEST_MAX_FINAL_REPAIR_ATTEMPTS = 2
DEFAULT_UNITTEST_LAYER = "auto"
DEFAULT_UNITTEST_FRAMEWORK = "gtest"
DEFAULT_UNITTEST_TARGET_COVERAGE = 90.0
DEFAULT_UNITTEST_COVERAGE_TARGET_RATIO = DEFAULT_UNITTEST_TARGET_COVERAGE / 100.0
DEFAULT_UNITTEST_ENABLE_MOCK = True
DEFAULT_UNITTEST_COMPILE_VERIFY = True
DEFAULT_UNITTEST_BUILD_PROFILE = "mingw"
DEFAULT_UNITTEST_PLATFORM = "stm32u3"
DEFAULT_UNITTEST_AUTO_UPDATE_QBS = True
DEFAULT_BATCH_MAX_FILES = 100
DEFAULT_BATCH_MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024
DEFAULT_BATCH_MAX_TOTAL_UPLOAD_SIZE_BYTES = 100 * 1024 * 1024
DEFAULT_BATCH_SNAPSHOT_RETENTION_DAYS = 30
DEFAULT_BATCH_AUTH_BLOCK_TIMEOUT_SECONDS = 1800
DEFAULT_BATCH_CHILD_TIMEOUT_SECONDS = 21600
DEFAULT_BATCH_DISPATCHER_LEASE_SECONDS = 60
DEFAULT_BATCH_DISPATCHER_HEARTBEAT_SECONDS = 15
DEFAULT_BATCH_DISPATCHER_POLL_INTERVAL_SECONDS = 1
DEFAULT_BATCH_SNAPSHOT_ORPHAN_GRACE_SECONDS = 3600
DEFAULT_BATCH_SNAPSHOT_DIR = "./data/batch_snapshots"

_MODEL_REAL_CONTEXT_WINDOWS: dict[str, int] = {
    "claude-sonnet-4-5": 200_000,
    "claude-opus-4-1": 200_000,
    "claude-haiku-4-5": 200_000,
    "claude-sonnet-4-6": 1_000_000,
    "claude-sonnet-5": 1_000_000,
    "claude-opus-4-6-v1": 1_000_000,
    "claude-opus-4-7": 1_000_000,
    "claude-opus-4-8": 1_000_000,
    "claude-opus-5": 1_000_000,
}
_CONTEXT_WINDOW_SAFETY_RATIO = 0.9
_CONTEXT_WINDOW_SAFETY_MARGIN_TOKENS = 20_000
_CONTEXT_WINDOW_MIN_TOKENS = 32_768
_MIN_INPUT_ALLOWANCE_TOKENS = 96_000
_STARVED_INPUT_ALLOWANCE_WARNED: set[tuple[int, int]] = set()


class Settings(BaseSettings):
    """Global application configuration."""

    # === Application metadata ===
    APP_NAME: str = "Macode"
    APP_VERSION: str = "3.2.0"
    API_V1_PREFIX: str = "/api/v1"
    DEBUG: str = "false"

    # === Server configuration ===
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    WORKERS: int = 1
    CORS_ORIGINS: list[str] = ["*"]

    # === JWT authentication configuration ===
    SECRET_KEY: str = "fw-dev-agent-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # === Database configuration ===
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/agent.db"

    # === Redis configuration ===
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_MAX_CONNECTIONS: int = 20

    # === LLM provider configuration ===
    # AWS Bedrock (priority 1)
    CLAUDE_CODE_USE_BEDROCK: str = "0"
    AWS_REGION: str = "us-east-1"
    AWS_PROFILE: Optional[str] = None
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    ANTHROPIC_DEFAULT_OPUS_MODEL: Optional[str] = None
    ANTHROPIC_DEFAULT_SONNET_MODEL: Optional[str] = None
    ANTHROPIC_DEFAULT_HAIKU_MODEL: Optional[str] = None
    ANTHROPIC_DEFAULT_MODEL: Optional[str] = None
    OPENROUTER_DEFAULT_MODEL: Optional[str] = None
    TURING_API_KEY: Optional[str] = None
    TURING_API_BASE: Optional[str] = None
    TURING_DEFAULT_MODEL: Optional[str] = None
    GATEWAY_API_KEY: Optional[str] = None
    GATEWAY_BASE_URL: Optional[str] = None
    GATEWAY_DEFAULT_MODEL: Optional[str] = None
    GATEWAY_CA_CERT_PATH: Optional[str] = None
    BEDROCK_DEFAULT_MODEL: str = "claude-sonnet-4-6"

    # === Image generation provider configuration ===
    IMAGE_API_PROVIDER: str = "macode"
    IMAGE_API_BASE: Optional[str] = None
    IMAGE_API_KEY: Optional[str] = None
    IMAGE_API_MODEL: str = "gpt-image-2"
    IMAGE_API_MODE: str = "images"
    IMAGE_API_TIMEOUT: int = 600
    IMAGE_API_RETRIES: int = 2
    IMAGE_API_STREAM: bool = False
    IMAGE_API_PARTIAL_IMAGES: int = 1
    IMAGE_API_ALLOW_PROMPT_REWRITE: bool = True
    IMAGE_MAX_REFERENCE_IMAGES: int = 16
    IMAGE_MAX_INPUT_BYTES: int = 50 * 1024 * 1024
    IMAGE_MAX_TOTAL_INPUT_BYTES: int = 256 * 1024 * 1024
    IMAGE_MAX_OUTPUT_BYTES: int = 50 * 1024 * 1024

    # === CAD Agent runtime configuration ===
    CAD_AGENT_SKILL_DIR: Optional[str] = None
    CAD_AGENT_UVX_PATH: str = "uvx"
    CAD_AGENT_RUNTIME_TIMEOUT_SECONDS: int = Field(default=900, ge=60, le=3600)
    CAD_AGENT_UV_HTTP_TIMEOUT_SECONDS: int = Field(default=900, ge=30, le=1800)

    # Zhipu AI removed

    # Default provider selection (set by UI Providers dialog)
    DEFAULT_PROVIDER: str = "macode"
    AGENT_LLM_CONFIG: str = ""

    # General LLM settings
    LLM_DEFAULT_TEMPERATURE: float = 0.7
    LLM_DEFAULT_MAX_TOKENS: int = 4096
    LLM_HEALTH_CHECK_INTERVAL: int = 60
    LLM_RATE_LIMIT_PER_MINUTE: int = 60

    # LLM Retry Settings
    LLM_RETRY_MAX_ATTEMPTS: int = 3        # Maximum retry attempts (0 = no retry)
    LLM_RETRY_BASE_DELAY: float = 1.0      # Initial retry delay (seconds)
    LLM_RETRY_MAX_DELAY: float = 30.0      # Maximum retry delay cap (seconds)
    LLM_RETRY_BACKOFF_FACTOR: float = 2.0  # Exponential backoff multiplier

    # LLM 6-Level Timeout Settings (seconds)
    # Tier 1 - FAST: health checks, pings
    LLM_TIMEOUT_FAST_CONNECT: int = 5
    LLM_TIMEOUT_FAST_READ: int = 15
    LLM_TIMEOUT_FAST_TOTAL: int = 20
    # Tier 2 - NORMAL: standard chat completions
    LLM_TIMEOUT_NORMAL_CONNECT: int = 10
    LLM_TIMEOUT_NORMAL_READ: int = 30
    LLM_TIMEOUT_NORMAL_TOTAL: int = 45
    # Tier 3 - EXTENDED: longer completions, streaming
    LLM_TIMEOUT_EXTENDED_CONNECT: int = 10
    LLM_TIMEOUT_EXTENDED_READ: int = 60
    LLM_TIMEOUT_EXTENDED_TOTAL: int = 90
    # Tier 4 - LONG_GENERATION: large code generation
    LLM_TIMEOUT_LONG_CONNECT: int = 10
    LLM_TIMEOUT_LONG_READ: int = 120
    LLM_TIMEOUT_LONG_TOTAL: int = 180
    # Tier 5 - AGENT_WORKFLOW: full agent pipeline with tool calls
    LLM_TIMEOUT_AGENT_CONNECT: int = 15
    LLM_TIMEOUT_AGENT_READ: int = 300
    LLM_TIMEOUT_AGENT_TOTAL: int = 360
    # Tier 6 - CLI_FALLBACK: local CLI subprocess, highest tolerance
    LLM_TIMEOUT_CLI_CONNECT: int = 15
    LLM_TIMEOUT_CLI_READ: int = 600
    LLM_TIMEOUT_CLI_TOTAL: int = 660

    # === MCP tool configuration ===
    # Integration profile keeps issue/repository conventions configurable for
    # embedded, software, hardware, and general engineering teams.
    INTEGRATION_PROFILE: str = "general"
    # Jira
    JIRA_BASE_URL: Optional[str] = None
    JIRA_EMAIL: Optional[str] = None
    JIRA_API_TOKEN: Optional[str] = None
    JIRA_DEPLOYMENT: str = "cloud"
    JIRA_PROJECT_KEY: Optional[str] = None
    JIRA_ISSUE_TYPES: str = "Bug"

    # Bitbucket
    BITBUCKET_BASE_URL: Optional[str] = None
    BITBUCKET_USERNAME: Optional[str] = None
    BITBUCKET_APP_PASSWORD: Optional[str] = None
    BITBUCKET_DEPLOYMENT: str = "cloud"
    BITBUCKET_WORKSPACE: Optional[str] = None

    # Git repository integration (local Git, GitHub, GitLab, Gitea, or custom API).
    GIT_PROVIDER: str = "local"
    GIT_BASE_URL: Optional[str] = None
    GIT_REPOSITORY_PATH: Optional[str] = None
    GIT_REPOSITORY_URL: Optional[str] = None
    GIT_USERNAME: Optional[str] = None
    GIT_TOKEN: Optional[str] = None
    GIT_DEFAULT_BRANCH: str = "main"

    # User-authorized application connections are brokered by Composio.
    COMPOSIO_API_KEY: Optional[str] = None
    COMPOSIO_API_BASE_URL: str = "https://backend.composio.dev/api/v3.1"
    COMPOSIO_AUTH_CONFIGS: str = ""
    COMPOSIO_FRONTEND_BASE_URL: str = ""

    # Official Feishu CLI; an empty path resolves the project-local installation.
    FEISHU_CLI_PATH: str = ""
    FEISHU_CLI_TIMEOUT_SECONDS: int = Field(default=30, ge=5, le=120)

    # === File upload configuration ===
    MAX_FILE_SIZE: int = 10 * 1024 * 1024  # 10MB
    ALLOWED_EXTENSIONS: set[str] = {".c", ".h", ".cpp", ".hpp"}
    UPLOAD_DIR: str = "./data/uploads"
    OUTPUT_DIR: str = "./data/outputs"
    DRIVER_TEMP_DIR: str = "./data/driver-temp"
    DRIVER_DOCLING_OCR_ENGINE: str = "easyocr"
    DRIVER_DOCLING_IMAGE_DESCRIPTION_MAX_TOKENS: int = Field(default=32_768, gt=0)
    DRIVER_DOCLING_IMAGE_VERIFICATION_MAX_TOKENS: int = Field(default=16_384, gt=0)
    DRIVER_DOCLING_FORMULA_MAX_TOKENS: int = Field(default=16_384, gt=0)
    DRIVER_DOCLING_PRECISION_TABLE_MAX_TOKENS: int = Field(default=16_384, gt=0)
    DRIVER_DOCLING_REGISTER_TABLE_MAX_TOKENS: int = Field(default=32_768, gt=0)
    DRIVER_DOCLING_VISION_RETRY_MAX_TOKENS: int = Field(default=65_536, gt=0)

    # === Batch Unit-Test configuration ===
    BATCH_MAX_FILES: int = Field(default=DEFAULT_BATCH_MAX_FILES, gt=0)
    BATCH_MAX_FILE_SIZE_BYTES: int = Field(default=DEFAULT_BATCH_MAX_FILE_SIZE_BYTES, gt=0)
    BATCH_MAX_TOTAL_UPLOAD_SIZE_BYTES: int = Field(
        default=DEFAULT_BATCH_MAX_TOTAL_UPLOAD_SIZE_BYTES, gt=0
    )
    BATCH_SNAPSHOT_RETENTION_DAYS: int = Field(
        default=DEFAULT_BATCH_SNAPSHOT_RETENTION_DAYS, gt=0
    )
    BATCH_AUTH_BLOCK_TIMEOUT_SECONDS: int = Field(
        default=DEFAULT_BATCH_AUTH_BLOCK_TIMEOUT_SECONDS, gt=0
    )
    BATCH_CHILD_TIMEOUT_SECONDS: int = Field(
        default=DEFAULT_BATCH_CHILD_TIMEOUT_SECONDS, gt=0
    )
    BATCH_DISPATCHER_LEASE_SECONDS: int = Field(
        default=DEFAULT_BATCH_DISPATCHER_LEASE_SECONDS, ge=5
    )
    BATCH_DISPATCHER_HEARTBEAT_SECONDS: int = Field(
        default=DEFAULT_BATCH_DISPATCHER_HEARTBEAT_SECONDS, gt=0
    )
    BATCH_DISPATCHER_POLL_INTERVAL_SECONDS: int = Field(
        default=DEFAULT_BATCH_DISPATCHER_POLL_INTERVAL_SECONDS, gt=0
    )
    BATCH_SNAPSHOT_ORPHAN_GRACE_SECONDS: int = Field(
        default=DEFAULT_BATCH_SNAPSHOT_ORPHAN_GRACE_SECONDS, gt=0
    )
    BATCH_RESUME_ENABLED: bool = False
    BATCH_SNAPSHOT_DIR: str = DEFAULT_BATCH_SNAPSHOT_DIR

    # Unit-Test runtime defaults shared by the regular and batch runners.
    UNITTEST_MAX_FINAL_REPAIR_ATTEMPTS: int = Field(default=2, ge=0)
    UNITTEST_LARGE_FILE_THRESHOLD_BYTES: int = Field(default=20 * 1024, gt=0)

    # === Logging configuration ===
    LOG_DIR: str = "./logs"
    LOG_LEVEL: str = "DEBUG"
    LOG_JSON_FORMAT: bool = True
    LOG_ROTATION: str = "00:00"
    LOG_RETENTION: str = "30 days"

    # === Vector store configuration ===
    CHROMA_PERSIST_DIR: str = "./data/chroma"

    # === Knowledge repository configuration ===
    KNOWLEDGE_REPOSITORY_DIR: str = "./data/knowledge_base/repository"
    KNOWLEDGE_GIT_ENABLED: bool = True
    KNOWLEDGE_GIT_AUTO_COMMIT: bool = True
    KNOWLEDGE_GIT_REMOTE_URL: str = ""
    KNOWLEDGE_GIT_BRANCH: str = "main"
    KNOWLEDGE_GIT_AUTHOR_NAME: str = "Macode Knowledge Bot"
    KNOWLEDGE_GIT_AUTHOR_EMAIL: str = "relivercao@gmail.com"
    KNOWLEDGE_MKDOCS_URL: str = "http://127.0.0.1:8001"
    KNOWLEDGE_WIKIJS_URL: str = "http://127.0.0.1:3000"
    KNOWLEDGE_AUTO_PUBLISH: bool = True
    KNOWLEDGE_LLM_TIMEOUT_SECONDS: int = Field(default=60, ge=1, le=600)
    KNOWLEDGE_SEMANTIC_LOOKUP_TIMEOUT_SECONDS: int = Field(default=300, ge=1, le=600)
    KNOWLEDGE_SEMANTIC_CONFIDENCE_THRESHOLD: float = Field(default=0.90, ge=0.0, le=1.0)
    KNOWLEDGE_LLM_OCR_ENABLED: bool = True
    KNOWLEDGE_LLM_OCR_BATCH_SIZE: int = 1
    KNOWLEDGE_LLM_OCR_CONCURRENCY: int = 2
    KNOWLEDGE_LLM_OCR_RENDER_SCALE: float = 2.0
    KNOWLEDGE_LLM_OCR_MAX_PAGES: int = 0
    KNOWLEDGE_LLM_OCR_MIN_TEXT_CHARS: int = 200
    KNOWLEDGE_LLM_OCR_MIN_IMAGE_AREA_RATIO: float = 0.01
    KNOWLEDGE_OBSIDIAN_VAULT_DIR: str = ""

    # === Generated Agent human approval notifications ===
    APPROVAL_EMAIL_ENABLED: bool = False
    APPROVAL_EMAIL_TO: str = ""
    APPROVAL_SMTP_HOST: Optional[str] = None
    APPROVAL_SMTP_PORT: int = 587
    APPROVAL_SMTP_USERNAME: Optional[str] = None
    APPROVAL_SMTP_PASSWORD: Optional[str] = None
    APPROVAL_SMTP_FROM: Optional[str] = None
    APPROVAL_SMTP_USE_TLS: bool = True
    APPROVAL_SMTP_USE_SSL: bool = False
    APPROVAL_FEISHU_ENABLED: bool = False
    APPROVAL_FEISHU_WEBHOOK_URL: Optional[str] = None
    APPROVAL_FEISHU_SECRET: Optional[str] = None
    APPROVAL_PUBLIC_API_BASE_URL: str = "http://127.0.0.1:8000/api/v1"

    # === Shared SMTP email configuration (registration and Agent approvals) ===
    SMTP_PROVIDER: Literal["custom", "gmail"] = "custom"
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = ""
    SMTP_USE_TLS: bool = True
    SMTP_USE_SSL: bool = False

    # === Billing and recharge configuration ===
    # Master switch for balance billing.  Defaults to false (dark launch)
    # so the existing open demo behavior and tests are unaffected.
    BILLING_ENABLED: bool = False
    # When billing is enabled, still allow guest (unauthenticated) LLM access.
    BILLING_GUEST_ALLOWED: bool = True
    # USD-to-CNY conversion rate applied to LLM usage pricing.
    USD_TO_CNY_RATE: float = 7.2
    # Comma-separated emails promoted to administrator on login (idempotent).
    ADMIN_BOOTSTRAP_EMAILS: str = ""
    # Public base URLs used to build payment notify/return links.
    PUBLIC_API_BASE_URL: str = "http://127.0.0.1:8000/api/v1"
    PUBLIC_FRONTEND_BASE_URL: str = "http://localhost:5173"

    # === QBS build tool configuration ===
    QBS_PATH: str = "qbs"                  # Default value, overridden by detection logic at startup
    # Profile registered into the project-local qbs settings dir on startup.
    # Platform-aware default: Windows uses the bundled mingw toolchain, other
    # hosts use the "host_gcc" profile created from the system compiler.
    QBS_DEFAULT_PROFILE: str = (
        "mingw" if _platform.system() == "Windows" else "host_gcc"
    )
    QBS_TIMEOUT: int = 300

    # === UnitTest Agent configuration ===
    UNITTEST_PROJECT_ROOT: str = ".."

    # === Claude CLI configuration ===
    CLAUDE_CLI_PATH: str = "../bin/claude_sdk/node_modules/.bin/claude.cmd"
    CLAUDE_CLI_DEFAULT_MODEL: Optional[str] = None
    CLAUDE_ROUTER_HOST: str = "127.0.0.1"
    CLAUDE_ROUTER_PORT: int = 8787
    CLAUDE_CODE_MAX_TOKENS: int = DEFAULT_CLAUDE_CODE_MAX_TOKENS
    CLAUDE_CODE_MAX_OUTPUT_TOKENS: int = DEFAULT_CLAUDE_CODE_MAX_OUTPUT_TOKENS
    CLAUDE_CODE_UNKNOWN_MODEL_CONTEXT_WINDOW: int = Field(
        default=DEFAULT_CLAUDE_CODE_UNKNOWN_MODEL_CONTEXT_WINDOW,
        gt=0,
    )
    # Isolated config directory for the project-bundled Claude CLI.
    # Prevents conflicts with any system-level Claude Code installation
    # which defaults to ~/.claude.  Relative paths are resolved from backend/.
    CLAUDE_CONFIG_DIR: str = "../.claude_data"

    # === Claude CLI Bedrock Direct Connection ===
    # When CLAUDE_CODE_USE_BEDROCK=1, the CLI will bypass the local Router
    # and connect directly to AWS Bedrock using the configured AWS profile.
    # This requires a valid AWS profile with Bedrock model access.
    CLAUDE_CODE_USE_BEDROCK: str = ""   # Set to "1" to enable Bedrock direct mode
    # Model aliases for Bedrock — Claude Code uses these env vars to resolve model IDs
    ANTHROPIC_DEFAULT_SONNET_MODEL: str = ""
    ANTHROPIC_DEFAULT_OPUS_MODEL: str = ""
    ANTHROPIC_DEFAULT_HAIKU_MODEL: str = ""

    # === CLI LLM Prodding (anti-laziness) Mechanism ===
    # When the CLI subprocess goes idle (stops producing output), the prodding
    # mechanism kills and restarts it with an escalated prompt that includes
    # partial progress and a strict continuation directive.
    CLI_PROD_ENABLED: str = "true"            # Enable prodding ("true"/"1"/"yes")
    CLI_PROD_MAX_ATTEMPTS: int = 3            # Maximum restart attempts before giving up
    CLI_PROD_TRIGGER_SECONDS: int = 120       # Idle seconds before triggering a prod restart
    CLI_PROD_CONTEXT_TAIL_CHARS: int = 15000  # Chars of prior output to include as context
    CLI_TOOL_ERROR_BREAKER_THRESHOLD: int = 3
    CLI_MAX_TOOL_CALLS: int = 300
    CLI_REPEATED_READ_BREAKER_THRESHOLD: int = 8
    CLI_MAX_TOTAL_TOKENS: int = 0
    CLI_TASK_HARD_TIMEOUT_SECONDS: int = DEFAULT_CLI_TASK_HARD_TIMEOUT_SECONDS

    @property
    def is_debug(self) -> bool:
        """Safe boolean conversion of DEBUG (handles system env like 'release')."""
        return str(self.DEBUG).lower() in ("true", "1", "yes")

    model_config = {
        "env_file": str(_BACKEND_DIR / ".env"),
        "env_file_encoding": "utf-8",
        "case_sensitive": True,
    }


@lru_cache()
def get_settings() -> Settings:
    """Return the global configuration singleton."""
    return Settings()


def normalize_api_base(url: Optional[str]) -> Optional[str]:
    """Normalize an API base URL by trimming whitespace, adding a scheme, and removing a trailing slash."""
    if url is None:
        return None
    normalized = url.strip()
    if not normalized:
        return None
    if not normalized.startswith(("http://", "https://")):
        normalized = f"https://{normalized}"
    return normalized.rstrip("/")


def resolve_gateway_anthropic_base_url(settings: Settings) -> Optional[str]:
    """Return the Anthropic-compatible gateway base URL without a /v1 suffix."""
    base_url = normalize_api_base(getattr(settings, "GATEWAY_BASE_URL", None)) or ""
    while base_url.casefold().endswith("/v1"):
        base_url = base_url[:-3].rstrip("/")
    return base_url or None


def resolve_gateway_ca_cert_path(settings: Settings) -> Optional[str]:
    """Return the configured gateway CA path when it points to an existing file."""
    raw = str(getattr(settings, "GATEWAY_CA_CERT_PATH", None) or "").strip()
    if not raw:
        return None
    ca_path = Path(raw)
    if not ca_path.is_absolute():
        ca_path = (_BACKEND_DIR / ca_path).resolve()
    return str(ca_path) if ca_path.is_file() else None


def is_gateway_transport_configured(settings: Settings) -> bool:
    """Return whether Driver vision requests can use the configured gateway."""
    return (
        str(getattr(settings, "DEFAULT_PROVIDER", "") or "").strip().lower() == "gateway"
        and bool(str(getattr(settings, "GATEWAY_API_KEY", None) or "").strip())
        and bool(resolve_gateway_anthropic_base_url(settings))
    )


def resolve_bedrock_default_model(settings: Settings) -> str:
    """Resolve the effective Bedrock model with Claude-style env precedence."""
    return (
        settings.ANTHROPIC_DEFAULT_SONNET_MODEL
        or settings.ANTHROPIC_DEFAULT_OPUS_MODEL
        or settings.ANTHROPIC_DEFAULT_HAIKU_MODEL
        or settings.BEDROCK_DEFAULT_MODEL
        or "claude-sonnet-4-5"
    )


AGENT_LLM_IDS = (
    "chat",
    "unittest",
    "driver",
    "build",
    "bugfix",
    "debug",
    "review",
    "knowledge",
    "image_generation",
    "agent_generator",
    "cad",
)
AGENT_LLM_PROVIDERS = {"macode", "bedrock"}

# Claude Code validates model identifiers before sending a request. Macode can
# expose additional upstream model names, so unsupported identifiers need a
# known Claude-compatible transport alias that the local Router maps back to
# the selected upstream model.
CLAUDE_CLI_MODEL_IDS = frozenset({
    "claude-3-5-haiku",
    "claude-3-5-sonnet",
    "claude-3-7-sonnet",
    "claude-fable-5",
    "claude-haiku-4-5",
    "claude-mythos-5",
    "claude-opus-4-0",
    "claude-opus-4-1",
    "claude-opus-4-5",
    "claude-opus-4-6",
    "claude-opus-4-7",
    "claude-opus-4-8",
    "claude-opus-5",
    "claude-sonnet-4-0",
    "claude-sonnet-4-5",
    "claude-sonnet-4-6",
    "claude-sonnet-5",
})
CLAUDE_CLI_ALIAS_POOL = (
    "claude-mythos-5",
    "claude-sonnet-5",
    "claude-opus-5",
    "claude-opus-4-8",
    "claude-opus-4-7",
    "claude-opus-4-6",
    "claude-opus-4-5",
    "claude-sonnet-4-0",
    "claude-opus-4-1",
    "claude-opus-4-0",
    "claude-3-7-sonnet",
    "claude-3-5-sonnet",
    "claude-haiku-4-5",
    "claude-3-5-haiku",
    "claude-sonnet-4-5",
    "claude-sonnet-4-6",
    "claude-fable-5",
)


def build_claude_cli_model_aliases(models: Iterable[str]) -> dict[str, str]:
    """Return upstream-model to Claude CLI transport-model mappings."""
    normalized = sorted({str(model).strip() for model in models if str(model).strip()})
    aliases: dict[str, str] = {}
    reserved = {model for model in normalized if model in CLAUDE_CLI_MODEL_IDS}

    for model in normalized:
        if model in CLAUDE_CLI_MODEL_IDS:
            aliases[model] = model

    available_aliases = [alias for alias in CLAUDE_CLI_ALIAS_POOL if alias not in reserved]
    for model in normalized:
        if model in aliases:
            continue
        aliases[model] = available_aliases.pop(0) if available_aliases else model
    return aliases


def build_claude_router_model_map(models: Iterable[str]) -> dict[str, str]:
    """Return Router mappings for direct model names and CLI transport aliases."""
    aliases = build_claude_cli_model_aliases(models)
    router_models = {model: model for model in aliases}
    router_models.update({alias: model for model, alias in aliases.items()})
    return router_models


def _configured_macode_models(settings: Settings) -> set[str]:
    """Return Macode models explicitly configured for the provider or Agents."""
    models: set[str] = set()
    default_model = str(getattr(settings, "TURING_DEFAULT_MODEL", "") or "").strip()
    if default_model:
        models.add(default_model)

    raw_config = getattr(settings, "AGENT_LLM_CONFIG", "") or ""
    try:
        parsed = json.loads(raw_config) if raw_config else {}
    except (TypeError, json.JSONDecodeError):
        parsed = {}
    if isinstance(parsed, dict):
        for entry in parsed.values():
            if not isinstance(entry, dict):
                continue
            provider = str(entry.get("provider") or "macode").strip().lower()
            model = str(entry.get("model") or "").strip()
            if provider == "macode" and model:
                models.add(model)
    return models


def resolve_claude_cli_transport_model(
    model: str,
    upstream_provider: Optional[str] = None,
    settings: Optional[Settings] = None,
) -> str:
    """Resolve the CLI-safe transport model without changing UI configuration."""
    requested_model = str(model or "").strip()
    if not requested_model:
        return requested_model
    provider = str(upstream_provider or "macode").strip().lower()
    if provider != "macode" or requested_model in CLAUDE_CLI_MODEL_IDS:
        return requested_model

    resolved_settings = settings or get_settings()
    configured_models = _configured_macode_models(resolved_settings)
    if requested_model not in configured_models:
        return requested_model
    return build_claude_cli_model_aliases(configured_models).get(
        requested_model,
        requested_model,
    )


@dataclass(frozen=True)
class AgentLLMSelection:
    """Resolved logical provider and model for one Agent."""

    provider: str
    runtime_provider: str
    model: str


def resolve_agent_llm_selection(
    agent_type: str,
    settings: Optional[Settings] = None,
) -> AgentLLMSelection:
    """Resolve one Agent's provider and model with global defaults as fallback."""
    resolved_settings = settings or get_settings()
    default_provider = str(
        getattr(resolved_settings, "DEFAULT_PROVIDER", "macode") or "macode"
    ).strip().lower()
    if default_provider not in AGENT_LLM_PROVIDERS:
        default_provider = "macode"

    raw_config = getattr(resolved_settings, "AGENT_LLM_CONFIG", "") or ""
    try:
        parsed = json.loads(raw_config) if raw_config else {}
    except (TypeError, json.JSONDecodeError):
        parsed = {}
    if not isinstance(parsed, dict):
        parsed = {}

    entry = parsed.get(agent_type, {})
    if not isinstance(entry, dict):
        entry = {}
    provider = str(entry.get("provider") or default_provider).strip().lower()
    if provider not in AGENT_LLM_PROVIDERS:
        provider = default_provider

    configured_model = str(entry.get("model") or "").strip()
    if provider == "bedrock":
        default_model = resolve_bedrock_default_model(resolved_settings)
    else:
        default_model = (
            getattr(resolved_settings, "TURING_DEFAULT_MODEL", None)
            or "claude-sonnet-4-6"
        )

    return AgentLLMSelection(
        provider=provider,
        runtime_provider="claude_cli",
        model=configured_model or default_model,
    )


def get_agent_llm_config(settings: Optional[Settings] = None) -> dict[str, dict[str, str]]:
    """Return normalized provider and model settings for every configurable Agent."""
    resolved_settings = settings or get_settings()
    return {
        agent_type: {
            "provider": selection.provider,
            "model": selection.model,
        }
        for agent_type in AGENT_LLM_IDS
        for selection in [resolve_agent_llm_selection(agent_type, resolved_settings)]
    }


def resolve_claude_cli_model(settings: Settings) -> str:
    """Resolve the effective Claude CLI model based on DEFAULT_PROVIDER.

    Priority:
    1. CLAUDE_CLI_DEFAULT_MODEL (explicit override)
    2. Model from the DEFAULT_PROVIDER — read directly from .env file
       to avoid system env var override contamination
    3. Fallback to claude-sonnet-4-5
    """
    if settings.CLAUDE_CLI_DEFAULT_MODEL:
        return settings.CLAUDE_CLI_DEFAULT_MODEL

    # Read directly from .env file to avoid system env var contamination
    env_file = _BACKEND_DIR / ".env"
    env_values: dict[str, str] = {}
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            env_values[k.strip()] = v.strip()

    provider = (env_values.get("DEFAULT_PROVIDER") or settings.DEFAULT_PROVIDER).lower()
    if provider == "openrouter":
        return env_values.get("OPENROUTER_DEFAULT_MODEL") or settings.OPENROUTER_DEFAULT_MODEL or "claude-sonnet-4-5"
    elif provider == "turing":
        return env_values.get("TURING_DEFAULT_MODEL") or settings.TURING_DEFAULT_MODEL or "claude-sonnet-4-5"
    elif provider == "anthropic":
        return env_values.get("ANTHROPIC_DEFAULT_MODEL") or settings.ANTHROPIC_DEFAULT_MODEL or "claude-sonnet-4-5"
    elif provider == "bedrock":
        return (
            env_values.get("ANTHROPIC_DEFAULT_SONNET_MODEL")
            or env_values.get("ANTHROPIC_DEFAULT_OPUS_MODEL")
            or env_values.get("ANTHROPIC_DEFAULT_HAIKU_MODEL")
            or env_values.get("BEDROCK_DEFAULT_MODEL")
            or resolve_bedrock_default_model(settings)
        )
    elif provider == "gateway":
        return (
            env_values.get("GATEWAY_DEFAULT_MODEL")
            or settings.GATEWAY_DEFAULT_MODEL
            or settings.TURING_DEFAULT_MODEL
            or "claude-sonnet-4-5"
        )
    return env_values.get("TURING_DEFAULT_MODEL") or settings.TURING_DEFAULT_MODEL or "claude-sonnet-4-5"


def _positive_int_or_default(value: object, default: int) -> int:
    """Return a positive integer setting value, falling back to a safe default."""
    try:
        parsed = int(value) if value is not None else int(default)
    except (TypeError, ValueError):
        parsed = int(default)
    return parsed if parsed > 0 else int(default)


def get_claude_code_max_tokens(settings: Optional[Settings] = None) -> int:
    """Return the configured Claude CLI working token budget."""
    settings = settings or get_settings()
    return _positive_int_or_default(
        getattr(settings, "CLAUDE_CODE_MAX_TOKENS", DEFAULT_CLAUDE_CODE_MAX_TOKENS),
        DEFAULT_CLAUDE_CODE_MAX_TOKENS,
    )


def get_claude_code_max_output_tokens(settings: Optional[Settings] = None) -> int:
    """Return the configured Claude CLI output token budget."""
    settings = settings or get_settings()
    return _positive_int_or_default(
        getattr(
            settings,
            "CLAUDE_CODE_MAX_OUTPUT_TOKENS",
            DEFAULT_CLAUDE_CODE_MAX_OUTPUT_TOKENS,
        ),
        DEFAULT_CLAUDE_CODE_MAX_OUTPUT_TOKENS,
    )


def get_model_context_window(model: Optional[str]) -> Optional[int]:
    """Return a known provider context window for a Claude model id."""
    normalized = str(model or "").strip().lower()
    for marker, window in _MODEL_REAL_CONTEXT_WINDOWS.items():
        if marker in normalized:
            return window
    return None


def get_assumed_context_window(
    model: Optional[str],
    settings: Optional[Settings] = None,
) -> int:
    """Return the assumed context window for an unlisted model."""
    if "claude" in str(model or "").strip().lower():
        return 200_000
    settings = settings or get_settings()
    return _positive_int_or_default(
        getattr(
            settings,
            "CLAUDE_CODE_UNKNOWN_MODEL_CONTEXT_WINDOW",
            DEFAULT_CLAUDE_CODE_UNKNOWN_MODEL_CONTEXT_WINDOW,
        ),
        DEFAULT_CLAUDE_CODE_UNKNOWN_MODEL_CONTEXT_WINDOW,
    )


def _min_input_allowance_window(settings: Optional[Settings] = None) -> int:
    return get_claude_code_max_output_tokens(settings) + _MIN_INPUT_ALLOWANCE_TOKENS


def get_effective_context_window(
    model: Optional[str],
    settings: Optional[Settings] = None,
) -> int:
    """Calibrate Claude CLI context limits against a model's provider window."""
    configured = get_claude_code_max_tokens(settings)
    real_window = get_model_context_window(model)
    if real_window is None:
        if configured != DEFAULT_CLAUDE_CODE_MAX_TOKENS:
            return configured
        real_window = get_assumed_context_window(model, settings)
    safe = max(
        min(
            int(real_window * _CONTEXT_WINDOW_SAFETY_RATIO),
            real_window - _CONTEXT_WINDOW_SAFETY_MARGIN_TOKENS,
        ),
        _CONTEXT_WINDOW_MIN_TOKENS,
    )
    safe = min(max(safe, _min_input_allowance_window(settings)), real_window)
    output_tokens = get_claude_code_max_output_tokens(settings)
    allowance = safe - output_tokens
    key = (safe, output_tokens)
    if allowance < _MIN_INPUT_ALLOWANCE_TOKENS and key not in _STARVED_INPUT_ALLOWANCE_WARNED:
        _STARVED_INPUT_ALLOWANCE_WARNED.add(key)
        import logging

        logging.getLogger(__name__).warning(
            "Claude Code context window %d leaves only %d input tokens after output reservation",
            safe,
            allowance,
        )
    if configured == DEFAULT_CLAUDE_CODE_MAX_TOKENS:
        return safe
    return min(configured, safe)


def apply_claude_code_token_env(
    env: dict[str, str],
    settings: Optional[Settings] = None,
    model: Optional[str] = None,
) -> dict[str, str]:
    """Set CLI token ceilings while preserving the caller's Router environment."""
    settings = settings or get_settings()
    resolved_model = model
    if resolved_model is None:
        try:
            resolved_model = resolve_claude_cli_model(settings)
        except (AttributeError, OSError, TypeError, ValueError):
            resolved_model = None
    context_window = get_effective_context_window(resolved_model, settings)
    env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(
        get_claude_code_max_output_tokens(settings)
    )
    env["CLAUDE_CODE_AUTO_COMPACT_WINDOW"] = str(context_window)
    env["CLAUDE_CODE_BLOCKING_LIMIT_OVERRIDE"] = str(context_window)
    env["MAX_MCP_OUTPUT_TOKENS"] = str(context_window)
    env["CLAUDE_CODE_FILE_READ_MAX_OUTPUT_TOKENS"] = str(context_window)
    return env


def get_resolved_cli_path() -> str:
    """Return the absolute Claude CLI path (relative paths resolved from backend/)."""
    cli_path = Path(get_settings().CLAUDE_CLI_PATH)
    if not cli_path.is_absolute():
        return str((_BACKEND_DIR / cli_path).resolve())
    return str(cli_path)


def get_resolved_claude_config_dir() -> str:
    """Return the absolute Claude config directory (relative paths resolved from backend/).

    This is injected as CLAUDE_CONFIG_DIR env var when spawning Claude CLI,
    so the project-bundled CLI stores all state (sessions, cache, history,
    telemetry, settings) inside the project instead of the global ~/.claude.
    """
    cfg_dir = Path(get_settings().CLAUDE_CONFIG_DIR)
    if not cfg_dir.is_absolute():
        cfg_dir = (_BACKEND_DIR / cfg_dir).resolve()
    cfg_dir.mkdir(parents=True, exist_ok=True)
    return str(cfg_dir)


def get_resolved_qbs_path() -> str:
    """
    Detect the QBS executable path by priority to ensure an out-of-the-box experience.

    Detection order:
    1. Absolute path explicitly specified via environment variable or config file
    2. Bundled binary inside the repository: bin/qbs/qbs(.exe)
    3. System PATH
    4. Common Qt installation directories
    """
    settings = get_settings()
    configured = settings.QBS_PATH

    # 1. The configured value is an existing absolute path → use it directly
    p = Path(configured)
    if p.is_absolute() and p.exists():
        return str(p)

    # 2. Bundled binary inside the repository (backend/../bin/qbs/bin/qbs.exe)
    _PROJECT_ROOT = _BACKEND_DIR.parent
    is_win = _platform.system() == "Windows"
    repo_bin = _PROJECT_ROOT / "bin" / "qbs" / "bin" / ("qbs.exe" if is_win else "qbs")
    if repo_bin.exists():
        return str(repo_bin.resolve())

    # 3. System PATH
    which = _shutil.which("qbs")
    if which:
        return which

    # 4. Common Qt installation directories
    if is_win:
        for base in [Path("C:/Qt"), Path("D:/Qt")]:
            if base.exists():
                candidates = sorted(base.glob("Tools/QtCreator/bin/qbs.exe"), reverse=True)
                if candidates:
                    return str(candidates[0])
    else:
        for candidate in ["/usr/bin/qbs", "/usr/local/bin/qbs"]:
            if Path(candidate).exists():
                return candidate

    # Fallback: return the configured value so the later _check_tool can raise an error
    return configured


def get_qbs_settings_dir() -> str:
    """Return the absolute path of the project-local QBS settings directory (bin/qbs/settings/)."""
    return str((_BACKEND_DIR.parent / "bin" / "qbs" / "settings").resolve())


def get_qbs_bin_dir() -> str:
    """Return the absolute path of bin/qbs/bin/ for locating qbs-config and qbs-setup-toolchains."""
    return str((_BACKEND_DIR.parent / "bin" / "qbs" / "bin").resolve())


def get_mingw_bin_dir() -> str:
    """Return the absolute path of the bundled MinGW toolchain bin/ directory."""
    return str((_BACKEND_DIR.parent / "bin" / "mingw" / "bin").resolve())
