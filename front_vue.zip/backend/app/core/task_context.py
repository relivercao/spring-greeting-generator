"""Task-scoped runtime context shared across agent and LLM layers."""

from contextvars import ContextVar, Token
from typing import Optional


_current_task_id: ContextVar[Optional[str]] = ContextVar(
    "current_agent_task_id",
    default=None,
)


def get_current_task_id() -> Optional[str]:
    """Return the task ID bound to the current asynchronous execution."""
    return _current_task_id.get()


def set_current_task_id(task_id: str) -> Token:
    """Bind a task ID and return the token required to restore the context."""
    return _current_task_id.set(task_id)


def reset_current_task_id(token: Token) -> None:
    """Restore the task context represented by the token."""
    _current_task_id.reset(token)
