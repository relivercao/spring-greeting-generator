"""Execution metadata copied into detached usage callbacks and CLI threads."""

from contextvars import ContextVar

usage_context: ContextVar[dict] = ContextVar("llm_usage_context", default={})
