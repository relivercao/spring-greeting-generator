"""
@file validators.py
@author caoshwen
@brief Input validation and sanitization for Macode.

@version 3.2
@date 2026-07-25

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import re
from typing import Optional, List
from .exceptions import PromptInjectionError, InputValidationError


# ============================================================
# Prompt Injection Detection Patterns
# ============================================================

INJECTION_PATTERNS = [
    # System prompt manipulation
    (r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|rules?)", "system_override"),
    (r"disregard\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|rules?)", "system_override"),
    (r"forget\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|rules?)", "system_override"),
    
    # Role manipulation
    (r"you\s+are\s+now\s+(a|an)\s+\w+", "role_injection"),
    (r"act\s+as\s+(a|an)\s+\w+", "role_injection"),
    (r"pretend\s+to\s+be\s+(a|an)\s+\w+", "role_injection"),
    (r"simulate\s+(a|an)\s+\w+", "role_injection"),
    
    # System access attempts
    (r"show\s+me\s+(your|the)\s+system\s+prompt", "system_access"),
    (r"what\s+(is|are)\s+your\s+(original\s+)?instructions?", "system_access"),
    (r"reveal\s+your\s+(system\s+)?prompt", "system_access"),
    (r"print\s+your\s+(system\s+)?prompt", "system_access"),
    
    # Command injection
    (r"execute\s+command", "command_injection"),
    (r"run\s+command", "command_injection"),
    (r"eval\s*\(", "code_injection"),
    (r"exec\s*\(", "code_injection"),
    
    # Jailbreak attempts
    (r"developer\s+mode", "jailbreak"),
    (r"DAN\s+mode", "jailbreak"),
    (r"bypass\s+(all\s+)?restrictions?", "jailbreak"),
]


# ============================================================
# Validation Functions
# ============================================================

def sanitize_prompt(
    prompt: str,
    max_length: int = 10000,
    check_injection: bool = True,
    strict_mode: bool = False
) -> str:
    """
    Sanitize user prompt input.
    
    Args:
        prompt: User input prompt
        max_length: Maximum allowed length
        check_injection: Whether to check for injection attempts
        strict_mode: If True, raise exception on detection. If False, sanitize and log.
    
    Returns:
        Sanitized prompt
    
    Raises:
        InputValidationError: If validation fails
        PromptInjectionError: If injection detected in strict mode
    """
    # Check empty input
    if not prompt or not prompt.strip():
        raise InputValidationError("prompt", "Prompt cannot be empty")
    
    # Check length
    if len(prompt) > max_length:
        raise InputValidationError(
            "prompt", 
            f"Prompt exceeds maximum length of {max_length} characters"
        )
    
    # Check for injection patterns
    if check_injection:
        sanitized_prompt = _detect_and_sanitize_injection(prompt, strict_mode)
        return sanitized_prompt
    
    return prompt.strip()


def _detect_and_sanitize_injection(prompt: str, strict_mode: bool) -> str:
    """
    Detect and handle potential prompt injection attempts.
    
    Args:
        prompt: User input
        strict_mode: If True, raise exception. If False, sanitize.
    
    Returns:
        Sanitized prompt (if not strict)
    
    Raises:
        PromptInjectionError: If injection detected in strict mode
    """
    import logging
    from app.infrastructure.observability.logger import LoggerService
    
    logger = LoggerService.get_logger("validators")
    prompt_lower = prompt.lower()
    
    for pattern, injection_type in INJECTION_PATTERNS:
        if re.search(pattern, prompt_lower, re.IGNORECASE):
            logger.warning(
                "Potential prompt injection detected",
                pattern=pattern,
                injection_type=injection_type,
                prompt_snippet=prompt[:100]
            )
            
            if strict_mode:
                raise PromptInjectionError(injection_type)
            else:
                # In non-strict mode, remove the suspicious pattern
                prompt = re.sub(pattern, "[REDACTED]", prompt, flags=re.IGNORECASE)
    
    return prompt.strip()


def validate_session_id(session_id: str) -> str:
    """
    Validate session ID format.
    
    Args:
        session_id: Session identifier
    
    Returns:
        Validated session ID
    
    Raises:
        InputValidationError: If validation fails
    """
    if not session_id:
        raise InputValidationError("session_id", "Session ID cannot be empty")
    
    # Session IDs should be alphanumeric with hyphens, 8-64 chars
    if not re.match(r'^[a-zA-Z0-9\-]{8,64}$', session_id):
        raise InputValidationError(
            "session_id",
            "Session ID must be 8-64 alphanumeric characters with optional hyphens"
        )
    
    return session_id


def validate_agent_type(agent_type: str, allowed_types: List[str]) -> str:
    """
    Validate agent type against allowed values.
    
    Args:
        agent_type: Agent type string
        allowed_types: List of allowed agent types
    
    Returns:
        Validated agent type
    
    Raises:
        InputValidationError: If validation fails
    """
    if not agent_type:
        raise InputValidationError("agent_type", "Agent type cannot be empty")
    
    if agent_type not in allowed_types:
        raise InputValidationError(
            "agent_type",
            f"Invalid agent type '{agent_type}'. Allowed: {', '.join(allowed_types)}"
        )
    
    return agent_type


def validate_file_path(file_path: str, max_length: int = 512) -> str:
    """
    Validate file path input.
    
    Args:
        file_path: File path string
        max_length: Maximum path length
    
    Returns:
        Validated file path
    
    Raises:
        InputValidationError: If validation fails
    """
    if not file_path:
        raise InputValidationError("file_path", "File path cannot be empty")
    
    if len(file_path) > max_length:
        raise InputValidationError(
            "file_path",
            f"File path exceeds maximum length of {max_length}"
        )
    
    # Check for path traversal attempts
    dangerous_patterns = [
        r'\.\.',  # Parent directory
        r'~/',    # Home directory
        r'/etc/', # System directories
        r'/proc/',
        r'/sys/',
        r'\\\\',  # UNC paths
    ]
    
    for pattern in dangerous_patterns:
        if re.search(pattern, file_path):
            raise InputValidationError(
                "file_path",
                f"File path contains dangerous pattern: {pattern}"
            )
    
    return file_path


def validate_email(email: str) -> str:
    """
    Validate email address format.
    
    Args:
        email: Email address
    
    Returns:
        Validated email
    
    Raises:
        InputValidationError: If validation fails
    """
    if not email:
        raise InputValidationError("email", "Email cannot be empty")
    
    # Simple email regex (RFC 5322 simplified)
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        raise InputValidationError("email", "Invalid email format")
    
    if len(email) > 254:  # RFC 5321
        raise InputValidationError("email", "Email exceeds maximum length")
    
    return email.lower()


def validate_username(username: str) -> str:
    """
    Validate username format.
    
    Args:
        username: Username string
    
    Returns:
        Validated username
    
    Raises:
        InputValidationError: If validation fails
    """
    if not username:
        raise InputValidationError("username", "Username cannot be empty")
    
    if len(username) < 3:
        raise InputValidationError("username", "Username must be at least 3 characters")
    
    if len(username) > 32:
        raise InputValidationError("username", "Username cannot exceed 32 characters")
    
    # Username: alphanumeric, underscore, hyphen only
    if not re.match(r'^[a-zA-Z0-9_-]+$', username):
        raise InputValidationError(
            "username",
            "Username can only contain letters, numbers, underscores, and hyphens"
        )
    
    return username


def sanitize_sql_like_pattern(pattern: str) -> str:
    """
    Sanitize SQL LIKE pattern to prevent SQL injection.
    
    Args:
        pattern: SQL LIKE pattern
    
    Returns:
        Sanitized pattern
    """
    # Escape special SQL LIKE characters
    pattern = pattern.replace('\\', '\\\\')
    pattern = pattern.replace('%', '\\%')
    pattern = pattern.replace('_', '\\_')
    pattern = pattern.replace('[', '\\[')
    pattern = pattern.replace(']', '\\]')
    
    return pattern


def validate_pagination(
    limit: Optional[int] = None,
    offset: Optional[int] = None,
    max_limit: int = 100
) -> tuple[int, int]:
    """
    Validate pagination parameters.
    
    Args:
        limit: Maximum records to return
        offset: Number of records to skip
        max_limit: Maximum allowed limit
    
    Returns:
        Tuple of (validated_limit, validated_offset)
    
    Raises:
        InputValidationError: If validation fails
    """
    # Default values
    validated_limit = limit if limit is not None else 20
    validated_offset = offset if offset is not None else 0
    
    # Validate limit
    if validated_limit < 1:
        raise InputValidationError("limit", "Limit must be at least 1")
    
    if validated_limit > max_limit:
        raise InputValidationError(
            "limit",
            f"Limit cannot exceed {max_limit}"
        )
    
    # Validate offset
    if validated_offset < 0:
        raise InputValidationError("offset", "Offset cannot be negative")
    
    return validated_limit, validated_offset


# ============================================================
# Content Sanitization
# ============================================================

def sanitize_html(content: str) -> str:
    """
    Remove potentially dangerous HTML tags and attributes.
    
    Args:
        content: HTML content
    
    Returns:
        Sanitized HTML
    """
    # Remove script tags
    content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL | re.IGNORECASE)
    
    # Remove event handlers
    content = re.sub(r'\s*on\w+\s*=\s*["\']?[^"\']*["\']?', '', content, flags=re.IGNORECASE)
    
    # Remove javascript: URLs
    content = re.sub(r'javascript:', '', content, flags=re.IGNORECASE)
    
    return content


def escape_markdown(text: str) -> str:
    """
    Escape special Markdown characters.
    
    Args:
        text: Text with Markdown
    
    Returns:
        Escaped text
    """
    special_chars = ['\\', '`', '*', '_', '{', '}', '[', ']', '(', ')', '#', '+', '-', '.', '!']
    for char in special_chars:
        text = text.replace(char, '\\' + char)
    return text
