"""
@file middleware.py
@author caoshwen
@brief FastAPI middleware: exception handling, rate limiting, request logging.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
import uuid
from collections import defaultdict
from typing import Callable, Optional

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from app.core.billing_context import reset_billing_user_id, set_billing_user_id
from app.infrastructure.observability.logger import LoggerService
from app.infrastructure.observability.metrics import MetricsCollector

log = LoggerService.get_logger("middleware")


# ============================================================
# 1. RequestLoggingMiddleware -- Request logging + trace_id
# ============================================================

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    For each request:
    - Inject X-Trace-ID response header
    - Log request method/path/status code/duration
    - Report metrics to MetricsCollector
    """

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        trace_id = request.headers.get("X-Trace-ID") or uuid.uuid4().hex
        request.state.trace_id = trace_id

        start = time.monotonic()
        response = await call_next(request)
        duration = time.monotonic() - start

        status_code = response.status_code
        method = request.method
        path = request.url.path

        # Skip logging for health check and high-frequency polling endpoints
        skip_log = (
            path in ("/health", "/metrics")
            or (method == "GET" and "/unittest/tasks/" in path and status_code == 200)
        )
        if not skip_log:
            log.info(
                "HTTP request",
                trace_id=trace_id,
                method=method,
                path=path,
                status_code=status_code,
                duration_ms=round(duration * 1000, 2),
                client=request.client.host if request.client else "unknown",
            )

        # Report metrics
        try:
            metrics = MetricsCollector.get_instance()
            metrics.record_http_request(method, path, status_code, duration)
        except Exception:
            pass  # Metrics reporting should not affect the request

        response.headers["X-Trace-ID"] = trace_id
        return response


# ============================================================
# 2. RateLimitMiddleware -- Simple in-memory rate limiting
# ============================================================

class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Simple sliding window rate limiting based on client IP.

    Phase 1: In-memory implementation (single process)
    Phase 2: Redis distributed rate limiting
    """

    def __init__(
        self,
        app: FastAPI,
        max_requests: int = 100,
        window_seconds: int = 60,
        exclude_paths: tuple[str, ...] = ("/health", "/metrics", "/"),
        exclude_path_prefixes: tuple[str, ...] = ("/api/v1/payment/webhook",),
    ):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.exclude_paths = exclude_paths
        self.exclude_path_prefixes = exclude_path_prefixes
        # client_ip -> list[timestamp]
        self._requests: dict[str, list[float]] = defaultdict(list)

    def _is_exempt(self, path: str) -> bool:
        """Return True for exact exclude paths and exempt path prefixes."""
        return (
            path in self.exclude_paths
            or path.startswith(self.exclude_path_prefixes)
        )

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        # Rate limiting disabled - pass through all requests.  The exemption
        # check stays so re-enabling the limiter never throttles external
        # payment gateway webhooks (providers retry notify calls in storms).
        if self._is_exempt(request.url.path):
            return await call_next(request)
        return await call_next(request)


# ============================================================
# 3. GlobalExceptionMiddleware -- Global exception handling
# ============================================================

class GlobalExceptionMiddleware(BaseHTTPMiddleware):
    """
    Catch all unhandled exceptions, return structured JSON error response,
    prevent stack trace leakage to the client.
    """

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        try:
            return await call_next(request)
        except Exception as exc:
            trace_id = getattr(request.state, "trace_id", "unknown")
            log.error(
                "Unhandled exception",
                trace_id=trace_id,
                method=request.method,
                path=request.url.path,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            return JSONResponse(
                status_code=500,
                content={
                    "detail": "Internal server error",
                    "trace_id": trace_id,
                },
            )


# ============================================================
# 4. BillingContextMiddleware -- request-scoped billing identity
# ============================================================

def _decode_billing_token(token: str) -> Optional[dict]:
    """Best-effort JWT decode for the billing context; never raises."""
    try:
        from app.core.security import decode_token

        return decode_token(token)
    except Exception:
        return None


class BillingContextMiddleware(BaseHTTPMiddleware):
    """
    Bind the billing user id ContextVar from the request's Bearer token.

    The context is set on a best-effort basis: requests without a Bearer
    header, or with an invalid/expired token, simply run without a billing
    identity (guest policy).  This middleware never rejects a request by
    itself - the endpoint level pre-check decides.
    """

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return await call_next(request)

        payload = _decode_billing_token(auth_header[len("Bearer "):])
        user_id = (payload or {}).get("user_id") or (payload or {}).get("sub")
        if not user_id:
            return await call_next(request)

        context_token = set_billing_user_id(str(user_id))
        try:
            return await call_next(request)
        finally:
            reset_billing_user_id(context_token)
