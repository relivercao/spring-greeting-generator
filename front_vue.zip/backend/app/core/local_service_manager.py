"""
@file local_service_manager.py
@brief Manages the Local File Selector service lifecycle.
@author zhangjian
Starts/stops the local file selector service as a background process.
This service provides file selection dialogs with full path access.
"""
import asyncio
import os
import subprocess
import sys
import uuid
from pathlib import Path

from loguru import logger


_BACKEND_DIR = Path(__file__).parent.parent.parent
_SELECTOR_SCRIPT = _BACKEND_DIR / "app" / "services" / "local_file_selector.py"
_SELECTOR_PYC = _BACKEND_DIR / "app" / "services" / "local_file_selector.pyc"
_SELECTOR_LOG = _BACKEND_DIR / "logs" / "local_file_selector.log"


class LocalServiceManager:
    """Manage Local File Selector as a subprocess."""

    def __init__(self, host: str = "127.0.0.1", port: int = 9999):
        self._host = host
        self._port = port
        self._process: subprocess.Popen | None = None
        self._instance_id = uuid.uuid4().hex

    async def start(self):
        """Start the Local File Selector subprocess if not already running."""
        status = await self._probe_service()
        if status["healthy"] and status["instance_match"]:
            logger.info(
                f"Local File Selector already running on {self._host}:{self._port} "
                f"(instance_id={self._instance_id})"
            )
            return True

        if status["healthy"] and not status["instance_match"]:
            logger.warning(
                "Local File Selector port is occupied by a different instance; restarting it",
                current_instance=status.get("instance_id"),
                expected_instance=self._instance_id,
                script_path=status.get("script_path"),
            )
            await self._terminate_port_owner()

        selector_entry = _SELECTOR_PYC if _SELECTOR_PYC.exists() else _SELECTOR_SCRIPT
        if not selector_entry.exists():
            logger.warning(f"Local File Selector script not found: {selector_entry}")
            return False

        _SELECTOR_LOG.parent.mkdir(parents=True, exist_ok=True)
        log_handle = open(_SELECTOR_LOG, "a", encoding="utf-8")
        env = os.environ.copy()
        env["LOCAL_FILE_SELECTOR_INSTANCE_ID"] = self._instance_id

        self._process = subprocess.Popen(
            [sys.executable, str(selector_entry)],
            stdout=log_handle,
            stderr=log_handle,
            cwd=str(_BACKEND_DIR),
            env=env,
        )

        for _ in range(20):
            await asyncio.sleep(0.5)
            status = await self._probe_service()
            if status["healthy"] and status["instance_match"]:
                logger.info(
                    f"Local File Selector started on {self._host}:{self._port} "
                    f"(pid={self._process.pid}, instance_id={self._instance_id})"
                )
                return True

            if self._process.poll() is not None:
                logger.warning(
                    "Local File Selector exited during startup",
                    returncode=self._process.returncode,
                    log_path=str(_SELECTOR_LOG),
                )
                return False

        logger.warning(
            "Local File Selector failed to become healthy within 10s",
            log_path=str(_SELECTOR_LOG),
            instance_id=self._instance_id,
        )
        return False

    async def stop(self):
        """Stop the Local File Selector subprocess."""
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None
            logger.info("Local File Selector stopped")

    async def _probe_service(self) -> dict:
        """Probe the service and verify it matches this manager instance."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=2.0) as client:
                resp = await client.get(f"http://{self._host}:{self._port}/health")
                if resp.status_code != 200:
                    return {"healthy": False, "instance_match": False}
                data = resp.json()
                return {
                    "healthy": True,
                    "instance_match": data.get("instance_id") == self._instance_id,
                    "instance_id": data.get("instance_id"),
                    "script_path": data.get("script_path"),
                }
        except Exception:
            return {"healthy": False, "instance_match": False}

    async def _terminate_port_owner(self) -> None:
        """Terminate the current owner of the selector port so a fresh instance can start."""
        try:
            import psutil
        except ImportError:
            logger.warning("psutil unavailable; cannot replace stale Local File Selector process")
            return

        target_pid = None
        try:
            connections = psutil.net_connections(kind="inet")
            for conn in connections:
                laddr = getattr(conn, "laddr", None)
                if not laddr:
                    continue
                if conn.status == psutil.CONN_LISTEN and laddr.port == self._port:
                    target_pid = conn.pid
                    break
        except Exception as exc:
            logger.warning("Failed to inspect selector port owner", error=str(exc), port=self._port)

        if target_pid:
            try:
                proc = psutil.Process(target_pid)
                proc.kill()
                logger.info("Killed selector port owner", pid=target_pid, port=self._port)
                await asyncio.sleep(1)
                return
            except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
                logger.warning("Failed to kill selector port owner", pid=target_pid, error=str(exc))

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                cmdline = " ".join(proc.info.get("cmdline") or [])
                if (
                    "local_file_selector.py" in cmdline
                    or "local_file_selector.pyc" in cmdline
                ) and (f":{self._port}" in cmdline or f" {self._port}" in cmdline or "9999" in cmdline):
                    proc.kill()
                    logger.info("Killed stale Local File Selector process", pid=proc.info["pid"])
                    await asyncio.sleep(1)
                    return
            except (psutil.NoSuchProcess, psutil.AccessDenied, TypeError):
                continue

    def get_url(self) -> str:
        """Get the service URL."""
        return f"http://{self._host}:{self._port}"
