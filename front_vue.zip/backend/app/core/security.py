"""
@file security.py
@author caoshwen
@brief JWT authentication and bcrypt password utilities.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import uuid
from typing import Optional

import bcrypt as _bcrypt
from fastapi import Depends, HTTPException, Request, Response, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.database import get_db
from app.models.user import User

settings = get_settings()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_PREFIX}/auth/login")

GUEST_COOKIE_NAME = "fw_guest_id"
GUEST_COOKIE_MAX_AGE_SECONDS = 60 * 60 * 24 * 30
GUEST_ID_PREFIX = "guest:"
GUEST_DATABASE_ID_PREFIX = "g-"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password"""
    return _bcrypt.checkpw(
        plain_password.encode("utf-8"), hashed_password.encode("utf-8")
    )


def get_password_hash(password: str) -> str:
    """Generate password hash"""
    return _bcrypt.hashpw(
        password.encode("utf-8"), _bcrypt.gensalt()
    ).decode("utf-8")


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create access token"""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire, "type": "access"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(data: dict) -> str:
    """Create refresh token"""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> dict:
    """Decode JWT token"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


async def get_current_user(token: str = Depends(oauth2_scheme)):
    """Get current user from token"""
    payload = decode_token(token)
    username: str = payload.get("sub")
    user_id: str = payload.get("user_id")
    if username is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return {"id": user_id or "unknown", "username": username, "email": ""}


async def get_current_active_user(current_user=Depends(get_current_user)):
    """Get current active user"""
    return current_user


async def get_current_admin_user(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Get current user and require administrator privileges."""
    result = await db.execute(select(User).where(User.id == current_user["id"]))
    user = result.scalar_one_or_none()
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator privileges required",
        )
    return user


def get_optional_user_from_request(
    request: Request,
    anonymous_id: str = "anonymous",
) -> dict[str, str]:
    """Return the bearer-token user or a local anonymous identity."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return {"id": anonymous_id, "username": anonymous_id}
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")

    payload = decode_token(auth_header[7:])
    if payload.get("type") != "access" or not payload.get("sub"):
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    return {
        "id": payload.get("user_id") or "unknown",
        "username": payload.get("sub") or "unknown",
    }


def _sign_guest_id(guest_uuid: str) -> str:
    signature = hmac.new(
        settings.SECRET_KEY.encode("utf-8"),
        guest_uuid.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"{GUEST_ID_PREFIX}{guest_uuid}.{signature}"


def _verify_guest_cookie(cookie_value: str | None) -> str | None:
    if not cookie_value or not cookie_value.startswith(GUEST_ID_PREFIX):
        return None
    guest_uuid, separator, signature = cookie_value[len(GUEST_ID_PREFIX):].partition(".")
    if not separator or not signature:
        return None
    try:
        uuid.UUID(guest_uuid)
    except ValueError:
        return None
    if not hmac.compare_digest(cookie_value, _sign_guest_id(guest_uuid)):
        return None
    return guest_uuid


def get_optional_user(request: Request, response: Response | None = None) -> dict[str, str]:
    """Return an authenticated user or a stable signed browser guest identity."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        payload = decode_token(auth_header[7:])
        user_id = payload.get("user_id")
        username = payload.get("sub")
        if payload.get("type") != "access" or not user_id or not username:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return {"id": user_id, "username": username}
    if auth_header:
        raise HTTPException(status_code=401, detail="Invalid authorization header")

    guest_uuid = _verify_guest_cookie(request.cookies.get(GUEST_COOKIE_NAME))
    if guest_uuid is None:
        guest_uuid = str(uuid.uuid4())
        if response is not None:
            response.set_cookie(
                key=GUEST_COOKIE_NAME,
                value=_sign_guest_id(guest_uuid),
                max_age=GUEST_COOKIE_MAX_AGE_SECONDS,
                httponly=True,
                samesite="lax",
                secure=request.url.scheme == "https",
            )
    return {
        "id": f"{GUEST_DATABASE_ID_PREFIX}{guest_uuid.replace('-', '')}",
        "username": "guest",
    }
