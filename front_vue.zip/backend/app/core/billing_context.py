"""Request-scoped billing context shared across middleware and LLM layers."""

from contextvars import ContextVar, Token
from typing import Optional


_billing_user_id: ContextVar[Optional[str]] = ContextVar(
    "current_billing_user_id",
    default=None,
)


def get_billing_user_id() -> Optional[str]:
    """Return the user ID bound to the current request's billing context."""
    return _billing_user_id.get()


def set_billing_user_id(user_id: str) -> Token:
    """Bind a billing user ID and return the token required to restore the context."""
    return _billing_user_id.set(user_id)


def reset_billing_user_id(token: Token) -> None:
    """Restore the billing context represented by the token."""
    _billing_user_id.reset(token)
