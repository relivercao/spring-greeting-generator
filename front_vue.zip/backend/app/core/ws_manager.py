"""
@file ws_manager.py
@author caoshwen
@brief WebSocket connection manager for real-time communication.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import json
from datetime import datetime, timezone
from typing import Any

from fastapi import WebSocket
from loguru import logger


class ConnectionManager:
    """
    WebSocket connection manager.

    Responsibilities:
    - Maintain task_id -> WebSocket connections mapping
    - Push messages to all subscribers of the specified task
    - Handle connect/disconnect/errors
    """

    def __init__(self):
        # task_id -> set of active WebSocket connections
        self._connections: dict[str, set[WebSocket]] = {}
        self._lock = asyncio.Lock()

    async def connect(self, task_id: str, websocket: WebSocket) -> None:
        """Accept WebSocket connection and register to task"""
        await websocket.accept()
        async with self._lock:
            if task_id not in self._connections:
                self._connections[task_id] = set()
            self._connections[task_id].add(websocket)
        logger.debug(f"WebSocket connected for task {task_id}")

    async def disconnect(self, task_id: str, websocket: WebSocket) -> None:
        """Disconnect WebSocket connection"""
        async with self._lock:
            if task_id in self._connections:
                self._connections[task_id].discard(websocket)
                if not self._connections[task_id]:
                    del self._connections[task_id]
        logger.debug(f"WebSocket disconnected for task {task_id}")

    async def send_to_task(self, task_id: str, data: dict[str, Any]) -> None:
        """Push message to all subscribers of the specified task"""
        async with self._lock:
            connections = self._connections.get(task_id, set()).copy()

        dead_connections = []
        for ws in connections:
            try:
                await ws.send_json(data)
            except Exception:
                dead_connections.append(ws)

        # Clean up disconnected connections
        if dead_connections:
            async with self._lock:
                if task_id in self._connections:
                    for ws in dead_connections:
                        self._connections[task_id].discard(ws)

    async def send_progress(
        self,
        task_id: str,
        progress: int,
        stage: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Push task progress update"""
        data = {
            "type": "progress",
            "task_id": task_id,
            "progress": progress,
            "stage": stage,
            "message": message,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if details:
            data["details"] = details
        await self.send_to_task(task_id, data)

    async def send_stream_chunk(
        self,
        task_id: str,
        content: str,
        is_final: bool = False,
    ) -> None:
        """Push streaming output chunk (for LLM responses)"""
        await self.send_to_task(task_id, {
            "type": "stream",
            "task_id": task_id,
            "content": content,
            "is_final": is_final,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def send_error(self, task_id: str, error: str) -> None:
        """Push error message"""
        await self.send_to_task(task_id, {
            "type": "error",
            "task_id": task_id,
            "error": error,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    async def send_complete(
        self,
        task_id: str,
        result: dict[str, Any] | None = None,
    ) -> None:
        """Push task completion message"""
        data = {
            "type": "complete",
            "task_id": task_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if result:
            data["result"] = result
        await self.send_to_task(task_id, data)

    def has_subscribers(self, task_id: str) -> bool:
        """Check if task has active subscribers"""
        return bool(self._connections.get(task_id))

    @property
    def active_connections_count(self) -> int:
        """Total number of active connections"""
        return sum(len(conns) for conns in self._connections.values())


# Global singleton
ws_manager = ConnectionManager()
