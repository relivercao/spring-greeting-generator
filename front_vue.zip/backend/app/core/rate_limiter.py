"""
@file rate_limiter.py
@author caoshwen
@brief Per-user rate limiting for Macode.

@version 3.2
@date 2026-07-25

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import time
from typing import Optional, Dict
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from .exceptions import RateLimitExceededError


@dataclass
class RateLimitConfig:
    """Rate limit configuration."""
    max_requests_per_minute: int = 60
    max_requests_per_hour: int = 1000
    max_tokens_per_day: int = 1_000_000
    max_cost_per_month: float = 100.0


@dataclass
class UserUsage:
    """Track user usage metrics."""
    requests_per_minute: list = field(default_factory=list)
    requests_per_hour: list = field(default_factory=list)
    tokens_today: int = 0
    cost_this_month: float = 0.0
    last_reset_day: Optional[str] = None
    last_reset_month: Optional[str] = None


class UserRateLimiter:
    """Per-user rate limiter with multiple dimensions."""
    
    def __init__(
        self,
        max_requests_per_minute: int = 60,
        max_requests_per_hour: int = 1000,
        max_tokens_per_day: int = 1_000_000,
        max_cost_per_month: float = 100.0
    ):
        self.config = RateLimitConfig(
            max_requests_per_minute=max_requests_per_minute,
            max_requests_per_hour=max_requests_per_hour,
            max_tokens_per_day=max_tokens_per_day,
            max_cost_per_month=max_cost_per_month
        )
        self._user_usage: Dict[str, UserUsage] = defaultdict(UserUsage)
    
    def check_request_limit(self, user_id: str) -> None:
        """Check if user can make another request."""
        now = time.time()
        usage = self._user_usage[user_id]
        
        self._cleanup_old_requests(usage, now)
        
        if len(usage.requests_per_minute) >= self.config.max_requests_per_minute:
            oldest = usage.requests_per_minute[0]
            retry_after = int(60 - (now - oldest))
            raise RateLimitExceededError(
                "requests_per_minute",
                self.config.max_requests_per_minute,
                retry_after
            )
        
        if len(usage.requests_per_hour) >= self.config.max_requests_per_hour:
            oldest = usage.requests_per_hour[0]
            retry_after = int(3600 - (now - oldest))
            raise RateLimitExceededError(
                "requests_per_hour",
                self.config.max_requests_per_hour,
                retry_after
            )
        
        usage.requests_per_minute.append(now)
        usage.requests_per_hour.append(now)
    
    def get_usage_stats(self, user_id: str) -> dict:
        """Get current usage statistics for a user."""
        usage = self._user_usage[user_id]
        now = time.time()
        self._cleanup_old_requests(usage, now)
        
        return {
            "requests_per_minute": {
                "current": len(usage.requests_per_minute),
                "limit": self.config.max_requests_per_minute,
            },
            "requests_per_hour": {
                "current": len(usage.requests_per_hour),
                "limit": self.config.max_requests_per_hour,
            },
            "tokens_per_day": {
                "current": usage.tokens_today,
                "limit": self.config.max_tokens_per_day,
            },
        }
    
    def _cleanup_old_requests(self, usage: UserUsage, now: float) -> None:
        """Remove request timestamps older than their window."""
        minute_ago = now - 60
        usage.requests_per_minute = [ts for ts in usage.requests_per_minute if ts > minute_ago]
        
        hour_ago = now - 3600
        usage.requests_per_hour = [ts for ts in usage.requests_per_hour if ts > hour_ago]
