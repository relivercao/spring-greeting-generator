"""Canonical filesystem paths for the shared firmware knowledge base."""

from dataclasses import dataclass
from pathlib import Path

from app.core.config import _BACKEND_DIR


@dataclass(frozen=True)
class KnowledgeBasePaths:
    """Resolved paths used by Raw and Driver workflows."""

    root: Path
    raw: Path
    errata: Path


def get_knowledge_base_paths(root: str | Path | None = None) -> KnowledgeBasePaths:
    """Return canonical paths without depending on the process working directory."""
    knowledge_base_root = (
        Path(root).resolve()
        if root is not None
        else (_BACKEND_DIR / "data" / "knowledge-base").resolve()
    )
    return KnowledgeBasePaths(
        root=knowledge_base_root,
        raw=knowledge_base_root / "raw",
        errata=knowledge_base_root / "errata",
    )
