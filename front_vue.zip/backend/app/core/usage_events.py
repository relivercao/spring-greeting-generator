"""Deliver direct CLI usage from worker threads to the application's event loop."""

import asyncio
from contextvars import copy_context

from loguru import logger

_loop = None
_callback = None
_pending: set[asyncio.Task] = set()


def configure_cli_usage(callback):
    global _loop, _callback
    _loop = asyncio.get_running_loop()
    _callback = callback


def emit_cli_usage(model, result, *, task_id=None, provider=None, duration_ms=0):
    """Queue one aggregate invocation, excluding prompts, tool output, and errors."""
    if _loop is None or _loop.is_closed() or _callback is None:
        return
    context = copy_context()
    usage = dict(result.get("token_usage") or {})
    usage.update(
        usage_source="reported" if any(usage.values()) else "unavailable",
        status="completed" if result.get("exit_code") == 0 else "failed",
        latency_ms=duration_ms,
    )

    async def deliver():
        from app.core.task_context import set_current_task_id, reset_current_task_id
        from app.core.config import get_settings
        token = set_current_task_id(task_id) if task_id else None
        try:
            await _callback(provider or get_settings().DEFAULT_PROVIDER or "claude_cli", model, usage)
        except Exception:
            logger.exception("Direct CLI usage delivery failed")
        finally:
            if token is not None:
                reset_current_task_id(token)

    def schedule():
        task = asyncio.create_task(deliver(), context=context)
        _pending.add(task)
        task.add_done_callback(_pending.discard)

    try:
        _loop.call_soon_threadsafe(schedule)
    except RuntimeError:
        logger.warning("Usage event loop closed before CLI usage delivery")


async def drain_cli_usage():
    global _callback, _loop
    # Flush callbacks queued by worker threads before taking the snapshot.
    await asyncio.sleep(0)
    if _pending:
        await asyncio.gather(*list(_pending), return_exceptions=True)
    _callback = None
    _loop = None
