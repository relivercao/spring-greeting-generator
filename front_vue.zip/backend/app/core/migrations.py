"""Small, explicit schema migrations for the application's SQLite database.

``Base.metadata.create_all()`` creates missing tables, but it does not alter
tables that already exist.  Keep the migrations here ordered and idempotent so
an existing installation can be upgraded during normal application startup.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from sqlalchemy import Connection, inspect


SCHEMA_MIGRATIONS_TABLE = "schema_migrations"


@dataclass(frozen=True)
class SchemaMigration:
    """One ordered application schema migration."""

    version: int
    name: str
    apply: Callable[[Connection], bool]


def _add_task_batch_links(connection: Connection) -> bool:
    """Add the batch-child guard columns to a pre-batch ``tasks`` table."""

    inspector = inspect(connection)
    if not inspector.has_table("tasks"):
        # Do not record the migration until its target exists.  Normal startup
        # creates all mapped tables before running migrations.
        return False

    column_names = {column["name"] for column in inspector.get_columns("tasks")}
    if "batch_task_id" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE tasks ADD COLUMN batch_task_id VARCHAR(36) "
            "REFERENCES batch_tasks(id) ON DELETE SET NULL"
        )
    if "batch_item_id" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE tasks ADD COLUMN batch_item_id VARCHAR(36) "
            "REFERENCES batch_items(id) ON DELETE SET NULL"
        )

    connection.exec_driver_sql(
        "CREATE INDEX IF NOT EXISTS ix_tasks_batch_task_id "
        "ON tasks (batch_task_id)"
    )
    # SQLite permits multiple NULL values in a unique index.  The predicate
    # makes the intended one-child-per-item rule explicit and keeps ordinary
    # (non-batch) tasks unrestricted.
    inspector = inspect(connection)
    unique_constraints = inspector.get_unique_constraints("tasks")
    indexes = inspector.get_indexes("tasks")
    has_batch_item_guard = any(
        constraint["column_names"] == ["batch_item_id"]
        for constraint in unique_constraints
    ) or any(
        index["unique"] and index["column_names"] == ["batch_item_id"]
        for index in indexes
    )
    if not has_batch_item_guard:
        existing_guard_index = next(
            (
                index
                for index in indexes
                if index["name"] == "ux_tasks_batch_item_id"
            ),
            None,
        )
        if existing_guard_index is not None:
            raise RuntimeError(
                "Index ux_tasks_batch_item_id exists but is not a unique "
                "single-column batch_item_id guard"
            )
        connection.exec_driver_sql(
            "CREATE UNIQUE INDEX ux_tasks_batch_item_id "
            "ON tasks (batch_item_id) WHERE batch_item_id IS NOT NULL"
        )
    return True


def _add_user_billing_columns(connection: Connection) -> bool:
    """Add balance/role columns to a pre-billing ``users`` table."""

    inspector = inspect(connection)
    if not inspector.has_table("users"):
        # Do not record the migration until its target exists.  Normal
        # startup creates all mapped tables before running migrations.
        return False

    column_names = {column["name"] for column in inspector.get_columns("users")}
    if "balance" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN balance FLOAT NOT NULL DEFAULT 0.0"
        )
    if "total_recharged" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN total_recharged FLOAT NOT NULL DEFAULT 0.0"
        )
    if "is_admin" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN is_admin BOOLEAN NOT NULL DEFAULT 0"
        )
    if "email_verified" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN email_verified BOOLEAN NOT NULL DEFAULT 0"
        )
    if "invited_by_user_id" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN invited_by_user_id VARCHAR(36)"
        )

    connection.exec_driver_sql(
        "CREATE INDEX IF NOT EXISTS ix_users_is_admin ON users (is_admin)"
    )
    return True


def _add_llm_usage_user_id(connection: Connection) -> bool:
    """Add the nullable indexed ``user_id`` column to ``llm_usage_logs``."""

    inspector = inspect(connection)
    if not inspector.has_table("llm_usage_logs"):
        return False

    column_names = {
        column["name"] for column in inspector.get_columns("llm_usage_logs")
    }
    if "user_id" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE llm_usage_logs ADD COLUMN user_id VARCHAR(36)"
        )

    connection.exec_driver_sql(
        "CREATE INDEX IF NOT EXISTS ix_llm_usage_logs_user_id "
        "ON llm_usage_logs (user_id)"
    )
    return True


def _add_user_level_columns(connection: Connection) -> bool:
    """Add membership level columns to ``users`` and backfill tiers.

    Existing users are placed on the tier their cumulative recharge
    already earns, using the default thresholds.  The thresholds below
    mirror ``DEFAULT_LEVELS`` in payment_config_service; admins can
    retune them later through the admin config API.
    """

    inspector = inspect(connection)
    if not inspector.has_table("users"):
        return False

    column_names = {column["name"] for column in inspector.get_columns("users")}
    if "level" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN level VARCHAR(32) NOT NULL DEFAULT 'default'"
        )
    if "level_manual" not in column_names:
        connection.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN level_manual BOOLEAN NOT NULL DEFAULT 0"
        )

    # Backfill auto-mode users from their cumulative recharge totals
    connection.exec_driver_sql(
        """
        UPDATE users SET level = CASE
            WHEN total_recharged >= 2000 THEN 'platinum'
            WHEN total_recharged >= 500 THEN 'gold'
            WHEN total_recharged >= 100 THEN 'silver'
            ELSE 'default'
        END
        WHERE level_manual = 0
        """
    )
    return True


def _add_usage_pricing_snapshots(connection: Connection) -> bool:
    """Preserve historical prices and distinguish unknown legacy usage."""
    inspector = inspect(connection)
    if not inspector.has_table("llm_usage_logs"):
        return False
    columns = {column["name"] for column in inspector.get_columns("llm_usage_logs")}
    for name, definition in {
        "charged_cny": "FLOAT NOT NULL DEFAULT 0.0",
        "cache_read_tokens": "INTEGER NOT NULL DEFAULT 0",
        "cache_write_tokens": "INTEGER NOT NULL DEFAULT 0",
        "usage_source": "VARCHAR(20) NOT NULL DEFAULT 'legacy'",
        "pricing_source": "VARCHAR(30) NOT NULL DEFAULT 'legacy'",
        "pricing_snapshot": "TEXT",
    }.items():
        if name not in columns:
            connection.exec_driver_sql(f"ALTER TABLE llm_usage_logs ADD COLUMN {name} {definition}")
    connection.exec_driver_sql(
        "CREATE INDEX IF NOT EXISTS ix_llm_usage_logs_user_created "
        "ON llm_usage_logs (user_id, created_at)"
    )
    return True


MIGRATIONS = (
    SchemaMigration(
        version=1,
        name="add_task_batch_links",
        apply=_add_task_batch_links,
    ),
    SchemaMigration(
        version=2,
        name="add_user_billing_columns",
        apply=_add_user_billing_columns,
    ),
    SchemaMigration(
        version=3,
        name="add_llm_usage_user_id",
        apply=_add_llm_usage_user_id,
    ),
    SchemaMigration(
        version=4,
        name="add_user_level_columns",
        apply=_add_user_level_columns,
    ),
    SchemaMigration(version=5, name="add_usage_pricing_snapshots", apply=_add_usage_pricing_snapshots),
)


def _ensure_migration_table(connection: Connection) -> None:
    connection.exec_driver_sql(
        f"""
        CREATE TABLE IF NOT EXISTS {SCHEMA_MIGRATIONS_TABLE} (
            version INTEGER PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )


def run_schema_migrations(connection: Connection) -> None:
    """Apply all pending SQLite schema migrations in version order."""

    if connection.dialect.name != "sqlite":
        raise RuntimeError(
            "Application schema migrations currently support SQLite only"
        )

    _ensure_migration_table(connection)
    applied_versions = {
        row[0]
        for row in connection.exec_driver_sql(
            f"SELECT version FROM {SCHEMA_MIGRATIONS_TABLE}"
        )
    }

    for migration in MIGRATIONS:
        if migration.version in applied_versions:
            continue
        if not migration.apply(connection):
            break
        connection.exec_driver_sql(
            f"INSERT INTO {SCHEMA_MIGRATIONS_TABLE} (version, name) VALUES (?, ?)",
            (migration.version, migration.name),
        )


__all__ = [
    "MIGRATIONS",
    "SCHEMA_MIGRATIONS_TABLE",
    "run_schema_migrations",
]
