"""Lexical masking for deterministic C/C++ source checks.

This is not a compiler or preprocessor. Masking preserves offsets and line
numbers so regex-based checks cannot mistake comments or literals for code.
"""

from __future__ import annotations

import re


_NON_CODE = re.compile(
    r'(?P<raw>(?:u8|u|U|L)?R"(?P<delimiter>[^\s()\\]{0,16})\(.*?\)(?P=delimiter)")'
    r'|(?P<literal>"(?:\\[\s\S]|[^"\\\r\n])*"|(?<!\w)(?:u8|u|U|L)?\'(?:\\[\s\S]|[^\'\\\r\n])*\')'
    r'|(?P<comment>//(?:\\\r?\n|[^\n])*|/\*[\s\S]*?(?:\*/|\Z))',
    re.DOTALL,
)


def mask_c_non_code(content: str, *, keep_literals: bool = False) -> str:
    """Replace comments and optionally literals with spaces, retaining newlines."""
    def mask(match: re.Match[str]) -> str:
        if keep_literals and match.group("comment") is None:
            return match.group(0)
        return re.sub(r"[^\r\n]", " ", match.group(0))

    return _NON_CODE.sub(mask, content)
