"""
@file database.py
@author caoshwen
@brief Async SQLAlchemy database engine and session management.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase
from typing import AsyncGenerator

from app.core.config import get_settings
from app.core.migrations import run_schema_migrations

settings = get_settings()

# Create async engine.  The SQLite busy timeout keeps concurrent writers
# (payment webhook fulfillment, billing deductions) waiting briefly for
# the table lock instead of failing immediately.
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.is_debug,
    future=True,
    connect_args={"timeout": 30},
)

# Async session factory
async_session_factory = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    """SQLAlchemy ORM base class"""
    pass


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency injection: get database session.

    Usage:
        @router.get("/users")
        async def get_users(db: AsyncSession = Depends(get_db)):
            ...
    """
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db() -> None:
    """Create missing tables and apply ordered SQLite schema migrations."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(run_schema_migrations)


async def close_db() -> None:
    """Close database connection"""
    await engine.dispose()
