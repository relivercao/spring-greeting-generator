"""
@file main.py
@author caoshwen
@brief Macode - FastAPI application entry point.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from contextlib import asynccontextmanager
from pathlib import Path
import json

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select, update

from app.core.config import get_settings, get_resolved_cli_path, normalize_api_base, resolve_claude_cli_model, resolve_bedrock_default_model
from app.core.database import init_db, close_db, async_session_factory
from app.core.driver_storage import configure_driver_temp_root
from app.core.middleware import (
    BillingContextMiddleware,
    GlobalExceptionMiddleware,
    RateLimitMiddleware,
    RequestLoggingMiddleware,
)
from app.api.v1.router import api_router
from app.infrastructure.observability.logger import LoggerService
from app.infrastructure.observability.metrics import MetricsCollector
from app.infrastructure.observability.health import HealthCheckAggregator
from app.infrastructure.observability.tracing import TracingService
from app.infrastructure.cache import RedisCacheClient, InMemoryCacheClient, SessionManager
from app.llm.bridge import LLMBridge
from app.llm.providers import (
    BedrockProvider,
    ClaudeCLIProvider,
)
from app.mcp.client import MCPClient
from app.mcp.servers import (
    JiraMCPServer,
    BitbucketMCPServer,
    STM32MCPServer,
    QBSMCPServer,
    ExternalSearchMCPServer,
    LocalGitMCPServer,
)
from app.skills import SkillLoader, SkillRegistry
from app.core.router_manager import RouterManager
from app.core.local_service_manager import LocalServiceManager
from app.models.task import Task
from app.models.driver_agent import DriverAgentTask, DriverTaskStatus
from app.services.knowledge_repository import KnowledgeRepository
from app.services.batch_runtime import (
    _cancel_batch_unittest_child,
    _cleanup_orphan_batch_snapshots,
    _resume_batch_unittest_child,
    _run_batch_unittest_child,
    _start_batch_dispatcher,
)
from app.services.billing_service import get_billing_service
from app.services.payment.order_expiry_service import (
    start_order_expiry_task,
    stop_order_expiry_task,
)
from app.services.payment.payment_config_service import seed_app_settings

# Ensure all ORM models are imported so init_db can create all tables
import app.models  # noqa: F401


async def _cleanup_stale_unittest_tasks(log) -> None:
    """Mark stale running unittest tasks as cancelled during backend startup."""
    try:
        from app.api.v1.endpoints.unittest import (
            FRONTEND_NODES,
            _WORKFLOW_STATE_KEY,
            _load_persisted_result,
            _mark_workflow_terminal,
            _running_tasks,
            _task_cancelled,
            _task_progress,
            _workflow_nodes_as_list,
            _workflow_snapshot_from_task,
        )
        from app.utils.claude_cli_monitor import (
            cleanup_task_cli,
            terminate_persisted_cli_processes,
        )

        async with async_session_factory() as session:
            result = await session.execute(
                select(Task).where(Task.agent_type == "unittest", Task.status == "running")
            )
            stale_tasks = list(result.scalars().all())
            stale_task_ids = [task.id for task in stale_tasks]
            restart_message = "Task cancelled because the backend was restarted"
            for task in stale_tasks:
                stored_result = _load_persisted_result(task)
                snapshot = _workflow_snapshot_from_task(task, stored_result)
                node_map = {
                    item["node_name"]: item["status"]
                    for item in snapshot.get("nodes") or []
                    if isinstance(item, dict) and item.get("node_name")
                }
                terminal_entry = {
                    "current_stage": snapshot.get("current_stage") or "",
                    "nodes": {
                        node_name: node_map.get(node_name, "pending")
                        for node_name in FRONTEND_NODES
                    },
                    "details": snapshot.get("details") or {},
                    "cli_activity": snapshot.get("cli_activity") or {},
                    "cli_activity_sequence": snapshot.get("cli_activity_sequence", 0),
                    "token_usage": snapshot.get("token_usage") or {},
                    "started_at": snapshot.get("started_at"),
                    "last_activity_at": snapshot.get("last_activity_at"),
                }
                _mark_workflow_terminal(terminal_entry, "cancelled")
                snapshot["nodes"] = _workflow_nodes_as_list(terminal_entry["nodes"])
                stored_result[_WORKFLOW_STATE_KEY] = snapshot
                task.status = "cancelled"
                task.message = restart_message
                task.error_message = restart_message
                task.result_data = json.dumps(stored_result, ensure_ascii=False)
            await session.commit()

        for task_id in stale_task_ids:
            _task_cancelled[task_id] = True
            task_info = _task_progress.get(task_id)
            if task_info:
                task_info["status"] = "cancelled"
                task_info["message"] = restart_message
                task_info["error"] = restart_message
            running_task = _running_tasks.pop(task_id, None)
            if running_task and not running_task.done():
                running_task.cancel()
            cleanup_task_cli(task_id)

        terminated = terminate_persisted_cli_processes(stale_task_ids)

        if stale_task_ids:
            log.warning(
                "Cancelled stale running unittest tasks during startup",
                count=len(stale_task_ids),
                terminated_cli_processes=terminated,
            )
    except Exception as e:
        log.warning("Failed to clean up stale unittest tasks during startup", error=str(e))


async def _cleanup_stale_image_tasks(log) -> None:
    """Mark image tasks interrupted by a backend restart as cancelled."""
    try:
        async with async_session_factory() as session:
            result = await session.execute(
                update(Task)
                .where(
                    Task.agent_type == "image_generation",
                    Task.status == "running",
                )
                .values(
                    status="cancelled",
                    progress=0,
                    message="Task cancelled because the backend was restarted",
                    error_message="Task cancelled because the backend was restarted",
                )
                .returning(Task.id)
            )
            stale_task_ids = list(result.scalars().all())
            await session.commit()
        if stale_task_ids:
            from app.utils.claude_cli_monitor import terminate_persisted_cli_processes
            terminated = terminate_persisted_cli_processes(stale_task_ids)
            log.warning(
                "Cancelled stale image generation tasks during startup",
                count=len(stale_task_ids),
                terminated_cli_processes=terminated,
            )
    except Exception as e:
        log.warning("Failed to clean up stale image generation tasks", error=str(e))


async def _cleanup_stale_firmware_agent_tasks(log) -> None:
    """Cancel durable firmware Agent tasks interrupted by a backend restart."""
    try:
        async with async_session_factory() as session:
            result = await session.execute(
                update(Task)
                .where(
                    Task.agent_type.in_(("driver", "review", "build", "bugfix", "bugfix_batch", "debug", "cad")),
                    Task.status == "running",
                )
                .values(
                    status="cancelled",
                    progress=0,
                    message="Task cancelled because the backend was restarted",
                    error_message="Task cancelled because the backend was restarted",
                )
                .returning(Task.id)
            )
            stale_task_ids = list(result.scalars().all())
            await session.commit()
        if stale_task_ids:
            from app.utils.claude_cli_monitor import terminate_persisted_cli_processes
            terminated = terminate_persisted_cli_processes(stale_task_ids)
            log.warning(
                "Cancelled stale firmware Agent tasks during startup",
                count=len(stale_task_ids),
                terminated_cli_processes=terminated,
            )
    except Exception as e:
        log.warning("Failed to clean up stale firmware Agent tasks", error=str(e))


async def _cleanup_stale_driver_tasks(log) -> None:
    """Mark persisted Driver tasks interrupted by a backend restart as cancelled."""
    try:
        active_statuses = {
            DriverTaskStatus.CREATED.value,
            DriverTaskStatus.RUNNING.value,
            DriverTaskStatus.WAITING_USER.value,
        }
        async with async_session_factory() as session:
            result = await session.execute(
                select(DriverAgentTask).where(DriverAgentTask.status.in_(active_statuses))
            )
            stale_tasks = list(result.scalars().all())
            for task in stale_tasks:
                try:
                    state_data = json.loads(task.state_data) if task.state_data else {}
                except (TypeError, json.JSONDecodeError):
                    state_data = {}
                if not isinstance(state_data, dict):
                    state_data = {}
                state_data.update({
                    "progress": 0,
                    "message": "Task cancelled because the backend was restarted",
                    "backend_stage": "cancelled",
                    "stage_confirmed": True,
                    "stage_source": "backend_startup_recovery",
                })
                task.status = DriverTaskStatus.CANCELLED.value
                task.current_step = "cancelled"
                task.last_error = "Task cancelled because the backend was restarted"
                task.state_data = json.dumps(state_data, ensure_ascii=False)
            await session.commit()
        if stale_tasks:
            log.warning("Cancelled stale Driver tasks during startup", count=len(stale_tasks))
    except Exception as e:
        log.warning("Failed to clean up stale Driver tasks", error=str(e))


async def _cleanup_stale_generated_agent_tasks(log) -> None:
    """Mark generated-Agent snapshots interrupted by a backend restart."""
    try:
        from app.services.generated_agent_repository import GeneratedAgentRepository
        repository = GeneratedAgentRepository(KnowledgeRepository())
        import asyncio
        count = await asyncio.to_thread(
            repository.mark_running_task_snapshots_interrupted,
            "Task cancelled because the backend was restarted",
        )
        if count:
            log.warning("Cancelled stale generated Agent tasks during startup", count=count)
    except Exception as e:
        log.warning("Failed to clean up stale generated Agent tasks", error=str(e))


settings = get_settings()

# === SECURITY: Validate SECRET_KEY before startup ===
if settings.SECRET_KEY == "fw-dev-agent-secret-key-change-in-production":
    raise RuntimeError(
        "SECURITY ERROR: SECRET_KEY is still using the default value!\n"
        "Please set a secure SECRET_KEY in your .env file before running in production.\n"
        "Generate a secure key with: python -c 'import secrets; print(secrets.token_urlsafe(32))'"
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifecycle management"""
    # --- Startup ---
    configure_driver_temp_root()
    # Ensure data directories exist
    Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
    Path(settings.OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

    # Logging
    logger_service = LoggerService(
        log_dir=settings.LOG_DIR,
        level=settings.LOG_LEVEL,
        json_format=settings.LOG_JSON_FORMAT,
    )
    logger_service.setup()

    log = LoggerService.get_logger("system")
    log.info("Macode starting up", version=settings.APP_VERSION)

    # Database
    await init_db()
    log.info("Database initialized")

    # Seed payment/registration runtime settings (idempotent)
    try:
        async with async_session_factory() as session:
            seeded_keys = await seed_app_settings(session)
        if seeded_keys:
            log.info("Seeded app settings", keys=seeded_keys)
    except Exception as exc:
        log.warning("Failed to seed app settings", error=str(exc))

    from app.api.v1.endpoints.unittest import _workspace_lease_manager

    _workspace_lease_manager.configure(
        async_session_factory,
        pending_ttl_seconds=max(30.0, float(settings.BATCH_DISPATCHER_LEASE_SECONDS) * 2.0),
    )
    await _cleanup_orphan_batch_snapshots(log)
    await _cleanup_stale_driver_tasks(log)
    orphan_workspace_leases = await _workspace_lease_manager.cleanup_orphans()
    if orphan_workspace_leases:
        log.warning("Removed orphan Unit-Test workspace leases during startup", count=orphan_workspace_leases)
    # A previous backend instance may have exited before its CLI workers
    # unwound.  Reconcile the durable PID registry before recovering task
    # rows so no provider request survives a restart.
    try:
        from app.utils.claude_cli_monitor import terminate_all_persisted_cli_processes
        terminated = terminate_all_persisted_cli_processes()
        if terminated:
            log.warning("Terminated persisted Claude CLI processes during startup", count=terminated)
    except Exception as exc:
        log.warning("Failed to reconcile persisted Claude CLI processes", error=str(exc))
    await _cleanup_stale_unittest_tasks(log)
    await _cleanup_stale_image_tasks(log)
    await _cleanup_stale_firmware_agent_tasks(log)
    await _cleanup_stale_generated_agent_tasks(log)

    # Redis cache
    try:
        cache_client = RedisCacheClient(
            url=settings.REDIS_URL,
            max_connections=settings.REDIS_MAX_CONNECTIONS,
        )
        await cache_client.initialize()
        log.info("Redis connected", url=settings.REDIS_URL)
    except Exception as e:
        log.warning("Redis unavailable, falling back to InMemoryCacheClient", error=str(e))
        cache_client = InMemoryCacheClient()
        await cache_client.initialize()

    session_manager = SessionManager(cache_client)
    # Attach to app.state for API endpoint access
    app.state.cache_client = cache_client
    app.state.session_manager = session_manager

    # Observability
    app.state.metrics = MetricsCollector.get_instance()
    app.state.tracing = TracingService()

    health_aggregator = HealthCheckAggregator()
    # Register Redis health check (only when Redis is available)
    if isinstance(cache_client, RedisCacheClient):
        health_aggregator.register("redis", cache_client.health_check)
    app.state.health = health_aggregator
    log.info("Observability services initialized (metrics, tracing, health)")

    # Claude Router (CLI accesses Turing API via Router)
    router_manager = RouterManager(settings)
    await router_manager.start()
    app.state.router_manager = router_manager
    health_aggregator.register("claude_router", router_manager.health_check)

    # Local File Selector Service (local file selection service, get full path)
    local_service_manager = LocalServiceManager()
    await local_service_manager.start()
    app.state.local_service_manager = local_service_manager

    # LLMBridge
    llm_bridge = LLMBridge(rate_limit_per_minute=settings.LLM_RATE_LIMIT_PER_MINUTE)

    # Register LLM providers by priority, only register if config is available
    if settings.AWS_PROFILE or (settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY):
        llm_bridge.register_provider(BedrockProvider(
            region=settings.AWS_REGION,
            profile_name=settings.AWS_PROFILE,
            access_key_id=settings.AWS_ACCESS_KEY_ID,
            secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            default_model=resolve_bedrock_default_model(settings),
        ))

    # Always register Claude CLI as a fallback provider
    cli_model = resolve_claude_cli_model(settings)
    log.info(f"Claude CLI: DEFAULT_PROVIDER={settings.DEFAULT_PROVIDER}, resolved model={cli_model}")
    llm_bridge.register_provider(ClaudeCLIProvider(
        cli_path=get_resolved_cli_path(),
        default_model=cli_model,
    ))

    await llm_bridge.initialize_all()
    app.state.llm_bridge = llm_bridge
    log.info("LLMBridge initialized", providers=len(llm_bridge.list_providers()))

    # MCPClient
    mcp_client = MCPClient()

    if settings.JIRA_BASE_URL and settings.JIRA_EMAIL and settings.JIRA_API_TOKEN:
        mcp_client.register(JiraMCPServer(
            base_url=settings.JIRA_BASE_URL,
            email=settings.JIRA_EMAIL,
            api_token=settings.JIRA_API_TOKEN,
        ))

    if settings.BITBUCKET_BASE_URL and settings.BITBUCKET_USERNAME and settings.BITBUCKET_APP_PASSWORD:
        mcp_client.register(BitbucketMCPServer(
            base_url=settings.BITBUCKET_BASE_URL,
            username=settings.BITBUCKET_USERNAME,
            app_password=settings.BITBUCKET_APP_PASSWORD,
        ))

    # STM32 and QBS are local toolchains, always register
    mcp_client.register(STM32MCPServer())
    mcp_client.register(QBSMCPServer(
        qbs_path=settings.QBS_PATH,
        timeout=settings.QBS_TIMEOUT,
    ))
    mcp_client.register(ExternalSearchMCPServer())
    mcp_client.register(LocalGitMCPServer())

    await mcp_client.initialize_all()
    app.state.mcp_client = mcp_client
    log.info("MCPClient initialized", tools=len(mcp_client.list_tools()))

    # Skill system
    skill_loader = SkillLoader()
    skill_entries = skill_loader.load_all()
    skill_registry = SkillRegistry(mcp_client=mcp_client)
    skill_registry.register(skill_entries)
    app.state.skill_registry = skill_registry
    log.info("SkillRegistry initialized", skills=len(skill_entries))

    await _start_batch_dispatcher(app, log)

    # Balance billing: forward LLM usage events to the billing service
    llm_bridge.register_usage_hook(get_billing_service().handle_usage_event)
    from app.core.usage_events import configure_cli_usage
    configure_cli_usage(get_billing_service().handle_usage_event)

    from app.orchestration.event_execution import EventExecutor
    from app.orchestration.feishu_events import FeishuEventResponder
    from app.services.event_dispatch import EventDispatcher
    from app.services.event_worker import EventWorker
    from app.services.feishu_messages import FeishuMessageHandler
    from app.services.feishu_listener import FeishuListenerManager
    app.state.event_worker = EventWorker(async_session_factory, EventExecutor(app, async_session_factory))
    app.state.event_dispatcher = EventDispatcher(async_session_factory, app.state.event_worker)
    await app.state.event_worker.start()
    app.state.feishu_listener_manager = FeishuListenerManager(
        FeishuMessageHandler(async_session_factory, FeishuEventResponder(app, async_session_factory, app.state.event_dispatcher)),
    )
    await app.state.feishu_listener_manager.restore(async_session_factory)

    # Payment: background sweep that expires stale pending orders
    start_order_expiry_task(app)

    log.info("All services initialized")

    yield

    # --- Shutdown ---
    log.info("Macode shutting down")
    if hasattr(app.state, "feishu_listener_manager"):
        await app.state.feishu_listener_manager.shutdown()
    if hasattr(app.state, "event_worker"):
        await app.state.event_worker.shutdown()
    if hasattr(app.state, "batch_dispatcher"):
        await app.state.batch_dispatcher.stop()
        log.info("Batch Unit-Test dispatcher stopped")

    # Stop the payment order expiry sweep before closing the database
    await stop_order_expiry_task(app)
    log.info("Order expiry task stopped")
    # Stop every task-scoped CLI process before closing services.  This is
    # intentionally independent of task timeouts: shutdown is an explicit
    # lifecycle boundary and must never leave provider calls orphaned.
    try:
        from app.utils.claude_cli_monitor import terminate_all_cli_processes
        terminated = terminate_all_cli_processes()
        if terminated:
            log.warning("Terminated active Claude CLI processes during shutdown", count=terminated)
    except Exception as exc:
        log.warning("Failed to terminate active Claude CLI processes during shutdown", error=str(exc))
    from app.core.usage_events import drain_cli_usage
    await drain_cli_usage()
    if hasattr(app.state, "llm_bridge"):
        await app.state.llm_bridge.shutdown_all()
        log.info("LLMBridge closed")
    await close_db()
    log.info("Database connections closed")

    # Close Redis
    if hasattr(app.state, "cache_client"):
        await app.state.cache_client.close()
        log.info("Cache client closed")

    # Close MCPClient
    if hasattr(app.state, "mcp_client"):
        await app.state.mcp_client.shutdown_all()
        log.info("MCPClient closed")
    retired_mcp_clients = getattr(app.state, "retired_mcp_clients", [])
    for retired_client in retired_mcp_clients:
        await retired_client.shutdown_all()
    if retired_mcp_clients:
        log.info("Retired MCP clients closed", count=len(retired_mcp_clients))

    from app.services.driver_source_service import shutdown_driver_source_parse_executor

    shutdown_driver_source_parse_executor()

    # Close Router
    if hasattr(app.state, "router_manager"):
        await app.state.router_manager.stop()
        log.info("Claude Router closed")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Macode - Unified API Gateway",
    lifespan=lifespan,
)

# === Middleware (registration order: last registered executes first) ===
# 1. CORS (outermost)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=("*" not in settings.CORS_ORIGINS),
    allow_methods=["*"],
    allow_headers=["*"],
)
# 2. Global exception handler
app.add_middleware(GlobalExceptionMiddleware)
# 3. Rate limiting
app.add_middleware(
    RateLimitMiddleware,
    max_requests=settings.LLM_RATE_LIMIT_PER_MINUTE,
    window_seconds=60,
)
# 4. Request logging + trace_id (innermost, executes first)
app.add_middleware(RequestLoggingMiddleware)

# Resolve the billing user from the bearer token before anything else runs;
# failures are swallowed (endpoints own authentication decisions).
app.add_middleware(BillingContextMiddleware)

# Register API routes
app.include_router(api_router, prefix=settings.API_V1_PREFIX)

# Serve the MkDocs build generated from the canonical knowledge repository.
knowledge_site_dir = KnowledgeRepository(initialize=False).site_dir
app.mount(
    "/knowledge-site",
    StaticFiles(directory=str(knowledge_site_dir), html=True, check_dir=False),
    name="knowledge-site",
)


# === Root endpoint ===

@app.get("/")
async def root():
    """Service root endpoint"""
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "description": "AI Agent Unified API Gateway",
    }


@app.get("/health")
async def health_check(request: Request):
    """Health check endpoint - aggregate all component statuses"""
    aggregator: HealthCheckAggregator = request.app.state.health
    result = await aggregator.check_all()
    result["version"] = settings.APP_VERSION
    status_code = 200 if result["status"] == "healthy" else 503
    return result


@app.get("/metrics")
async def metrics_endpoint():
    """Metrics endpoint - JSON summary (phase 1)"""
    metrics = MetricsCollector.get_instance()
    return metrics.get_summary()
