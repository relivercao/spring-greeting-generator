"""
@file debug.py
@author caoshwen
@brief Debug agent request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field


class DebugRequest(BaseModel):
    crash_description: str = Field(..., description="Crash description")
    log_files: list[str] = Field(..., description="List of log files")
    project_root: str = Field(..., description="Project root directory")
