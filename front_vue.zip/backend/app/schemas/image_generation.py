"""Schemas for image generation settings and task responses."""

from typing import Literal, Optional
from urllib.parse import urlparse

from pydantic import BaseModel, Field, field_validator


class ImageGenerationSettingsUpdate(BaseModel):
    """Editable image provider settings."""

    provider: Literal["macode", "custom"] = "macode"
    api_base: str = ""
    api_key: Optional[str] = None
    model: str = Field(min_length=1, max_length=200)
    mode: Literal["images", "responses"] = "images"
    timeout_seconds: int = Field(default=600, ge=30, le=1800)
    retry_attempts: int = Field(default=2, ge=0, le=5)
    stream_images: bool = False
    partial_images: int = Field(default=1, ge=0, le=3)
    allow_prompt_rewrite: bool = True

    @field_validator("api_base")
    @classmethod
    def validate_api_base(cls, value: str) -> str:
        normalized = value.strip().rstrip("/")
        if not normalized:
            return ""
        parsed = urlparse(normalized)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("API base URL must be an absolute HTTP or HTTPS URL")
        if parsed.username or parsed.password:
            raise ValueError("API base URL must not contain credentials")
        return normalized

    @field_validator("model")
    @classmethod
    def normalize_model(cls, value: str) -> str:
        return value.strip()


class ImageGenerationSettingsResponse(BaseModel):
    """Safe image provider settings returned to the frontend."""

    provider: Literal["macode", "custom"]
    api_base: str
    api_key: str
    model: str
    mode: Literal["images", "responses"]
    timeout_seconds: int
    retry_attempts: int
    stream_images: bool
    partial_images: int
    allow_prompt_rewrite: bool
    configured: bool
    using_turing_fallback: bool
