"""User-facing payment schemas (recharge checkout, orders, ledger).

Field names here are the contract shared with the payment endpoints,
the payment services, and the Vue frontend: renaming anything breaks
both sides simultaneously.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class PlanOut(BaseModel):
    """One preset recharge plan as shown on the recharge page."""

    id: str
    name: str
    description: Optional[str] = None
    price: float
    original_price: Optional[float] = None
    credited_amount: float
    validity_days: int = 0
    features: List[str] = Field(default_factory=list)
    for_sale: bool = True
    sort_order: int = 0

    model_config = {"from_attributes": True}

    @field_validator("features", mode="before")
    @classmethod
    def _parse_features(cls, value):
        """Accept the ORM JSON-string column and tolerate junk."""
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
            except ValueError:
                return []
            return parsed if isinstance(parsed, list) else []
        if value is None:
            return []
        return value


class CheckoutLimits(BaseModel):
    """Recharge limits in effect for the current user."""

    min_recharge_amount: float = 1.0
    max_recharge_amount: float = 1000.0
    daily_remaining: float = 5000.0
    fee_rate: float = 0.0
    recharge_multiplier: float = 1.0


class LevelOut(BaseModel):
    """One membership tier definition (from payment.levels)."""

    key: str
    name: str
    threshold: float = 0.0
    discount_percent: float = 0.0


class UserLevelProgressOut(BaseModel):
    """The current user's tier plus the path to the next one."""

    current_level: LevelOut
    next_level: Optional[LevelOut] = None
    total_recharged: float = 0.0
    remaining_to_next: Optional[float] = None


class CheckoutInfoOut(BaseModel):
    """Everything the recharge page needs in one call."""

    plans: List[PlanOut] = Field(default_factory=list)
    limits: CheckoutLimits = Field(default_factory=CheckoutLimits)
    payment_methods: List[str] = Field(default_factory=list)
    levels: List[LevelOut] = Field(default_factory=list)
    level_progress: Optional[UserLevelProgressOut] = None


class OrderCreateRequest(BaseModel):
    """Create a recharge order from a plan and/or a custom amount."""

    plan_id: Optional[str] = Field(None, description="Selected preset plan id")
    amount: Optional[float] = Field(
        None, gt=0, description="Custom amount in CNY (plan orders may omit it)"
    )
    payment_type: str = Field(
        "alipay", description="Gateway channel, e.g. alipay or wxpay"
    )


class OrderOut(BaseModel):
    """One payment order (creation response, list row, poll detail)."""

    id: str
    out_trade_no: str
    order_type: str
    plan_name: Optional[str] = None
    amount: float
    pay_amount: float
    credited_amount: float
    payment_type: str
    status: str
    pay_url: Optional[str] = None
    qr_code: Optional[str] = None
    # Gateway payment mode snapshot (popup / qrcode); not a DB column,
    # the payment service copies it from the provider config.
    pay_mode: Optional[str] = None
    expires_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    paid_at: Optional[datetime] = None
    refund_amount: float = 0.0

    model_config = {"from_attributes": True}


class OrderListOut(BaseModel):
    """Paged order history."""

    items: List[OrderOut] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20


class TransactionOut(BaseModel):
    """One balance ledger entry."""

    id: str
    type: str
    amount: float
    balance_after: float
    model: Optional[str] = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    description: Optional[str] = None
    reference_id: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class TransactionListOut(BaseModel):
    """Paged balance ledger."""

    items: List[TransactionOut] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20
