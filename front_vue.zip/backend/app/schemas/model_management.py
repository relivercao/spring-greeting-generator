"""Validated model catalog inputs; all rates are USD per million tokens."""

from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, model_validator

Rate = Annotated[float, Field(ge=0, le=1_000_000, allow_inf_nan=False)]
Name = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)]


class ModelEntryIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    provider: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=50, pattern=r"^[a-zA-Z0-9_-]+$")]
    model: Name
    display_name: Name
    enabled: bool = True
    context_window: int | None = Field(None, gt=0, le=100_000_000)
    max_output_tokens: int | None = Field(None, gt=0, le=100_000_000)
    input_usd_per_mtok: Rate | None = None
    output_usd_per_mtok: Rate | None = None
    cache_read_usd_per_mtok: Rate | None = None
    cache_write_usd_per_mtok: Rate | None = None
    source: Name = "manual"

    @model_validator(mode="after")
    def complete_prices(self):
        if (self.input_usd_per_mtok is None) != (self.output_usd_per_mtok is None):
            raise ValueError("Set both input and output prices, or leave both unset")
        if self.input_usd_per_mtok is None and any(
            rate is not None for rate in (self.cache_read_usd_per_mtok, self.cache_write_usd_per_mtok)
        ):
            raise ValueError("Cache prices require input and output prices")
        return self


class ModelImportIn(BaseModel):
    format: str = Field(pattern=r"^(catalog|litellm)$")
    provider: str = Field(default="macode", pattern=r"^[a-zA-Z0-9_-]{1,50}$")
    entries: list[dict[str, Any]] | dict[str, Any]
    overwrite: bool = False
