"""
@file auth.py
@author caoshwen
@brief Authentication request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime


class UserRegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=20, description="Username")
    email: EmailStr = Field(..., description="Email address")
    password: str = Field(..., min_length=8, description="Password")
    email_code: Optional[str] = Field(
        None, max_length=64, description="Email verification code"
    )
    invite_code: Optional[str] = Field(
        None, max_length=64, description="Invitation code"
    )
    promo_code: Optional[str] = Field(
        None, max_length=64, description="Promotional code"
    )


class UserLoginRequest(BaseModel):
    username: str = Field(..., description="Username")
    password: str = Field(..., description="Password")


class RefreshTokenRequest(BaseModel):
    refresh_token: str = Field(..., description="Refresh token")


class LogoutRequest(BaseModel):
    refresh_token: str = Field(..., description="Refresh token")


class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    created_at: Optional[datetime] = None
    balance: float = 0.0
    total_recharged: float = 0.0
    is_admin: bool = False
    email_verified: bool = False
    level: str = "default"

    model_config = {"from_attributes": True}


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    refresh_token: Optional[str] = None
    user: Optional[UserResponse] = None
