"""
@file session.py
@author caoshwen
@brief Session management request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field
from typing import Optional, Any
from datetime import datetime


class SessionCreateRequest(BaseModel):
    title: Optional[str] = Field(default="New Session", max_length=255, description="Session title")
    agent_type: str = Field(default="chat", description="Agent type: chat/unittest/driver/build/bugfix/debug/review")


class SessionResponse(BaseModel):
    id: str
    user_id: str
    title: str
    agent_type: str
    summary: Optional[str] = None
    message_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class SessionListResponse(BaseModel):
    sessions: list[SessionResponse]
    total: int
    limit: int
    offset: int


class MessageResponse(BaseModel):
    id: str
    session_id: str
    role: str
    content: str
    token_count: int = 0
    model: Optional[str] = None
    provider: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}
