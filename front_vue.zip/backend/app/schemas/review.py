"""
@file review.py
@author caoshwen
@brief Code review request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field
from typing import Literal, Optional


class ReviewRequest(BaseModel):
    source_files: list[str] = Field(default_factory=list, description="List of source files to review")
    project_root: Optional[str] = Field(default=None, description="Project root directory")
    review_type: str = Field(default="full", description="Review type: full/quick")
    standards: Optional[list[str]] = Field(default=None, description="List of review standards")
    focus: Optional[str] = Field(default=None, description="Optional review focus")
    repo: Optional[str] = Field(default=None, description="Remote repository identifier")
    pr_id: Optional[int] = Field(default=None, description="Pull request identifier")
    git_repository_path: Optional[str] = Field(default=None, description="Local Git repository path")
    git_base_ref: str = Field(default="HEAD~1", description="Git base ref or commit")
    git_target_ref: str = Field(default="WORKTREE", description="Git target ref or WORKTREE")
    git_include_untracked: bool = Field(default=True, description="Include untracked files in a working-tree diff")
    jira_project: Optional[str] = Field(default=None, description="Jira project key for bug retrieval")
    jira_jql: Optional[str] = Field(default=None, description="Optional Jira JQL query")
    jira_issue_keys: list[str] = Field(default_factory=list, description="Specific Jira issue keys")
    jira_status: Optional[str] = Field(default=None, description="Optional Jira bug status filter")
    jira_max_results: int = Field(default=20, ge=1, le=100, description="Maximum Jira bugs to retrieve")
    require_approval: bool = Field(default=False, description="Pause after analysis for human approval")
    approval_channels: list[Literal["email", "feishu"]] = Field(default_factory=list)
    approval_recipients: list[str] = Field(default_factory=list)


class ReviewApprovalRequest(BaseModel):
    """Approval decision for a pending Code Review task."""

    decision: Literal["approve", "reject"]
    comment: str = Field(default="", max_length=4000)
    token: str = Field(default="", max_length=200)
