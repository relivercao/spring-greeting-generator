"""Admin console schemas (payment config, providers, plans, users, codes).

``ProviderOut`` masks the merchant key (``pkey``) during validation so
no read path can leak the secret even if a service forgets to mask it.
The masking keeps a 4-character prefix (``abcd****``) so admins can
still tell credentials apart; the config service must treat any value
matching that shape as "unchanged" on update.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel, Field, field_validator

from app.schemas.payment import OrderOut
from app.schemas.payment import PlanOut as PaymentPlanOut


def mask_pkey(value: str) -> str:
    """Mask a merchant key, keeping a short prefix for identification."""
    if not value:
        return ""
    if len(value) <= 8:
        return "****"
    return value[:4] + "****"


class PaymentGeneralConfig(BaseModel):
    """General payment limits and timing (app_settings: payment.general)."""

    min_recharge_amount: float = 1.0
    max_recharge_amount: float = 1000.0
    daily_recharge_limit: float = 5000.0
    fee_rate: float = 0.0
    recharge_multiplier: float = 1.0
    order_expire_minutes: int = 30
    payment_grace_minutes: int = 10
    amount_tolerance: float = 0.01
    max_pending_orders: int = 5


class ModelPricing(BaseModel):
    """USD price per one million tokens (for one model or the default)."""

    input_usd_per_mtok: float = Field(3.0, ge=0, le=1_000_000, allow_inf_nan=False)
    output_usd_per_mtok: float = Field(15.0, ge=0, le=1_000_000, allow_inf_nan=False)


class PricingConfig(BaseModel):
    """LLM pricing table (app_settings: payment.pricing)."""

    default: ModelPricing = Field(default_factory=ModelPricing)
    models: Dict[str, ModelPricing] = Field(default_factory=dict)


class LevelConfig(BaseModel):
    """One membership tier (app_settings: payment.levels)."""

    key: str = Field(..., min_length=1, max_length=32, pattern=r"^[a-zA-Z0-9_-]+$")
    name: str = Field(..., min_length=1, max_length=50)
    threshold: float = Field(0.0, ge=0.0)
    discount_percent: float = Field(0.0, ge=0.0, le=100.0)


class LevelsConfig(BaseModel):
    """Membership tier list, sorted by ascending threshold."""

    levels: List[LevelConfig] = Field(default_factory=list)


class AdminConfigOut(BaseModel):
    """Full payment configuration as served to the admin console."""

    general: PaymentGeneralConfig = Field(default_factory=PaymentGeneralConfig)
    pricing: PricingConfig = Field(default_factory=PricingConfig)
    levels: LevelsConfig = Field(default_factory=LevelsConfig)


class AdminConfigIn(BaseModel):
    """Full payment configuration as submitted by the admin console."""

    general: PaymentGeneralConfig
    pricing: PricingConfig
    levels: Optional[LevelsConfig] = None


class ProviderIn(BaseModel):
    """Create/update a payment gateway credential set."""

    name: str = Field(..., min_length=1, max_length=100)
    provider_key: str = Field("easypay", max_length=50)
    is_enabled: bool = True
    sort_order: int = 0
    remark: Optional[str] = Field(None, max_length=255)
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="Merchant config (pid, pkey, apiBase, notifyUrl, ...)",
    )


class ProviderOut(BaseModel):
    """Gateway credential set with the merchant key masked."""

    id: str
    name: str
    provider_key: str
    is_enabled: bool
    sort_order: int = 0
    remark: Optional[str] = None
    config: Dict[str, Any] = Field(default_factory=dict)

    model_config = {"from_attributes": True}

    @field_validator("config", mode="before")
    @classmethod
    def _parse_config(cls, value):
        """Accept the ORM JSON-string column and tolerate junk."""
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
            except ValueError:
                return {}
            return parsed if isinstance(parsed, dict) else {}
        if value is None:
            return {}
        return value

    @field_validator("config", mode="after")
    @classmethod
    def _mask_pkey(cls, value: Dict[str, Any]) -> Dict[str, Any]:
        """Mask the merchant key no matter who constructed the model."""
        masked = dict(value)
        pkey = masked.get("pkey")
        if isinstance(pkey, str) and pkey:
            masked["pkey"] = mask_pkey(pkey)
        return masked


class PlanIn(BaseModel):
    """Create/update a preset recharge plan."""

    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=255)
    price: float = Field(..., ge=0)
    original_price: Optional[float] = Field(None, ge=0)
    credited_amount: float = Field(..., ge=0)
    validity_days: int = Field(0, ge=0)
    features: List[str] = Field(default_factory=list)
    for_sale: bool = True
    sort_order: int = 0


class PlanOut(PaymentPlanOut):
    """Plan row for the admin console (adds timestamps)."""

    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class AdminUserOut(BaseModel):
    """User row for the admin console."""

    id: str
    username: str
    email: str
    balance: float = 0.0
    total_recharged: float = 0.0
    is_active: bool = True
    is_admin: bool = False
    email_verified: bool = False
    level: str = "default"
    level_manual: bool = False
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class BalanceAdjustIn(BaseModel):
    """Manual balance correction (amount is signed CNY)."""

    amount: float = Field(
        ..., description="Signed amount: positive credits, negative debits"
    )
    reason: str = Field(..., min_length=1, max_length=255)


class UserStatusIn(BaseModel):
    """Enable/disable a user account."""

    is_active: bool


class UserAdminIn(BaseModel):
    """Grant/revoke the admin role."""

    is_admin: bool


class UserLevelIn(BaseModel):
    """Set a user's membership level.

    A null/empty ``level`` clears the manual override and recomputes
    the tier from the user's cumulative recharge.
    """

    level: Optional[str] = Field(
        None, max_length=32, description="Level key, or empty to reset to auto"
    )
    manual: bool = Field(
        True, description="True pins the level; False returns to auto tiering"
    )


class RedeemCodeCreateIn(BaseModel):
    """Batch-generate invitation or promotional codes."""

    code_type: str = Field(..., pattern="^(invitation|promo)$")
    bonus_amount: float = Field(..., ge=0)
    max_uses: int = Field(1, ge=1)
    count: int = Field(1, ge=1, le=100)
    expires_days: Optional[int] = Field(
        None, ge=1, description="Days from now until the codes expire"
    )


class RedeemCodeOut(BaseModel):
    """One redeem code row for the admin console."""

    id: str
    code: str
    code_type: str
    bonus_amount: float
    max_uses: int
    used_count: int
    expires_at: Optional[datetime] = None
    is_active: bool = True
    created_at: Optional[datetime] = None
    used_by: Optional[str] = None
    used_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class AdminOrderOut(OrderOut):
    """Order row for the admin console (adds user + gateway snapshot)."""

    user_id: str
    username: str
    payment_trade_no: Optional[str] = None
    provider_instance_id: Optional[str] = None
    provider_key: Optional[str] = None
    refund_reason: Optional[str] = None
    refunded_at: Optional[datetime] = None
    refund_status: Optional[str] = None
    updated_at: Optional[datetime] = None


T = TypeVar("T")


class AdminListOut(BaseModel, Generic[T]):
    """Generic paged envelope for admin list endpoints."""

    items: List[T] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20
