"""
@file build.py
@author caoshwen
@brief Build agent request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field


class BuildRequest(BaseModel):
    project_root: str = Field(..., description="Project root directory")
    build_type: str = Field(..., description="Build type: unittest/debug/release")
    toolchain: str = Field(..., description="Toolchain: host_gcc/arm_gcc")
    target: str = Field(..., description="Build target")
    clean: bool = Field(default=False, description="Whether to clean build")
