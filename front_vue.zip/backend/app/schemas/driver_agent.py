"""
@file driver_agent.py
@brief Pydantic schemas for Driver Agent multi-turn conversation API.

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

from app.models.driver_agent import (
    DEFAULT_DRIVER_MAX_RETRIES,
    MAX_DRIVER_REPOSITORY_URL_CHARS,
    MAX_DRIVER_SESSION_TITLE_CHARS,
    MAX_DRIVER_SELECTED_PATHS,
    MAX_DRIVER_SOURCE_FILES,
)

from app.core.driver_build_defaults import (
    DEFAULT_BASELINE_FAIL_FAST,
    DEFAULT_BUILD_JOBS,
    DEFAULT_CLEAN_BUILD,
    DEFAULT_DRIVER_BUILD_CONFIGURATION,
    DEFAULT_DRIVER_BUILD_TIMEOUT_SECONDS,
    DEFAULT_DRIVER_COMPILE_ATTEMPTS,
    DEFAULT_STRICT_CONFIGURATION,
    MAX_DRIVER_BUILD_TIMEOUT_SECONDS,
    MAX_BUILD_JOBS,
    MAX_DRIVER_COMPILE_ATTEMPTS,
    MAX_MIDDLEWARE_REPAIR_PATHS,
    MIN_DRIVER_BUILD_TIMEOUT_SECONDS,
)


# ==================== Request Schemas ====================


class DriverModuleConfig(BaseModel):
    """Module configuration from DriverChipConfiguration UI."""
    module_type: str = Field(..., description="Module type: USB, GPIO, UART, SPI, I2C, CAN, PWM, ADC, Other")
    module_name: str = Field(..., description="User-specified module name")
    driver_profile: Optional[str] = Field(default=None, description="Project-specific driver profile")
    required_capabilities: list[str] = Field(default_factory=list, description="Required public driver capabilities")
    device_name: Optional[str] = Field(default=None, description="Device name")
    device_type: Optional[str] = Field(default=None, description="Device type: sensor/actuator/communication")
    interface: Optional[str] = Field(default=None, description="Normalized interface: i2c/spi/uart/gpio/usb/can/pwm/adc")
    # Keep these fields optional for wire compatibility with requests created
    # before the build-platform contract was introduced.  The generation
    # endpoint supplies the platform-neutral build default when ``platform``
    # is omitted and preserves an empty MCU family for the legacy generation
    # flow; new clients should send both values explicitly.
    platform: Optional[str] = Field(
        default=None,
        min_length=1,
        description="Target platform e.g. stm32u3 (optional for legacy clients)",
    )
    mcu_family: Optional[str] = Field(
        default=None,
        min_length=1,
        description="MCU family e.g. STM32U3 (optional for legacy clients)",
    )
    clock_config: Optional[dict[str, Any]] = Field(default=None, description="Clock configuration")
    pins: Optional[list[dict[str, Any]]] = Field(default=None, description="Pin configuration")
    project_path: Optional[str] = Field(
        default=None,
        max_length=4096,
        description="Server-local STM32 project path for generation context and compile verification",
    )
    editor_path: Optional[str] = Field(default=None, description="Platform editor or build tooling path")
    stm32cubeide_path: Optional[str] = Field(default=None, description="STM32CubeIDE installation path")
    workspace_path: Optional[str] = Field(default=None, description="STM32CubeIDE workspace path")
    configuration: Optional[str] = Field(
        default=DEFAULT_DRIVER_BUILD_CONFIGURATION,
        description="Build configuration, e.g. Debug or Release",
    )
    final_configuration: Optional[str] = Field(
        default=None,
        min_length=1,
        description=(
            "Optional explicit final configuration before publishing the generated driver; "
            "when omitted, use configuration"
        ),
    )
    strict_configuration: bool = Field(
        default=DEFAULT_STRICT_CONFIGURATION,
        description="Require the requested configuration instead of an available project configuration",
    )
    clean_build: bool = Field(
        default=DEFAULT_CLEAN_BUILD,
        description="Run a clean build instead of the default incremental build",
    )
    build_jobs: int = Field(
        default=DEFAULT_BUILD_JOBS,
        ge=0,
        le=MAX_BUILD_JOBS,
        description="Parallel build jobs; zero preserves the project setting",
    )
    in_place_build: Optional[bool] = Field(
        default=None,
        description=(
            "Override P4 compile delivery mode. Omit to build and repair transactionally "
            "in the original project."
        ),
    )
    timeout: int = Field(
        default=DEFAULT_DRIVER_BUILD_TIMEOUT_SECONDS,
        ge=MIN_DRIVER_BUILD_TIMEOUT_SECONDS,
        le=MAX_DRIVER_BUILD_TIMEOUT_SECONDS,
        description="Build timeout in seconds",
    )
    target_inc_dir: Optional[str] = Field(
        default=None,
        description="Optional explicit project-relative header directory override",
    )
    target_src_dir: Optional[str] = Field(
        default=None,
        description="Optional explicit project-relative source directory override",
    )
    platformkit_root: Optional[str] = Field(
        default=None,
        description=(
            "Optional manifest-scope-relative platformkit root. Normally inferred from generated "
            "driver placement; use this for platforms with a non-standard placement path."
        ),
    )
    middleware_repair_paths: list[str] = Field(
        default_factory=list,
        max_length=MAX_MIDDLEWARE_REPAIR_PATHS,
        description=(
            "Optional manifest-scope-relative existing files that supplement the automatically "
            "discovered platformkit middleware module. These files are published only after the "
            "final target build succeeds."
        ),
    )


class RegisterDef(BaseModel):
    """Register definition."""
    name: str
    address: int
    width: int = Field(default=8, gt=0, le=64)
    description: Optional[str] = None
    access: Optional[str] = None  # RO/RW/WO
    reset: Optional[str] = None
    fields: Optional[list[dict[str, Any]]] = None


class OutputOptions(BaseModel):
    """Output options controlling what artifacts to generate."""
    include_config: bool = Field(
        default=False,
        description="Deprecated and ignored. DriverAgent never generates a config header.",
    )
    include_tests: bool = True
    include_docs: bool = True
    compile_verify: bool = Field(
        default=True,
        description=(
            "Run the final build verification by default. Set false explicitly "
            "to retain the legacy generation-only behavior."
        ),
    )
    baseline_verify: bool = True
    cli_build_verify: bool = Field(
        default=False,
        description=(
            "Opt in to an isolated candidate build inside the Claude CLI phase. "
            "The backend final build remains authoritative."
        ),
    )
    baseline_fail_fast: bool = Field(
        default=DEFAULT_BASELINE_FAIL_FAST,
        description=(
            "Stop before integrating generated files when the original project "
            "fails baseline compilation"
        ),
    )
    max_compile_attempts: int = Field(
        default=DEFAULT_DRIVER_COMPILE_ATTEMPTS,
        ge=1,
        le=MAX_DRIVER_COMPILE_ATTEMPTS,
    )
    package_format: str = "zip"


class TaskOptions(BaseModel):
    """Task metadata options."""
    title: Optional[str] = None
    session_id: Optional[str] = None
    priority: str = "normal"


class DriverGenerateRequest(BaseModel):
    """Full driver generation request (extended from simple schema)."""
    task_id: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=64,
        pattern=r"^[A-Za-z0-9_-]+$",
        description="Client-provided task ID for early cancellation",
    )
    prompt: str = Field(..., min_length=1, description="User generation prompt")
    module_config: DriverModuleConfig
    source_ids: Optional[list[str]] = Field(
        default=None,
        max_length=MAX_DRIVER_SOURCE_FILES,
        description="Uploaded source IDs",
    )
    repository_source_id: Optional[str] = Field(default=None, description="Repository fetch source ID")
    registers: Optional[list[RegisterDef]] = Field(default=None, description="Register definitions")
    output_options: Optional[OutputOptions] = None


class DriverChatRequest(BaseModel):
    """Multi-turn chat request for driver agent."""
    session_id: Optional[str] = None
    task_id: Optional[str] = None
    message: str = Field(..., min_length=1)
    target_file: Optional[str] = None
    project_root: Optional[str] = None


class DriverRepositoryFetchRequest(BaseModel):
    """Request to fetch a remote repository."""
    model_config = ConfigDict(protected_namespaces=())

    repository_url: str = Field(
        ...,
        min_length=1,
        max_length=MAX_DRIVER_REPOSITORY_URL_CHARS,
        description="Git repository URL",
    )
    branch: Optional[str] = None
    selected_paths: Optional[list[str]] = Field(
        default=None,
        max_length=MAX_DRIVER_SELECTED_PATHS,
    )
    auth: Optional[dict[str, str]] = Field(
        default=None,
        exclude=True,
        repr=False,
        description="Runtime-only repository auth; never persisted or serialized.",
    )


# ==================== Response Schemas ====================


class DriverAgentTaskStateResponse(BaseModel):
    """Task state response."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    session_id: str
    status: str
    current_step: Optional[str] = None
    target_file: Optional[str] = None
    test_file: Optional[str] = None
    project_root: Optional[str] = None
    build_command: Optional[str] = None
    retry_count: int
    max_retries: int
    last_error: Optional[str] = None
    state_data: Optional[dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime


class DriverAgentChatMessageResponse(BaseModel):
    """Chat message response."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    session_id: str
    role: str
    content: str
    message_metadata: Optional[dict[str, Any]] = None
    created_at: datetime


class DriverAgentSessionResponse(BaseModel):
    """Session response."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: Optional[str] = None
    title: Optional[str] = Field(default=None, max_length=MAX_DRIVER_SESSION_TITLE_CHARS)
    agent_type: str
    status: str
    created_at: datetime
    updated_at: datetime


class DriverAgentToolResultResponse(BaseModel):
    """Tool result response."""
    model_config = ConfigDict(from_attributes=True)

    id: str
    task_id: str
    session_id: str
    tool_name: str
    input_data: Optional[dict[str, Any]] = None
    output_data: Optional[dict[str, Any]] = None
    status: str
    error_message: Optional[str] = None
    created_at: datetime


class DriverAgentChatResponse(BaseModel):
    """Chat response from driver agent."""
    session_id: str
    task_id: str
    reply: str
    task_state: DriverAgentTaskStateResponse


class DriverAgentMessagesResponse(BaseModel):
    """Messages list response."""
    session_id: str
    messages: list[DriverAgentChatMessageResponse]


class DriverAgentToolResultsResponse(BaseModel):
    """Tool results list response."""
    task_id: str
    tool_results: list[DriverAgentToolResultResponse]


class DriverSourceResponse(BaseModel):
    """Source file response."""
    model_config = ConfigDict(from_attributes=True)

    source_id: str
    source_type: str
    name: str
    size: int
    extension: str
    mime_type: Optional[str] = None
    upload_status: str
    parse_status: str
    parsed_summary: Optional[str] = None
    extra_metadata: Optional[dict[str, Any]] = None
    created_at: datetime


class DriverSourcesUploadResponse(BaseModel):
    """Upload response for multiple sources."""
    sources: list[DriverSourceResponse]


class DriverRepositorySourceResponse(BaseModel):
    """Repository source response."""
    model_config = ConfigDict(from_attributes=True)

    repository_source_id: str
    repository_url: str
    branch: Optional[str] = None
    included_paths: Optional[list[str]] = None
    file_count: int
    status: str
    created_at: datetime


class DriverArtifactResponse(BaseModel):
    """Artifact response."""
    model_config = ConfigDict(from_attributes=True)

    artifact_id: str
    task_id: str
    name: str
    artifact_type: str
    language: Optional[str] = None
    content: Optional[str] = None
    size: Optional[int] = None
    created_at: datetime


class DriverArtifactsResponse(BaseModel):
    """Artifacts list response."""
    task_id: str
    artifacts: list[DriverArtifactResponse]
    output_dir: Optional[str] = None
