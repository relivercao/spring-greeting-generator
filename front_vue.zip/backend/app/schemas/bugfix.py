"""
@file bugfix.py
@author caoshwen
@brief BugFix agent request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field, field_validator, model_validator
import json
from typing import Optional


def _relative_path(value: str) -> str:
    path = str(value or "").strip().replace("\\", "/")
    segments = path.split("/")
    if not path or path.startswith("/") or any(part in {"", ".", ".."} for part in segments):
        raise ValueError("source paths must be relative and cannot contain traversal segments")
    return path


class BugFixRequest(BaseModel):
    bug_description: str = Field(default="", max_length=20_000, description="Bug description")
    issue_id: Optional[str] = Field(default=None, max_length=128, description="Jira issue key")
    repo: Optional[str] = Field(default=None, max_length=128, description="Bitbucket repository slug")
    branch: str = Field(default="main", min_length=1, max_length=256, description="Bitbucket branch or commit")
    source_files: list[str] = Field(default_factory=list, max_length=32, description="Bitbucket source paths")
    source_contents: dict[str, str] = Field(default_factory=dict, description="Optional inline source files")
    project_root: Optional[str] = Field(default=None, max_length=1000, description="Legacy project root field")
    max_attempts: int = Field(default=3, ge=1, le=10, description="Maximum fix attempts")

    @field_validator("source_files")
    @classmethod
    def validate_source_paths(cls, paths: list[str]) -> list[str]:
        try:
            return [_relative_path(path) for path in paths]
        except ValueError as error:
            raise ValueError("source_files must contain relative paths without traversal segments") from error

    @field_validator("source_contents")
    @classmethod
    def validate_inline_sources(cls, sources: dict[str, str]) -> dict[str, str]:
        if len(sources) > 32:
            raise ValueError("source_contents may contain at most 32 files")
        total_chars = 0
        normalized = {}
        try:
            for path, content in sources.items():
                safe_path = _relative_path(path)
                if not isinstance(content, str) or len(content) > 250_000:
                    raise ValueError("each inline source file must be text with at most 250000 characters")
                total_chars += len(content)
                normalized[safe_path] = content
        except ValueError as error:
            raise ValueError(f"Invalid source_contents: {error}") from error
        if total_chars > 1_000_000:
            raise ValueError("source_contents may contain at most 1000000 characters in total")
        return normalized

    @model_validator(mode="after")
    def validate_task_inputs(self):
        if not self.bug_description.strip() and not (self.issue_id or "").strip():
            raise ValueError("bug_description or issue_id is required")
        if self.source_files and not (self.repo or "").strip():
            raise ValueError("repo is required when source_files are provided")
        return self


class BugFixBatchRequest(BaseModel):
    """An ordered queue of independent defects with complete source context."""

    items: list[BugFixRequest] = Field(min_length=1, max_length=100)

    @model_validator(mode="after")
    def validate_batch_size(self):
        if len(json.dumps(self.model_dump()).encode("utf-8")) > 5_000_000:
            raise ValueError("Batch inputs may contain at most 5000000 bytes in total")
        return self
