"""Knowledge base API schemas."""

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


class KnowledgeConversationMessage(BaseModel):
    """One bounded user or assistant message used to resolve follow-up questions."""

    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=4000)


class KnowledgeAskRequest(BaseModel):
    """Register-first knowledge base question."""

    question: str = Field(min_length=1, max_length=4000)
    chip: Optional[str] = Field(default=None, max_length=100)
    document_id: Optional[str] = None
    history: list[KnowledgeConversationMessage] = Field(default_factory=list, max_length=12)
    limit: int = Field(default=5, ge=1, le=20)
    use_llm: bool = True
    retrieval_mode: Literal["hybrid", "keyword"] = "hybrid"


class KnowledgeChunkPreviewRequest(BaseModel):
    """Preview structure-aware chunks without writing an index entry."""

    text: str = Field(min_length=1, max_length=65536)
    max_chars: int = Field(default=2200, ge=400, le=8000)


class PdfConversionSummary(BaseModel):
    """Docling and LLM OCR statistics returned for PDF ingestion."""

    engine: str = "docling"
    pages: int = 0
    tables: int = 0
    text_chars: int = 0
    llm_ocr_pages: int = 0
    llm_ocr_chars: int = 0
    llm_ocr_provider: str = ""
    llm_ocr_model: str = ""
    source_lines: int = 0
    source_checksum: str = ""
    lossless_verified: bool = True
    warnings: list[str] = Field(default_factory=list)
    page_quality: list[dict[str, Any]] = Field(default_factory=list)
    extraction_completeness: str = "not_verified"


class KnowledgePublicationSummary(BaseModel):
    """Automatic human-readable site publication result."""

    attempted: bool = False
    ok: bool = False
    local_url: str = ""
    error: str = ""


class KnowledgeIngestResponse(BaseModel):
    """Document ingestion result."""

    ok: bool = True
    document_id: str
    title: str
    stats: dict[str, Any]
    conversion: Optional[PdfConversionSummary] = None
    repository_path: Optional[str] = None
    publication: Optional[KnowledgePublicationSummary] = None


class KnowledgeRepositorySyncRequest(BaseModel):
    """Synchronize the canonical Git repository and optionally rebuild SQLite."""

    pull: bool = True
    push: bool = False
    rebuild_index: bool = True


class GitHubReferenceImportRequest(BaseModel):
    """Clone a public GitHub repository and import its Markdown documentation."""

    repository: str = Field(min_length=1, max_length=300)
    ref: str = Field(default="", max_length=200)
    chip: str = Field(default="GENERAL", min_length=1, max_length=100)
    revision: str = Field(default="", max_length=100)
    doc_type: str = Field(default="reference-project", max_length=100)
    tags: list[str] = Field(default_factory=list, max_length=30)
    max_documents: int = Field(default=100, ge=1, le=500)


class ObsidianVaultImportRequest(BaseModel):
    """Import Markdown notes from a local Obsidian vault."""

    path: str = Field(default="", max_length=2000)
    chip: str = Field(default="", max_length=100)
    revision: str = Field(default="", max_length=100)
    doc_type: str = Field(default="obsidian-note", max_length=100)
    tags: list[str] = Field(default_factory=list, max_length=30)
    include_globs: list[str] = Field(default_factory=list, max_length=50)
    exclude_globs: list[str] = Field(default_factory=list, max_length=50)
    max_documents: int = Field(default=500, ge=1, le=5000)
    rebuild_index: bool = True


class MkDocsBuildRequest(BaseModel):
    """Build options for the static MkDocs interface."""

    strict: bool = False
    clean: bool = True


class MarkdownIngestRequest(BaseModel):
    """Path-based Markdown ingestion request for batch and CLI workflows."""

    path: str = Field(min_length=1, max_length=1000)
    chip: str = Field(default="GENERAL", min_length=1, max_length=100)
    title: str = Field(min_length=1, max_length=300)
    revision: str = Field(default="", max_length=100)
    peripheral_hint: str = Field(default="", max_length=100)
    doc_type: str = Field(default="reference", max_length=100)
    tags: list[str] = Field(default_factory=list, max_length=30)


class PdfIngestRequest(MarkdownIngestRequest):
    """Path-based PDF ingestion request."""

    no_ocr: bool = False
    llm_ocr: bool = True
    skip_extract: bool = False


class KnowledgeAskResponse(BaseModel):
    """Register-first answer and supporting evidence."""

    mode: str = "register_first"
    answer: str
    confidence: str
    confidence_score: float = Field(default=0.5, ge=0.0, le=1.0)
    exact_hits: list[dict[str, Any]] = Field(default_factory=list)
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    parsed_query: dict[str, Any] = Field(default_factory=dict)
    retrieval_stage: str = "highest_match"
    retrieval_mode: Literal["hybrid", "keyword"] = "hybrid"
    llm_used: bool = False
    llm_provider: str = ""
    llm_model: str = ""
    llm_mode: Literal["disabled", "unavailable", "fallback", "synthesis", "no_evidence", "not_needed", "semantic_cli"] = "disabled"
    llm_prompt_version: str = ""
    semantic_lookup_used: bool = False
    semantic_lookup_path: str = ""
    semantic_lookup_confidence_before: float = Field(default=0.5, ge=0.0, le=1.0)
    semantic_lookup_threshold: float = Field(default=0.9, ge=0.0, le=1.0)
    semantic_lookup_mode: Literal["disabled", "skipped", "not_needed", "claude_cli", "failed"] = "disabled"
    semantic_lookup_error: str = ""
    semantic_lookup_provider: str = ""
