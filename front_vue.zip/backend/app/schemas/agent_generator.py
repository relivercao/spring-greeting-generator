"""Schemas for Git-backed Agent generation and execution."""

from typing import Any, Literal
import re

from pydantic import BaseModel, Field, field_validator


class KnowledgeReference(BaseModel):
    """A selectable canonical knowledge document."""

    id: str
    title: str
    chip: str = "GENERAL"
    revision: str = ""
    repository_path: str = ""
    updated_at: str = ""
    source_type: str = ""


class AgentInputFile(BaseModel):
    """A file uploaded as an input to an Agent definition."""

    id: str
    name: str
    size: int = 0
    content_type: str = "application/octet-stream"
    repository_path: str = ""
    uploaded_at: str = ""
    code_analysis: dict[str, Any] = Field(default_factory=dict)


class AgentSkillFile(BaseModel):
    """A skill instruction file attached to an Agent definition."""

    id: str
    name: str
    size: int = 0
    content_type: str = "text/markdown"
    repository_path: str = ""
    uploaded_at: str = ""


class AgentInputDefinition(BaseModel):
    """A runtime value accepted by a generated Agent task."""

    id: str = Field(min_length=1, max_length=80)
    label: str = Field(min_length=1, max_length=120)
    type: Literal["text", "textarea", "number", "boolean", "select", "file"] = "text"
    required: bool = False
    placeholder: str = Field(default="", max_length=300)
    default: Any = None
    options: list[str] = Field(default_factory=list, max_length=100)


class AgentExternalTool(BaseModel):
    """An MCP tool selected for a generated Agent."""

    name: str
    description: str = ""
    server: str = ""
    input_schema: dict[str, Any] = Field(default_factory=dict)


class AgentFlowNode(BaseModel):
    """One user-configurable step in a generated Agent flow."""

    id: str
    label: str
    description: str = ""
    kind: str = "task"
    approval_channels: list[Literal["email", "feishu"]] = Field(default_factory=list)
    approval_recipients: list[str] = Field(default_factory=list, max_length=50)
    approval_required: bool | None = None


class GeneratedAgentWorkflowNode(AgentFlowNode):
    """Runtime state for one generated Agent workflow node."""

    status: Literal["pending", "active", "done", "fail"] = "pending"


AgentOutputMode = Literal["text", "file", "both"]
AgentOutputFormat = Literal["markdown", "text", "json", "yaml", "csv", "c_source", "c_header", "python"]
AgentLLMProvider = Literal["macode", "bedrock"]


class GeneratedAgentOutputFile(BaseModel):
    """A downloadable artifact created by a generated Agent task."""

    id: str
    name: str
    path: str = ""
    size: int = 0
    content_type: str = "application/octet-stream"
    repository_path: str = ""
    download_url: str = ""
    created_at: str = ""


class GeneratedAgent(BaseModel):
    """A generated Agent manifest stored in the knowledge Git tree."""

    id: str
    name: str
    description: str = ""
    goal: str = ""
    icon: str = "MagicStick"
    color: str = "#2563eb"
    logo_url: str = ""
    category: str = "Generated"
    system_prompt: str = ""
    prompt_preview: str = ""
    capabilities: list[str] = Field(default_factory=list)
    knowledge_document_ids: list[str] = Field(default_factory=list)
    knowledge_documents: list[KnowledgeReference] = Field(default_factory=list)
    repository_path: str = ""
    llm_provider: str = "macode"
    llm_model: str = ""
    generated_by_llm: bool = False
    warnings: list[str] = Field(default_factory=list)
    input_files: list[AgentInputFile] = Field(default_factory=list)
    input_definitions: list[AgentInputDefinition] = Field(default_factory=list)
    skill_files: list[AgentSkillFile] = Field(default_factory=list)
    market_skill_names: list[str] = Field(default_factory=list)
    selected_tools: list[AgentExternalTool] = Field(default_factory=list)
    flow_nodes: list[AgentFlowNode] = Field(default_factory=list)
    output_mode: AgentOutputMode = "text"
    output_format: AgentOutputFormat = "markdown"
    output_filename: str = ""
    created_at: str = ""
    updated_at: str = ""


class GenerateAgentRequest(BaseModel):
    """Input used to design a new Agent."""

    name: str = Field(default="", max_length=120)
    goal: str = Field(default="", max_length=2000)
    prompt: str = Field(min_length=1, max_length=20000)
    icon: str = Field(default="MagicStick", max_length=60)
    color: str = Field(default="#2563eb", max_length=20)
    logo_url: str = Field(default="", max_length=500)
    knowledge_document_ids: list[str] = Field(default_factory=list, max_length=100)
    input_files: list[AgentInputFile] = Field(default_factory=list, max_length=50)
    input_definitions: list[AgentInputDefinition] = Field(default_factory=list, max_length=30)
    skill_files: list[AgentSkillFile] = Field(default_factory=list, max_length=30)
    market_skill_names: list[str] = Field(default_factory=list, max_length=30)
    selected_tools: list[str] = Field(default_factory=list, max_length=50)
    flow_nodes: list[AgentFlowNode] = Field(default_factory=list, max_length=30)
    llm_provider: AgentLLMProvider = "macode"
    llm_model: str = Field(default="", max_length=200)
    output_mode: AgentOutputMode = "text"
    output_format: AgentOutputFormat = "markdown"
    output_filename: str = Field(default="", max_length=120)

    @field_validator("market_skill_names")
    @classmethod
    def validate_market_skill_names(cls, values: list[str]) -> list[str]:
        normalized = [value.strip() for value in values]
        if any(not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", value) for value in normalized):
            raise ValueError("market_skill_names must contain valid Skill names")
        return list(dict.fromkeys(normalized))


class GenerateAgentSkillRequest(BaseModel):
    """Input used to draft a Skill for a generated Agent."""

    name: str = Field(min_length=1, max_length=64, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    goal: str = Field(min_length=1, max_length=5000)
    agent_name: str = Field(default="", max_length=120)
    agent_goal: str = Field(default="", max_length=2000)
    agent_prompt: str = Field(default="", max_length=20000)
    llm_provider: AgentLLMProvider = "macode"
    llm_model: str = Field(default="", max_length=200)

    @field_validator("goal")
    @classmethod
    def _trim_required_goal(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Skill goal is required")
        return normalized


class GenerateAgentSkillResponse(BaseModel):
    """Validated Skill draft returned for review before attachment."""

    name: str
    description: str
    content: str
    warnings: list[str] = Field(default_factory=list)


class GenerateAgentResponse(BaseModel):
    """Generated Agent response including its canonical repository path."""

    ok: bool = True
    agent: GeneratedAgent


class GeneratedAgentChatRequest(BaseModel):
    """Message sent to a generated Agent."""

    message: str = Field(min_length=1, max_length=20000)
    history: list[dict[str, Any]] = Field(default_factory=list, max_length=50)
    inputs: dict[str, Any] = Field(default_factory=dict, max_length=30)


class GeneratedAgentApprovalRequest(BaseModel):
    """Approval decision submitted for a pending generated Agent task."""

    decision: Literal["approve", "reject"]
    comment: str = Field(default="", max_length=4000)
    token: str = Field(default="", max_length=200)


class GeneratedAgentTaskStartResponse(BaseModel):
    """Acknowledgement returned when a generated Agent task starts."""

    task_id: str
    agent_id: str
    status: str = "running"
    started_at: str = ""


class GeneratedAgentTaskStatusResponse(BaseModel):
    """Observable state for a generated Agent task."""

    task_id: str
    agent_id: str
    status: str
    message: str = ""
    response: str = ""
    output_files: list[GeneratedAgentOutputFile] = Field(default_factory=list)
    workflow_nodes: list[GeneratedAgentWorkflowNode] = Field(default_factory=list)
    progress: int = Field(default=0, ge=0, le=100)
    knowledge_documents: list[KnowledgeReference] = Field(default_factory=list)
    market_skills: list[dict[str, Any]] = Field(default_factory=list)
    provider: str = ""
    model: str = ""
    usage: dict[str, int] = Field(default_factory=dict)
    quality: dict[str, Any] = Field(default_factory=dict)
    approval: dict[str, Any] = Field(default_factory=dict)
    started_at: str = ""
    completed_at: str = ""
