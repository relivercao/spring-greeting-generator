"""Bounded event envelopes and deterministic routing configuration."""

from typing import Literal
from pathlib import PurePosixPath

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.agents.base import AgentType


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EventData(StrictModel):
    source_contents: dict[str, str] = Field(default_factory=dict, max_length=20)
    crash_log: str = Field(default="", max_length=100000)
    stack_trace: str = Field(default="", max_length=20000)
    register_dump: dict[str, str] = Field(default_factory=dict, max_length=64)
    chip: str = Field(default="", max_length=100)

    @field_validator("source_contents")
    @classmethod
    def safe_sources(cls, value):
        for path, content in value.items():
            parts = PurePosixPath(path).parts
            if (not parts or len(path) > 240 or "\\" in path or ":" in path or "\x00" in path
                    or path.startswith("/") or any(part in {".", ".."} for part in path.split("/"))):
                raise ValueError("Source names must be safe relative paths.")
            if not content.strip() or len(content) > 100000:
                raise ValueError("Each inline source must contain 1 to 100000 characters.")
        if sum(map(len, value.values())) > 250000:
            raise ValueError("Combined inline source content must not exceed 250000 characters.")
        return value

    @field_validator("register_dump")
    @classmethod
    def bounded_registers(cls, value):
        if any(len(key) > 80 or len(item) > 128 for key, item in value.items()):
            raise ValueError("Register names or values exceed the supported size.")
        return value


class EventInput(StrictModel):
    event_id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")
    event_type: str = Field(min_length=1, max_length=100, pattern=r"^[a-z][a-z0-9_.-]*$")
    text: str = Field(min_length=1, max_length=16000)
    actor_id: str = Field(default="", max_length=128)
    subject_id: str = Field(default="", max_length=128)
    data: EventData = Field(default_factory=EventData)

    @field_validator("text")
    @classmethod
    def nonblank_text(cls, value):
        if not value.strip():
            raise ValueError("Event text must not be blank.")
        return value


class EventRule(StrictModel):
    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_-]+$")
    name: str = Field(min_length=1, max_length=80)
    enabled: bool = True
    priority: int = Field(default=100, ge=0, le=1000)
    source: Literal["*", "api", "feishu", "webhook"] = "*"
    source_id: str = Field(default="", max_length=128)
    event_type: str = Field(default="*", max_length=100, pattern=r"^(\*|[a-z][a-z0-9_.-]*\*?)$")
    match: Literal["any", "command", "contains"] = "any"
    value: str = Field(default="", max_length=120)
    agent: AgentType

    @model_validator(mode="after")
    def valid_condition(self):
        if self.source == "api" and self.source_id:
            raise ValueError("Authenticated API events do not have a source ID. Leave it empty.")
        if self.match != "any" and not self.value.strip():
            raise ValueError("A command or keyword match requires a value.")
        if self.match == "command" and (not self.value.startswith("/") or any(c.isspace() for c in self.value)):
            raise ValueError("Commands must start with / and contain no whitespace.")
        return self


class RoutingPolicyInput(StrictModel):
    enabled: bool = False
    fallback_agent: AgentType | None = None
    rules: list[EventRule] = Field(default_factory=list, max_length=50)
    revision: int = Field(default=0, ge=0)

    @field_validator("rules")
    @classmethod
    def unique_ids(cls, value):
        if len({rule.id for rule in value}) != len(value):
            raise ValueError("Routing rule IDs must be unique.")
        return value


class EventPreview(StrictModel):
    event: EventInput
    source: Literal["api", "feishu", "webhook"] = "api"
    source_id: str = Field(default="", max_length=128)
    policy: RoutingPolicyInput | None = None

    @model_validator(mode="after")
    def valid_source(self):
        if self.source == "api" and self.source_id:
            raise ValueError("Authenticated API events do not have a source ID. Leave it empty.")
        return self


class WebhookSourceInput(StrictModel):
    name: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9][A-Za-z0-9 _.-]*$")


class WebhookSourceState(StrictModel):
    enabled: bool
