"""
@file chat.py
@author caoshwen
@brief Chat request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field
from typing import Optional, Any


class ChatRequest(BaseModel):
    message: str = Field(..., description="User message")
    agent: str = Field(default="chat", description="Agent type: chat/unittest/driver/build/bugfix/debug/review/knowledge")
    context: Optional[dict[str, Any]] = Field(default=None, description="Conversation context")
    history: Optional[list[dict[str, Any]]] = Field(default=None, description="Historical messages")
    session_id: Optional[str] = Field(default=None, description="Session ID")
    web_search_enabled: bool = Field(default=True, description="Search public web sources for this chat message")
