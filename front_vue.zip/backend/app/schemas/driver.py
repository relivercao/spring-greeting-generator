"""
@file driver.py
@author caoshwen
@brief Driver generation request/response schemas.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from pydantic import BaseModel, Field
from typing import Optional


class RegisterDef(BaseModel):
    name: str
    address: int
    width: int


class DriverGenerationRequest(BaseModel):
    device_name: str = Field(..., description="Device name")
    device_type: str = Field(..., description="Device type")
    interface: str = Field(..., description="Interface type: i2c/spi/uart")
    registers: list[RegisterDef] = Field(..., description="Register definitions")
    platform: Optional[str] = Field(default=None, description="Target platform")
