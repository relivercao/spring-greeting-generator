"""Persistence model for preset recharge plans.

A :class:`RechargePlan` is a fixed-price package offered on the recharge
page.  ``price`` is the CNY amount charged, ``credited_amount`` the CNY
balance credited on completion, and ``validity_days`` the optional
validity window (``0`` means a plain balance top-up).  ``features`` is a
JSON-encoded string so the frontend can render perk labels without a
schema change per deployment.
"""

from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import Boolean, DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


def _uuid4() -> str:
    """Generate the lowercase UUID v4 representation used by plan IDs."""

    return str(uuid.uuid4())


class RechargePlan(Base):
    """One preset recharge package for sale."""

    __tablename__ = "recharge_plans"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    price: Mapped[float] = mapped_column(Float, nullable=False)
    original_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    credited_amount: Mapped[float] = mapped_column(Float, nullable=False)
    # 0 means a pure balance top-up with no validity window.
    validity_days: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # JSON-encoded list of feature labels shown on the plan card.
    features: Mapped[str | None] = mapped_column(Text, nullable=True)
    for_sale: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )


__all__ = ["RechargePlan"]
