"""Persistence model for EasyPay recharge orders.

A :class:`PaymentOrder` row is created when a user submits a recharge
request, carries the EasyPay gateway trade snapshot, and walks the order
state machine (``pending`` -> ``paid`` -> ``recharging`` -> ``completed``)
driven by the fulfillment service.  All money columns are CNY floats:
``amount`` is the order face value, ``pay_amount`` the value actually
charged by the gateway, and ``credited_amount`` the balance credited on
completion.  ``username`` is a snapshot taken at creation time so order
history survives later username changes.
"""

from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


def _uuid4() -> str:
    """Generate the lowercase UUID v4 representation used by order IDs."""

    return str(uuid.uuid4())


class OrderStatus:
    """Payment order lifecycle states (single-word protocol values)."""

    PENDING = "pending"        # Created, waiting for gateway payment
    PAID = "paid"              # Payment confirmed, fulfillment not started
    RECHARGING = "recharging"  # Fulfillment lease held, credit in flight
    COMPLETED = "completed"    # Balance credited to the user
    EXPIRED = "expired"        # Not paid before expires_at
    CANCELLED = "cancelled"    # Cancelled by the user while pending
    FAILED = "failed"          # Fulfillment error, retryable
    REFUNDED = "refunded"      # Completed order refunded via the gateway

    ALL: tuple[str, ...] = (
        PENDING,
        PAID,
        RECHARGING,
        COMPLETED,
        EXPIRED,
        CANCELLED,
        FAILED,
        REFUNDED,
    )


class PaymentOrder(Base):
    """One recharge order and its gateway/payment lifecycle snapshot."""

    __tablename__ = "payment_orders"
    __table_args__ = (
        CheckConstraint(
            "status IN ('pending', 'paid', 'recharging', 'completed', "
            "'expired', 'cancelled', 'failed', 'refunded')",
            name="ck_payment_orders_status",
        ),
        CheckConstraint(
            "order_type IN ('balance', 'plan')",
            name="ck_payment_orders_order_type",
        ),
        Index("ix_payment_orders_user_created_at", "user_id", "created_at"),
        Index("ix_payment_orders_status_created_at", "status", "created_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4)
    # Merchant order number allocated by the payment service
    # ("MAC" + YYYYMMDD + 8 random characters).
    out_trade_no: Mapped[str] = mapped_column(
        String(64), unique=True, nullable=False, index=True
    )
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False, index=True
    )
    username: Mapped[str] = mapped_column(String(50), nullable=False)
    order_type: Mapped[str] = mapped_column(
        String(20), nullable=False, default="balance"
    )

    # Plan snapshot (only set when order_type == "plan").
    plan_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    plan_name: Mapped[str | None] = mapped_column(String(100), nullable=True)

    amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    pay_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    credited_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)

    payment_type: Mapped[str] = mapped_column(
        String(20), nullable=False, default="alipay"
    )
    provider_instance_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True, index=True
    )
    provider_key: Mapped[str | None] = mapped_column(String(50), nullable=True)
    payment_trade_no: Mapped[str | None] = mapped_column(String(64), nullable=True)
    pay_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    qr_code: Mapped[str | None] = mapped_column(Text, nullable=True)

    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=OrderStatus.PENDING, index=True
    )
    client_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)

    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True, index=True
    )
    paid_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    failed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    failed_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)

    refund_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    refund_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    refunded_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    refund_status: Mapped[str | None] = mapped_column(String(20), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )


__all__ = ["OrderStatus", "PaymentOrder"]
