"""
@file audit_log.py
@author caoshwen
@brief Audit log model for tracking user actions.

@version 3.2
@date 2026-07-25

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, DateTime, JSON, Index
from sqlalchemy.orm import declarative_base

from app.core.database import Base


class AuditLog(Base):
    """
    Audit log model for tracking all user actions.
    
    Tracks:
    - Who performed the action (user_id)
    - What action was performed (action)
    - Which resource was affected (resource_type, resource_id)
    - When it happened (timestamp)
    - From where (ip_address, user_agent)
    - What was the result (result, error_message)
    - Additional context (details)
    """
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Who
    user_id = Column(String(64), nullable=False, index=True)
    username = Column(String(64), nullable=True)
    
    # What
    action = Column(String(128), nullable=False, index=True)
    # Examples: "chat.create", "agent.execute", "session.create", "user.login", "settings.update"
    
    # Which resource
    resource_type = Column(String(64), nullable=True)
    # Examples: "session", "task", "message", "user", "settings"
    resource_id = Column(String(128), nullable=True, index=True)
    
    # When
    timestamp = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        index=True
    )
    
    # From where
    ip_address = Column(String(45), nullable=True)  # IPv6 max length
    user_agent = Column(String(512), nullable=True)
    
    # Result
    result = Column(String(32), nullable=False, default="success")
    # Values: "success", "failure", "denied", "error"
    
    error_message = Column(String(512), nullable=True)
    
    # Additional context
    details = Column(JSON, nullable=True)
    # Store additional context like: request parameters, response size, duration, etc.
    
    # Indexes for common queries
    __table_args__ = (
        Index('ix_audit_logs_user_timestamp', 'user_id', 'timestamp'),
        Index('ix_audit_logs_action_timestamp', 'action', 'timestamp'),
        Index('ix_audit_logs_resource', 'resource_type', 'resource_id'),
    )
    
    def __repr__(self) -> str:
        return (
            f"<AuditLog(id={self.id}, user={self.username}, "
            f"action={self.action}, result={self.result}, "
            f"timestamp={self.timestamp})>"
        )
    
    def to_dict(self) -> dict:
        """Convert audit log to dictionary."""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "username": self.username,
            "action": self.action,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "ip_address": self.ip_address,
            "user_agent": self.user_agent,
            "result": self.result,
            "error_message": self.error_message,
            "details": self.details,
        }


# Common action types (for reference)
class AuditAction:
    """Audit action constants."""
    
    # Authentication
    USER_LOGIN = "user.login"
    USER_LOGOUT = "user.logout"
    USER_REGISTER = "user.register"
    TOKEN_REFRESH = "token.refresh"
    
    # Chat
    CHAT_CREATE = "chat.create"
    CHAT_STREAM = "chat.stream"
    
    # Sessions
    SESSION_CREATE = "session.create"
    SESSION_DELETE = "session.delete"
    SESSION_LIST = "session.list"
    
    # Agents
    AGENT_EXECUTE = "agent.execute"
    AGENT_CANCEL = "agent.cancel"
    
    # Tasks
    TASK_CREATE = "task.create"
    TASK_UPDATE = "task.update"
    TASK_DELETE = "task.delete"
    
    # Settings
    SETTINGS_VIEW = "settings.view"
    SETTINGS_UPDATE = "settings.update"
    
    # Admin
    ADMIN_USER_VIEW = "admin.user.view"
    ADMIN_USER_UPDATE = "admin.user.update"
    ADMIN_LOGS_VIEW = "admin.logs.view"


# Result types
class AuditResult:
    """Audit result constants."""
    SUCCESS = "success"
    FAILURE = "failure"
    DENIED = "denied"
    ERROR = "error"
