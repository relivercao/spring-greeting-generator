"""
@file task.py
@author caoshwen
@brief Task ORM model for async task tracking.

@version 3.2
@date 2026-03-09

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime, timezone
from sqlalchemy import DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Task(Base):
    __tablename__ = "tasks"
    __table_args__ = (
        # A BatchItem may create at most one ordinary child Task.  NULL values
        # remain repeatable for ordinary (non-batch) tasks on SQLite.
        UniqueConstraint("batch_item_id", name="uq_tasks_batch_item_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    session_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("sessions.id"), nullable=True)
    batch_task_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("batch_tasks.id", name="fk_tasks_batch_task_id_batch_tasks", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    batch_item_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("batch_items.id", name="fk_tasks_batch_item_id_batch_items", ondelete="SET NULL"),
        nullable=True,
    )
    agent_type: Mapped[str] = mapped_column(String(20), nullable=False, index=True)  # unittest/driver/build/...
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)  # pending/running/completed/failed/cancelled
    progress: Mapped[int] = mapped_column(Integer, default=0)  # 0-100
    message: Mapped[str] = mapped_column(String(500), default="")
    input_data: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON: task input parameters
    result_data: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON: task execution result
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    duration_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
