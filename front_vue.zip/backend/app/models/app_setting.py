"""Persistence model for application-wide settings.

:class:`AppSetting` is a small key/value store for runtime configuration
(payment limits, LLM pricing table, registration toggles).  ``value`` is
a JSON-encoded text column so different keys can carry different shapes
without schema changes; serialization and validation belong to the
service layer, mirroring the batch models' JSON-as-Text convention.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


class AppSetting(Base):
    """One JSON-encoded application setting entry."""

    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )


__all__ = ["AppSetting"]
