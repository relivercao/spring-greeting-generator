"""Provider-scoped model metadata and independently maintained token prices."""

from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ModelCatalogEntry(Base):
    __tablename__ = "model_catalog"
    __table_args__ = (UniqueConstraint("provider", "model", name="uq_model_catalog_identity"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    provider: Mapped[str] = mapped_column(String(50), index=True)
    model: Mapped[str] = mapped_column(String(200), index=True)
    display_name: Mapped[str] = mapped_column(String(200))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    context_window: Mapped[int | None] = mapped_column(Integer, nullable=True)
    max_output_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    input_usd_per_mtok: Mapped[float | None] = mapped_column(Float, nullable=True)
    output_usd_per_mtok: Mapped[float | None] = mapped_column(Float, nullable=True)
    cache_read_usd_per_mtok: Mapped[float | None] = mapped_column(Float, nullable=True)
    cache_write_usd_per_mtok: Mapped[float | None] = mapped_column(Float, nullable=True)
    source: Mapped[str] = mapped_column(String(200), default="manual")
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
