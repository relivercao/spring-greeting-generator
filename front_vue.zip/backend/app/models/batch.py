"""Persistence models for queued batch Unit-Test execution.

The batch layer deliberately keeps its state separate from the existing
``tasks`` lifecycle.  A :class:`BatchTask` owns an ordered set of
:class:`BatchItem` rows, while :class:`BatchQueueEntry` is the only source of
FIFO ordering and :class:`DispatcherLease` only records dispatcher ownership.
The ordinary ``Task`` row is linked once an item is actually started.

JSON values (for example ``result_summary``) use ``Text`` just like the
existing task model.  This keeps the SQLite and future PostgreSQL schemas
portable and leaves serialization/validation to the service layer.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
import uuid

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.batch_contract import BatchItemStatus, BatchTaskStatus
from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


def _uuid4() -> str:
    """Generate the lowercase UUID v4 representation used by batch IDs."""

    return str(uuid.uuid4())


def _opaque_id() -> str:
    """Generate an internal queue row identifier.

    Queue IDs are deliberately opaque to the HTTP API.  UUID strings are a
    convenient collision-resistant representation while retaining that
    implementation detail.
    """

    return uuid.uuid4().hex


class BatchQueueEntryState(str, Enum):
    """Internal state of a batch FIFO queue record."""

    QUEUED = "queued"
    CLAIMED = "claimed"
    RELEASED = "released"


class BatchTask(Base):
    """A persisted batch and its lifecycle/progress snapshot."""

    __tablename__ = "batch_tasks"
    __table_args__ = (
        CheckConstraint(
            "status IN ('queued', 'running', 'done')",
            name="ck_batch_tasks_status",
        ),
        CheckConstraint(
            "progress >= 0 AND progress <= 100",
            name="ck_batch_tasks_progress",
        ),
        CheckConstraint("version >= 1", name="ck_batch_tasks_version"),
        Index("ix_batch_tasks_status_created_at", "status", "created_at"),
    )

    # Batch IDs are generated server-side.  ``String(36)`` intentionally
    # mirrors the existing Task ID type and the UUID-only download contract.
    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=_uuid4
    )

    # The first release runs in a local/anonymous mode and does not perform
    # user filtering.  Keeping an optional FK still allows authenticated
    # callers and makes the child Task association auditable.
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False, index=True
    )
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=BatchTaskStatus.QUEUED.value, index=True
    )
    project_root: Mapped[str] = mapped_column(Text, nullable=False)
    cancel_requested: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    terminal_reason: Mapped[str | None] = mapped_column(
        String(100), nullable=True
    )
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    items: Mapped[list["BatchItem"]] = relationship(
        "BatchItem",
        back_populates="batch_task",
        cascade="all, delete-orphan",
        order_by="BatchItem.sequence",
    )
    queue_entry: Mapped["BatchQueueEntry | None"] = relationship(
        "BatchQueueEntry",
        back_populates="batch_task",
        uselist=False,
        cascade="all, delete-orphan",
    )

    # SQLAlchemy's built-in integer versioning gives state transitions an
    # optimistic-lock check while leaving explicit service-level UPDATEs
    # possible for dispatcher fencing.
    __mapper_args__ = {"version_id_col": version}


class BatchItem(Base):
    """One immutable source-file input and its existing child Task link."""

    __tablename__ = "batch_items"
    __table_args__ = (
        UniqueConstraint(
            "batch_task_id",
            "sequence",
            name="uq_batch_items_task_sequence",
        ),
        UniqueConstraint(
            "unittest_task_id",
            name="uq_batch_items_unittest_task_id",
        ),
        CheckConstraint(
            "sequence >= 0", name="ck_batch_items_sequence_nonnegative"
        ),
        CheckConstraint(
            "status IN ('queued', 'running', 'pass', 'fail')",
            name="ck_batch_items_status",
        ),
        CheckConstraint(
            "progress >= 0 AND progress <= 100",
            name="ck_batch_items_progress",
        ),
        Index("ix_batch_items_batch_task_sequence", "batch_task_id", "sequence"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=_uuid4
    )
    batch_task_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("batch_tasks.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    source_path: Mapped[str] = mapped_column(Text, nullable=False)
    relative_path: Mapped[str] = mapped_column(Text, nullable=False)
    snapshot_path: Mapped[str] = mapped_column(Text, nullable=False)
    content_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=BatchItemStatus.QUEUED.value, index=True
    )
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    current_stage: Mapped[str | None] = mapped_column(String(100), nullable=True)
    message: Mapped[str | None] = mapped_column(String(500), nullable=True)
    blocked_reason: Mapped[str | None] = mapped_column(String(100), nullable=True)
    resume_required: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False
    )
    unittest_task_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey(
            "tasks.id",
            name="fk_batch_items_unittest_task_id_tasks",
            ondelete="SET NULL",
            use_alter=True,
        ),
        nullable=True,
    )
    result_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    terminal_reason: Mapped[str | None] = mapped_column(String(100), nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    batch_task: Mapped[BatchTask] = relationship(
        "BatchTask", back_populates="items", foreign_keys=[batch_task_id]
    )
    # This is intentionally a one-way relationship.  Task also stores the
    # batch_item_id guard column, so a bidirectional relationship would create
    # two competing foreign-key joins between the same pair of tables.
    unittest_task: Mapped["Task | None"] = relationship(
        "Task", foreign_keys=[unittest_task_id]
    )


class BatchQueueEntry(Base):
    """Internal FIFO record for one BatchTask."""

    __tablename__ = "batch_queue_entries"
    __table_args__ = (
        UniqueConstraint("batch_task_id", name="uq_batch_queue_entries_task"),
        UniqueConstraint("queue_seq", name="uq_batch_queue_entries_queue_seq"),
        CheckConstraint(
            "queue_seq >= 0", name="ck_batch_queue_entries_queue_seq"
        ),
        CheckConstraint(
            "state IN ('queued', 'claimed', 'released')",
            name="ck_batch_queue_entries_state",
        ),
        Index("ix_batch_queue_entries_state_queue_seq", "state", "queue_seq"),
    )

    id: Mapped[str] = mapped_column(
        String(64), primary_key=True, default=_opaque_id
    )
    batch_task_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("batch_tasks.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    queue_seq: Mapped[int] = mapped_column(Integer, nullable=False)
    state: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default=BatchQueueEntryState.QUEUED.value,
        index=True,
    )
    claimed_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )

    batch_task: Mapped[BatchTask] = relationship(
        "BatchTask", back_populates="queue_entry", foreign_keys=[batch_task_id]
    )


class DispatcherLease(Base):
    """Persistent ownership/fencing row for the batch dispatcher."""

    __tablename__ = "dispatcher_leases"
    __table_args__ = (
        CheckConstraint("fencing_token >= 0", name="ck_dispatcher_leases_fencing"),
        CheckConstraint("version >= 1", name="ck_dispatcher_leases_version"),
    )

    # There is one logical lease in the first release.  Keeping the key as the
    # primary key makes acquisition an atomic insert/update and allows future
    # deployments to add additional dispatcher keys without a schema change.
    key: Mapped[str] = mapped_column(
        String(100), primary_key=True, default="unittest-batch-dispatcher"
    )
    owner_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    heartbeat_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)
    fencing_token: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )

    __mapper_args__ = {"version_id_col": version}


# Compatibility aliases used by an earlier internal prototype.  They do not
# create additional tables and keep imports from old worker code harmless.
UnitTestBatchTask = BatchTask
UnitTestBatchItem = BatchItem


__all__ = [
    "BatchTaskStatus",
    "BatchItemStatus",
    "BatchQueueEntryState",
    "BatchTask",
    "BatchItem",
    "BatchQueueEntry",
    "DispatcherLease",
    "UnitTestBatchTask",
    "UnitTestBatchItem",
]
