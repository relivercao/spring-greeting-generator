"""Persistence model for user balance transactions.

A :class:`BalanceTransaction` is an append-only ledger row written
whenever a user's balance changes.  ``amount`` is a signed CNY value
(positive credit, negative debit) and ``balance_after`` is the resulting
balance snapshot, so the ledger can be audited without replaying it.
Token columns are only meaningful for ``usage`` rows.
"""

from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import DateTime, Float, ForeignKey, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


def _uuid4() -> str:
    """Generate the lowercase UUID v4 representation used by ledger IDs."""

    return str(uuid.uuid4())


class TransactionType:
    """Balance transaction categories."""

    RECHARGE = "recharge"        # Successful order fulfillment credit
    USAGE = "usage"              # LLM call deduction
    ADMIN_ADJUST = "admin_adjust"  # Manual admin correction
    SIGNUP_BONUS = "signup_bonus"  # Registration bonus
    PROMO_BONUS = "promo_bonus"  # Promotional code bonus
    REFUND = "refund"            # Refund deduction on a refunded order

    ALL: tuple[str, ...] = (
        RECHARGE,
        USAGE,
        ADMIN_ADJUST,
        SIGNUP_BONUS,
        PROMO_BONUS,
        REFUND,
    )


class BalanceTransaction(Base):
    """One append-only balance ledger entry for a user."""

    __tablename__ = "balance_transactions"
    __table_args__ = (
        Index(
            "ix_balance_transactions_user_created_at",
            "user_id",
            "created_at",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4)
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False, index=True
    )
    # Signed CNY amount: positive credits the balance, negative debits it.
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    balance_after: Mapped[float] = mapped_column(Float, nullable=False)
    type: Mapped[str] = mapped_column(String(30), nullable=False, index=True)
    # Order id, usage log id, redeem code, etc. depending on the type.
    reference_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # LLM usage details, only populated for type == "usage".
    model: Mapped[str | None] = mapped_column(String(100), nullable=True)
    prompt_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    completion_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )


__all__ = ["BalanceTransaction", "TransactionType"]
