"""
@file driver_agent.py
@brief Driver Agent ORM models for multi-turn conversations, tasks, tool results, and artifacts.

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
from datetime import datetime, timezone
from enum import Enum

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


DRIVER_AGENT_TYPE = "driver_agent"
DRIVER_TASK_TYPE = "driver_generation"
DRIVER_INITIAL_STEP = "analyze_request"
DEFAULT_DRIVER_MAX_RETRIES = 5
MAX_DRIVER_SESSION_TITLE_CHARS = 200
MAX_DRIVER_SOURCE_FILES = 50  # Increased from 20 to support larger projects
MAX_DRIVER_REPOSITORY_URL_CHARS = 2048
MAX_DRIVER_SELECTED_PATHS = 100


class DriverSessionStatus(str, Enum):
    ACTIVE = "active"


class DriverTaskStatus(str, Enum):
    CREATED = "created"
    RUNNING = "running"
    WAITING_USER = "waiting_user"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DriverSourceUploadStatus(str, Enum):
    UPLOADED = "uploaded"


class DriverSourceType(str, Enum):
    KNOWLEDGE_BASE = "knowledge_base"
    REFERENCE = "reference"


VALID_DRIVER_SOURCE_TYPES = {source_type.value for source_type in DriverSourceType}


class DriverSourceParseStatus(str, Enum):
    PENDING = "pending"
    PARSING = "parsing"
    SKIPPED = "skipped"
    PARSED = "parsed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DriverRepositoryFetchStatus(str, Enum):
    IDLE = "idle"
    FETCHING = "fetching"
    FETCHED = "fetched"
    FAILED = "failed"


class DriverAgentChatSession(Base):
    """Driver agent multi-turn conversation session."""
    __tablename__ = "driver_agent_chat_sessions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    title: Mapped[str | None] = mapped_column(String(MAX_DRIVER_SESSION_TITLE_CHARS), nullable=True)
    agent_type: Mapped[str] = mapped_column(String(30), nullable=False, default=DRIVER_AGENT_TYPE)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default=DriverSessionStatus.ACTIVE.value)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    messages: Mapped[list["DriverAgentChatMessage"]] = relationship(
        back_populates="session", cascade="all, delete-orphan"
    )
    tasks: Mapped[list["DriverAgentTask"]] = relationship(
        back_populates="session", cascade="all, delete-orphan"
    )


class DriverAgentChatMessage(Base):
    """Driver agent conversation message."""
    __tablename__ = "driver_agent_chat_messages"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("driver_agent_chat_sessions.id"), nullable=False, index=True
    )
    role: Mapped[str] = mapped_column(String(20), nullable=False)  # user / assistant / system
    content: Mapped[str] = mapped_column(Text, nullable=False)
    message_metadata: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    session: Mapped["DriverAgentChatSession"] = relationship(back_populates="messages")


class DriverAgentTask(Base):
    """Driver agent task state."""
    __tablename__ = "driver_agent_tasks"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("driver_agent_chat_sessions.id"), nullable=False, index=True
    )
    agent_type: Mapped[str] = mapped_column(String(30), nullable=False, default=DRIVER_AGENT_TYPE)
    task_type: Mapped[str] = mapped_column(String(30), nullable=False, default=DRIVER_TASK_TYPE)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default=DriverTaskStatus.CREATED.value)
    current_step: Mapped[str | None] = mapped_column(String(50), nullable=True)
    target_file: Mapped[str | None] = mapped_column(String(500), nullable=True)
    test_file: Mapped[str | None] = mapped_column(String(500), nullable=True)
    project_root: Mapped[str | None] = mapped_column(String(500), nullable=True)
    build_command: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_retries: Mapped[int] = mapped_column(Integer, nullable=False, default=DEFAULT_DRIVER_MAX_RETRIES)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    state_data: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    session: Mapped["DriverAgentChatSession"] = relationship(back_populates="tasks")
    tool_results: Mapped[list["DriverAgentToolResult"]] = relationship(
        back_populates="task", cascade="all, delete-orphan"
    )
    artifacts: Mapped[list["DriverAgentArtifact"]] = relationship(
        back_populates="task", cascade="all, delete-orphan"
    )


class DriverAgentToolResult(Base):
    """Driver agent tool execution result."""
    __tablename__ = "driver_agent_tool_results"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    task_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("driver_agent_tasks.id"), nullable=False, index=True
    )
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("driver_agent_chat_sessions.id"), nullable=False, index=True
    )
    tool_name: Mapped[str] = mapped_column(String(100), nullable=False)
    input_data: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    output_data: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    status: Mapped[str] = mapped_column(String(20), nullable=False)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    task: Mapped["DriverAgentTask"] = relationship(back_populates="tool_results")


class DriverAgentArtifact(Base):
    """Driver agent generated artifact."""
    __tablename__ = "driver_agent_artifacts"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    task_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("driver_agent_tasks.id"), nullable=False, index=True
    )
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("driver_agent_chat_sessions.id"), nullable=False, index=True
    )
    artifact_type: Mapped[str] = mapped_column(String(30), nullable=False)  # header/source/config/test/doc/log
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    path: Mapped[str] = mapped_column(Text, nullable=False)
    language: Mapped[str | None] = mapped_column(String(20), nullable=True)
    content: Mapped[str | None] = mapped_column(Text, nullable=True)
    size: Mapped[int | None] = mapped_column(Integer, nullable=True)
    content_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    task: Mapped["DriverAgentTask"] = relationship(back_populates="artifacts")


class DriverSource(Base):
    """Driver source file (knowledge base or reference upload)."""
    __tablename__ = "driver_sources"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    source_type: Mapped[str] = mapped_column(String(30), nullable=False)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    size: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    extension: Mapped[str] = mapped_column(String(20), nullable=False)
    mime_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    upload_status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=DriverSourceUploadStatus.UPLOADED.value
    )
    parse_status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=DriverSourceParseStatus.PENDING.value
    )
    saved_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    parsed_content: Mapped[str | None] = mapped_column(Text, nullable=True)  # extracted text
    parsed_summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    extra_metadata: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )


class DriverRepositorySource(Base):
    """Driver repository source (fetched git repo)."""
    __tablename__ = "driver_repository_sources"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    repository_url: Mapped[str] = mapped_column(String(MAX_DRIVER_REPOSITORY_URL_CHARS), nullable=False)
    branch: Mapped[str | None] = mapped_column(String(100), nullable=True)
    commit_sha: Mapped[str | None] = mapped_column(String(64), nullable=True)
    selected_paths: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON array
    fetch_status: Mapped[str] = mapped_column(
        String(20), nullable=False, default=DriverRepositoryFetchStatus.IDLE.value
    )
    workspace_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    file_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    included_files: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON array
    message: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
