"""Persistence model for invite and promotional codes.

One :class:`RedeemCode` table serves both registration flows:
``code_type`` distinguishes invitation codes (required when registration
is invite-only) from promotional codes (bonus credit at signup).
``used_count``/``max_uses`` gate multi-use promo codes via a conditional
UPDATE in the repository layer.
"""

from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


def _uuid4() -> str:
    """Generate the lowercase UUID v4 representation used by code IDs."""

    return str(uuid.uuid4())


class RedeemCodeType:
    """Redeem code categories."""

    INVITATION = "invitation"
    PROMO = "promo"

    ALL: tuple[str, ...] = (INVITATION, PROMO)


class RedeemCode(Base):
    """One invitation or promotional code."""

    __tablename__ = "redeem_codes"
    __table_args__ = (
        CheckConstraint(
            "code_type IN ('invitation', 'promo')",
            name="ck_redeem_codes_code_type",
        ),
        CheckConstraint("max_uses >= 1", name="ck_redeem_codes_max_uses"),
        CheckConstraint("used_count >= 0", name="ck_redeem_codes_used_count"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4)
    code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    code_type: Mapped[str] = mapped_column(
        String(20), nullable=False, default=RedeemCodeType.INVITATION
    )
    # CNY bonus credited when the code is consumed.
    bonus_amount: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    max_uses: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    used_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_by: Mapped[str | None] = mapped_column(String(36), nullable=True)
    # Snapshot of the most recent consumer (single-use invitation codes
    # only record one user; promo codes record the last one).
    used_by: Mapped[str | None] = mapped_column(String(36), nullable=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )


__all__ = ["RedeemCode", "RedeemCodeType"]
