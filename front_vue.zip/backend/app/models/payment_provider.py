"""Persistence model for configured payment provider instances.

A :class:`PaymentProviderInstance` stores one gateway credential set
(currently only the EasyPay ``easypay`` protocol).  ``config`` is a
JSON-encoded object holding the merchant credentials (``pid``, ``pkey``,
``apiBase``, notify/return URLs, channel IDs, payment mode and custom
method mapping).  The config is plaintext in the database, so every read
path exposed over HTTP must mask ``pkey`` before returning it.
"""

from __future__ import annotations

from datetime import datetime, timezone
import uuid

from sqlalchemy import Boolean, DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    """Return a timezone-aware UTC timestamp for ORM defaults."""

    return datetime.now(timezone.utc)


def _uuid4() -> str:
    """Generate the lowercase UUID v4 representation used by instance IDs."""

    return str(uuid.uuid4())


class PaymentProviderInstance(Base):
    """One configured payment gateway credential set."""

    __tablename__ = "payment_provider_instances"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    # Protocol identifier; the first release only ships "easypay".
    provider_key: Mapped[str] = mapped_column(
        String(50), nullable=False, default="easypay"
    )
    is_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # JSON-encoded merchant config.  Contains the pkey secret: never expose
    # this column verbatim through the admin API.
    config: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    remark: Mapped[str | None] = mapped_column(String(255), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )


__all__ = ["PaymentProviderInstance"]
