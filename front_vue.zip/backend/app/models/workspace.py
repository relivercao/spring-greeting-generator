"""Persistent project-workspace leases shared by Unit-Test workers.

The ordinary Unit-Test endpoint and the batch dispatcher may run in different
application processes.  A process-local ``asyncio`` map is useful as a fast
path, but it cannot prevent two workers from writing the same project at the
same time.  This small table is the durable coordination boundary.  A row is
owned by one Task/child id at a time and is removed when that owner reaches a
terminal state.

``pending`` rows cover the short request/Task-creation window.  They carry an
expiry so a process which dies before inserting its Task cannot strand a
workspace forever.  Active rows are reclaimed only after the owner Task is
observed terminal (or an explicit release), rather than by a wall-clock lease
expiry; long-running Unit-Test jobs therefore cannot be stolen merely because
they outlive a heartbeat interval.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import CheckConstraint, DateTime, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class WorkspaceLease(Base):
    """One durable mutual-exclusion row per normalized project root."""

    __tablename__ = "workspace_leases"
    __table_args__ = (
        CheckConstraint(
            "state IN ('pending', 'active')",
            name="ck_workspace_leases_state",
        ),
        CheckConstraint(
            "fencing_token >= 0",
            name="ck_workspace_leases_fencing",
        ),
        Index("ix_workspace_leases_owner_id", "owner_id"),
    )

    # Windows paths can be long (and future deployments may use URI-like
    # workspace identifiers), so leave room beyond the current 255-char path
    # convention.  SQLite does not enforce String length, while PostgreSQL
    # still receives a bounded, indexable key.
    key: Mapped[str] = mapped_column(String(2048), primary_key=True)
    owner_id: Mapped[str] = mapped_column(String(255), nullable=False)
    state: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending"
    )
    fencing_token: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    pending_until: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True, index=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=_utcnow, onupdate=_utcnow
    )


__all__ = ["WorkspaceLease"]
