"""Persistent FIFO dispatcher for Batch Unit-Test work.

The dispatcher is deliberately independent from FastAPI.  HTTP handlers only
create/query rows and signal :meth:`wake`; this service owns the short
database transactions which claim a batch, create one child Task, and fold the
child result back into ``BatchItem``/``BatchTask``.

The first deployment uses SQLite.  A ``BEGIN IMMEDIATE`` is therefore used for
claim and lease transactions so two application processes cannot observe the
same queue head.  The public class also accepts injected session/runner
factories, which keeps the state machine unit-testable and leaves the runner
implementation (and its AWS/CLI dependencies) outside this module.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from contextlib import suppress
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import inspect
import json
import logging
import os
import socket
import uuid
from typing import Any

from sqlalchemy import func, select, text, update
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.batch_contract import (
    BATCH_ITEM_ERROR_CODES,
    BATCH_TERMINAL_REASONS,
    BatchItemStatus,
    BatchTaskStatus,
    CHILD_STATUS_TO_ITEM_STATUS,
)
from app.core.config import (
    DEFAULT_BATCH_AUTH_BLOCK_TIMEOUT_SECONDS,
    DEFAULT_BATCH_CHILD_TIMEOUT_SECONDS,
    DEFAULT_BATCH_DISPATCHER_HEARTBEAT_SECONDS,
    DEFAULT_BATCH_DISPATCHER_LEASE_SECONDS,
    DEFAULT_BATCH_DISPATCHER_POLL_INTERVAL_SECONDS,
)
from app.models.batch import (
    BatchItem,
    BatchQueueEntry,
    BatchQueueEntryState,
    BatchTask,
    DispatcherLease,
)
from app.models.task import Task
from app.services.batch_input_store import BatchInputStore, SnapshotInvalidError
from app.services.unittest_runner import (
    UnitTestInput,
    UnitTestRunner,
    WorkspaceLeaseManager,
)


logger = logging.getLogger(__name__)


SessionFactory = Callable[[], Any]
"""Callable returning an async-session context manager.

``async_sessionmaker`` is intentionally not imported in the type alias.  The
application and tests use both SQLAlchemy's factory and small fake factories;
runtime duck typing is more useful here than an overly narrow annotation.
"""


RunChild = Callable[..., Any]
CancelChild = Callable[[str], Any]
ResumeChild = Callable[..., Any]


@dataclass(frozen=True, slots=True)
class BatchCounts:
    """Canonical aggregate used by the dispatcher and HTTP DTO builders."""

    total: int = 0
    queued: int = 0
    running: int = 0
    passed: int = 0
    failed: int = 0

    @property
    def pass_count(self) -> int:
        """Compatibility spelling for callers that avoid the keyword ``pass``."""

        return self.passed

    @property
    def fail_count(self) -> int:
        return self.failed

    def as_dict(self) -> dict[str, int]:
        # ``pass``/``fail`` are the frozen wire names.  Do not expose a second
        # ``completed`` count which can drift from the two terminal counts.
        return {
            "total": self.total,
            "queued": self.queued,
            "running": self.running,
            "pass": self.passed,
            "fail": self.failed,
        }


@dataclass(frozen=True, slots=True)
class BatchClaim:
    """Immutable result of one successful FIFO claim."""

    batch_task_id: str
    queue_entry_id: str
    queue_seq: int
    project_root: str
    user_id: str
    fencing_token: int

    # A few names used by early dispatcher prototypes are kept as read-only
    # aliases; they do not add fields to the API response.
    @property
    def task_id(self) -> str:
        return self.batch_task_id

    @property
    def batch_id(self) -> str:
        return self.batch_task_id


@dataclass(frozen=True, slots=True)
class BatchDispatchOutcome:
    """Result returned by :meth:`run_once` for diagnostics and tests."""

    claim: BatchClaim | None
    completed: bool = False
    blocked: bool = False

    @property
    def batch_task_id(self) -> str | None:
        return self.claim.batch_task_id if self.claim else None


@dataclass(frozen=True, slots=True)
class ChildResult:
    """Small adapter value accepted by injected child runners/tests.

    Production runners normally persist the ordinary ``Task`` row and return
    no value; this shape is useful for deterministic integrations which return
    the projected child status directly.  The dispatcher also accepts mappings
    and ordinary ``Task`` objects, so this is purely a compatibility helper.
    """

    status: str
    progress: int = 100
    message: str | None = None
    result_summary: Mapping[str, Any] | None = None
    error_code: str | None = None
    error_message: str | None = None
    terminal_reason: str | None = None
    blocked_reason: str | None = None
    resume_required: bool = False


class DispatcherLeaseLost(RuntimeError):
    """Raised internally when a worker no longer owns the dispatcher lease."""


class BatchQueueDispatcher:
    """One logical FIFO worker for persisted BatchTask rows.

    Parameters are intentionally injectable.  In production ``session_factory``
    is ``app.core.database.async_session_factory`` and ``input_store`` is the
    configured :class:`~app.services.batch_input_store.BatchInputStore`.
    ``run_child`` may be supplied by the endpoint/runner integration and is
    called *after* the child Task transaction commits.  Its preferred shape is
    ``run_child(batch, item, unit_test_input)``; one-argument forms accepting
    only ``UnitTestInput`` are accepted as a convenience for tests.
    """

    LEASE_KEY = "unittest-batch-dispatcher"

    def __init__(
        self,
        session_factory: SessionFactory,
        input_store: BatchInputStore | None = None,
        *,
        runner: UnitTestRunner | Any | None = None,
        run_child: RunChild | None = None,
        child_starter: RunChild | None = None,
        cancel_child: CancelChild | None = None,
        resume_child: ResumeChild | None = None,
        workspace_manager: WorkspaceLeaseManager | None = None,
        workspace_owner_is_dead: Callable[[str], bool] | None = None,
        # ``takeover_guard`` is intentionally separate from the workspace
        # liveness callback.  A dispatcher lease may expire while the old
        # worker's external CLI/QBS process is still alive; callers that can
        # observe worker processes should return ``True`` only after that
        # owner is known to be gone.  Keep the two historical spellings as
        # aliases so older integrations do not silently lose the guard.
        takeover_guard: Callable[[str], Any] | None = None,
        worker_owner_is_dead: Callable[[str], Any] | None = None,
        worker_id: str | None = None,
        settings: Any | None = None,
        lease_seconds: float | None = None,
        heartbeat_seconds: float | None = None,
        poll_interval_seconds: float | None = None,
        child_timeout_seconds: float | None = None,
        # Progress is normally held in the legacy endpoint's in-memory
        # registry.  A provider is optional so the dispatcher remains usable
        # in isolated tests and non-FastAPI hosts.
        progress_provider: Callable[[str], Any] | None = None,
        child_progress_provider: Callable[[str], Any] | None = None,
        now_factory: Callable[[], datetime] | None = None,
    ) -> None:
        self.session_factory = session_factory
        self.input_store = input_store or BatchInputStore()
        self.runner = runner or UnitTestRunner()
        # ``child_starter`` was the name used by the first Stage 3 adapter;
        # retain it as an alias while keeping ``run_child`` as the documented
        # production hook.
        self.run_child = run_child or child_starter
        self.cancel_child = cancel_child
        self.resume_child = resume_child
        self.workspace_manager = workspace_manager
        self.workspace_owner_is_dead = workspace_owner_is_dead
        self.takeover_guard = takeover_guard or worker_owner_is_dead
        self.worker_id = worker_id or self._default_worker_id()
        self.progress_provider = progress_provider or child_progress_provider

        if settings is None:
            # Import lazily so isolated repository/model tests do not need to
            # construct the application's full settings object.
            try:
                from app.core.config import get_settings

                settings = get_settings()
            except Exception:  # pragma: no cover - defensive import fallback
                settings = None

        self.lease_seconds = max(
            1.0,
            float(
                lease_seconds
                if lease_seconds is not None
                else getattr(
                    settings,
                    "BATCH_DISPATCHER_LEASE_SECONDS",
                    DEFAULT_BATCH_DISPATCHER_LEASE_SECONDS,
                )
            ),
        )
        self.heartbeat_seconds = max(
            0.05,
            float(
                heartbeat_seconds
                if heartbeat_seconds is not None
                else getattr(
                    settings,
                    "BATCH_DISPATCHER_HEARTBEAT_SECONDS",
                    DEFAULT_BATCH_DISPATCHER_HEARTBEAT_SECONDS,
                )
            ),
        )
        self.poll_interval_seconds = max(
            0.01,
            float(
                poll_interval_seconds
                if poll_interval_seconds is not None
                else getattr(
                    settings,
                    "BATCH_DISPATCHER_POLL_INTERVAL_SECONDS",
                    DEFAULT_BATCH_DISPATCHER_POLL_INTERVAL_SECONDS,
                )
            ),
        )
        self.auth_block_timeout_seconds = max(
            1.0,
            float(
                getattr(
                    settings,
                    "BATCH_AUTH_BLOCK_TIMEOUT_SECONDS",
                    DEFAULT_BATCH_AUTH_BLOCK_TIMEOUT_SECONDS,
                )
            ),
        )
        # A child that remains pending/running/unknown must not hold the FIFO
        # head forever.  The timeout is deliberately injectable for tests and
        # deployments with different runner SLAs.  Keep the fallback local to
        # the dispatcher so older Settings objects remain compatible.
        self.child_timeout_seconds = max(
            1.0,
            float(
                child_timeout_seconds
                if child_timeout_seconds is not None
                else getattr(
                    settings,
                    "BATCH_CHILD_TIMEOUT_SECONDS",
                    DEFAULT_BATCH_CHILD_TIMEOUT_SECONDS,
                )
            ),
        )
        self.resume_enabled = bool(getattr(settings, "BATCH_RESUME_ENABLED", False))
        self._now_factory = now_factory or (lambda: datetime.now(timezone.utc))

        self._lease_token: int | None = None
        self._lease_held = False
        self._stop_event = asyncio.Event()
        self._wake_event = asyncio.Event()
        self._loop_task: asyncio.Task[Any] | None = None
        self._heartbeat_task: asyncio.Task[Any] | None = None
        self._active_child_ids: set[str] = set()
        # A pending child can survive a process/lease hand-off.  Once this
        # worker has handed it to the external runner, remember that fact even
        # when the callback returns before the Task row becomes ``running``.
        # This prevents every poll from starting a second external process.
        self._started_child_ids: set[str] = set()
        # Detached child-cancel tasks forwarded by the progress watcher.  A
        # strong reference keeps them alive after the watcher itself returns.
        self._child_cancel_tasks: set[asyncio.Task[Any]] = set()
        self._active_batch_id: str | None = None
        self._active_item_id: str | None = None
        # A claimed queue entry remains owned by this worker while an Item is
        # waiting for authentication.  Keeping the immutable claim here lets
        # subsequent poll iterations resume that same batch instead of trying
        # to claim a second entry (the DB correctly reports one claimed row).
        self._claimed_claim: BatchClaim | None = None

    # ------------------------------------------------------------------
    # Public lifecycle / lease API
    # ------------------------------------------------------------------

    @property
    def fencing_token(self) -> int | None:
        return self._lease_token

    @property
    def lease_held(self) -> bool:
        return self._lease_held

    @property
    def active_batch_id(self) -> str | None:
        return self._active_batch_id

    @property
    def active_item_id(self) -> str | None:
        return self._active_item_id

    async def acquire_lease(self) -> bool:
        """Acquire or renew this worker's persistent lease.

        A takeover increments ``fencing_token``.  A worker which still has an
        old token can therefore never pass the conditional ownership checks in
        claim/heartbeat/update transactions.
        """

        now = self._db_now()
        expiry = now + timedelta(seconds=self.lease_seconds)
        for attempt in range(2):
            try:
                async with self.session_factory() as session:
                    await self._begin_write(session)
                    row = await session.scalar(
                        select(DispatcherLease).where(
                            DispatcherLease.key == self.LEASE_KEY
                        )
                    )
                    if row is not None:
                        row_expiry = self._as_naive_utc(row.expires_at)
                        active_other = (
                            row.owner_id != self.worker_id
                            and row_expiry is not None
                            and row_expiry > now
                        )
                        if active_other:
                            await session.rollback()
                            self._lease_held = False
                            return False

                        previous_owner = row.owner_id
                        previous_token = int(row.fencing_token or 0)
                        row.owner_id = self.worker_id
                        row.heartbeat_at = now
                        row.expires_at = expiry
                        if previous_owner != self.worker_id or (
                            row_expiry is not None and row_expiry <= now
                        ):
                            row.fencing_token = previous_token + 1
                        token = int(row.fencing_token or 0)
                    else:
                        token = 1
                        session.add(
                            DispatcherLease(
                                key=self.LEASE_KEY,
                                owner_id=self.worker_id,
                                heartbeat_at=now,
                                expires_at=expiry,
                                fencing_token=token,
                                version=1,
                            )
                        )

                    await session.flush()
                    await session.commit()
                    self._lease_token = token
                    self._lease_held = True
                    return True
            except IntegrityError:
                # Two fresh workers can race on the initial INSERT.  The
                # SQLite write lock normally serializes this; one retry makes
                # the behavior deterministic on other test backends too.
                if attempt == 0:
                    await asyncio.sleep(0)
                    continue
                self._lease_held = False
                return False
            except Exception:
                self._lease_held = False
                logger.exception("Failed to acquire batch dispatcher lease")
                return False
        return False

    async def renew_lease(self) -> bool:
        """Heartbeat the lease if this worker still owns its fencing token."""

        token = self._lease_token
        if not self._lease_held or token is None:
            return False
        now = self._db_now()
        expiry = now + timedelta(seconds=self.lease_seconds)
        try:
            async with self.session_factory() as session:
                await self._begin_write(session)
                row = await session.scalar(
                    select(DispatcherLease).where(
                        DispatcherLease.key == self.LEASE_KEY,
                        DispatcherLease.owner_id == self.worker_id,
                        DispatcherLease.fencing_token == token,
                    )
                )
                if row is None or (
                    self._as_naive_utc(row.expires_at) is not None
                    and self._as_naive_utc(row.expires_at) < now
                ):
                    await session.rollback()
                    self._lease_held = False
                    return False
                row.heartbeat_at = now
                row.expires_at = expiry
                await session.flush()
                await session.commit()
                return True
        except Exception:
            self._lease_held = False
            logger.exception("Failed to renew batch dispatcher lease")
            return False

    async def release_lease(self) -> bool:
        """Expire this worker's lease without deleting its fencing history."""

        token = self._lease_token
        if token is None:
            self._lease_held = False
            return False
        now = self._db_now()
        released = False
        try:
            async with self.session_factory() as session:
                await self._begin_write(session)
                row = await session.scalar(
                    select(DispatcherLease).where(
                        DispatcherLease.key == self.LEASE_KEY,
                        DispatcherLease.owner_id == self.worker_id,
                        DispatcherLease.fencing_token == token,
                    )
                )
                if row is not None:
                    row.heartbeat_at = now
                    row.expires_at = now
                    await session.flush()
                    await session.commit()
                    released = True
                else:
                    await session.rollback()
        except Exception:
            logger.exception("Failed to release batch dispatcher lease")
        finally:
            self._lease_held = False
            self._lease_token = None
        return released

    async def start(self) -> bool:
        """Start the worker, remaining on standby when another lease is active."""

        if self._loop_task is not None and not self._loop_task.done():
            return self._lease_held
        self._stop_event.clear()
        acquired = await self.acquire_lease()
        if acquired:
            self._start_heartbeat()
        self._loop_task = asyncio.create_task(
            self._dispatch_loop(), name=f"batch-dispatcher:{self.worker_id}"
        )
        self._wake_event.set()
        return acquired

    async def stop(self) -> None:
        """Stop background loops and release the lease."""

        self._stop_event.set()
        self._wake_event.set()
        for task in (self._loop_task, self._heartbeat_task):
            if task is not None and not task.done():
                task.cancel()
        for task in (self._loop_task, self._heartbeat_task):
            if task is not None:
                with suppress(asyncio.CancelledError, Exception):
                    await task
        self._loop_task = None
        self._heartbeat_task = None
        self._claimed_claim = None
        await self.release_lease()

    async def run_forever(self) -> None:
        """Convenience coroutine for hosts which own task creation themselves."""

        if not self._lease_held and not await self.acquire_lease():
            return
        self._stop_event.clear()
        heartbeat = asyncio.create_task(self._heartbeat_loop())
        try:
            await self._dispatch_loop()
        finally:
            heartbeat.cancel()
            with suppress(asyncio.CancelledError):
                await heartbeat
            await self.release_lease()

    def wake(self) -> None:
        """Wake a running dispatcher after a new queue row is committed."""

        self._wake_event.set()

    def _start_heartbeat(self) -> None:
        if self._heartbeat_task is None or self._heartbeat_task.done():
            self._heartbeat_task = asyncio.create_task(
                self._heartbeat_loop(), name=f"batch-heartbeat:{self.worker_id}"
            )

    # ------------------------------------------------------------------
    # FIFO claim
    # ------------------------------------------------------------------

    async def claim_next(self) -> BatchClaim | None:
        """Atomically claim the oldest eligible queued BatchTask.

        No external work or file I/O occurs inside this transaction.  The
        caller receives an immutable claim only after the ``queued -> claimed``
        and ``BatchTask queued -> running`` updates have committed.
        """

        if not await self._lease_is_current():
            return None
        token = self._lease_token
        assert token is not None  # guarded by _lease_is_current
        now = self._db_now()
        try:
            async with self.session_factory() as session:
                await self._begin_write(session)
                if not await self._session_lease_is_current(session, token, now):
                    await session.rollback()
                    self._lease_held = False
                    return None

                # A claimed row is the durable queue head.  A successor lease
                # owner must adopt it instead of waiting forever or creating a
                # second child.  Fencing on every later write prevents the old
                # owner from advancing the same batch after takeover.
                entry = await session.scalar(
                    select(BatchQueueEntry)
                    .join(BatchTask, BatchTask.id == BatchQueueEntry.batch_task_id)
                    .where(
                        BatchQueueEntry.state == BatchQueueEntryState.CLAIMED.value,
                        BatchTask.status == BatchTaskStatus.RUNNING.value,
                    )
                    .order_by(BatchQueueEntry.queue_seq.asc())
                    .limit(1)
                )
                if entry is not None:
                    batch = await session.scalar(
                        select(BatchTask).where(BatchTask.id == entry.batch_task_id)
                    )
                    if batch is None:
                        await session.rollback()
                        return None

                    # A persisted claimed row is recoverable only after the
                    # previous worker's external process is known to be dead.
                    # The first release had no process-observer hook, so keep
                    # the historical permissive behavior when no guard is
                    # supplied; production wiring can (and should) inject it.
                    previous_owner = entry.claimed_by
                    if (
                        previous_owner
                        and previous_owner != self.worker_id
                        and self.takeover_guard is not None
                    ):
                        allowed = await self._owner_takeover_allowed(previous_owner)
                        if not allowed:
                            await session.rollback()
                            return None
                        # The guard may involve an external process lookup and
                        # therefore time may have elapsed.  Re-read the row so
                        # a concurrent claimant cannot be overwritten based on
                        # the stale owner observed above.
                        latest = await session.scalar(
                            select(BatchQueueEntry).where(
                                BatchQueueEntry.id == entry.id,
                                BatchQueueEntry.state
                                == BatchQueueEntryState.CLAIMED.value,
                            )
                        )
                        if latest is None or latest.claimed_by != previous_owner:
                            await session.rollback()
                            return None
                        entry = latest
                    entry.claimed_by = self.worker_id
                    entry.claimed_at = now
                    entry.updated_at = now
                    await session.flush()
                    await session.commit()
                    return BatchClaim(
                        batch_task_id=batch.id,
                        queue_entry_id=entry.id,
                        queue_seq=int(entry.queue_seq),
                        project_root=batch.project_root,
                        user_id=batch.user_id,
                        fencing_token=token,
                    )

                # A running row without a claimed queue entry is inconsistent
                # and must remain a global barrier.  Startup reconciliation can
                # repair its Item state without allowing a later batch to pass.
                running_exists = await session.scalar(
                    select(func.count())
                    .select_from(BatchTask)
                    .where(BatchTask.status == BatchTaskStatus.RUNNING.value)
                )
                if int(running_exists or 0):
                    await session.rollback()
                    return None

                stmt = (
                    select(BatchQueueEntry)
                    .join(BatchTask, BatchTask.id == BatchQueueEntry.batch_task_id)
                    .where(
                        BatchQueueEntry.state == BatchQueueEntryState.QUEUED.value,
                        BatchTask.status == BatchTaskStatus.QUEUED.value,
                    )
                    .order_by(BatchQueueEntry.queue_seq.asc())
                    .limit(1)
                )
                entry = await session.scalar(stmt)
                if entry is None:
                    await session.rollback()
                    return None
                batch = await session.scalar(
                    select(BatchTask).where(BatchTask.id == entry.batch_task_id)
                )
                if batch is None:
                    # Foreign keys normally make this impossible.  Do not
                    # consume a corrupt queue row if an old database disabled
                    # FK enforcement.
                    await session.rollback()
                    return None

                entry.state = BatchQueueEntryState.CLAIMED.value
                entry.claimed_by = self.worker_id
                entry.claimed_at = now
                batch.status = BatchTaskStatus.RUNNING.value
                batch.started_at = batch.started_at or now
                batch.updated_at = now
                await session.flush()
                await session.commit()
                return BatchClaim(
                    batch_task_id=batch.id,
                    queue_entry_id=entry.id,
                    queue_seq=int(entry.queue_seq),
                    project_root=batch.project_root,
                    user_id=batch.user_id,
                    fencing_token=token,
                )
        except Exception:
            logger.exception("Failed to claim next batch")
            return None

    # Compatibility aliases used by early integration branches.
    claim_batch = claim_next
    claim = claim_next
    claim_next_batch = claim_next

    async def run_once(self) -> BatchDispatchOutcome:
        """Claim and process at most one batch, then return its outcome."""

        if not self._lease_held and not await self.acquire_lease():
            return BatchDispatchOutcome(None)
        claim = self._claimed_claim
        if (
            claim is None
            or claim.fencing_token != self._lease_token
            or not await self._lease_is_current()
        ):
            self._claimed_claim = None
            claim = await self.claim_next()
        if claim is None:
            return BatchDispatchOutcome(None)
        self._claimed_claim = claim

        self._active_batch_id = claim.batch_task_id
        blocked = False
        completed = False
        try:
            blocked = await self._process_batch(claim)
            completed = not blocked and await self._batch_is_done(claim.batch_task_id)
        except DispatcherLeaseLost:
            # Never write with an old fencing token.  The successor worker can
            # reconcile the claimed row after the old process is gone.
            logger.warning(
                "Batch dispatcher lease lost while processing %s",
                claim.batch_task_id,
            )
            self._claimed_claim = None
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Unhandled batch dispatcher failure for %s", claim.batch_task_id)
            with suppress(Exception):
                await self._fail_batch_safely(
                    claim.batch_task_id,
                    reason="RUNNER_FAILED",
                    message="Batch dispatcher failed unexpectedly",
                )
        finally:
            self._active_batch_id = None
            self._active_item_id = None
            if completed:
                self._claimed_claim = None
        return BatchDispatchOutcome(claim, completed=completed, blocked=blocked)

    # ------------------------------------------------------------------
    # Batch/item execution
    # ------------------------------------------------------------------

    async def _process_batch(self, claim: BatchClaim) -> bool:
        """Process items in sequence order; return whether auth-blocked."""

        while True:
            await self._require_current_lease()
            batch, item = await self._next_item(claim.batch_task_id)
            if batch is None:
                return False

            if batch.cancel_requested:
                await self._cancel_batch_rows(claim)
                return False
            if item is None:
                await self._complete_batch_if_ready(claim)
                return False

            self._active_item_id = item.id
            if item.status == BatchItemStatus.RUNNING.value:
                outcome = await self._process_running_item(claim, item)
            else:
                outcome = await self._process_item(claim, batch, item)
            self._active_item_id = None
            if outcome == "blocked":
                return True
            if outcome == "pending":
                return False
            # ``pass``, ``fail`` and a snapshot failure all continue to the
            # next sequence.  Re-read rows every iteration so external cancel
            # requests and optimistic updates are observed promptly.

    async def _process_running_item(
        self,
        claim: BatchClaim,
        item: BatchItem,
    ) -> str:
        """Observe an already-linked child without ever starting it twice."""

        child_id = item.unittest_task_id
        if not child_id:
            await self._finish_item(
                claim,
                item.id,
                status=BatchItemStatus.FAIL.value,
                terminal_reason="CHILD_STATUS_UNKNOWN",
                error_code="CHILD_STATUS_UNKNOWN",
                error_message="Running BatchItem has no linked child Task",
                result_summary=None,
            )
            return "fail"

        result = await self._read_child_result(child_id)
        state = self._result_state(result)
        if state in {"completed", "failed", "cancelled"}:
            outcome = await self._project_child_result(
                claim, item.id, child_id, result
            )
            await self._release_child(child_id)
            return outcome

        if item.resume_required:
            blocked_at = self._as_naive_utc(item.updated_at or item.started_at)
            if blocked_at is None:
                blocked_at = self._db_now()
            if self._db_now() - blocked_at >= timedelta(
                seconds=self.auth_block_timeout_seconds
            ):
                if not await self._cancel_child(child_id, allow_local=True):
                    # A failed cancellation must not clear the resumable
                    # marker or make the batch appear complete while the
                    # child may still be writing.  Keep polling/retrying.
                    return "blocked"
                after_cancel = await self._read_child_result(child_id)
                after_state = self._result_state(after_cancel)
                if after_state in {"completed", "failed"}:
                    # Completion/failure that won the cancellation race is
                    # authoritative; do not overwrite it with an auth timeout.
                    outcome = await self._project_child_result(
                        claim, item.id, child_id, after_cancel
                    )
                    await self._release_child(child_id)
                    return outcome
                await self._finish_item(
                    claim,
                    item.id,
                    status=BatchItemStatus.FAIL.value,
                    terminal_reason="AUTH_BLOCK_TIMEOUT",
                    error_code="AUTH_BLOCK_TIMEOUT",
                    error_message="Authentication block timed out",
                    result_summary=None,
                )
                await self._release_child(child_id)
                return "fail"
            return "blocked"

        if state == "paused":
            outcome = await self._project_child_result(
                claim, item.id, child_id, result
            )
            # The ordinary Unit-Test endpoint releases the workspace while an
            # auth-paused task waits for resume.  Resume reserves the same
            # project again before changing Task back to running.
            await self._release_child(child_id)
            return outcome

        # A child link is committed before the external runner is invoked.  If
        # the process dies in that small window, a successor worker must reuse
        # the pending child instead of creating a second Task.  Running children
        # are only observed (their external process may still be alive); a
        # pending child is safe to hand to the normal callback once.
        if state == "pending":
            if await self._child_timed_out(item):
                if not await self._cancel_child(child_id, allow_local=True):
                    # Keep the Item running and the batch head claimed until
                    # the external child is actually stopped.  The persisted
                    # cancellation/timeout condition is retried on the next
                    # poll instead of publishing a false terminal state.
                    return "pending"
                after_cancel = await self._read_child_result(child_id)
                after_state = self._result_state(after_cancel)
                if after_state in {"completed", "failed"}:
                    outcome = await self._project_child_result(
                        claim, item.id, child_id, after_cancel
                    )
                    await self._release_child(child_id)
                    return outcome
                await self._mark_child_cancelled_if_active(child_id)
                await self._finish_item(
                    claim,
                    item.id,
                    status=BatchItemStatus.FAIL.value,
                    terminal_reason="CHILD_STATUS_UNKNOWN",
                    error_code="CHILD_STATUS_UNKNOWN",
                    error_message="Child remained pending until execution timeout",
                    result_summary=None,
                )
                await self._release_child(child_id)
                return "fail"
            # A callback which returned before changing the ordinary Task row
            # may leave this child in ``pending`` for several polls.  Reusing
            # the same child is safe; invoking the external starter repeatedly
            # is not.  A fresh dispatcher instance has an empty set and can
            # perform the documented lease-takeover hand-off once.
            if child_id in self._started_child_ids:
                await self._sync_item_progress(
                    claim.batch_task_id, item.id, child_id
                )
                return "pending"
            workspace_reserved = False
            keep_workspace = False
            try:
                content = self.input_store.read_snapshot(
                    item,
                    expected_hash=item.content_hash,
                )
                batch, _ = await self._next_item(claim.batch_task_id)
                if batch is None:
                    return "pending"
                if self.workspace_manager is not None:
                    workspace_reserved = await self._wait_for_workspace(
                        child_id,
                        batch.project_root,
                        claim.batch_task_id,
                    )
                    if not workspace_reserved:
                        if not await self._cancel_child(child_id, allow_local=True):
                            return "pending"
                        after_cancel = await self._read_child_result(child_id)
                        after_state = self._result_state(after_cancel)
                        if after_state in {"completed", "failed"}:
                            outcome = await self._project_child_result(
                                claim, item.id, child_id, after_cancel
                            )
                            await self._release_child(child_id)
                            return outcome
                        await self._mark_child_cancelled_if_active(child_id)
                        await self._finish_item(
                            claim,
                            item.id,
                            status=BatchItemStatus.FAIL.value,
                            terminal_reason="CANCELLED",
                            error_code="CANCELLED",
                            error_message="Batch was cancelled before the item resumed",
                            result_summary=None,
                        )
                        await self._release_child(child_id)
                        return "fail"
                    # The child Task already exists on this recovery path, so
                    # only now is it safe to convert the bounded pending
                    # reservation into an active workspace lease.
                    self.workspace_manager.mark_active(child_id)
                    keep_workspace = True
                unit_input = self._build_unit_test_input(
                    batch, item, child_id, content
                )
                self._started_child_ids.add(child_id)
                self._active_child_ids.add(child_id)
                try:
                    await self._run_child_with_progress(
                        batch,
                        item,
                        unit_input,
                        child_id,
                    )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    # A callback exception does not prove the external child
                    # stopped.  Persisted Task state remains authoritative;
                    # retain the workspace and observe it on the next poll.
                    logger.exception("Batch child callback failed for %s", child_id)
                finally:
                    self._active_child_ids.discard(child_id)
                persisted = await self._read_child_result(child_id)
                persisted_state = self._result_state(persisted)
                if persisted_state in {
                    "completed",
                    "failed",
                    "cancelled",
                    "paused",
                }:
                    projected = await self._project_child_result(
                        claim, item.id, child_id, persisted
                    )
                    keep_workspace = False
                    # The helper owns this terminal release; do not repeat it
                    # in the enclosing workspace-reservation ``finally``.
                    workspace_reserved = False
                    await self._release_child(child_id)
                    return projected
                # The callback may have scheduled work and returned before the
                # Task row changed state.  Callback payloads must not advance
                # a still-pending/running persisted Task.  Leave the Item and
                # workspace active for the next observation/timeout pass.
                return "pending"
            except (SnapshotInvalidError, OSError, ValueError, TypeError) as exc:
                await self._finish_item(
                    claim,
                    item.id,
                    status=BatchItemStatus.FAIL.value,
                    terminal_reason="SNAPSHOT_INVALID",
                    error_code="SNAPSHOT_INVALID",
                    error_message=str(exc)[:2000],
                    result_summary=None,
                )
                return "fail"
            except DispatcherLeaseLost:
                raise
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await self._finish_item(
                    claim,
                    item.id,
                    status=BatchItemStatus.FAIL.value,
                    terminal_reason="RUNNER_FAILED",
                    error_code="RUNNER_FAILED",
                    error_message=str(exc)[:2000],
                    result_summary=None,
                )
                return "fail"
            finally:
                if (
                    workspace_reserved
                    and not keep_workspace
                    and self.workspace_manager is not None
                ):
                    await self.workspace_manager.release(child_id)

        if state == "running":
            if await self._child_timed_out(item):
                if not await self._cancel_child(child_id, allow_local=True):
                    return "pending"
                after_cancel = await self._read_child_result(child_id)
                after_state = self._result_state(after_cancel)
                if after_state in {"completed", "failed"}:
                    outcome = await self._project_child_result(
                        claim, item.id, child_id, after_cancel
                    )
                    await self._release_child(child_id)
                    return outcome
                await self._mark_child_cancelled_if_active(child_id)
                await self._finish_item(
                    claim,
                    item.id,
                    status=BatchItemStatus.FAIL.value,
                    terminal_reason="CHILD_STATUS_UNKNOWN",
                    error_code="CHILD_STATUS_UNKNOWN",
                    error_message="Child remained running until execution timeout",
                    result_summary=None,
                )
                await self._release_child(child_id)
                return "fail"
            return "pending"

        # Unknown states are not terminal merely because they are unfamiliar to
        # this version of the dispatcher.  Keep monitoring for the configured
        # window, then fail deterministically so a corrupt child cannot stall
        # the FIFO forever.
        if await self._child_timed_out(item):
            if not await self._cancel_child(child_id, allow_local=True):
                return "pending"
            after_cancel = await self._read_child_result(child_id)
            after_state = self._result_state(after_cancel)
            if after_state in {"completed", "failed"}:
                outcome = await self._project_child_result(
                    claim, item.id, child_id, after_cancel
                )
                await self._release_child(child_id)
                return outcome
            await self._mark_child_cancelled_if_active(child_id)
            await self._finish_item(
                claim,
                item.id,
                status=BatchItemStatus.FAIL.value,
                terminal_reason="CHILD_STATUS_UNKNOWN",
                error_code="CHILD_STATUS_UNKNOWN",
                error_message="Unknown child state reached execution timeout",
                result_summary=None,
            )
            await self._release_child(child_id)
            return "fail"
        return "pending"

    async def _child_timed_out(self, item: BatchItem) -> bool:
        """Return whether a non-terminal child exceeded its monitoring SLA."""

        started = self._as_naive_utc(item.started_at or item.updated_at)
        if started is None:
            return False
        return self._db_now() - started >= timedelta(
            seconds=self.child_timeout_seconds
        )

    async def _release_child(self, child_id: str) -> None:
        """Forget a started child and release its project workspace.

        This helper is used only after the persisted child has reached a
        terminal or explicitly paused state.  Paths that intentionally retain
        a lease while a child is still running continue to use their explicit
        ``keep_workspace``/``finally`` logic below.
        """

        self._started_child_ids.discard(child_id)
        if self.workspace_manager is not None:
            await self.workspace_manager.release(child_id)

    async def _process_item(
        self,
        claim: BatchClaim,
        batch: BatchTask,
        item: BatchItem,
    ) -> str:
        """Run one queued item and persist its terminal projection."""

        try:
            content = self.input_store.read_snapshot(
                item,
                expected_hash=item.content_hash,
            )
        except (SnapshotInvalidError, OSError, ValueError, TypeError) as exc:
            await self._finish_item(
                claim,
                item.id,
                status=BatchItemStatus.FAIL.value,
                terminal_reason="SNAPSHOT_INVALID",
                error_code="SNAPSHOT_INVALID",
                error_message=str(exc)[:2000],
                result_summary=None,
            )
            return "fail"

        child_id = item.unittest_task_id or str(uuid.uuid4())
        workspace_owner_id = child_id
        workspace_reserved = False
        keep_workspace = False
        try:
            if self.workspace_manager is not None:
                workspace_reserved = await self._wait_for_workspace(
                    workspace_owner_id,
                    batch.project_root,
                    claim.batch_task_id,
                )
                if not workspace_reserved:
                    await self._finish_item(
                        claim,
                        item.id,
                        status=BatchItemStatus.FAIL.value,
                        terminal_reason="CANCELLED",
                        error_code="CANCELLED",
                        error_message="Batch was cancelled before the item started",
                        result_summary=None,
                    )
                    return "fail"

            # Mark the Item running and create/link exactly one ordinary child
            # in the same transaction.  If a prior worker already linked a
            # child, reuse it and never insert a second Task.
            started = await self._start_item_transaction(
                claim,
                batch,
                item.id,
                child_id,
                content,
            )
            if started is None:
                return "fail"
            child_id, child_status, child = started

            # A concurrent recovery path may have linked a child after the
            # Item snapshot above was read.  Transfer the pending reservation
            # to that persisted child before any runner callback is invoked.
            if (
                self.workspace_manager is not None
                and child_id != workspace_owner_id
            ):
                await self.workspace_manager.release(workspace_owner_id)
                workspace_reserved = False
                workspace_owner_id = child_id
                workspace_reserved = await self._wait_for_workspace(
                    workspace_owner_id,
                    batch.project_root,
                    claim.batch_task_id,
                )
                if not workspace_reserved:
                    return "pending"

            # The child link transaction is committed at this point.  Keeping
            # the reservation pending before this boundary lets another
            # process reclaim a crash in the reserve -> Task-create window;
            # after it, the Task row makes an active lease safe.
            if self.workspace_manager is not None:
                self.workspace_manager.mark_active(workspace_owner_id)

            # A child which was already terminal (for example after a worker
            # crash) can be projected without starting it again.  A paused
            # child retains the workspace only when resume remains possible.
            if child_status in {"completed", "failed", "cancelled", "paused"}:
                result = await self._read_child_result(child_id)
                outcome = await self._project_child_result(
                    claim, item.id, child_id, result
                )
                keep_workspace = False
                # The helper owns this terminal release; do not repeat it in
                # the workspace-reservation ``finally`` below.
                workspace_reserved = False
                await self._release_child(child_id)
                return outcome

            # From this point onward an external process may have started.
            # Retain the project lease until the persisted Task is observed in
            # a terminal state, including when this coroutine is cancelled or
            # the callback returns before updating the Task row.
            keep_workspace = self.workspace_manager is not None
            self._started_child_ids.add(child_id)
            self._active_child_ids.add(child_id)
            unit_input = self._build_unit_test_input(batch, item, child_id, content)
            try:
                await self._run_child_with_progress(
                    batch,
                    item,
                    unit_input,
                    child_id,
                        child=child,
                )
            except asyncio.CancelledError:
                if not await self._is_cancel_requested(claim.batch_task_id):
                    raise
            except Exception as exc:
                # The production bridge persists preparation/scheduling
                # failures on Task.  If an injected callback does not, retain
                # the Item/workspace and let the bounded timeout reconcile it.
                logger.warning(
                    "Batch child callback returned with an error for %s: %s",
                    child_id,
                    exc,
                )

            # Callback payloads are advisory.  Only the persisted ordinary
            # Task can advance the BatchItem to a terminal/paused state.
            persisted = await self._read_child_result(child_id)
            persisted_state = self._result_state(persisted)
            if persisted_state in {
                "completed",
                "failed",
                "cancelled",
                "paused",
            }:
                outcome = await self._project_child_result(
                    claim, item.id, child_id, persisted
                )
                keep_workspace = False
                # The helper owns this terminal release; do not repeat it in
                # the workspace-reservation ``finally`` below.
                workspace_reserved = False
                await self._release_child(child_id)
                return outcome

            # A callback may itself have returned a terminal-looking value,
            # but projecting it here would let stale output overwrite a
            # pending/running Task.  Keep observing the persisted child.
            return "pending"
        finally:
            self._active_child_ids.discard(child_id)
            if (
                workspace_reserved
                and not keep_workspace
                and self.workspace_manager is not None
            ):
                await self.workspace_manager.release(workspace_owner_id)

    async def _start_item_transaction(
        self,
        claim: BatchClaim,
        batch: BatchTask,
        item_id: str,
        child_id: str,
        content: bytes,
    ) -> tuple[str, str, Task] | None:
        now = self._db_now()
        try:
            async with self.session_factory() as session:
                await self._begin_write(session)
                if not await self._session_lease_is_current(
                    session, claim.fencing_token, now
                ):
                    await session.rollback()
                    raise DispatcherLeaseLost()
                item = await session.scalar(
                    select(BatchItem).where(
                        BatchItem.id == item_id,
                        BatchItem.batch_task_id == claim.batch_task_id,
                    )
                )
                batch_row = await session.scalar(
                    select(BatchTask).where(BatchTask.id == claim.batch_task_id)
                )
                if item is None or batch_row is None:
                    await session.rollback()
                    return None
                if item.status in {
                    BatchItemStatus.PASS.value,
                    BatchItemStatus.FAIL.value,
                }:
                    await session.rollback()
                    return None

                existing_child: Task | None = None
                if item.unittest_task_id:
                    existing_child = await session.scalar(
                        select(Task).where(Task.id == item.unittest_task_id)
                    )
                    if existing_child is None:
                        # A dangling link is unsafe to execute.  Fail the Item
                        # rather than creating a second child under the same
                        # persisted ID.
                        item.status = BatchItemStatus.FAIL.value
                        item.progress = 100
                        item.terminal_reason = "CHILD_STATUS_UNKNOWN"
                        item.error_code = "CHILD_STATUS_UNKNOWN"
                        item.error_message = "Linked child Task is missing"
                        item.finished_at = now
                        await self._refresh_batch_in_session(
                            session, batch_row, terminal_reason=None, now=now
                        )
                        await session.commit()
                        return None
                    child_id = existing_child.id
                else:
                    # A direct child must be a single-file context.  Persisting
                    # this compact metadata also gives ordinary resume code the
                    # same source/path information as the batch dispatcher.
                    source_text = content.decode("utf-8", errors="replace")
                    payload = {
                        # Keep the legacy single-file list/detail projection
                        # compatible; older UI code reads ``filename`` while
                        # the batch runner also consumes the richer fields.
                        "filename": item.filename,
                        "files": [item.source_path],
                        "source_filename": item.filename,
                        "source_full_path": item.source_path,
                        "source_paths": [item.source_path],
                        "source_contents": {item.source_path: source_text},
                        "source_path_map": {
                            item.source_path: item.source_path,
                            item.filename: item.source_path,
                        },
                        "output_dir": batch_row.project_root,
                        "batch_task_id": batch_row.id,
                        "batch_item_id": item.id,
                        "is_batch_child": True,
                    }
                    existing_child = Task(
                        id=child_id,
                        user_id=batch_row.user_id,
                        agent_type="unittest",
                        status="pending",
                        progress=0,
                        message="Batch item child task created",
                        input_data=json.dumps(payload, ensure_ascii=False),
                        batch_task_id=batch_row.id,
                        batch_item_id=item.id,
                    )
                    session.add(existing_child)
                    item.unittest_task_id = child_id

                item.status = BatchItemStatus.RUNNING.value
                item.progress = max(0, min(int(item.progress or 0), 100))
                item.blocked_reason = None
                item.resume_required = False
                item.started_at = item.started_at or now
                item.message = "Unit-Test child started"
                await session.flush()
                await session.commit()
                return child_id, str(existing_child.status or "pending"), existing_child
        except DispatcherLeaseLost:
            raise
        except IntegrityError as exc:
            # Unique ``batch_item_id`` is the final duplicate-child guard.  A
            # concurrent worker wins; re-read on the next dispatcher pass.
            logger.warning("Child creation race for BatchItem %s: %s", item_id, exc)
            return None
        except Exception as exc:
            logger.exception("Failed to start BatchItem %s", item_id)
            with suppress(Exception):
                await self._finish_item(
                    claim,
                    item_id,
                    status=BatchItemStatus.FAIL.value,
                    terminal_reason="RUNNER_FAILED",
                    error_code="RUNNER_FAILED",
                    error_message=str(exc)[:2000],
                    result_summary=None,
                )
            return None

    def _build_unit_test_input(
        self,
        batch: BatchTask,
        item: BatchItem,
        child_id: str,
        content: bytes,
    ) -> UnitTestInput:
        source_text = content.decode("utf-8", errors="replace")
        return UnitTestInput(
            task_id=child_id,
            user_id=batch.user_id,
            source_files=[item.source_path],
            source_contents={item.source_path: source_text},
            source_path_map={
                item.source_path: item.source_path,
                item.filename: item.source_path,
            },
            output_dir=batch.project_root,
        )

    async def _run_child_after_commit(
        self,
        batch: BatchTask,
        item: BatchItem,
        unit_input: UnitTestInput,
        child_id: str,
        *,
        child: Task | None = None,
    ) -> Any:
        callback = self.run_child
        if callback is not None:
            if child is None:
                child = await self._read_child_after_commit(child_id)
            content = unit_input.source_contents.get(item.source_path, "").encode("utf-8")
            return await self._invoke_callback(
                callback,
                (
                    (batch, item, child, content),
                    (batch, item, unit_input),
                    (unit_input,),
                    (batch, item),
                    (child_id, unit_input),
                ),
            )

        # An integration can provide a complete UnitTestRunner.  The runner's
        # ``start`` method still requires the application's bridge/MCP objects;
        # accept them as optional attributes to avoid importing FastAPI here.
        start = getattr(self.runner, "start", None)
        if callable(start):
            llm_bridge = getattr(self.runner, "llm_bridge", None)
            mcp_client = getattr(self.runner, "mcp_client", None)
            skill_registry = getattr(self.runner, "skill_registry", None)
            if llm_bridge is not None and mcp_client is not None:
                started = start(
                    unit_input,
                    llm_bridge=llm_bridge,
                    mcp_client=mcp_client,
                    skill_registry=skill_registry,
                )
                if inspect.isawaitable(started):
                    started = await started
                if isinstance(started, tuple) and len(started) == 2:
                    future = started[1]
                    return await future if inspect.isawaitable(future) else future
                return await started if inspect.isawaitable(started) else started

        raise RuntimeError(
            "BatchQueueDispatcher requires run_child or a configured UnitTestRunner"
        )

    async def _read_child_after_commit(self, child_id: str) -> Task:
        """Read a child after its creation transaction becomes visible.

        SQLite can briefly yield the connection that committed a row while a
        second async session is being opened.  A bounded retry closes that
        visibility window without masking a genuinely missing child row.
        """

        for attempt in range(4):
            async with self.session_factory() as session:
                child = await session.scalar(select(Task).where(Task.id == child_id))
            if child is not None:
                return child
            if attempt < 3:
                await asyncio.sleep(0.01 * (attempt + 1))
        raise RuntimeError(f"Batch child Task {child_id} is missing after commit")

    async def _run_child_with_progress(
        self,
        batch: BatchTask,
        item: BatchItem,
        unit_input: UnitTestInput,
        child_id: str,
        *,
        child: Task | None = None,
    ) -> Any:
        """Run a child while mirroring the ordinary endpoint's live progress.

        The legacy Unit-Test endpoint keeps rich stage data in an in-memory
        registry.  Batch detail responses are persisted and may be served by
        another process, so a small watcher periodically folds the provider's
        snapshot into ``BatchItem`` and the aggregate ``BatchTask`` row.  The
        callback itself remains unchanged and the watcher is best-effort; a
        lease loss is handled by the normal fenced projection path.

        The watcher also polls ``cancel_requested`` so an external batch
        cancellation is forwarded to the running child immediately (same
        kill path as the ordinary Unit-Test endpoint) instead of waiting
        for the child's natural completion.
        """

        watcher: asyncio.Task[Any] | None = None
        has_cancel_hook = (
            self.cancel_child is not None
            or callable(getattr(self.runner, "cancel", None))
        )
        if self.progress_provider is not None or has_cancel_hook:
            watcher = asyncio.create_task(
                self._progress_watch(
                    batch.id,
                    item.id,
                    child_id,
                ),
                name=f"batch-progress:{child_id}",
            )
        try:
            result = await self._run_child_after_commit(
                batch,
                item,
                unit_input,
                child_id,
                child=child,
            )
            # Capture a final in-flight snapshot before projecting the
            # terminal callback result.  Terminal fields are still written by
            # ``_finish_item`` and therefore retain their fencing guarantees.
            if self.progress_provider is not None:
                await self._sync_item_progress(batch.id, item.id, child_id)
            return result
        finally:
            if watcher is not None and not watcher.done():
                watcher.cancel()
                with suppress(asyncio.CancelledError):
                    await watcher

            # The watcher deliberately detaches its kill task so cancelling
            # the watcher cannot interrupt process teardown. Join that task
            # here, or issue the cancellation directly if the callback ended
            # before the watcher observed the persisted request.
            try:
                cancel_requested = await self._is_cancel_requested(batch.id)
            except DispatcherLeaseLost:
                cancel_requested = False
            if cancel_requested:
                cancel_tasks = [
                    task
                    for task in self._child_cancel_tasks
                    if task.get_name() == f"batch-cancel:{child_id}"
                ]
                if cancel_tasks:
                    await asyncio.gather(*cancel_tasks, return_exceptions=True)
                else:
                    await self._cancel_child(child_id)

    async def _progress_watch(
        self,
        batch_id: str,
        item_id: str,
        child_id: str,
    ) -> None:
        """Poll the injected progress source until the child callback exits.

        Also polls ``cancel_requested`` for the batch and, when observed,
        forwards the cancellation to the running child through the same
        hook the ordinary Unit-Test endpoint uses.  The forwarding task is
        detached so the callback's return (which cancels this watcher)
        cannot abort the kill signals mid-flight.  The between-items check
        in ``_process_batch`` remains the authoritative backstop.
        """

        interval = min(max(self.poll_interval_seconds, 0.05), 1.0)
        try:
            # Let the child starter publish its initial Task state before the
            # watcher opens another SQLite session.  This matters for the
            # shared in-memory test handle and also reduces startup contention
            # in deployments that use a small connection pool.
            await asyncio.sleep(max(interval, 0.25))
            while True:
                await self._sync_item_progress(batch_id, item_id, child_id)
                if await self._is_cancel_requested(batch_id):
                    logger.info(
                        "Batch %s cancellation observed while child %s is "
                        "running; forwarding cancellation to the child",
                        batch_id,
                        child_id,
                    )
                    cancel_task = asyncio.create_task(
                        self._cancel_child(child_id),
                        name=f"batch-cancel:{child_id}",
                    )
                    self._child_cancel_tasks.add(cancel_task)
                    cancel_task.add_done_callback(
                        self._child_cancel_tasks.discard
                    )
                    return
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            raise
        except DispatcherLeaseLost:
            # The callback will hit the same fenced boundary and the successor
            # worker can safely reconcile the item.
            logger.debug("Progress watcher lost dispatcher lease for %s", child_id)
        except Exception:
            # Progress is observational.  Never turn a successful child into
            # a failed one merely because an optional provider is unavailable.
            logger.debug("Batch progress watcher failed for %s", child_id, exc_info=True)

    async def _sync_item_progress(
        self,
        batch_id: str,
        item_id: str,
        child_id: str,
    ) -> None:
        """Persist one non-terminal progress snapshot with lease fencing."""

        provider = self.progress_provider
        if provider is None:
            return
        try:
            snapshot = provider(child_id)
            if inspect.isawaitable(snapshot):
                snapshot = await snapshot
        except Exception:
            logger.debug("Progress provider failed for %s", child_id, exc_info=True)
            return
        if snapshot is None:
            return
        if isinstance(snapshot, Mapping):
            values = snapshot
        else:
            values = {
                key: getattr(snapshot, key, None)
                for key in (
                    "status",
                    "progress",
                    "current_stage",
                    "stage",
                    "message",
                    "error",
                )
            }
        # A terminal status is projected from the authoritative Task/result
        # path; the watcher only mirrors progress while the Item is running.
        # Missing/invalid provider fields must not reset already persisted
        # progress, and in-flight progress is monotonic until terminalization.
        progress: int | None = None
        if "progress" in values and values.get("progress") is not None:
            try:
                progress = max(0, min(99, int(values.get("progress"))))
            except (TypeError, ValueError):
                progress = None
        stage = values.get("current_stage") or values.get("stage")
        message = values.get("message") or values.get("error")
        now = self._db_now()
        token = self._lease_token
        if not self._lease_held or token is None:
            return
        try:
            async with self.session_factory() as session:
                await self._begin_write(session)
                if not await self._session_lease_is_current(session, token, now):
                    await session.rollback()
                    self._lease_held = False
                    return
                item = await session.scalar(
                    select(BatchItem).where(
                        BatchItem.id == item_id,
                        BatchItem.batch_task_id == batch_id,
                    )
                )
                batch = await session.scalar(
                    select(BatchTask).where(BatchTask.id == batch_id)
                )
                if item is None or batch is None or item.status != BatchItemStatus.RUNNING.value:
                    await session.rollback()
                    return
                if progress is not None:
                    item.progress = max(int(item.progress or 0), progress)
                if stage is not None:
                    item.current_stage = str(stage)[:100]
                if message is not None:
                    item.message = str(message)[:500]
                await self._refresh_batch_in_session(session, batch, now=now)
                await session.commit()
        except DispatcherLeaseLost:
            raise
        except Exception:
            # SQLite contention and a disappearing item are harmless for this
            # best-effort mirror; the next poll or terminal projection retries.
            logger.debug("Failed to persist progress for %s", child_id, exc_info=True)

    # ------------------------------------------------------------------
    # Child projection and aggregation
    # ------------------------------------------------------------------

    async def _read_child_result(self, child_id: str) -> Any:
        async with self.session_factory() as session:
            child = await session.scalar(select(Task).where(Task.id == child_id))
            if child is None:
                return {"status": "unknown", "error_code": "CHILD_STATUS_UNKNOWN"}
            # ``Task`` is the source of truth for lifecycle fields.  A child
            # result payload is user/runner data and may contain stale or
            # conflicting keys (including ``status``); merge it only as a
            # summary, then restore the persisted authority below.
            payload: dict[str, Any] = {
                "status": child.status or "unknown",
                "error": child.error_message,
                "error_message": child.error_message,
                "progress": child.progress,
                "message": child.message,
                "result_data": child.result_data,
            }
            if child.result_data:
                try:
                    decoded = json.loads(child.result_data)
                    if isinstance(decoded, Mapping):
                        payload.update(decoded)
                except (TypeError, ValueError, json.JSONDecodeError):
                    pass
            # Never let stale result_data advance/terminalize a still-running
            # Task, nor erase an authoritative error/progress update.
            payload["status"] = child.status or "unknown"
            payload["progress"] = child.progress
            payload["message"] = child.message
            payload["error"] = child.error_message
            payload["error_message"] = child.error_message
            payload["result_data"] = child.result_data
            return payload

    async def _project_child_result(
        self,
        claim: BatchClaim,
        item_id: str,
        child_id: str,
        result: Any,
    ) -> str:
        state = self._result_state(result)
        if state == "completed":
            status = BatchItemStatus.PASS.value
            reason = code = None
        elif state in {"failed", "cancelled"}:
            status = BatchItemStatus.FAIL.value
            code = self._error_code_for_result(result, state)
            reason = "CANCELLED" if state == "cancelled" else code
        elif state == "paused":
            if self.resume_enabled:
                await self._mark_item_blocked(
                    claim,
                    item_id,
                    child_id,
                    self._blocked_reason_for_result(result),
                )
                return "blocked"
            status = BatchItemStatus.FAIL.value
            # With resume disabled an authentication pause cannot occupy the
            # FIFO head.  Project it immediately using the same terminal code
            # as an enabled resume window that expires.
            code = "AUTH_BLOCK_TIMEOUT"
            reason = code
        else:
            status = BatchItemStatus.FAIL.value
            code = "CHILD_STATUS_UNKNOWN"
            reason = code

        await self._finish_item(
            claim,
            item_id,
            status=status,
            terminal_reason=reason,
            error_code=code,
            error_message=self._result_message(result),
            result_summary=self._result_summary(result),
        )
        return "pass" if status == BatchItemStatus.PASS.value else "fail"

    async def _mark_item_blocked(
        self,
        claim: BatchClaim,
        item_id: str,
        child_id: str,
        reason: str,
    ) -> None:
        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            if not await self._session_lease_is_current(
                session, claim.fencing_token, now
            ):
                await session.rollback()
                raise DispatcherLeaseLost()
            item = await session.scalar(
                select(BatchItem).where(
                    BatchItem.id == item_id,
                    BatchItem.batch_task_id == claim.batch_task_id,
                )
            )
            if item is None:
                await session.rollback()
                return
            if item.status in {
                BatchItemStatus.PASS.value,
                BatchItemStatus.FAIL.value,
            }:
                await session.rollback()
                return
            item.status = BatchItemStatus.RUNNING.value
            item.unittest_task_id = child_id
            item.blocked_reason = reason
            item.resume_required = True
            item.message = "Unit-Test child is waiting for authentication"
            item.updated_at = now
            await session.flush()
            await session.commit()

    async def _finish_item(
        self,
        claim: BatchClaim,
        item_id: str,
        *,
        status: str,
        terminal_reason: str | None,
        error_code: str | None,
        error_message: str | None,
        result_summary: Mapping[str, Any] | None,
    ) -> None:
        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            if not await self._session_lease_is_current(
                session, claim.fencing_token, now
            ):
                await session.rollback()
                raise DispatcherLeaseLost()
            item = await session.scalar(
                select(BatchItem).where(
                    BatchItem.id == item_id,
                    BatchItem.batch_task_id == claim.batch_task_id,
                )
            )
            batch = await session.scalar(
                select(BatchTask).where(BatchTask.id == claim.batch_task_id)
            )
            if item is None or batch is None:
                await session.rollback()
                return
            if item.status in {
                BatchItemStatus.PASS.value,
                BatchItemStatus.FAIL.value,
            }:
                # Terminal projection is irreversible.  A cancellation or
                # timeout callback can race a just-completed child; whichever
                # result committed first remains authoritative.
                await session.rollback()
                return
            item.status = status
            item.progress = 100
            item.current_stage = None
            item.blocked_reason = None
            item.resume_required = False
            item.terminal_reason = terminal_reason
            item.error_code = error_code
            item.error_message = error_message
            item.result_summary = (
                json.dumps(dict(result_summary), ensure_ascii=False)
                if result_summary is not None
                else None
            )
            item.finished_at = now
            item.message = "Unit-Test item completed" if status == BatchItemStatus.PASS.value else (
                error_message or terminal_reason or "Unit-Test item failed"
            )[:500]
            await self._refresh_batch_in_session(session, batch, now=now)
            await session.commit()

    async def _refresh_batch_in_session(
        self,
        session: AsyncSession,
        batch: BatchTask,
        *,
        terminal_reason: str | None = None,
        now: datetime | None = None,
    ) -> BatchCounts:
        items = list(
            (
                await session.scalars(
                    select(BatchItem)
                    .where(BatchItem.batch_task_id == batch.id)
                    .order_by(BatchItem.sequence.asc())
                )
            ).all()
        )
        counts = aggregate_batch_counts(items)
        batch.progress = calculate_batch_progress(items)
        batch.updated_at = now or self._db_now()
        if counts.total and counts.queued == 0 and counts.running == 0:
            batch.status = BatchTaskStatus.DONE.value
            batch.progress = 100
            batch.finished_at = batch.finished_at or (now or self._db_now())
            # A normal completion (including failed Items) has no batch-level
            # reason.  Cancellation/system callers set it explicitly after the
            # aggregate is terminal.
            if terminal_reason is not None:
                batch.terminal_reason = terminal_reason
            entry = await session.scalar(
                select(BatchQueueEntry).where(
                    BatchQueueEntry.batch_task_id == batch.id
                )
            )
            if entry is not None:
                entry.state = BatchQueueEntryState.RELEASED.value
                entry.claimed_by = entry.claimed_by or self.worker_id
                entry.updated_at = now or self._db_now()
        else:
            batch.status = BatchTaskStatus.RUNNING.value
        return counts

    async def _complete_batch_if_ready(self, claim: BatchClaim) -> None:
        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            if not await self._session_lease_is_current(
                session, claim.fencing_token, now
            ):
                await session.rollback()
                raise DispatcherLeaseLost()
            batch = await session.scalar(
                select(BatchTask).where(BatchTask.id == claim.batch_task_id)
            )
            if batch is None:
                await session.rollback()
                return
            await self._refresh_batch_in_session(session, batch, now=now)
            await session.commit()

    async def _batch_is_done(self, batch_id: str) -> bool:
        async with self.session_factory() as session:
            status = await session.scalar(
                select(BatchTask.status).where(BatchTask.id == batch_id)
            )
            return status == BatchTaskStatus.DONE.value

    async def _next_item(self, batch_id: str) -> tuple[BatchTask | None, BatchItem | None]:
        async with self.session_factory() as session:
            batch = await session.scalar(select(BatchTask).where(BatchTask.id == batch_id))
            if batch is None:
                return None, None
            item = await session.scalar(
                select(BatchItem)
                .where(
                    BatchItem.batch_task_id == batch_id,
                    BatchItem.status.in_(
                        (
                            BatchItemStatus.RUNNING.value,
                            BatchItemStatus.QUEUED.value,
                        )
                    ),
                )
                .order_by(BatchItem.sequence.asc())
                .limit(1)
            )
            return batch, item

    # ------------------------------------------------------------------
    # Cancel / resume / restart hooks
    # ------------------------------------------------------------------

    async def request_cancel(self, batch_id: str) -> bool:
        """Set cancellation intent and report whether the batch exists."""

        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            batch = await session.scalar(select(BatchTask).where(BatchTask.id == batch_id))
            if batch is None:
                await session.rollback()
                return False
            if batch.status != BatchTaskStatus.DONE.value:
                batch.cancel_requested = True
                batch.updated_at = now
                await session.flush()
            await session.commit()

        # Cancellation is intentionally completed by the lease-owning
        # dispatcher.  The HTTP request only persists intent and returns; this
        # keeps the documented 200 response independent from process teardown.
        self.wake()
        return True

    cancel_batch = request_cancel

    async def resume_batch(self, batch_id: str) -> bool:
        """Resume the same child ID, preserving the block if delegation fails."""

        if not self.resume_enabled:
            return False

        # Resume is an execution-side operation, not just a metadata update.
        # Only the worker which currently owns the dispatcher lease may invoke
        # the child callback.  A standby process can still serve the HTTP
        # endpoint (the app is multi-worker), so checking the lease here is
        # essential before it performs any provider/runner side effect.
        # Capture the token now and use that immutable value for the final
        # projection below; a takeover during the callback must fence this
        # worker even if it subsequently acquires a newer token.
        resume_token = self._lease_token
        if (
            not self._lease_held
            or resume_token is None
            or not await self._lease_is_current()
            or resume_token != self._lease_token
        ):
            self._lease_held = False
            return False

        child_id: str | None = None
        async with self.session_factory() as session:
            batch = await session.scalar(select(BatchTask).where(BatchTask.id == batch_id))
            item = None
            if batch is not None:
                item = await session.scalar(
                    select(BatchItem)
                    .where(
                        BatchItem.batch_task_id == batch_id,
                        BatchItem.status == BatchItemStatus.RUNNING.value,
                        BatchItem.resume_required.is_(True),
                    )
                    .order_by(BatchItem.sequence.asc())
                    .limit(1)
                )
            if (
                batch is None
                or batch.cancel_requested
                or item is None
                or not item.unittest_task_id
            ):
                return False
            child_id = item.unittest_task_id
            item_id = item.id

        assert child_id is not None
        try:
            if self.resume_child is not None:
                resumed = await self._invoke_callback(
                    self.resume_child,
                    ((batch_id, child_id), (child_id,)),
                )
                if resumed is False:
                    return False
            else:
                # An injected UnitTestRunner may expose a project-specific
                # resume method; the dispatcher never invents a new child ID.
                resume = getattr(self.runner, "resume", None) or getattr(
                    self.runner, "resume_existing", None
                )
                if not callable(resume):
                    return False
                value = resume(child_id)
                if inspect.isawaitable(value):
                    await value
        except Exception as exc:
            # FastAPI's ordinary resume path carries meaningful 401/404/500
            # semantics (SSO incomplete, profile/context missing, etc.).
            # Preserve those HTTP exceptions for the batch route; only
            # unexpected runner errors retain the historical ``False`` result
            # so a transient callback failure leaves the item blocked.
            try:
                from fastapi import HTTPException
            except Exception:  # pragma: no cover - FastAPI is a runtime dep
                HTTPException = ()  # type: ignore[assignment]
            if HTTPException and isinstance(exc, HTTPException):
                raise
            logger.exception("Failed to resume batch child %s", child_id)
            return False

        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            # The callback may take long enough for this worker's lease to
            # expire or be taken over.  Re-check the same fencing token while
            # holding the write transaction before touching BatchItem/BatchTask.
            # On lease loss leave the resumable marker untouched so the
            # successor worker can safely observe the child and finish it.
            if not await self._session_lease_is_current(session, resume_token, now):
                await session.rollback()
                self._lease_held = False
                return False
            batch = await session.scalar(
                select(BatchTask).where(BatchTask.id == batch_id)
            )
            item = await session.scalar(
                select(BatchItem).where(
                    BatchItem.id == item_id,
                    BatchItem.batch_task_id == batch_id,
                    BatchItem.status == BatchItemStatus.RUNNING.value,
                    BatchItem.resume_required.is_(True),
                    BatchItem.unittest_task_id == child_id,
                )
            )
            if batch is None or batch.cancel_requested or item is None:
                await session.rollback()
                await self._cancel_child(child_id)
                return False
            item.blocked_reason = None
            item.resume_required = False
            item.message = "Batch item resumed after authentication"
            item.updated_at = now
            batch.updated_at = now
            await session.flush()
            await session.commit()
        self.wake()
        return True

    async def reconcile_after_restart(self) -> int:
        """Finalize every batch interrupted by the previous backend process.

        A restart loses all in-memory execution state: the Unit-Test startup
        hook has already cancelled stale children, and no future, CLI/QBS
        process or resume context can be reattached.  Every non-done
        BatchTask is therefore finalized instead of resumed:

        * a ``running`` Item keeps an authoritative child terminal state that
          was persisted just before the crash and is otherwise finalized as
          ``fail/BACKEND_RESTART``;
        * every still-``queued`` Item fails with ``BACKEND_RESTART`` without
          creating a child;
        * the BatchTask ends ``done`` with ``terminal_reason=BACKEND_RESTART``
          and its queue entry is released, so post-restart submissions start a
          fresh FIFO cycle.
        """

        changed = 0
        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            batches = list(
                (
                    await session.scalars(
                        select(BatchTask).where(
                            BatchTask.status != BatchTaskStatus.DONE.value
                        )
                    )
                ).all()
            )
            items_by_batch: dict[str, list[BatchItem]] = {}
            if batches:
                rows = list(
                    (
                        await session.scalars(
                            select(BatchItem).where(
                                BatchItem.batch_task_id.in_(
                                    [batch.id for batch in batches]
                                )
                            )
                        )
                    ).all()
                )
                for item in rows:
                    items_by_batch.setdefault(item.batch_task_id, []).append(item)

            for batch in batches:
                for item in items_by_batch.get(batch.id, []):
                    if item.status == BatchItemStatus.RUNNING.value:
                        child = None
                        if item.unittest_task_id:
                            child = await session.scalar(
                                select(Task).where(Task.id == item.unittest_task_id)
                            )
                        child_state = str(getattr(child, "status", "") or "").lower()

                        # Startup cleanup normally changes an interrupted running
                        # child to ``cancelled``.  It is nevertheless possible for a
                        # child to have reached a terminal state just before the
                        # process stopped; preserve that authoritative result instead
                        # of overwriting it with BACKEND_RESTART.
                        if child is not None and child_state == "completed":
                            item.status = BatchItemStatus.PASS.value
                            item.terminal_reason = None
                            item.error_code = None
                            item.error_message = None
                            item.result_summary = self._serialized_result_summary(child)
                        elif child is not None and child_state == "failed":
                            item.status = BatchItemStatus.FAIL.value
                            item.terminal_reason = "RUNNER_FAILED"
                            item.error_code = "RUNNER_FAILED"
                            item.error_message = child.error_message
                            item.result_summary = None
                        else:
                            # ``cancelled`` is the expected state for a child that was
                            # interrupted by backend startup cleanup.  Unknown,
                            # pending, running and paused states are also unsafe to
                            # reattach after restart, so mark the child cancelled and
                            # use the same explicit batch-level diagnostic.
                            if child is not None and child_state not in {
                                "completed",
                                "failed",
                                "cancelled",
                            }:
                                child.status = "cancelled"
                                child.progress = min(int(child.progress or 0), 99)
                                child.message = "Task cancelled during backend restart"
                                child.error_message = "Backend restarted before task completion"
                            item.status = BatchItemStatus.FAIL.value
                            item.terminal_reason = "BACKEND_RESTART"
                            item.error_code = "BACKEND_RESTART"
                            item.error_message = "Batch child was cancelled during backend restart"
                            item.result_summary = None
                        item.progress = 100
                        item.resume_required = False
                        item.blocked_reason = None
                        item.finished_at = now
                        changed += 1
                    elif item.status == BatchItemStatus.QUEUED.value:
                        # The batch was interrupted before this Item started; no
                        # child exists and none may be created after a restart.
                        item.status = BatchItemStatus.FAIL.value
                        item.terminal_reason = "BACKEND_RESTART"
                        item.error_code = "BACKEND_RESTART"
                        item.error_message = (
                            "Batch interrupted by backend restart before execution"
                        )
                        item.progress = 100
                        item.resume_required = False
                        item.blocked_reason = None
                        item.finished_at = now
                        changed += 1
                    # Terminal ``pass``/``fail`` Items keep their results.

                counts = await self._refresh_batch_in_session(
                    session, batch, terminal_reason="BACKEND_RESTART", now=now
                )
                if not counts.total:
                    # Defensive: a corrupt zero-item batch must not block FIFO.
                    batch.status = BatchTaskStatus.DONE.value
                    batch.progress = 100
                    batch.finished_at = batch.finished_at or now
                    batch.terminal_reason = "BACKEND_RESTART"
                    entry = await session.scalar(
                        select(BatchQueueEntry).where(
                            BatchQueueEntry.batch_task_id == batch.id
                        )
                    )
                    if entry is not None:
                        entry.state = BatchQueueEntryState.RELEASED.value
                        entry.updated_at = now
            await session.commit()
        if changed:
            self.wake()
        return changed

    # Compatibility alias.
    recover_after_restart = reconcile_after_restart
    reconcile_backend_restart = reconcile_after_restart

    # ------------------------------------------------------------------
    # Internal cancellation/workspace/loop helpers
    # ------------------------------------------------------------------

    async def _cancel_batch_rows(self, claim: BatchClaim | str) -> None:
        # ``str`` is retained for internal prototype callers/tests which used
        # this helper before fencing was introduced.  Production paths always
        # pass a BatchClaim and therefore enforce lease ownership below.
        legacy_call = isinstance(claim, str)
        batch_id = claim if legacy_call else claim.batch_task_id
        if not legacy_call:
            await self._require_current_lease()

        async with self.session_factory() as session:
            child_ids = list(
                (
                    await session.scalars(
                        select(BatchItem.unittest_task_id).where(
                            BatchItem.batch_task_id == batch_id,
                            BatchItem.status == BatchItemStatus.RUNNING.value,
                            BatchItem.unittest_task_id.is_not(None),
                        )
                    )
                ).all()
            )

        # Do not publish done/release the FIFO head while its child may still
        # write to the workspace.  A failing cancellation callback leaves the
        # persisted intent in place so the next dispatcher pass retries.
        for child_id in child_ids:
            if child_id and not await self._cancel_child(child_id):
                return

        now = self._db_now()
        async with self.session_factory() as session:
            await self._begin_write(session)
            if (
                not legacy_call
                and not await self._session_lease_is_current(
                    session, claim.fencing_token, now
                )
            ):
                await session.rollback()
                raise DispatcherLeaseLost()
            batch = await session.scalar(select(BatchTask).where(BatchTask.id == batch_id))
            if batch is None:
                await session.rollback()
                return
            items = list(
                (
                    await session.scalars(
                        select(BatchItem)
                        .where(
                            BatchItem.batch_task_id == batch_id,
                            BatchItem.status.in_(
                                (
                                    BatchItemStatus.QUEUED.value,
                                    BatchItemStatus.RUNNING.value,
                                )
                            ),
                        )
                        .order_by(BatchItem.sequence.asc())
                    )
                ).all()
            )
            for item in items:
                child = None
                if item.status == BatchItemStatus.RUNNING.value and item.unittest_task_id:
                    child = await session.scalar(
                        select(Task).where(Task.id == item.unittest_task_id)
                    )
                child_state = str(getattr(child, "status", "") or "").lower()
                if child_state == "completed":
                    item.status = BatchItemStatus.PASS.value
                    item.terminal_reason = None
                    item.error_code = None
                    item.error_message = None
                    result = {
                        "status": child.status,
                        "result_data": child.result_data,
                    }
                    summary = self._result_summary(result)
                    item.result_summary = (
                        json.dumps(summary, ensure_ascii=False) if summary else None
                    )
                elif child_state == "failed":
                    item.status = BatchItemStatus.FAIL.value
                    item.terminal_reason = "RUNNER_FAILED"
                    item.error_code = "RUNNER_FAILED"
                    item.error_message = child.error_message
                else:
                    item.status = BatchItemStatus.FAIL.value
                    item.terminal_reason = "CANCELLED"
                    item.error_code = "CANCELLED"
                    item.error_message = "Batch cancellation requested"
                item.progress = 100
                item.blocked_reason = None
                item.resume_required = False
                item.finished_at = now
            batch.cancel_requested = True
            await self._refresh_batch_in_session(
                session, batch, terminal_reason="CANCELLED", now=now
            )
            await session.commit()

        # Cancellation is complete only after all running children were
        # observed terminal and the batch rows committed.  The project gate
        # can now be released; a failed callback returned above and retains it.
        for child_id in child_ids:
            if child_id:
                await self._release_child(child_id)

    async def _cancel_child(
        self,
        child_id: str,
        *,
        allow_local: bool = False,
    ) -> bool:
        """Cancel a child and return ``True`` only after it is terminal.

        Cancellation callbacks historically returned ``False``/``None``
        interchangeably.  Treating every return as success allowed the batch
        to be marked ``done`` while a CLI process was still writing.  We now
        verify the persisted Task state after the callback and after any
        runner wait.  ``allow_local`` is used only by timeout/restart paths
        where no external cancellation hook exists; in that case the
        dispatcher itself can mark an orphaned row cancelled.
        """

        terminal = {"completed", "failed", "cancelled"}
        try:
            before = await self._child_state(child_id)
            if before in terminal:
                return True

            hook_kind = "none"
            value: Any = None
            if self.cancel_child is not None:
                hook_kind = "custom"
                value = self.cancel_child(child_id)
                if inspect.isawaitable(value):
                    value = await value
            else:
                cancel = getattr(self.runner, "cancel", None)
                if callable(cancel):
                    hook_kind = "runner"
                    value = cancel(child_id)
                    if inspect.isawaitable(value):
                        value = await value

            # An explicit negative acknowledgement is a failed cancellation;
            # a concurrently completed child is still safe to accept.
            if value is False:
                current = await self._child_state(child_id)
                if current in terminal:
                    return True
                if allow_local and hook_kind == "runner":
                    active_ids = getattr(self.runner, "active_task_ids", None)
                    if callable(active_ids):
                        try:
                            return child_id not in set(active_ids())
                        except Exception:
                            return False
                return False

            wait = getattr(self.runner, "wait", None)
            if callable(wait) and hook_kind != "none":
                try:
                    waited = wait(child_id)
                    if inspect.isawaitable(waited):
                        await waited
                except asyncio.CancelledError:
                    # Cancellation of the waiting coroutine does not by itself
                    # prove that the external child stopped; verify the row.
                    pass
                except Exception:
                    # The execution future may surface its original failure
                    # while unwinding.  The persisted terminal check below is
                    # the authority, so retain the diagnostic only.
                    logger.debug(
                        "Batch child %s exited with an error during cancellation",
                        child_id,
                        exc_info=True,
                    )

            after = await self._child_state(child_id)
            if after in terminal:
                return True

            # No hook means there is no known external process to signal.  A
            # timeout caller may explicitly opt into local orphan cleanup;
            # never apply that fallback to a custom/runner negative ack.
            if allow_local and hook_kind == "none":
                return after is not None
            if allow_local and hook_kind == "runner":
                active_ids = getattr(self.runner, "active_task_ids", None)
                if callable(active_ids):
                    try:
                        return child_id not in set(active_ids())
                    except Exception:
                        return False
            return False
        except Exception:
            logger.exception("Failed to signal cancellation for child %s", child_id)
            return False

    async def _child_state(self, child_id: str) -> str | None:
        """Read a child Task status without projecting or mutating it."""

        async with self.session_factory() as session:
            value = await session.scalar(select(Task.status).where(Task.id == child_id))
            return str(value or "").strip().lower() or None

    async def _mark_child_cancelled_if_active(self, child_id: str) -> None:
        """Persist a timeout cancellation when no runner callback owns the row.

        The ordinary Unit-Test cancellation callback normally updates ``Task``
        itself.  A dispatcher can also be used with a lightweight/in-process
        runner (or after a crashed process), where no callback is available;
        leaving the row in ``pending``/``running`` would make later recovery
        misclassify the child and could trigger another execution attempt.
        Only non-terminal rows are changed, so a concurrently completed child
        remains authoritative.
        """

        try:
            async with self.session_factory() as session:
                await self._begin_write(session)
                child = await session.scalar(select(Task).where(Task.id == child_id))
                state = str(getattr(child, "status", "") or "").lower()
                if child is not None and state not in {
                    "completed",
                    "failed",
                    "cancelled",
                }:
                    child.status = "cancelled"
                    child.progress = min(int(child.progress or 0), 99)
                    child.message = "Task cancelled after batch child timeout"
                    child.error_message = "Batch child exceeded execution timeout"
                    await session.flush()
                    await session.commit()
                else:
                    await session.rollback()
        except Exception:
            logger.exception("Failed to persist timeout cancellation for child %s", child_id)

    async def _wait_for_workspace(
        self,
        owner_id: str,
        project_root: str,
        batch_id: str,
    ) -> bool:
        assert self.workspace_manager is not None
        while True:
            await self._require_current_lease()
            if await self._is_cancel_requested(batch_id):
                return False
            owner = await self.workspace_manager.reserve(
                owner_id,
                project_root,
                owner_is_dead=self.workspace_owner_is_dead,
            )
            if owner is None:
                return True
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(), timeout=self.poll_interval_seconds
                )
                if self._stop_event.is_set():
                    return False
            except asyncio.TimeoutError:
                continue

    async def _dispatch_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                if not self._lease_held:
                    if not await self.acquire_lease():
                        try:
                            await asyncio.wait_for(
                                self._wake_event.wait(),
                                timeout=self.poll_interval_seconds,
                            )
                        except asyncio.TimeoutError:
                            pass
                        self._wake_event.clear()
                        continue
                    self._start_heartbeat()

                outcome = await self.run_once()
                if outcome.claim is None or not outcome.completed:
                    try:
                        await asyncio.wait_for(
                            self._wake_event.wait(), timeout=self.poll_interval_seconds
                        )
                    except asyncio.TimeoutError:
                        pass
                    self._wake_event.clear()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Batch dispatcher loop iteration failed")
                await asyncio.sleep(self.poll_interval_seconds)

    async def _heartbeat_loop(self) -> None:
        while not self._stop_event.is_set() and self._lease_held:
            try:
                await asyncio.sleep(self.heartbeat_seconds)
                if self._stop_event.is_set():
                    return
                if not await self.renew_lease():
                    self._wake_event.set()
                    return
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Batch dispatcher heartbeat iteration failed")

    async def _is_cancel_requested(self, batch_id: str) -> bool:
        async with self.session_factory() as session:
            return bool(
                await session.scalar(
                    select(BatchTask.cancel_requested).where(BatchTask.id == batch_id)
                )
            )

    async def _fail_batch_safely(
        self, batch_id: str, *, reason: str, message: str
    ) -> None:
        """Best-effort terminalization used only for unexpected outer failures."""

        now = self._db_now()
        token = self._lease_token
        async with self.session_factory() as session:
            await self._begin_write(session)
            if token is not None and not await self._session_lease_is_current(
                session, token, now
            ):
                await session.rollback()
                return
            batch = await session.scalar(select(BatchTask).where(BatchTask.id == batch_id))
            if batch is None:
                await session.rollback()
                return
            items = list(
                (
                    await session.scalars(
                        select(BatchItem).where(
                            BatchItem.batch_task_id == batch_id,
                            BatchItem.status.in_(
                                (
                                    BatchItemStatus.QUEUED.value,
                                    BatchItemStatus.RUNNING.value,
                                )
                            ),
                        )
                    )
                ).all()
            )
            for item in items:
                item.status = BatchItemStatus.FAIL.value
                item.progress = 100
                item.terminal_reason = reason
                item.error_code = reason
                item.error_message = message
                item.finished_at = now
            # Runner/provider failures belong to the affected Item(s).  A
            # BatchTask that reaches ``done`` with failed Items still has a
            # normal lifecycle completion and therefore keeps its batch-level
            # terminal_reason null.  Only the explicitly frozen batch-level
            # reasons (currently cancellation/system restart) may be
            # promoted from this fallback path.
            batch_reason = reason if reason in BATCH_TERMINAL_REASONS else None
            await self._refresh_batch_in_session(
                session, batch, terminal_reason=batch_reason, now=now
            )
            await session.commit()

    async def _lease_is_current(self) -> bool:
        token = self._lease_token
        if not self._lease_held or token is None:
            return False
        async with self.session_factory() as session:
            return await self._session_lease_is_current(session, token, self._db_now())

    async def _require_current_lease(self) -> None:
        if not await self._lease_is_current():
            self._lease_held = False
            raise DispatcherLeaseLost()

    async def _session_lease_is_current(
        self,
        session: AsyncSession,
        token: int,
        now: datetime,
    ) -> bool:
        row = await session.scalar(
            select(DispatcherLease).where(
                DispatcherLease.key == self.LEASE_KEY,
                DispatcherLease.owner_id == self.worker_id,
                DispatcherLease.fencing_token == token,
            ).with_for_update()
        )
        if row is None:
            return False
        expiry = self._as_naive_utc(row.expires_at)
        return expiry is None or expiry >= now

    async def _invoke_callback(
        self,
        callback: Callable[..., Any],
        candidates: Sequence[tuple[Any, ...]],
    ) -> Any:
        """Invoke a callback using the first signature-compatible candidate."""

        try:
            signature = inspect.signature(callback)
        except (TypeError, ValueError):
            signature = None
        selected: tuple[Any, ...] | None = None
        if signature is not None:
            for args in candidates:
                try:
                    signature.bind(*args)
                except TypeError:
                    continue
                selected = args
                break
        if selected is None:
            selected = candidates[0]
        value = callback(*selected)
        return await value if inspect.isawaitable(value) else value

    async def _owner_takeover_allowed(self, owner_id: str) -> bool:
        """Ask the injected worker/process observer whether takeover is safe.

        A guard is deliberately fail-closed: an exception or a non-true
        return value leaves the claimed queue row untouched.  This is only
        called when a callback was explicitly configured; deployments without
        an observer retain the legacy lease-expiry behavior for compatibility.
        """

        callback = self.takeover_guard
        if callback is None:
            return True
        try:
            value = callback(owner_id)
            if inspect.isawaitable(value):
                value = await value
            return value is True
        except Exception:
            logger.warning(
                "Unable to verify previous batch worker %s before takeover",
                owner_id,
                exc_info=True,
            )
            return False

    # ------------------------------------------------------------------
    # Result normalization / time / DB helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _result_state(result: Any) -> str:
        if isinstance(result, Mapping):
            value = result.get("status") or result.get("state")
        else:
            value = getattr(result, "status", None) or getattr(result, "state", None)
        value = getattr(value, "value", value)
        return str(value or "unknown").strip().lower()

    @staticmethod
    def _error_code_for_result(result: Any, state: str) -> str:
        # Task.status is the lifecycle authority.  A cancellation can race a
        # provider/auth result that was already serialized in result_data;
        # never let that stale payload replace the explicit cancellation
        # reason exposed by the batch contract.
        if state == "cancelled":
            return "CANCELLED"
        value = None
        if isinstance(result, Mapping):
            value = result.get("error_code") or result.get("code")
        else:
            value = getattr(result, "error_code", None) or getattr(result, "code", None)
        if value:
            # Callback/result payloads are an untrusted integration seam.  A
            # provider-specific string must not become a new public batch
            # error vocabulary by accident; normalize only the frozen codes
            # (plus the explicit cancellation projection).
            code = str(value).strip().upper()
            if code in BATCH_ITEM_ERROR_CODES or code == "CANCELLED":
                return code
        return "RUNNER_FAILED"

    @staticmethod
    def _blocked_reason_for_result(result: Any) -> str:
        if isinstance(result, Mapping):
            if result.get("aws_auth_required"):
                return "AWS_AUTH_REQUIRED"
            if result.get("generic_auth_required"):
                return "PROVIDER_AUTH_REQUIRED"
            value = result.get("error_code") or result.get("code")
        else:
            if getattr(result, "aws_auth_required", False):
                return "AWS_AUTH_REQUIRED"
            if getattr(result, "generic_auth_required", False):
                return "PROVIDER_AUTH_REQUIRED"
            value = getattr(result, "error_code", None) or getattr(result, "code", None)
        return str(value or "AWS_AUTH_REQUIRED")

    @staticmethod
    def _result_message(result: Any) -> str | None:
        if isinstance(result, Mapping):
            value = result.get("error_message") or result.get("error") or result.get("message")
        else:
            value = (
                getattr(result, "error_message", None)
                or getattr(result, "message", None)
                or getattr(result, "error", None)
            )
        return str(value)[:2000] if value else None

    @classmethod
    def _result_summary(cls, result: Any) -> dict[str, Any] | None:
        if isinstance(result, Mapping):
            raw = result.get("result_summary")
            if isinstance(raw, Mapping):
                value = dict(raw)
            else:
                raw_data = result.get("result_data")
                if isinstance(raw_data, str):
                    try:
                        decoded = json.loads(raw_data)
                    except (TypeError, ValueError, json.JSONDecodeError):
                        decoded = {}
                    value = dict(decoded) if isinstance(decoded, Mapping) else {}
                else:
                    value = {}
            # Keep only the light fields promised by the batch DTO.
            coverage = value.get("coverage_report") or {}
            summary: dict[str, Any] = {
                key: value[key]
                for key in ("compile_success", "test_count", "passed_count")
                if key in value
            }
            if isinstance(coverage, Mapping):
                if "line_coverage" in coverage:
                    summary["line_coverage"] = coverage.get("line_coverage")
                summary["coverage_available"] = not bool(
                    value.get("coverage_unavailable", False)
                )
            if summary:
                return summary
        return None

    @classmethod
    def _serialized_result_summary(cls, child: Task) -> str | None:
        """Project a terminal Task's lightweight result summary to JSON text."""

        summary = cls._result_summary(
            {
                "status": getattr(child, "status", None),
                "result_data": getattr(child, "result_data", None),
            }
        )
        return json.dumps(summary, ensure_ascii=False) if summary else None

    @staticmethod
    def _default_worker_id() -> str:
        host = socket.gethostname() or "host"
        return f"{host}:{os.getpid()}:{uuid.uuid4().hex[:12]}"

    def _db_now(self) -> datetime:
        value = self._now_factory()
        if not isinstance(value, datetime):
            value = datetime.now(timezone.utc)
        return self._as_naive_utc(value) or datetime.utcnow()

    @staticmethod
    def _as_naive_utc(value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is not None:
            return value.astimezone(timezone.utc).replace(tzinfo=None)
        return value

    async def _begin_write(self, session: AsyncSession) -> None:
        if session.in_transaction():
            raise RuntimeError("Batch dispatcher requires a clean database session")
        bind = session.get_bind()
        if bind.dialect.name == "sqlite":
            await session.execute(text("BEGIN IMMEDIATE"))
        else:
            await session.begin()


def aggregate_batch_counts(items: Iterable[Any]) -> BatchCounts:
    """Aggregate persisted Item states using the frozen wire vocabulary."""

    total = queued = running = passed = failed = 0
    for item in items:
        total += 1
        status = str(getattr(item, "status", item) or "").lower()
        if status == BatchItemStatus.QUEUED.value:
            queued += 1
        elif status == BatchItemStatus.RUNNING.value:
            running += 1
        elif status == BatchItemStatus.PASS.value:
            passed += 1
        elif status == BatchItemStatus.FAIL.value:
            failed += 1
        else:
            # Corrupt/unknown rows are conservatively counted as failed for
            # progress purposes; callers can still expose CHILD_STATUS_UNKNOWN
            # when projecting the row itself.
            failed += 1
    return BatchCounts(total, queued, running, passed, failed)


def calculate_batch_progress(items: Sequence[Any] | Iterable[Any]) -> int:
    """Calculate the canonical 0..100 progress from Item states/progress."""

    values = list(items)
    total = len(values)
    if total == 0:
        return 0
    completed = sum(
        1
        for item in values
        if getattr(item, "status", None)
        in (BatchItemStatus.PASS.value, BatchItemStatus.FAIL.value)
    )
    current = next(
        (
            max(0, min(int(getattr(item, "progress", 0) or 0), 100))
            for item in values
            if getattr(item, "status", None) == BatchItemStatus.RUNNING.value
        ),
        0,
    )
    result = (completed * 100 + current) // total
    return max(0, min(result, 100))


# Short aliases make the aggregate helpers discoverable to API DTO code while
# preserving one implementation of the progress/count contract.
compute_batch_counts = aggregate_batch_counts
compute_batch_progress = calculate_batch_progress
BatchDispatcher = BatchQueueDispatcher


__all__ = [
    "BatchCounts",
    "BatchClaim",
    "BatchDispatchOutcome",
    "ChildResult",
    "BatchQueueDispatcher",
    "BatchDispatcher",
    "DispatcherLeaseLost",
    "aggregate_batch_counts",
    "compute_batch_counts",
    "calculate_batch_progress",
    "compute_batch_progress",
]
