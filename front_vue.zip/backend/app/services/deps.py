"""
@file deps.py
@brief FastAPI dependency injection functions for services.

@version 3.2
@date 2026-07-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""

from typing import AsyncIterator
from fastapi import Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_optional_user_from_request
from app.models.task import Task
from app.services.unittest import (
    TaskService,
    ValidationService,
    FileService,
    LogParserService,
)


# ========== Service Dependencies ==========

async def get_task_service(
    db: AsyncSession = Depends(get_db),
) -> TaskService:
    """
    Get TaskService instance.

    Args:
        db: Database session (injected)

    Returns:
        TaskService instance
    """
    return TaskService(db)


async def get_validation_service(
    db: AsyncSession = Depends(get_db),
) -> ValidationService:
    """
    Get ValidationService instance.

    Args:
        db: Database session (injected)

    Returns:
        ValidationService instance
    """
    return ValidationService(db)


async def get_owned_unittest_task(
    task_id: str,
    request: Request,
    task_service: TaskService = Depends(get_task_service),
) -> Task:
    """Authorize task access before progress reads or lifecycle side effects.

    Retain the existing local anonymous identity for guest tasks. Download
    tokens grant artifact access only, never task lifecycle permissions.
    """
    user = get_optional_user_from_request(request, "anonymous")
    task = await task_service.get_owned_task(task_id, user["id"])
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task


async def get_file_service(
    db: AsyncSession = Depends(get_db),
) -> FileService:
    """
    Get FileService instance.

    Args:
        db: Database session (injected)

    Returns:
        FileService instance
    """
    return FileService(db)


async def get_log_parser_service(
    db: AsyncSession = Depends(get_db),
) -> LogParserService:
    """
    Get LogParserService instance.

    Args:
        db: Database session (injected)

    Returns:
        LogParserService instance
    """
    return LogParserService(db)
