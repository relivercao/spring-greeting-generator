"""Vision-based recovery for precision tables corrupted by Docling OCR."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import mimetypes
import re
from pathlib import Path
from typing import Any

import httpx
from loguru import logger
from PIL import Image

from app.core.config import get_settings
from app.services.driver_docling_vision_client import (
    DriverDoclingVisionClient,
    coerce_confidence,
)
from app.services.driver_docling_prompt_templates import (
    PROMPT_VERSION,
    PRECISION_EXTRACTION_SYSTEM_PROMPT,
    PRECISION_REPAIR_SYSTEM_PROMPT,
    PRECISION_VERIFICATION_SYSTEM_PROMPT,
    build_precision_extraction_prompt,
    build_precision_repair_prompt,
    build_precision_verification_prompt,
)


PRECISION_TABLE_MIN_CONFIDENCE = 0.90
PRECISION_TABLE_EXTRACTION_MIN_CONFIDENCE = 0.70
PRECISION_TABLE_MAX_ROWS = 64
PLUS_MINUS = "\u00b1"
FULL_WIDTH_PLUS_MINUS = "\uff0b\uff0f\uff0d"


class DriverDoclingPrecisionTableService:
    """Re-read suspicious precision tables from pixels and verify every row."""

    def __init__(self, vision_client: DriverDoclingVisionClient | None = None):
        self._vision = vision_client or DriverDoclingVisionClient()

    async def recover_tables(
        self,
        *,
        fallbacks: list[dict[str, Any]],
        image_output_dir: Path,
        source_name: str,
        timeout_seconds: float,
    ) -> list[dict[str, Any]]:
        if not fallbacks:
            return []

        try:
            router_url, api_key, model = self._vision.resolve_settings()
            timeout = httpx.Timeout(float(timeout_seconds))
            client = self._vision.create_http_client(router_url=router_url, timeout=timeout)
        except Exception as exc:
            return [
                self._failure(index, fallback, f"vision setup failed: {exc}")
                for index, fallback in enumerate(fallbacks)
            ]

        semaphore = asyncio.Semaphore(1)
        async with client:
            results = []
            for index, fallback in enumerate(fallbacks):
                results.append(
                    await self._recover_one(
                        index=index,
                        fallback=fallback,
                        image_output_dir=image_output_dir,
                        source_name=source_name,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                    )
                )
            return results

    async def _recover_one(
        self,
        *,
        index: int,
        fallback: dict[str, Any],
        image_output_dir: Path,
        source_name: str,
        semaphore: asyncio.Semaphore,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
    ) -> dict[str, Any]:
        image_path = self._resolve_image_path(
            str(fallback.get("image_markdown") or ""),
            image_output_dir,
        )
        if image_path is None or not image_path.is_file():
            return self._failure(index, fallback, "source table image is unavailable")

        expected_rows = max(1, len(fallback.get("table_rows") or []) - 1)
        image_data = base64.b64encode(image_path.read_bytes()).decode("ascii")
        media_type = mimetypes.guess_type(image_path.name)[0] or "image/png"
        original_table = str(fallback.get("table_markdown") or "")
        audit = self._image_audit(image_path, model)
        failure_stage = "extraction"

        try:
            extracted = await self._vision.request_image_json(
                image_data=image_data,
                media_type=media_type,
                prompt=self._extraction_prompt(source_name, original_table, expected_rows),
                system_prompt=PRECISION_EXTRACTION_SYSTEM_PROMPT,
                max_tokens=get_settings().DRIVER_DOCLING_PRECISION_TABLE_MAX_TOKENS,
                semaphore=semaphore,
                client=client,
                router_url=router_url,
                api_key=api_key,
                model=model,
            )
            audit["extraction_payload"] = extracted
            try:
                candidate_rows = self._normalize_rows(
                    extracted,
                    expected_rows=None,
                    require_verified=False,
                )
            except ValueError as exc:
                failure_stage = "extraction_repair"
                audit["extraction_validation_error"] = str(exc)
                repair_row_count = self._payload_row_count(extracted) or expected_rows
                repaired = await self._vision.request_image_json(
                    image_data=image_data,
                    media_type=media_type,
                    prompt=build_precision_repair_prompt(
                        payload=extracted,
                        error=str(exc),
                        expected_rows=repair_row_count,
                        require_verified=False,
                    ),
                    system_prompt=PRECISION_REPAIR_SYSTEM_PROMPT,
                    max_tokens=get_settings().DRIVER_DOCLING_PRECISION_TABLE_MAX_TOKENS,
                    semaphore=semaphore,
                    client=client,
                    router_url=router_url,
                    api_key=api_key,
                    model=model,
                )
                audit["extraction_repair_payload"] = repaired
                candidate_rows = self._normalize_rows(
                    repaired,
                    expected_rows=None,
                    require_verified=False,
                )

            failure_stage = "verification"
            verified = await self._vision.request_image_json(
                image_data=image_data,
                media_type=media_type,
                prompt=self._verification_prompt(candidate_rows, len(candidate_rows)),
                system_prompt=PRECISION_VERIFICATION_SYSTEM_PROMPT,
                max_tokens=get_settings().DRIVER_DOCLING_PRECISION_TABLE_MAX_TOKENS,
                semaphore=semaphore,
                client=client,
                router_url=router_url,
                api_key=api_key,
                model=model,
            )
            audit["verification_payload"] = verified
            try:
                verified_rows = self._normalize_rows(
                    verified,
                    expected_rows=len(candidate_rows),
                    require_verified=True,
                )
            except ValueError as exc:
                failure_stage = "verification_repair"
                audit["verification_validation_error"] = str(exc)
                repaired_verification = await self._vision.request_image_json(
                    image_data=image_data,
                    media_type=media_type,
                    prompt=build_precision_repair_prompt(
                        payload=verified,
                        error=str(exc),
                        expected_rows=len(candidate_rows),
                        require_verified=True,
                    ),
                    system_prompt=PRECISION_REPAIR_SYSTEM_PROMPT,
                    max_tokens=get_settings().DRIVER_DOCLING_PRECISION_TABLE_MAX_TOKENS,
                    semaphore=semaphore,
                    client=client,
                    router_url=router_url,
                    api_key=api_key,
                    model=model,
                )
                audit["verification_repair_payload"] = repaired_verification
                verified_rows = self._normalize_rows(
                    repaired_verification,
                    expected_rows=len(candidate_rows),
                    require_verified=True,
                )
        except Exception as exc:
            logger.warning("Precision table recovery failed for {}: {}", image_path, exc)
            return self._failure(
                index,
                fallback,
                str(exc),
                image_path=image_path,
                failure_stage=failure_stage,
                audit=audit,
            )

        return {
            "status": "success",
            "index": index,
            "image_path": str(image_path),
            "rows": verified_rows,
            "markdown": self._render_markdown(verified_rows),
            "minimum_confidence": min(float(row["confidence"]) for row in verified_rows),
            "original_table": original_table,
            "audit": audit,
        }

    @staticmethod
    def _resolve_image_path(image_markdown: str, image_output_dir: Path) -> Path | None:
        match = re.search(r"!\[[^\]]*]\(([^)\s]+)", image_markdown)
        if not match:
            return None
        raw_path = match.group(1).removeprefix("./")
        parts = Path(raw_path).parts
        if image_output_dir.name in parts:
            relative_parts = parts[parts.index(image_output_dir.name) + 1:]
            return image_output_dir.joinpath(*relative_parts).resolve()
        return (image_output_dir / Path(raw_path).name).resolve()

    @classmethod
    def _normalize_rows(
        cls,
        payload: Any,
        *,
        expected_rows: int | None,
        require_verified: bool,
    ) -> list[dict[str, Any]]:
        if not isinstance(payload, dict):
            raise ValueError("precision table response is not an object")
        if require_verified and payload.get("verified") is not True:
            raise ValueError("precision table verification did not pass")

        table_confidence = coerce_confidence(
            (payload.get("field_confidence") or {}).get("table")
            if isinstance(payload.get("field_confidence"), dict)
            else payload.get("confidence")
        )
        threshold = (
            PRECISION_TABLE_MIN_CONFIDENCE
            if require_verified
            else PRECISION_TABLE_EXTRACTION_MIN_CONFIDENCE
        )
        if table_confidence is None or table_confidence < threshold:
            raise ValueError("precision table confidence is below the required threshold")

        rows = payload.get("rows")
        if not isinstance(rows, list) or not 1 <= len(rows) <= PRECISION_TABLE_MAX_ROWS:
            raise ValueError("precision table response contains an invalid row count")
        if expected_rows is not None and len(rows) != expected_rows:
            raise ValueError(
                f"precision table row count mismatch: expected {expected_rows}, "
                f"received {len(rows)}"
            )

        normalized = []
        for row_index, row in enumerate(rows, start=1):
            if not isinstance(row, dict):
                raise ValueError(f"precision table row {row_index} is not an object")
            confidence = coerce_confidence(row.get("confidence"), table_confidence)
            if confidence is None or confidence < threshold:
                raise ValueError(f"precision table row {row_index} confidence is too low")
            if require_verified and row.get("verified") is not True:
                raise ValueError(f"precision table row {row_index} was not verified")

            symbol = str(row.get("symbol") or "").strip()
            item = re.sub(r"\s+", " ", str(row.get("item") or "").strip()).upper()
            value = cls._normalize_value(row.get("value"))
            if not symbol or not item or not cls._valid_value(value):
                raise ValueError(f"precision table row {row_index} contains invalid cells")
            normalized.append(
                {
                    "symbol": symbol,
                    "item": item,
                    "value": value,
                    "confidence": round(float(confidence), 4),
                }
            )
        return normalized

    @staticmethod
    def _normalize_value(value: Any) -> str:
        return (
            str(value or "")
            .strip()
            .replace("+/-", PLUS_MINUS)
            .replace(FULL_WIDTH_PLUS_MINUS, PLUS_MINUS)
            .replace(" ", "")
        )

    @staticmethod
    def _valid_value(value: str) -> bool:
        number = r"\d+(?:\.\d+)?"
        return bool(
            re.fullmatch(number, value)
            or re.fullmatch(rf"{number}{re.escape(PLUS_MINUS)}{number}", value)
            or re.fullmatch(rf"{number}(?:~|-){number}", value)
        )

    @staticmethod
    def _render_markdown(rows: list[dict[str, Any]]) -> str:
        output = [
            "| SYMBOL | ITEM | DATA(um) |",
            "|--------|------|----------|",
        ]
        for row in rows:
            symbol = str(row["symbol"]).replace("|", "\\|")
            item = str(row["item"]).replace("|", "\\|")
            value = str(row["value"]).replace("|", "\\|")
            output.append(f"| {symbol} | {item} | {value} |")
        return "\n".join(output)

    @staticmethod
    def _extraction_prompt(source_name: str, original_table: str, expected_rows: int) -> str:
        return build_precision_extraction_prompt(
            source_name=source_name,
            original_table=original_table,
            expected_rows=expected_rows,
        )

    @staticmethod
    def _verification_prompt(rows: list[dict[str, Any]], expected_rows: int) -> str:
        return build_precision_verification_prompt(
            rows=rows,
            expected_rows=expected_rows,
        )

    @staticmethod
    def _payload_row_count(payload: Any) -> int | None:
        rows = payload.get("rows") if isinstance(payload, dict) else None
        if isinstance(rows, list) and 1 <= len(rows) <= PRECISION_TABLE_MAX_ROWS:
            return len(rows)
        return None

    @staticmethod
    def _image_audit(image_path: Path, model: str) -> dict[str, Any]:
        width = None
        height = None
        try:
            with Image.open(image_path) as image:
                width, height = image.size
        except OSError:
            pass
        return {
            "prompt_version": PROMPT_VERSION,
            "model": model,
            "image_name": image_path.name,
            "image_width": width,
            "image_height": height,
            "image_sha256": hashlib.sha256(image_path.read_bytes()).hexdigest(),
        }

    @staticmethod
    def _failure(
        index: int,
        fallback: dict[str, Any],
        error: str,
        *,
        image_path: Path | None = None,
        failure_stage: str = "setup",
        audit: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "status": "failed",
            "index": index,
            "image_path": str(image_path or ""),
            "error": error,
            "failure_stage": failure_stage,
            "original_table": str(fallback.get("table_markdown") or ""),
            "audit": audit or {},
        }
