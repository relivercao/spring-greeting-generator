"""Batch Unit-Test runtime wiring shared by the FastAPI lifecycle."""

import asyncio
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from functools import partial
import os
import re
from typing import Any

from fastapi import FastAPI
from sqlalchemy import select

from app.core.config import DEFAULT_BATCH_DISPATCHER_LEASE_SECONDS, get_settings
from app.core.database import async_session_factory
from app.models.task import Task

settings = get_settings()


def _batch_worker_owner_is_dead(owner_id: str) -> bool:
    """Return whether a previous dispatcher worker process has exited.

    Production worker ids are ``<hostname>:<pid>:<nonce>``.  Lease takeover
    must not start/reuse a child while that process can still own an external
    CLI/QBS process, so the dispatcher gets a conservative process-liveness
    guard.  Unknown/test ids fail closed; those callers can inject their own
    observer directly into ``BatchQueueDispatcher``.
    """

    match = re.match(r"^.+:(\d+):[0-9a-fA-F-]{8,}$", str(owner_id or ""))
    if not match:
        return False
    try:
        pid = int(match.group(1))
        if pid <= 0 or pid == os.getpid():
            # A live current process is definitely not safe to take over.
            return False
        try:
            import psutil

            return not psutil.pid_exists(pid)
        except ImportError:
            # Without psutil, use the portable Windows/POSIX kill probe.  A
            # permission error means the process may still be alive, so fail
            # closed rather than risking duplicate external work.
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return True
            except PermissionError:
                return False
            except OSError:
                return True
            return False
    except (TypeError, ValueError):
        return False


async def _run_batch_unittest_child(
    batch,
    item,
    unit_input,
    *,
    runner,
    llm_bridge,
    mcp_client,
    skill_registry,
    session_factory=None,
) -> Any:
    """Run one already-persisted batch child through the legacy Unit-Test path."""

    from app.api.v1.endpoints.unittest import (
        _init_progress,
        _mark_workspace_active,
        _release_workspace,
        _run_unittest_task,
        _task_cancelled,
        _task_progress,
    )

    factory = session_factory or async_session_factory
    task_id = unit_input.task_id

    # The dispatcher committed Task/BatchItem association before invoking this
    # callback.  Publish the child as running without reviving a concurrent
    # cancellation or an already-terminal child.
    async with factory() as session:
        child = await session.scalar(select(Task).where(Task.id == task_id))
        if child is None:
            raise RuntimeError(f"Batch child Task {task_id} is missing")
        if child.status in {"completed", "failed", "cancelled", "paused"}:
            return {
                "status": child.status,
                "progress": child.progress or 0,
                "message": child.message,
                "error_message": child.error_message,
                "result_data": child.result_data,
            }
        if _task_cancelled.get(task_id):
            child.status = "cancelled"
            child.message = "Task cancelled by user"
            child.error_message = "Task cancelled by user"
            await session.commit()
            return {
                "status": "cancelled",
                "progress": child.progress or 0,
                "message": child.message,
                "error_message": child.error_message,
            }
        child.status = "running"
        child.message = "Unit test generation task started"
        await session.commit()

    # Match the existing single-file endpoint's context shape.  In particular,
    # source_files/source_contents use the uploaded filename while
    # source_path_map retains the immutable real path from BatchItem.
    source_text = next(iter(unit_input.source_contents.values()), "")
    execution_input = replace(
        unit_input,
        source_files=[item.filename],
        source_contents={item.filename: source_text},
        source_path_map={item.filename: item.source_path},
        output_dir=batch.project_root,
    )

    _init_progress(
        task_id,
        meta={
            "title": item.filename,
            "source_filename": item.filename,
            "source_full_path": item.source_path,
            "output_dir": batch.project_root,
        },
    )
    _mark_workspace_active(task_id)

    try:
        execution = runner.prepare_execution(
            execution_input,
            llm_bridge=llm_bridge,
            mcp_client=mcp_client,
            skill_registry=skill_registry,
        )
        future = runner.run_existing(
            task_id,
            execution.agent,
            execution.task_desc,
            execution.context,
            execution.context_config,
            execution.agent_config,
            run_callable=_run_unittest_task,
        )
        return await runner.wait(future)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        # _run_unittest_task persists all failures occurring after it starts.
        # This guard covers only preparation/scheduling failures.
        entry = _task_progress.get(task_id)
        # The legacy runner raises an HTTPException after persisting a
        # recoverable provider/AWS authentication pause.  Preserve that
        # paused marker in the in-memory progress registry: the batch resume
        # bridge consults it before invoking the shared resume flow.  Turning
        # it into ``failed`` here would leave the database child paused while
        # making every subsequent resume request return ``not paused``.
        auth_paused = bool(
            entry
            and (
                entry.get("aws_auth_required")
                or entry.get("generic_auth_required")
                or entry.get("status") == "paused"
            )
        )
        if entry is not None and not auth_paused:
            entry["status"] = "failed"
            entry["progress"] = -1
            entry["message"] = "Failed to start Unit-Test child"
            entry["error"] = str(exc)
        async with factory() as session:
            child = await session.scalar(select(Task).where(Task.id == task_id))
            if child is not None and child.status in {"pending", "running"}:
                child.status = "failed"
                child.progress = -1
                child.message = "Failed to start Unit-Test child"
                child.error_message = str(exc)
                await session.commit()
        await _release_workspace(task_id)
        from app.api.v1.endpoints.unittest import _schedule_progress_cleanup

        if not auth_paused:
            _schedule_progress_cleanup(task_id)
        raise


async def _cancel_batch_unittest_child(
    task_id: str,
    *,
    session_factory=None,
) -> Any:
    """Delegate batch cancellation to the existing Unit-Test cleanup path."""

    from app.api.v1.endpoints.unittest import cancel_unittest_task

    factory = session_factory or async_session_factory
    async with factory() as session:
        child = await session.scalar(
            select(Task).where(Task.id == task_id, Task.agent_type == "unittest")
        )
        if child is None:
            return {"status": "not_found"}
        return await cancel_unittest_task(task_id, task=child, db=session)


async def _resume_batch_unittest_child(
    batch_id: str,
    task_id: str,
    *,
    session_factory=None,
) -> bool:
    """Resume a batch child through the existing single-file resume flow.

    The ordinary endpoint owns provider/AWS validation, sidecar restoration,
    and the process-local workspace reservation.  Calling that service
    directly keeps batch resume on the same child ID without an HTTP loopback.
    Resolve the persisted child within the dispatcher-selected batch before
    invoking the lifecycle operation without an HTTP request.
    """

    from app.api.v1.endpoints.unittest import resume_unittest_task

    factory = session_factory or async_session_factory
    async with factory() as session:
        child = await session.scalar(
            select(Task).where(
                Task.id == task_id,
                Task.agent_type == "unittest",
                Task.batch_task_id == batch_id,
            )
        )
        if child is None:
            return False
        response = await resume_unittest_task(task_id, task=child, db=session)
    return bool(isinstance(response, dict) and response.get("status") == "running")


async def _start_batch_dispatcher(
    app: FastAPI,
    log,
    *,
    session_factory=None,
    dispatcher_factory=None,
):
    """Wire and start the production BatchQueueDispatcher."""

    from app.api.v1.endpoints.unittest import (
        _is_workspace_owner_dead,
        _running_tasks,
        _task_progress,
        _workspace_lease_manager,
    )
    from app.services.batch_dispatcher import BatchQueueDispatcher
    from app.services.batch_input_store import BatchInputStore
    from app.services.unittest_runner import UnitTestRunner

    factory = session_factory or async_session_factory
    dispatcher_type = dispatcher_factory or BatchQueueDispatcher
    runner = UnitTestRunner(running_tasks=_running_tasks)
    dispatcher = dispatcher_type(
        factory,
        BatchInputStore(settings=settings),
        runner=runner,
        run_child=partial(
            _run_batch_unittest_child,
            runner=runner,
            llm_bridge=app.state.llm_bridge,
            mcp_client=app.state.mcp_client,
            skill_registry=app.state.skill_registry,
            session_factory=factory,
        ),
        cancel_child=partial(
            _cancel_batch_unittest_child,
            session_factory=factory,
        ),
        resume_child=partial(
            _resume_batch_unittest_child,
            session_factory=factory,
        ),
        workspace_manager=_workspace_lease_manager,
        workspace_owner_is_dead=_is_workspace_owner_dead,
        takeover_guard=_batch_worker_owner_is_dead,
        # The ordinary endpoint keeps rich stage progress in memory.  The
        # dispatcher mirrors this snapshot into persisted BatchItem fields so
        # polling another process still reports meaningful current progress.
        progress_provider=lambda child_id: _task_progress.get(child_id),
        settings=settings,
    )
    app.state.batch_dispatcher = dispatcher

    reconciled = await dispatcher.reconcile_after_restart()
    if reconciled:
        log.warning(
            "Reconciled stale Batch Unit-Test children after startup",
            count=reconciled,
        )
    started = await dispatcher.start()
    if started:
        log.info("Batch Unit-Test dispatcher started", worker_id=dispatcher.worker_id)
    else:
        log.info("Batch Unit-Test dispatcher is in standby")
    return dispatcher


async def _cleanup_orphan_batch_snapshots(
    log,
    *,
    snapshot_store=None,
    session_factory=None,
) -> None:
    """Remove stale orphan and retention-expired batch snapshot directories.

    Orphan cleanup is deliberately separate from retention cleanup.  A
    finalized directory with a queued/running ``BatchTask`` owner must remain
    executable regardless of age; only terminal batches beyond the configured
    retention window are eligible for removal.
    """
    try:
        from app.models.batch import BatchTask
        from app.services.batch_input_store import BatchInputStore

        store = snapshot_store or BatchInputStore()
        factory = session_factory or async_session_factory
        async with factory() as session:
            result = await session.execute(
                select(
                    BatchTask.id,
                    BatchTask.status,
                    BatchTask.created_at,
                    BatchTask.finished_at,
                )
            )
            rows = list(result.all())

        referenced_ids = tuple(row.id for row in rows)
        now = datetime.now(timezone.utc)
        retention_days = max(1, int(getattr(store, "retention_days", 30)))
        cutoff = now - timedelta(days=retention_days)
        terminal_ids: list[str] = []
        for row in rows:
            if str(row.status or "").lower() != "done":
                continue
            # ``finished_at`` is preferred because it reflects the lifetime
            # users care about.  Very old databases may not have populated it;
            # fall back to creation time while still keeping the operation
            # restricted to terminal rows.
            timestamp = row.finished_at or row.created_at
            if timestamp is None:
                continue
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=timezone.utc)
            if timestamp <= cutoff:
                terminal_ids.append(str(row.id))

        removed = await asyncio.to_thread(store.cleanup_orphans, referenced_ids)
        if removed:
            log.warning(
                "Removed orphan Batch Unit-Test snapshots during startup",
                count=len(removed),
            )

        expired = await asyncio.to_thread(
            store.cleanup_expired,
            terminal_ids,
            now.timestamp(),
            retention_days=retention_days,
        )
        if expired:
            log.warning(
                "Removed retention-expired Batch Unit-Test snapshots during startup",
                count=len(expired),
            )
    except Exception as exc:
        # Snapshot cleanup is maintenance work; a locked/corrupt directory must
        # not make the API unavailable during startup.
        log.warning(
            "Failed to clean up orphan Batch Unit-Test snapshots during startup",
            error=str(exc),
        )

