"""Persist and securely serve documents created through Chat Agent."""

from __future__ import annotations

import csv
import hashlib
import hmac
import html
import io
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import quote
from uuid import uuid4

from app.core.config import get_settings


_ALLOWED_EXTENSIONS = {".txt", ".md", ".markdown", ".doc", ".docx", ".html", ".htm", ".csv", ".xls", ".xlsx", ".pptx"}
_SAFE_NAME = re.compile(r"[^A-Za-z0-9._-]+")
_SAFE_ID = re.compile(r"^[a-f0-9]{32}$")
_MAX_CONTENT_BYTES = 5 * 1024 * 1024
_MAX_SPREADSHEET_ROWS = 5000
_MAX_SPREADSHEET_COLUMNS = 100
_DOCUMENT_EXTENSION_PATTERN = r"markdown|docx|xlsx|pptx|html|htm|csv|txt|md|doc|xls|ppt"
_PRESENTATION_TERMS = r"(?<![a-z])(?:pptx?|powerpoint|presentation|slides?|slide\s+deck)(?![a-z])|\u5e7b\u706f\u7247|\u6f14\u793a\u6587\u7a3f"


def requested_document_format(message: str) -> str | None:
    """Return a supported extension only for explicit document-creation requests."""
    text = (message or "").lower()
    extension = re.search(rf"\.({_DOCUMENT_EXTENSION_PATTERN})\b", text)
    document_terms = (
        _PRESENTATION_TERMS + r"|document|documentation|file|report|spreadsheet|excel|word|doc|readme|guide|manual|notes|"
        r"\u6587\u6863|\u6587\u4ef6|\u62a5\u544a|\u8868\u683c|\u7535\u5b50\u8868\u683c|word|excel"
    )
    action_terms = (
        r"create|generate|write|draft|export|make|prepare|compose|"
        r"\u751f\u6210|\u521b\u5efa|\u5236\u4f5c|\u7f16\u5199|\u5199|\u5bfc\u51fa|\u6574\u7406"
    )
    if not re.search(action_terms, text) or not (extension or re.search(document_terms, text)):
        return None
    if extension:
        return ".pptx" if extension.group(1) == "ppt" else "." + extension.group(1)
    if re.search(_PRESENTATION_TERMS, text):
        return ".pptx"
    if re.search(r"spreadsheet|excel|\u8868\u683c|\u7535\u5b50\u8868\u683c", text):
        return ".xlsx"
    if re.search(r"html|web page|\u7f51\u9875", text):
        return ".html"
    if re.search(r"word|docx|doc|word\s+\u6587\u6863", text):
        return ".docx"
    if re.search(r"plain text|text file|txt", text):
        return ".txt"
    if re.search(r"csv", text):
        return ".csv"
    return ".md"


@dataclass(frozen=True)
class ChatArtifact:
    """A saved document and its unguessable open URL."""

    artifact_id: str
    filename: str
    path: str
    url: str
    size_bytes: int

    @property
    def download_url(self) -> str:
        """Reuse the open URL with an explicit attachment disposition."""
        separator = "&" if "?" in self.url else "?"
        return f"{self.url}{separator}download=true"


class ChatArtifactError(ValueError):
    """Raised when generated document data is unsafe or unsupported."""


class ChatArtifactService:
    """Store generated documents below OUTPUT_DIR and issue durable links."""

    def __init__(self, output_root: str | Path, secret_key: str, api_prefix: str = "/api/v1"):
        self.output_root = Path(output_root).expanduser().resolve()
        self.secret_key = secret_key.encode("utf-8")
        self.api_prefix = "/" + api_prefix.strip("/")

    @classmethod
    def from_settings(cls) -> "ChatArtifactService":
        settings = get_settings()
        output_root = Path(settings.OUTPUT_DIR).expanduser()
        if not output_root.is_absolute():
            output_root = Path(__file__).resolve().parents[2] / output_root
        return cls(output_root, settings.SECRET_KEY, settings.API_V1_PREFIX)

    def save_document(
        self,
        *,
        user_id: str,
        session_id: str,
        filename: str,
        content: Any,
    ) -> ChatArtifact:
        safe_name = self._safe_filename(filename)
        encoded = self._encode_document(safe_name, content)
        if not encoded or len(encoded) > _MAX_CONTENT_BYTES:
            raise ChatArtifactError("Generated document is empty or exceeds the 5 MB limit")

        owner_hash = hashlib.sha256(str(user_id).encode("utf-8")).hexdigest()[:32]
        session_hash = hashlib.sha256(str(session_id).encode("utf-8")).hexdigest()[:32]
        # The UUID4 path component is the durable bearer capability for this file.
        artifact_id = uuid4().hex
        artifact_dir = (self.output_root / "chat" / owner_hash / session_hash).resolve()
        if self.output_root not in artifact_dir.parents:
            raise ChatArtifactError("Invalid generated document path")
        artifact_dir.mkdir(parents=True, exist_ok=True)
        target = (artifact_dir / f"{artifact_id}-{safe_name}").resolve()
        if target.parent != artifact_dir:
            raise ChatArtifactError("Invalid generated document path")
        target.write_bytes(encoded)

        url = (
            f"{self.api_prefix}/chat/artifacts/{owner_hash}/{session_hash}/"
            f"{artifact_id}/{quote(safe_name)}"
        )
        return ChatArtifact(
            artifact_id=artifact_id,
            filename=safe_name,
            path=str(target),
            url=url,
            size_bytes=len(encoded),
        )

    def resolve_signed_artifact(
        self,
        *,
        owner_hash: str,
        session_hash: str,
        artifact_id: str,
        filename: str,
        expires: int | None = None,
        signature: str | None = None,
    ) -> Path | None:
        if not all(_SAFE_ID.fullmatch(value) for value in (owner_hash, session_hash, artifact_id)):
            return None
        try:
            safe_name = self._safe_filename(filename)
        except ChatArtifactError:
            return None
        if safe_name != filename:
            return None

        relative_path = Path("chat") / owner_hash / session_hash / f"{artifact_id}-{safe_name}"
        if expires is not None or signature is not None:
            if expires is None or signature is None:
                return None
            expected = self._signature(expires, relative_path.as_posix())
            if not hmac.compare_digest(signature, expected):
                return None
        path = (self.output_root / relative_path).resolve()
        if self.output_root not in path.parents or not path.is_file():
            return None
        return path

    def _signature(self, expires: int, relative_path: str) -> str:
        payload = f"{expires}\n{relative_path}".encode("utf-8")
        return hmac.new(self.secret_key, payload, hashlib.sha256).hexdigest()

    @staticmethod
    def _safe_filename(filename: str) -> str:
        name = Path(str(filename).replace("\\", "/")).name.strip()
        suffix = Path(name).suffix.lower()
        if suffix not in _ALLOWED_EXTENSIONS:
            raise ChatArtifactError("Unsupported document format")
        stem = _SAFE_NAME.sub("_", Path(name).stem).strip("._-") or "document"
        return f"{stem[:100]}{suffix}"

    @classmethod
    def _encode_document(cls, filename: str, content: Any) -> bytes:
        suffix = Path(filename).suffix.lower()
        if suffix == ".pptx":
            from app.services.chat_presentations import encode_presentation

            return encode_presentation(content)
        if suffix == ".docx":
            return cls._encode_docx(content)
        if suffix == ".doc":
            text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False, indent=2)
            body = "".join(f"<p>{html.escape(line)}</p>" for line in text.splitlines() or [text])
            return f"<!doctype html><html><head><meta charset=\"utf-8\"></head><body>{body}</body></html>".encode("utf-8")
        if suffix == ".xlsx":
            return cls._encode_xlsx(content)
        if suffix == ".xls":
            return cls._encode_xls(content)
        if suffix == ".csv":
            return cls._encode_csv(content)
        if isinstance(content, str):
            text = content
        else:
            text = json.dumps(content, ensure_ascii=False, indent=2)
        return text.encode("utf-8")

    @staticmethod
    def _encode_docx(content: Any) -> bytes:
        from docx import Document

        document = Document()
        text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False, indent=2)
        for line in text.splitlines() or [text]:
            stripped = line.strip()
            if stripped.startswith("### "):
                document.add_heading(stripped[4:], level=3)
            elif stripped.startswith("## "):
                document.add_heading(stripped[3:], level=2)
            elif stripped.startswith("# "):
                document.add_heading(stripped[2:], level=1)
            elif stripped.startswith(("- ", "* ")):
                document.add_paragraph(stripped[2:], style="List Bullet")
            else:
                document.add_paragraph(line)
        output = io.BytesIO()
        document.save(output)
        return output.getvalue()

    @classmethod
    def _encode_xlsx(cls, content: Any) -> bytes:
        from openpyxl import Workbook

        rows = cls._spreadsheet_rows(content)
        if len(rows) > _MAX_SPREADSHEET_ROWS or any(len(row) > _MAX_SPREADSHEET_COLUMNS for row in rows):
            raise ChatArtifactError("Spreadsheet exceeds the row or column limit")
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Document"
        for row in rows:
            safe_row = []
            for cell in row:
                if isinstance(cell, (int, float, bool)) or cell is None:
                    safe_row.append(cell)
                    continue
                safe_row.append(cls._spreadsheet_text(cell))
            sheet.append(safe_row)
        output = io.BytesIO()
        workbook.save(output)
        return output.getvalue()

    @classmethod
    def _encode_xls(cls, content: Any) -> bytes:
        rows = cls._spreadsheet_rows(content)
        table_rows = "".join(
            "<tr>" + "".join(
                f"<td>{html.escape(ChatArtifactService._spreadsheet_text(cell))}</td>"
                for cell in row
            ) + "</tr>"
            for row in rows
        )
        document = f"<!doctype html><html><head><meta charset=\"utf-8\"></head><body><table>{table_rows}</table></body></html>"
        return document.encode("utf-8")

    @classmethod
    def _encode_csv(cls, content: Any) -> bytes:
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        for row in cls._spreadsheet_rows(content):
            writer.writerow([
                cell if isinstance(cell, (int, float, bool)) or cell is None
                else cls._spreadsheet_text(cell)
                for cell in row
            ])
        return output.getvalue().encode("utf-8")

    @staticmethod
    def _spreadsheet_text(value: Any) -> str:
        text = str(value if value is not None else "")
        return "'" + text if text.lstrip().startswith(("=", "+", "-", "@")) else text

    @staticmethod
    def _spreadsheet_rows(content: Any) -> list[list[Any]]:
        value = content
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError:
                lines = [line.strip() for line in value.splitlines() if line.strip()]
                if lines and all(line.startswith("|") and line.endswith("|") for line in lines):
                    values = [[cell.strip() for cell in line.strip("|").split("|")] for line in lines]
                    value = [row for row in values if not all(re.fullmatch(r":?-{3,}:?", cell) for cell in row)]
                else:
                    value = list(csv.reader(io.StringIO(value)))
        if isinstance(value, dict):
            value = value.get("rows") or value.get("data") or [[key, item] for key, item in value.items()]
        if not isinstance(value, list):
            value = [[value]]
        rows = [row if isinstance(row, list) else [row] for row in value]
        return rows or [[""]]


def artifact_media_type(filename: str) -> str:
    suffix = Path(filename).suffix.lower()
    return {
        ".txt": "text/plain; charset=utf-8",
        ".md": "text/markdown; charset=utf-8",
        ".markdown": "text/markdown; charset=utf-8",
        ".html": "text/html; charset=utf-8",
        ".htm": "text/html; charset=utf-8",
        ".csv": "text/csv; charset=utf-8",
        ".doc": "application/msword",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xls": "application/vnd.ms-excel",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    }.get(suffix, "application/octet-stream")
