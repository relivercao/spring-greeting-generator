"""Shared database and WebSocket lifecycle helpers for asynchronous Agents."""

from __future__ import annotations

import asyncio
import json
from typing import Any, Optional

from fastapi.encoders import jsonable_encoder
from sqlalchemy import select

from app.agents.base import AgentResult, AgentStatus
from app.core.database import async_session_factory
from app.core.ws_manager import ws_manager
from app.models.task import Task


class AgentTaskRegistry:
    """Track in-process background Agents so status and cancellation stay consistent."""

    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task] = {}
        self._agents: dict[str, Any] = {}

    def register(self, task_id: str, background_task: asyncio.Task, agent: Any) -> None:
        """Register one background task and its Agent instance."""
        self._tasks[task_id] = background_task
        self._agents[task_id] = agent

    def get_task(self, task_id: str) -> Optional[asyncio.Task]:
        """Return the running asyncio task, if it is still known."""
        return self._tasks.get(task_id)

    def get_agent(self, task_id: str) -> Any:
        """Return the running Agent instance, if it is still known."""
        return self._agents.get(task_id)

    def remove(self, task_id: str) -> None:
        """Forget a completed background task and its Agent."""
        self._tasks.pop(task_id, None)
        self._agents.pop(task_id, None)

    async def cancel(self, task_id: str) -> bool:
        """Cancel an Agent and its wrapper task without imposing a timeout."""
        agent = self.get_agent(task_id)
        if agent is not None:
            await agent.cancel(task_id)
        background_task = self.get_task(task_id)
        if background_task and not background_task.done():
            background_task.cancel()
            return True
        return agent is not None


agent_task_registry = AgentTaskRegistry()


def load_json_object(value: Optional[str]) -> dict[str, Any]:
    """Load a stored JSON object and return an empty object for invalid data."""
    if not value:
        return {}
    try:
        parsed = json.loads(value)
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def serialize_task(task: Task) -> dict[str, Any]:
    """Serialize one asynchronous task for frontend polling."""
    return {
        "task_id": task.id,
        "agent_type": task.agent_type,
        "status": task.status,
        "progress": task.progress,
        "message": task.message,
        "error": task.error_message,
        "input": load_json_object(task.input_data),
        "result": load_json_object(task.result_data) if task.result_data else None,
        "duration_ms": task.duration_ms,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "updated_at": task.updated_at.isoformat() if task.updated_at else None,
    }


def serialize_agent_result(result: AgentResult) -> dict[str, Any]:
    """Convert an Agent result, including typed subclass fields, to JSON data."""
    encoded = jsonable_encoder(result)
    if not isinstance(encoded, dict):
        return {"value": encoded}
    result_data = encoded.pop("data", None)
    if isinstance(result_data, dict):
        encoded.update(result_data)
    return encoded


def task_usage_for_agent(agent: Any, task_id: str) -> dict[str, int]:
    """Read task-scoped LLM usage from an Agent's bridge when available."""
    bridge = getattr(agent, "_llm", None)
    if bridge is None or not hasattr(bridge, "get_task_usage"):
        return {}
    return dict(bridge.get_task_usage(task_id) or {})


async def update_task_progress(
    task_id: str,
    progress: int,
    stage: str,
    message: str,
    details: Optional[dict[str, Any]] = None,
) -> None:
    """Persist and publish a non-terminal task progress update."""
    bounded_progress = max(0, min(progress, 99))
    persisted = False
    async with async_session_factory() as session:
        result = await session.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task and task.status == AgentStatus.RUNNING.value:
            task.progress = bounded_progress
            task.message = message
            await session.commit()
            persisted = True
    if persisted:
        await ws_manager.send_progress(task_id, bounded_progress, stage, message, details)


async def complete_task(result: AgentResult, result_data: Optional[dict[str, Any]] = None) -> None:
    """Persist and publish an Agent terminal result."""
    stored_data = result_data if result_data is not None else result.data
    persisted = False
    async with async_session_factory() as session:
        db_result = await session.execute(select(Task).where(Task.id == result.task_id))
        task = db_result.scalar_one_or_none()
        if task and task.status == AgentStatus.RUNNING.value:
            task.status = result.status.value
            task.progress = 100 if result.status == AgentStatus.COMPLETED else 0
            task.message = result.message
            task.result_data = (
                json.dumps(stored_data, ensure_ascii=False) if stored_data is not None else None
            )
            task.error_message = "\n".join(result.errors) if result.errors else None
            task.duration_ms = result.duration_ms
            await session.commit()
            persisted = True

    if not persisted:
        return
    if result.status == AgentStatus.COMPLETED:
        await ws_manager.send_complete(result.task_id, stored_data)
    else:
        await ws_manager.send_error(result.task_id, result.message)


async def fail_task(task_id: str, message: str) -> None:
    """Persist and publish an unexpected background task failure."""
    persisted = False
    async with async_session_factory() as session:
        result = await session.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task and task.status == AgentStatus.RUNNING.value:
            task.status = AgentStatus.FAILED.value
            task.progress = 0
            task.message = "Task failed"
            task.error_message = message
            await session.commit()
            persisted = True
    if persisted:
        await ws_manager.send_error(task_id, message)


async def mark_task_cancelled(task_id: str, message: str) -> None:
    """Persist and publish a cancellation requested outside the Agent."""
    persisted = False
    async with async_session_factory() as session:
        result = await session.execute(select(Task).where(Task.id == task_id))
        task = result.scalar_one_or_none()
        if task and task.status == AgentStatus.RUNNING.value:
            task.status = AgentStatus.CANCELLED.value
            task.progress = 0
            task.message = message
            task.error_message = message
            await session.commit()
            persisted = True
    if persisted:
        await ws_manager.send_error(task_id, message)
