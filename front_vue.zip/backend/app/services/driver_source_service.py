"""
@file driver_source_service.py
@brief Service for managing driver source file uploads and parsing.

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import concurrent.futures
import json
import mimetypes
import shutil
import threading
from time import monotonic
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any
from uuid import uuid4

from loguru import logger

from app.core.config import _BACKEND_DIR
from app.core.knowledge_base_paths import get_knowledge_base_paths
from app.models.driver_agent import (
    DriverSourceParseStatus,
    DriverSourceType,
    DriverSourceUploadStatus,
    MAX_DRIVER_SOURCE_FILES,
    VALID_DRIVER_SOURCE_TYPES,
)
from app.repositories.driver_conversation import DriverConversationRepository
from app.services.driver_docling_service import (
    DIRECT_TEXT_EXTENSIONS,
    DOCLING_SUPPORTED_EXTENSIONS,
    DriverDoclingService,
)
from app.services.driver_docling_progress import DoclingProgress
from app.services.knowledge_base import KnowledgeBaseService

# Allowed file extensions. Legacy binary .doc is not supported by Docling.
ALLOWED_EXTENSIONS = DOCLING_SUPPORTED_EXTENSIONS | DIRECT_TEXT_EXTENSIONS

# Input and persistence limits.
MAX_FILE_SIZE = 50 * 1024 * 1024
MAX_FILES_PER_UPLOAD = MAX_DRIVER_SOURCE_FILES
MAX_FILENAME_CHARS = 240
MAX_ARTIFACT_NAME_CHARS = 120
PARSE_WORKER_COUNT = 1
PARSE_POLL_INTERVAL_SECONDS = 1.0
MAX_STORED_SUMMARY_CHARS = 5_000
MAX_STORED_METADATA_CHARS = 100_000
MIN_VALID_MARKDOWN_CHARS = 50
KNOWLEDGE_DOCUMENT_ID_PREFIX = "driver_"

# In-band marker Docling returns instead of raising when a parse is cancelled.
PARSE_CANCELLED_MARKER = "CANCELLED"
# Suffix for the directory holding the previous parse artifacts while a
# replacement parse runs. Kept distinct from any real artifact stem so a stash
# left behind by a crash is recognizable.
PARSE_STASH_SUFFIX = ".superseded-"
CORRUPTION_SAMPLE_CHARS = 500
MAX_CORRUPTION_RATIO = 0.1
DEFAULT_UPLOAD_DIR = _BACKEND_DIR / "data" / "uploads" / "driver"

_parse_executor: concurrent.futures.ThreadPoolExecutor | None = None
_parse_executor_lock = threading.Lock()
# Source parse serialization is process-local. The threading guard protects
# this in-memory registry while each asyncio.Lock serializes one source_id
# within the current worker process only. Multi-worker deployments need a
# cross-process parse lease, e.g. database, Redis, or file lock, before relying
# on this for duplicate parse prevention across workers.
_source_parse_locks: dict[str, dict[str, Any]] = {}
_source_parse_locks_guard = threading.Lock()


def get_driver_source_parse_executor() -> concurrent.futures.ThreadPoolExecutor:
    """Return the shared worker used for blocking Docling source conversions."""
    global _parse_executor
    with _parse_executor_lock:
        if _parse_executor is None:
            _parse_executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=PARSE_WORKER_COUNT,
                thread_name_prefix="driver-source-parse",
            )
        return _parse_executor


def shutdown_driver_source_parse_executor() -> None:
    """Stop the shared source parse executor during application shutdown."""
    global _parse_executor
    with _parse_executor_lock:
        executor = _parse_executor
        _parse_executor = None
    if executor is not None:
        executor.shutdown(wait=False, cancel_futures=True)


def _run_parse_coroutine_in_thread(coro: Any) -> Any:
    """Run an async Docling parse in a worker thread and drain loop resources."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
        for task in pending:
            task.cancel()
        if pending:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.run_until_complete(loop.shutdown_default_executor())
        asyncio.set_event_loop(None)
        loop.close()


@asynccontextmanager
async def serialize_source_parse(source_id: str):
    """Serialize parse attempts for one uploaded source within this worker."""
    with _source_parse_locks_guard:
        entry = _source_parse_locks.get(source_id)
        if entry is None:
            entry = {"lock": asyncio.Lock(), "users": 0}
            _source_parse_locks[source_id] = entry
        entry["users"] += 1
        lock = entry["lock"]

    try:
        async with lock:
            yield
    finally:
        with _source_parse_locks_guard:
            entry["users"] -= 1
            if entry["users"] == 0:
                _source_parse_locks.pop(source_id, None)


def _knowledge_base_raw_dir() -> Path:
    return get_knowledge_base_paths().raw / "fw-spec-common"


class DriverSourceService:
    """Service for handling driver source file uploads and document parsing."""

    def __init__(
        self,
        repo: DriverConversationRepository,
        docling_service: DriverDoclingService,
        upload_dir: str | Path | None = None,
        progress_callback=None,
    ):
        self._repo = repo
        self._docling = docling_service
        self._progress_callback = progress_callback
        self._upload_dir = Path(upload_dir or DEFAULT_UPLOAD_DIR).resolve()
        self._upload_dir.mkdir(parents=True, exist_ok=True)

    async def upload_and_parse(
        self,
        user_id: str | None,
        source_type: str,
        filename: str,
        file_content: bytes,
    ) -> dict[str, Any]:
        """Upload a file, save to disk, and parse its content.

        Args:
            user_id: Optional user identifier.
            source_type: 'knowledge_base' or 'reference'.
            filename: Original filename.
            file_content: Raw file bytes.
        Returns:
            Dict with source metadata and parse results.
        """
        # Validate source_type
        if source_type not in VALID_DRIVER_SOURCE_TYPES:
            raise ValueError("source_type must be knowledge_base or reference")

        safe_filename = self._safe_filename(filename)
        ext = Path(safe_filename).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {ext}")

        # Validate size
        if len(file_content) > MAX_FILE_SIZE:
            raise ValueError(f"File size exceeds the {MAX_FILE_SIZE // (1024*1024)} MB limit")

        # Determine MIME type
        mime_type = mimetypes.guess_type(safe_filename)[0] or "application/octet-stream"

        # Create source record
        source = await self._repo.create_source(
            user_id=user_id,
            source_type=source_type,
            name=safe_filename,
            size=len(file_content),
            extension=ext,
            mime_type=mime_type,
        )

        # Save file to disk
        source_dir = (self._upload_dir / source.id).resolve()
        self._ensure_within(self._upload_dir, source_dir)
        source_dir.mkdir(parents=True, exist_ok=True)
        file_path = (source_dir / safe_filename).resolve()
        self._ensure_within(source_dir, file_path)
        file_path.write_bytes(file_content)

        # Update saved path in database (ORM object changes need explicit commit)
        source.saved_path = self._relative_upload_path(file_path)
        source.upload_status = DriverSourceUploadStatus.UPLOADED.value
        # Note: Changes will be committed by the endpoint's db.commit()

        if source_type == DriverSourceType.REFERENCE.value and ext in DIRECT_TEXT_EXTENSIONS:
            is_direct_text = True
            skipped_summary = "Reference text file: parsing skipped, access via saved_path"
            await self._repo.update_source_parse_status(
                source_id=source.id,
                parse_status=DriverSourceParseStatus.SKIPPED.value,
                parsed_content=None,
                parsed_summary=skipped_summary,
                extra_metadata=json.dumps({
                    "parse_skipped": True,
                    "direct_text": is_direct_text,
                    "reason": "Reference text files are read directly"
                }, ensure_ascii=False),
            )
            return {
                "source_id": source.id,
                "source_type": source.source_type,
                "name": source.name,
                "size": source.size,
                "extension": source.extension,
                "mime_type": source.mime_type,
                "upload_status": source.upload_status,
                "parse_status": DriverSourceParseStatus.SKIPPED.value,
                "parsed_summary": skipped_summary,
                "extra_metadata": {
                    "parse_skipped": True,
                    "direct_text": is_direct_text,
                },
                "created_at": source.created_at,
            }

        # For knowledge_base files or reference non-source files, return pending status
        # Parsing will happen during driver generation (on-demand)
        return {
            "source_id": source.id,
            "source_type": source.source_type,
            "name": source.name,
            "size": source.size,
            "extension": source.extension,
            "mime_type": source.mime_type,
            "upload_status": source.upload_status,
            "parse_status": DriverSourceParseStatus.PENDING.value,
            "parsed_summary": "File uploaded, will be parsed during generation",
            "extra_metadata": None,
            "created_at": source.created_at,
        }

    async def _mark_parse_cancelled(
        self,
        source_id: str,
        task_id: str | None,
        parse_attempt_id: str,
    ) -> None:
        await self._repo.update_source_parse_status(
            source_id=source_id,
            parse_status=DriverSourceParseStatus.CANCELLED.value,
            parsed_summary="Parsing cancelled by user",
            extra_metadata=json.dumps(
                {
                    "cancelled": True,
                    "task_id": task_id,
                    "parse_attempt_id": parse_attempt_id,
                },
                ensure_ascii=False,
            ),
        )
        await self._commit_parse_transition()

    async def _commit_parse_transition(self) -> None:
        """Commit one parse-status transition.

        The transaction boundary lives here rather than in the repository, which
        only flushes like every other repository in this codebase. It is committed
        per transition instead of once at the end because a parse can run for
        minutes and polling requests read through independent sessions: a status
        that is only flushed stays invisible to them, so the source would appear
        stuck at its previous status for the whole parse.
        """
        await self._repo.db.commit()

    def _stash_parse_artifacts(self, source_id: str, filename: str) -> Path | None:
        """Move existing parse artifacts aside and return the stash location.

        The previous artifacts are kept until the replacement parse succeeds.
        Deleting them up front means a transient Docling failure destroys a good
        parse result permanently, and because get_source_content() now retries
        FAILED sources automatically, that loss happens without anyone asking for
        a re-parse.
        """
        artifact_root = _knowledge_base_raw_dir().resolve()
        artifact_dir = self._knowledge_base_artifact_dir(source_id, filename).resolve()
        self._ensure_within(artifact_root, artifact_dir)
        if not artifact_dir.exists():
            return None
        stash_dir = artifact_dir.with_name(
            f"{artifact_dir.name}{PARSE_STASH_SUFFIX}{uuid4().hex}"
        )
        self._ensure_within(artifact_root, stash_dir)
        artifact_dir.rename(stash_dir)
        return stash_dir

    def _restore_stashed_parse_artifacts(
        self,
        source_id: str,
        filename: str,
        stash_dir: Path | None,
    ) -> None:
        """Put stashed artifacts back after a failed or cancelled replacement."""
        if stash_dir is None or not stash_dir.exists():
            return
        artifact_root = _knowledge_base_raw_dir().resolve()
        artifact_dir = self._knowledge_base_artifact_dir(source_id, filename).resolve()
        self._ensure_within(artifact_root, artifact_dir)
        try:
            if artifact_dir.exists():
                # Discard whatever the failed attempt left behind.
                shutil.rmtree(artifact_dir)
            stash_dir.rename(artifact_dir)
        except OSError as exc:
            # Restoring is best effort; leave the stash in place so the previous
            # artifacts are still recoverable by hand rather than silently lost.
            logger.warning(
                "Could not restore previous parse artifacts for {} from {}: {}",
                filename,
                stash_dir,
                exc,
            )

    @staticmethod
    def _drop_stashed_parse_artifacts(stash_dir: Path | None) -> None:
        """Delete stashed artifacts once the replacement parse has succeeded."""
        if stash_dir is None or not stash_dir.exists():
            return
        try:
            shutil.rmtree(stash_dir)
        except OSError as exc:
            logger.warning("Could not remove stashed parse artifacts {}: {}", stash_dir, exc)

    def _discard_parse_artifacts(self, source_id: str, filename: str) -> None:
        artifact_root = _knowledge_base_raw_dir().resolve()
        artifact_dir = self._knowledge_base_artifact_dir(source_id, filename).resolve()
        self._ensure_within(artifact_root, artifact_dir)
        if artifact_dir.exists():
            shutil.rmtree(artifact_dir)

    async def _parse_source(
        self,
        source_id: str,
        file_path: str,
        filename: str,
        task_id: str | None = None,
    ) -> None:
        """Parse a source off the request event loop and persist the result.

        Args:
            source_id: Source document ID
            file_path: Path to file to parse
            filename: Original filename
            task_id: Optional task ID for cancellation checking during parsing
        """
        parse_attempt_id = uuid4().hex
        parse_progress = DoclingProgress()
        future: asyncio.Future[Any] | None = None
        try:
            file_path = str(self._resolve_upload_path(file_path))

            # Check cancellation before starting parse
            if task_id:
                from app.utils.claude_cli_monitor import is_task_cancelled
                if is_task_cancelled(task_id):
                    logger.warning(f"🛑 [_parse_source] Task {task_id} cancelled before parsing {filename}, aborting")
                    await self._mark_parse_cancelled(
                        source_id,
                        task_id,
                        parse_attempt_id,
                    )
                    return

            await self._repo.update_source_parse_status(
                source_id=source_id,
                parse_status=DriverSourceParseStatus.PARSING.value,
                parsed_summary="Docling parsing started",
                extra_metadata=json.dumps(
                    {
                        "task_id": task_id,
                        "parse_attempt_id": parse_attempt_id,
                    },
                    ensure_ascii=False,
                ),
            )
            await self._commit_parse_transition()
            image_output_dir = self._knowledge_base_image_dir(source_id, filename)

            def _sync_parse():
                """Run the parse in sync context (will be executed in thread pool).

                Previous artifacts are stashed rather than deleted, and are only
                dropped once this parse has produced a usable result. A failed or
                cancelled attempt restores them, so a transient Docling error
                cannot destroy the last good parse.
                """
                # This runs only after earlier work leaves the single-worker executor.
                stash_dir = self._stash_parse_artifacts(source_id, filename)
                try:
                    with parse_progress.track():
                        result = _run_parse_coroutine_in_thread(
                            self._docling.parse_file(
                                file_path,
                                image_output_dir=image_output_dir,
                                task_id=task_id,
                            )
                        )
                except BaseException:
                    self._restore_stashed_parse_artifacts(source_id, filename, stash_dir)
                    raise
                if isinstance(result, dict) and result.get("error") == PARSE_CANCELLED_MARKER:
                    # Cancellation is reported in-band, so it never raises here.
                    self._restore_stashed_parse_artifacts(source_id, filename, stash_dir)
                    return result
                if not isinstance(result, dict) or result.get("error") or not result.get("content"):
                    self._restore_stashed_parse_artifacts(source_id, filename, stash_dir)
                    return result
                self._drop_stashed_parse_artifacts(stash_dir)
                return result

            # Docling conversion is blocking, so keep it off the request loop.
            loop = asyncio.get_running_loop()
            future = loop.run_in_executor(get_driver_source_parse_executor(), _sync_parse)
            last_progress_at = float("-inf")
            while not future.done():
                if task_id:
                    from app.utils.claude_cli_monitor import is_task_cancelled
                    if is_task_cancelled(task_id):
                        logger.warning(
                            "Driver source parse cancelled for task {} while parsing {}; "
                            "the next parse will run after the active Docling batch exits",
                            task_id,
                            filename,
                        )
                        future.cancel()
                        await self._mark_parse_cancelled(
                            source_id,
                            task_id,
                            parse_attempt_id,
                        )
                        return
                if self._progress_callback and monotonic() - last_progress_at >= 5:
                    try:
                        await self._progress_callback(parse_progress.snapshot())
                    except Exception as exc:
                        logger.warning("Docling progress publication failed: {}", exc)
                    last_progress_at = monotonic()
                await asyncio.sleep(PARSE_POLL_INTERVAL_SECONDS)
            parse_result = await future

            # Check if parsing returned a cancellation result
            if parse_result.get("error") == PARSE_CANCELLED_MARKER:
                logger.warning(f"🛑 [_parse_source] Parsing of {filename} was cancelled")
                await self._mark_parse_cancelled(
                    source_id,
                    task_id,
                    parse_attempt_id,
                )
                return

            parse_error = parse_result.get("error")
            parsed_content = parse_result.get("content", "") if not parse_error else ""
            summary = parse_result.get("summary", "")
            metadata: dict[str, Any] = parse_result.get("metadata", {}) or {}
            if parse_error:
                metadata["parse_error"] = parse_error
            metadata["task_id"] = task_id
            metadata["parse_attempt_id"] = parse_attempt_id

            # Check cancellation after parse completes
            if task_id:
                from app.utils.claude_cli_monitor import is_task_cancelled
                if is_task_cancelled(task_id):
                    logger.warning(f"🛑 [_parse_source] Task {task_id} cancelled after parsing {filename}, aborting")
                    await self._mark_parse_cancelled(
                        source_id,
                        task_id,
                        parse_attempt_id,
                    )
                    return

            # Save parsed Markdown to the source artifact directory and publish
            # knowledge-base records only after the parse produced usable text.
            if parsed_content:
                markdown_path = await self._save_markdown_to_knowledge_base(
                    source_id, filename, parsed_content
                )
                if metadata.get("image_output_dir"):
                    logger.info(f"Saved parsed images to knowledge base: {metadata['image_output_dir']}")

            if task_id:
                from app.utils.claude_cli_monitor import is_task_cancelled

                if is_task_cancelled(task_id):
                    await self._mark_parse_cancelled(
                        source_id,
                        task_id,
                        parse_attempt_id,
                    )
                    return

            if parsed_content and markdown_path is not None:
                try:
                    index_result = await self._index_markdown(
                        source_id,
                        filename,
                        parsed_content,
                        metadata,
                    )
                except Exception as exc:
                    # Indexing is an enrichment step. Preserve the parsed
                    # source and expose the failure for a later repair job.
                    logger.error(
                        "Knowledge-base indexing failed for {}: {}",
                        filename,
                        exc,
                    )
                    metadata["knowledge_index"] = {
                        "status": "failed",
                        "document_id": self._knowledge_document_id(source_id),
                        "error": str(exc)[:2_000],
                    }
                else:
                    if index_result is not None:
                        metadata["knowledge_index"] = index_result

                if task_id:
                    from app.utils.claude_cli_monitor import is_task_cancelled

                    if is_task_cancelled(task_id):
                        await self._mark_parse_cancelled(
                            source_id,
                            task_id,
                            parse_attempt_id,
                        )
                        return

            parse_status_update = {
                "source_id": source_id,
                "parse_status": (
                    DriverSourceParseStatus.PARSED.value
                    if parsed_content
                    else DriverSourceParseStatus.FAILED.value
                ),
                "parsed_summary": summary[:MAX_STORED_SUMMARY_CHARS],
                "extra_metadata": json.dumps(metadata, ensure_ascii=False)[:MAX_STORED_METADATA_CHARS],
            }
            if parsed_content:
                parse_status_update["parsed_content"] = parsed_content
            await self._repo.update_source_parse_status(**parse_status_update)
            await self._commit_parse_transition()
            if parsed_content:
                logger.info("Source parse completed for {}", filename)
            else:
                logger.warning("Source parse failed for {}: {}", filename, parse_error or "empty content")
        except asyncio.CancelledError:
            if future is not None:
                future.cancel()
            await asyncio.shield(
                self._mark_parse_cancelled(
                    source_id,
                    task_id,
                    parse_attempt_id,
                )
            )
            raise
        except Exception as exc:
            logger.error(f"Source parse failed for {filename}: {exc}")
            await self._repo.update_source_parse_status(
                source_id=source_id,
                parse_status=DriverSourceParseStatus.FAILED.value,
                parsed_summary=f"Parse error: {exc}",
                extra_metadata=json.dumps(
                    {
                        "parse_error": str(exc),
                        "task_id": task_id,
                        "parse_attempt_id": parse_attempt_id,
                    },
                    ensure_ascii=False,
                ),
            )
            await self._commit_parse_transition()

    async def get_source_content(
        self,
        source_id: str,
        task_id: str | None = None,
        force_reparse: bool = False,
    ) -> str | None:
        """Get parsed text content for a source.

        If content hasn't been parsed yet, parse it on-demand. A source whose
        previous parse was cancelled is retryable by a later driver task.
        If parse_status='skipped' (reference source files), read directly from disk.

        Args:
            source_id: Source document ID
            task_id: Optional task ID for cancellation checking during parsing
            force_reparse: Ignore cached content and run a new Docling parse.
        """
        async with serialize_source_parse(source_id):
            source = await self._repo.get_source(source_id)
            if source is None:
                return None

            is_reference = source.source_type == DriverSourceType.REFERENCE.value
            if source.extension in DIRECT_TEXT_EXTENSIONS and (
                is_reference or source.parse_status == DriverSourceParseStatus.SKIPPED.value
            ):
                logger.info(
                    "[get_source_content] Reading reference file {} directly from disk",
                    source.name,
                )
                try:
                    file_path = await self.get_source_file_path(source)
                    if file_path is None:
                        logger.warning("[get_source_content] Source file unavailable: {}", source.id)
                        return None
                    return file_path.read_text(encoding="utf-8", errors="replace")
                except Exception as exc:
                    logger.error(
                        "[get_source_content] Failed to read reference file {}: {}",
                        source.name,
                        exc,
                    )
                    return None

            if source.parsed_content and not force_reparse:
                await self._ensure_knowledge_index(source)
                return source.parsed_content

            retryable_statuses = {
                DriverSourceParseStatus.PENDING.value,
                DriverSourceParseStatus.PARSING.value,
                DriverSourceParseStatus.CANCELLED.value,
                DriverSourceParseStatus.FAILED.value,
                DriverSourceParseStatus.SKIPPED.value,
            }
            should_parse = force_reparse or source.parse_status in retryable_statuses
            if not should_parse:
                return source.parsed_content

            file_path = await self.get_source_file_path(source)
            if file_path is None:
                logger.warning("[get_source_content] Source file unavailable: {}", source.id)
                return None

            logger.info(
                "[get_source_content] Parsing {} on-demand "
                "(force_reparse={}, previous_status={})",
                source.name,
                force_reparse,
                source.parse_status,
            )
            try:
                await self._parse_source(
                    source_id,
                    str(file_path),
                    source.name,
                    task_id,
                )
                source = await self._repo.get_source(source_id)
                if source and source.parse_status == DriverSourceParseStatus.CANCELLED.value:
                    raise asyncio.CancelledError(
                        f"Parsing of {source.name} was cancelled by user"
                    )
                if source and source.parse_status == DriverSourceParseStatus.PARSED.value:
                    return source.parsed_content
                return None
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.error(
                    "[get_source_content] On-demand parse failed for {}: {}",
                    source.name,
                    exc,
                )
                return None

    def _knowledge_base_artifact_dir(self, source_id: str, filename: str) -> Path:
        """Return the source-specific directory containing all parsed artifacts."""
        return _knowledge_base_raw_dir() / self._artifact_stem(source_id, filename)

    def _knowledge_base_image_dir(self, source_id: str, filename: str) -> Path:
        return self._knowledge_base_artifact_dir(source_id, filename) / "images"

    @staticmethod
    def _knowledge_document_id(source_id: str) -> str:
        """Return the stable shared-index ID for one Driver source."""
        return f"{KNOWLEDGE_DOCUMENT_ID_PREFIX}{source_id}"

    @staticmethod
    def _knowledge_chip(metadata: dict[str, Any]) -> str:
        """Choose a useful chip label without inventing hardware facts."""
        for key in ("chip", "part_number", "part", "device", "model"):
            value = metadata.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()[:200]
        return "GENERAL"

    async def _index_markdown(
        self,
        source_id: str,
        filename: str,
        markdown_content: str,
        parse_metadata: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Publish a parsed Driver knowledge-base source to the shared index.

        Reference files intentionally remain task-scoped. Only files uploaded
        through the Driver knowledge-base lane become shared documents.
        """
        source = await self._repo.get_source(source_id)
        if (
            source is None
            or getattr(source, "source_type", None)
            != DriverSourceType.KNOWLEDGE_BASE.value
        ):
            return None

        document_id = self._knowledge_document_id(source_id)
        source_path = f"driver://{source_id}/{filename}"
        revision = str(
            parse_metadata.get("revision")
            or parse_metadata.get("document_version")
            or parse_metadata.get("parse_attempt_id")
            or ""
        )
        peripheral_hint = str(parse_metadata.get("peripheral") or "")
        chip = self._knowledge_chip(parse_metadata)

        def ingest() -> dict[str, Any]:
            service = KnowledgeBaseService()
            return service.ingest_markdown(
                markdown_content,
                chip=chip,
                title=filename,
                revision=revision,
                peripheral_hint=peripheral_hint,
                source_path=source_path,
                replace_source=True,
                document_id=document_id,
            )

        result = await asyncio.to_thread(ingest)
        return {
            "status": "indexed",
            "document_id": str(result.get("document_id") or document_id),
            "stats": result.get("stats") or {},
        }

    async def _ensure_knowledge_index(self, source: Any) -> None:
        """Backfill or retry the index for a cached parsed knowledge source."""
        if (
            getattr(source, "source_type", None) != DriverSourceType.KNOWLEDGE_BASE.value
            or not source.parsed_content
        ):
            return
        try:
            metadata = json.loads(source.extra_metadata or "{}")
        except (TypeError, ValueError):
            metadata = {}
        if not isinstance(metadata, dict):
            metadata = {}
        current = metadata.get("knowledge_index")
        expected_id = self._knowledge_document_id(source.id)
        if (
            isinstance(current, dict)
            and current.get("status") == "indexed"
            and current.get("document_id") == expected_id
        ):
            return
        try:
            index_result = await self._index_markdown(
                source.id,
                source.name,
                source.parsed_content,
                metadata,
            )
        except Exception as exc:
            logger.warning("Knowledge-base index retry failed for {}: {}", source.name, exc)
            return
        if index_result is None:
            return
        metadata["knowledge_index"] = index_result
        await self._repo.update_source_parse_status(
            source_id=source.id,
            parse_status=source.parse_status,
            extra_metadata=json.dumps(metadata, ensure_ascii=False)[:MAX_STORED_METADATA_CHARS],
        )
        await self._commit_parse_transition()

    async def _save_markdown_to_knowledge_base(
        self, source_id: str, filename: str, markdown_content: str
    ) -> Path | None:
        """Save parsed Markdown content to knowledge base directory.

        Args:
            filename: Original filename
            markdown_content: Parsed Markdown content from Docling
        """
        try:
            # Validate content before saving (detect corrupted parsing results)
            if self._is_corrupted_content(markdown_content):
                logger.warning(f"Detected corrupted parsing result for {filename}, skipping save to knowledge base")
                return None

            artifact_stem = self._artifact_stem(source_id, filename)
            artifact_dir = self._knowledge_base_artifact_dir(source_id, filename)
            artifact_dir.mkdir(parents=True, exist_ok=True)

            # Generate Markdown filename (replace extension with .md)
            md_filename = f"{artifact_stem}.md"
            md_path = artifact_dir / md_filename

            # Save Markdown content
            md_path.write_text(markdown_content, encoding="utf-8")
            logger.info(f"Saved parsed Markdown to knowledge base: {md_path}")
            return md_path

        except Exception as e:
            logger.error(f"Failed to save Markdown to knowledge base for {filename}: {e}")
            return None

    def find_knowledge_base_markdown(self, source_id: str, filename: str) -> Path | None:
        """Find the Raw Markdown generated for one exact uploaded source."""
        artifact_stem = self._artifact_stem(source_id, filename)
        raw_dir = _knowledge_base_raw_dir()
        candidate_paths = (
            self._knowledge_base_artifact_dir(source_id, filename) / f"{artifact_stem}.md",
            raw_dir / f"{artifact_stem}.md",
        )
        for markdown_path in candidate_paths:
            if markdown_path.is_file():
                return markdown_path
        return None

    def _is_corrupted_content(self, content: str) -> bool:
        """Detect if parsed content is corrupted (contains too many control characters).

        Args:
            content: Parsed markdown content

        Returns:
            True if content appears corrupted, False otherwise
        """
        if not content or len(content) < MIN_VALID_MARKDOWN_CHARS:
            return True

        # Sample first 500 characters for detection
        sample = content[:CORRUPTION_SAMPLE_CHARS]

        # Count non-printable characters (excluding newlines, tabs, spaces)
        non_printable_count = sum(
            1 for c in sample
            if ord(c) < 32 and c not in ('\n', '\t', '\r')
        )

        # If more than 10% are control characters, consider it corrupted
        corruption_ratio = non_printable_count / len(sample)

        if corruption_ratio > MAX_CORRUPTION_RATIO:
            logger.warning(f"Content corruption detected: {corruption_ratio:.2%} non-printable characters")
            return True

        return False

    async def delete_source(self, source_id: str) -> bool:
        """Delete a source and its files."""
        source = await self._repo.get_source(source_id)
        if source is None:
            return False

        # Delete file from disk
        file_path = await self.get_source_file_path(source)
        if file_path is not None and file_path.exists():
            file_path.unlink()
            parent = file_path.parent
            if parent.exists() and not any(parent.iterdir()):
                parent.rmdir()

        kb_root = _knowledge_base_raw_dir()
        artifact_stem = self._artifact_stem(source.id, source.name)
        artifact_dir = self._knowledge_base_artifact_dir(source.id, source.name)
        self._ensure_within(kb_root, artifact_dir)
        if artifact_dir.exists():
            shutil.rmtree(artifact_dir)

        # Backward-compatible cleanup for artifacts created before per-source
        # directories were introduced.
        legacy_markdown_path = kb_root / f"{artifact_stem}.md"
        legacy_image_dir = kb_root / f"{artifact_stem}_images"
        self._ensure_within(kb_root, legacy_markdown_path)
        self._ensure_within(kb_root, legacy_image_dir)
        if legacy_markdown_path.exists():
            legacy_markdown_path.unlink()
        if legacy_image_dir.exists():
            shutil.rmtree(legacy_image_dir)

        # The shared index is derived data and must not retain a deleted Driver
        # document. Cleanup is best effort so a transient SQLite issue cannot
        # prevent removal of the uploaded source itself.
        try:
            document_id = self._knowledge_document_id(source_id)
            await asyncio.to_thread(
                lambda: KnowledgeBaseService().delete_document(document_id)
            )
        except Exception as exc:
            logger.warning(
                "Could not remove Driver knowledge document {}: {}",
                source_id,
                exc,
            )

        return await self._repo.delete_source(source_id)

    @staticmethod
    def _safe_filename(filename: str) -> str:
        """Return a single safe filename component without trusting client paths."""
        normalized = str(filename or "").replace("\\", "/")
        safe = Path(normalized).name
        if not safe or safe in {".", ".."} or "\x00" in safe:
            raise ValueError("A valid filename is required")
        if len(safe) > MAX_FILENAME_CHARS:
            raise ValueError(f"Filename exceeds {MAX_FILENAME_CHARS} characters")
        return safe

    @staticmethod
    def _ensure_within(root: Path, candidate: Path) -> None:
        try:
            candidate.resolve().relative_to(root.resolve())
        except ValueError as exc:
            raise ValueError("Path escapes the configured root") from exc

    async def get_source_file_path(self, source: Any) -> Path | None:
        """Resolve a source file inside the active upload root.

        New rows store a relative path. Legacy rows may contain an absolute path
        from another installation; those paths are never read directly. If the
        source was copied into the active upload root, its canonical relative path
        is restored automatically.
        """
        candidate = None
        if source.saved_path:
            try:
                candidate = self._resolve_upload_path(source.saved_path)
            except ValueError:
                candidate = None
            if candidate is not None and candidate.is_file():
                await self._normalize_source_path(source, candidate)
                return candidate

        try:
            fallback = (self._upload_dir / source.id / self._safe_filename(source.name)).resolve()
            self._ensure_within(self._upload_dir, fallback)
        except (OSError, ValueError):
            return None
        if not fallback.is_file():
            return None
        await self._normalize_source_path(source, fallback)
        return fallback

    async def _normalize_source_path(self, source: Any, file_path: Path) -> None:
        normalized = self._relative_upload_path(file_path)
        if source.saved_path != normalized:
            source.saved_path = normalized
            await self._repo.db.flush()

    def _relative_upload_path(self, file_path: str | Path) -> str:
        candidate = file_path.resolve()
        self._ensure_within(self._upload_dir, candidate)
        return candidate.relative_to(self._upload_dir).as_posix()

    def _resolve_upload_path(self, path: str | Path) -> Path:
        raw_path = Path(path)
        candidate = raw_path if raw_path.is_absolute() else self._upload_dir / raw_path
        candidate = candidate.resolve()
        self._ensure_within(self._upload_dir, candidate)
        return candidate

    @staticmethod
    def _artifact_stem(source_id: str, filename: str) -> str:
        source_token = "".join(ch for ch in str(source_id) if ch.isalnum() or ch in "_-")
        name_token = "".join(ch for ch in Path(filename).stem if ch.isalnum() or ch in "_-")
        return f"{source_token or 'source'}_{name_token or 'document'}"[:MAX_ARTIFACT_NAME_CHARS]
