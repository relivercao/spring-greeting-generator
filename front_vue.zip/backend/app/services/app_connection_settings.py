"""Administrator-managed hosted application authorization configuration."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

from app.core.config import _BACKEND_DIR, get_settings
from app.core.env_file import update_env_file
from app.services.app_connections import APP_CATALOG, AppConnectionError


ENV_FILE = Path(_BACKEND_DIR) / ".env"
_CONFIG_LOCK = asyncio.Lock()


def provider_configuration() -> dict:
    settings = get_settings()
    try:
        configs = json.loads(settings.COMPOSIO_AUTH_CONFIGS or "{}")
    except ValueError:
        configs = {}
    return {
        "api_key_configured": bool(settings.COMPOSIO_API_KEY),
        "api_base_url": settings.COMPOSIO_API_BASE_URL,
        "app_frontend_base_url": (
            settings.COMPOSIO_FRONTEND_BASE_URL
        ),
        # Keep the legacy field available to existing API clients.
        "frontend_base_url": settings.PUBLIC_FRONTEND_BASE_URL,
        "auth_configs": configs if isinstance(configs, dict) else {},
        "apps": [{"slug": item["slug"], "name": item["name"]} for item in APP_CATALOG],
    }


def _validated_url(
    value: str,
    label: str,
    *,
    local_allowed: bool = False,
    trusted_http_origin: str | None = None,
) -> str:
    parsed = urlsplit(value)
    local_http = local_allowed and parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}
    same_origin_http = (
        bool(trusted_http_origin)
        and parsed.scheme == "http"
        and f"{parsed.scheme}://{parsed.netloc}" == trusted_http_origin.rstrip("/")
    )
    if (
        (parsed.scheme != "https" and not local_http and not same_origin_http)
        or not parsed.netloc
        or parsed.username or parsed.password or parsed.query or parsed.fragment
        or any(character.isspace() for character in value)
    ):
        raise AppConnectionError(f"{label} must be a valid HTTPS URL; localhost may use HTTP.", 422)
    return value.rstrip("/")


async def save_provider_configuration(
    *, api_key: str | None, api_base_url: str, auth_configs: dict[str, str],
    app_frontend_base_url: str | None = None, frontend_base_url: str | None = None,
    trusted_http_origin: str | None = None,
) -> dict:
    # ``frontend_base_url`` remains a request compatibility alias. The App
    # Connect flow now persists to its own key and never changes payment links.
    callback_base_url = app_frontend_base_url or frontend_base_url
    if not callback_base_url:
        raise AppConnectionError("Application URL is required.", 422)
    allowed = {app["slug"] for app in APP_CATALOG}
    if set(auth_configs) - allowed:
        raise AppConnectionError("The application configuration contains an unknown app.", 422)
    configs = {slug: config.strip() for slug, config in auth_configs.items() if config.strip()}
    if any(not value.replace("_", "").replace("-", "").isalnum() for value in configs.values()):
        raise AppConnectionError("Auth Config IDs must contain only letters, digits, underscores, and hyphens.", 422)
    if len(set(configs.values())) != len(configs):
        raise AppConnectionError("Each application must have a different Auth Config ID.", 422)
    updates = {
        "COMPOSIO_API_BASE_URL": _validated_url(api_base_url.strip(), "Provider API URL"),
        "COMPOSIO_FRONTEND_BASE_URL": _validated_url(
            callback_base_url.strip(),
            "Application URL",
            local_allowed=True,
            trusted_http_origin=trusted_http_origin,
        ),
        "COMPOSIO_AUTH_CONFIGS": json.dumps(configs, separators=(",", ":")),
    }
    if api_key is not None:
        updates["COMPOSIO_API_KEY"] = api_key.strip()
    if any("\r" in value or "\n" in value for value in updates.values()):
        raise AppConnectionError("Configuration values must use a single line.", 422)
    async with _CONFIG_LOCK:
        await asyncio.to_thread(update_env_file, ENV_FILE, updates)
        os.environ.update(updates)
        get_settings.cache_clear()
    return {"message": "Application connection settings saved.", **provider_configuration()}
