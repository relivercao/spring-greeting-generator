"""Transfer Docling worker progress without sharing database sessions across threads."""

from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from threading import Lock
from time import monotonic


_active_progress = ContextVar("driver_docling_progress", default=None)


class DoclingProgress:
    def __init__(self):
        self._lock = Lock()
        self._started = monotonic()
        self._state = {"phase": "queued", "message": "Waiting for the Docling worker"}

    @contextmanager
    def track(self):
        token = _active_progress.set(self)
        try:
            self.update("parsing", "Docling conversion started")
            yield
        finally:
            _active_progress.reset(token)

    def update(self, phase: str, message: str, **details) -> None:
        with self._lock:
            self._state = {"phase": phase, "message": message, **details}

    def snapshot(self) -> dict:
        with self._lock:
            return {
                **self._state,
                "elapsed_seconds": round(monotonic() - self._started, 1),
                "heartbeat_at": datetime.now(timezone.utc).isoformat(),
            }


def report_docling_progress(phase: str, message: str, **details) -> None:
    progress = _active_progress.get()
    if progress is not None:
        progress.update(phase, message, **details)
