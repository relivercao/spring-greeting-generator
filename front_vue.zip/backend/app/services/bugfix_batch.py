"""Server-owned serial BugFix queues backed by ordinary task records."""

import asyncio
import json
import uuid

from sqlalchemy import select

from app.agents.impl import BugFixAgent
from app.agents.impl.bugfix_agent import BugFixContext
from app.core.database import async_session_factory
from app.models.task import Task
from app.schemas.bugfix import BugFixBatchRequest, BugFixRequest
from app.services.agent_task_runtime import (
    agent_task_registry,
    fail_task,
    load_json_object,
    mark_task_cancelled,
)
from app.services.bugfix_execution import run_bugfix_task

BATCH_AGENT_TYPE = "bugfix_batch"
TERMINAL_STATUSES = {"completed", "failed", "cancelled"}


def make_batch_task(payload: BugFixBatchRequest, user_id: str) -> Task:
    """Persist the entire queue before starting any potentially costly work."""
    items = [
        {"task_id": str(uuid.uuid4()), "request": item.model_dump()}
        for item in payload.items
    ]
    return Task(
        id=str(uuid.uuid4()), user_id=user_id, agent_type=BATCH_AGENT_TYPE,
        status="running", progress=0, message="Bug-fix batch queued",
        input_data=json.dumps({"items": items}),
    )


async def batch_snapshot(batch: Task, session) -> dict:
    """Project queue progress; only child tasks owned by this user are visible."""
    entries = load_json_object(batch.input_data).get("items", [])
    task_ids = [entry["task_id"] for entry in entries]
    children = (await session.execute(select(Task).where(
        Task.id.in_(task_ids), Task.user_id == batch.user_id, Task.agent_type == "bugfix",
    ))).scalars().all()
    children_by_id = {child.id: child for child in children}
    items = []
    for index, entry in enumerate(entries):
        child = children_by_id.get(entry["task_id"])
        request = entry["request"]
        status = child.status if child else (
            "cancelled" if batch.status in TERMINAL_STATUSES else "queued"
        )
        items.append({
            "task_id": entry["task_id"], "sequence": index,
            "issue_id": request.get("issue_id"),
            "label": request.get("issue_id") or request.get("bug_description", "")[:100],
            "repo": request.get("repo"), "branch": request.get("branch"),
            "source_files": request.get("source_files", []), "status": status,
            "progress": child.progress if child else 0,
            "message": child.message if child else (
                "Not started: batch stopped" if status == "cancelled" else "Waiting in queue"
            ),
            "error": child.error_message if child else None,
        })
    counts = {status: sum(item["status"] == status for item in items)
              for status in ("queued", "running", "completed", "failed", "cancelled")}
    counts["total"] = len(items)
    progress = round(sum(
        100 if item["status"] in TERMINAL_STATUSES else (item["progress"] or 0)
        for item in items
    ) / max(1, len(items)))
    return {
        "task_id": batch.id, "status": batch.status, "progress": progress,
        "message": batch.message, "error": batch.error_message,
        "items": items, "counts": counts,
        "created_at": batch.created_at.isoformat() if batch.created_at else None,
    }


class BugFixBatchRunner:
    """Run one defect at a time and stop before starting a cancelled queue item."""

    def __init__(self, llm_bridge, mcp_client, skill_registry=None):
        self.llm_bridge = llm_bridge
        self.mcp_client = mcp_client
        self.skill_registry = skill_registry
        self.current_task_id = None
        self.cancel_requested = False

    async def cancel(self, _task_id: str) -> None:
        self.cancel_requested = True
        if self.current_task_id:
            await agent_task_registry.cancel(self.current_task_id)

    async def _start_child(self, batch_id: str, user_id: str, entry: dict) -> bool:
        request = BugFixRequest.model_validate(entry["request"])
        # Billing is rechecked between items, matching independent single tasks.
        from app.services.billing_service import enforce_billing
        await enforce_billing({"id": user_id})
        async with async_session_factory() as session:
            batch = await session.get(Task, batch_id)
            if self.cancel_requested or not batch or batch.status != "running":
                return False
            child = Task(
                id=entry["task_id"], user_id=user_id, agent_type="bugfix",
                status="running", progress=0, message="Bug fix task started",
                input_data=json.dumps(request.model_dump()),
            )
            self.current_task_id = child.id
            session.add(child)
            await session.commit()
        agent = BugFixAgent(self.llm_bridge, self.mcp_client, self.skill_registry)
        context = BugFixContext(task_id=child.id, user_id=user_id, **request.model_dump())
        task_desc = f"Fix bug: {request.issue_id or request.bug_description[:100]}"
        worker = asyncio.create_task(run_bugfix_task(child.id, agent, task_desc, context), name=child.id)
        agent_task_registry.register(child.id, worker, agent)
        await worker
        self.current_task_id = None
        return True

    async def run(self, batch_id: str) -> None:
        try:
            async with async_session_factory() as session:
                batch = await session.get(Task, batch_id)
                user_id = batch.user_id
                entries = load_json_object(batch.input_data)["items"]
            for entry in entries:
                if self.cancel_requested:
                    break
                if not await self._start_child(batch_id, user_id, entry):
                    break
                async with async_session_factory() as session:
                    batch = await session.get(Task, batch_id)
                    snapshot = await batch_snapshot(batch, session)
                    batch.progress = snapshot["progress"]
                    batch.message = f"Processed {sum(snapshot['counts'][key] for key in TERMINAL_STATUSES)} of {len(entries)} defects"
                    await session.commit()
            if self.cancel_requested:
                await mark_task_cancelled(batch_id, "Bug-fix batch cancelled")
                return
            async with async_session_factory() as session:
                batch = await session.get(Task, batch_id)
                if batch.status != "running":
                    return
                snapshot = await batch_snapshot(batch, session)
                failed = snapshot["counts"]["failed"] + snapshot["counts"]["cancelled"]
                batch.status = "failed" if failed else "completed"
                batch.progress = 100
                batch.message = f"Batch finished: {snapshot['counts']['completed']} completed, {failed} unsuccessful"
                await session.commit()
        except asyncio.CancelledError:
            if self.current_task_id:
                await agent_task_registry.cancel(self.current_task_id)
                await mark_task_cancelled(self.current_task_id, "Bug-fix batch cancelled")
            await mark_task_cancelled(batch_id, "Bug-fix batch cancelled")
        except Exception as error:
            if self.current_task_id:
                await fail_task(self.current_task_id, str(error))
            await fail_task(batch_id, str(error))
        finally:
            agent_task_registry.remove(batch_id)
