"""
@file driver_task_token_usage.py
@author zhangjian
@brief Task-scoped token usage persistence for Driver workflows.

@version 1.0
@date 2026-08-12

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

This module records token usage from every Driver-related LLM path, including
Docling vision calls that run before the DriverAgent CLI monitor starts.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

from loguru import logger
from sqlalchemy import text
from sqlalchemy.exc import OperationalError

from app.core.config import get_settings
from app.core.database import async_session_factory
from app.utils.token_usage import TOKEN_USAGE_STATUS_AVAILABLE, TokenUsageAccumulator


_STATE_JSON = (
    "CASE "
    "WHEN state_data IS NOT NULL AND state_data <> '' AND json_valid(state_data) "
    "THEN state_data ELSE '{}' END"
)


def normalize_llm_token_usage(usage: Any) -> dict[str, int]:
    """Normalize provider/Router token fields to the Driver UI schema."""
    if usage is None:
        return TokenUsageAccumulator.merge()
    if not isinstance(usage, dict):
        usage = {
            "input_tokens": getattr(usage, "prompt_tokens", 0),
            "output_tokens": getattr(usage, "completion_tokens", 0),
            "total_tokens": getattr(usage, "total_tokens", 0),
        }

    normalized = {
        "input_tokens": _first_count(
            usage,
            "input_tokens",
            "prompt_tokens",
            "inputTokens",
            "promptTokens",
        ),
        "output_tokens": _first_count(
            usage,
            "output_tokens",
            "completion_tokens",
            "outputTokens",
            "completionTokens",
        ),
        "cache_creation_input_tokens": _first_count(
            usage,
            "cache_creation_input_tokens",
            "cacheWriteInputTokens",
        ),
        "cache_read_input_tokens": _first_count(
            usage,
            "cache_read_input_tokens",
            "cacheReadInputTokens",
        ),
        "total_tokens": _first_count(usage, "total_tokens", "totalTokens"),
    }
    return TokenUsageAccumulator.merge(normalized)


async def record_driver_task_token_usage(
    task_id: str | None,
    usage: Any,
    *,
    source: str | None = None,
) -> dict[str, int]:
    """Atomically add one LLM usage increment to a Driver task state."""
    normalized = normalize_llm_token_usage(usage)
    if not task_id or not TokenUsageAccumulator.has_usage(normalized):
        return normalized

    settings = get_settings()
    attempts = max(1, int(settings.SQLITE_WRITE_RETRY_ATTEMPTS))
    try:
        for attempt_index in range(attempts):
            try:
                await _persist_driver_task_token_usage(task_id, normalized, source)
                break
            except OperationalError as exc:
                if not _is_sqlite_lock_error(exc) or attempt_index >= attempts - 1:
                    raise
                delay = float(settings.SQLITE_WRITE_RETRY_BASE_DELAY_SECONDS) * (2 ** attempt_index)
                logger.warning(
                    "Driver token usage write locked; retrying: task_id={}, source={}, "
                    "attempt={}/{}, delay={:.2f}s",
                    task_id,
                    source or "unknown",
                    attempt_index + 1,
                    attempts,
                    delay,
                )
                await asyncio.sleep(delay)
    except Exception as exc:
        logger.warning(
            "Failed to record Driver token usage: task_id={}, source={}, error={}",
            task_id,
            source or "unknown",
            exc,
        )
    return normalized


async def _persist_driver_task_token_usage(
    task_id: str,
    normalized: dict[str, int],
    source: str | None,
) -> None:
    async with async_session_factory() as db_session:
        result = await db_session.execute(
            text(
                f"""
                UPDATE driver_agent_tasks
                SET
                    state_data = json_set(
                        {_STATE_JSON},
                        '$.token_usage.input_tokens',
                        COALESCE(CAST(json_extract({_STATE_JSON}, '$.token_usage.input_tokens') AS INTEGER), 0)
                            + :input_tokens,
                        '$.token_usage.output_tokens',
                        COALESCE(CAST(json_extract({_STATE_JSON}, '$.token_usage.output_tokens') AS INTEGER), 0)
                            + :output_tokens,
                        '$.token_usage.cache_creation_input_tokens',
                        COALESCE(CAST(json_extract({_STATE_JSON}, '$.token_usage.cache_creation_input_tokens') AS INTEGER), 0)
                            + :cache_creation_input_tokens,
                        '$.token_usage.cache_read_input_tokens',
                        COALESCE(CAST(json_extract({_STATE_JSON}, '$.token_usage.cache_read_input_tokens') AS INTEGER), 0)
                            + :cache_read_input_tokens,
                        '$.token_usage.total_tokens',
                        COALESCE(CAST(json_extract({_STATE_JSON}, '$.token_usage.total_tokens') AS INTEGER), 0)
                            + :total_tokens,
                        '$.token_usage_status',
                        :token_usage_status,
                        '$.token_usage_source',
                        :token_usage_source,
                        '$.token_usage_message',
                        :token_usage_message
                    ),
                    updated_at = :updated_at
                WHERE id = :task_id
                """
            ),
            {
                "task_id": task_id,
                "updated_at": datetime.now(timezone.utc),
                "token_usage_status": TOKEN_USAGE_STATUS_AVAILABLE,
                "token_usage_source": source or "provider",
                "token_usage_message": "Token usage reported by the provider.",
                **normalized,
            },
        )
        await db_session.commit()
        rowcount = getattr(result, "rowcount", None)
        log_method = logger.info if rowcount else logger.warning
        log_method(
            "Driver token usage recorded: task_id={}, source={}, "
            "input={}, output={}, cache_write={}, cache_read={}, "
            "total={}, persisted={}",
            task_id,
            source or "unknown",
            normalized["input_tokens"],
            normalized["output_tokens"],
            normalized["cache_creation_input_tokens"],
            normalized["cache_read_input_tokens"],
            normalized["total_tokens"],
            bool(rowcount),
        )


def _is_sqlite_lock_error(exc: Exception) -> bool:
    message = str(exc).lower()
    return "database is locked" in message or "database table is locked" in message


def _first_count(usage: dict[str, Any], *keys: str) -> int:
    for key in keys:
        value = usage.get(key)
        count = TokenUsageAccumulator.coerce_count(value)
        if count:
            return count
    return 0
