"""Shared Router Vision client for Docling formula and image analysis."""

from __future__ import annotations

import asyncio
import json
import os
import re
import ssl
from pathlib import Path
from typing import Any

import certifi
import httpx
from loguru import logger

from app.core.config import get_settings
from app.services.driver_task_token_usage import record_driver_task_token_usage
from app.utils.claude_cli_monitor import is_task_cancelled

ANTHROPIC_API_VERSION = "2023-06-01"

# Environment overrides for pinning a dedicated vision endpoint/model.
VISION_ROUTER_URL_ENV_VAR = "DRIVER_DOCLING_IMAGE_DESCRIPTION_ROUTER_URL"
VISION_MODEL_ENV_VAR = "DRIVER_DOCLING_IMAGE_DESCRIPTION_MODEL"

# Router configuration file consulted for an API key in Router mode.
ROUTER_CONFIG_FILENAME = "claude_router_config.json"

# Bound on the upstream error body echoed into the raised error. The endpoint
# previously surfaced only "Server error '500 ...'" because raise_for_status()
# discarded the body, which made an auth failure indistinguishable from an
# unsupported image payload.
MAX_VISION_ERROR_BODY_CHARS = 2_000
MAX_VISION_JSON_ATTEMPTS = 2
COMPACT_JSON_RETRY_INSTRUCTION = (
    "Return one complete, compact JSON object matching the requested schema. "
    "Use short field values, no Markdown fences, commentary, or reasoning. "
    "Preserve every required field and requested ID; do not invent evidence."
)


class VisionJsonResponseError(ValueError):
    """A model response was incomplete or was not parseable JSON."""

    def __init__(self, message: str, *, truncated: bool):
        super().__init__(message)
        self.truncated = truncated


class DriverDoclingVisionClient:
    """Resolve Router settings and request strict JSON from one attached image."""

    @staticmethod
    def create_http_client(*, router_url: str, timeout: httpx.Timeout) -> httpx.AsyncClient:
        """Trust the gateway CA in addition to the normal HTTPX trust store."""
        from app.core.config import (
            get_settings,
            is_gateway_transport_configured,
            resolve_gateway_anthropic_base_url,
            resolve_gateway_ca_cert_path,
        )

        settings = get_settings()
        endpoint = httpx.URL(router_url)
        gateway = httpx.URL(resolve_gateway_anthropic_base_url(settings) or "")
        uses_gateway_tls = (
            is_gateway_transport_configured(settings)
            and endpoint.scheme == "https"
            and (endpoint.scheme, endpoint.host, endpoint.port)
            == (gateway.scheme, gateway.host, gateway.port)
        )
        if not uses_gateway_tls:
            return httpx.AsyncClient(timeout=timeout)

        ca_path = resolve_gateway_ca_cert_path(settings)
        if not ca_path:
            raise RuntimeError(
                "Docling gateway TLS requires an existing PEM certificate at "
                "GATEWAY_CA_CERT_PATH; certificate verification remains enabled"
            )
        if os.getenv("SSL_CERT_FILE"):
            context = ssl.create_default_context(cafile=os.environ["SSL_CERT_FILE"])
        elif os.getenv("SSL_CERT_DIR"):
            context = ssl.create_default_context(capath=os.environ["SSL_CERT_DIR"])
        else:
            context = ssl.create_default_context(cafile=certifi.where())
        try:
            context.load_verify_locations(cafile=ca_path)
        except (OSError, ssl.SSLError) as exc:
            raise RuntimeError(
                "Cannot load Docling gateway CA from GATEWAY_CA_CERT_PATH; "
                "provide a valid PEM CA bundle"
            ) from exc
        return httpx.AsyncClient(timeout=timeout, verify=context)

    @staticmethod
    def resolve_settings() -> tuple[str, str, str]:
        """Resolve (base_url, api_key, model) for the vision endpoint.

        Gateway deployments must talk to the PMI Lite-LLM gateway directly, the
        same way the Claude CLI paths do via apply_gateway_env. Without this the
        client defaulted to the local Claude Router and picked a key belonging to
        one of the removed legacy providers, so every image request failed with a
        bare HTTP 500 from the Router.

        An explicit DRIVER_DOCLING_IMAGE_DESCRIPTION_ROUTER_URL override always
        wins, so a deployment can still pin a dedicated vision endpoint.
        """
        from app.core.config import (
            _BACKEND_DIR,
            get_settings,
            is_gateway_transport_configured,
            resolve_claude_cli_model,
            resolve_gateway_anthropic_base_url,
        )

        settings = get_settings()
        model = (
            os.getenv(VISION_MODEL_ENV_VAR)
            or resolve_claude_cli_model(settings)
        ).strip()
        url_override = (os.getenv(VISION_ROUTER_URL_ENV_VAR) or "").strip().rstrip("/")

        if not url_override and is_gateway_transport_configured(settings):
            # Anthropic-compatible gateway endpoint; request_image_json appends
            # the /v1/messages path itself.
            base_url = resolve_gateway_anthropic_base_url(settings) or ""
            api_key = (settings.GATEWAY_API_KEY or "").strip()
            if not base_url or not model:
                raise RuntimeError(
                    "Docling image description gateway URL or model is not configured"
                )
            return base_url, api_key, model

        router_url = (
            url_override
            or f"http://{settings.CLAUDE_ROUTER_HOST}:{settings.CLAUDE_ROUTER_PORT}"
        ).rstrip("/")

        # Router mode: the key is supplied by the Router's own configuration,
        # since the legacy per-provider keys are no longer registered providers.
        api_key = (settings.GATEWAY_API_KEY or "").strip() or None
        if not api_key:
            config_path = _BACKEND_DIR / "config" / ROUTER_CONFIG_FILENAME
            provider = str(settings.DEFAULT_PROVIDER or "").strip().lower()
            try:
                router_config = json.loads(config_path.read_text(encoding="utf-8"))
                providers = router_config.get("Providers") or []
                selected = next(
                    (
                        item
                        for item in providers
                        if str(item.get("name") or "").strip().lower() == provider
                    ),
                    providers[0] if providers else {},
                )
                api_key = selected.get("api_key")
            except (OSError, json.JSONDecodeError, AttributeError, TypeError):
                api_key = None

        if not router_url or not model:
            raise RuntimeError("Docling image description Router URL or model is not configured")
        return router_url, str(api_key or ""), model

    async def request_image_json(
        self,
        *,
        image_data: str,
        media_type: str,
        prompt: str,
        system_prompt: str,
        max_tokens: int,
        semaphore: Any,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
        task_id: str | None = None,
        usage_source: str | None = None,
        debug_dir: str | Path | None = None,
        debug_prefix: str = "vision_response",
    ) -> Any:
        request_body = {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": 0,
            "system": system_prompt,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_data,
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
        }
        headers = {
            "content-type": "application/json",
            "anthropic-version": ANTHROPIC_API_VERSION,
        }
        if api_key:
            headers["x-api-key"] = api_key
        messages_url = (
            f"{router_url}/messages"
            if router_url.rstrip("/").endswith("/v1")
            else f"{router_url}/v1/messages"
        )
        for attempt in range(MAX_VISION_JSON_ATTEMPTS):
            attempt_prefix = debug_prefix if attempt == 0 else f"{debug_prefix}_retry_{attempt}"
            try:
                return await self._request_image_json_once(
                    request_body=request_body, headers=headers, messages_url=messages_url,
                    semaphore=semaphore, client=client, task_id=task_id,
                    usage_source=usage_source, debug_dir=debug_dir,
                    debug_prefix=attempt_prefix,
                )
            except VisionJsonResponseError as exc:
                if attempt + 1 == MAX_VISION_JSON_ATTEMPTS:
                    raise
                if task_id and is_task_cancelled(task_id):
                    raise asyncio.CancelledError(
                        f"Task {task_id} cancelled before Docling vision retry"
                    ) from exc
                if exc.truncated:
                    retry_ceiling = get_settings().DRIVER_DOCLING_VISION_RETRY_MAX_TOKENS
                    request_body["max_tokens"] = max(
                        max_tokens, min(max_tokens * 2, retry_ceiling),
                    )
                request_body["messages"][0]["content"][-1]["text"] = (
                    f"{prompt}\n\n{COMPACT_JSON_RETRY_INSTRUCTION}"
                )
                logger.warning(
                    "Retrying Docling vision JSON: source={}, reason={}, max_tokens={}",
                    usage_source or debug_prefix,
                    "truncated" if exc.truncated else "invalid_json",
                    request_body["max_tokens"],
                )
        raise RuntimeError("Docling vision JSON attempts exhausted")

    async def _request_image_json_once(
        self, *, request_body: dict[str, Any], headers: dict[str, str],
        messages_url: str, semaphore: Any, client: httpx.AsyncClient,
        task_id: str | None, usage_source: str | None,
        debug_dir: str | Path | None, debug_prefix: str,
    ) -> Any:
        if task_id and is_task_cancelled(task_id):
            raise asyncio.CancelledError(f"Task {task_id} cancelled before Docling vision request")
        async with semaphore:
            if task_id and is_task_cancelled(task_id):
                raise asyncio.CancelledError(f"Task {task_id} cancelled before Docling vision request")
            response = await client.post(messages_url, headers=headers, json=request_body)
            if response.is_error:
                # Preserve the upstream body before raising: it is the only thing
                # that distinguishes an auth rejection from an unsupported image
                # payload, and it is otherwise lost by raise_for_status().
                error_body = (response.text or "")[:MAX_VISION_ERROR_BODY_CHARS]
                self._write_parse_debug_files(
                    debug_dir=debug_dir,
                    debug_prefix=debug_prefix,
                    response_payload=None,
                    response_text=error_body,
                    parse_error=f"Vision endpoint returned HTTP {response.status_code}",
                    status_code=response.status_code,
                    finish_reason=None,
                )
                raise httpx.HTTPStatusError(
                    f"Vision endpoint {messages_url} returned HTTP "
                    f"{response.status_code}: {error_body}",
                    request=response.request,
                    response=response,
                )
        try:
            response_payload = response.json()
        except json.JSONDecodeError as exc:
            self._write_parse_debug_files(
                debug_dir=debug_dir,
                debug_prefix=debug_prefix,
                response_payload=None,
                response_text=response.text,
                parse_error=f"Router response envelope is not JSON: {exc}",
                status_code=response.status_code,
                finish_reason=None,
            )
            raise ValueError("Router returned an invalid JSON response envelope") from exc
        if not isinstance(response_payload, dict):
            self._write_parse_debug_files(
                debug_dir=debug_dir,
                debug_prefix=debug_prefix,
                response_payload=response_payload,
                response_text=response.text,
                parse_error="Router returned a non-object response envelope",
                status_code=response.status_code,
                finish_reason=None,
            )
            raise ValueError("Router returned a non-object response")
        if response_payload.get("error") or response_payload.get("type") == "error":
            self._write_parse_debug_files(
                debug_dir=debug_dir,
                debug_prefix=debug_prefix,
                response_payload=response_payload,
                response_text=response.text,
                parse_error="Vision endpoint returned an upstream error envelope",
                status_code=response.status_code,
                finish_reason=None,
            )
            raise ValueError("Vision endpoint returned an upstream error envelope (HTTP 200)")
        await record_driver_task_token_usage(
            task_id,
            response_payload.get("usage"),
            source=usage_source or "docling_vision",
        )
        response_text = "\n".join(
            str(block.get("text") or "")
            for block in response_payload.get("content") or []
            if isinstance(block, dict) and block.get("type") == "text"
        ).strip()
        finish_reason = self._response_finish_reason(response_payload)
        payload = self.parse_json_response_text(response_text)
        output_tokens = self._response_output_tokens(response_payload)
        max_tokens = request_body["max_tokens"]
        truncated = finish_reason in {"max_tokens", "length"} or (
            payload is None and output_tokens >= max_tokens
        )
        if truncated or payload is None:
            error = (
                "Vision JSON output was truncated "
                f"(finish_reason={finish_reason}, output_tokens={output_tokens}, "
                f"max_tokens={max_tokens})"
                if truncated else "Router did not return valid JSON"
            )
            self._write_parse_debug_files(
                debug_dir=debug_dir,
                debug_prefix=debug_prefix,
                response_payload=response_payload,
                response_text=response_text,
                parse_error=error,
                status_code=response.status_code,
                finish_reason=finish_reason,
                max_tokens=max_tokens,
                output_tokens=output_tokens,
                truncated=truncated,
            )
            raise VisionJsonResponseError(error, truncated=truncated)
        return payload

    @staticmethod
    def _response_output_tokens(response_payload: dict[str, Any]) -> int:
        usage = response_payload.get("usage")
        if not isinstance(usage, dict):
            return 0
        try:
            return max(0, int(usage.get("output_tokens", usage.get("completion_tokens", 0))))
        except (ValueError, TypeError):
            return 0

    @staticmethod
    def parse_json_response_text(response_text: str) -> Any:
        candidates = [response_text.strip()]
        candidates.extend(
            re.findall(
                r"```(?:json)?\s*(.*?)\s*```",
                response_text,
                flags=re.IGNORECASE | re.DOTALL,
            )
        )
        for candidate in candidates:
            if not candidate:
                continue
            try:
                return json.loads(candidate)
            except json.JSONDecodeError:
                continue
        return None

    @staticmethod
    def _response_finish_reason(response_payload: dict[str, Any]) -> str | None:
        for key in ("stop_reason", "finish_reason"):
            value = response_payload.get(key)
            if value:
                return str(value)
        choices = response_payload.get("choices")
        if isinstance(choices, list) and choices:
            first_choice = choices[0]
            if isinstance(first_choice, dict) and first_choice.get("finish_reason"):
                return str(first_choice.get("finish_reason"))
        return None

    @staticmethod
    def _write_parse_debug_files(
        *,
        debug_dir: str | Path | None,
        debug_prefix: str,
        response_payload: Any,
        response_text: str,
        parse_error: str,
        status_code: int | None,
        finish_reason: str | None,
        max_tokens: int | None = None,
        output_tokens: int | None = None,
        truncated: bool = False,
    ) -> None:
        if debug_dir is None:
            return
        debug_path = Path(debug_dir)
        try:
            debug_path.mkdir(parents=True, exist_ok=True)
            safe_prefix = re.sub(r"[^a-zA-Z0-9_.-]+", "_", debug_prefix).strip("._")
            safe_prefix = safe_prefix or "vision_response"
            (debug_path / f"{safe_prefix}_raw_response.txt").write_text(
                response_text,
                encoding="utf-8",
            )
            (debug_path / f"{safe_prefix}_raw_response.json").write_text(
                json.dumps(response_payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            (debug_path / f"{safe_prefix}_parse_error.json").write_text(
                json.dumps(
                    {
                        "error": parse_error,
                        "status_code": status_code,
                        "finish_reason": finish_reason,
                        "max_tokens": max_tokens,
                        "output_tokens": output_tokens,
                        "truncated": truncated,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
        except OSError:
            return


def coerce_confidence(value: Any, default: float | None = None) -> float | None:
    if isinstance(value, bool):
        return default
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return default
    return confidence if 0.0 <= confidence <= 1.0 else default
