"""Vision recovery for structurally corrupted register tables."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import html
import mimetypes
import re
from pathlib import Path
from typing import Any

import httpx
from loguru import logger
from PIL import Image

from app.core.config import get_settings
from app.services.driver_docling_vision_client import (
    DriverDoclingVisionClient,
    coerce_confidence,
)
from app.services.driver_docling_prompt_templates import (
    PROMPT_VERSION,
    REGISTER_EXTRACTION_SYSTEM_PROMPT,
    REGISTER_REPAIR_SYSTEM_PROMPT,
    REGISTER_VERIFICATION_SYSTEM_PROMPT,
    build_register_extraction_prompt,
    build_register_structure_repair_prompt,
    build_register_verification_prompt,
)
from app.services.driver_docling_table_service import DriverDoclingTableService


REGISTER_TABLE_MIN_CONFIDENCE = 0.90
REGISTER_TABLE_EXTRACTION_MIN_CONFIDENCE = 0.70
REGISTER_TABLE_MAX_TABLES = 24
REGISTER_TABLE_MAX_COLUMNS = 24
REGISTER_TABLE_MAX_ROWS = 100
REGISTER_TABLE_FALLBACK_START = "<!-- docling-register-table-fallback-start -->"
REGISTER_TABLE_FALLBACK_END = "<!-- docling-register-table-fallback-end -->"
REGISTER_TABLE_PARTIAL_START = "<!-- docling-register-table-partial-fallback-start -->"
REGISTER_TABLE_PARTIAL_END = "<!-- docling-register-table-partial-fallback-end -->"
IMAGE_MARKDOWN_PATTERN = re.compile(
    r"!\[[^\]]*]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)"
)
SOURCE_IMAGE_MARKDOWN_PATTERN = re.compile(
    r"(!\[[^\]]*]\()([^\)\s]+)(?:\s+\"[^\"]*\")?(\))"
)
IMAGE_PAGE_PATTERN = re.compile(
    r"(?:\bPage\s*:\s*|_page_)(\d+)",
    re.IGNORECASE,
)
HEADING_PATTERN = re.compile(r"^#{1,6}\s+(.+?)\s*$")
TABLE_NUMBER_PATTERN = re.compile(r"\btable\s*(\d+)\b", re.IGNORECASE)
TABLE_TITLE_PATTERN = re.compile(
    r"^\s*(?:\d+(?:\.\d+)*\.?\s+)?table\s*(\d+)\b", re.IGNORECASE,
)
TABLE_TITLE_LABELS = {"caption", "section_header", "text", "paragraph"}
REGISTER_TOKEN_PATTERN = re.compile(
    r"\b(?:[0-9A-F]{2}h(?:_D[0-7])?|D[0-7](?::D[0-7])?)\b",
    re.IGNORECASE,
)


class DriverDoclingRegisterTableService:
    """Reconstruct high-risk register tables from full-page pixels."""

    def __init__(self, vision_client: DriverDoclingVisionClient | None = None):
        self._vision = vision_client or DriverDoclingVisionClient()

    def mark_candidates(
        self,
        content: str,
        table_service: DriverDoclingTableService,
        provenance_manifest: dict[str, Any] | None = None,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Mark high-confidence register table failures without removing original text."""
        if REGISTER_TABLE_FALLBACK_START in content:
            return content, []

        lines = content.splitlines()
        output: list[str] = []
        fallbacks: list[dict[str, Any]] = []
        group_primaries: dict[str, int] = {}
        index = 0
        while index < len(lines):
            if not self._is_markdown_table_line(lines[index]):
                output.append(lines[index])
                index += 1
                continue

            start = index
            block: list[str] = []
            while index < len(lines) and self._is_markdown_table_line(lines[index]):
                block.append(lines[index])
                index += 1

            fallback = self._candidate_for_block(
                lines=lines,
                block=block,
                start_index=start,
                table_service=table_service,
                provenance_manifest=provenance_manifest,
            )
            if fallback is None:
                output.extend(block)
                continue

            fallback["index"] = len(fallbacks)
            group_key = self._candidate_group_key(fallback)
            if group_key:
                primary_index = group_primaries.get(group_key)
                if primary_index is None:
                    group_primaries[group_key] = fallback["index"]
                    fallback["is_group_primary"] = True
                else:
                    fallback["is_group_primary"] = False
                    fallback["group_primary_index"] = primary_index
                    primary = fallbacks[primary_index]
                    primary["table_markdown"] = "\n\n".join(
                        part
                        for part in (
                            str(primary.get("table_markdown") or ""),
                            str(fallback.get("table_markdown") or ""),
                        )
                        if part
                    )
            fallbacks.append(fallback)
            output.append(REGISTER_TABLE_FALLBACK_START)
            output.extend(block)
            output.append(REGISTER_TABLE_FALLBACK_END)

        return "\n".join(output), fallbacks

    @staticmethod
    def apply_recoveries(
        content: str,
        recoveries: list[dict[str, Any]],
    ) -> str:
        """Apply verified replacements while preserving annotated OCR on failures."""
        pattern = re.compile(
            re.escape(REGISTER_TABLE_FALLBACK_START)
            + r".*?"
            + re.escape(REGISTER_TABLE_FALLBACK_END),
            re.DOTALL,
        )
        recovery_iter = iter(recoveries)
        recovery_by_index = {
            int(recovery.get("index")): recovery
            for recovery in recoveries
            if str(recovery.get("index", "")).isdigit()
        }

        def replace(match: re.Match[str]) -> str:
            recovery = next(recovery_iter, None)
            if recovery and recovery.get("status") == "group_member":
                primary = recovery_by_index.get(
                    int(recovery.get("group_primary_index", -1))
                )
                if primary and primary.get("status") in {"success", "partial_success", "unverified"}:
                    return ""
                return match.group(0)
            if recovery and recovery.get("status") in {
                "success",
                "partial_success",
                "unverified",
                "failed",
            }:
                return str(recovery.get("markdown") or match.group(0))
            return match.group(0)

        return pattern.sub(replace, content)

    @staticmethod
    def _candidate_group_key(fallback: dict[str, Any]) -> str:
        recovery_group = str(fallback.get("recovery_group") or "").strip()
        if not recovery_group:
            return ""
        pages = tuple(
            int(page)
            for page in (fallback.get("source_pages") or [])
            if str(page).isdigit()
        )
        if not pages:
            return ""
        return f"{pages}:{recovery_group}"

    @staticmethod
    def _is_markdown_table_line(line: str) -> bool:
        stripped = line.strip()
        return stripped.startswith("|") and stripped.endswith("|")

    def _candidate_for_block(
        self,
        *,
        lines: list[str],
        block: list[str],
        start_index: int,
        table_service: DriverDoclingTableService,
        provenance_manifest: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        issues = table_service.detect_quality_issues("\n".join(block))
        if not issues:
            return None

        rows = [self._split_cells(line) for line in block]
        heading = self._nearest_heading(lines, start_index)
        if not self._looks_like_register_table(rows, heading):
            return None

        issue = issues[0]
        reasons = set(issue.get("reasons") or [])
        broken_tokens = self._has_broken_register_tokens(rows)
        repeated_caption = self._has_repeated_table_caption(rows)
        table_numbers = self._table_numbers(heading, block)
        register_identity = (
            "register" in heading.casefold()
            or self._register_token_count(rows) >= 3
        )
        risk_signals = {
            "wide_table",
            "inconsistent_column_count",
            "repeated_cells",
        }
        high_risk = register_identity and bool(
            reasons & risk_signals or broken_tokens or repeated_caption
        )
        if not high_risk:
            return None

        source_pages, page_binding = self._resolve_provenance_pages(
            heading,
            provenance_manifest,
        )
        if not source_pages and table_numbers:
            source_pages, page_binding = self._resolve_compound_provenance_pages(
                table_numbers,
                heading,
                provenance_manifest,
            )
        source_page = source_pages[0] if source_pages else None
        image_markdown = self._image_markdown_for_pages(provenance_manifest, source_pages)
        if source_page is None:
            # Never guess a page from surrounding Markdown images. A wrong page
            # silently contaminates recovery and is worse than an explicit gap.
            page_binding = page_binding or "provenance_unknown"
        if source_page is None and not image_markdown:
            image_markdown = ""

        return {
            "status": "candidate",
            "start_line": start_index + 1,
            "end_line": start_index + len(block),
            "heading": heading,
            "reasons": sorted(reasons),
            "broken_register_tokens": broken_tokens,
            "repeated_table_caption": repeated_caption,
            "image_markdown": image_markdown,
            "source_page": source_page,
            "source_pages": source_pages,
            "page_binding": page_binding,
            "table_markdown": "\n".join(block),
            "expected_table_numbers": sorted(table_numbers),
            "recovery_group": (
                f"table_{min(table_numbers)}_{max(table_numbers)}"
                if len(table_numbers) > 1
                else f"table_{next(iter(table_numbers))}"
                if table_numbers
                else ""
            ),
            "quality_issue": issue,
            "index_policy": "replace_only_after_verified_recovery",
        }

    @classmethod
    def _resolve_provenance_pages(
        cls,
        heading: str,
        provenance_manifest: dict[str, Any] | None,
    ) -> tuple[list[int], str]:
        if not provenance_manifest:
            return [], "provenance_unknown"
        match = TABLE_NUMBER_PATTERN.search(heading or "")
        if not match:
            return [], "provenance_unknown"
        number = int(match.group(1))
        elements = provenance_manifest.get("elements") or []

        # Docling commonly emits a table title as a sibling caption or section
        # header, while the table element itself has an empty text field. Use
        # the title element's exact page provenance and require a table element
        # on that page before accepting the binding.
        title_pages: set[int] = set()
        title_indices: list[int] = []
        for element_index, element in enumerate(elements):
            label = str(element.get("label") or "").lower()
            if label not in TABLE_TITLE_LABELS:
                continue
            title_text = " ".join(
                str(element.get(key) or "")
                for key in ("text", "caption", "title")
            ).strip()
            title_match = TABLE_TITLE_PATTERN.match(title_text)
            if not title_match or int(title_match.group(1)) != number:
                continue
            title_indices.append(element_index)
            title_pages.update(
                int(page)
                for page in (element.get("pages") or [])
                if str(page).isdigit()
            )

        if title_pages:
            title_index = min(title_indices)
            next_title_index = len(elements)
            for element_index in range(title_index + 1, len(elements)):
                element = elements[element_index]
                label = str(element.get("label") or "").lower()
                if label not in TABLE_TITLE_LABELS:
                    continue
                text = " ".join(
                    str(element.get(key) or "")
                    for key in ("text", "caption", "title")
                ).strip()
                if TABLE_TITLE_PATTERN.match(text):
                    next_title_index = element_index
                    break

            table_elements = [
                element
                for element in elements
                if str(element.get("label") or "").lower() == "table"
            ]
            table_pages = {
                int(page)
                for element in table_elements
                for page in (element.get("pages") or [])
                if str(page).isdigit() and int(page) in title_pages
            }
            if table_pages:
                # Include table elements serialized after the title until the
                # next table title. This covers a table continued on the next
                # page without treating unrelated later tables as part of it.
                continuation_pages = {
                    int(page)
                    for element in elements[title_index + 1 : next_title_index]
                    if str(element.get("label") or "").lower() == "table"
                    for page in (element.get("pages") or [])
                    if str(page).isdigit() and int(page) > max(title_pages)
                }
                source_pages = sorted(table_pages | continuation_pages)
                return source_pages, "element_provenance"

        # Backward compatibility for manifests that stored the table title on
        # the table element itself.
        matches = []
        for element in elements:
            if str(element.get("label") or "").lower() != "table":
                continue
            haystack = " ".join(
                str(element.get(key) or "") for key in ("text", "caption", "title")
            )
            if re.search(rf"\btable\s*{number}\b", haystack, re.IGNORECASE):
                pages = [int(page) for page in (element.get("pages") or []) if str(page).isdigit()]
                if pages:
                    matches.append(sorted(set(pages)))
        if len(matches) == 1:
            return matches[0], "element_provenance"
        return [], "provenance_unknown"

    @classmethod
    def _resolve_compound_provenance_pages(
        cls,
        table_numbers: set[int],
        heading: str,
        provenance_manifest: dict[str, Any] | None,
    ) -> tuple[list[int], str]:
        """Inherit a page range from the adjacent parent register table.

        Docling can emit a child table title inside the parent table grid. In
        that case the child has no standalone provenance element, but the
        preceding titled register table owns the contiguous table elements.
        """
        if not provenance_manifest or not table_numbers:
            return [], "provenance_unknown"
        elements = provenance_manifest.get("elements") or []
        title_entries: list[tuple[int, int, str, set[int]]] = []
        for index, element in enumerate(elements):
            if str(element.get("label") or "").lower() not in TABLE_TITLE_LABELS:
                continue
            text = " ".join(
                str(element.get(key) or "")
                for key in ("text", "caption", "title")
            ).strip()
            match = TABLE_TITLE_PATTERN.match(text)
            if not match:
                continue
            pages = {
                int(page)
                for page in (element.get("pages") or [])
                if str(page).isdigit()
            }
            if pages:
                title_entries.append((index, int(match.group(1)), text, pages))

        if not title_entries:
            return [], "provenance_unknown"
        child_number = min(table_numbers)
        parent_candidates = [
            entry
            for entry in title_entries
            if entry[1] < child_number and "register" in entry[2].casefold()
        ]
        if not parent_candidates:
            return [], "provenance_unknown"
        parent_index, _parent_number, _parent_title, parent_pages = parent_candidates[-1]
        next_title_index = next(
            (
                index
                for index, number, _text, _pages in title_entries
                if index > parent_index and number > child_number
            ),
            len(elements),
        )
        pages = set(parent_pages)
        for element in elements[parent_index + 1 : next_title_index]:
            if str(element.get("label") or "").lower() != "table":
                continue
            pages.update(
                int(page)
                for page in (element.get("pages") or [])
                if str(page).isdigit()
            )
        if not pages:
            return [], "provenance_unknown"
        return sorted(pages), "inferred_same_compound_table"

    @staticmethod
    def _image_markdown_for_pages(
        provenance_manifest: dict[str, Any] | None,
        pages: list[int],
    ) -> str:
        if not provenance_manifest or not pages:
            return ""
        page_map = {int(item.get("page_no")): item for item in provenance_manifest.get("pages") or [] if str(item.get("page_no")).isdigit()}
        refs = []
        for page in pages:
            filename = page_map.get(page, {}).get("image_filename")
            if filename:
                refs.append(f"![Page {page}](./{filename} \"page:{page}\")")
        return "\n".join(refs)

    @staticmethod
    def _nearest_heading(lines: list[str], start_index: int) -> str:
        for line in reversed(lines[max(0, start_index - 40):start_index]):
            stripped = line.strip()
            match = HEADING_PATTERN.match(stripped)
            if match:
                return match.group(1).strip()
            if TABLE_NUMBER_PATTERN.search(stripped) and re.search(r"\bregister\b", stripped, re.IGNORECASE):
                return stripped
        return ""

    @classmethod
    def _nearest_image_markdown(
        cls,
        lines: list[str],
        start_index: int,
        *,
        source_page: int | None = None,
    ) -> str:
        candidates: list[tuple[int, str, int | None]] = []
        for line_index, line in enumerate(lines):
            stripped = line.strip()
            if IMAGE_MARKDOWN_PATTERN.search(stripped):
                candidates.append((line_index, stripped, cls._image_page_number(stripped)))
        if source_page is not None:
            same_page = [item for item in candidates if item[2] == source_page]
            if same_page:
                return min(same_page, key=lambda item: abs(item[0] - start_index))[1]
        preceding = [item for item in candidates if item[0] < start_index]
        if preceding:
            return preceding[-1][1]
        return ""

    @classmethod
    def _infer_source_page(
        cls,
        lines: list[str],
        start_index: int,
    ) -> tuple[int | None, str]:
        image_positions = [
            (line_index, cls._image_page_number(line))
            for line_index, line in enumerate(lines)
            if IMAGE_MARKDOWN_PATTERN.search(line.strip())
        ]
        image_positions = [item for item in image_positions if item[1] is not None]
        if not image_positions:
            return None, "unavailable"

        before = [item for item in image_positions if item[0] < start_index]
        after = [item for item in image_positions if item[0] >= start_index]
        previous = before[-1] if before else None
        following = after[0] if after else None

        if following and following[0] - start_index <= 8:
            return int(following[1]), "nearby_following_image"
        if previous and following and int(following[1]) > int(previous[1]) + 1:
            return int(previous[1]) + 1, "missing_page_between_images"
        if previous:
            return int(previous[1]), "nearest_preceding_image"
        if following:
            return max(1, int(following[1]) - 1), "nearest_following_image"
        return None, "unavailable"

    @staticmethod
    def _image_page_number(image_markdown: str) -> int | None:
        match = IMAGE_PAGE_PATTERN.search(image_markdown)
        return int(match.group(1)) if match else None

    @staticmethod
    def _split_cells(line: str) -> list[str]:
        return [cell.strip() for cell in line.strip().strip("|").split("|")]

    @staticmethod
    def _looks_like_register_table(rows: list[list[str]], heading: str) -> bool:
        if "register" in heading.casefold():
            return True
        return DriverDoclingRegisterTableService._register_token_count(rows) >= 3

    @staticmethod
    def _register_token_count(rows: list[list[str]]) -> int:
        return sum(
            len(REGISTER_TOKEN_PATTERN.findall(cell))
            for row in rows
            for cell in row
        )

    @classmethod
    def _table_numbers(cls, heading: str, block: list[str]) -> set[int]:
        text = heading + "\n" + "\n".join(block)
        return {
            int(match.group(1))
            for match in TABLE_NUMBER_PATTERN.finditer(text)
        }

    @staticmethod
    def _has_repeated_table_caption(rows: list[list[str]]) -> bool:
        for row in rows:
            captions = [
                re.sub(r"\s+", " ", cell.strip()).casefold()
                for cell in row
                if re.match(r"\s*table\s+\d+\b", cell, re.IGNORECASE)
            ]
            if captions and max(captions.count(value) for value in set(captions)) >= 3:
                return True
        return False

    @staticmethod
    def _has_broken_register_tokens(rows: list[list[str]]) -> bool:
        return any(
            re.search(r"\b[0-9A-F]{2}h_(?:\s|$)", cell, re.IGNORECASE)
            or re.search(r"\bD[0-7]\s+[0-9A-F]{2}h_", cell, re.IGNORECASE)
            for row in rows
            for cell in row
        )

    async def recover_tables(
        self,
        *,
        fallbacks: list[dict[str, Any]],
        image_output_dir: Path,
        source_name: str,
        timeout_seconds: float,
        concurrency: int = 2,
    ) -> list[dict[str, Any]]:
        if not fallbacks:
            return []

        try:
            router_url, api_key, model = self._vision.resolve_settings()
            timeout = httpx.Timeout(float(timeout_seconds))
            client = self._vision.create_http_client(router_url=router_url, timeout=timeout)
        except Exception as exc:
            results = []
            for index, fallback in enumerate(fallbacks):
                if fallback.get("is_group_primary") is False:
                    results.append(
                        {
                            "status": "group_member",
                            "index": index,
                            "group_primary_index": fallback.get("group_primary_index"),
                        }
                    )
                    continue
                results.append(
                    self._failure(
                        index,
                        fallback,
                        f"vision setup failed: {exc}",
                        image_path=self._resolve_image_path(
                            str(fallback.get("image_markdown") or ""),
                            image_output_dir,
                            source_page=self._coerce_source_page(fallback.get("source_page")),
                        ),
                        failure_stage="setup",
                    )
                )
            return results

        semaphore = asyncio.Semaphore(max(1, min(4, int(concurrency))))
        async with client:
            tasks = [
                (
                    asyncio.sleep(0, result={
                        "status": "group_member",
                        "index": index,
                        "group_primary_index": fallback.get("group_primary_index"),
                    })
                    if fallback.get("is_group_primary") is False
                    else self._recover_one(
                        index=index,
                        fallback=fallback,
                        image_output_dir=image_output_dir,
                        source_name=source_name,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                    )
                )
                for index, fallback in enumerate(fallbacks)
            ]
            return await asyncio.gather(*tasks)

    async def _recover_one(
        self,
        *,
        index: int,
        fallback: dict[str, Any],
        image_output_dir: Path,
        source_name: str,
        semaphore: asyncio.Semaphore,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
    ) -> dict[str, Any]:
        if str(fallback.get("page_binding") or "") == "provenance_unknown":
            return self._failure(index, fallback, "element page provenance is unavailable", failure_stage="provenance")
        image_path = self._resolve_recovery_image(fallback, image_output_dir, index)
        if image_path is None or not image_path.is_file():
            return self._failure(index, fallback, "source page image is unavailable")

        image_data = base64.b64encode(image_path.read_bytes()).decode("ascii")
        media_type = mimetypes.guess_type(image_path.name)[0] or "image/png"
        original_table = str(fallback.get("table_markdown") or "")
        heading = str(fallback.get("heading") or "")
        audit = self._image_audit(image_path, model)
        audit["page_binding"] = str(fallback.get("page_binding") or "")
        audit["expected_page"] = self._coerce_source_page(fallback.get("source_page"))
        expected_table_numbers = self._expected_table_numbers(heading, original_table)
        audit["expected_table_numbers"] = sorted(expected_table_numbers)
        failure_stage = "extraction"
        candidate_shared_header: dict[str, Any] | None = None
        candidate_tables: list[dict[str, Any]] = []
        verified_tables: list[dict[str, Any]] = []
        verified_shared_header: dict[str, Any] | None = None
        failed_table_indexes: set[int] = set()

        try:
            extracted = await self._vision.request_image_json(
                image_data=image_data,
                media_type=media_type,
                prompt=self._extraction_prompt(source_name, heading, original_table),
                system_prompt=REGISTER_EXTRACTION_SYSTEM_PROMPT,
                max_tokens=get_settings().DRIVER_DOCLING_REGISTER_TABLE_MAX_TOKENS,
                semaphore=semaphore,
                client=client,
                router_url=router_url,
                api_key=api_key,
                model=model,
            )
            audit["extraction_payload"] = extracted
            candidate_shared_header, candidate_tables, extraction_errors = (
                self._normalize_register_payload_with_shared_header(
                    extracted,
                    require_verified=False,
                )
            )
            audit["extraction_errors"] = extraction_errors
            audit["extraction_shared_header"] = candidate_shared_header

            if extraction_errors:
                failure_stage = "structure_repair"
                try:
                    repaired = await self._vision.request_image_json(
                        image_data=image_data,
                        media_type=media_type,
                        prompt=build_register_structure_repair_prompt(
                            payload=extracted,
                            errors=extraction_errors,
                            heading=heading,
                        ),
                        system_prompt=REGISTER_REPAIR_SYSTEM_PROMPT,
                        max_tokens=get_settings().DRIVER_DOCLING_REGISTER_TABLE_MAX_TOKENS,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                    )
                    audit["structure_repair_payload"] = repaired
                    repaired_shared_header, repaired_tables, repair_errors = (
                        self._normalize_register_payload_with_shared_header(
                            repaired,
                            require_verified=False,
                        )
                    )
                    audit["structure_repair_errors"] = repair_errors
                    audit["structure_repair_shared_header"] = repaired_shared_header
                    if repaired_tables:
                        candidate_tables = self._merge_repaired_tables(
                            candidate_tables,
                            repaired_tables,
                            failed_indexes={
                                int(error["table_index"])
                                for error in extraction_errors
                                if error.get("table_index")
                            },
                        )
                    candidate_shared_header = repaired_shared_header or candidate_shared_header
                except Exception as exc:
                    audit["structure_repair_request_error"] = str(exc)

            if not candidate_tables:
                raise ValueError("register table extraction produced no valid tables")

            failure_stage = "verification"
            verification_errors: list[dict[str, Any]] = []
            try:
                verified = await self._vision.request_image_json(
                    image_data=image_data,
                    media_type=media_type,
                    prompt=self._verification_prompt(
                        candidate_tables,
                        heading,
                        shared_header=candidate_shared_header,
                    ),
                    system_prompt=REGISTER_VERIFICATION_SYSTEM_PROMPT,
                    max_tokens=get_settings().DRIVER_DOCLING_REGISTER_TABLE_MAX_TOKENS,
                    semaphore=semaphore,
                    client=client,
                    router_url=router_url,
                    api_key=api_key,
                    model=model,
                )
                audit["verification_payload"] = verified
                verified_shared_header, verified_tables, verification_errors = (
                    self._normalize_register_payload_with_shared_header(
                        verified,
                        require_verified=True,
                    )
                )
                verified_tables = self._align_verified_tables(
                    verified_tables,
                    candidate_tables,
                )
            except Exception as exc:
                verification_errors = [
                    self._validation_error("verification", 0, "", str(exc))
                ]
                audit["verification_request_error"] = str(exc)
                verified_tables = []
            audit["verification_shared_header"] = verified_shared_header
            audit["verification_errors"] = verification_errors

            verified_indexes = {
                int(table["_source_index"])
                for table in verified_tables
                if isinstance(table.get("_source_index"), int)
            }
            failed_table_indexes = set(range(1, len(candidate_tables) + 1)) - verified_indexes
            retry_errors: list[dict[str, Any]] = []
            if failed_table_indexes:
                failure_stage = "verification_retry"
                retry_indexes = sorted(failed_table_indexes)
                (
                    retried_shared_header,
                    retried_tables,
                    retry_errors,
                    retry_attempts,
                ) = await self._verify_tables_individually(
                    candidate_tables=candidate_tables,
                    target_indexes=retry_indexes,
                    heading=heading,
                    shared_header=candidate_shared_header,
                    image_data=image_data,
                    media_type=media_type,
                    semaphore=semaphore,
                    client=client,
                    router_url=router_url,
                    api_key=api_key,
                    model=model,
                )
                audit["verification_retry_attempts"] = retry_attempts
                if retried_shared_header:
                    verified_shared_header = retried_shared_header
                successful_retry_indexes = [
                    int(table["_source_index"])
                    for table in retried_tables
                    if isinstance(table.get("_source_index"), int)
                ]
                verified_tables = self._merge_verified_tables(
                    verified_tables,
                    retried_tables,
                    successful_retry_indexes,
                )
                failed_table_indexes.difference_update(successful_retry_indexes)
                audit["verification_retry_errors"] = retry_errors
            audit["unresolved_table_indexes"] = sorted(failed_table_indexes)

        except Exception as exc:
            logger.warning("Register table recovery failed for {}: {}", image_path, exc)
            if candidate_tables:
                return self._unverified_recovery(
                    index=index,
                    fallback=fallback,
                    error=str(exc),
                    image_path=image_path,
                    failure_stage=failure_stage,
                    audit=audit,
                    tables=candidate_tables,
                    shared_header=candidate_shared_header,
                    original_table=original_table,
                )
            return self._failure(
                index,
                fallback,
                str(exc),
                image_path=image_path,
                failure_stage=failure_stage,
                audit=audit,
            )

        if not verified_tables:
            error = "register table verification produced no publishable tables"
            if candidate_tables:
                return self._unverified_recovery(
                    index=index,
                    fallback=fallback,
                    error=error,
                    image_path=image_path,
                    failure_stage=failure_stage,
                    audit=audit,
                    tables=candidate_tables,
                    shared_header=candidate_shared_header,
                    original_table=original_table,
                )
            return self._failure(
                index,
                fallback,
                error,
                image_path=image_path,
                failure_stage=failure_stage,
                audit=audit,
            )

        confidences = [
            float(row["confidence"])
            for table in verified_tables
            for row in table["header_rows"] + table["rows"]
        ]
        confidences.extend(
            float(span["confidence"])
            for table in verified_tables
            for span in table["merged_cells"]
        )
        if verified_shared_header:
            confidences.extend(
                float(row["confidence"])
                for row in verified_shared_header["header_rows"]
            )
            confidences.extend(
                float(span["confidence"])
                for span in verified_shared_header["merged_cells"]
            )
        unresolved_indexes = [
            index for index in failed_table_indexes if index > 0
        ]
        unresolved_titles = [
            str(candidate_tables[index - 1].get("title") or f"table {index}")
            for index in sorted(unresolved_indexes)
            if index <= len(candidate_tables)
        ]
        unresolved_tables = [
            candidate_tables[index - 1]
            for index in sorted(unresolved_indexes)
            if index <= len(candidate_tables)
        ]
        status = "partial_success" if unresolved_titles else "success"
        markdown = self._render_markdown(
            verified_tables,
            shared_header=verified_shared_header,
        )
        if status == "partial_success":
            markdown = self._render_partial_markdown(
                markdown,
                fallback,
                unresolved_titles,
                image_path,
                unverified_markdown=self._render_markdown(unresolved_tables),
            )
        return {
            "status": status,
            "index": index,
            "image_path": str(image_path),
            "shared_header": verified_shared_header,
            "tables": verified_tables,
            "unresolved_tables": unresolved_titles,
            "markdown": markdown,
            "minimum_confidence": min(confidences),
            "original_table": original_table,
            "audit": audit,
        }

    @classmethod
    def _resolve_recovery_image(
        cls,
        fallback: dict[str, Any],
        image_output_dir: Path,
        index: int,
    ) -> Path | None:
        pages = [
            cls._coerce_source_page(value)
            for value in (fallback.get("source_pages") or [])
        ]
        pages = [page for page in pages if page is not None]
        if len(pages) <= 1:
            return cls._resolve_image_path(
                str(fallback.get("image_markdown") or ""),
                image_output_dir,
                source_page=pages[0] if pages else cls._coerce_source_page(fallback.get("source_page")),
            )
        paths = [cls._resolve_image_path("", image_output_dir, source_page=page) for page in pages]
        paths = [path for path in paths if path is not None and path.is_file()]
        if not paths:
            return None
        try:
            images = [Image.open(path).convert("RGB") for path in paths]
            width = max(image.width for image in images)
            output = Image.new("RGB", (width, sum(image.height for image in images)), "white")
            y_offset = 0
            for image in images:
                output.paste(image, (0, y_offset))
                y_offset += image.height
            combined = image_output_dir / f"docling_register_recovery_{index:04d}.png"
            output.save(combined)
            return combined.resolve()
        except (OSError, ValueError) as exc:
            logger.warning("Failed to combine multi-page register images: {}", exc)
            return paths[0].resolve()

    @staticmethod
    def _resolve_image_path(
        image_markdown: str,
        image_output_dir: Path,
        *,
        source_page: int | None = None,
    ) -> Path | None:
        if source_page is not None:
            matches = sorted(image_output_dir.glob(f"*_page_{source_page:04d}.png"))
            if len(matches) == 1:
                return matches[0].resolve()
        match = re.search(r"!\[[^\]]*]\(([^)\s]+)", image_markdown)
        if not match:
            return None
        raw_path = match.group(1).removeprefix("./")
        image_name = Path(raw_path).name
        full_page_name = re.sub(
            r"_picture_\d+(?=\.[^.]+$)",
            "",
            image_name,
            flags=re.IGNORECASE,
        )
        full_page_path = image_output_dir / full_page_name
        if full_page_path.is_file():
            return full_page_path.resolve()
        parts = Path(raw_path).parts
        if image_output_dir.name in parts:
            relative_parts = parts[parts.index(image_output_dir.name) + 1:]
            return image_output_dir.joinpath(*relative_parts).resolve()
        return (image_output_dir / Path(raw_path).name).resolve()

    @staticmethod
    def _coerce_source_page(value: Any) -> int | None:
        if isinstance(value, bool):
            return None
        try:
            page = int(value)
        except (TypeError, ValueError):
            return None
        return page if page > 0 else None

    @classmethod
    def _normalize_tables(
        cls,
        payload: Any,
        *,
        require_verified: bool,
    ) -> list[dict[str, Any]]:
        tables, errors = cls._normalize_tables_with_errors(
            payload,
            require_verified=require_verified,
        )
        if errors:
            raise ValueError(str(errors[0]["error"]))
        return tables

    @classmethod
    def _normalize_register_payload_with_shared_header(
        cls,
        payload: Any,
        *,
        require_verified: bool,
    ) -> tuple[dict[str, Any] | None, list[dict[str, Any]], list[dict[str, Any]]]:
        """Normalize register tables while accepting a public header-only object.

        The optional shared header is accepted when the model explicitly returns it. Other
        returned tables are validated independently without imposing a parent/child hierarchy.
        """
        payload = cls._unwrap_register_payload(payload)
        if not isinstance(payload, dict):
            tables, errors = cls._normalize_tables_with_errors(
                payload,
                require_verified=require_verified,
            )
            return None, tables, errors

        normalized_payload = dict(payload)
        raw_tables = payload.get("tables")
        if isinstance(raw_tables, list):
            raw_tables = list(raw_tables)
        shared_raw = payload.get("shared_header")
        normalized_payload["tables"] = raw_tables
        tables, errors = cls._normalize_tables_with_errors(
            normalized_payload,
            require_verified=require_verified,
        )

        if shared_raw is None:
            return None, tables, errors

        stage = "verification" if require_verified else "extraction"
        confidence = coerce_confidence(
            (payload.get("field_confidence") or {}).get("tables")
            if isinstance(payload.get("field_confidence"), dict)
            else payload.get("confidence")
        )
        threshold = (
            REGISTER_TABLE_MIN_CONFIDENCE
            if require_verified
            else REGISTER_TABLE_EXTRACTION_MIN_CONFIDENCE
        )
        normalized_header: dict[str, Any] | None = None
        try:
            normalized_header = cls._normalize_one_table(
                shared_raw,
                table_index=0,
                default_confidence=confidence or threshold,
                threshold=threshold,
                require_verified=require_verified,
                allow_empty_rows=True,
            )
            normalized_header["table_role"] = "shared_header"
        except ValueError as exc:
            title = (
                re.sub(r"\s+", " ", str(shared_raw.get("title") or "").strip())
                if isinstance(shared_raw, dict)
                else ""
            )
            errors.append(cls._validation_error(stage, 0, title, str(exc)))
        return normalized_header, tables, errors

    @staticmethod
    def _unwrap_register_payload(payload: Any) -> Any:
        """Accept repair responses that wrap the extraction schema in candidate_payload."""
        if not isinstance(payload, dict):
            return payload
        candidate_payload = payload.get("candidate_payload")
        if not isinstance(candidate_payload, dict):
            return payload
        if not isinstance(candidate_payload.get("tables"), list):
            return payload
        unwrapped = dict(candidate_payload)
        for key in ("field_confidence", "confidence", "shared_header"):
            if key not in unwrapped and key in payload:
                unwrapped[key] = payload[key]
        return unwrapped

    @classmethod
    def _normalize_tables_with_errors(
        cls,
        payload: Any,
        *,
        require_verified: bool,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        stage = "verification" if require_verified else "extraction"
        if not isinstance(payload, dict):
            return [], [
                cls._validation_error(
                    stage,
                    0,
                    "",
                    "register table response is not an object",
                )
            ]
        threshold = (
            REGISTER_TABLE_MIN_CONFIDENCE
            if require_verified
            else REGISTER_TABLE_EXTRACTION_MIN_CONFIDENCE
        )
        tables = payload.get("tables")
        if not isinstance(tables, list) or not 1 <= len(tables) <= REGISTER_TABLE_MAX_TABLES:
            return [], [
                cls._validation_error(
                    stage,
                    0,
                    "",
                    "register table response contains an invalid table count",
                )
            ]

        normalized_tables: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = []
        for table_index, table in enumerate(tables, start=1):
            title = (
                re.sub(r"\s+", " ", str(table.get("title") or "").strip())
                if isinstance(table, dict)
                else ""
            )
            confidence = cls._table_confidence(
                payload,
                table,
                table_index=table_index,
            )
            if confidence is None or confidence < threshold:
                errors.append(
                    cls._validation_error(
                        stage,
                        table_index,
                        title,
                        "register table confidence is below the required threshold",
                    )
                )
                continue
            try:
                normalized = cls._normalize_one_table(
                    table,
                    table_index=table_index,
                    default_confidence=confidence,
                    threshold=threshold,
                    require_verified=require_verified,
                    allow_empty_rows=True,
                )
                normalized["_source_index"] = table_index
                normalized_tables.append(normalized)
            except ValueError as exc:
                errors.append(cls._validation_error(stage, table_index, title, str(exc)))
        return normalized_tables, errors

    @classmethod
    def _table_confidence(
        cls,
        payload: dict[str, Any],
        table: Any,
        *,
        table_index: int,
    ) -> float | None:
        """Resolve confidence for one table without requiring batch confidence."""
        field_confidence = payload.get("field_confidence")
        tables_confidence = (
            field_confidence.get("tables")
            if isinstance(field_confidence, dict)
            else None
        )
        batch_fallback = payload.get("confidence")
        if tables_confidence is not None and not isinstance(tables_confidence, (dict, list)):
            batch_fallback = tables_confidence
        candidates: list[Any] = []
        if isinstance(tables_confidence, dict):
            candidates.extend(
                tables_confidence.get(key)
                for key in (table_index, str(table_index), f"table_{table_index}")
            )
        elif isinstance(tables_confidence, list):
            if table_index <= len(tables_confidence):
                candidates.append(tables_confidence[table_index - 1])

        if isinstance(table, dict):
            candidates.append(table.get("confidence"))
            table_field_confidence = table.get("field_confidence")
            if isinstance(table_field_confidence, dict):
                candidates.extend(
                    table_field_confidence.get(key)
                    for key in ("table", "tables", "confidence")
                )
            for row in [*(table.get("header_rows") or []), *(table.get("rows") or [])]:
                if isinstance(row, dict):
                    candidates.append(row.get("confidence"))
            for span in table.get("merged_cells") or []:
                if isinstance(span, dict):
                    candidates.append(span.get("confidence"))

        explicit = [coerce_confidence(value) for value in candidates]
        explicit = [value for value in explicit if value is not None]
        return min(explicit) if explicit else coerce_confidence(batch_fallback)

    @staticmethod
    def _merge_repaired_tables(
        candidate_tables: list[dict[str, Any]],
        repaired_tables: list[dict[str, Any]],
        failed_indexes: set[int] | None = None,
    ) -> list[dict[str, Any]]:
        """Replace repaired table positions while retaining valid extraction results."""
        failed_indexes = failed_indexes or set()
        by_index = {
            int(table["_source_index"]): table
            for table in candidate_tables
            if table.get("_source_index") is not None
        }
        expected_table_count = len(candidate_tables) + len(failed_indexes)
        full_response = bool(failed_indexes) and len(repaired_tables) >= expected_table_count
        if full_response:
            for source_index, table in enumerate(repaired_tables, start=1):
                by_index[source_index] = table
        else:
            next_failed_index = iter(sorted(failed_indexes))
            next_index = max(by_index, default=0) + 1
            for table in repaired_tables:
                source_index = next(next_failed_index, None)
                if source_index is None:
                    source_index = next_index
                    next_index += 1
                by_index[source_index] = table
        if not by_index:
            merged = repaired_tables
        else:
            merged = [by_index[index] for index in sorted(by_index)]
        return [
            {key: value for key, value in table.items() if key != "_source_index"}
            for table in merged
        ]

    @classmethod
    def _normalize_one_table(
        cls,
        table: Any,
        *,
        table_index: int,
        default_confidence: float,
        threshold: float,
        require_verified: bool,
        allow_empty_rows: bool = False,
    ) -> dict[str, Any]:
        if not isinstance(table, dict):
            raise ValueError(f"register table {table_index} is not an object")
        if require_verified and table.get("verified") is not True:
            raise ValueError(f"register table {table_index} was not verified")

        title = re.sub(r"\s+", " ", str(table.get("title") or "").strip())

        raw_header_rows = table.get("header_rows")
        if not isinstance(raw_header_rows, list):
            legacy_columns = cls._normalize_cells(table.get("columns"))
            raw_header_rows = [{"cells": legacy_columns, "confidence": default_confidence}]

        column_count = cls._coerce_column_count(table.get("column_count"))
        if column_count is None and len(raw_header_rows) == 1:
            first_header = raw_header_rows[0]
            first_cells = (
                first_header.get("cells") if isinstance(first_header, dict) else first_header
            )
            column_count = len(cls._normalize_cells(first_cells))
        if column_count is None or not 2 <= column_count <= REGISTER_TABLE_MAX_COLUMNS:
            raise ValueError(f"register table {table_index} has an invalid column count")

        header_rows = cls._normalize_grid_rows(
            raw_header_rows,
            table_index=table_index,
            row_kind="header row",
            column_count=column_count,
            default_confidence=default_confidence,
            threshold=threshold,
            require_verified=require_verified,
        )
        raw_rows = table.get("rows")
        if not isinstance(raw_rows, list) or (
            not allow_empty_rows and not 1 <= len(raw_rows) <= REGISTER_TABLE_MAX_ROWS
        ) or len(raw_rows) > REGISTER_TABLE_MAX_ROWS:
            raise ValueError(f"register table {table_index} has an invalid row count")
        rows = cls._normalize_grid_rows(
            raw_rows,
            table_index=table_index,
            row_kind="row",
            column_count=column_count,
            default_confidence=default_confidence,
            threshold=threshold,
            require_verified=require_verified,
        )
        merge_warnings: list[str] = []
        merged_cells = cls._normalize_merged_cells(
            table.get("merged_cells"),
            table_index=table_index,
            header_row_count=len(header_rows),
            body_row_count=len(rows),
            column_count=column_count,
            default_confidence=default_confidence,
            threshold=threshold,
            require_verified=require_verified,
            warnings=merge_warnings,
        )
        cls._apply_merged_cells(header_rows, rows, merged_cells, warnings=merge_warnings)

        columns = cls._flatten_header_rows(header_rows, column_count)
        if cls._has_duplicate_columns(columns) and not cls._duplicates_explained_by_merges(
            columns, merged_cells,
        ):
            raise ValueError(f"register table {table_index} has duplicate columns")

        for row_index, row in enumerate(rows, start=1):
            if any(cls._is_broken_register_fragment(cell) for cell in row["cells"]):
                raise ValueError(
                    f"register table {table_index} row {row_index} contains a broken register token"
                )

        normalized_table = {
            "title": title,
            "column_count": column_count,
            "header_rows": header_rows,
            "merged_cells": merged_cells,
            "columns": columns,
            "rows": rows,
        }
        if merge_warnings:
            normalized_table["merge_warnings"] = merge_warnings
        return normalized_table

    @classmethod
    def _normalize_grid_rows(
        cls,
        raw_rows: list[Any],
        *,
        table_index: int,
        row_kind: str,
        column_count: int,
        default_confidence: float,
        threshold: float,
        require_verified: bool,
    ) -> list[dict[str, Any]]:
        normalized_rows: list[dict[str, Any]] = []
        for row_index, raw_row in enumerate(raw_rows, start=1):
            row = raw_row if isinstance(raw_row, dict) else {"cells": raw_row}
            if not isinstance(row.get("cells"), list):
                raise ValueError(
                    f"register table {table_index} {row_kind} {row_index} is not an object"
                )
            if require_verified and row.get("verified") is not True:
                raise ValueError(
                    f"register table {table_index} {row_kind} {row_index} was not verified"
                )
            row_confidence = coerce_confidence(row.get("confidence"), default_confidence)
            if row_confidence is None or row_confidence < threshold:
                raise ValueError(
                    f"register table {table_index} {row_kind} {row_index} confidence is too low"
                )
            cells = cls._normalize_cells(row.get("cells"))
            if len(cells) != column_count:
                raise ValueError(
                    f"register table {table_index} {row_kind} {row_index} has "
                    f"{len(cells)} cells; expected {column_count}"
                )
            normalized_rows.append(
                {
                    "cells": cells,
                    "confidence": round(float(row_confidence), 4),
                }
            )
        return normalized_rows

    @classmethod
    def _normalize_merged_cells(
        cls,
        raw_merged_cells: Any,
        *,
        table_index: int,
        header_row_count: int,
        body_row_count: int,
        column_count: int,
        default_confidence: float,
        threshold: float,
        require_verified: bool,
        warnings: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        def warn(message: str) -> None:
            if warnings is not None:
                warnings.append(message)

        if raw_merged_cells in (None, []):
            return []
        if not isinstance(raw_merged_cells, list) or len(raw_merged_cells) > 128:
            warn(f"register table {table_index} has invalid merged cell metadata")
            return []

        normalized: list[dict[str, Any]] = []
        for span_index, raw_span in enumerate(raw_merged_cells, start=1):
            if not isinstance(raw_span, dict):
                warn(
                    f"register table {table_index} merged cell {span_index} is not an object"
                )
                continue
            scope = str(raw_span.get("scope") or "").strip().casefold()
            if scope not in {"header", "body"}:
                warn(
                    f"register table {table_index} merged cell {span_index} has invalid scope"
                )
                continue
            if require_verified and raw_span.get("verified") is not True:
                warn(
                    f"register table {table_index} merged cell {span_index} was not verified"
                )
                continue
            confidence = coerce_confidence(raw_span.get("confidence"), default_confidence)
            if confidence is None or confidence < threshold:
                warn(
                    f"register table {table_index} merged cell {span_index} confidence is too low"
                )
                continue

            row = cls._coerce_zero_based_index(raw_span.get("row"))
            column = cls._coerce_zero_based_index(raw_span.get("column"))
            row_span = cls._coerce_positive_span(raw_span.get("row_span"))
            col_span = cls._coerce_positive_span(raw_span.get("col_span"))
            value = re.sub(r"\s+", " ", str(raw_span.get("value") or "").strip())
            row_count = header_row_count if scope == "header" else body_row_count
            if row is None or column is None or row_span is None or col_span is None:
                warn(
                    f"register table {table_index} merged cell {span_index} has invalid coordinates"
                )
                continue
            if row_span == 1 and col_span == 1:
                warn(
                    f"register table {table_index} merged cell {span_index} has no span"
                )
                continue
            if row + row_span > row_count or column + col_span > column_count:
                warn(
                    f"register table {table_index} merged cell {span_index} exceeds table bounds"
                )
                continue
            if not value:
                warn(
                    f"register table {table_index} merged cell {span_index} has no value"
                )
                continue
            normalized.append(
                {
                    "scope": scope,
                    "row": row,
                    "column": column,
                    "row_span": row_span,
                    "col_span": col_span,
                    "value": value,
                    "confidence": round(float(confidence), 4),
                }
            )
        return normalized

    @staticmethod
    def _apply_merged_cells(
        header_rows: list[dict[str, Any]],
        body_rows: list[dict[str, Any]],
        merged_cells: list[dict[str, Any]],
        *,
        warnings: list[str] | None = None,
    ) -> None:
        occupied: set[tuple[str, int, int]] = set()
        for span in merged_cells:
            rows = header_rows if span["scope"] == "header" else body_rows
            for row_index in range(span["row"], span["row"] + span["row_span"]):
                for column_index in range(
                    span["column"],
                    span["column"] + span["col_span"],
                ):
                    key = (span["scope"], row_index, column_index)
                    if key in occupied:
                        if warnings is not None:
                            warnings.append("register table contains overlapping merged cells")
                        continue
                    occupied.add(key)
                    if (
                        0 <= row_index < len(rows)
                        and 0 <= column_index < len(rows[row_index]["cells"])
                    ):
                        rows[row_index]["cells"][column_index] = span["value"]

    @staticmethod
    def _coerce_zero_based_index(value: Any) -> int | None:
        if isinstance(value, bool):
            return None
        try:
            index = int(value)
        except (TypeError, ValueError):
            return None
        return index if index >= 0 else None

    @staticmethod
    def _coerce_positive_span(value: Any) -> int | None:
        if isinstance(value, bool):
            return None
        try:
            span = int(value)
        except (TypeError, ValueError):
            return None
        return span if span > 0 else None

    @staticmethod
    def _coerce_column_count(value: Any) -> int | None:
        if isinstance(value, bool):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _flatten_header_rows(
        header_rows: list[dict[str, Any]],
        column_count: int,
    ) -> list[str]:
        columns: list[str] = []
        for column_index in range(column_count):
            path: list[str] = []
            for row in header_rows:
                cells = row.get("cells") or []
                value = cells[column_index] if column_index < len(cells) else ""
                if value and (not path or path[-1].casefold() != value.casefold()):
                    path.append(value)
            columns.append(" / ".join(path))
        return columns

    @staticmethod
    def _validation_error(
        stage: str,
        table_index: int,
        title: str,
        error: str,
    ) -> dict[str, Any]:
        return {
            "stage": stage,
            "table_index": table_index,
            "title": title,
            "error": error,
        }

    @staticmethod
    def _normalize_cells(value: Any) -> list[str]:
        if not isinstance(value, list):
            return []
        return [re.sub(r"\s+", " ", str(cell or "").strip()) for cell in value]

    @staticmethod
    def _has_duplicate_columns(columns: list[str]) -> bool:
        normalized = [column.casefold() for column in columns if column]
        return len(normalized) != len(set(normalized))

    @staticmethod
    def _duplicates_explained_by_merges(
        columns: list[str],
        merged_cells: list[dict[str, Any]],
    ) -> bool:
        duplicate_groups: dict[str, list[int]] = {}
        for index, column in enumerate(columns):
            normalized = column.casefold()
            if normalized:
                duplicate_groups.setdefault(normalized, []).append(index)
        duplicate_groups = {
            value: indexes for value, indexes in duplicate_groups.items() if len(indexes) > 1
        }
        if not duplicate_groups:
            return False
        header_spans = [span for span in merged_cells if span.get("scope") == "header"]
        return all(
            any(
                span["column"] <= min(indexes)
                and max(indexes) < span["column"] + span["col_span"]
                for span in header_spans
            )
            for indexes in duplicate_groups.values()
        )

    @staticmethod
    def _is_broken_register_fragment(value: str) -> bool:
        normalized = str(value or "").strip()
        return bool(
            re.search(r"\b[0-9A-F]{2}h_$", normalized, re.IGNORECASE)
            or re.fullmatch(r"D[0-7]\s+[0-9A-F]{2}h_", normalized, re.IGNORECASE)
        )

    @staticmethod
    def _expected_table_numbers(heading: str, original_table: str) -> set[int]:
        return {
            int(match.group(1))
            for match in TABLE_NUMBER_PATTERN.finditer(f"{heading}\n{original_table}")
        }

    @staticmethod
    def _align_verified_tables(
        verified_tables: list[dict[str, Any]],
        candidate_tables: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Bind verified responses to candidates by title before falling back to position."""
        candidate_indexes: dict[str, list[int]] = {}
        for position, table in enumerate(candidate_tables, start=1):
            title = re.sub(r"\s+", " ", str(table.get("title") or "").strip()).casefold()
            if title:
                candidate_indexes.setdefault(title, []).append(position)
        used: set[int] = set()
        aligned: list[dict[str, Any]] = []
        for position, table in enumerate(verified_tables, start=1):
            title = re.sub(r"\s+", " ", str(table.get("title") or "").strip()).casefold()
            matches = [index for index in candidate_indexes.get(title, []) if index not in used]
            target_index = matches[0] if matches else None
            if target_index is None:
                source_index = table.get("_source_index")
                if isinstance(source_index, int) and 1 <= source_index <= len(candidate_tables):
                    if source_index not in used:
                        target_index = source_index
            if target_index is None:
                available = [index for index in range(1, len(candidate_tables) + 1) if index not in used]
                target_index = available[0] if available else position
            replacement = dict(table)
            replacement["_source_index"] = target_index
            used.add(target_index)
            aligned.append(replacement)
        return aligned

    async def _verify_tables_individually(
        self,
        *,
        candidate_tables: list[dict[str, Any]],
        target_indexes: list[int],
        heading: str,
        shared_header: dict[str, Any] | None,
        image_data: str,
        media_type: str,
        semaphore: asyncio.Semaphore,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
    ) -> tuple[dict[str, Any] | None, list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        """Verify only the unresolved candidates and keep each result independent."""
        verified_tables: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = []
        attempts: list[dict[str, Any]] = []
        verified_shared_header: dict[str, Any] | None = None
        for target_index in target_indexes:
            if not 1 <= target_index <= len(candidate_tables):
                continue
            candidate = candidate_tables[target_index - 1]
            title = str(candidate.get("title") or f"table {target_index}")
            try:
                response = await self._vision.request_image_json(
                    image_data=image_data,
                    media_type=media_type,
                    prompt=self._verification_prompt(
                        [candidate],
                        heading,
                        shared_header=shared_header,
                    ),
                    system_prompt=REGISTER_VERIFICATION_SYSTEM_PROMPT,
                    max_tokens=get_settings().DRIVER_DOCLING_REGISTER_TABLE_MAX_TOKENS,
                    semaphore=semaphore,
                    client=client,
                    router_url=router_url,
                    api_key=api_key,
                    model=model,
                )
                response_shared_header, response_tables, response_errors = (
                    self._normalize_register_payload_with_shared_header(
                        response,
                        require_verified=True,
                    )
                )
                if response_shared_header:
                    verified_shared_header = response_shared_header
                selected = next(
                    (
                        table for table in response_tables
                        if re.sub(r"\s+", " ", str(table.get("title") or "").strip()).casefold()
                        == re.sub(r"\s+", " ", title).casefold()
                    ),
                    response_tables[0] if response_tables else None,
                )
                if selected is None:
                    error = response_errors[0]["error"] if response_errors else "verification returned no table"
                    errors.append(self._validation_error("verification_retry", target_index, title, error))
                    attempts.append({"table_index": target_index, "title": title, "status": "failed", "error": error})
                    continue
                selected = dict(selected)
                selected["_source_index"] = target_index
                verified_tables.append(selected)
                attempts.append({"table_index": target_index, "title": title, "status": "verified"})
            except Exception as exc:
                error = str(exc)
                errors.append(self._validation_error("verification_retry", target_index, title, error))
                attempts.append({"table_index": target_index, "title": title, "status": "failed", "error": error})
        return verified_shared_header, verified_tables, errors, attempts

    @staticmethod
    def _render_markdown(
        tables: list[dict[str, Any]],
        *,
        shared_header: dict[str, Any] | None = None,
    ) -> str:
        output: list[str] = []
        render_tables = ([shared_header] if shared_header else []) + list(tables)
        for table in render_tables:
            if output:
                output.append("")
            output.append(f"**{table['title']}**")
            output.append("")
            columns = [
                DriverDoclingRegisterTableService._escape_cell(cell)
                for cell in (
                    table["header_rows"][0]["cells"]
                    if table.get("table_role") == "shared_header"
                    else table["columns"]
                )
            ]
            output.append("| " + " | ".join(columns) + " |")
            output.append("|" + "|".join("---" for _ in columns) + "|")
            body_rows = (
                table["header_rows"][1:]
                if table.get("table_role") == "shared_header"
                else table["rows"] or table["header_rows"][1:]
            )
            for row in body_rows:
                cells = [
                    DriverDoclingRegisterTableService._escape_cell(cell)
                    for cell in row["cells"]
                ]
                output.append("| " + " | ".join(cells) + " |")
        return "\n".join(output)

    @classmethod
    def _render_partial_markdown(
        cls,
        verified_markdown: str,
        fallback: dict[str, Any],
        unresolved_titles: list[str],
        image_path: Path,
        *,
        unverified_markdown: str = "",
    ) -> str:
        unresolved_summary = ", ".join(unresolved_titles)
        original_table = str(fallback.get("table_markdown") or "")
        fallback_markdown = cls._source_image_markdown(fallback, image_path)
        lines = [
            verified_markdown,
            "",
            REGISTER_TABLE_PARTIAL_START,
            (
                "> WARNING: Some register tables could not be verified: "
                f"{unresolved_summary}. Any candidate tables below are retained for reference "
                "only and must not be treated as trusted register data."
            ),
        ]
        if unverified_markdown.strip():
            lines.extend(["", "> Unverified table candidates:", "", unverified_markdown])
        if original_table.strip():
            lines.extend(["", cls._unverified_ocr_markdown(original_table)])
        if fallback_markdown:
            lines.extend(["", fallback_markdown])
        lines.append(REGISTER_TABLE_PARTIAL_END)
        return "\n".join(lines)

    @classmethod
    def _image_fallback_markdown(
        cls,
        fallback: dict[str, Any],
        image_path: Path | None,
    ) -> str:
        original_table = str(fallback.get("table_markdown") or "")
        lines = [
            REGISTER_TABLE_PARTIAL_START,
            (
                "> WARNING: This register table could not be verified. The OCR table below is "
                "retained for reference only and must not be treated as trusted register data."
            ),
        ]
        if original_table.strip():
            lines.extend(["", cls._unverified_ocr_markdown(original_table)])
        if image_path is not None and image_path.is_file():
            image_markdown = cls._source_image_markdown(fallback, image_path)
            if image_markdown:
                lines.extend(["", image_markdown])
        else:
            lines.extend(["", "> WARNING: Source page image is unavailable."])
        lines.append(REGISTER_TABLE_PARTIAL_END)
        return "\n".join(lines)

    @staticmethod
    def _unverified_ocr_markdown(original_table: str) -> str:
        """Keep raw OCR searchable without rendering malformed rows as a trusted table."""
        escaped = html.escape(original_table.strip(), quote=False)
        return (
            "<details>\n"
            "<summary>Original OCR table (unverified)</summary>\n\n"
            "<pre>\n"
            f"{escaped}\n"
            "</pre>\n"
            "</details>"
        )

    @staticmethod
    def _source_image_markdown(
        fallback: dict[str, Any],
        image_path: Path | None,
    ) -> str:
        original = str(fallback.get("image_markdown") or "").strip()
        if image_path is None:
            return original
        match = SOURCE_IMAGE_MARKDOWN_PATTERN.search(original)
        title = DriverDoclingRegisterTableService._source_image_title(image_path)
        if match:
            old_path = match.group(2)
            normalized = old_path.replace("\\", "/")
            prefix = normalized.rsplit("/", 1)[0] if "/" in normalized else "."
            new_link = f"{match.group(1)}{prefix}/{image_path.name}{title}{match.group(3)}"
            return f"{original[:match.start()]}{new_link}{original[match.end():]}"
        return f"![Source page](./{image_path.parent.name}/{image_path.name}{title})"

    @staticmethod
    def _source_image_title(image_path: Path) -> str:
        page_match = re.search(r"_page_(\d+)", image_path.name, re.IGNORECASE)
        if not page_match:
            return ""
        return f' "Page:{int(page_match.group(1))}"'

    @staticmethod
    def _image_audit(image_path: Path, model: str) -> dict[str, Any]:
        width = None
        height = None
        try:
            with Image.open(image_path) as image:
                width, height = image.size
        except OSError:
            pass
        page_match = re.search(r"_page_(\d+)", image_path.name, re.IGNORECASE)
        return {
            "prompt_version": PROMPT_VERSION,
            "model": model,
            "image_name": image_path.name,
            "image_width": width,
            "image_height": height,
            "page_number": int(page_match.group(1)) if page_match else None,
            "image_sha256": hashlib.sha256(image_path.read_bytes()).hexdigest(),
        }

    @staticmethod
    def _escape_cell(value: Any) -> str:
        return str(value or "").replace("|", "\\|").replace("\n", " ").strip()

    @staticmethod
    def _extraction_prompt(source_name: str, heading: str, original_table: str) -> str:
        return build_register_extraction_prompt(
            source_name=source_name,
            heading=heading,
            original_table=original_table,
        )

    @staticmethod
    def _verification_prompt(
        tables: list[dict[str, Any]],
        heading: str,
        *,
        shared_header: dict[str, Any] | None = None,
    ) -> str:
        return build_register_verification_prompt(
            tables=tables,
            heading=heading,
            shared_header=shared_header,
        )

    @staticmethod
    def _unverified_recovery(
        *,
        index: int,
        fallback: dict[str, Any],
        error: str,
        image_path: Path,
        failure_stage: str,
        audit: dict[str, Any],
        tables: list[dict[str, Any]],
        shared_header: dict[str, Any] | None,
        original_table: str,
    ) -> dict[str, Any]:
        titles = [
            str(table.get("title") or f"table {position}")
            for position, table in enumerate(tables, start=1)
        ]
        confidences = [
            float(row["confidence"])
            for table in tables
            for row in table.get("header_rows", []) + table.get("rows", [])
            if coerce_confidence(row.get("confidence")) is not None
        ]
        markdown = DriverDoclingRegisterTableService._render_markdown(
            tables,
            shared_header=shared_header,
        )
        markdown = DriverDoclingRegisterTableService._render_partial_markdown(
            markdown,
            fallback,
            titles,
            image_path,
        )
        audit = dict(audit)
        audit["unverified_table_titles"] = titles
        return {
            "status": "unverified",
            "index": index,
            "image_path": str(image_path),
            "error": error,
            "failure_stage": failure_stage,
            "shared_header": shared_header,
            "tables": tables,
            "unresolved_tables": titles,
            "markdown": markdown,
            "minimum_confidence": min(confidences) if confidences else 0.0,
            "original_table": original_table,
            "audit": audit,
        }

    @staticmethod
    def _failure(
        index: int,
        fallback: dict[str, Any],
        error: str,
        *,
        image_path: Path | None = None,
        failure_stage: str = "setup",
        audit: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return {
            "status": "failed",
            "index": index,
            "image_path": str(image_path or ""),
            "error": error,
            "failure_stage": failure_stage,
            "original_table": str(fallback.get("table_markdown") or ""),
            "markdown": DriverDoclingRegisterTableService._image_fallback_markdown(
                fallback,
                image_path,
            ),
            "audit": audit or {},
        }

    @staticmethod
    def _verification_error_indexes(
        errors: list[dict[str, Any]],
        *,
        table_count: int,
    ) -> set[int]:
        indexes = {
            int(error.get("table_index"))
            for error in errors
            if str(error.get("table_index", "")).isdigit()
            and 1 <= int(error.get("table_index")) <= table_count
        }
        if errors and not indexes:
            return set(range(1, table_count + 1))
        return indexes

    @staticmethod
    def _merge_verified_tables(
        verified_tables: list[dict[str, Any]],
        retried_tables: list[dict[str, Any]],
        target_indexes: list[int],
    ) -> list[dict[str, Any]]:
        by_index: dict[int, dict[str, Any]] = {}
        for position, table in enumerate(verified_tables, start=1):
            source_index = table.get("_source_index")
            by_index[int(source_index) if source_index is not None else position] = table
        for target_index, table in zip(target_indexes, retried_tables):
            replacement = dict(table)
            replacement["_source_index"] = target_index
            by_index[target_index] = replacement
        return [by_index[index] for index in sorted(by_index)]
