"""Read and normalize Jira bug context for previews and agent execution."""

import re
from typing import Any

from loguru import logger

from app.core.config import get_settings


class JiraContextError(ValueError):
    """A Jira bug could not be loaded safely."""

    def __init__(self, message: str, status_code: int = 502):
        super().__init__(message)
        self.status_code = status_code


def configured_issue_types() -> tuple[str, ...]:
    """Return safe Jira issue type names configured for the current industry."""
    raw = str(get_settings().JIRA_ISSUE_TYPES or "Bug")
    values = []
    for item in raw.split(","):
        value = re.sub(r"[^A-Za-z0-9 _-]", "", item).strip()
        if value and value.casefold() not in {entry.casefold() for entry in values}:
            values.append(value[:80])
    return tuple(values or ("Bug",))


def _issue_type_jql() -> str:
    """Build an escaped JQL issue type clause for cloud and server Jira."""
    values = configured_issue_types()
    if len(values) == 1:
        # Preserve the long-standing default query used by Jira MCP adapters.
        # Custom issue types are quoted because names may contain spaces.
        if values[0].casefold() == "bug":
            return "issuetype = Bug"
        return f'issuetype = "{values[0]}"'
    quoted = ", ".join(f'"{value}"' for value in values)
    return f"issuetype in ({quoted})"


def jira_text(value: Any) -> str:
    """Flatten Jira text or Atlassian document nodes into readable text."""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "".join(jira_text(node) for node in value)
    if not isinstance(value, dict):
        return ""
    if value.get("type") == "hardBreak":
        return "\n"
    text = str(value.get("text") or "") + jira_text(value.get("content", []))
    if value.get("type") in {"paragraph", "heading", "listItem", "codeBlock"}:
        text += "\n"
    return text


def normalize_issue(data: dict) -> dict:
    """Expose only the Jira fields needed by the bug-fix workflow."""
    return {
        field: jira_text(data.get(field)).strip()
        for field in (
            "key", "summary", "description", "status", "priority", "issue_type", "assignee", "updated"
        )
    }


async def _call_jira(mcp_client, tool: str, **arguments) -> dict:
    if mcp_client is None:
        raise JiraContextError("Jira is not configured. Configure the Jira integration first.", 503)
    try:
        result = await mcp_client.call_tool(tool, **arguments)
    except Exception as error:
        logger.warning("Jira bug lookup failed ({})", type(error).__name__)
        raise JiraContextError(
            "Jira could not be read. Check the integration, ticket key, and access permissions."
        ) from error
    if not result.success or not isinstance(result.data, dict):
        raise JiraContextError(
            "Jira could not be read. Check the integration, ticket key, and access permissions."
        )
    return result.data


async def load_jira_bug(mcp_client, issue_key: str) -> dict:
    """Load an existing Bug ticket; never substitute user notes for a failed lookup."""
    key = issue_key.strip().upper()
    if not re.fullmatch(r"[A-Z][A-Z0-9_]*-[1-9][0-9]*", key):
        raise JiraContextError("Enter a Jira ticket key such as FW-123.", 422)
    issue = normalize_issue(await _call_jira(mcp_client, "jira_get_issue", issue_key=key))
    accepted_types = {value.casefold() for value in configured_issue_types()}
    if issue["issue_type"].casefold() not in accepted_types:
        labels = ", ".join(configured_issue_types())
        raise JiraContextError(f"Select a Jira ticket with issue type {labels}.", 422)
    if issue["key"].upper() != key or not issue["summary"]:
        raise JiraContextError("Jira returned incomplete or mismatched ticket details.")
    return issue


async def list_jira_bugs(mcp_client, project: str, max_results: int = 20) -> dict:
    """Read recent Bug tickets from Jira or limit them to one validated project."""
    project_key = project.strip().upper()
    issue_types = configured_issue_types()
    if project_key and issue_types == ("Bug",):
        if not re.fullmatch(r"[A-Z][A-Z0-9_]*", project_key):
            raise JiraContextError("Enter a Jira project key such as FW.", 422)
        data = await _call_jira(
            mcp_client, "jira_get_bugs", project=project_key, max_results=max_results
        )
    else:
        if project_key and not re.fullmatch(r"[A-Z][A-Z0-9_]*", project_key):
            raise JiraContextError("Enter a Jira project key such as FW.", 422)
        project_clause = f'project = "{project_key}" AND ' if project_key else ""
        data = await _call_jira(
            mcp_client,
            "jira_search",
            jql=f"{project_clause}{_issue_type_jql()} ORDER BY updated DESC",
            max_results=max_results,
        )
    raw_issues = data.get("issues")
    if not isinstance(raw_issues, list):
        raise JiraContextError("Jira did not return a bug list.")
    issues = [
        normalize_issue(item) for item in raw_issues
        if isinstance(item, dict)
        and str(item.get("issue_type") or "").casefold() in {value.casefold() for value in issue_types}
    ]
    return {"issues": issues[:max_results], "total": data.get("total", len(issues))}
