"""
@file driver_docling_service.py
@brief Document parsing service using Docling for multi-format extraction.

Strictly follows the Docling library architecture:
- DocumentConverter with format-specific pipeline options
- PDF pipeline: OCR, table structure detection, layout analysis
- Multi-format export: markdown, text, JSON, HTML
- Chunking: HierarchicalChunker + HybridChunker for token-aware splitting
- Batch conversion support
- Structured metadata extraction (pages, tables, figures, headings)

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import html
import json
import os
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Literal
from urllib.parse import unquote

from loguru import logger
from app.core.driver_storage import get_driver_temp_root
from app.core.runtime_dependencies import check_docling_runtime

from app.services.driver_docling_formula_service import (
    FORMULA_IMAGES_DIRNAME,
    FORMULA_RECOGNITION_DIRNAME,
    DriverDoclingFormulaService,
)
from app.services.driver_docling_image_description_service import (
    DriverDoclingImageDescriptionService,
)
from app.services.driver_docling_postprocess_service import (
    DEFAULT_TOC_MAX_ITEMS,
    MAX_TOC_MAX_ITEMS,
    MIN_TOC_MAX_ITEMS,
)
from app.services.driver_docling_vision_client import DriverDoclingVisionClient


# Supported file extensions for Docling processing
DOCLING_SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".pptx", ".xlsx", ".html",
    ".md", ".csv", ".png", ".jpg", ".jpeg", ".tiff", ".bmp",
}

# Direct text extensions (no Docling needed)
DIRECT_TEXT_EXTENSIONS = {".c", ".h", ".cpp", ".hpp", ".txt", ".md", ".mk", ".ld", ".s", ".S", ".net"}

# Maximum file size for parsing (50 MB)
MAX_PARSE_SIZE_BYTES = 50 * 1024 * 1024

# Default chunking parameters
_DEFAULT_MAX_TOKENS = 1024
_DEFAULT_OVERLAP_TOKENS = 128
_MAX_IMAGE_STEM_LENGTH = 120
APPROX_CHARS_PER_TOKEN = 4
PARAGRAPH_SEPARATOR = "\n\n"
IMAGE_FILENAME_INDEX_WIDTH = 4
BYTES_PER_KIB = 1024
MARKDOWN_MAX_HEADING_LEVEL = 6
MARKDOWN_HEADING_PATTERN = re.compile(
    rf"^(#{{1,{MARKDOWN_MAX_HEADING_LEVEL}}})\s+(.+)"
)
TABLE_CAPTION_PATTERN = re.compile(r"^\s*(Table\s+\d+\s+.+?)\s*$", re.IGNORECASE)
EMBEDDED_TABLE_CAPTION_PATTERN = re.compile(
    r"\b(Table\s+\d+\s+.*?\b(?:Register|Map)\b.*?)\s*$",
    re.IGNORECASE,
)
PICTURE_IMAGE_FILENAME_PATTERN = re.compile(
    rf".*_page_\d{{{IMAGE_FILENAME_INDEX_WIDTH}}}"
    rf"_picture_\d{{{IMAGE_FILENAME_INDEX_WIDTH}}}\.png"
)

ImageDescriptionMode = Literal["router_vision", "claude_cli"]


class DoclingPathAccessError(ValueError):
    """Raised when a requested input path escapes the configured upload directory."""


DEFAULT_DOCLING_UPLOAD_DIR = "data/uploads/driver"
DEFAULT_DOCLING_ARTIFACTS_PATH = Path(__file__).resolve().parents[3] / "models"
OCR_ENGINE_AUTO = "auto"
OCR_ENGINE_RAPIDOCR = "rapidocr"
OCR_ENGINE_EASYOCR = "easyocr"
OCR_ENGINE_TESSERACT = "tesseract"
SUPPORTED_OCR_ENGINES = (
    OCR_ENGINE_AUTO,
    OCR_ENGINE_RAPIDOCR,
    OCR_ENGINE_EASYOCR,
    OCR_ENGINE_TESSERACT,
)
TABLE_MODE_ACCURATE = "accurate"
TABLE_MODE_FAST = "fast"
SUPPORTED_TABLE_MODES = (TABLE_MODE_ACCURATE, TABLE_MODE_FAST)
DEFAULT_OCR_ENGINE = OCR_ENGINE_EASYOCR
DEFAULT_TABLE_MODE = TABLE_MODE_ACCURATE
DEFAULT_IMAGES_SCALE = 2.0
DEFAULT_MAX_NUM_PAGES = 200
DEFAULT_DOCUMENT_TIMEOUT_SECONDS = 300.0
DEFAULT_OCR_LANGUAGES = ("ch_sim", "en")
TRUE_ENV_VALUES = frozenset({"1", "true", "yes", "on"})
DEFAULT_ENABLE_IMAGE_DESCRIPTIONS = True
DEFAULT_ENABLE_IMAGE_DETAIL_VERIFICATION = True
DEFAULT_ENABLE_FORMULA_RECOGNITION = True
IMAGE_DESCRIPTION_MODE_ROUTER_VISION: ImageDescriptionMode = "router_vision"
IMAGE_DESCRIPTION_MODE_CLAUDE_CLI: ImageDescriptionMode = "claude_cli"
SUPPORTED_IMAGE_DESCRIPTION_MODES: tuple[ImageDescriptionMode, ...] = (
    IMAGE_DESCRIPTION_MODE_ROUTER_VISION,
    IMAGE_DESCRIPTION_MODE_CLAUDE_CLI,
)
DEFAULT_IMAGE_DESCRIPTION_TIMEOUT_SECONDS = 900
DEFAULT_IMAGE_DESCRIPTION_BATCH_SIZE = 1
DEFAULT_IMAGE_DESCRIPTION_CONCURRENCY = 4
MAX_IMAGE_DESCRIPTION_CONCURRENCY = 4
DEFAULT_ENABLE_BOILERPLATE_IMAGE_FILTER = True
DEFAULT_BOILERPLATE_FILTER_MODE = "enforce"
SUPPORTED_BOILERPLATE_FILTER_MODES = ("observe", "enforce")
STAGE1_IMAGE_REFS_FILENAME = "stage1_with_image_refs.md"
IMAGE_MAPPING_FILENAME = "image_mapping.json"
VERIFICATION_REPORT_FILENAME = "verification_report.json"
MIN_IMAGE_FILE_SIZE_BYTES = 100
MAX_IMAGE_FILE_SIZE_BYTES = 10 * 1024 * 1024
DOC_CONVERSION_ERROR_LIMIT = 5
OCR_BATCH_SIZE = 10
LARGE_PDF_PAGE_WARNING_THRESHOLD = 50
OCR_BATCH_CANCEL_DELAY_SECONDS = 2
OCR_BATCH_THREAD_WORKERS = 1
OCR_BATCH_CANCEL_POLL_SECONDS = 0.3


def _read_bool_env(name: str, default: bool) -> bool:
    raw_value = os.getenv(name, str(default).lower()).strip().lower()
    return raw_value in TRUE_ENV_VALUES


def _read_int_env(name: str, default: int, minimum: int, maximum: int) -> int:
    raw_value = os.getenv(name)
    if raw_value is None:
        return default
    try:
        value = int(raw_value)
    except (TypeError, ValueError):
        logger.warning(
            "Invalid integer value for {}={} ; using default {}",
            name,
            raw_value,
            default,
        )
        return default
    bounded_value = max(minimum, min(maximum, value))
    if bounded_value != value:
        logger.warning(
            "Value for {}={} is outside {}..{}; using {}",
            name,
            value,
            minimum,
            maximum,
            bounded_value,
        )
    return bounded_value


def _normalize_image_description_mode(raw_mode: str | None) -> ImageDescriptionMode:
    normalized_mode = (raw_mode or IMAGE_DESCRIPTION_MODE_ROUTER_VISION).strip().lower()
    if normalized_mode == IMAGE_DESCRIPTION_MODE_ROUTER_VISION:
        return IMAGE_DESCRIPTION_MODE_ROUTER_VISION
    if normalized_mode == IMAGE_DESCRIPTION_MODE_CLAUDE_CLI:
        return IMAGE_DESCRIPTION_MODE_CLAUDE_CLI

    logger.warning(
        "Unsupported image description mode '{}' ; falling back to {}",
        normalized_mode,
        IMAGE_DESCRIPTION_MODE_ROUTER_VISION,
    )
    return IMAGE_DESCRIPTION_MODE_ROUTER_VISION


def _normalize_boilerplate_filter_mode(raw_mode: str | None) -> str:
    normalized_mode = (raw_mode or DEFAULT_BOILERPLATE_FILTER_MODE).strip().lower()
    if normalized_mode in SUPPORTED_BOILERPLATE_FILTER_MODES:
        return normalized_mode
    logger.warning(
        "Unsupported boilerplate filter mode '{}' ; falling back to {}",
        normalized_mode,
        DEFAULT_BOILERPLATE_FILTER_MODE,
    )
    return DEFAULT_BOILERPLATE_FILTER_MODE


class DoclingPipelineConfig:
    """Configuration for Docling document conversion pipeline.

    Maps to Docling's PdfPipelineOptions and related configuration classes.
    """

    def __init__(
        self,
        do_ocr: bool = True,  # Enabled for scanned PDF support (EasyOCR backend)
        do_table_structure: bool = True,
        do_code_enrichment: bool = False,
        do_formula_enrichment: bool = False,
        force_full_page_ocr: bool = False,
        ocr_engine: str | None = None,
        ocr_languages: list[str] | None = None,
        table_mode: str = DEFAULT_TABLE_MODE,
        images_scale: float = DEFAULT_IMAGES_SCALE,  # Docling standard image scale
        generate_page_images: bool = True,
        max_num_pages: int = DEFAULT_MAX_NUM_PAGES,  # Limit large PDFs to avoid OOM
        max_file_size: int = MAX_PARSE_SIZE_BYTES,
        document_timeout: float = DEFAULT_DOCUMENT_TIMEOUT_SECONDS,
        enable_image_descriptions: bool | None = None,
        enable_image_detail_verification: bool | None = None,
        enable_formula_recognition: bool | None = None,
        image_description_mode: ImageDescriptionMode | None = None,
        max_image_descriptions: int | None = None,  # deprecated compatibility input; ignored
        image_description_timeout: int | None = None,
        image_description_batch_size: int | None = None,
        image_description_concurrency: int | None = None,
        enable_boilerplate_image_filter: bool | None = None,
        boilerplate_filter_mode: str | None = None,
        toc_max_items: int | None = None,
        artifacts_path: str | Path | None = None,
    ):
        self.do_ocr = do_ocr
        self.do_table_structure = do_table_structure
        self.do_code_enrichment = do_code_enrichment
        self.do_formula_enrichment = do_formula_enrichment
        self.force_full_page_ocr = force_full_page_ocr
        self.ocr_engine = (
            ocr_engine or os.getenv("DRIVER_DOCLING_OCR_ENGINE") or DEFAULT_OCR_ENGINE
        ).strip().lower()
        if self.ocr_engine not in SUPPORTED_OCR_ENGINES:
            raise ValueError(
                f"Unsupported Docling OCR engine {self.ocr_engine!r}; "
                f"expected one of {', '.join(SUPPORTED_OCR_ENGINES)}"
            )
        self.ocr_languages = ocr_languages or list(DEFAULT_OCR_LANGUAGES)
        self.table_mode = table_mode
        self.images_scale = images_scale
        self.generate_page_images = generate_page_images
        self.max_num_pages = max_num_pages
        self.max_file_size = max_file_size
        self.document_timeout = document_timeout
        configured_artifacts_path = artifacts_path or os.getenv(
            "DRIVER_DOCLING_ARTIFACTS_PATH",
            str(DEFAULT_DOCLING_ARTIFACTS_PATH),
        )
        self.artifacts_path = Path(configured_artifacts_path).expanduser().resolve()
        self.enable_image_descriptions = (
            enable_image_descriptions
            if enable_image_descriptions is not None
            else _read_bool_env("DRIVER_DOCLING_ENABLE_IMAGE_DESCRIPTIONS", DEFAULT_ENABLE_IMAGE_DESCRIPTIONS)
        )
        self.enable_image_detail_verification = (
            enable_image_detail_verification
            if enable_image_detail_verification is not None
            else _read_bool_env(
                "DRIVER_DOCLING_ENABLE_IMAGE_DETAIL_VERIFICATION",
                DEFAULT_ENABLE_IMAGE_DETAIL_VERIFICATION,
            )
        )
        self.enable_formula_recognition = (
            enable_formula_recognition
            if enable_formula_recognition is not None
            else _read_bool_env(
                "DRIVER_DOCLING_ENABLE_FORMULA_RECOGNITION",
                DEFAULT_ENABLE_FORMULA_RECOGNITION,
            )
        )
        self.image_description_mode = _normalize_image_description_mode(
            image_description_mode
            or os.getenv("DRIVER_DOCLING_IMAGE_DESCRIPTION_MODE", IMAGE_DESCRIPTION_MODE_ROUTER_VISION)
        )
        legacy_max_image_descriptions = (
            max_image_descriptions
            if max_image_descriptions is not None
            else os.getenv("DRIVER_DOCLING_MAX_IMAGE_DESCRIPTIONS")
        )
        if legacy_max_image_descriptions is not None:
            logger.warning(
                "max_image_descriptions={} is deprecated and ignored; all eligible images will be processed",
                legacy_max_image_descriptions,
            )
        self.max_image_descriptions = None
        self.image_description_timeout = int(
            image_description_timeout
            if image_description_timeout is not None
            else os.getenv("DRIVER_DOCLING_IMAGE_DESCRIPTION_TIMEOUT", str(DEFAULT_IMAGE_DESCRIPTION_TIMEOUT_SECONDS))
        )
        # Plan B intentionally uses one image per CLI call. The batch size is
        # exposed in config for observability and future tuning, but values
        # other than one are normalized to one to preserve image/result pairing.
        configured_batch_size = int(
            image_description_batch_size
            if image_description_batch_size is not None
            else os.getenv("DRIVER_DOCLING_IMAGE_DESCRIPTION_BATCH_SIZE", str(DEFAULT_IMAGE_DESCRIPTION_BATCH_SIZE))
        )
        self.image_description_batch_size = 1 if configured_batch_size != 1 else configured_batch_size
        self.image_description_concurrency = min(
            MAX_IMAGE_DESCRIPTION_CONCURRENCY,
            max(
                1,
                int(
                    image_description_concurrency
                    if image_description_concurrency is not None
                    else os.getenv(
                        "DRIVER_DOCLING_IMAGE_DESCRIPTION_CONCURRENCY",
                        str(DEFAULT_IMAGE_DESCRIPTION_CONCURRENCY),
                    )
                ),
            ),
        )
        self.enable_boilerplate_image_filter = (
            enable_boilerplate_image_filter
            if enable_boilerplate_image_filter is not None
            else _read_bool_env(
                "DRIVER_DOCLING_ENABLE_BOILERPLATE_IMAGE_FILTER",
                DEFAULT_ENABLE_BOILERPLATE_IMAGE_FILTER,
            )
        )
        self.boilerplate_filter_mode = _normalize_boilerplate_filter_mode(
            boilerplate_filter_mode
            or os.getenv("DRIVER_DOCLING_BOILERPLATE_FILTER_MODE", DEFAULT_BOILERPLATE_FILTER_MODE)
        )
        self.toc_max_items = (
            max(MIN_TOC_MAX_ITEMS, min(MAX_TOC_MAX_ITEMS, int(toc_max_items)))
            if toc_max_items is not None
            else _read_int_env(
                "DRIVER_DOCLING_TOC_MAX_ITEMS",
                DEFAULT_TOC_MAX_ITEMS,
                MIN_TOC_MAX_ITEMS,
                MAX_TOC_MAX_ITEMS,
            )
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize config to dict for logging/storage."""
        return {
            "do_ocr": self.do_ocr,
            "do_table_structure": self.do_table_structure,
            "do_code_enrichment": self.do_code_enrichment,
            "do_formula_enrichment": self.do_formula_enrichment,
            "ocr_engine": self.ocr_engine,
            "ocr_languages": self.ocr_languages,
            "table_mode": self.table_mode,
            "images_scale": self.images_scale,
            "generate_page_images": self.generate_page_images,
            "max_num_pages": self.max_num_pages,
            "document_timeout": self.document_timeout,
            "artifacts_path": str(self.artifacts_path),
            "enable_image_descriptions": self.enable_image_descriptions,
            "enable_image_detail_verification": self.enable_image_detail_verification,
            "enable_formula_recognition": self.enable_formula_recognition,
            "image_description_mode": self.image_description_mode,
            "max_image_descriptions": None,
            "image_description_limit": None,
            "image_description_timeout": self.image_description_timeout,
            "image_description_batch_size": self.image_description_batch_size,
            "image_description_concurrency": self.image_description_concurrency,
            "enable_boilerplate_image_filter": self.enable_boilerplate_image_filter,
            "boilerplate_filter_mode": self.boilerplate_filter_mode,
            "toc_max_items": self.toc_max_items,
        }


class DriverDoclingService:
    """Service for parsing uploaded documents into structured text content.

    Strictly follows the Docling library's DocumentConverter pattern:
    - Configurable pipeline options (OCR, table detection, layout)
    - Multi-format support via format-specific backends
    - Structured output: markdown content + tables + registers + metadata
    - Chunking support for LLM-ready text segments
    - Batch conversion for multiple files
    """

    def __init__(
        self,
        upload_dir: str = DEFAULT_DOCLING_UPLOAD_DIR,
        pipeline_config: DoclingPipelineConfig | None = None,
        runtime_report: dict[str, Any] | None = None,
    ):
        self._runtime_report = (
            runtime_report if runtime_report is not None else check_docling_runtime()
        )
        self._upload_dir = Path(upload_dir)
        self._upload_dir.mkdir(parents=True, exist_ok=True)
        self._config = pipeline_config or DoclingPipelineConfig()
        self._converter = None  # Lazy-initialized DocumentConverter
        self._vision_client = DriverDoclingVisionClient()
        self._formula_service = DriverDoclingFormulaService(
            self._config,
            self._vision_client,
        )
        self._image_description_service = DriverDoclingImageDescriptionService(
            self._config,
            self._vision_client,
        )

    def _docling_runtime_available(self) -> bool:
        return bool(self._runtime_report.get("ok"))

    def _docling_runtime_error(self, path: Path) -> dict[str, Any]:
        return {
            "file": str(path),
            "content": "",
            "summary": "Docling runtime is unavailable; PDF and Docling tasks are disabled",
            "error": "DOCLING_RUNTIME_UNAVAILABLE",
            "runtime": self._runtime_report,
        }

    def _resolve_allowed_path(self, file_path: str) -> Path:
        """Resolve a user-supplied path and ensure it stays inside the upload directory."""
        path = Path(file_path).resolve()
        allowed_root = self._upload_dir.resolve()
        try:
            path.relative_to(allowed_root)
        except ValueError as exc:
            logger.warning(
                "[Docling] Access denied outside upload directory: file={}, allowed_root={}",
                path,
                allowed_root,
            )
            raise DoclingPathAccessError("Access denied") from exc
        return path

    def validate_input_file(self, file_path: str) -> dict[str, Any]:
        """Validate an input file without running the Docling conversion pipeline."""
        try:
            path = self._resolve_allowed_path(file_path)
        except DoclingPathAccessError:
            return {
                "summary": "Access denied",
                "error": "PATH_TRAVERSAL",
            }

        if not path.exists():
            return {
                "summary": "File not found",
                "error": "FILE_NOT_FOUND",
            }

        try:
            file_size = path.stat().st_size
        except OSError as exc:
            return {
                "summary": f"Could not read file metadata: {exc}",
                "error": "READ_FAILED",
            }

        if file_size > MAX_PARSE_SIZE_BYTES:
            return {
                "summary": "File too large",
                "error": "FILE_TOO_LARGE",
            }

        ext = path.suffix.lower()
        if ext not in DIRECT_TEXT_EXTENSIONS and ext not in DOCLING_SUPPORTED_EXTENSIONS:
            return {
                "summary": f"Unsupported extension: {ext}",
                "error": "UNSUPPORTED",
            }

        return {
            "path": str(path),
            "extension": ext,
            "size": file_size,
        }

    # ==================== Core Conversion ====================

    async def parse_file(
        self,
        file_path: str,
        image_output_dir: str | Path | None = None,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        """Parse a file and return structured content.

        Args:
            file_path: Path to file to parse
            image_output_dir: Optional directory to save extracted images
            task_id: Optional task ID for cancellation checking during parsing

        Returns dict with keys: content, summary, tables, registers, metadata,
        headings, figures, chunks (if chunking enabled)
        """
        validation = self.validate_input_file(file_path)
        if validation.get("error"):
            return {"content": "", **validation}

        path = Path(validation["path"])
        logger.info(
            "[Docling] Parse started: task_id={}, file={}, ocr_engine={}, "
            "ocr_languages={}, images_scale={}, max_pages={}, image_descriptions={}",
            task_id,
            path.name,
            self._config.ocr_engine,
            self._config.ocr_languages,
            self._config.images_scale,
            self._config.max_num_pages,
            self._config.enable_image_descriptions,
        )
        ext = validation["extension"]

        if ext in DIRECT_TEXT_EXTENSIONS:
            result = await self._parse_text_file(path)
        elif ext in DOCLING_SUPPORTED_EXTENSIONS:
            if not self._docling_runtime_available():
                result = self._docling_runtime_error(path)
            else:
                result = await self._parse_with_docling(
                    path,
                    image_output_dir=image_output_dir,
                    task_id=task_id,
                )
        else:
            raise RuntimeError(f"Validated extension was not routable: {ext}")

        metadata = result.get("metadata", {}) or {}
        if result.get("error"):
            logger.warning(
                "[Docling] Parse finished with error: task_id={}, file={}, error={}",
                task_id,
                path.name,
                result["error"],
            )
        else:
            logger.info(
                "[Docling] Parse completed: task_id={}, file={}, source_type={}, "
                "pages={}, chars={}, tables={}, figures={}, images={}, headings={}",
                task_id,
                path.name,
                metadata.get("source_type"),
                metadata.get("page_count"),
                len(result.get("content", "")),
                len(result.get("tables", [])),
                len(result.get("figures", [])),
                len(result.get("images", [])),
                len(result.get("headings", [])),
            )
        return result

    async def parse_file_with_chunks(
        self,
        file_path: str,
        max_tokens: int = _DEFAULT_MAX_TOKENS,
        overlap_tokens: int = _DEFAULT_OVERLAP_TOKENS,
        chunker_type: str = "hierarchical",
    ) -> dict[str, Any]:
        """Parse a file and return content with token-aware chunks.

        Uses Docling's HierarchicalChunker or HybridChunker to split the document
        into LLM-ready segments while preserving document structure.

        Args:
            file_path: Path to file.
            max_tokens: Maximum tokens per chunk (HybridChunker).
            overlap_tokens: Overlap tokens between chunks.
            chunker_type: 'hierarchical' or 'hybrid'.
        """
        result = await self.parse_file(file_path)
        if result.get("error"):
            return result

        # Only chunk Docling-parsed documents (have _docling_doc attached)
        docling_doc = result.get("_docling_doc")
        if docling_doc is not None:
            chunks = self._chunk_document(docling_doc, max_tokens, overlap_tokens, chunker_type)
            result["chunks"] = chunks
            result.pop("_docling_doc", None)
        else:
            # Fallback: simple text chunking for plain text files
            result["chunks"] = self._simple_text_chunks(result["content"], max_tokens)

        return result

    async def batch_parse(self, file_paths: list[str]) -> list[dict[str, Any]]:
        """Parse multiple files using Docling's batch conversion capability.

        Leverages DocumentConverter.convert_all() for efficient batch processing.
        """
        ordered_results: list[dict[str, Any] | None] = [None] * len(file_paths)
        docling_entries: list[tuple[int, Path]] = []
        text_entries: list[tuple[int, Path]] = []

        for index, fp in enumerate(file_paths):
            try:
                path = self._resolve_allowed_path(fp)
            except DoclingPathAccessError:
                ordered_results[index] = {
                    "file": fp,
                    "content": "",
                    "summary": "Access denied",
                    "error": "PATH_TRAVERSAL",
                }
                continue
            if not path.exists():
                ordered_results[index] = {
                    "file": fp,
                    "content": "",
                    "error": "FILE_NOT_FOUND",
                }
                continue
            if path.stat().st_size > MAX_PARSE_SIZE_BYTES:
                ordered_results[index] = {
                    "file": fp,
                    "content": "",
                    "error": "FILE_TOO_LARGE",
                }
                continue
            ext = path.suffix.lower()
            if ext in DIRECT_TEXT_EXTENSIONS:
                text_entries.append((index, path))
            elif ext in DOCLING_SUPPORTED_EXTENSIONS:
                if not self._docling_runtime_available():
                    ordered_results[index] = self._docling_runtime_error(path)
                else:
                    docling_entries.append((index, path))
            else:
                ordered_results[index] = {
                    "file": fp,
                    "content": "",
                    "error": "UNSUPPORTED",
                }

        # Parse text files directly
        for index, path in text_entries:
            r = await self._parse_text_file(path)
            r["file"] = str(path)
            ordered_results[index] = r

        # Batch parse Docling-supported files
        if docling_entries:
            docling_paths = [path for _, path in docling_entries]
            batch_results = await self._batch_parse_with_docling(docling_paths)

            grouped_results: dict[str, deque[dict[str, Any]]] = defaultdict(deque)
            for item in batch_results:
                raw_file = item.get("file")
                if raw_file is None:
                    continue
                try:
                    normalized = str(Path(str(raw_file)).resolve())
                except OSError:
                    continue
                grouped_results[normalized].append(item)

            for index, path in docling_entries:
                normalized_path = str(path.resolve())
                if grouped_results[normalized_path]:
                    ordered_results[index] = grouped_results[normalized_path].popleft()
                else:
                    ordered_results[index] = {
                        "file": str(path),
                        "content": "",
                        "summary": "Batch conversion result mismatch",
                        "error": "DOCLING_RESULT_MISMATCH",
                    }

        return [r for r in ordered_results if r is not None]

    # ==================== Export Formats ====================

    async def export_as_markdown(self, file_path: str) -> str:
        """Parse and export document as Markdown (Docling's export_to_markdown)."""
        path = self._resolve_allowed_path(file_path)
        result = await self.parse_file(str(path))
        return result.get("content", "")

    async def export_as_text(self, file_path: str) -> str | dict[str, Any]:
        """Parse and export document as plain text (Docling's export_to_text)."""
        path = self._resolve_allowed_path(file_path)
        ext = path.suffix.lower()
        if ext in DIRECT_TEXT_EXTENSIONS:
            result = await self._parse_text_file(path)
            if result.get("error"):
                return result
            return result.get("content", "")

        doc = self._convert_single(path)
        if doc is None:
            return {
                "summary": "Docling conversion failed",
                "error": "CONVERSION_FAILED",
            }
        try:
            return doc.export_to_text()
        except AttributeError:
            return doc.export_to_markdown()

    async def export_as_json(self, file_path: str) -> dict[str, Any]:
        """Parse and export document as structured JSON (Docling's export_to_dict)."""
        path = self._resolve_allowed_path(file_path)
        ext = path.suffix.lower()
        if ext in DIRECT_TEXT_EXTENSIONS:
            result = await self._parse_text_file(path)
            return {"content": result.get("content", ""), "format": "text"}

        doc = self._convert_single(path)
        if doc is None:
            return {"error": "conversion_failed"}
        try:
            return doc.export_to_dict()
        except AttributeError:
            return {"content": doc.export_to_markdown(), "format": "markdown_fallback"}

    async def export_as_html(self, file_path: str) -> str | dict[str, Any]:
        """Parse and export document as HTML (Docling's export_to_html)."""
        path = self._resolve_allowed_path(file_path)
        ext = path.suffix.lower()
        if ext in DIRECT_TEXT_EXTENSIONS:
            result = await self._parse_text_file(path)
            if result.get("error"):
                return result
            content = result.get("content", "")
            return f"<pre>{html.escape(content)}</pre>"

        doc = self._convert_single(path)
        if doc is None:
            return {
                "summary": "Docling conversion failed",
                "error": "CONVERSION_FAILED",
            }
        try:
            return doc.export_to_html()
        except AttributeError:
            return f"<pre>{html.escape(doc.export_to_markdown())}</pre>"

    # ==================== Internal: Docling Conversion ====================

    def _get_converter(self):
        """Lazy-initialize the DocumentConverter with configured pipeline options."""
        if self._converter is not None:
            return self._converter

        self._validate_model_artifacts()

        try:
            from docling.document_converter import DocumentConverter

            # Build pipeline options based on config
            format_options = self._build_format_options()
            self._converter = DocumentConverter(format_options=format_options)
            return self._converter
        except ImportError:
            logger.warning("Docling library not installed; using fallback parsing")
            return None

    def _validate_model_artifacts(self) -> None:
        """Validate the bundled local model files before Docling initialization."""
        artifacts_path = self._config.artifacts_path
        required_files = [
            artifacts_path
            / "docling-project--docling-layout-heron"
            / "model.safetensors",
            artifacts_path
            / "docling-project--docling-layout-heron"
            / "config.json",
            artifacts_path
            / "docling-project--docling-layout-heron"
            / "preprocessor_config.json",
            artifacts_path
            / "docling-project--docling-models"
            / "model_artifacts"
            / "tableformer"
            / "accurate"
            / "tableformer_accurate.safetensors",
            artifacts_path
            / "docling-project--docling-models"
            / "model_artifacts"
            / "tableformer"
            / "accurate"
            / "tm_config.json",
        ]
        if self._config.do_ocr and self._config.ocr_engine == OCR_ENGINE_EASYOCR:
            required_files.extend(
                [
                    artifacts_path / "EasyOCR" / "craft_mlt_25k.pth",
                    artifacts_path / "EasyOCR" / "english_g2.pth",
                    artifacts_path / "EasyOCR" / "zh_sim_g2.pth",
                ]
            )
        elif self._config.do_ocr and self._config.ocr_engine == OCR_ENGINE_RAPIDOCR:
            rapidocr_root = artifacts_path / "RapidOcr"
            required_files.extend(
                [
                    rapidocr_root / "onnx" / "PP-OCRv4" / "det" / "ch_PP-OCRv4_det_infer.onnx",
                    rapidocr_root / "onnx" / "PP-OCRv4" / "cls" / "ch_ppocr_mobile_v2.0_cls_infer.onnx",
                    rapidocr_root / "onnx" / "PP-OCRv4" / "rec" / "ch_PP-OCRv4_rec_infer.onnx",
                    rapidocr_root / "paddle" / "PP-OCRv4" / "rec" / "ch_PP-OCRv4_rec_infer" / "ppocr_keys_v1.txt",
                    rapidocr_root / "fonts" / "FZYTK.TTF",
                ]
            )
        missing_files = [path for path in required_files if not path.is_file()]
        missing_requirements: list[str] = []
        if self._config.do_formula_enrichment:
            formula_root = artifacts_path / "docling-project--CodeFormulaV2"
            if not (formula_root / "config.json").is_file():
                missing_requirements.append(str(formula_root / "config.json"))
            if not formula_root.is_dir() or not any(formula_root.glob("*.safetensors")):
                missing_requirements.append(f"{formula_root}/*.safetensors")
        if missing_files or missing_requirements:
            missing_text = "\n".join(
                f"- {path}"
                for path in [*(str(path) for path in missing_files), *missing_requirements]
            )
            raise FileNotFoundError(
                "Docling local model artifacts are incomplete. "
                f"Expected model root: {artifacts_path}\n"
                f"Missing files:\n{missing_text}\n"
                "Docling model downloads are disabled for this project."
            )

        logger.info("Using local Docling model artifacts: {}", artifacts_path)

    def _build_format_options(self) -> dict | None:
        """Build Docling FormatOption dict from pipeline config."""
        try:
            from docling.datamodel.base_models import InputFormat
            from docling.datamodel.pipeline_options import (
                PdfPipelineOptions,
                TableStructureOptions,
            )
            from docling.document_converter import PdfFormatOption

            # Configure PDF pipeline
            pdf_pipeline_options = PdfPipelineOptions(
                artifacts_path=self._config.artifacts_path,
                do_ocr=self._config.do_ocr,
                do_table_structure=self._config.do_table_structure,
                do_code_enrichment=self._config.do_code_enrichment,
                do_formula_enrichment=self._config.do_formula_enrichment,
                images_scale=self._config.images_scale,
                generate_page_images=self._config.generate_page_images,
                generate_picture_images=self._config.generate_page_images,
            )

            # Configure OCR options
            if self._config.do_ocr:
                pdf_pipeline_options = self._configure_ocr(pdf_pipeline_options)

            # Configure table structure
            if self._config.do_table_structure:
                try:
                    from docling.datamodel.pipeline_options import TableFormerMode
                    mode = (
                        TableFormerMode.ACCURATE
                        if self._config.table_mode == TABLE_MODE_ACCURATE
                        else TableFormerMode.FAST
                    )
                    pdf_pipeline_options.table_structure_options = TableStructureOptions(mode=mode)
                except ImportError:
                    logger.warning("TableFormerMode is unavailable; table structure mode configuration was skipped")

            return {
                InputFormat.PDF: PdfFormatOption(pipeline_options=pdf_pipeline_options),
            }
        except ImportError:
            logger.warning("Docling PDF pipeline dependencies are unavailable; converter configuration was skipped")
            return None

    def _configure_ocr(self, pipeline_options):
        """Configure OCR engine and language settings."""
        try:
            from docling.datamodel.pipeline_options import (
                EasyOcrOptions,
                OcrAutoOptions,
                RapidOcrOptions,
                TesseractCliOcrOptions,
            )

            ocr_map = {
                OCR_ENGINE_AUTO: OcrAutoOptions,
                OCR_ENGINE_RAPIDOCR: RapidOcrOptions,
                OCR_ENGINE_EASYOCR: EasyOcrOptions,
                OCR_ENGINE_TESSERACT: TesseractCliOcrOptions,
            }
            ocr_cls = ocr_map.get(self._config.ocr_engine, OcrAutoOptions)
            ocr_kwargs = {
                "force_full_page_ocr": self._config.force_full_page_ocr,
            }
            if ocr_cls is EasyOcrOptions:
                ocr_kwargs.update(
                    {
                        "model_storage_directory": str(self._config.artifacts_path / "EasyOCR"),
                        "download_enabled": False,
                    }
                )
            elif ocr_cls is RapidOcrOptions:
                rapidocr_root = self._config.artifacts_path / "RapidOcr"
                ocr_kwargs.update(
                    {
                        "backend": "onnxruntime",
                        "det_model_path": str(
                            rapidocr_root / "onnx" / "PP-OCRv4" / "det" / "ch_PP-OCRv4_det_infer.onnx"
                        ),
                        "cls_model_path": str(
                            rapidocr_root / "onnx" / "PP-OCRv4" / "cls" / "ch_ppocr_mobile_v2.0_cls_infer.onnx"
                        ),
                        "rec_model_path": str(
                            rapidocr_root / "onnx" / "PP-OCRv4" / "rec" / "ch_PP-OCRv4_rec_infer.onnx"
                        ),
                        "rec_keys_path": str(
                            rapidocr_root
                            / "paddle"
                            / "PP-OCRv4"
                            / "rec"
                            / "ch_PP-OCRv4_rec_infer"
                            / "ppocr_keys_v1.txt"
                        ),
                        "font_path": str(rapidocr_root / "fonts" / "FZYTK.TTF"),
                    }
                )
            ocr_opts = ocr_cls(**ocr_kwargs)
            if (
                ocr_cls is not RapidOcrOptions
                and self._config.ocr_languages
                and hasattr(ocr_opts, "lang")
            ):
                ocr_opts.lang = self._config.ocr_languages
            pipeline_options.ocr_options = ocr_opts
        except ImportError:
            logger.warning("Docling OCR dependencies are unavailable; OCR options were not configured")
        return pipeline_options

    def _convert_single(self, path: Path):
        """Convert a single file and return the DoclingDocument, or None on failure."""
        converter = self._get_converter()
        if converter is None:
            return None
        try:
            result = converter.convert(
                str(path),
                max_num_pages=self._config.max_num_pages,
                max_file_size=self._config.max_file_size,
            )
            if result.status.name in ("SUCCESS", "PARTIAL_SUCCESS"):
                return result.document
            logger.warning("Docling conversion status: {} for {}", result.status.name, path)
            return None
        except Exception as e:
            logger.error("Docling conversion failed for {}: {}", path, e)
            return None

    async def _parse_with_docling(
        self,
        path: Path,
        image_output_dir: str | Path | None = None,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        """Parse document using Docling library with full pipeline.

        For PDFs with OCR enabled, uses fixed-size page batches to avoid
        memory overflow issues.

        Args:
            path: Path to document to parse
            image_output_dir: Optional directory to save extracted images
            task_id: Optional task ID for cancellation checking during parsing
        """
        converter = self._get_converter()
        if converter is None:
            return await self._fallback_parse(path)

        # Check if this is a PDF that needs OCR batch processing
        ext = path.suffix.lower()
        if ext == ".pdf" and self._config.do_ocr:
            logger.info("PDF with OCR enabled, using batch processing: {}", path.name)
            return await self._parse_pdf_with_ocr_batching(path, converter, image_output_dir=image_output_dir, task_id=task_id)

        # Standard processing for non-OCR or non-PDF files
        try:
            result = converter.convert(
                str(path),
                max_num_pages=self._config.max_num_pages,
                max_file_size=self._config.max_file_size,
            )

            if result.status.name not in ("SUCCESS", "PARTIAL_SUCCESS"):
                errors = [e.error_message for e in (result.errors or [])]
                return {
                    "content": "",
                    "summary": f"Docling conversion failed: {result.status.name}",
                    "error": "DOCLING_FAILED",
                    "errors": errors[:DOC_CONVERSION_ERROR_LIMIT],
                }

            doc = result.document

            # Export as markdown for LLM consumption
            content = doc.export_to_markdown()

            # Extract structured elements
            tables = self._extract_tables(doc)
            figures = self._extract_figures(doc)
            exported_images = self._save_doc_images(doc, image_output_dir, path.stem)
            exported_formulas = self._save_doc_formulas(doc, image_output_dir, path.stem)
            provenance_manifest = self._build_provenance_manifest(
                doc,
                exported_images=exported_images,
                source_name=path.stem,
                page_count=len(getattr(result, "pages", {}) or {}),
            )
            provenance_manifest_path = self._save_provenance_manifest(
                provenance_manifest,
                image_output_dir,
            )
            self._save_docling_document_json(doc, image_output_dir)
            headings = self._extract_headings(content)
            registers = self._detect_register_tables(content)

            # ✨ Stage 1: Inject image references (replace <!-- image --> with paths)
            image_mapping = {}
            verification = {}
            image_descriptions = {}
            formula_report = {}
            if exported_images:
                logger.info("Stage 1: Processing {} images", len(exported_images))
                content_with_refs, image_mapping = self._inject_image_references(
                    content, exported_images, doc
                )
                
                # Save stage 1 output for verification
                if image_output_dir:
                    stage1_file = Path(image_output_dir) / STAGE1_IMAGE_REFS_FILENAME
                    try:
                        stage1_file.write_text(content_with_refs, encoding='utf-8')
                        logger.info("Stage 1 output saved to: {}", stage1_file)
                    except Exception as e:
                        logger.warning("Failed to save stage 1 output: {}", e)
                    
                    # Also save mapping for inspection
                    mapping_file = Path(image_output_dir) / IMAGE_MAPPING_FILENAME
                    try:
                        mapping_file.write_text(
                            json.dumps(image_mapping, ensure_ascii=False, indent=2),
                            encoding='utf-8'
                        )
                        logger.info("Image mapping saved to: {}", mapping_file)
                    except Exception as e:
                        logger.warning("Failed to save mapping: {}", e)
                
                # Verify mapping accuracy
                verification = self._verify_image_mapping(image_mapping, doc, content_with_refs)
                logger.info(
                    "Stage 1 verification: {}/{} verified",
                    verification["verified"],
                    verification["total_placeholders"],
                )
                
                if verification['warnings']:
                    for warning in verification['warnings']:
                        logger.warning("  - {}", warning)
                
                if verification['errors']:
                    for error in verification['errors']:
                        logger.error("  - {}", error)
                
                # Use content with image references
                content = content_with_refs

                # Save verification report
                if image_output_dir:
                    verify_file = Path(image_output_dir) / VERIFICATION_REPORT_FILENAME
                    try:
                        verify_file.write_text(
                            json.dumps(verification, ensure_ascii=False, indent=2),
                            encoding='utf-8'
                        )
                        logger.info("Verification report saved to: {}", verify_file)
                    except Exception as e:
                        logger.warning("Failed to save verification report: {}", e)

            content, formula_report = await self._maybe_recognize_formulas(
                content=content,
                formulas=exported_formulas,
                image_output_dir=image_output_dir,
                source_name=path.stem,
                task_id=task_id,
            )
            if image_mapping:
                content, image_descriptions = await self._maybe_inject_image_descriptions(
                    content=content,
                    image_mapping=image_mapping,
                    image_output_dir=image_output_dir,
                    source_name=path.stem,
                    task_id=task_id,
                )

            # Compute metadata
            page_count = len(result.pages) if hasattr(result, "pages") else None
            metadata = {
                "source_type": "docling",
                "page_count": page_count,
                "table_count": len(tables),
                "figure_count": len(figures),
                "image_count": len(exported_images),
                "image_output_dir": str(Path(image_output_dir).resolve()) if image_output_dir else None,
                "heading_count": len(headings),
                "register_count": len(registers),
                "conversion_status": result.status.name,
                "pipeline_config": self._config.to_dict(),
                "stage1_completed": len(image_mapping) > 0,
                "stage1_verification": verification if verification else None,
                "image_descriptions_enabled": self._config.enable_image_descriptions,
                "image_description_count": len(image_descriptions),
                "formula_recognition": formula_report or None,
                "provenance_manifest": provenance_manifest,
                "provenance_manifest_path": str(provenance_manifest_path) if provenance_manifest_path else None,
            }

            summary = self._generate_document_summary(content, path.name, metadata)

            return {
                "content": content,
                "summary": summary,
                "tables": tables,
                "figures": figures,
                "images": exported_images,
                "headings": headings,
                "registers": registers,
                "metadata": metadata,
                "image_mapping": image_mapping,
                "verification": verification,
                "image_descriptions": image_descriptions,
                "formula_recognition": formula_report,
                "_docling_doc": doc,  # Keep for chunking (removed before returning to API)
            }
        except Exception as e:
            logger.error("Docling parse failed for {}: {}", path, e)
            return await self._fallback_parse(path)

    async def _parse_pdf_with_ocr_batching(
        self,
        path: Path,
        converter,
        image_output_dir: str | Path | None = None,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        """Parse PDF with OCR using batch processing to avoid memory overflow.

        Splits PDF into fixed-size temporary page batches, processes them
        separately, then merges results.

        Args:
            path: Path to PDF file
            converter: Docling DocumentConverter instance
            image_output_dir: Optional directory to save extracted images
            task_id: Optional task ID for cancellation checking during parsing
        """
        import gc
        import tempfile
        from pypdf import PdfReader, PdfWriter
        from app.services.driver_docling_progress import report_docling_progress

        try:
            def _cancelled_result(processed: int = 0, total: int = 0) -> dict[str, Any]:
                return {
                    "content": "",
                    "summary": "PDF parsing cancelled by user",
                    "error": "CANCELLED",
                    "metadata": {
                        "cancelled": True,
                        "processed_pages": processed,
                        "total_pages": total,
                    },
                }

            # Check cancellation before starting PDF reading
            if task_id:
                from app.utils.claude_cli_monitor import is_task_cancelled
                if is_task_cancelled(task_id):
                    logger.warning(
                        "🛑 [_parse_pdf_with_ocr_batching] Task {} cancelled before PDF reading, aborting",
                        task_id,
                    )
                    return _cancelled_result()

            # Process in fixed-size batches so cancellation checks can run between conversions.
            batch_size = OCR_BATCH_SIZE

            # Get total page count
            reader = PdfReader(str(path))
            total_pages = len(reader.pages)
            logger.info("PDF has {} pages, processing in batches of {}", total_pages, batch_size)

            # Warn user if cancellation might be slow for large PDFs
            if total_pages > LARGE_PDF_PAGE_WARNING_THRESHOLD:
                estimated_max_cancel_delay = (total_pages / batch_size) * OCR_BATCH_CANCEL_DELAY_SECONDS
                logger.warning(
                    "Large PDF ({} pages). If you cancel during parsing, "
                    "it may take up to {}s to take effect "
                    "(waiting for current batch to finish).",
                    total_pages,
                    int(estimated_max_cancel_delay),
                )
            all_content = []
            all_tables = []
            all_figures = []
            all_images = []
            all_formulas = []
            caption_rebindings = []
            all_provenance_elements: list[dict[str, Any]] = []
            processed_pages = 0
            failed_batches = []

            # Log task_id for debugging cancel functionality
            logger.info(
                "[_parse_pdf_with_ocr_batching] Starting batch processing with task_id={}",
                task_id,
            )

            # Create temporary directory for batch files
            with tempfile.TemporaryDirectory(prefix="driver-docling-", dir=get_driver_temp_root()) as temp_dir:
                temp_path = Path(temp_dir)

                for start_page in range(0, min(total_pages, self._config.max_num_pages), batch_size):
                    # Check cancellation before processing each batch
                    if task_id:
                        from app.utils.claude_cli_monitor import is_task_cancelled
                        is_cancelled = is_task_cancelled(task_id)
                        logger.info(
                            "[_parse_pdf_with_ocr_batching] Batch {}: task_id={}, is_cancelled={}",
                            (start_page // batch_size) + 1,
                            task_id,
                            is_cancelled,
                        )
                        if is_cancelled:
                            logger.warning(
                                "🛑 [_parse_pdf_with_ocr_batching] Task {} cancelled during PDF parsing at batch {}, aborting",
                                task_id,
                                (start_page // batch_size) + 1,
                            )
                            return {
                                "content": "",
                                "summary": "PDF parsing cancelled by user",
                                "error": "CANCELLED",
                                "metadata": {
                                    "cancelled": True,
                                    "processed_pages": processed_pages,
                                    "total_pages": total_pages,
                                }
                            }

                    end_page = min(start_page + batch_size, total_pages, self._config.max_num_pages)
                    batch_num = (start_page // batch_size) + 1
                    total_batches = (min(total_pages, self._config.max_num_pages) + batch_size - 1) // batch_size
                    report_docling_progress(
                        "ocr", f"Docling OCR batch {batch_num}/{total_batches}: pages {start_page + 1}-{end_page}",
                        batch=batch_num, total_batches=total_batches,
                        processed_pages=processed_pages, total_pages=total_pages,
                    )

                    logger.info(
                        "Processing batch {}/{}: pages {}-{}",
                        batch_num,
                        total_batches,
                        start_page + 1,
                        end_page,
                    )

                    try:
                        # Check cancellation again before heavy Docling conversion
                        if task_id:
                            from app.utils.claude_cli_monitor import is_task_cancelled
                            if is_task_cancelled(task_id):
                                logger.warning(
                                    "🛑 [_parse_pdf_with_ocr_batching] Task {} cancelled before batch {} conversion, aborting",
                                    task_id,
                                    batch_num,
                                )
                                return {
                                    "content": "",
                                    "summary": "PDF parsing cancelled by user",
                                    "error": "CANCELLED",
                                    "metadata": {
                                        "cancelled": True,
                                        "processed_pages": processed_pages,
                                        "total_pages": total_pages,
                                    }
                                }

                        # Create temporary PDF with only this batch of pages
                        writer = PdfWriter()
                        for page_num in range(start_page, end_page):
                            writer.add_page(reader.pages[page_num])

                        batch_pdf_path = temp_path / f"batch_{batch_num}.pdf"
                        writer.write(str(batch_pdf_path))
                        writer.close()

                        # Process this batch with cancellation polling
                        # Docling conversion is blocking, so run in thread pool and poll for cancellation
                        import asyncio
                        import concurrent.futures

                        def _convert_batch():
                            return converter.convert(
                                str(batch_pdf_path),
                                max_num_pages=batch_size,
                                max_file_size=self._config.max_file_size,
                            )

                        # Run conversion in a short-lived thread pool. Do not use
                        # the executor context manager here because it waits for
                        # the current Docling batch during shutdown.
                        loop = asyncio.get_event_loop()
                        pool = concurrent.futures.ThreadPoolExecutor(max_workers=OCR_BATCH_THREAD_WORKERS)
                        try:
                            future = loop.run_in_executor(pool, _convert_batch)

                            # Poll for cancellation while conversion is running
                            while not future.done():
                                if task_id:
                                    from app.utils.claude_cli_monitor import is_task_cancelled
                                    if is_task_cancelled(task_id):
                                        logger.warning(
                                            "🛑 [_parse_pdf_with_ocr_batching] Task {} cancelled during batch {} conversion, aborting",
                                            task_id,
                                            batch_num,
                                        )
                                        # Running Python threads cannot be killed safely; stop waiting
                                        # immediately and discard the eventual conversion result.
                                        future.cancel()
                                        batch_pdf_path.unlink(missing_ok=True)
                                        return _cancelled_result(processed_pages, total_pages)
                                await asyncio.sleep(OCR_BATCH_CANCEL_POLL_SECONDS)

                            # Get result
                            batch_result = await future
                        finally:
                            pool.shutdown(wait=False, cancel_futures=True)

                        # Check cancellation after Docling conversion completes
                        if task_id:
                            from app.utils.claude_cli_monitor import is_task_cancelled
                            if is_task_cancelled(task_id):
                                logger.warning(
                                    "🛑 [_parse_pdf_with_ocr_batching] Task {} cancelled after batch {} conversion, aborting",
                                    task_id,
                                    batch_num,
                                )
                                batch_pdf_path.unlink(missing_ok=True)
                                return {
                                    "content": "",
                                    "summary": "PDF parsing cancelled by user",
                                    "error": "CANCELLED",
                                    "metadata": {
                                        "cancelled": True,
                                        "processed_pages": processed_pages,
                                        "total_pages": total_pages,
                                    }
                                }

                        if batch_result.status.name in ("SUCCESS", "PARTIAL_SUCCESS"):
                            doc = batch_result.document
                            batch_content = doc.export_to_markdown()
                            # Docling may detect a table but miss the caption element.
                            # Read captions from the same temporary batch PDF so its
                            # local page numbers align with the Docling provenance;
                            # ``page_offset`` then maps both to the source PDF page.
                            batch_content, batch_caption_rebinding = self._rebind_missing_table_captions(
                                content=batch_content,
                                doc=doc,
                                source_pdf=batch_pdf_path,
                                page_offset=start_page,
                            )
                            caption_rebindings.extend(batch_caption_rebinding)
                            rebound_count = sum(
                                1 for item in batch_caption_rebinding if item.get("status") == "rebound"
                            )
                            if rebound_count:
                                logger.info(
                                    "Batch {} rebound {} missing table caption(s)",
                                    batch_num,
                                    rebound_count,
                                )

                            all_content.append(batch_content)
                            all_tables.extend(self._extract_tables(doc))
                            all_figures.extend(self._extract_figures(doc, page_offset=start_page))
                            all_images.extend(self._save_doc_images(doc, image_output_dir, path.stem, page_offset=start_page))
                            batch_manifest = self._build_provenance_manifest(
                                doc,
                                exported_images=[],
                                source_name=path.stem,
                                page_count=end_page - start_page,
                            )
                            for element in batch_manifest.get("elements") or []:
                                for prov in element.get("provenance") or []:
                                    prov["page_no"] = int(prov["page_no"]) + start_page
                                element["pages"] = [int(page) + start_page for page in (element.get("pages") or [])]
                            all_provenance_elements.extend(batch_manifest.get("elements") or [])
                            all_formulas.extend(
                                self._save_doc_formulas(
                                    doc,
                                    image_output_dir,
                                    path.stem,
                                    page_offset=start_page,
                                )
                            )
                            processed_pages = end_page
                            report_docling_progress(
                                "ocr", f"Docling OCR processed {processed_pages}/{total_pages} pages",
                                batch=batch_num, total_batches=total_batches,
                                processed_pages=processed_pages, total_pages=total_pages,
                            )

                            logger.info(
                                "Batch {} processed successfully ({} chars)",
                                batch_num,
                                len(batch_content),
                            )
                        else:
                            logger.warning("Batch {} failed: {}", batch_num, batch_result.status.name)
                            failed_batches.append((start_page+1, end_page))

                        # Clean up batch file
                        batch_pdf_path.unlink(missing_ok=True)

                    except Exception as e:
                        logger.error("Batch {} error: {}", batch_num, e)
                        failed_batches.append((start_page+1, end_page))

                    # Force garbage collection after each batch to free memory
                    gc.collect()

            # Merge all content
            merged_content = "\n\n---\n\n".join(all_content)

            # Stage 1: Inject image references for the OCR batching branch too.
            # PDFs with OCR enabled return from this method directly, so the standard
            # _parse_with_docling branch never gets a chance to replace <!-- image -->.
            image_mapping = {}
            verification = {}
            image_descriptions = {}
            formula_report = {}
            if all_images:
                logger.info("Stage 1 (batched): Processing {} images", len(all_images))
                merged_content, image_mapping = self._inject_image_references_from_saved_images(
                    merged_content,
                    all_images,
                )

                if image_output_dir:
                    output_dir = Path(image_output_dir)
                    stage1_file = output_dir / STAGE1_IMAGE_REFS_FILENAME
                    mapping_file = output_dir / IMAGE_MAPPING_FILENAME
                    verify_file = output_dir / VERIFICATION_REPORT_FILENAME
                    try:
                        stage1_file.write_text(merged_content, encoding="utf-8")
                        logger.info("Stage 1 output saved to: {}", stage1_file)
                    except Exception as e:
                        logger.warning("Failed to save stage 1 output: {}", e)

                    try:
                        mapping_file.write_text(
                            json.dumps(image_mapping, ensure_ascii=False, indent=2),
                            encoding="utf-8",
                        )
                        logger.info("Image mapping saved to: {}", mapping_file)
                    except Exception as e:
                        logger.warning("Failed to save mapping: {}", e)

                verification = self._verify_saved_image_mapping(image_mapping)
                logger.info(
                    "Stage 1 verification: {}/{} verified",
                    verification["verified"],
                    verification["total_placeholders"],
                )
                if verification["warnings"]:
                    for warning in verification["warnings"]:
                        logger.warning("  - {}", warning)
                if verification["errors"]:
                    for error in verification["errors"]:
                        logger.error("  - {}", error)

                if image_output_dir:
                    try:
                        verify_file.write_text(
                            json.dumps(verification, ensure_ascii=False, indent=2),
                            encoding="utf-8",
                        )
                    except Exception as e:
                        logger.warning("Failed to save verification report: {}", e)

            merged_content, formula_report = await self._maybe_recognize_formulas(
                content=merged_content,
                formulas=all_formulas,
                image_output_dir=image_output_dir,
                source_name=path.stem,
                task_id=task_id,
            )
            if image_mapping:
                merged_content, image_descriptions = await self._maybe_inject_image_descriptions(
                    content=merged_content,
                    image_mapping=image_mapping,
                    image_output_dir=image_output_dir,
                    source_name=path.stem,
                    task_id=task_id,
                )

            headings = self._extract_headings(merged_content)
            registers = self._detect_register_tables(merged_content)

            # Build metadata
            metadata = {
                "source_type": "docling_batched",
                "page_count": processed_pages,
                "total_pages": total_pages,
                "batch_size": batch_size,
                "batches_processed": len(all_content),
                "batches_failed": len(failed_batches),
                "failed_page_ranges": failed_batches,
                "table_count": len(all_tables),
                "figure_count": len(all_figures),
                "image_count": len(all_images),
                "image_output_dir": str(Path(image_output_dir).resolve()) if image_output_dir else None,
                "heading_count": len(headings),
                "register_count": len(registers),
                "conversion_status": "PARTIAL_SUCCESS" if failed_batches else "SUCCESS",
                "pipeline_config": self._config.to_dict(),
                "stage1_completed": len(image_mapping) > 0,
                "stage1_verification": verification if verification else None,
                "image_descriptions_enabled": self._config.enable_image_descriptions,
                "image_description_count": len(image_descriptions),
                "formula_recognition": formula_report or None,
                "caption_rebinding": caption_rebindings,
            }
            provenance_manifest = {
                "schema_version": "1.0",
                "source_name": path.stem,
                "page_count": total_pages,
                "pages": [
                    {
                        "page_no": item.get("page"),
                        "image_filename": item.get("filename"),
                        "image_path": item.get("path"),
                    }
                    for item in all_images
                    if item.get("type") == "page"
                ],
                "elements": all_provenance_elements,
            }
            provenance_manifest_path = self._save_provenance_manifest(provenance_manifest, image_output_dir)
            metadata["provenance_manifest_path"] = str(provenance_manifest_path) if provenance_manifest_path else None

            summary = self._generate_document_summary(merged_content, path.name, metadata)

            logger.info(
                "Batch processing complete: {}/{} pages, {} chars",
                processed_pages,
                total_pages,
                len(merged_content),
            )

            return {
                "content": merged_content,
                "summary": summary,
                "tables": all_tables,
                "figures": all_figures,
                "images": all_images,
                "headings": headings,
                "registers": registers,
                "metadata": metadata,
                "image_mapping": image_mapping,
                "verification": verification,
                "image_descriptions": image_descriptions,
                "formula_recognition": formula_report,
                "provenance_manifest": provenance_manifest,
            }

        except Exception as e:
            logger.error("Batch OCR processing failed for {}: {}", path, e)
            return await self._fallback_parse(path)

    async def _batch_parse_with_docling(self, paths: list[Path]) -> list[dict[str, Any]]:
        """Batch-convert multiple files using Docling's convert_all."""
        results = []
        converter = self._get_converter()
        if converter is None:
            logger.warning("Docling batch conversion is unavailable; falling back to basic parsing")
            for path in paths:
                r = await self._fallback_parse(path)
                r["file"] = str(path)
                results.append(r)
            return results

        try:
            conv_results = converter.convert_all(
                source=[str(p) for p in paths],
                raises_on_error=False,
                max_num_pages=self._config.max_num_pages,
                max_file_size=self._config.max_file_size,
            )

            for conv_res in conv_results:
                file_path = str(conv_res.input.file) if hasattr(conv_res, "input") else "unknown"
                if conv_res.status.name in ("SUCCESS", "PARTIAL_SUCCESS"):
                    doc = conv_res.document
                    content = doc.export_to_markdown()
                    tables = self._extract_tables(doc)
                    registers = self._detect_register_tables(content)
                    headings = self._extract_headings(content)

                    results.append({
                        "file": file_path,
                        "content": content,
                        "summary": self._generate_document_summary(content, Path(file_path).name, {}),
                        "tables": tables,
                        "headings": headings,
                        "registers": registers,
                        "metadata": {
                            "source_type": "docling",
                            "conversion_status": conv_res.status.name,
                        },
                    })
                else:
                    results.append({
                        "file": file_path,
                        "content": "",
                        "error": f"DOCLING_{conv_res.status.name}",
                    })
        except Exception as e:
            logger.error("Batch Docling conversion failed: {}", e)
            for path in paths:
                r = await self._fallback_parse(path)
                r["file"] = str(path)
                results.append(r)

        return results

    # ==================== Chunking ====================

    def _chunk_document(
        self,
        docling_doc,
        max_tokens: int,
        overlap_tokens: int,
        chunker_type: str,
    ) -> list[dict[str, Any]]:
        """Chunk a DoclingDocument using Docling's chunking infrastructure.

        Args:
            docling_doc: A DoclingDocument instance.
            max_tokens: Max tokens per chunk (for HybridChunker).
            overlap_tokens: Overlap between adjacent chunks.
            chunker_type: 'hierarchical' or 'hybrid'.
        """
        try:
            if chunker_type == "hybrid":
                return self._hybrid_chunk(docling_doc, max_tokens)
            else:
                return self._hierarchical_chunk(docling_doc)
        except ImportError as e:
            logger.warning(
                "Chunking library not available: {}; falling back to simple chunking",
                e,
            )
            content = docling_doc.export_to_markdown()
            return self._simple_text_chunks(content, max_tokens)
        except Exception as e:
            logger.error("Chunking failed: {}", e)
            content = docling_doc.export_to_markdown()
            return self._simple_text_chunks(content, max_tokens)

    def _hierarchical_chunk(self, docling_doc) -> list[dict[str, Any]]:
        """Chunk using Docling's HierarchicalChunker (structure-aware)."""
        from docling.chunking import HierarchicalChunker

        chunker = HierarchicalChunker(merge_list_items=True)
        chunks = []
        for i, chunk in enumerate(chunker.chunk(docling_doc)):
            chunks.append({
                "index": i,
                "text": chunk.text if hasattr(chunk, "text") else str(chunk),
                "meta": {
                    "headings": getattr(chunk, "meta", {}).get("headings", [])
                    if hasattr(chunk, "meta") and isinstance(getattr(chunk, "meta", None), dict)
                    else [],
                },
            })
        return chunks

    def _hybrid_chunk(self, docling_doc, max_tokens: int) -> list[dict[str, Any]]:
        """Chunk using Docling's HybridChunker (token-aware + structure-aware)."""
        from docling.chunking import HybridChunker

        chunker = HybridChunker(max_tokens=max_tokens, merge_peers=True)
        chunks = []
        for i, chunk in enumerate(chunker.chunk(docling_doc)):
            chunks.append({
                "index": i,
                "text": chunk.text if hasattr(chunk, "text") else str(chunk),
                "meta": {
                    "headings": getattr(chunk, "meta", {}).get("headings", [])
                    if hasattr(chunk, "meta") and isinstance(getattr(chunk, "meta", None), dict)
                    else [],
                },
            })
        return chunks

    def _simple_text_chunks(self, content: str, max_tokens: int) -> list[dict[str, Any]]:
        """Fallback: split text by paragraphs/headings with approximate token limit."""
        if not content:
            return []

        max_chars = max_tokens * APPROX_CHARS_PER_TOKEN
        paragraphs = re.split(r"\n\n+", content)
        chunks = []
        current_chunk = ""
        current_heading = ""

        for para in paragraphs:
            if para.startswith("#"):
                current_heading = para.split("\n")[0]

            if len(current_chunk) + len(para) + len(PARAGRAPH_SEPARATOR) > max_chars:
                if current_chunk.strip():
                    chunks.append({
                        "index": len(chunks),
                        "text": current_chunk.strip(),
                        "meta": {"headings": [current_heading] if current_heading else []},
                    })
                current_chunk = para
            else:
                current_chunk += PARAGRAPH_SEPARATOR + para if current_chunk else para

        if current_chunk.strip():
            chunks.append({
                "index": len(chunks),
                "text": current_chunk.strip(),
                "meta": {"headings": [current_heading] if current_heading else []},
            })

        return chunks

    def _save_doc_images(
        self,
        doc,
        image_output_dir: str | Path | None,
        source_stem: str,
        page_offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Save Docling page and picture images into the requested output directory."""
        if image_output_dir is None:
            return []

        output_dir = Path(image_output_dir)
        try:
            output_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.error("Failed to create image output directory {}: {}", output_dir, exc)
            return []
        safe_stem = self._safe_image_stem(source_stem)
        saved_images: list[dict[str, Any]] = []

        pages = getattr(doc, "pages", {}) or {}
        sorted_pages = sorted(
            pages.items(),
            key=lambda item: int(item[0]) if str(item[0]).isdigit() else str(item[0]),
        )
        for page_key, page in sorted_pages:
            page_no = self._coerce_page_number(getattr(page, "page_no", page_key), page_key)
            global_page_no = page_offset + page_no
            output_path = output_dir / (
                f"{safe_stem}_page_{global_page_no:0{IMAGE_FILENAME_INDEX_WIDTH}d}.png"
            )
            if self._save_image_ref(getattr(page, "image", None), output_path):
                saved_images.append({
                    "type": "page",
                    "page": global_page_no,
                    "filename": output_path.name,
                    "path": str(output_path.resolve()),
                })

        for index, picture in enumerate(getattr(doc, "pictures", []) or [], start=1):
            page_no = self._picture_page_number(picture, page_offset)
            if page_no is None:
                output_path = output_dir / (
                    f"{safe_stem}_picture_"
                    f"{page_offset + index:0{IMAGE_FILENAME_INDEX_WIDTH}d}.png"
                )
            else:
                output_path = output_dir / (
                    f"{safe_stem}_page_{page_no:0{IMAGE_FILENAME_INDEX_WIDTH}d}"
                    f"_picture_{index:0{IMAGE_FILENAME_INDEX_WIDTH}d}.png"
                )
            if self._save_picture_image(doc, picture, output_path):
                saved_images.append({
                    "type": "picture",
                    "page": page_no,
                    "filename": output_path.name,
                    "path": str(output_path.resolve()),
                    **self._picture_geometry_metadata(picture, doc=doc),
                })

        return saved_images

    def _build_provenance_manifest(
        self,
        doc: Any,
        *,
        exported_images: list[dict[str, Any]],
        source_name: str,
        page_count: int,
    ) -> dict[str, Any]:
        """Build a stable, JSON-safe element-to-page manifest.

        Markdown does not retain element provenance reliably enough for recovery.
        This manifest is the machine-readable source of truth used by post-processing.
        """
        page_images = {
            int(item["page"]): item
            for item in exported_images
            if item.get("type") == "page" and item.get("page") is not None
        }
        pages = [
            {
                "page_no": page_no,
                "image_filename": page_images.get(page_no, {}).get("filename"),
                "image_path": page_images.get(page_no, {}).get("path"),
            }
            for page_no in range(1, max(0, int(page_count)) + 1)
        ]
        elements: list[dict[str, Any]] = []
        iterator = getattr(doc, "iterate_items", None)
        if callable(iterator):
            try:
                iterable = iterator(with_groups=False)
            except TypeError:
                iterable = iterator()
            for item, _level in iterable:
                prov_items = getattr(item, "prov", None) or []
                provenance = []
                for prov in prov_items:
                    raw_page_no = getattr(prov, "page_no", None)
                    try:
                        page_no = int(raw_page_no)
                    except (TypeError, ValueError):
                        continue
                    if page_no <= 0:
                        continue
                    provenance.append(
                        {
                            "page_no": page_no,
                            "bbox": self._serialize_docling_bbox(getattr(prov, "bbox", None)),
                        }
                    )
                label = getattr(getattr(item, "label", None), "value", getattr(item, "label", ""))
                text = str(
                    getattr(item, "text", None)
                    or getattr(item, "caption", None)
                    or getattr(item, "title", None)
                    or ""
                )
                elements.append(
                    {
                        "element_id": str(getattr(item, "self_ref", "") or ""),
                        "label": str(label or "").lower(),
                        "text": text[:4000],
                        "provenance": provenance,
                        "pages": sorted({entry["page_no"] for entry in provenance}),
                    }
                )
        return {
            "schema_version": "1.0",
            "source_name": source_name,
            "page_count": int(page_count),
            "pages": pages,
            "elements": elements,
        }

    @staticmethod
    def _save_provenance_manifest(
        manifest: dict[str, Any],
        image_output_dir: str | Path | None,
    ) -> Path | None:
        if image_output_dir is None:
            return None
        output_path = Path(image_output_dir) / "docling_provenance_manifest.json"
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            return output_path.resolve()
        except (OSError, TypeError, ValueError) as exc:
            logger.warning("Failed to save Docling provenance manifest: {}", exc)
            return None

    @staticmethod
    def _save_docling_document_json(doc: Any, image_output_dir: str | Path | None) -> Path | None:
        """Persist Docling's lossless structured export beside Markdown."""
        if image_output_dir is None or not hasattr(doc, "export_to_dict"):
            return None
        output_path = Path(image_output_dir) / "docling_document.json"
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(
                json.dumps(doc.export_to_dict(), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            return output_path.resolve()
        except (OSError, TypeError, ValueError) as exc:
            logger.warning("Failed to save structured Docling JSON: {}", exc)
            return None
    def _save_doc_formulas(
        self,
        doc,
        image_output_dir: str | Path | None,
        source_stem: str,
        page_offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Save formula element crops while the Docling page backend is available."""
        if image_output_dir is None or not self._config.enable_formula_recognition:
            return []

        formula_dir = (
            Path(image_output_dir)
            / FORMULA_RECOGNITION_DIRNAME
            / FORMULA_IMAGES_DIRNAME
        )
        try:
            formula_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.warning("Failed to create formula image directory {}: {}", formula_dir, exc)
            return []

        safe_stem = self._safe_image_stem(source_stem)
        saved_formulas: list[dict[str, Any]] = []
        formula_index = 0
        for item in getattr(doc, "texts", []) or []:
            label = getattr(item, "label", None)
            label_value = str(getattr(label, "value", label) or "").lower()
            if label_value != "formula":
                continue

            formula_index += 1
            page_no = self._picture_page_number(item, page_offset)
            page_token = page_no if page_no is not None else page_offset + 1
            output_path = formula_dir / (
                f"{safe_stem}_page_{page_token:0{IMAGE_FILENAME_INDEX_WIDTH}d}"
                f"_formula_{formula_index:0{IMAGE_FILENAME_INDEX_WIDTH}d}.png"
            )
            formula_record = {
                "index": len(saved_formulas),
                "page": page_no,
                "filename": output_path.name,
                "path": "",
                "original_text": str(getattr(item, "text", "") or ""),
                "status": "missing",
            }
            try:
                image = item.get_image(doc) if hasattr(item, "get_image") else None
                if image is None:
                    saved_formulas.append(formula_record)
                    continue
                image.save(output_path)
            except (AttributeError, OSError, ValueError) as exc:
                logger.debug("Formula image extraction note for {}: {}", output_path.name, exc)
                formula_record["error"] = str(exc)
                saved_formulas.append(formula_record)
                continue
            if not self._is_saved_image_valid(output_path):
                saved_formulas.append(formula_record)
                continue
            formula_record.update(
                {
                    "path": str(output_path.resolve()),
                    "status": "saved",
                }
            )
            saved_formulas.append(formula_record)
        return saved_formulas

    def _save_picture_image(self, doc, picture, output_path: Path) -> bool:
        try:
            image = picture.get_image(doc) if hasattr(picture, "get_image") else None
            if image is not None:
                image.save(output_path)
                return self._is_saved_image_valid(output_path)
        except (AttributeError, OSError, ValueError) as exc:
            logger.debug("Picture image extraction note for {}: {}", output_path.name, exc)
        return self._save_image_ref(getattr(picture, "image", None), output_path)

    def _save_image_ref(self, image_ref, output_path: Path) -> bool:
        if image_ref is None:
            return False
        try:
            image = getattr(image_ref, "pil_image", None)
            if callable(image):
                image = image()
            if image is not None:
                image.save(output_path)
                return self._is_saved_image_valid(output_path)

            uri = getattr(image_ref, "uri", None)
            if uri:
                uri_text = str(uri)
                uri_text = unquote(uri_text)
                uri_text = uri_text.removeprefix("file://")
                source_path = Path(uri_text)
                if source_path.is_file():
                    output_path.write_bytes(source_path.read_bytes())
                    return self._is_saved_image_valid(output_path)
        except (AttributeError, OSError, ValueError) as exc:
            logger.debug("Image export note for {}: {}", output_path.name, exc)
        return False

    def _is_saved_image_valid(self, output_path: Path) -> bool:
        try:
            return output_path.is_file() and output_path.stat().st_size > 0
        except OSError as exc:
            logger.debug("Image validation note for {}: {}", output_path.name, exc)
            return False

    def _coerce_page_number(self, value, fallback) -> int:
        for candidate in (value, fallback):
            try:
                return max(1, int(candidate))
            except (TypeError, ValueError):
                continue
        return 1

    def _picture_page_number(self, picture, page_offset: int) -> int | None:
        prov = getattr(picture, "prov", None) or []
        if not prov:
            return None
        page_no = getattr(prov[0], "page_no", None)
        if page_no is None:
            return None
        return page_offset + self._coerce_page_number(page_no, 1)

    @classmethod
    def _picture_geometry_metadata(
        cls,
        picture: Any | None,
        doc: Any | None = None,
    ) -> dict[str, Any]:
        """Return best-effort Docling picture geometry metadata."""
        metadata = {
            "bbox": None,
            "page_width": None,
            "page_height": None,
            "image_area_ratio": None,
            "position_band": None,
        }
        if picture is None:
            return metadata
        prov = getattr(picture, "prov", None) or []
        if not prov:
            return metadata
        item = prov[0]
        bbox_points = cls._serialize_docling_bbox(getattr(item, "bbox", None))
        page_width, page_height = cls._docling_page_dimensions(item, doc=doc)
        metadata["bbox"] = bbox_points
        metadata["page_width"] = page_width
        metadata["page_height"] = page_height
        if bbox_points and page_width and page_height:
            xs = [point[0] for point in bbox_points]
            ys = [point[1] for point in bbox_points]
            width = max(xs) - min(xs)
            height = max(ys) - min(ys)
            page_area = float(page_width) * float(page_height)
            if page_area > 0:
                metadata["image_area_ratio"] = round((width * height) / page_area, 6)
            y_center_ratio = ((min(ys) + max(ys)) / 2) / float(page_height)
            coord_origin = str(
                getattr(getattr(item, "bbox", None), "coord_origin", "") or ""
            ).upper()
            if "BOTTOMLEFT" in coord_origin:
                y_center_ratio = 1.0 - y_center_ratio
            if y_center_ratio <= 0.12:
                metadata["position_band"] = "header"
            elif y_center_ratio >= 0.88:
                metadata["position_band"] = "footer"
            else:
                metadata["position_band"] = "body"
        return metadata

    @staticmethod
    def _serialize_docling_bbox(bbox: Any) -> list[list[float]] | None:
        if bbox is None:
            return None
        for left_name, top_name, right_name, bottom_name in (
            ("l", "t", "r", "b"),
            ("left", "top", "right", "bottom"),
            ("x0", "y0", "x1", "y1"),
        ):
            values = [
                getattr(bbox, left_name, None),
                getattr(bbox, top_name, None),
                getattr(bbox, right_name, None),
                getattr(bbox, bottom_name, None),
            ]
            if all(value is not None for value in values):
                left, top, right, bottom = [float(value) for value in values]
                return [[left, top], [right, top], [right, bottom], [left, bottom]]
        if hasattr(bbox, "as_tuple"):
            try:
                left, top, right, bottom = [float(value) for value in bbox.as_tuple()]
                return [[left, top], [right, top], [right, bottom], [left, bottom]]
            except (TypeError, ValueError):
                return None
        return None

    @staticmethod
    def _docling_page_dimensions(
        item: Any,
        *,
        doc: Any | None = None,
    ) -> tuple[float | None, float | None]:
        page_no = getattr(item, "page_no", None)
        pages = getattr(doc, "pages", None) if doc is not None else None
        if isinstance(pages, dict) and page_no is not None:
            page_item = pages.get(page_no)
            if page_item is None:
                try:
                    page_item = pages.get(int(page_no))
                except (TypeError, ValueError):
                    page_item = None
            page_size = getattr(page_item, "size", None)
            width = getattr(page_size, "width", None)
            height = getattr(page_size, "height", None)
            if width is not None and height is not None:
                return float(width), float(height)
        page_size = getattr(item, "page_size", None) or getattr(item, "page_bbox", None)
        if page_size is None:
            return None, None
        width = getattr(page_size, "width", None) or getattr(page_size, "w", None)
        height = getattr(page_size, "height", None) or getattr(page_size, "h", None)
        if width is not None and height is not None:
            return float(width), float(height)
        bbox_points = DriverDoclingService._serialize_docling_bbox(page_size)
        if bbox_points:
            xs = [point[0] for point in bbox_points]
            ys = [point[1] for point in bbox_points]
            return max(xs) - min(xs), max(ys) - min(ys)
        return None, None

    def _safe_image_stem(self, name: str) -> str:
        safe = re.sub(r"[^a-zA-Z0-9_.-]+", "_", name).strip("._")
        return safe[:_MAX_IMAGE_STEM_LENGTH] if safe else "document"

    # ==================== Image Reference Injection (Stage 1) ====================

    def _inject_image_references(
        self,
        content: str,
        exported_images: list[dict],
        doc
    ) -> tuple[str, dict]:
        """
        Stage 1: Replace <!-- image --> placeholders with image path references.
        
        This creates a verifiable mapping between placeholders and actual image files.
        
        Args:
            content: Markdown content with <!-- image --> placeholders
            exported_images: List of saved image file information
            doc: Docling document object
        
        Returns:
            Tuple of (modified_content, image_mapping)
            - modified_content: Markdown with image references
            - image_mapping: Dict mapping placeholder index to image info
        """
        lines = content.split('\n')
        result_lines = []
        image_mapping = {}
        
        # Filter picture-type images (embedded images, not full page screenshots)
        picture_images = [img for img in exported_images if img['type'] == 'picture']
        
        picture_counter = 0
        total_image_counter = 0
        
        for line_no, line in enumerate(lines):
            if line.strip() == '<!-- image -->':
                if picture_counter < len(picture_images):
                    img = picture_images[picture_counter]
                    
                    # Generate numbered image reference with metadata
                    caption = img.get('caption', '')
                    page = img.get('page', 'unknown')
                    filename = img['filename']
                    
                    # Markdown image syntax with title attribute for metadata.
                    # The knowledge-base markdown is saved next to the *_images folder,
                    # so the reference must include the image directory name.
                    image_dir_name = Path(img.get("path", "")).parent.name if img.get("path") else ""
                    rel_path = f"{image_dir_name}/{filename}" if image_dir_name else filename
                    img_ref = f"![Image {total_image_counter + 1}](./{rel_path} \"Page:{page} | Index:{total_image_counter}\")"
                    
                    # Record mapping for verification
                    image_mapping[total_image_counter] = {
                        "markdown_line": line_no,
                        "placeholder_index": total_image_counter,
                        "picture_index": picture_counter,
                        "filename": filename,
                        "path": img['path'],
                        "page": page,
                        "original_caption": caption,
                        **self._picture_geometry_metadata(
                            doc.pictures[picture_counter]
                            if hasattr(doc, "pictures") and picture_counter < len(doc.pictures)
                            else None,
                            doc=doc,
                        ),
                    }
                    
                    result_lines.append(img_ref)
                    picture_counter += 1
                    total_image_counter += 1
                else:
                    # No matching file for placeholder
                    result_lines.append(f"<!-- image: WARNING - No matching file for placeholder {total_image_counter} -->")
                    logger.warning(
                        "Line {}: No picture file for placeholder {}",
                        line_no,
                        total_image_counter,
                    )
                    image_mapping[total_image_counter] = {
                        "markdown_line": line_no,
                        "placeholder_index": total_image_counter,
                        "picture_index": None,
                        "filename": "",
                        "path": "",
                        "page": "unknown",
                        "original_caption": "",
                        "status": "missing",
                    }
                    total_image_counter += 1
            else:
                result_lines.append(line)
        
        new_content = '\n'.join(result_lines)
        
        logger.info("Stage 1: Injected {} image references", len(image_mapping))
        
        return new_content, image_mapping

    def _verify_image_mapping(
        self,
        image_mapping: dict,
        doc,
        content: str
    ) -> dict:
        """
        Stage 2: Verify the accuracy of image mapping.
        
        Performs multiple checks to ensure placeholder-to-file correspondence is correct.
        
        Args:
            image_mapping: The mapping created in stage 1
            doc: Docling document object
            content: Markdown content (for context)
        
        Returns:
            Verification report dict with keys:
            - total_placeholders: Total number mapped
            - verified: Number successfully verified
            - warnings: List of warning messages
            - errors: List of error messages
            - success: Boolean indicating if verification passed
            - accuracy: Float ratio of verified/total
        """
        report = {
            "total_placeholders": len(image_mapping),
            "verified": 0,
            "mapped": 0,
            "missing": 0,
            "warnings": [],
            "errors": []
        }
        
        for idx, mapping in image_mapping.items():
            if mapping.get("status") == "missing":
                report["missing"] += 1
                report['errors'].append(f"Image {idx}: Markdown placeholder has no matching image file")
                continue

            # Check 1: File existence
            img_path = Path(mapping['path'])
            if not img_path.exists():
                report['errors'].append(f"Image {idx}: file does not exist: {img_path}")
                continue

            report["mapped"] += 1
            
            # Check 2: File size sanity check
            file_size = img_path.stat().st_size
            if file_size < MIN_IMAGE_FILE_SIZE_BYTES:
                report['warnings'].append(f"Image {idx}: file is too small ({file_size} bytes) - {img_path.name}")
            elif file_size > MAX_IMAGE_FILE_SIZE_BYTES:
                report['warnings'].append(
                    f"Image {idx}: file is too large ({file_size // BYTES_PER_KIB}KB) - {img_path.name}"
                )
            
            # Check 3: Cross-reference with Docling document
            if hasattr(doc, 'pictures') and mapping['picture_index'] < len(doc.pictures):
                docling_picture = doc.pictures[mapping['picture_index']]
                
                # Verify page number consistency
                if docling_picture.prov:
                    docling_page = getattr(docling_picture.prov[0], 'page_no', None)
                    mapped_page = mapping['page']
                    
                    if docling_page and mapped_page and str(docling_page) != str(mapped_page):
                        report['warnings'].append(
                            f"Image {idx}: page mismatch (Docling={docling_page}, Mapped={mapped_page})"
                        )
            
            # Check 4: Filename format validation
            if not PICTURE_IMAGE_FILENAME_PATTERN.match(mapping['filename']):
                report['warnings'].append(f"Image {idx}: unexpected filename format: {mapping['filename']}")
            
            report['verified'] += 1
        
        # Calculate success metrics
        report['success'] = len(report['errors']) == 0
        report['accuracy'] = report['verified'] / report['total_placeholders'] if report['total_placeholders'] > 0 else 0
        
        return report

    def _inject_image_references_from_saved_images(
        self,
        content: str,
        saved_images: list[dict],
    ) -> tuple[str, dict]:
        """
        Replace <!-- image --> placeholders using already-saved Docling image files.

        This is used by the batched PDF/OCR path, where each 10-page batch has its
        own temporary Docling document and the final merged markdown no longer has a
        single Docling document object that can be used for direct picture mapping.
        """
        lines = content.split("\n")
        result_lines: list[str] = []
        image_mapping: dict[int, dict[str, Any]] = {}

        picture_images = [img for img in saved_images if img.get("type") == "picture"]
        image_counter = 0

        for line_no, line in enumerate(lines):
            if line.strip() == "<!-- image -->":
                if image_counter < len(picture_images):
                    img = picture_images[image_counter]
                    filename = img.get("filename", "")
                    page = img.get("page", "unknown")
                    image_dir_name = Path(img.get("path", "")).parent.name if img.get("path") else ""
                    rel_path = f"{image_dir_name}/{filename}" if image_dir_name else filename
                    img_ref = f"![Image {image_counter + 1}](./{rel_path} \"Page:{page} | Index:{image_counter}\")"
                    result_lines.append(img_ref)
                    image_mapping[image_counter] = {
                        "markdown_line": line_no,
                        "placeholder_index": image_counter,
                        "picture_index": image_counter,
                        "filename": filename,
                        "path": img.get("path", ""),
                        "page": page,
                        "original_caption": img.get("caption", ""),
                        "bbox": img.get("bbox"),
                        "page_width": img.get("page_width"),
                        "page_height": img.get("page_height"),
                        "image_area_ratio": img.get("image_area_ratio"),
                        "position_band": img.get("position_band"),
                    }
                else:
                    result_lines.append(
                        f"<!-- image: WARNING - No matching file for placeholder {image_counter} -->"
                    )
                    logger.warning(
                        "Line {}: No picture file for placeholder {}",
                        line_no,
                        image_counter,
                    )
                    image_mapping[image_counter] = {
                        "markdown_line": line_no,
                        "placeholder_index": image_counter,
                        "picture_index": None,
                        "filename": "",
                        "path": "",
                        "page": "unknown",
                        "original_caption": "",
                        "status": "missing",
                    }
                image_counter += 1
            else:
                result_lines.append(line)

        if image_counter != len(picture_images):
            logger.warning(
                "Image placeholder count differs from saved picture count: "
                f"placeholders={image_counter}, pictures={len(picture_images)}"
            )

        logger.info(
            "Stage 1 (saved images): Injected {} image references",
            len(image_mapping),
        )
        return "\n".join(result_lines), image_mapping

    def _verify_saved_image_mapping(self, image_mapping: dict) -> dict:
        """Verify mappings that were built from saved image metadata only."""
        report = {
            "total_placeholders": len(image_mapping),
            "verified": 0,
            "mapped": 0,
            "missing": 0,
            "warnings": [],
            "errors": [],
        }

        for idx, mapping in image_mapping.items():
            if mapping.get("status") == "missing":
                report["missing"] += 1
                report["errors"].append(f"Image {idx}: Markdown placeholder has no matching image file")
                continue

            img_path = Path(mapping.get("path", ""))
            if not img_path.exists():
                report["errors"].append(f"Image {idx}: file does not exist: {img_path}")
                continue

            report["mapped"] += 1

            file_size = img_path.stat().st_size
            if file_size < MIN_IMAGE_FILE_SIZE_BYTES:
                report["warnings"].append(f"Image {idx}: file is too small ({file_size} bytes) - {img_path.name}")
            elif file_size > MAX_IMAGE_FILE_SIZE_BYTES:
                report["warnings"].append(
                    f"Image {idx}: file is too large ({file_size // BYTES_PER_KIB}KB) - {img_path.name}"
                )

            filename = mapping.get("filename", "")
            if not PICTURE_IMAGE_FILENAME_PATTERN.match(filename):
                report["warnings"].append(f"Image {idx}: unexpected filename format: {filename}")

            report["verified"] += 1

        report["success"] = len(report["errors"]) == 0
        report["accuracy"] = (
            report["verified"] / report["total_placeholders"]
            if report["total_placeholders"] > 0
            else 0
        )
        return report

    async def _maybe_recognize_formulas(
        self,
        content: str,
        formulas: list[dict[str, Any]],
        image_output_dir: str | Path | None,
        source_name: str,
        task_id: str | None = None,
    ) -> tuple[str, dict[str, Any]]:
        return await self._formula_service.recognize_formulas(
            content,
            formulas,
            image_output_dir,
            source_name,
            task_id=task_id,
        )

    async def _maybe_inject_image_descriptions(
        self,
        content: str,
        image_mapping: dict,
        image_output_dir: str | Path | None,
        source_name: str,
        task_id: str | None = None,
    ) -> tuple[str, dict]:
        return await self._image_description_service.inject_image_descriptions(
            content,
            image_mapping,
            image_output_dir,
            source_name,
            task_id=task_id,
        )

    # ==================== Structure Extraction ====================

    def _rebind_missing_table_captions(
        self,
        *,
        content: str,
        doc: Any,
        source_pdf: Path,
        page_offset: int = 0,
    ) -> tuple[str, list[dict[str, Any]]]:
        """Insert PDF captions for Docling tables that have no caption element.

        ``source_pdf`` is deliberately the PDF used for the current conversion. In
        the OCR batching path this is the temporary batch PDF, whose local page
        numbers are converted to source-document pages with ``page_offset``.
        """
        iterator = getattr(doc, "iterate_items", None)
        if not callable(iterator):
            return content, []
        try:
            items = iterator(with_groups=False)
        except TypeError:
            items = iterator()
        tables = []
        for item, _level in items:
            label = str(getattr(getattr(item, "label", None), "value", getattr(item, "label", "")) or "").lower()
            if label == "table":
                tables.append(item)

        captions_by_page = self._pdf_table_caption_candidates(source_pdf)
        report: list[dict[str, Any]] = []
        search_from = 0
        for table in tables:
            caption = str(getattr(table, "caption", None) or "").strip()
            exporter = getattr(table, "export_to_markdown", None)
            table_markdown = str(exporter() or "").strip() if callable(exporter) else ""
            if caption:
                report.append({"status": "already_bound", "caption": caption})
                continue
            if not table_markdown:
                report.append({"status": "skipped", "reason": "table_markdown_unavailable"})
                continue
            block_start = self._find_table_markdown(content, table_markdown, search_from)
            if block_start < 0:
                report.append({"status": "skipped", "reason": "table_markdown_not_found"})
                continue
            search_from = block_start + len(table_markdown)
            page_no, table_bbox = self._docling_item_page_bbox(table, page_offset=page_offset, doc=doc)
            candidates = captions_by_page.get(page_no - page_offset if page_no is not None else -1, [])
            if not candidates:
                report.append({"status": "orphan", "page": page_no})
                continue
            candidate = self._best_table_caption_candidate(candidates, table_bbox)
            title = candidate["text"]
            prefix = content[max(0, block_start - 500):block_start]
            if re.search(re.escape(title), prefix, re.IGNORECASE):
                report.append({"status": "already_bound", "caption": title, "page": page_no})
                continue
            content = content[:block_start] + title + "\n\n" + content[block_start:]
            search_from = block_start + len(title) + 2
            report.append({
                "status": "rebound",
                "caption": title,
                "page": page_no,
                "source": candidate.get("source"),
                "confidence": candidate.get("confidence", 0.0),
            })
        return content, report

    @staticmethod
    def _find_table_markdown(content: str, table_markdown: str, start: int) -> int:
        direct = content.find(table_markdown, start)
        if direct >= 0:
            return direct
        target_lines = [re.sub(r"\s+", " ", line).strip() for line in table_markdown.splitlines() if line.strip()]
        if not target_lines:
            return -1
        offset = 0
        for line in content.splitlines(keepends=True):
            normalized = re.sub(r"\s+", " ", line).strip()
            if offset >= start and normalized == target_lines[0]:
                return offset
            offset += len(line)
        return -1

    @staticmethod
    def _pdf_table_caption_candidates(source_pdf: Path) -> dict[int, list[dict[str, Any]]]:
        result: dict[int, list[dict[str, Any]]] = {}
        try:
            import fitz
            document = fitz.open(str(source_pdf))
            for index, page in enumerate(document):
                for block in page.get_text("blocks"):
                    if len(block) < 5:
                        continue
                    text = " ".join(str(block[4] or "").split())
                    for caption in DriverDoclingService._table_caption_texts(text):
                        result.setdefault(index + 1, []).append({
                            "text": caption,
                            "bbox": [[float(block[0]), float(block[1])], [float(block[2]), float(block[3])]],
                            "source": "pdf_text_span",
                            "confidence": 0.98,
                        })
            document.close()
        except Exception:
            pass
        if result:
            return result
        try:
            from pypdf import PdfReader
            reader = PdfReader(str(source_pdf))
            for index, page in enumerate(reader.pages):
                text = str(page.extract_text() or "")
                for line in text.splitlines():
                    for caption in DriverDoclingService._table_caption_texts(" ".join(line.split())):
                        result.setdefault(index + 1, []).append({
                            "text": caption,
                            "source": "pdf_text",
                            "confidence": 0.90,
                        })
        except Exception:
            pass
        return result

    @staticmethod
    def _table_caption_texts(text: str) -> list[str]:
        """Return standalone or trailing embedded table captions from PDF text."""
        normalized = " ".join(text.split())
        standalone = TABLE_CAPTION_PATTERN.match(normalized)
        if standalone:
            return [standalone.group(1)]
        embedded = EMBEDDED_TABLE_CAPTION_PATTERN.search(normalized)
        return [embedded.group(1)] if embedded else []

    @staticmethod
    def _docling_item_page_bbox(item: Any, page_offset: int = 0, doc: Any | None = None) -> tuple[int | None, list[list[float]] | None]:
        prov = getattr(item, "prov", None) or []
        if not prov:
            return None, None
        first = prov[0]
        try:
            page_no = int(getattr(first, "page_no", 0)) + page_offset
        except (TypeError, ValueError):
            page_no = None
        points = DriverDoclingService._serialize_docling_bbox(getattr(first, "bbox", None))
        if points and "BOTTOMLEFT" in str(getattr(getattr(first, "bbox", None), "coord_origin", "") or "").upper():
            _, page_height = DriverDoclingService._docling_page_dimensions(first, doc=doc)
            if page_height:
                points = [[point[0], float(page_height) - point[1]] for point in points]
        return page_no, points

    @staticmethod
    def _best_table_caption_candidate(
        candidates: list[dict[str, Any]],
        table_bbox: list[list[float]] | None,
    ) -> dict[str, Any]:
        if not table_bbox or len(candidates) == 1:
            return candidates[0]
        table_x = [point[0] for point in table_bbox]
        table_y = [point[1] for point in table_bbox]
        table_left, table_right = min(table_x), max(table_x)
        table_top, table_bottom = min(table_y), max(table_y)
        scored = []
        for candidate in candidates:
            bbox = candidate.get("bbox")
            if not bbox:
                scored.append((float("inf"), candidate))
                continue
            xs = [point[0] for point in bbox]
            ys = [point[1] for point in bbox]
            overlap = max(0.0, min(table_right, max(xs)) - max(table_left, min(xs)))
            overlap_ratio = overlap / max(1.0, min(table_right - table_left, max(xs) - min(xs)))
            distance = min(abs(max(ys) - table_top), abs(table_bottom - min(ys)))
            scored.append((distance + (1.0 - overlap_ratio) * 1000.0, candidate))
        scored.sort(key=lambda value: value[0])
        return scored[0][1]

    def _extract_tables(self, doc) -> list[dict[str, Any]]:
        """Extract table data from DoclingDocument."""
        tables = []
        try:
            if hasattr(doc, "tables"):
                for table in doc.tables:
                    table_data = {
                        "caption": getattr(table, "caption", "") or "",
                        "data": getattr(table, "data", []),
                    }
                    # Export table as markdown if possible
                    if hasattr(table, "export_to_markdown"):
                        table_data["markdown"] = table.export_to_markdown()
                    tables.append(table_data)
        except Exception as e:
            logger.debug("Table extraction note: {}", e)
        return tables

    def _extract_figures(self, doc, page_offset: int = 0) -> list[dict[str, Any]]:
        """Extract figure/image metadata from DoclingDocument."""
        figures = []
        try:
            if hasattr(doc, "pictures"):
                for pic in doc.pictures:
                    figures.append({
                        "caption": getattr(pic, "caption", "") or "",
                        "page": self._picture_page_number(pic, page_offset=page_offset),
                    })
        except Exception as e:
            logger.debug("Figure extraction note: {}", e)
        return figures

    def _extract_headings(self, content: str) -> list[dict[str, Any]]:
        """Extract heading hierarchy from markdown content."""
        headings = []
        for line in content.split("\n"):
            match = MARKDOWN_HEADING_PATTERN.match(line)
            if match:
                level = len(match.group(1))
                text = match.group(2).strip()
                headings.append({"level": level, "text": text})
        return headings

    # ==================== Register Detection ====================

    def _extract_registers_from_code(self, content: str) -> list[dict[str, Any]]:
        """Extract register definitions from C/H source code."""
        registers = []
        # Match: #define REG_NAME (0xADDRESS) or #define ADDR_NAME 0xADDRESS
        pattern = re.compile(
            r"#define\s+(\w+(?:_REG|_ADDR|_BASE|_OFFSET|_CR|_SR|_DR)\w*)\s+\(?0x([0-9A-Fa-f]+)\)?",
            re.MULTILINE,
        )
        for match in pattern.finditer(content):
            registers.append({
                "name": match.group(1),
                "offset": f"0x{match.group(2)}",
                "source": "code_define",
            })

        # Match: volatile uint32_t* REG = (volatile uint32_t*)0xADDR
        vol_pattern = re.compile(
            r"volatile\s+\w+\s*\*\s*(\w+)\s*=\s*\(.*?\)?\s*0x([0-9A-Fa-f]+)",
            re.MULTILINE,
        )
        for match in vol_pattern.finditer(content):
            registers.append({
                "name": match.group(1),
                "offset": f"0x{match.group(2)}",
                "source": "code_volatile",
            })

        return registers

    def _detect_register_tables(self, content: str) -> list[dict[str, Any]]:
        """Detect register tables from document content (markdown tables with hex addresses)."""
        registers = []
        # Match markdown table rows with register-like data
        pattern = re.compile(
            r"^\|?\s*(\w[\w\s]*\w)\s*\|?\s*0x([0-9A-Fa-f]+)\s*\|?\s*(\d+)?\s*\|?\s*(R|W|RW|RO|WO|R/W)?\s*\|?",
            re.MULTILINE,
        )
        for match in pattern.finditer(content):
            reg = {
                "name": match.group(1).strip(),
                "offset": f"0x{match.group(2)}",
                "source": "document_table",
            }
            if match.group(3):
                reg["width"] = int(match.group(3))
            if match.group(4):
                reg["access"] = match.group(4)
            registers.append(reg)
        return registers

    # ==================== Text File Parsing ====================

    async def _parse_text_file(self, path: Path) -> dict[str, Any]:
        """Parse plain text / source code files directly."""
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            headings = self._extract_headings(content)
            registers = (
                self._extract_registers_from_code(content)
                if path.suffix in (".c", ".h", ".hpp", ".cpp")
                else []
            )
            summary = self._generate_text_summary(content, path)

            return {
                "content": content,
                "summary": summary,
                "tables": [],
                "figures": [],
                "headings": headings,
                "registers": registers,
                "metadata": {
                    "source_type": "text",
                    "lines": content.count("\n") + 1,
                    "chars": len(content),
                    "extension": path.suffix,
                },
            }
        except Exception as e:
            logger.error("Failed to parse text file {}: {}", path, e)
            return {"content": "", "summary": f"Parse error: {e}", "error": str(e)}

    async def _fallback_parse(self, path: Path) -> dict[str, Any]:
        """Fallback when Docling is not available or fails.

        For binary formats (PDF, DOCX, etc.), return error instead of corrupted content.
        For text formats, attempt basic text read.
        """
        ext = path.suffix.lower()

        # Binary formats that cannot be read as text
        binary_formats = {".pdf", ".docx", ".pptx", ".xlsx", ".png", ".jpg", ".jpeg", ".tiff", ".bmp"}

        if ext in binary_formats:
            logger.warning("Cannot parse binary format {} without Docling: {}", ext, path.name)
            return {
                "content": "",
                "summary": f"Binary format {ext} requires Docling parser (currently unavailable or failed)",
                "error": "BINARY_FORMAT_NO_PARSER",
                "tables": [],
                "figures": [],
                "headings": [],
                "registers": [],
                "metadata": {"source_type": "fallback", "extension": ext},
            }

        # Text formats - attempt basic read
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            return {
                "content": content,
                "summary": f"Fallback parse (Docling unavailable): {path.name}",
                "tables": [],
                "figures": [],
                "headings": self._extract_headings(content),
                "registers": self._detect_register_tables(content),
                "metadata": {"source_type": "fallback", "extension": ext},
            }
        except Exception as e:
            logger.error("Fallback parse failed for {}: {}", path, e)
            return {"content": "", "summary": "Cannot read file", "error": "READ_FAILED"}

    # ==================== Summary Generation ====================

    def _generate_text_summary(self, content: str, path: Path) -> str:
        """Generate brief summary for text/source content."""
        lines = content.split("\n")
        line_count = len(lines)
        ext = path.suffix

        if ext in (".c", ".h", ".cpp", ".hpp"):
            func_pattern = re.compile(r"^\w[\w\s\*]+\s+(\w+)\s*\(", re.MULTILINE)
            funcs = func_pattern.findall(content)
            defines = len(re.findall(r"^#define\s+", content, re.MULTILINE))
            includes = len(re.findall(r"^#include\s+", content, re.MULTILINE))
            return (
                f"Source '{path.name}': {line_count} lines, "
                f"{len(funcs)} functions, {defines} defines, {includes} includes."
            )
        return f"Text '{path.name}': {line_count} lines."

    def _generate_document_summary(
        self, content: str, filename: str, metadata: dict[str, Any]
    ) -> str:
        """Generate summary for parsed document with structural info."""
        word_count = len(content.split())
        parts = [f"Document '{filename}': {word_count} words"]

        page_count = metadata.get("page_count")
        if page_count:
            parts.append(f"{page_count} pages")

        table_count = metadata.get("table_count", 0)
        if table_count:
            parts.append(f"{table_count} tables")

        figure_count = metadata.get("figure_count", 0)
        if figure_count:
            parts.append(f"{figure_count} figures")

        heading_count = metadata.get("heading_count", 0)
        if heading_count:
            parts.append(f"{heading_count} sections")

        register_count = metadata.get("register_count", 0)
        if register_count:
            parts.append(f"{register_count} registers detected")

        return ", ".join(parts) + "."


# ==================== Docling Post-processing Hook ====================
# Kept as a small hook to avoid growing the main parsing service further.
# The implementation lives in driver_docling_postprocess_service.py.
try:
    from app.services.driver_docling_postprocess_service import DriverDoclingPostprocessService

    _ORIGINAL_PARSE_WITH_DOCLING = DriverDoclingService._parse_with_docling

    async def _parse_with_docling_postprocessed(self, path, image_output_dir=None, task_id=None):
        result = await _ORIGINAL_PARSE_WITH_DOCLING(
            self,
            path,
            image_output_dir=image_output_dir,
            task_id=task_id,
        )
        if not isinstance(result, dict) or result.get("error") or not result.get("content"):
            return result

        postprocessor = DriverDoclingPostprocessService(
            precision_table_timeout_seconds=getattr(
                self._config,
                "image_description_timeout",
                DEFAULT_IMAGE_DESCRIPTION_TIMEOUT_SECONDS,
            ),
            toc_max_items=getattr(self._config, "toc_max_items", DEFAULT_TOC_MAX_ITEMS),
        )
        content, postprocess_report = await postprocessor.postprocess_content_async(
            content=str(result.get("content") or ""),
            image_output_dir=image_output_dir,
            source_name=getattr(path, "stem", str(path)),
            metadata=result.get("metadata") or {},
            provenance_manifest=result.get("provenance_manifest"),
        )
        result["content"] = content
        metadata = result.setdefault("metadata", {})
        metadata["postprocess"] = postprocess_report
        # Postprocess metadata is retained without a publishability gate.
        result["headings"] = self._extract_headings(content)
        result["registers"] = self._detect_register_tables(content)
        metadata["heading_count"] = len(result["headings"])
        metadata["register_count"] = len(result["registers"])
        result["summary"] = self._generate_document_summary(
            content,
            getattr(path, "name", str(path)),
            metadata,
        )
        return result

    DriverDoclingService._parse_with_docling = _parse_with_docling_postprocessed
except Exception as exc:
    logger.warning("Docling post-processing hook was not installed: {}", exc)
