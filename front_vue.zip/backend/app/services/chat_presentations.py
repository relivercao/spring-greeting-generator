"""Encode bounded, structured Chat slide content as an editable PowerPoint file."""

from __future__ import annotations

import io
import json
from typing import Any


PRESENTATION_CONTENT_INSTRUCTIONS = (
    'For .pptx, content must be an object with schema '
    '{"slides":[{"title":"Slide title","bullets":["Key point"],"notes":"Speaker notes"}]}. '
    "Include 1 to 60 slides, a nonempty title of at most 160 characters on each slide, "
    "at most 6 nonempty bullet strings of at most 180 characters each, "
    "and optional speaker notes of at most 8000 characters. Put detail in the notes. "
    "Return slide content, never source code, base64, a local path, or a download URL."
)


def _validated_slides(content: Any) -> list[dict[str, Any]]:
    if isinstance(content, str):
        try:
            content = json.loads(content)
        except json.JSONDecodeError as error:
            raise ValueError("Presentation content must be valid JSON") from error
    slides = content.get("slides") if isinstance(content, dict) else None
    if not isinstance(slides, list) or not 1 <= len(slides) <= 60:
        raise ValueError("Presentation must contain between 1 and 60 slides")
    for slide in slides:
        if not isinstance(slide, dict):
            raise ValueError("Presentation slides must be objects")
        title = slide.get("title")
        bullets = slide.get("bullets", [])
        notes = slide.get("notes", "")
        if not isinstance(title, str) or not title.strip() or len(title) > 160:
            raise ValueError("Presentation slide titles must contain 1 to 160 characters")
        if (
            not isinstance(bullets, list) or len(bullets) > 6
            or any(not isinstance(item, str) or not item.strip() or len(item) > 180 for item in bullets)
        ):
            raise ValueError("Presentation slides support up to 6 bullet strings of 1 to 180 characters")
        if not isinstance(notes, str) or len(notes) > 8000:
            raise ValueError("Presentation speaker notes must be text of at most 8000 characters")
    return slides


def encode_presentation(content: Any) -> bytes:
    """Validate before creating any file; return an actual OOXML presentation."""
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.util import Inches, Pt

    slides = _validated_slides(content)
    presentation = Presentation()
    presentation.slide_width = Inches(13.333)
    presentation.slide_height = Inches(7.5)
    for entry in slides:
        slide = presentation.slides.add_slide(presentation.slide_layouts[1])
        title = slide.shapes.title
        title.left, title.top = Inches(0.6), Inches(0.35)
        title.width, title.height = Inches(12.1), Inches(1.1)
        title.text = entry["title"].strip()
        title.text_frame.word_wrap = True
        for paragraph in title.text_frame.paragraphs:
            paragraph.font.size = Pt(30)
            paragraph.font.bold = True
            paragraph.font.color.rgb = RGBColor.from_string("17365D")
        body = slide.placeholders[1]
        body.left, body.top = Inches(0.7), Inches(1.65)
        body.width, body.height = Inches(11.9), Inches(5.2)
        body.text_frame.clear()
        body.text_frame.word_wrap = True
        for index, bullet in enumerate(entry.get("bullets", [])):
            paragraph = body.text_frame.paragraphs[0] if index == 0 else body.text_frame.add_paragraph()
            paragraph.text = bullet.strip()
            paragraph.level = 0
            paragraph.font.size = Pt(22)
            paragraph.space_after = Pt(10)
        if entry.get("notes"):
            slide.notes_slide.notes_text_frame.text = entry["notes"]
    output = io.BytesIO()
    presentation.save(output)
    return output.getvalue()
