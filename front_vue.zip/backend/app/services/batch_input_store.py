"""Validation and durable input snapshots for queued Batch Unit-Test work.

The store is intentionally independent from the ORM.  It prepares a complete
snapshot before a caller publishes BatchTask/BatchItem/QueueEntry rows, and it
provides cleanup hooks for database rollback and startup orphan recovery.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import shutil
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from app.core.batch_contract import BATCH_ALLOWED_EXTENSIONS
from app.core.config import (
    DEFAULT_BATCH_MAX_FILES,
    DEFAULT_BATCH_MAX_FILE_SIZE_BYTES,
    DEFAULT_BATCH_MAX_TOTAL_UPLOAD_SIZE_BYTES,
    DEFAULT_BATCH_SNAPSHOT_DIR,
    DEFAULT_BATCH_SNAPSHOT_RETENTION_DAYS,
    DEFAULT_BATCH_SNAPSHOT_ORPHAN_GRACE_SECONDS,
    get_settings,
)
from app.services.unittest_uploads import normalize_source_name


_UPLOAD_CHUNK_SIZE = 1024 * 1024
_STAGING_PREFIX = ".staging-"


class BatchInputError(ValueError):
    """A stable Batch API business error produced by input snapshot handling."""

    def __init__(self, code: str, http_status: int, message: str = "") -> None:
        self.code = code
        self.error_code = code
        self.http_status = http_status
        self.status_code = http_status
        self.message = message
        self.detail = f"{code}: {message}" if message else code
        super().__init__(self.detail)


class SnapshotInvalidError(BatchInputError):
    """Raised when a persisted Item snapshot cannot be trusted."""

    def __init__(self, message: str = "Snapshot content is invalid") -> None:
        # SNAPSHOT_INVALID is an Item runtime reason, not an HTTP endpoint error.
        # 500 remains useful for callers that surface an unexpected direct read.
        super().__init__("SNAPSHOT_INVALID", 500, message)


@dataclass(frozen=True, slots=True)
class BatchInputItem:
    """Metadata needed to create one BatchItem row."""

    item_id: str
    sequence: int
    filename: str
    source_path: str
    relative_path: str
    snapshot_path: str
    size: int
    content_hash: str


@dataclass(frozen=True, slots=True)
class BatchInputBatch:
    """A finalized immutable upload snapshot ready for a database transaction."""

    batch_task_id: str
    project_root: str
    items: tuple[BatchInputItem, ...]

    @property
    def snapshot_dir(self) -> str:
        """Return the common finalized batch directory."""

        if self.items:
            return str(Path(self.items[0].snapshot_path).parents[2])
        return ""


# Names used by early implementation-plan drafts remain import-compatible.
BatchInputSnapshot = BatchInputBatch
BatchInputSnapshotItem = BatchInputItem


@dataclass(frozen=True, slots=True)
class _ValidatedInput:
    upload: Any
    filename: str
    source_path: Path
    source_path_text: str
    relative_path: str


class BatchInputStore:
    """Validate uploads and atomically publish per-batch input snapshots."""

    def __init__(
        self,
        snapshot_root: str | os.PathLike[str] | None = None,
        *,
        settings: Any | None = None,
        project_root_resolver: Callable[[str], str | None] | None = None,
        chunk_size: int = _UPLOAD_CHUNK_SIZE,
    ) -> None:
        settings = settings or get_settings()
        configured_root = snapshot_root
        if configured_root is None:
            configured_root = getattr(
                settings, "BATCH_SNAPSHOT_DIR", DEFAULT_BATCH_SNAPSHOT_DIR
            )

        self.snapshot_root = Path(configured_root).expanduser().resolve()
        self.max_files = int(
            getattr(settings, "BATCH_MAX_FILES", DEFAULT_BATCH_MAX_FILES)
        )
        self.max_file_size = int(
            getattr(
                settings,
                "BATCH_MAX_FILE_SIZE_BYTES",
                DEFAULT_BATCH_MAX_FILE_SIZE_BYTES,
            )
        )
        self.max_total_size = int(
            getattr(
                settings,
                "BATCH_MAX_TOTAL_UPLOAD_SIZE_BYTES",
                DEFAULT_BATCH_MAX_TOTAL_UPLOAD_SIZE_BYTES,
            )
        )
        self.orphan_grace_seconds = int(
            getattr(
                settings,
                "BATCH_SNAPSHOT_ORPHAN_GRACE_SECONDS",
                DEFAULT_BATCH_SNAPSHOT_ORPHAN_GRACE_SECONDS,
            )
        )
        # Committed snapshots are retained for a bounded period after a
        # terminal batch completes.  Startup cleanup receives the set of
        # terminal batch IDs from the database and uses this value to remove
        # only those finalized directories; queued/running snapshots are
        # never eligible for retention cleanup.
        self.retention_days = int(
            getattr(
                settings,
                "BATCH_SNAPSHOT_RETENTION_DAYS",
                DEFAULT_BATCH_SNAPSHOT_RETENTION_DAYS,
            )
        )
        if project_root_resolver is None:
            from app.agents.impl.unittest.paths import find_project_root_for_source

            project_root_resolver = find_project_root_for_source
        self._project_root_resolver = project_root_resolver
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        self._chunk_size = int(chunk_size)

    async def validate_and_stage(
        self,
        files: Sequence[Any],
        source_paths_json: str,
        batch_task_id: str | None = None,
        *,
        source_mode: str = "project",
    ) -> BatchInputBatch:
        """Validate, stage, hash and atomically finalize all uploaded files."""

        uploads = list(files or [])
        if not uploads:
            raise BatchInputError(
                "BATCH_TASK_EMPTY", 400, "At least one non-empty file is required"
            )
        if len(uploads) > self.max_files:
            raise BatchInputError(
                "BATCH_PAYLOAD_TOO_LARGE",
                413,
                f"File count exceeds the configured limit of {self.max_files}",
            )

        source_paths = self._parse_source_paths(source_paths_json, len(uploads))
        normalized_batch_id = self._batch_id(batch_task_id)
        if source_mode == "upload":
            project_root = self.snapshot_root / normalized_batch_id / "project"
            validated = self._validate_upload_metadata(uploads, source_paths, project_root)
        elif source_mode == "project":
            validated, project_root = self._validate_metadata(uploads, source_paths)
        else:
            raise BatchInputError("BATCH_SOURCE_PATH_INVALID", 422, "Unsupported source mode")

        staging_dir: Path | None = None
        finalized = False
        try:
            self.snapshot_root.mkdir(parents=True, exist_ok=True)
            staging_dir = self.snapshot_root / (
                f"{_STAGING_PREFIX}{normalized_batch_id}-{uuid.uuid4().hex}"
            )
            staging_dir.mkdir(exist_ok=False)
            if source_mode == "upload":
                await asyncio.to_thread(_initialize_upload_project, staging_dir / "project")

            staged_items: list[tuple[str, _ValidatedInput, int, str]] = []
            total_size = 0
            for sequence, validated_item in enumerate(validated):
                item_id = str(uuid.uuid4())
                content_path = staging_dir / "items" / item_id / "content.bin"
                content_path.parent.mkdir(parents=True, exist_ok=False)
                size, content_hash = await self._write_upload(
                    validated_item.upload,
                    content_path,
                    current_total=total_size,
                )
                total_size += size
                if source_mode == "upload":
                    target = staging_dir / "project" / validated_item.relative_path
                    await asyncio.to_thread(_copy_uploaded_source, content_path, target)
                staged_items.append(
                    (item_id, validated_item, size, content_hash)
                )

            final_dir = self.snapshot_root / normalized_batch_id
            if final_dir.exists() or final_dir.is_symlink():
                raise BatchInputError(
                    "BATCH_SNAPSHOT_FAILED",
                    500,
                    "A snapshot already exists for this batch ID",
                )
            await _atomic_replace_directory(staging_dir, final_dir)
            finalized = True

            items = tuple(
                BatchInputItem(
                    item_id=item_id,
                    sequence=sequence,
                    filename=validated_item.filename,
                    source_path=validated_item.source_path_text,
                    relative_path=validated_item.relative_path,
                    snapshot_path=str(
                        final_dir / "items" / item_id / "content.bin"
                    ),
                    size=size,
                    content_hash=content_hash,
                )
                for sequence, (
                    item_id,
                    validated_item,
                    size,
                    content_hash,
                ) in enumerate(staged_items)
            )
            return BatchInputBatch(
                batch_task_id=normalized_batch_id,
                project_root=_normalized_path_text(project_root),
                items=items,
            )
        except BatchInputError:
            raise
        except (OSError, TypeError, ValueError) as exc:
            raise BatchInputError(
                "BATCH_SNAPSHOT_FAILED", 500, "Unable to persist upload snapshot"
            ) from exc
        finally:
            if staging_dir is not None and not finalized:
                _remove_path(staging_dir)

    async def create_snapshot(
        self,
        files: Sequence[Any],
        source_paths_json: str,
        batch_task_id: str | None = None,
    ) -> BatchInputBatch:
        """Compatibility alias for :meth:`validate_and_stage`."""

        return await self.validate_and_stage(
            files, source_paths_json, batch_task_id=batch_task_id
        )

    def read_snapshot(
        self,
        path_or_item: str | os.PathLike[str] | BatchInputItem | Any,
        expected_hash: str | None = None,
        *,
        expected_size: int | None = None,
    ) -> bytes:
        """Read an Item snapshot and verify available size/hash metadata."""

        path_value = getattr(path_or_item, "snapshot_path", path_or_item)
        if expected_hash is None:
            expected_hash = getattr(path_or_item, "content_hash", None)
        if expected_size is None:
            expected_size = getattr(path_or_item, "size", None)

        try:
            path = Path(path_value)
        except (TypeError, ValueError) as exc:
            raise SnapshotInvalidError("Snapshot path is invalid") from exc

        # A database row is not a capability to read arbitrary local files.
        # Require the immutable batch/item/content.bin layout before touching disk.
        try:
            root = self.snapshot_root.resolve(strict=False)
            candidate = Path(os.path.abspath(os.path.normpath(str(path.expanduser()))))
            relative = candidate.relative_to(root)
            expected_item = getattr(path_or_item, "item_id", None)
            expected_batch = getattr(path_or_item, "batch_task_id", None)
            if expected_batch is not None and expected_item is not None:
                expected_parts = (str(expected_batch), "items", str(expected_item), "content.bin")
                if tuple(relative.parts) != expected_parts:
                    raise SnapshotInvalidError("Snapshot path identity is invalid")
            elif len(relative.parts) != 4 or relative.parts[1] != "items" or relative.parts[3] != "content.bin":
                raise SnapshotInvalidError("Snapshot path identity is invalid")

            # ``candidate.is_symlink()`` below only protects the final file.
            # A database path can still traverse an intermediate symlink such
            # as ``<batch>/items/<item> -> external-dir``.  Inspect every
            # component beneath the trusted root before touching the file so
            # snapshots remain an immutable, root-confined capability.
            cursor = root
            for part in relative.parts:
                cursor = cursor / part
                if cursor.is_symlink():
                    raise SnapshotInvalidError("Snapshot path contains an unsafe symlink")
        except (ValueError, OSError) as exc:
            raise SnapshotInvalidError("Snapshot path is outside snapshot root") from exc

        try:
            if candidate.is_symlink() or not candidate.is_file():
                raise SnapshotInvalidError("Snapshot file is missing or unsafe")
            content = candidate.read_bytes()
        except SnapshotInvalidError:
            raise
        except (OSError, PermissionError) as exc:
            raise SnapshotInvalidError("Snapshot file cannot be read") from exc

        if expected_size is not None:
            try:
                normalized_size = int(expected_size)
            except (TypeError, ValueError) as exc:
                raise SnapshotInvalidError("Snapshot size metadata is invalid") from exc
            if len(content) != normalized_size:
                raise SnapshotInvalidError("Snapshot size verification failed")

        if expected_hash is not None:
            actual_hash = hashlib.sha256(content).hexdigest()
            if actual_hash.casefold() != str(expected_hash).strip().casefold():
                raise SnapshotInvalidError("Snapshot hash verification failed")

        return content

    def cleanup_snapshot(self, snapshot: Any) -> bool:
        """Remove one finalized batch snapshot after a database rollback."""

        target = self._resolve_batch_directory(snapshot)
        if target is None or not _is_direct_child(target, self.snapshot_root):
            return False
        existed = target.exists() or target.is_symlink()
        if existed:
            _remove_path(target)
        return existed and not target.exists() and not target.is_symlink()

    def cleanup_orphans(
        self,
        referenced_ids: Iterable[str],
        now: datetime | float | int | None = None,
    ) -> list[Path]:
        """Delete stale staging/final directories without a database owner."""

        if not self.snapshot_root.is_dir():
            return []

        referenced = {
            str(getattr(value, "batch_task_id", getattr(value, "id", value))).casefold()
            for value in referenced_ids
        }
        current_time = _timestamp(now)
        removed: list[Path] = []

        try:
            candidates = list(self.snapshot_root.iterdir())
        except OSError:
            return []

        for candidate in candidates:
            try:
                if not candidate.is_dir() and not candidate.is_symlink():
                    continue
                is_staging = candidate.name.startswith(_STAGING_PREFIX)
                is_referenced = candidate.name.casefold() in referenced
                if not is_staging and is_referenced:
                    continue
                age = current_time - candidate.lstat().st_mtime
                if age < self.orphan_grace_seconds:
                    continue
                _remove_path(candidate)
                if not candidate.exists() and not candidate.is_symlink():
                    removed.append(candidate)
            except OSError:
                # Startup cleanup is best effort; one locked path must not prevent
                # processing the rest of the snapshot root.
                continue
        return removed

    def cleanup_expired(
        self,
        terminal_ids: Iterable[str],
        now: datetime | float | int | None = None,
        *,
        retention_days: int | None = None,
    ) -> list[Path]:
        """Remove finalized snapshots whose terminal owners exceeded retention.

        ``cleanup_orphans`` intentionally preserves every directory that still
        has a database owner.  This companion operation is called only with
        IDs of terminal ``BatchTask`` rows, so a queued/running batch can never
        be removed by age alone.  Directory mtime is the snapshot publication
        timestamp and is used as a conservative lower bound: if a deployment
        copies a snapshot and refreshes its mtime, cleanup simply defers until
        the next pass rather than risking an early deletion.

        The method is synchronous like ``cleanup_orphans`` so startup callers
        can run both operations in one worker thread without holding a DB
        transaction while deleting files.
        """

        if not self.snapshot_root.is_dir():
            return []

        terminal = {
            str(getattr(value, "batch_task_id", getattr(value, "id", value))).casefold()
            for value in terminal_ids
        }
        if not terminal:
            return []

        try:
            days = self.retention_days if retention_days is None else int(retention_days)
        except (TypeError, ValueError):
            days = self.retention_days
        # A negative retention would make every terminal snapshot immediately
        # eligible.  Settings validation prevents this in production, but the
        # explicit clamp keeps direct/test callers fail-safe.
        days = max(1, days)
        cutoff = _timestamp(now) - days * 24 * 60 * 60
        removed: list[Path] = []

        try:
            candidates = list(self.snapshot_root.iterdir())
        except OSError:
            return []

        for candidate in candidates:
            try:
                # Staging directories are governed by orphan grace, not
                # terminal retention.  ``cleanup_orphans`` handles them.
                if (
                    candidate.name.startswith(_STAGING_PREFIX)
                    or candidate.name.casefold() not in terminal
                    or not candidate.is_dir()
                    or candidate.is_symlink()
                ):
                    continue
                if candidate.stat().st_mtime >= cutoff:
                    continue
                _remove_path(candidate)
                if not candidate.exists() and not candidate.is_symlink():
                    removed.append(candidate)
            except OSError:
                # Retention is maintenance work; a locked directory must not
                # prevent the rest of startup from completing.
                continue
        return removed

    def _parse_source_paths(
        self, source_paths_json: str, upload_count: int
    ) -> list[str]:
        try:
            decoded = json.loads(source_paths_json)
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise BatchInputError(
                "BATCH_FILE_PATHS_MISMATCH",
                400,
                "source_paths_json must be a JSON array",
            ) from exc

        if (
            not isinstance(decoded, list)
            or len(decoded) != upload_count
            or any(not isinstance(path, str) or not path.strip() for path in decoded)
        ):
            raise BatchInputError(
                "BATCH_FILE_PATHS_MISMATCH",
                400,
                "source_paths_json must contain one path per uploaded file",
            )
        return decoded

    def _validate_metadata(
        self, uploads: Sequence[Any], source_paths: Sequence[str]
    ) -> tuple[list[_ValidatedInput], Path]:
        validated: list[_ValidatedInput] = []
        seen_paths: set[str] = set()
        project_root: Path | None = None
        project_root_key: str | None = None

        for sequence, (upload, raw_source_path) in enumerate(
            zip(uploads, source_paths)
        ):
            filename = self._validate_filename(getattr(upload, "filename", None))
            source_path = self._validate_source_path(raw_source_path, sequence)

            if not _path_component_equal(filename, source_path.name):
                raise BatchInputError(
                    "BATCH_SOURCE_PATH_INVALID",
                    422,
                    f"Source path does not match uploaded filename at index {sequence}",
                )

            source_key = _canonical_path_key(source_path)
            if source_key in seen_paths:
                raise BatchInputError(
                    "BATCH_SOURCE_PATH_INVALID",
                    422,
                    "Duplicate normalized source paths are not allowed",
                )
            seen_paths.add(source_key)

            try:
                resolved_root = self._project_root_resolver(str(source_path))
            except (OSError, RuntimeError, ValueError) as exc:
                raise BatchInputError(
                    "BATCH_PROJECT_ROOT_UNRESOLVABLE",
                    422,
                    f"Project root cannot be resolved for item {sequence}",
                ) from exc
            if not resolved_root:
                raise BatchInputError(
                    "BATCH_PROJECT_ROOT_UNRESOLVABLE",
                    422,
                    f"Project root cannot be resolved for item {sequence}",
                )

            try:
                item_root = Path(resolved_root).expanduser().resolve(strict=True)
            except (OSError, RuntimeError, ValueError) as exc:
                raise BatchInputError(
                    "BATCH_PROJECT_ROOT_UNRESOLVABLE",
                    422,
                    f"Project root cannot be resolved for item {sequence}",
                ) from exc
            if not item_root.is_dir():
                raise BatchInputError(
                    "BATCH_PROJECT_ROOT_UNRESOLVABLE",
                    422,
                    f"Project root is invalid for item {sequence}",
                )

            root_key = _canonical_path_key(item_root)
            if project_root is None:
                project_root = item_root
                project_root_key = root_key
            elif root_key != project_root_key:
                raise BatchInputError(
                    "BATCH_FILES_NOT_IN_SAME_PROJECT",
                    422,
                    "All uploaded files must belong to one project",
                )

            try:
                relative_path = source_path.relative_to(item_root).as_posix()
            except ValueError as exc:
                raise BatchInputError(
                    "BATCH_PROJECT_ROOT_UNRESOLVABLE",
                    422,
                    f"Resolved root does not contain item {sequence}",
                ) from exc

            validated.append(
                _ValidatedInput(
                    upload=upload,
                    filename=filename,
                    source_path=source_path,
                    source_path_text=_normalized_path_text(source_path),
                    relative_path=relative_path,
                )
            )

        if project_root is None:  # Guarded by the non-empty upload check.
            raise BatchInputError("BATCH_TASK_EMPTY", 400)
        return validated, project_root

    def _validate_upload_metadata(
        self, uploads: Sequence[Any], source_paths: Sequence[str], project_root: Path,
    ) -> list[_ValidatedInput]:
        """Map browser-relative names into a private, batch-owned workspace."""
        validated: list[_ValidatedInput] = []
        seen_paths: set[str] = set()
        for upload, raw_path in zip(uploads, source_paths, strict=True):
            filename = self._validate_filename(getattr(upload, "filename", None))
            try:
                relative_path = normalize_source_name(raw_path)
                if "\x00" in relative_path or Path(relative_path).name != filename:
                    raise ValueError("Upload path does not match its filename")
                source_path = project_root / relative_path
                if not source_path.resolve().is_relative_to(project_root.resolve()):
                    raise ValueError("Upload path escapes its workspace")
            except (OSError, RuntimeError, ValueError) as exc:
                raise BatchInputError(
                    "BATCH_SOURCE_PATH_INVALID", 422, "Uploaded source paths must be safe relative paths matching each filename",
                ) from exc
            path_key = relative_path.casefold()
            if path_key in seen_paths:
                raise BatchInputError("BATCH_SOURCE_PATH_INVALID", 422, "Duplicate uploaded source paths are not allowed")
            seen_paths.add(path_key)
            validated.append(_ValidatedInput(
                upload=upload, filename=filename, source_path=source_path,
                source_path_text=_normalized_path_text(source_path), relative_path=relative_path,
            ))
        return validated

    @staticmethod
    def _validate_filename(raw_filename: Any) -> str:
        if (
            not isinstance(raw_filename, str)
            or not raw_filename
            or len(raw_filename) > 255
            or "\x00" in raw_filename
            or "/" in raw_filename
            or "\\" in raw_filename
            or raw_filename in {".", ".."}
        ):
            raise BatchInputError(
                "BATCH_SOURCE_PATH_INVALID", 422, "Upload filename is invalid"
            )

        extension = Path(raw_filename).suffix.casefold()
        if extension not in BATCH_ALLOWED_EXTENSIONS:
            raise BatchInputError(
                "BATCH_FILE_TYPE_UNSUPPORTED",
                400,
                "Batch uploads support only .c and .cpp files",
            )
        return raw_filename

    @staticmethod
    def _validate_source_path(raw_path: str, sequence: int) -> Path:
        if "\x00" in raw_path:
            raise BatchInputError(
                "BATCH_SOURCE_PATH_INVALID",
                422,
                f"Source path is invalid at index {sequence}",
            )
        try:
            candidate = Path(raw_path).expanduser()
            if not candidate.is_absolute():
                raise ValueError("path is not absolute")
            if _contains_symlink_component(candidate):
                raise ValueError("symbolic links are not accepted")
            normalized = candidate.resolve(strict=True)
            if not normalized.is_file():
                raise ValueError("path is not a regular file")
        except (OSError, RuntimeError, ValueError) as exc:
            raise BatchInputError(
                "BATCH_SOURCE_PATH_INVALID",
                422,
                f"Source path is invalid at index {sequence}",
            ) from exc
        return normalized

    async def _write_upload(
        self,
        upload: Any,
        destination: Path,
        *,
        current_total: int,
    ) -> tuple[int, str]:
        reader = getattr(upload, "read", None)
        if not callable(reader):
            raise BatchInputError(
                "BATCH_SNAPSHOT_FAILED", 500, "Uploaded file cannot be read"
            )

        size = 0
        digest = hashlib.sha256()
        accepts_size = True
        try:
            with destination.open("xb") as output:
                while True:
                    try:
                        value = reader(self._chunk_size) if accepts_size else reader()
                    except TypeError:
                        if not accepts_size:
                            raise
                        accepts_size = False
                        value = reader()
                    chunk = await value if inspect.isawaitable(value) else value
                    if not isinstance(chunk, (bytes, bytearray, memoryview)):
                        raise TypeError("upload read() must return bytes")
                    chunk = bytes(chunk)
                    if not chunk:
                        break

                    size += len(chunk)
                    if size > self.max_file_size:
                        raise BatchInputError(
                            "BATCH_PAYLOAD_TOO_LARGE",
                            413,
                            "An uploaded file exceeds the configured size limit",
                        )
                    if current_total + size > self.max_total_size:
                        raise BatchInputError(
                            "BATCH_PAYLOAD_TOO_LARGE",
                            413,
                            "The batch exceeds the configured total size limit",
                        )
                    output.write(chunk)
                    digest.update(chunk)
                    if not accepts_size:
                        break
                output.flush()
                os.fsync(output.fileno())
        except BatchInputError:
            raise
        except (OSError, TypeError, ValueError) as exc:
            raise BatchInputError(
                "BATCH_SNAPSHOT_FAILED", 500, "Unable to persist uploaded content"
            ) from exc

        if size == 0:
            raise BatchInputError(
                "BATCH_TASK_EMPTY", 400, "Uploaded files must not be empty"
            )
        return size, digest.hexdigest()

    @staticmethod
    def _batch_id(batch_task_id: str | None) -> str:
        if batch_task_id is None:
            return str(uuid.uuid4())
        if not isinstance(batch_task_id, str):
            raise BatchInputError(
                "BATCH_SNAPSHOT_FAILED", 500, "Batch ID is invalid for snapshot storage"
            )
        try:
            parsed = uuid.UUID(batch_task_id)
        except (ValueError, AttributeError) as exc:
            raise BatchInputError(
                "BATCH_SNAPSHOT_FAILED", 500, "Batch ID is invalid for snapshot storage"
            ) from exc
        if parsed.version != 4 or str(parsed) != batch_task_id:
            raise BatchInputError(
                "BATCH_SNAPSHOT_FAILED", 500, "Batch ID is invalid for snapshot storage"
            )
        return batch_task_id

    def _resolve_batch_directory(self, snapshot: Any) -> Path | None:
        if isinstance(snapshot, BatchInputBatch):
            return self._directory_for_batch_id(snapshot.batch_task_id)
        if isinstance(snapshot, BatchInputItem) or hasattr(snapshot, "snapshot_path"):
            value = getattr(snapshot, "snapshot_path", None)
        elif hasattr(snapshot, "batch_task_id"):
            return self._directory_for_batch_id(getattr(snapshot, "batch_task_id"))
        else:
            value = snapshot

        if value is None:
            return None
        try:
            path = Path(value)
        except (TypeError, ValueError):
            return None
        if not path.is_absolute() and len(path.parts) == 1:
            return self._directory_for_batch_id(str(path))
        if not path.is_absolute():
            return None

        # Normalize lexically without following a possibly hostile batch
        # directory symlink.  The returned target is always the first direct
        # child of snapshot_root, so cleanup can unlink that symlink itself
        # without traversing into its destination.
        absolute = Path(os.path.abspath(os.path.normpath(str(path.expanduser()))))
        try:
            relative = absolute.relative_to(self.snapshot_root)
        except ValueError:
            return None
        if not relative.parts:
            return None
        return self.snapshot_root / relative.parts[0]

    def _directory_for_batch_id(self, value: Any) -> Path | None:
        try:
            batch_id = self._batch_id(value)
        except BatchInputError:
            return None
        return self.snapshot_root / batch_id


async def validate_and_stage(
    files: Sequence[Any],
    source_paths_json: str,
    batch_task_id: str | None = None,
    *,
    store: BatchInputStore | None = None,
) -> BatchInputBatch:
    """Create a snapshot using an explicit store or current configuration."""

    return await (store or BatchInputStore()).validate_and_stage(
        files, source_paths_json, batch_task_id=batch_task_id
    )


async def create_snapshot(
    files: Sequence[Any],
    source_paths_json: str,
    batch_task_id: str | None = None,
    *,
    store: BatchInputStore | None = None,
) -> BatchInputBatch:
    """Module-level compatibility alias for snapshot creation."""

    return await validate_and_stage(
        files,
        source_paths_json,
        batch_task_id=batch_task_id,
        store=store,
    )


def read_snapshot(
    path_or_item: Any,
    expected_hash: str | None = None,
    *,
    expected_size: int | None = None,
    store: BatchInputStore | None = None,
) -> bytes:
    """Read and verify a snapshot using an explicit or configured store."""

    return (store or BatchInputStore()).read_snapshot(
        path_or_item, expected_hash, expected_size=expected_size
    )


def cleanup_snapshot(
    snapshot: Any, *, store: BatchInputStore | None = None
) -> bool:
    """Remove one batch snapshot using an explicit or configured store."""

    return (store or BatchInputStore()).cleanup_snapshot(snapshot)


def cleanup_orphans(
    referenced_ids: Iterable[str],
    now: datetime | float | int | None = None,
    *,
    store: BatchInputStore | None = None,
) -> list[Path]:
    """Remove stale unreferenced snapshots using current configuration."""

    return (store or BatchInputStore()).cleanup_orphans(referenced_ids, now=now)


def _canonical_path_key(path: Path) -> str:
    normalized = os.path.normcase(os.path.normpath(str(path)))
    return normalized.casefold() if os.name == "nt" else normalized


def _initialize_upload_project(project_root: Path) -> None:
    """Mark the upload workspace so root discovery cannot reach the host app."""
    project_root.mkdir(mode=0o700)
    (project_root / ".unittest-upload.json").write_text('{"source_mode":"upload"}', encoding="utf-8")


def _copy_uploaded_source(snapshot_path: Path, target: Path) -> None:
    """Keep mutable source files separate from the immutable input snapshot."""
    target.parent.mkdir(parents=True, exist_ok=True)
    with snapshot_path.open("rb") as source, target.open("xb") as destination:
        shutil.copyfileobj(source, destination)


def _normalized_path_text(path: Path) -> str:
    normalized = os.path.normpath(str(path))
    if os.name == "nt":
        drive, tail = os.path.splitdrive(normalized)
        if drive:
            normalized = drive.upper() + tail
    return normalized


def _path_component_equal(left: str, right: str) -> bool:
    if os.name == "nt":
        return left.casefold() == right.casefold()
    return left == right


def _contains_symlink_component(path: Path) -> bool:
    """Return True if any existing lexical component of *path* is a symlink."""

    current = Path(path.anchor)
    parts = path.parts[1:] if path.anchor else path.parts
    for part in parts:
        if part in {"", "."}:
            continue
        if part == "..":
            current = current.parent
            continue
        current = current / part
        if current.is_symlink():
            return True
    return False


async def _atomic_replace_directory(source: Path, destination: Path) -> None:
    """Atomically rename a directory, tolerating brief Windows sharing locks."""

    for attempt in range(5):
        try:
            os.replace(source, destination)
            return
        except PermissionError:
            if attempt == 4:
                raise
            await asyncio.sleep(0.01 * (2**attempt))


def _is_direct_child(path: Path, root: Path) -> bool:
    try:
        return path.parent.resolve(strict=False) == root.resolve(strict=False)
    except (OSError, RuntimeError):
        return False


def _remove_path(path: Path) -> None:
    if path.is_symlink():
        path.unlink(missing_ok=True)
    elif path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def _timestamp(value: datetime | float | int | None) -> float:
    if value is None:
        return time.time()
    if isinstance(value, datetime):
        return value.timestamp()
    return float(value)


__all__ = [
    "BatchInputBatch",
    "BatchInputError",
    "BatchInputItem",
    "BatchInputSnapshot",
    "BatchInputSnapshotItem",
    "BatchInputStore",
    "SnapshotInvalidError",
    "cleanup_orphans",
    "cleanup_snapshot",
    "create_snapshot",
    "read_snapshot",
    "validate_and_stage",
]
