"""Balance billing service: pre-call gating and post-call usage deduction.

This module is the single billing policy entry point:

- :func:`ensure_sufficient_balance` is awaited by the chat / agent / image
  endpoints before any LLM work starts, raising ``402`` when the caller is
  not allowed to consume LLM quota.
- :meth:`BillingService.handle_usage_event` is registered on ``LLMBridge``
  as the usage hook (wired in ``main.py`` lifespan) and deducts the priced
  cost of every completed provider call.

Both entry points open their own short database sessions via
``async_session_factory`` because usage events fire from detached background
generation tasks whose request-scoped session is already closed, and several
gated endpoints resolve the user without holding a request-scoped session.

Overdraft is by design: a deduction always completes (the balance may go
slightly negative) and the *next* request is blocked by the pre-check.
Every billing failure is logged and swallowed - billing must never break or
block generation.
"""

from __future__ import annotations

from typing import Any, Optional
from uuid import uuid4

from fastapi import HTTPException
from loguru import logger

from app.core.billing_context import get_billing_user_id
from app.core.config import get_settings
from app.core.database import async_session_factory
from app.models.balance_transaction import TransactionType
from app.repositories.balance_transaction import BalanceTransactionRepository
from app.repositories.user import UserRepository
from app.services.payment import payment_config_service

# Unauthenticated identities used by the optional-user helpers in
# app.core.security (plain fallbacks plus the signed guest prefix).
_GUEST_USER_IDS = frozenset({"guest", "anonymous"})
_GUEST_ID_PREFIX = "g-"

_INSUFFICIENT_BALANCE_DETAIL = (
    "Insufficient balance. Please sign in and recharge."
)


def _is_guest_id(user_id: Optional[str]) -> bool:
    """Return True when the id represents an unauthenticated caller."""
    if not user_id:
        return True
    return user_id in _GUEST_USER_IDS or user_id.startswith(_GUEST_ID_PREFIX)


class BillingService:
    """Implements the balance billing policy (gate + deduct)."""

    # ========== Pre-call gate ==========

    async def ensure_sufficient_balance(
        self, current_user: Optional[dict]
    ) -> None:
        """Raise ``402`` when the caller may not start billable LLM work.

        Policy (all no-ops while ``BILLING_ENABLED`` is false):

        - guests are rejected unless ``BILLING_GUEST_ALLOWED``;
        - administrators are exempt;
        - signed-in users need a strictly positive balance.

        Args:
            current_user: The optional-user dict resolved by the endpoint
                (``{"id": ..., "username": ...}``), or ``None``.
        """
        settings = get_settings()
        if not settings.BILLING_ENABLED:
            return

        user_id = (current_user or {}).get("id")
        if _is_guest_id(user_id):
            if not settings.BILLING_GUEST_ALLOWED:
                raise HTTPException(
                    status_code=402,
                    detail=_INSUFFICIENT_BALANCE_DETAIL,
                )
            return

        user = await self._load_user(str(user_id))
        if user is None:
            # A bearer identity without a matching user row has no balance
            # to spend; block it like an empty account.
            logger.warning(f"Billing pre-check blocked unknown user id {user_id!r}")
            raise HTTPException(
                status_code=402,
                detail=_INSUFFICIENT_BALANCE_DETAIL,
            )
        if user.is_admin:
            return
        if (user.balance or 0.0) <= 0:
            raise HTTPException(
                status_code=402,
                detail=_INSUFFICIENT_BALANCE_DETAIL,
            )

    # ========== Usage deduction ==========

    async def handle_usage_event(
        self,
        provider: Optional[str],
        model: Optional[str],
        usage: Any,
    ) -> None:
        """Persist a price snapshot and actual debit in one transaction.

        Usage remains visible when billing is disabled, the caller is a
        guest, or prices are missing. Database errors are logged and never
        interrupt generation. No prompts, responses, or raw errors are saved.
        """
        from app.core.task_context import get_current_task_id
        from app.core.usage_context import usage_context
        from app.models.llm_usage import LLMUsageLog
        from app.models.task import Task
        from app.services.model_catalog_service import resolve_pricing
        from app.services.usage_pricing import calculate_cost, normalize_usage
        import json

        try:
            counts, metadata = normalize_usage(usage)
            context = usage_context.get()
            user_id = context.get("user_id") or get_billing_user_id()
            task_id = context.get("workflow_id") or get_current_task_id()
            pricing_provider = metadata.get("pricing_provider") or provider or "unknown"
            async with async_session_factory() as session:
                task = await session.get(Task, task_id) if task_id else None
                if task:
                    user_id = task.user_id
                pricing = await resolve_pricing(session, pricing_provider, model or "unknown")
                settings = get_settings()
                snapshot = {**(pricing or {}), "usd_to_cny_rate": settings.USD_TO_CNY_RATE,
                            "billing_enabled": settings.BILLING_ENABLED}
                cost_usd = calculate_cost(counts, pricing)
                if not settings.BILLING_ENABLED:
                    snapshot['billing_status'] = 'billing_disabled'
                elif _is_guest_id(user_id):
                    snapshot['billing_status'] = 'guest'
                elif counts['usage_source'] in {'estimated', 'unavailable'}:
                    snapshot['billing_status'] = f"{counts['usage_source']}_usage"
                elif pricing is None:
                    snapshot['billing_status'] = 'unpriced'
                elif cost_usd <= 0:
                    snapshot['billing_status'] = 'zero_cost'
                else:
                    snapshot['billing_status'] = 'account_unavailable'
                row = LLMUsageLog(
                    id=str(uuid4()), user_id=user_id,
                    workflow_id=task_id,
                    session_id=context.get("session_id") or (task.session_id if task else None),
                    agent_name=context.get("agent_name") or (task.agent_type if task else "unknown"),
                    provider=pricing_provider, model=model or "unknown",
                    **counts, cost_usd=cost_usd, charged_cny=0,
                    status="failed" if metadata.get("status") == "failed" else "completed",
                    pricing_source=pricing["source"] if pricing else "unpriced",
                    pricing_snapshot=None,
                )
                session.add(row)
                # Estimates are visible in statistics but never debited. A failed
                # CLI may still have real, billable provider usage.
                if (settings.BILLING_ENABLED and not _is_guest_id(user_id)
                        and counts["usage_source"] == "reported" and cost_usd > 0):
                    user_repo = UserRepository(session)
                    user = await user_repo.get_by_id(str(user_id))
                    if user is not None:
                        charge = round(cost_usd * settings.USD_TO_CNY_RATE, 4)
                        snapshot['charge_before_discount_cny'] = charge
                        charge = await self._apply_level_discount(session, user, charge, snapshot=snapshot)
                        snapshot['billing_status'] = 'charged' if charge > 0 else 'below_minimum_charge'
                        if charge > 0:
                            refreshed = await user_repo.add_balance(str(user_id), -charge)
                            row.charged_cny = charge
                            await BalanceTransactionRepository(session).create_row(
                                user_id=str(user_id), amount=-charge,
                                balance_after=refreshed.balance, type=TransactionType.USAGE,
                                reference_id=row.id, description=f"{pricing_provider}/{model}",
                                model=model, prompt_tokens=counts["prompt_tokens"],
                                completion_tokens=counts["completion_tokens"],
                            )
                row.pricing_snapshot = json.dumps(snapshot)
                await session.commit()
        except Exception:
            logger.exception("Usage recording and billing failed")

    # ========== Internal helpers ==========

    async def _load_user(self, user_id: str):
        """Load a user row in a short independent session."""
        async with async_session_factory() as session:
            return await UserRepository(session).get_by_id(user_id)

    async def _apply_level_discount(
        self, session, user, cost_cny: float, *, snapshot: dict | None = None
    ) -> float:
        """
        Scale the cost by the user's membership-level discount.

        Level lookup failures are logged and charged at full price:
        billing availability outranks discount accuracy.
        """
        if snapshot is not None:
            snapshot['discount_percent'] = 0
        try:
            levels = (await payment_config_service.get_levels(session))["levels"]
        except Exception:
            logger.exception("Failed to load payment levels; charging full price")
            return cost_cny
        level = payment_config_service.level_for_key(
            levels, getattr(user, "level", None) or "default"
        )
        if level is None or level["discount_percent"] <= 0:
            return cost_cny
        if snapshot is not None:
            snapshot['discount_percent'] = level['discount_percent']
        return round(
            cost_cny * (1 - level["discount_percent"] / 100.0), 4
        )

_billing_service: Optional[BillingService] = None


def get_billing_service() -> BillingService:
    """Return the process-wide billing service singleton."""
    global _billing_service
    if _billing_service is None:
        _billing_service = BillingService()
    return _billing_service


async def enforce_billing(current_user: Optional[dict]) -> None:
    """Module-level pre-check wrapper imported by the API endpoints."""
    await get_billing_service().ensure_sufficient_balance(current_user)


__all__ = [
    "BillingService",
    "enforce_billing",
    "get_billing_service",
]
