"""Serialize progress writes and coalesce updates while the database is busy."""

import asyncio

from loguru import logger


class DriverProgressWriter:
    def __init__(self, persist):
        self._persist = persist
        self._latest = None
        self._worker = None
        self.tasks = set()

    def submit(self, update) -> None:
        self._latest = update
        if self._worker is None or self._worker.done():
            self._worker = asyncio.create_task(self._drain())
            self.tasks.add(self._worker)
            self._worker.add_done_callback(self.tasks.discard)

    async def _drain(self) -> None:
        while self._latest is not None:
            update, self._latest = self._latest, None
            try:
                await self._persist(update)
            except Exception as exc:
                logger.warning("Driver progress persistence failed: {}", exc)
