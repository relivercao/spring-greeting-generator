"""
@file driver_repository_service.py
@brief Service for fetching and managing remote git repositories as driver context.

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.

"""
import asyncio
import base64
import os
import shutil
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from loguru import logger

from app.core.config import _BACKEND_DIR
from app.models.driver_agent import DriverRepositoryFetchStatus
from app.repositories.driver_conversation import DriverConversationRepository


# Repository and context limits.
MAX_REPO_FILES = 500
MAX_REPO_METADATA_FILES = 100
MAX_REPOSITORY_FILE_SIZE_BYTES = 5 * 1024 * 1024
MAX_REPOSITORY_SIZE_BYTES = 500 * 1024 * 1024
MAX_GIT_ERROR_CHARS = 500
COMMIT_SHA_LENGTH = 40
GIT_CLONE_TIMEOUT_SECONDS = 300
GIT_CLONE_POLL_INTERVAL_SECONDS = 1.0
ALLOWED_REPOSITORY_SCHEMES = {"https", "ssh"}
DEFAULT_REPOSITORY_WORKSPACE = _BACKEND_DIR / "data" / "repositories" / "driver"

# Supported code extensions for inclusion
CODE_EXTENSIONS = {".c", ".h", ".cpp", ".hpp", ".mk", ".txt", ".md", ".json", ".yaml", ".yml"}


class DriverRepositoryService:
    """Service for fetching remote git repositories and indexing them as driver context."""

    def __init__(
        self,
        repo: DriverConversationRepository,
        workspace_dir: str | Path | None = None,
    ):
        self._repo = repo
        self._workspace_dir = Path(workspace_dir or DEFAULT_REPOSITORY_WORKSPACE).resolve()
        self._workspace_dir.mkdir(parents=True, exist_ok=True)

    async def fetch_repository(
        self,
        user_id: str | None,
        repository_url: str,
        branch: str | None = None,
        selected_paths: list[str] | None = None,
        auth_token: str | None = None,
    ) -> dict[str, Any]:
        """Fetch a remote git repository and index relevant files.

        Args:
            user_id: Optional user identifier.
            repository_url: Git repository URL.
            branch: Branch to checkout (default branch if None).
            selected_paths: Subdirectories to include.
            auth_token: Runtime-only token (NOT persisted).

        Returns:
            Dict with repository source metadata.
        """
        self._validate_repository_url(repository_url)

        # Create repository source record
        repo_source = await self._repo.create_repository_source(
            user_id=user_id,
            repository_url=repository_url,
            branch=branch,
            selected_paths=selected_paths,
        )

        # Update status to fetching
        await self._repo.update_repository_fetch_status(
            source_id=repo_source.id,
            fetch_status=DriverRepositoryFetchStatus.FETCHING.value,
            message="Cloning repository...",
        )

        try:
            # Clone the repository
            clone_dir = self._workspace_dir / repo_source.id
            await self._clone_repo(
                repository_url=repository_url,
                target_dir=clone_dir,
                branch=branch,
                auth_token=auth_token,
            )

            # Get commit SHA
            commit_sha = await self._get_commit_sha(clone_dir)

            # Index files
            included_files = await self._index_files(clone_dir, selected_paths)

            # Update repository source
            await self._repo.update_repository_fetch_status(
                source_id=repo_source.id,
                fetch_status=DriverRepositoryFetchStatus.FETCHED.value,
                workspace_path=str(clone_dir),
                file_count=len(included_files),
                included_files=included_files[:MAX_REPO_METADATA_FILES],
                commit_sha=commit_sha,
                message="Repository code is ready.",
            )

            return {
                "repository_source_id": repo_source.id,
                "repository_url": repository_url,
                "branch": branch or "default",
                "included_paths": selected_paths,
                "file_count": len(included_files),
                "status": DriverRepositoryFetchStatus.FETCHED.value,
                "created_at": repo_source.created_at,
            }

        except asyncio.CancelledError:
            self._remove_clone_dir(clone_dir)
            raise
        except Exception as e:
            logger.error(f"Repository fetch failed: {e}")
            self._remove_clone_dir(clone_dir)
            await self._repo.update_repository_fetch_status(
                source_id=repo_source.id,
                fetch_status=DriverRepositoryFetchStatus.FAILED.value,
                message=f"Fetch failed: {e}",
            )
            return {
                "repository_source_id": repo_source.id,
                "repository_url": repository_url,
                "status": DriverRepositoryFetchStatus.FAILED.value,
                "message": str(e),
                "created_at": repo_source.created_at,
            }

    async def get_repository_files(
        self,
        source_id: str,
        file_paths: list[str] | None = None,
    ) -> list[dict[str, str]]:
        """Read files from a fetched repository.

        Args:
            source_id: Repository source ID.
            file_paths: Specific files to read (all if None).

        Returns:
            List of dicts with path and content.
        """
        repo_source = await self._repo.get_repository_source(source_id)
        if (
            repo_source is None
            or repo_source.fetch_status != DriverRepositoryFetchStatus.FETCHED.value
            or not repo_source.workspace_path
        ):
            return []

        workspace = Path(repo_source.workspace_path).resolve()
        self._ensure_within(self._workspace_dir, workspace)
        if not workspace.exists():
            return []

        results = []
        if file_paths:
            for fp in file_paths:
                full_path = self._resolve_repo_path(workspace, fp)
                if not full_path.exists() or not full_path.is_file():
                    continue
                if full_path.suffix.lower() not in CODE_EXTENSIONS:
                    continue
                if full_path.stat().st_size > MAX_REPOSITORY_FILE_SIZE_BYTES:
                    continue
                results.append({
                    "path": str(full_path.relative_to(workspace)),
                    "content": self._read_text(full_path),
                })
                if len(results) >= MAX_REPO_FILES:
                    break
        else:
            # Read all indexed code files
            for code_file in workspace.rglob("*"):
                if not code_file.is_file() or code_file.suffix.lower() not in CODE_EXTENSIONS:
                    continue
                try:
                    resolved_file = code_file.resolve()
                    self._ensure_within(workspace, resolved_file)
                    if resolved_file.stat().st_size > MAX_REPOSITORY_FILE_SIZE_BYTES:
                        continue
                    rel = str(code_file.relative_to(workspace))
                    results.append({"path": rel, "content": self._read_text(resolved_file)})
                except (OSError, ValueError):
                    continue
                if len(results) >= MAX_REPO_FILES:
                    break

        return results

    async def _clone_repo(
        self,
        repository_url: str,
        target_dir: Path,
        branch: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        """Clone a git repository (shallow clone for efficiency)."""
        target_dir = target_dir.resolve()
        self._ensure_within(self._workspace_dir, target_dir)
        if target_dir.exists() and any(target_dir.iterdir()):
            raise FileExistsError(f"Repository target is not empty: {target_dir}")
        target_dir.mkdir(parents=True, exist_ok=True)

        cmd = ["git", "clone", "--depth", "1"]
        if branch:
            cmd.extend(["--branch", branch])

        clone_url = repository_url
        cmd.extend([clone_url, str(target_dir)])

        # Use a constrained environment. The token is never persisted, logged,
        # or passed as a command-line argument.
        env = {
            key: value
            for key, value in os.environ.items()
            if key
            in {
                "ALLUSERSPROFILE",
                "APPDATA",
                "COMSPEC",
                "HOME",
                "HOMEDRIVE",
                "HOMEPATH",
                "LOCALAPPDATA",
                "PATH",
                "PATHEXT",
                "SYSTEMDRIVE",
                "SYSTEMROOT",
                "TEMP",
                "TMP",
                "USERPROFILE",
                "WINDIR",
            }
        }
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["GIT_CONFIG_NOSYSTEM"] = "1"
        env["GIT_CONFIG_GLOBAL"] = os.devnull
        if auth_token and repository_url.startswith("https://"):
            encoded = base64.b64encode(f"oauth2:{auth_token}".encode("utf-8")).decode("ascii")
            env["GIT_CONFIG_COUNT"] = "1"
            env["GIT_CONFIG_KEY_0"] = "http.extraHeader"
            env["GIT_CONFIG_VALUE_0"] = f"Authorization: Basic {encoded}"

        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        communicate_task = asyncio.create_task(process.communicate())
        started_at = asyncio.get_running_loop().time()
        try:
            while not communicate_task.done():
                if asyncio.get_running_loop().time() - started_at > GIT_CLONE_TIMEOUT_SECONDS:
                    process.kill()
                    await communicate_task
                    raise TimeoutError(
                        f"Git clone exceeded {GIT_CLONE_TIMEOUT_SECONDS} seconds"
                    )
                clone_size = await asyncio.to_thread(self._directory_size_bytes, target_dir)
                if clone_size > MAX_REPOSITORY_SIZE_BYTES:
                    process.kill()
                    await communicate_task
                    raise RuntimeError(
                        f"Repository exceeds the {MAX_REPOSITORY_SIZE_BYTES // (1024 * 1024)} MB limit"
                    )
                await asyncio.sleep(GIT_CLONE_POLL_INTERVAL_SECONDS)
            _, stderr = await communicate_task
            clone_size = await asyncio.to_thread(self._directory_size_bytes, target_dir)
            if clone_size > MAX_REPOSITORY_SIZE_BYTES:
                raise RuntimeError(
                    f"Repository exceeds the {MAX_REPOSITORY_SIZE_BYTES // (1024 * 1024)} MB limit"
                )
        except asyncio.CancelledError:
            if process.returncode is None:
                process.kill()
            await communicate_task
            raise

        if process.returncode != 0:
            error_msg = self._redact_clone_error(
                stderr.decode("utf-8", errors="replace"),
                auth_token,
            )
            raise RuntimeError(f"Git clone failed: {error_msg[:MAX_GIT_ERROR_CHARS]}")

    async def _get_commit_sha(self, repo_dir: Path) -> str | None:
        """Get the current HEAD commit SHA."""
        try:
            process = await asyncio.create_subprocess_exec(
                "git", "rev-parse", "HEAD",
                cwd=str(repo_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await process.communicate()
            if process.returncode == 0:
                return stdout.decode().strip()[:COMMIT_SHA_LENGTH]
        except Exception as exc:
            logger.debug("Could not read repository commit SHA: {}", exc)
        return None

    async def _index_files(
        self,
        repo_dir: Path,
        selected_paths: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Index code files in the repository."""
        files = []

        if selected_paths:
            search_dirs = [self._resolve_repo_path(repo_dir, p) for p in selected_paths]
        else:
            search_dirs = [repo_dir]

        for search_dir in search_dirs:
            if not search_dir.exists():
                continue
            for code_file in search_dir.rglob("*"):
                try:
                    if (
                        not code_file.is_file()
                        or code_file.suffix.lower() not in CODE_EXTENSIONS
                        or code_file.stat().st_size > MAX_REPOSITORY_FILE_SIZE_BYTES
                    ):
                        continue
                    resolved_file = code_file.resolve()
                    self._ensure_within(repo_dir, resolved_file)
                    rel = str(code_file.relative_to(repo_dir))
                    size = resolved_file.stat().st_size
                    files.append({
                        "path": rel,
                        "size": size,
                        "language": self._detect_language(code_file.suffix),
                    })
                except (OSError, ValueError):
                    continue
                if len(files) >= MAX_REPO_FILES:
                    return files

        return files

    def _detect_language(self, ext: str) -> str:
        """Detect programming language from file extension."""
        lang_map = {
            ".c": "c",
            ".h": "c",
            ".cpp": "cpp",
            ".hpp": "cpp",
            ".mk": "makefile",
            ".md": "markdown",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".txt": "text",
        }
        return lang_map.get(ext.lower(), "unknown")

    @staticmethod
    def _validate_repository_url(repository_url: str) -> None:
        """Allow only network Git URLs; reject local paths and embedded credentials."""
        parsed = urlparse(repository_url.strip())
        if parsed.scheme not in ALLOWED_REPOSITORY_SCHEMES or not parsed.hostname:
            raise ValueError("repository_url must be an HTTPS or SSH Git URL")
        if parsed.password or (parsed.scheme == "https" and parsed.username):
            raise ValueError("repository_url must not contain embedded credentials")

    @staticmethod
    def _ensure_within(root: Path, candidate: Path) -> None:
        try:
            candidate.resolve().relative_to(root.resolve())
        except ValueError as exc:
            raise ValueError("Repository path escapes the workspace") from exc

    def _resolve_repo_path(self, workspace: Path, relative_path: str | Path) -> Path:
        raw = str(relative_path).replace("\\", "/")
        candidate_path = Path(raw)
        if candidate_path.is_absolute():
            raise ValueError("Repository paths must be relative")
        candidate = (workspace / candidate_path).resolve()
        self._ensure_within(workspace, candidate)
        return candidate

    @staticmethod
    def _redact_clone_error(error_message: str, auth_token: str | None) -> str:
        """Remove any runtime-only credential representation from Git errors."""
        if not auth_token:
            return error_message
        encoded = base64.b64encode(f"oauth2:{auth_token}".encode("utf-8")).decode("ascii")
        header = f"Authorization: Basic {encoded}"
        redacted = error_message.replace(header, "Authorization: Basic ***")
        redacted = redacted.replace(auth_token, "***")
        redacted = redacted.replace(encoded, "***")
        return redacted

    @staticmethod
    def _read_text(path: Path) -> str:
        return path.read_text(encoding="utf-8", errors="replace")

    @staticmethod
    def _directory_size_bytes(root: Path) -> int:
        total = 0
        if not root.exists():
            return total
        for path in root.rglob("*"):
            try:
                if not path.is_symlink() and path.is_file():
                    total += path.stat().st_size
            except OSError:
                continue
        return total

    def _remove_clone_dir(self, clone_dir: Path) -> None:
        try:
            clone_dir = clone_dir.resolve()
            self._ensure_within(self._workspace_dir, clone_dir)
            if clone_dir.exists():
                shutil.rmtree(clone_dir, ignore_errors=True)
        except (OSError, ValueError) as exc:
            logger.warning("Could not remove failed repository clone {}: {}", clone_dir, exc)
