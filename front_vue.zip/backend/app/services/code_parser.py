"""Structured source-code analysis for Agent input files.

The service prefers the project-local Node parser because it provides the
requested Tree-sitter, Acorn, and JSONC implementations. A conservative
Python fallback keeps uploads useful when optional parser assets are absent.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any


_MAX_ANALYSIS_BYTES = 2 * 1024 * 1024
_PARSER_SCRIPT = Path(__file__).resolve().parents[3] / "tools" / "code_parser.cjs"
_LANGUAGE_BY_EXTENSION = {
    ".c": "c",
    ".h": "c",
    ".cc": "cpp",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".hxx": "cpp",
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".json": "json",
    ".jsonc": "jsonc",
}


def _language_for_name(name: str) -> str:
    return _LANGUAGE_BY_EXTENSION.get(Path(name or "").suffix.lower(), "")


def _base_result(name: str, content: bytes) -> dict[str, Any]:
    language = _language_for_name(name)
    return {
        "language": language or "text",
        "parser": "none",
        "parser_version": "",
        "status": "unsupported" if not language else "fallback",
        "syntax_errors": 0,
        "declarations": [],
        "functions": [],
        "imports": [],
        "symbols": 0,
        "bytes": len(content),
        "lines": content.count(b"\n") + (1 if content else 0),
        "truncated": len(content) > _MAX_ANALYSIS_BYTES,
    }


def _decode(content: bytes) -> str:
    return content[:_MAX_ANALYSIS_BYTES].decode("utf-8-sig", errors="replace")


def _fallback_analysis(name: str, content: bytes) -> dict[str, Any]:
    """Extract useful symbols without pretending to be a full parser."""
    result = _base_result(name, content)
    language = result["language"]
    text = _decode(content)
    if not language or language == "text":
        return result
    result["parser"] = "regex-fallback"
    result["parser_version"] = "1"
    declarations: list[dict[str, Any]] = []
    functions: list[dict[str, Any]] = []
    imports: list[str] = []
    patterns: list[tuple[str, str]] = []
    if language in {"c", "cpp"}:
        patterns = [
            ("function", r"\b([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{"),
            ("type", r"\b(?:struct|class|enum|union|typedef)\s+([A-Za-z_]\w*)"),
            ("macro", r"^\s*#\s*define\s+([A-Za-z_]\w*)"),
        ]
        imports = re.findall(r"^\s*#\s*include\s*[<\"]([^>\"]+)[>\"]", text, re.MULTILINE)
    elif language == "python":
        patterns = [
            ("function", r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\("),
            ("class", r"^\s*class\s+([A-Za-z_]\w*)\b"),
        ]
        imports = re.findall(r"^\s*(?:from\s+([^\s]+)\s+import|import\s+([^\s]+))", text, re.MULTILINE)
        imports = [next(value for value in item if value) for item in imports]
    elif language in {"javascript", "typescript", "tsx"}:
        patterns = [
            ("function", r"\bfunction\s+([A-Za-z_$][\w$]*)\s*\("),
            ("class", r"\bclass\s+([A-Za-z_$][\w$]*)\b"),
            ("const", r"\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*="),
        ]
        imports = re.findall(r"(?:import\s+.*?\s+from\s+|require\s*\(\s*)[\"']([^\"']+)", text)
    elif language in {"json", "jsonc"}:
        result["parser"] = "json-compatible-fallback"
        try:
            json.loads(_strip_jsonc(text))
            result["status"] = "parsed"
        except json.JSONDecodeError as error:
            result["syntax_errors"] = 1
            result["error"] = error.msg
        keys = re.findall(r"[\"']([A-Za-z_$][\w$.-]*)[\"']\s*:", text)
        declarations = [{"name": key, "kind": "property", "line": _line_for(text, key)} for key in keys[:200]]
    for kind, pattern in patterns:
        for match in re.finditer(pattern, text, re.MULTILINE):
            item = {"name": match.group(1), "kind": kind, "line": text.count("\n", 0, match.start()) + 1}
            declarations.append(item)
            if kind == "function":
                functions.append(item)
    result["declarations"] = _unique_symbols(declarations)
    result["functions"] = _unique_symbols(functions)
    result["imports"] = list(dict.fromkeys(imports))[:200]
    result["symbols"] = len(result["declarations"])
    return result


def _line_for(text: str, value: str) -> int:
    index = text.find(value)
    return text.count("\n", 0, max(index, 0)) + 1


def _unique_symbols(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str, int]] = set()
    result = []
    for item in items[:200]:
        key = (str(item.get("name")), str(item.get("kind")), int(item.get("line") or 0))
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def _strip_jsonc(text: str) -> str:
    """Remove JSONC comments and trailing commas while preserving strings."""
    output: list[str] = []
    in_string = False
    escape = False
    index = 0
    while index < len(text):
        character = text[index]
        next_character = text[index + 1] if index + 1 < len(text) else ""
        if in_string:
            output.append(character)
            if escape:
                escape = False
            elif character == "\\":
                escape = True
            elif character == '"':
                in_string = False
            index += 1
            continue
        if character == '"':
            in_string = True
            output.append(character)
            index += 1
            continue
        if character == "/" and next_character == "/":
            index += 2
            while index < len(text) and text[index] not in "\r\n":
                index += 1
            continue
        if character == "/" and next_character == "*":
            index += 2
            while index + 1 < len(text) and text[index : index + 2] != "*/":
                index += 1
            index += 2
            continue
        output.append(character)
        index += 1
    return re.sub(r",\s*([}\]])", r"\1", "".join(output))


def _node_command() -> str | None:
    configured = os.environ.get("MACODE_NODE_PATH", "").strip()
    if configured and Path(configured).is_file():
        return configured
    project_root = Path(__file__).resolve().parents[3]
    candidates = [project_root / "node" / "node.exe", project_root / "bin" / "node" / "node.exe"]
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return shutil.which("node")


def _node_analysis(name: str, content: bytes) -> dict[str, Any] | None:
    if not _PARSER_SCRIPT.is_file() or not _node_command():
        return None
    payload = {"name": name, "content": _decode(content)}
    try:
        completed = subprocess.run(
            [_node_command() or "node", str(_PARSER_SCRIPT)],
            input=json.dumps(payload),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=15,
            check=False,
        )
        if completed.returncode != 0:
            return None
        parsed = json.loads(completed.stdout.strip() or "{}")
        if not isinstance(parsed, dict) or not parsed.get("language"):
            return None
        parsed["bytes"] = len(content)
        parsed["lines"] = content.count(b"\n") + (1 if content else 0)
        parsed["truncated"] = len(content) > _MAX_ANALYSIS_BYTES
        return parsed
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
        return None


def analyze_source_file(name: str, content: bytes) -> dict[str, Any]:
    """Return bounded, serializable structure information for one file."""
    if not isinstance(content, bytes):
        content = bytes(content)
    node_result = _node_analysis(name, content)
    return node_result or _fallback_analysis(name, content)


def get_code_parser_status() -> dict[str, Any]:
    """Describe parser assets without exposing machine-specific paths."""
    node_available = bool(_node_command())
    script_available = _PARSER_SCRIPT.is_file()
    return {
        "available": node_available and script_available,
        "node_available": node_available,
        "script_available": script_available,
        "parsers": {
            "tree-sitter": {"version": "0.21.1", "languages": ["c", "cpp", "python", "typescript", "tsx"]},
            "acorn": {"version": "8.18.0", "languages": ["javascript"]},
            "jsonc-parser": {"version": "3.3.1", "languages": ["json", "jsonc"]},
        },
        "fallback": "regex-fallback",
    }
