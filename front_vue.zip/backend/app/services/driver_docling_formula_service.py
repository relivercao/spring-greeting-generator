"""Formula recognition pipeline for Docling-generated Markdown."""

from __future__ import annotations

import asyncio
import base64
import io
import json
import re
from pathlib import Path
from typing import Any

import httpx
from loguru import logger

from app.core.config import get_settings
from app.services.driver_docling_vision_client import (
    DriverDoclingVisionClient,
    coerce_confidence,
)
from app.utils.claude_cli_monitor import is_task_cancelled


FORMULA_RECOGNITION_DIRNAME = "formula_recognition"
FORMULA_IMAGES_DIRNAME = "formulas"
FORMULA_MANIFEST_FILENAME = "formula_manifest.json"
FORMULA_REPORT_FILENAME = "formula_recognition_report.json"
FORMULA_STAGE_FILENAME = "stage2_with_formulas.md"
FORMULA_RESULT_FILENAME = "result.json"
FORMULA_PLACEHOLDER = "<!-- formula-not-decoded -->"
FORMULA_MIN_CONFIDENCE = 0.75
RESULTS_DIRNAME = "results"


class DriverDoclingFormulaService:
    """Recognize, verify, repair, and inject formulas without manual review."""

    def __init__(self, config: Any, vision_client: DriverDoclingVisionClient | None = None):
        self._config = config
        self._vision = vision_client or DriverDoclingVisionClient()

    async def recognize_formulas(
        self,
        content: str,
        formulas: list[dict[str, Any]],
        image_output_dir: str | Path | None,
        source_name: str,
        task_id: str | None = None,
    ) -> tuple[str, dict[str, Any]]:
        placeholder_count = content.count(FORMULA_PLACEHOLDER)
        if not self._config.enable_formula_recognition or placeholder_count == 0:
            return content, {
                "enabled": self._config.enable_formula_recognition,
                "placeholder_count": placeholder_count,
                "formula_element_count": len(formulas),
                "recognized_count": 0,
                "failed_count": 0,
            }
        if image_output_dir is None:
            return content, {
                "enabled": True,
                "placeholder_count": placeholder_count,
                "formula_element_count": len(formulas),
                "recognized_count": 0,
                "failed_count": placeholder_count,
                "error": "formula recognition requires image_output_dir",
            }

        analysis_dir = Path(image_output_dir) / FORMULA_RECOGNITION_DIRNAME
        results_dir = analysis_dir / RESULTS_DIRNAME
        analysis_dir.mkdir(parents=True, exist_ok=True)
        results_dir.mkdir(parents=True, exist_ok=True)
        formula_contexts = self.formula_recognition_contexts(content)
        indexed_formulas = [
            {
                **formula,
                "index": index,
                "document_context": (
                    formula_contexts[index] if index < len(formula_contexts) else ""
                ),
            }
            for index, formula in enumerate(formulas)
        ]
        paired_formulas = indexed_formulas[:placeholder_count]
        (analysis_dir / FORMULA_MANIFEST_FILENAME).write_text(
            json.dumps(indexed_formulas, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        results: list[dict[str, Any]] = []
        try:
            router_url, api_key, model = self._vision.resolve_settings()
            semaphore = asyncio.Semaphore(self._config.image_description_concurrency)
            timeout = httpx.Timeout(float(self._config.image_description_timeout))
            async with self._vision.create_http_client(router_url=router_url, timeout=timeout) as client:
                tasks = [
                    self.recognize_single_formula(
                        formula=formula,
                        source_name=source_name,
                        results_dir=results_dir,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                        task_id=task_id,
                    )
                    for formula in paired_formulas
                ]
                results = await asyncio.gather(*tasks) if tasks else []
        except Exception as exc:
            logger.warning("Formula recognition setup failed: {}", exc)
            results = [
                {
                    "status": "failed",
                    "index": index,
                    "page": formula.get("page"),
                    "filename": formula.get("filename"),
                    "error": str(exc),
                }
                for index, formula in enumerate(paired_formulas)
            ]

        publishable = {
            int(result["index"]): result
            for result in results
            if result.get("status") == "success"
            or result.get("status") == "unverified"
        }
        content = self.replace_formula_placeholders(content, publishable)
        failed = [result for result in results if result.get("status") == "failed"]
        unverified = [result for result in results if result.get("status") == "unverified"]
        unpaired_placeholders = max(0, placeholder_count - len(formulas))
        unpaired_formulas = max(0, len(formulas) - placeholder_count)
        report = {
            "enabled": True,
            "source": source_name,
            "placeholder_count": placeholder_count,
            "formula_element_count": len(formulas),
            "recognized_count": len(publishable),
            "verified_count": sum(
                1 for result in publishable.values()
                if result.get("acceptance") == "verified"
            ),
            "auto_repaired_count": sum(
                1 for result in publishable.values()
                if result.get("acceptance") == "auto_repaired"
            ),
            "auto_repaired_unverified_count": len(unverified),
            "image_fallback_count": len(failed) + unpaired_placeholders,
            "failed_count": len(failed) + len(unverified) + unpaired_placeholders,
            "unpaired_placeholder_count": unpaired_placeholders,
            "unpaired_formula_count": unpaired_formulas,
            "results": results,
        }
        (analysis_dir / FORMULA_REPORT_FILENAME).write_text(
            json.dumps(report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (analysis_dir / FORMULA_STAGE_FILENAME).write_text(content, encoding="utf-8")
        logger.info(
            "Formula recognition completed: placeholders={}, elements={}, recognized={}, failed={}",
            placeholder_count,
            len(formulas),
            len(publishable),
            report["failed_count"],
        )
        return content, report

    async def recognize_single_formula(
        self,
        *,
        formula: dict[str, Any],
        source_name: str,
        results_dir: Path,
        semaphore: asyncio.Semaphore,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        self._raise_if_cancelled(task_id)
        index = int(formula.get("index") or 0)
        result_dir = results_dir / f"formula_{index + 1:04d}"
        result_dir.mkdir(parents=True, exist_ok=True)
        result_path = result_dir / FORMULA_RESULT_FILENAME
        image_path_text = str(formula.get("path") or "")
        image_path = Path(image_path_text) if image_path_text else None
        if image_path is None or not image_path.is_file():
            return {
                "status": "failed",
                "index": index,
                "page": formula.get("page"),
                "filename": formula.get("filename"),
                "result_path": str(result_path),
                "error": "formula crop is unavailable",
            }
        audit: dict[str, Any] = {}
        try:
            image_data = self.encode_formula_image(image_path)
            media_type = "image/png"
            document_context = str(formula.get("document_context") or "")
            recognition_payload = await self._vision.request_image_json(
                image_data=image_data,
                media_type=media_type,
                prompt=(
                    f"Transcribe the single formula crop from '{source_name}' into exact LaTeX. "
                    "Ignore page headers, surrounding prose, and the equation number. "
                    "Use nearby document text only to disambiguate exact variable spelling; "
                    "derive every operator and grouping from the image pixels. "
                    f"Nearby document text: {document_context or '(none)'}\n"
                    "Preserve subscripts, superscripts, fractions, Greek letters, and operators. "
                    "Return only JSON: "
                    '{"latex":"formula without dollar delimiters",'
                    '"field_confidence":{"latex":0.0}}'
                ),
                system_prompt="You are a mathematical OCR engine. Return strict JSON only.",
                max_tokens=get_settings().DRIVER_DOCLING_FORMULA_MAX_TOKENS,
                semaphore=semaphore,
                client=client,
                router_url=router_url,
                api_key=api_key,
                model=model,
                task_id=task_id,
                usage_source="docling_formula_recognition",
            )
            self._raise_if_cancelled(task_id)
            latex = self.normalize_formula_latex(
                recognition_payload.get("latex") if isinstance(recognition_payload, dict) else ""
            )
            recognition_confidence = coerce_confidence(
                (recognition_payload.get("field_confidence") or {}).get("latex")
                if isinstance(recognition_payload, dict)
                and isinstance(recognition_payload.get("field_confidence"), dict)
                else None
            )
            if not latex or recognition_confidence is None:
                raise ValueError("formula recognition returned invalid LaTeX or confidence")
            if recognition_confidence < FORMULA_MIN_CONFIDENCE:
                raise ValueError(
                    f"formula recognition confidence {recognition_confidence:.2f} is below "
                    f"{FORMULA_MIN_CONFIDENCE:.2f}"
                )
            audit["recognition"] = {
                "latex": latex,
                "field_confidence": {"latex": recognition_confidence},
            }
            syntax_error = self.validate_formula_latex(latex)
            if syntax_error:
                audit["recognition"]["syntax_error"] = syntax_error

            async def verify_candidate(candidate_latex: str) -> dict[str, Any]:
                try:
                    verification_payload = await self._vision.request_image_json(
                        image_data=image_data,
                        media_type=media_type,
                        prompt=(
                            "Verify whether this candidate LaTeX exactly matches the attached formula crop. "
                            "Ignore page headers, surrounding prose, and the equation number. "
                            "Nearby text may confirm variable spelling but not mathematical structure. "
                            "Do not correct or replace it. Return only JSON: "
                            '{"verified":true,"reason":"short reason",'
                            '"field_confidence":{"verification":0.0}}\n'
                            f"Nearby document text: {document_context or '(none)'}\n"
                            f"Candidate LaTeX: {json.dumps(candidate_latex, ensure_ascii=False)}"
                        ),
                        system_prompt="You verify mathematical OCR against pixels. Return strict JSON only.",
                        max_tokens=get_settings().DRIVER_DOCLING_FORMULA_MAX_TOKENS,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                        task_id=task_id,
                        usage_source="docling_formula_verification",
                    )
                    self._raise_if_cancelled(task_id)
                    confidence = coerce_confidence(
                        (verification_payload.get("field_confidence") or {}).get("verification")
                        if isinstance(verification_payload, dict)
                        and isinstance(verification_payload.get("field_confidence"), dict)
                        else None
                    )
                    return {
                        "verified": (
                            bool(verification_payload.get("verified"))
                            if isinstance(verification_payload, dict)
                            else False
                        ),
                        "reason": (
                            str(verification_payload.get("reason") or "")
                            if isinstance(verification_payload, dict)
                            else ""
                        ),
                        "field_confidence": {"verification": confidence},
                    }
                except Exception as exc:
                    return {
                        "verified": False,
                        "reason": "",
                        "field_confidence": {"verification": None},
                        "error": str(exc),
                    }

            def verification_passed(
                verification: dict[str, Any],
                candidate_confidence: float,
            ) -> bool:
                confidence = coerce_confidence(
                    (verification.get("field_confidence") or {}).get("verification")
                )
                return bool(
                    verification.get("verified")
                    and confidence is not None
                    and min(candidate_confidence, confidence) >= FORMULA_MIN_CONFIDENCE
                )

            verification = (
                {
                    "verified": False,
                    "reason": f"deterministic syntax validation failed: {syntax_error}",
                    "field_confidence": {"verification": 0.0},
                }
                if syntax_error
                else await verify_candidate(latex)
            )
            audit["verification"] = verification
            selected_confidence = recognition_confidence
            acceptance = "verified"

            if not verification_passed(verification, recognition_confidence):
                try:
                    repair_payload = await self._vision.request_image_json(
                        image_data=image_data,
                        media_type=media_type,
                        prompt=(
                            "Re-transcribe the attached formula crop and correct the candidate LaTeX using the "
                            "verification feedback. Derive every symbol, subscript, operator, and grouping from "
                            "the image pixels. Nearby text may only disambiguate variable spelling. "
                            "Return strict JSON only: "
                            '{"latex":"corrected formula without dollar delimiters",'
                            '"field_confidence":{"latex":0.0}}\n'
                            f"Nearby document text: {document_context or '(none)'}\n"
                            f"Original candidate: {json.dumps(latex, ensure_ascii=False)}\n"
                            f"Verification feedback: {json.dumps(verification, ensure_ascii=False)}"
                        ),
                        system_prompt="You repair mathematical OCR using the attached pixels. Return strict JSON only.",
                        max_tokens=get_settings().DRIVER_DOCLING_FORMULA_MAX_TOKENS,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                        task_id=task_id,
                        usage_source="docling_formula_repair",
                    )
                except Exception as exc:
                    audit["repair"] = {"error": str(exc)}
                    raise ValueError("formula automatic repair request failed") from exc

                repaired_latex = self.normalize_formula_latex(
                    repair_payload.get("latex") if isinstance(repair_payload, dict) else ""
                )
                repair_confidence = coerce_confidence(
                    (repair_payload.get("field_confidence") or {}).get("latex")
                    if isinstance(repair_payload, dict)
                    and isinstance(repair_payload.get("field_confidence"), dict)
                    else None
                )
                audit["repair"] = {
                    "latex": repaired_latex,
                    "field_confidence": {"latex": repair_confidence},
                }
                if not repaired_latex:
                    raise ValueError("formula automatic repair returned no usable LaTeX")
                repair_confidence = repair_confidence or 0.0
                repaired_syntax_error = self.validate_formula_latex(repaired_latex)
                repaired_verification = {
                    "verified": False,
                    "reason": "syntax validation was not run because the repaired formula is invalid",
                    "field_confidence": {"verification": 0.0},
                }
                unverified_reasons: list[str] = []
                if repair_confidence < FORMULA_MIN_CONFIDENCE:
                    unverified_reasons.append(
                        f"repair confidence {repair_confidence:.2f} is below {FORMULA_MIN_CONFIDENCE:.2f}"
                    )
                if repaired_syntax_error:
                    audit["repair"]["syntax_error"] = repaired_syntax_error
                    unverified_reasons.append(
                        f"syntax validation failed: {repaired_syntax_error}"
                    )
                else:
                    repaired_verification = await verify_candidate(repaired_latex)
                    audit["repair_verification"] = repaired_verification
                    if not verification_passed(repaired_verification, repair_confidence):
                        unverified_reasons.append("visual verification failed after automatic repair")
                if unverified_reasons:
                    audit["repair"]["unverified_reasons"] = unverified_reasons

                latex = repaired_latex
                selected_confidence = repair_confidence
                verification = repaired_verification
                acceptance = (
                    "auto_repaired_unverified"
                    if unverified_reasons
                    else "auto_repaired"
                )

            verification_confidence = coerce_confidence(
                (verification.get("field_confidence") or {}).get("verification")
            )
            verification_confidence = verification_confidence or 0.0
            final_confidence = min(selected_confidence, verification_confidence)
            audit["acceptance"] = {
                "mode": acceptance,
                "reason": (
                    "recognition and verification passed"
                    if acceptance == "verified"
                    else (
                        "automatic repair and second verification passed"
                        if acceptance == "auto_repaired"
                        else "automatic repair was written but could not be fully verified"
                    )
                ),
            }
            result = {
                "status": (
                    "unverified"
                    if acceptance == "auto_repaired_unverified"
                    else "success"
                ),
                "acceptance": acceptance,
                "index": index,
                "page": formula.get("page"),
                "filename": formula.get("filename"),
                "latex": latex,
                "field_confidence": {
                    "recognition": round(recognition_confidence, 4),
                    "repair": (
                        round(selected_confidence, 4)
                        if acceptance in {"auto_repaired", "auto_repaired_unverified"}
                        else None
                    ),
                    "verification": round(float(verification_confidence), 4),
                    "final": round(final_confidence, 4),
                },
                "result_path": str(result_path),
                "audit": audit,
            }
        except Exception as exc:
            result = {
                "status": "failed",
                "index": index,
                "page": formula.get("page"),
                "filename": formula.get("filename"),
                "result_path": str(result_path),
                "error": str(exc),
                "audit": audit,
            }
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result

    @staticmethod
    def normalize_formula_latex(value: Any) -> str:
        latex = str(value or "").strip()
        latex = re.sub(r"^```(?:latex|tex)?\s*|\s*```$", "", latex, flags=re.IGNORECASE)
        latex = latex.strip().removeprefix("$$").removesuffix("$$").strip()
        latex = latex.removeprefix("$").removesuffix("$").strip()
        return latex if 0 < len(latex) <= 2000 else ""

    @staticmethod
    def validate_formula_latex(latex: str) -> str | None:
        """Return a deterministic syntax error for clearly incomplete LaTeX."""
        candidate = str(latex or "").strip()
        if not candidate:
            return "formula is empty"

        depth = 0
        escaped = False
        for character in candidate:
            if escaped:
                escaped = False
                continue
            if character == "\\":
                escaped = True
                continue
            if character == "{":
                depth += 1
            elif character == "}":
                depth -= 1
                if depth < 0:
                    return "closing brace has no matching opening brace"
        if depth:
            return "opening brace has no matching closing brace"

        if "=" in candidate:
            right_hand_side = candidate.rsplit("=", 1)[1].strip()
            if not right_hand_side:
                return "right-hand side is empty"
            if re.fullmatch(
                r"\\(?:Sigma|sum|prod|int)(?:\s*_[{]?[A-Za-z0-9]+[}]?)?(?:\s*\^[{]?[A-Za-z0-9]+[}]?)?",
                right_hand_side,
            ):
                return "right-hand side contains an operator without an operand"

        if re.search(r"(?:[=+*/^_-]|\\(?:Sigma|sum|prod|int|frac|sqrt))\s*$", candidate):
            return "formula ends with an incomplete operator"
        return None

    @staticmethod
    def encode_formula_image(image_path: Path) -> str:
        from PIL import Image

        with Image.open(image_path) as image:
            image = image.convert("RGB")
            if image.width < 1200:
                scale = min(3.0, 1200 / max(1, image.width))
                image = image.resize(
                    (max(1, round(image.width * scale)), max(1, round(image.height * scale))),
                    Image.Resampling.LANCZOS,
                )
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode("ascii")

    @staticmethod
    def _raise_if_cancelled(task_id: str | None) -> None:
        if task_id and is_task_cancelled(task_id):
            raise asyncio.CancelledError(
                f"Task {task_id} cancelled during Docling formula recognition"
            )

    @staticmethod
    def formula_recognition_contexts(content: str) -> list[str]:
        lines = content.splitlines()
        contexts: list[str] = []
        for index, line in enumerate(lines):
            if FORMULA_PLACEHOLDER not in line:
                continue
            nearby: list[str] = []
            for raw_line in lines[max(0, index - 3):min(len(lines), index + 4)]:
                normalized = raw_line.strip()
                if (
                    not normalized
                    or normalized == FORMULA_PLACEHOLDER
                    or normalized.startswith("![")
                ):
                    continue
                nearby.append(normalized)
            contexts.append("\n".join(nearby)[-1800:])
        return contexts

    @staticmethod
    def replace_formula_placeholders(
        content: str,
        successful: dict[int, dict[str, Any]],
    ) -> str:
        parts = content.split(FORMULA_PLACEHOLDER)
        if len(parts) == 1:
            return content
        result = [parts[0]]
        for index, trailing in enumerate(parts[1:]):
            formula = successful.get(index)
            if formula:
                confidence = float((formula.get("field_confidence") or {}).get("final") or 0.0)
                acceptance = str(formula.get("acceptance") or "verified")
                result.append(
                    f"$$\n{formula['latex']}\n$$\n\n"
                    f"<!-- formula confidence: {confidence:.2f}; acceptance: {acceptance} -->"
                )
            else:
                result.append(FORMULA_PLACEHOLDER)
            result.append(trailing)
        return "".join(result)
