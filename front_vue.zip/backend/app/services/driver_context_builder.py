"""
@file driver_context_builder.py
@brief Builds LLM context from Driver Agent conversation history for multi-turn support.

@version 3.2
@date 2026-05-28

@copyright Copyright (c) 2026 relivercao@gmail.com
All rights reserved.

"""
import json
from typing import Any

from app.repositories.driver_conversation import DriverConversationRepository


# Context retention limits (confirmed in design doc)
RECENT_CONVERSATION_TURNS = 10
RECENT_TOOL_RESULTS = 20
LATEST_ERROR_RECORDS = 3
RECENT_ARTIFACT_RECORDS = 10


class DriverContextBuilder:
    """Builds LLM context from session state for multi-turn Driver Agent conversation."""

    def __init__(self, repo: DriverConversationRepository):
        self._repo = repo

    async def build_context(self, session_id: str, task_id: str | None = None) -> list[dict[str, Any]]:
        """Build conversation context messages for LLM.

        Returns a list of message dicts suitable for LLM input:
        [{"role": "system"/"user"/"assistant", "content": "..."}]
        """
        messages: list[dict[str, Any]] = []

        # 1. System context with task state
        system_parts = ["You are a firmware driver code generation assistant."]
        if task_id:
            task = await self._repo.get_task(task_id)
            if task:
                state_data = json.loads(task.state_data) if task.state_data else {}
                system_parts.append(
                    f"Current task: {task.id}, status={task.status}, "
                    f"step={task.current_step}, retries={task.retry_count}/{task.max_retries}"
                )
                if task.last_error:
                    system_parts.append(f"Last error: {task.last_error}")
                if state_data:
                    system_parts.append(f"Task state: {json.dumps(state_data, ensure_ascii=False)}")

        # 2. Recent tool results as context
        if task_id:
            tool_results = await self._repo.list_tool_results(task_id, limit=RECENT_TOOL_RESULTS)
            if tool_results:
                tool_summary = []
                for tr in tool_results[-RECENT_TOOL_RESULTS:]:
                    output = json.loads(tr.output_data) if tr.output_data else {}
                    tool_summary.append(
                        f"[{tr.tool_name}] status={tr.status}"
                        + (f" error={tr.error_message}" if tr.error_message else "")
                    )
                system_parts.append("Recent tool results:\n" + "\n".join(tool_summary))

        # 3. Recent artifacts
        if task_id:
            artifacts = await self._repo.list_artifacts(task_id)
            if artifacts:
                art_summary = [
                    f"- {a.name} ({a.artifact_type}, {a.language or 'unknown'})"
                    for a in artifacts[-RECENT_ARTIFACT_RECORDS:]
                ]
                system_parts.append("Generated artifacts:\n" + "\n".join(art_summary))

        messages.append({"role": "system", "content": "\n\n".join(system_parts)})

        # 4. Recent conversation turns
        conv_messages = await self._repo.list_messages(session_id, limit=RECENT_CONVERSATION_TURNS * 2)
        for msg in conv_messages[-(RECENT_CONVERSATION_TURNS * 2):]:
            messages.append({"role": msg.role, "content": msg.content})

        return messages

    async def build_generation_context(
        self,
        session_id: str,
        task_id: str,
        source_contents: list[dict[str, Any]] | None = None,
        repo_files: list[dict[str, str]] | None = None,
    ) -> list[dict[str, Any]]:
        """Build compact generation context; source bodies stay behind task-scoped tools."""
        base_messages = await self.build_context(session_id, task_id)

        if source_contents:
            doc_lines = ["Reference documents (paths and purposes only):"]
            for source in source_contents:
                path = (
                    source.get("parsed_path")
                    or source.get("path")
                    or source.get("saved_path")
                    or source.get("name")
                    or "unknown"
                )
                role = source.get("role") or source.get("source_type") or "reference document"
                purpose = source.get("purpose") or role
                doc_lines.append(f"- Path: {path} | Role: {role} | Purpose: {purpose}")
            base_messages.append({"role": "system", "content": "\n".join(doc_lines)})

        if repo_files:
            code_lines = ["Reference repository files (paths and purposes only):"]
            for repository_file in repo_files:
                path = repository_file.get("context_path") or repository_file.get("path") or "unknown"
                purpose = repository_file.get("purpose") or repository_file.get("role") or "project reference interface"
                code_lines.append(f"- Path: {path} | Purpose: {purpose}")
            base_messages.append({"role": "system", "content": "\n".join(code_lines)})

        return base_messages
