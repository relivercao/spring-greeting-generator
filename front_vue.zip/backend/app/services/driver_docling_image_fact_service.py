"""Deterministic vocabulary and fact guards for Docling image descriptions."""

from __future__ import annotations

import difflib
import re
import unicodedata
from collections import Counter
from typing import Any


TECHNICAL_TOKEN_PATTERN = re.compile(
    r"\b[A-Za-z][A-Za-z0-9]*(?:[_/-][A-Za-z0-9]+)+\b"
    r"|\b[A-Z][A-Z0-9]{1,19}\b"
)
PIN_COORDINATE_PATTERN = re.compile(r"\b([A-Z]{1,3}\d{1,3})\b")
HIGH_RISK_RELATIONSHIP_PATTERN = re.compile(
    r"\b(?:series|parallel|common[- ]anode|common[- ]cathode|buck[- ]boost|"
    r"daisy[- ]chain(?:ed|ing)?|cascade data path)\b",
    re.IGNORECASE,
)
UNCERTAIN_LANGUAGE_PATTERN = re.compile(
    r"\b(?:likely|approximately|possibly|probably|may represent|appears to)\b",
    re.IGNORECASE,
)
PURPOSE_INFERENCE_PATTERN = re.compile(
    r"\b(?:handheld|IoT|automotive|consumer|medical|industrial)\b",
    re.IGNORECASE,
)
UNIT_PATTERN = re.compile(
    r"(?:mV|V|mA|A|uA|nA|nF|uF|pF|uH|mH|ns|us|ms|MHz|kHz|Hz|"
    r"kOhm|Ohm|mm|cm|um|degC|%)\b",
    re.IGNORECASE,
)
ENGINEERING_VALUE_PATTERN = re.compile(
    r"[-+]?\d+(?:\.\d+)?(?:\s*(?:\+/-|to|~|-)\s*\d+(?:\.\d+)?)?\s*"
    r"(?:mV|V|mA|A|uA|nA|nF|uF|pF|uH|mH|ns|us|ms|MHz|kHz|Hz|"
    r"kOhm|Ohm|mm|cm|um|mil|inch|degC|%)\b",
    re.IGNORECASE,
)


def normalize_fact_text(value: Any) -> str:
    return "".join(
        character.lower()
        for character in str(value or "")
        if character.isalnum()
    )


def confusable_fact_text(value: Any) -> str:
    translation = str.maketrans(
        {
            "0": "O",
            "Q": "O",
            "1": "I",
            "L": "I",
            "|": "I",
            "5": "S",
            "8": "B",
            "2": "Z",
            "6": "G",
        }
    )
    return "".join(
        character
        for character in str(value or "").upper().translate(translation)
        if character.isalnum()
    )


def normalize_engineering_text(value: Any) -> str:
    text = str(value or "")
    text = (
        text.replace(unicodedata.lookup("MICRO SIGN"), "u")
        .replace(unicodedata.lookup("GREEK SMALL LETTER MU"), "u")
        .replace(unicodedata.lookup("OHM SIGN"), "Ohm")
        .replace(unicodedata.lookup("GREEK CAPITAL LETTER OMEGA"), "Ohm")
        .replace(unicodedata.lookup("DEGREE SIGN"), "deg")
        .replace(unicodedata.lookup("PLUS-MINUS SIGN"), "+/-")
    )
    return re.sub(r"deg\s*C\b", "degC", text, flags=re.IGNORECASE)


def signal_shape_is_compatible(raw_value: str, candidate_value: str) -> bool:
    """Allow common letter/digit OCR swaps without changing identifier structure."""
    raw = re.sub(r"[^A-Za-z0-9]", "", str(raw_value or "").upper())
    candidate = re.sub(r"[^A-Za-z0-9]", "", str(candidate_value or "").upper())
    raw_digits = re.findall(r"\d", raw)
    candidate_digits = re.findall(r"\d", candidate)
    if bool(raw_digits) == bool(candidate_digits):
        return len(raw_digits) == len(candidate_digits)
    return bool(
        not raw_digits
        and candidate_digits == ["1"]
        and raw.endswith(("I", "L"))
        and candidate.endswith("1")
        and raw[:-1] == candidate[:-1]
    )


def build_document_vocabulary(content: str) -> dict[str, Any]:
    """Extract reusable identifiers and pin mappings from the current document."""
    text = str(content or "").replace("\\_", "_")
    counts: Counter[str] = Counter()
    display_by_key: dict[str, str] = {}
    matrix_dimensions: dict[str, str] = {}

    multiplication_sign = re.escape(unicodedata.lookup("MULTIPLICATION SIGN"))
    for match in re.finditer(
        rf"\b(\d{{1,2}})\s*([xX{multiplication_sign}])\s*(\d{{1,2}})\b",
        text,
    ):
        key = f"{match.group(1)}x{match.group(3)}"
        matrix_dimensions.setdefault(key, match.group(0).replace(" ", ""))

    token_pattern = re.compile(
        r"\b[A-Za-z][A-Za-z0-9]*(?:[_/-][A-Za-z0-9]+)+\b"
        r"|\b[A-Z][A-Z0-9]{1,19}\b"
    )
    for match in token_pattern.finditer(text):
        token = match.group(0).strip("_/-")
        if (
            not token
            or len(token) > 40
            or token.lower().startswith("src_")
            or (not any(character.isdigit() for character in token) and len(token) > 12)
        ):
            continue
        key = normalize_fact_text(token)
        if len(key) < 2:
            continue
        counts[key] += 1
        current = display_by_key.get(key)
        if current is None or len(token) < len(current):
            display_by_key[key] = token

    device_models: list[str] = []
    frontmatter = re.match(r"\A---\s*\n(.*?)\n---\s*", text, re.DOTALL)
    if frontmatter:
        model_match = re.search(
            r"(?im)^chip_model\s*:\s*[\"']?([^\"'\n]+)",
            frontmatter.group(1),
        )
        if model_match:
            model = model_match.group(1).strip()
            if model:
                device_models.append(model)
                key = normalize_fact_text(model)
                counts[key] += 10
                display_by_key[key] = model

    for key, count in counts.items():
        candidate = display_by_key[key]
        if (
            count >= 2
            and len(candidate) >= 8
            and sum(character.isdigit() for character in candidate) >= 3
            and sum(character.isalpha() for character in candidate) >= 2
            and "/" not in candidate
            and candidate not in device_models
        ):
            device_models.append(candidate)

    pin_mappings: dict[str, str] = {}
    inside_pin_table = False
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not (line.startswith("|") and line.endswith("|")):
            if line:
                inside_pin_table = False
            continue
        cells = [re.sub(r"[*`]", "", cell).strip() for cell in line.strip("|").split("|")]
        first_header = str(cells[0] if cells else "").strip().lower().rstrip(".")
        second_header = str(cells[1] if len(cells) > 1 else "").strip().lower()
        if first_header in {"no", "pin", "ball", "coordinate"} and (
            "pin" in second_header or "name" in second_header or "signal" in second_header
        ):
            inside_pin_table = True
            continue
        if not inside_pin_table or all(re.fullmatch(r":?-+:?", cell) for cell in cells):
            continue
        coordinate_cell = cells[0].replace(" ", "") if cells else ""
        coordinates = [
            value.upper()
            for value in coordinate_cell.split(",")
            if re.fullmatch(r"[A-Za-z]{1,3}\d{1,3}", value)
        ]
        if not coordinates or len(coordinates) != len(coordinate_cell.split(",")):
            continue
        for cell in cells[1:]:
            token_match = re.search(r"\b[A-Z][A-Z0-9_/-]{1,19}\b", cell)
            if not token_match:
                continue
            signal = token_match.group(0).strip("_/-")
            if signal in coordinates or signal in {"PIN", "BALL", "WLCSP"}:
                continue
            range_match = re.fullmatch(r"([A-Z_]+)(\d+)\s*[~-]\s*([A-Z_]+)?(\d+)", cell)
            signals = [signal]
            if range_match:
                start_prefix, start_number, end_prefix, end_number = range_match.groups()
                end_prefix = end_prefix or start_prefix
                if start_prefix == end_prefix:
                    signals = [
                        f"{start_prefix}{number}"
                        for number in range(int(start_number), int(end_number) + 1)
                    ]
            if len(signals) == len(coordinates):
                pairs = zip(coordinates, signals)
            elif len(coordinates) == 1:
                pairs = [(coordinates[0], signal)]
            else:
                break
            for coordinate, mapped_signal in pairs:
                pin_mappings[coordinate] = mapped_signal
                key = normalize_fact_text(mapped_signal)
                counts[key] += 5
                display_by_key[key] = mapped_signal
            break

    identifiers = sorted(
        display_by_key.values(),
        key=lambda value: (-counts[normalize_fact_text(value)], len(value), value),
    )
    return {
        "identifiers": identifiers,
        "identifier_counts": {
            display_by_key[key]: count
            for key, count in counts.items()
            if key in display_by_key
        },
        "device_models": device_models,
        "pin_mappings": pin_mappings,
        "matrix_dimensions": matrix_dimensions,
    }


def canonicalize_fact_value(
    value: str,
    *,
    fact_type: str,
    label: str,
    vocabulary: dict[str, Any] | None,
) -> dict[str, Any]:
    """Map OCR-confusable values to terms extracted from this document."""
    raw = str(value or "").strip()
    vocabulary = vocabulary or {}
    pin_mappings = {
        str(key).upper(): str(mapped)
        for key, mapped in (vocabulary.get("pin_mappings") or {}).items()
    }
    coordinate_match = PIN_COORDINATE_PATTERN.search(str(label or "").upper())
    if fact_type == "pin" and coordinate_match:
        mapped = pin_mappings.get(coordinate_match.group(1))
        if mapped:
            return {
                "value": mapped,
                "document_match": True,
                "document_confidence": 1.0,
                "reason": "structured pin mapping",
            }

    identifiers = [str(item) for item in vocabulary.get("identifiers") or [] if str(item).strip()]
    device_models = [str(item) for item in vocabulary.get("device_models") or [] if str(item).strip()]
    if fact_type == "device_model" or (
        len(raw) >= 6 and any(character.isdigit() for character in raw) and "_" in raw
    ):
        pool = device_models or identifiers
    elif fact_type in {"pin", "signal", "register"}:
        pool = list(pin_mappings.values()) + identifiers
    else:
        pool = []

    raw_key = normalize_fact_text(raw)
    range_match = re.fullmatch(
        r"([A-Za-z_]+)(\d+)\s*([~/-])\s*([A-Za-z_]+)?(\d+)",
        raw,
    )
    if fact_type in {"pin", "signal"} and range_match:
        start_prefix, start_number, _, end_prefix, end_number = range_match.groups()
        end_prefix = end_prefix or start_prefix
        known_keys = {normalize_fact_text(candidate) for candidate in pool}
        if start_prefix.casefold() == end_prefix.casefold():
            expanded = [
                f"{start_prefix}{number}"
                for number in range(int(start_number), int(end_number) + 1)
            ]
            if expanded and all(normalize_fact_text(candidate) in known_keys for candidate in expanded):
                return {
                    "value": raw,
                    "document_match": True,
                    "document_confidence": 0.98,
                    "reason": "validated document identifier range",
                }
        return {
            "value": raw,
            "document_match": False,
            "document_confidence": 0.0,
            "reason": "identifier range is absent from the document vocabulary",
        }

    for candidate in pool:
        if normalize_fact_text(candidate) == raw_key:
            return {
                "value": candidate,
                "document_match": True,
                "document_confidence": 0.98,
                "reason": "exact document vocabulary match",
            }

    if len(raw_key) < 3:
        return {
            "value": raw,
            "document_match": False,
            "document_confidence": 0.0,
            "reason": "no document vocabulary match",
        }

    raw_confusable = confusable_fact_text(raw)
    ranked: list[tuple[float, int, str]] = []
    counts = vocabulary.get("identifier_counts") or {}
    for candidate in pool:
        candidate_confusable = confusable_fact_text(candidate)
        if not candidate_confusable:
            continue
        if fact_type in {"pin", "signal", "register"} and not signal_shape_is_compatible(
            raw, candidate
        ):
            continue
        if candidate_confusable == raw_confusable:
            similarity = 1.0
        elif fact_type == "device_model":
            similarity = difflib.SequenceMatcher(None, raw_confusable, candidate_confusable).ratio()
        else:
            similarity = 0.0
        ranked.append((similarity, int(counts.get(candidate) or 0), candidate))
    ranked.sort(reverse=True)
    if ranked and ranked[0][0] >= 0.82:
        similarity, _, candidate = ranked[0]
        return {
            "value": candidate,
            "document_match": True,
            "document_confidence": round(0.82 + min(0.16, (similarity - 0.82) * 0.9), 4),
            "reason": "confusable-character document vocabulary match",
        }

    return {
        "value": raw,
        "document_match": False,
        "document_confidence": 0.0,
        "reason": "no document vocabulary match",
    }


def validate_fact_value(
    *,
    fact_type: str,
    label: str,
    value: str,
    unit: str,
    vocabulary: dict[str, Any] | None,
    document_match: bool,
) -> str | None:
    """Return a reason when a selected value is not publishable for its type."""
    text = str(value or "").strip()
    if not text:
        return "selected value is empty"
    if fact_type in {"pin", "signal"}:
        if not any(character.isalpha() for character in text):
            return f"{fact_type} value must contain a letter"
        if vocabulary and vocabulary.get("identifiers") and not document_match:
            return f"{fact_type} value is absent from the document vocabulary"
    elif fact_type == "device_model":
        if not document_match:
            return "device model does not match document metadata or vocabulary"
    elif fact_type == "register":
        if not document_match and not re.search(r"(?:0x[0-9a-f]+|[0-9a-f]{2,4}h)", text, re.IGNORECASE):
            return "register value is neither documented nor address-shaped"
    elif fact_type in {"numeric", "dimension", "component_value"}:
        if not re.search(r"[-+]?\d", text):
            return f"{fact_type} value does not contain a number"
        if fact_type in {"dimension", "component_value"} and not (
            str(unit or "").strip() or UNIT_PATTERN.search(text)
        ):
            return f"{fact_type} value does not contain a unit"

    coordinate_match = PIN_COORDINATE_PATTERN.search(str(label or "").upper())
    pin_mappings = (vocabulary or {}).get("pin_mappings") or {}
    if fact_type == "pin" and coordinate_match and coordinate_match.group(1) in pin_mappings:
        expected = normalize_fact_text(pin_mappings[coordinate_match.group(1)])
        if normalize_fact_text(text) != expected:
            return "pin value conflicts with the structured pin mapping"
    return None


def harden_image_summary(
    summary: dict[str, Any],
    item: dict[str, Any],
    publishable_facts: list[dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Canonicalize identifiers and remove unsupported high-risk statements."""
    vocabulary = item.get("document_vocabulary") or {}
    local_context = "\n".join(
        str(item.get(field) or "")
        for field in ("figure_caption", "document_context")
    ).casefold()
    audit: dict[str, Any] = {
        "identifier_corrections": [],
        "removed_detail_points": [],
        "removed_description_sentences": [],
        "claims": [],
    }
    normalized_publishable_facts = {
        normalize_fact_text(
            " ".join(str(fact.get(field) or "") for field in ("label", "value", "unit"))
        )
        for fact in publishable_facts or []
        if isinstance(fact, dict)
    }

    def replace_matrix_mojibake(text: str, field: str) -> str:
        dimensions = vocabulary.get("matrix_dimensions") or {}
        corrected = text
        for match in list(re.finditer(r"\b(\d{1,2})[^\x00-\x7F](\d{1,2})\b", text)):
            key = f"{match.group(1)}x{match.group(2)}"
            replacement = dimensions.get(key)
            if replacement:
                corrected = corrected.replace(match.group(0), str(replacement))
                audit["identifier_corrections"].append(
                    {"field": field, "from": match.group(0), "to": replacement}
                )
        return corrected

    def engineering_value_is_publishable(value: str) -> bool:
        normalized_value = normalize_fact_text(value)
        return bool(normalized_value) and any(
            normalized_value in fact or fact in normalized_value
            for fact in normalized_publishable_facts
            if fact
        )

    def harden_text(text: str, *, field: str) -> str | None:
        original = str(text or "").strip()
        if not original:
            return None
        corrected = replace_matrix_mojibake(original, field)
        invalid_identifiers: list[str] = []
        text_claims: list[dict[str, Any]] = []
        for match in list(TECHNICAL_TOKEN_PATTERN.finditer(corrected)):
            token = match.group(0)
            if token.isalpha() and token.isupper() and len(token) <= 2:
                continue
            if not any(character.isdigit() for character in token) and not token.isupper() and "_" not in token:
                continue
            fact_type = (
                "device_model"
                if len(token) >= 8 and sum(character.isdigit() for character in token) >= 3
                else "signal"
            )
            candidate = canonicalize_fact_value(
                token,
                fact_type=fact_type,
                label=field,
                vocabulary=vocabulary,
            )
            if candidate["document_match"]:
                replacement = str(candidate["value"])
                claim_status = "verified" if replacement == token else "canonicalized"
                text_claims.append(
                    {
                        "type": fact_type,
                        "raw_value": token,
                        "value": replacement,
                        "status": claim_status,
                        "reason": candidate.get("reason"),
                    }
                )
                if replacement != token:
                    corrected = re.sub(rf"\b{re.escape(token)}\b", replacement, corrected)
                    audit["identifier_corrections"].append(
                        {"field": field, "from": token, "to": replacement}
                    )
            else:
                invalid_identifiers.append(token)
                text_claims.append(
                    {
                        "type": fact_type,
                        "raw_value": token,
                        "value": token,
                        "status": "uncertain",
                        "reason": candidate.get("reason"),
                    }
                )
        if invalid_identifiers:
            audit["claims"].extend({"field": field, **claim} for claim in text_claims)
            return None

        normalized_engineering = normalize_engineering_text(corrected)
        engineering_values = [
            match.group(0).strip()
            for match in ENGINEERING_VALUE_PATTERN.finditer(normalized_engineering)
        ]
        for engineering_value in engineering_values:
            status = "verified" if engineering_value_is_publishable(engineering_value) else "uncertain"
            text_claims.append(
                {
                    "type": "engineering_value",
                    "raw_value": engineering_value,
                    "value": engineering_value,
                    "status": status,
                }
            )
        if any(claim["status"] == "uncertain" for claim in text_claims):
            audit["claims"].extend({"field": field, **claim} for claim in text_claims)
            return None

        relationship_match = HIGH_RISK_RELATIONSHIP_PATTERN.search(corrected)
        if relationship_match and relationship_match.group(0).casefold() not in local_context:
            text_claims.append(
                {
                    "type": "relationship",
                    "raw_value": relationship_match.group(0),
                    "value": relationship_match.group(0),
                    "status": "uncertain",
                }
            )
            audit["claims"].extend({"field": field, **claim} for claim in text_claims)
            return None
        if UNCERTAIN_LANGUAGE_PATTERN.search(corrected):
            audit["claims"].extend({"field": field, **claim} for claim in text_claims)
            return None
        purpose_match = PURPOSE_INFERENCE_PATTERN.search(corrected)
        if purpose_match and purpose_match.group(0).casefold() not in local_context:
            audit["claims"].extend({"field": field, **claim} for claim in text_claims)
            return None
        audit["claims"].extend({"field": field, **claim} for claim in text_claims)
        return corrected

    hardened = dict(summary)
    hardened_title = harden_text(str(summary.get("title") or ""), field="title")
    if hardened_title:
        hardened["title"] = hardened_title
    else:
        caption = re.sub(
            r"^Figure\s*\d+(?:[-.]\d+)*(?:[.:\s]|$)\s*",
            "",
            str(item.get("figure_caption") or ""),
            flags=re.IGNORECASE,
        ).strip()
        hardened["title"] = caption or "Technical Figure"

    description = str(summary.get("description") or "").strip()
    sentences = [
        sentence.strip()
        for sentence in re.split(r"(?<=[.!?])\s+", description)
        if sentence.strip()
    ] or ([description] if description else [])
    safe_sentences: list[str] = []
    for sentence in sentences:
        safe = harden_text(sentence, field="description")
        if safe:
            safe_sentences.append(safe)
        else:
            audit["removed_description_sentences"].append(sentence)
    hardened["description"] = " ".join(safe_sentences).strip()

    records = summary.get("detail_point_records") or [
        {"id": f"D{index}", "text": point}
        for index, point in enumerate(summary.get("detail_points") or [], start=1)
    ]
    safe_records: list[dict[str, Any]] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        text = str(record.get("text") or "").strip()
        safe = harden_text(text, field=str(record.get("id") or "detail"))
        if not safe:
            audit["removed_detail_points"].append(
                {"id": record.get("id"), "text": text}
            )
            continue
        record_claims = [
            claim for claim in audit["claims"]
            if claim.get("field") == str(record.get("id") or "detail")
        ]
        safe_records.append({**record, "text": safe, "claims": record_claims})
    hardened["detail_point_records"] = safe_records
    hardened["detail_points"] = [record["text"] for record in safe_records]
    audit["removed_count"] = (
        len(audit["removed_detail_points"])
        + len(audit["removed_description_sentences"])
    )
    return hardened, audit
