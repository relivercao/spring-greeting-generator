"""Table quality analysis for Docling-generated Markdown."""

from __future__ import annotations

import re
from typing import Any


class DriverDoclingTableService:
    """Detect table structures that may need downstream normalization."""

    def detect_quality_issues(self, content: str) -> list[dict[str, Any]]:
        issues: list[dict[str, Any]] = []
        lines = content.splitlines()
        index = 0
        while index < len(lines):
            if not self._is_table_line(lines[index]):
                index += 1
                continue
            start = index
            block: list[str] = []
            while index < len(lines) and self._is_table_line(lines[index]):
                block.append(lines[index])
                index += 1
            issue = self._issue_for_block(block, start + 1)
            if issue:
                issues.append(issue)
        return issues

    @staticmethod
    def _is_table_line(line: str) -> bool:
        stripped = line.strip()
        return stripped.startswith("|") and stripped.endswith("|")

    def _issue_for_block(
        self,
        block: list[str],
        start_line: int,
    ) -> dict[str, Any] | None:
        if not block:
            return None
        rows = [self._split_cells(line) for line in block]
        max_columns = max((len(row) for row in rows), default=0)
        data_rows = [
            row
            for row in rows
            if not row
            or not all(re.fullmatch(r":?-{3,}:?", cell.strip()) for cell in row)
        ]
        reasons: list[str] = []
        if max_columns >= 8:
            reasons.append("wide_table")
        if len(block) >= 20:
            reasons.append("large_table")
        if any(self._has_repeated_cells(row) for row in data_rows):
            reasons.append("repeated_cells")
        if self._has_inconsistent_column_count(rows):
            reasons.append("inconsistent_column_count")
        if not reasons:
            return None
        return {
            "start_line": start_line,
            "end_line": start_line + len(block) - 1,
            "row_count": len(block),
            "max_column_count": max_columns,
            "reasons": reasons,
        }

    @staticmethod
    def _split_cells(line: str) -> list[str]:
        return [cell.strip() for cell in line.strip().strip("|").split("|")]

    @staticmethod
    def _has_repeated_cells(cells: list[str]) -> bool:
        normalized = [
            cell
            for cell in cells
            if cell and not re.fullmatch(r":?-{3,}:?", cell)
        ]
        if len(normalized) < 4:
            return False
        counts = {cell: normalized.count(cell) for cell in set(normalized)}
        return max(counts.values(), default=0) >= max(3, len(normalized) // 2)

    @staticmethod
    def _has_inconsistent_column_count(rows: list[list[str]]) -> bool:
        counts = [len(row) for row in rows if row]
        return len(set(counts)) > 1
