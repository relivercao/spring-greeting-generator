"""Keep independently configured bot connections usable during OAuth outages."""

from app.services.app_connections import APP_CATALOG, AppConnectionError


async def oauth_catalog(service, user_id):
    try:
        return await service.list_apps(user_id)
    except AppConnectionError as error:
        return {"provider": {"name": "Composio", "configured": True}, "warning": str(error),
                "apps": [{**app, "configured": False, "connected": False, "has_account": False,
                          "account_count": 0, "connection_status": "UNKNOWN"} for app in APP_CATALOG]}
