"""Image description and verification pipeline for Docling Markdown."""

from __future__ import annotations

import asyncio
import base64
import json
import mimetypes
import re
import threading
import unicodedata
from pathlib import Path
from typing import Any

import httpx
from loguru import logger

from app.core.config import get_settings
from app.services.driver_docling_image_fact_service import (
    build_document_vocabulary,
    canonicalize_fact_value,
    harden_image_summary,
    validate_fact_value,
)
from app.services.driver_docling_vision_client import (
    DriverDoclingVisionClient,
    coerce_confidence,
)
from app.services.image_boilerplate_classifier import (
    BOILERPLATE_FILTER_MODE_ENFORCE,
    BOILERPLATE_SCORING_PROFILE_V1,
    DECISION_RULE_SMALL_HEADER_FOOTER,
    classify_boilerplate_image,
    normalize_boilerplate_filter_mode,
)
from app.services.image_boilerplate_features import (
    duplicate_counts_by_hash,
    extract_boilerplate_features,
)
from app.utils.claude_cli_monitor import is_task_cancelled


IMAGE_DESCRIPTION_MODE_ROUTER_VISION = "router_vision"
IMAGE_DESCRIPTION_ACTIVITY_TIMEOUT_SECONDS = 180
IMAGE_DESCRIPTION_MIN_CONFIDENCE = 0.55
IMAGE_DETAIL_OCR_MIN_CONFIDENCE = 0.60
IMAGE_DETAIL_FINAL_MIN_CONFIDENCE = 0.85
IMAGE_FACT_SELECTED_MIN_CONFIDENCE = 0.80
IMAGE_FACT_SELECTED_MIN_MARGIN = 0.15
IMAGE_FACT_OCR_FAMILY_WEIGHT = 0.35
IMAGE_FACT_VISUAL_WEIGHT = 0.25
IMAGE_FACT_DOCUMENT_WEIGHT = 0.40
IMAGE_FACT_AMBIGUITY_PENALTY = 0.10
IMAGE_FACT_CORRECTION_PENALTY = 0.05
IMAGE_LOCAL_OCR_MAX_TOKENS = 40
IMAGE_DESCRIPTION_CONTEXT_LINES = 8
IMAGE_DESCRIPTION_TYPES = frozenset(
    {
        "block_diagram",
        "schematic",
        "timing_diagram",
        "protocol_diagram",
        "flowchart",
        "pinout",
        "register_table",
        "waveform",
        "plot",
        "pcb_layout",
        "package",
        "other",
    }
)
MIN_IMAGE_DESCRIPTION_WIDTH_PX = 128
MIN_IMAGE_DESCRIPTION_HEIGHT_PX = 64
MIN_IMAGE_DESCRIPTION_AREA_PX = 7282
MIN_WIDE_IMAGE_DESCRIPTION_WIDTH_PX = 320
MIN_WIDE_IMAGE_DESCRIPTION_HEIGHT_PX = 40
MIN_WIDE_IMAGE_DESCRIPTION_AREA_PX = 15000
IMAGE_DESCRIPTION_ANALYSIS_DIRNAME = "image_description_analysis"
IMAGE_MANIFEST_FILENAME = "image_manifest.json"
IMAGE_DESCRIPTIONS_FILENAME = "image_descriptions.json"
IMAGE_DESCRIPTION_RESULTS_DIRNAME = "results"
IMAGE_DESCRIPTION_RESULT_FILENAME = "result.json"
INITIAL_TITLE_AUDIT_FILENAME = "initial_title_audit.json"
IMAGE_DESCRIPTION_REPORT_FILENAME = "image_description_report.json"
STAGE3_IMAGE_DESCRIPTIONS_FILENAME = "stage3_with_image_descriptions.md"
BYPASS_IMAGE_DESCRIPTION_PERMISSIONS = False

_IMAGE_OCR_READER: Any = None
_IMAGE_OCR_ENGINE: str | None = None
_IMAGE_OCR_LOCK = threading.Lock()


def _rapidocr_output_to_results(output: Any) -> list[tuple[Any, Any, Any]]:
    boxes = getattr(output, "boxes", None)
    texts = getattr(output, "txts", None)
    scores = getattr(output, "scores", None)
    if boxes is None or texts is None or scores is None:
        return []
    return list(zip(boxes, texts, scores))


class DriverDoclingImageDescriptionService:
    """Describe images, verify semantics, and inject grounded Markdown blocks."""

    def __init__(self, config: Any, vision_client: DriverDoclingVisionClient | None = None):
        self._config = config
        self._vision = vision_client or DriverDoclingVisionClient()

    async def inject_image_descriptions(
        self,
        content: str,
        image_mapping: dict,
        image_output_dir: str | Path | None,
        source_name: str,
        task_id: str | None = None,
    ) -> tuple[str, dict]:
        """Describe every eligible image with isolated, bounded workers.

        Each image gets its own working directory and ``result.json``. The
        image index is assigned by this service and is never taken from model
        output, which prevents descriptions from being attached to the wrong
        Markdown image when multiple calls run concurrently.
        """
        if not self._config.enable_image_descriptions:
            return content, {}

        candidate_items: dict[int, dict[str, Any]] = {}
        eligible: dict[int, dict[str, Any]] = {}
        skipped: dict[int, dict[str, Any]] = {}
        document_vocabulary = build_document_vocabulary(content)
        for raw_idx, item in image_mapping.items():
            try:
                idx = int(raw_idx)
            except (TypeError, ValueError):
                logger.warning("Skipping image with invalid mapping index: {}", raw_idx)
                continue
            if not item.get("path") or not item.get("filename") or item.get("status") == "missing":
                continue

            enriched_item = dict(item)
            enriched_item["document_vocabulary"] = document_vocabulary
            enriched_item.update(self._image_description_metadata(item.get("path")))
            current_markdown_line = self._locate_current_image_line(content, enriched_item)
            enriched_item["current_markdown_line"] = current_markdown_line
            context = self._image_description_context(content, current_markdown_line)
            enriched_item["document_context"] = context
            figure_caption = self._figure_caption_from_context(context)
            enriched_item["figure_caption"] = figure_caption
            enriched_item["expected_types"] = sorted(
                self._expected_image_types(figure_caption)
                or self._expected_image_types(context)
            )
            if enriched_item.get("description_eligible"):
                candidate_items[idx] = enriched_item
            else:
                enriched_item["description_skip_reason"] = (
                    enriched_item.get("description_skip_reason") or "TOO_SMALL"
                )
                skipped[idx] = enriched_item

        boilerplate_filter_enabled = bool(
            getattr(self._config, "enable_boilerplate_image_filter", True)
        )
        boilerplate_filter_mode = normalize_boilerplate_filter_mode(
            getattr(self._config, "boilerplate_filter_mode", BOILERPLATE_FILTER_MODE_ENFORCE)
        )
        boilerplate_enforce = boilerplate_filter_mode == BOILERPLATE_FILTER_MODE_ENFORCE
        image_scores: list[dict[str, Any]] = []
        extracted_features: dict[int, dict[str, Any]] = {}
        if boilerplate_filter_enabled and candidate_items:
            for idx, item in sorted(candidate_items.items()):
                try:
                    extracted_features[idx] = extract_boilerplate_features(
                        item["path"],
                        metadata=item,
                        profile=BOILERPLATE_SCORING_PROFILE_V1,
                    )
                except Exception as exc:
                    item["boilerplate_filter_error"] = str(exc)
                    logger.warning(
                        "Boilerplate feature extraction failed for image {} ({}): {}",
                        idx,
                        item.get("filename"),
                        exc,
                    )
        duplicate_counts = (
            duplicate_counts_by_hash(extracted_features)
            if boilerplate_filter_enabled and extracted_features
            else {}
        )
        scored_items: list[dict[str, Any]] = []
        for idx, item in sorted(candidate_items.items()):
            if not boilerplate_filter_enabled:
                eligible[idx] = item
                continue
            features = extracted_features.get(idx) or {}
            duplicate_count = int(duplicate_counts.get(idx, 1))
            decision = classify_boilerplate_image(
                features,
                expected_types=item.get("expected_types") or [],
                document_context=str(item.get("document_context") or ""),
                figure_caption=str(item.get("figure_caption") or ""),
                duplicate_count=duplicate_count,
                enforce=boilerplate_enforce,
                profile=BOILERPLATE_SCORING_PROFILE_V1,
            )
            visual_only_decision = classify_boilerplate_image(
                features,
                expected_types=item.get("expected_types") or [],
                document_context=str(item.get("document_context") or ""),
                figure_caption=str(item.get("figure_caption") or ""),
                duplicate_count=1,
                enforce=True,
                profile=BOILERPLATE_SCORING_PROFILE_V1,
            )
            scored_items.append(
                {
                    "idx": idx,
                    "item": item,
                    "features": features,
                    "decision": decision,
                    "visual_only_decision": visual_only_decision,
                    "duplicate_count": duplicate_count,
                    "bbox_available": self._boilerplate_bbox_available(features),
                    "bbox_unavailable_reason": self._boilerplate_bbox_unavailable_reason(
                        item,
                        features,
                    ),
                }
            )

        filter_health = self._boilerplate_filter_health(scored_items)
        degrade_single_bbox_path = (
            filter_health.get("health") == "degraded"
            and boilerplate_filter_mode == BOILERPLATE_FILTER_MODE_ENFORCE
        )
        if degrade_single_bbox_path:
            logger.warning(
                "Boilerplate filter separation is degraded (margin={}): single-image "
                "bbox-unavailable skip decisions will be observed only",
                filter_health.get("separation_margin"),
            )

        for scored in scored_items:
            idx = int(scored["idx"])
            item = scored["item"]
            features = scored["features"]
            decision = scored["decision"]
            visual_only_decision = scored["visual_only_decision"]
            duplicate_count = int(scored["duplicate_count"])
            bbox_available = bool(scored["bbox_available"])
            auto_observe_reason = None
            effective_skip = bool(decision.skip)
            if (
                effective_skip
                and degrade_single_bbox_path
                and duplicate_count == 1
                and not bbox_available
            ):
                effective_skip = False
                auto_observe_reason = "DEGRADED_SEPARATION_BBOX_UNAVAILABLE_SINGLE"
            decision_report = decision.to_report()
            decision_report["features"] = self._boilerplate_report_features(features)
            decision_report["duplicate_count"] = duplicate_count
            decision_report["filter_mode"] = boilerplate_filter_mode
            decision_report["bbox_available"] = bbox_available
            decision_report["bbox_unavailable_reason"] = scored["bbox_unavailable_reason"]
            decision_report["decision_basis"] = self._boilerplate_decision_basis(
                decision,
                visual_only_decision,
                duplicate_count,
            )
            decision_report["base_logo_score_without_duplicate"] = round(
                visual_only_decision.logo_score,
                4,
            )
            decision_report["would_skip_without_duplicate"] = bool(
                visual_only_decision.would_skip
            )
            if auto_observe_reason:
                decision_report["skip"] = False
                decision_report["would_skip"] = True
                decision_report["auto_observe_reason"] = auto_observe_reason
            if item.get("boilerplate_filter_error"):
                decision_report["error"] = item.get("boilerplate_filter_error")
            item["boilerplate_filter"] = decision_report
            image_scores.append(
                {
                    "index": idx,
                    "filename": item.get("filename"),
                    "page": item.get("page"),
                    "decision": (
                        "skipped"
                        if effective_skip
                        else "would_skip"
                        if decision.would_skip
                        else "kept"
                    ),
                    **decision_report,
                }
            )
            if effective_skip:
                item["description_skip_reason"] = decision.reason
                skipped[idx] = item
                continue
            eligible[idx] = item

        if skipped:
            logger.info(
                "Skipping {} image(s) for description: {}",
                len(skipped),
                ", ".join(str(item.get("filename")) for item in skipped.values()),
            )
        if image_output_dir is None:
            logger.warning("Image descriptions require image_output_dir; skipping")
            return content, {}

        output_dir = Path(image_output_dir)
        analysis_dir = output_dir / IMAGE_DESCRIPTION_ANALYSIS_DIRNAME
        results_dir = analysis_dir / IMAGE_DESCRIPTION_RESULTS_DIRNAME
        analysis_dir.mkdir(parents=True, exist_ok=True)
        results_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = analysis_dir / IMAGE_MANIFEST_FILENAME
        output_path = analysis_dir / IMAGE_DESCRIPTIONS_FILENAME

        if not eligible:
            report = self._build_image_description_report(
                source_name=source_name,
                image_mapping=image_mapping,
                eligible=eligible,
                skipped=skipped,
                worker_results=[],
                successful=[],
                failed=[],
                image_scores=image_scores,
                boilerplate_filter_enabled=boilerplate_filter_enabled,
                boilerplate_filter_mode=boilerplate_filter_mode,
            )
            self._write_image_description_report(analysis_dir, report)
            return content, {}

        manifest = [
            {
                "index": idx,
                "filename": item.get("filename"),
                "path": item.get("path"),
                "page": item.get("page"),
                "placeholder_index": item.get("placeholder_index"),
                "width": item.get("width"),
                "height": item.get("height"),
                "area": item.get("area"),
                "file_size": item.get("file_size"),
                "description_eligibility_policy": item.get("description_eligibility_policy"),
                "current_markdown_line": item.get("current_markdown_line"),
                "figure_caption": item.get("figure_caption"),
                "document_context": item.get("document_context"),
                "expected_types": item.get("expected_types"),
            }
            for idx, item in sorted(eligible.items())
        ]
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

        logger.info(
            "Starting per-image descriptions: mode={}, eligible={}, skipped={}, batch_size={}, concurrency={}",
            self._config.image_description_mode,
            len(eligible),
            len(skipped),
            self._config.image_description_batch_size,
            self._config.image_description_concurrency,
        )
        semaphore = asyncio.Semaphore(self._config.image_description_concurrency)
        from app.services.driver_docling_progress import report_docling_progress

        completed_images = 0
        failed_images = 0

        async def _track_image_result(work):
            nonlocal completed_images, failed_images
            result = await work
            completed_images += 1
            failed_images += int(result.get("status") != "success")
            report_docling_progress(
                "image_descriptions",
                f"Docling image descriptions {completed_images}/{len(eligible)}; failed={failed_images}",
                completed_images=completed_images, total_images=len(eligible),
                failed_images=failed_images, skipped_images=len(skipped),
            )
            return result

        report_docling_progress(
            "image_descriptions", f"Docling image descriptions 0/{len(eligible)}",
            completed_images=0, total_images=len(eligible), failed_images=0,
            skipped_images=len(skipped),
        )
        try:
            if self._config.image_description_mode == IMAGE_DESCRIPTION_MODE_ROUTER_VISION:
                router_url, api_key, model = self._vision.resolve_settings()
                timeout = httpx.Timeout(float(self._config.image_description_timeout))
                async with self._vision.create_http_client(router_url=router_url, timeout=timeout) as client:
                    tasks = [
                        self._describe_single_image_router(
                            index=idx,
                            item=item,
                            source_name=source_name,
                            results_dir=results_dir,
                            semaphore=semaphore,
                            client=client,
                            router_url=router_url,
                            api_key=api_key,
                            model=model,
                            task_id=task_id,
                        )
                        for idx, item in sorted(eligible.items())
                    ]
                    worker_results = await asyncio.gather(
                        *(_track_image_result(work) for work in tasks), return_exceptions=False,
                    )
            else:
                logger.warning(
                    "claude_cli image description mode is deprecated; use router_vision instead"
                )
                from app.core.config import get_resolved_cli_path, get_settings, resolve_claude_cli_model
                from app.utils.claude_cli_monitor import ClaudeCliMonitor

                settings = get_settings()
                cli_path = get_resolved_cli_path()
                model = resolve_claude_cli_model(settings)
                tasks = [
                    self._describe_single_image(
                        index=idx,
                        item=item,
                        source_name=source_name,
                        output_dir=output_dir,
                        analysis_dir=analysis_dir,
                        results_dir=results_dir,
                        semaphore=semaphore,
                        cli_path=cli_path,
                        model=model,
                        monitor_factory=ClaudeCliMonitor,
                        task_id=task_id,
                    )
                    for idx, item in sorted(eligible.items())
                ]
                worker_results = await asyncio.gather(
                    *(_track_image_result(work) for work in tasks), return_exceptions=False,
                )
        except Exception as exc:
            logger.warning("Image description setup or execution failed: {}", exc)
            return content, {}

        successful = [item for item in worker_results if item.get("status") == "success"]
        failed = [item for item in worker_results if item.get("status") != "success"]
        logger.info(
            "Completed per-image descriptions: attempted={}, described={}, failed={}",
            len(worker_results),
            len(successful),
            len(failed),
        )
        descriptions = {
            int(item["index"]): item
            for item in successful
            if item.get("index") is not None
        }

        merged_payload = {
            "source": source_name,
            "descriptions": [descriptions[index] for index in sorted(descriptions)],
        }
        try:
            output_path.write_text(
                json.dumps(merged_payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.warning("Failed to save merged image descriptions: {}", exc)

        report = self._build_image_description_report(
            source_name=source_name,
            image_mapping=image_mapping,
            eligible=eligible,
            skipped=skipped,
            worker_results=worker_results,
            successful=successful,
            failed=failed,
            image_scores=image_scores,
            boilerplate_filter_enabled=boilerplate_filter_enabled,
            boilerplate_filter_mode=boilerplate_filter_mode,
        )
        try:
            (analysis_dir / IMAGE_DESCRIPTION_REPORT_FILENAME).write_text(
                json.dumps(report, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.warning("Failed to save image description report: {}", exc)

        content = self._inject_image_description_blocks(content, descriptions)
        stage3_path = output_dir / STAGE3_IMAGE_DESCRIPTIONS_FILENAME
        try:
            stage3_path.write_text(content, encoding="utf-8")
        except Exception as exc:
            logger.warning("Failed to save stage 3 markdown: {}", exc)
        return content, descriptions

    def _build_image_description_report(
        self,
        *,
        source_name: str,
        image_mapping: dict,
        eligible: dict[int, dict[str, Any]],
        skipped: dict[int, dict[str, Any]],
        worker_results: list[dict[str, Any]],
        successful: list[dict[str, Any]],
        failed: list[dict[str, Any]],
        image_scores: list[dict[str, Any]],
        boilerplate_filter_enabled: bool,
        boilerplate_filter_mode: str,
    ) -> dict[str, Any]:
        """Build the image description report payload."""
        skipped_items = [
            {
                "index": index,
                "filename": item.get("filename"),
                "page": item.get("page"),
                "reason": item.get("description_skip_reason"),
                "evidence": item.get("boilerplate_filter"),
            }
            for index, item in sorted(skipped.items())
        ]
        skipped_counts_by_reason: dict[str, int] = {}
        for item in skipped_items:
            reason = str(item.get("reason") or "UNKNOWN")
            skipped_counts_by_reason[reason] = skipped_counts_by_reason.get(reason, 0) + 1
        boilerplate_health = self._boilerplate_report_health(image_scores)

        return {
            "source": source_name,
            "mode": self._config.image_description_mode,
            "batch_size": self._config.image_description_batch_size,
            "concurrency": self._config.image_description_concurrency,
            "boilerplate_filter_enabled": boilerplate_filter_enabled,
            "boilerplate_filter_mode": boilerplate_filter_mode,
            "boilerplate_feature_version": BOILERPLATE_SCORING_PROFILE_V1["feature_version"],
            "boilerplate_filter_health": boilerplate_health,
            "total_mapped_images": len(image_mapping),
            "eligible_images": len(eligible),
            "skipped_small_images": sum(
                1
                for item in skipped.values()
                if str(item.get("description_skip_reason") or "").startswith("image too small")
                or item.get("description_skip_reason") == "TOO_SMALL"
            ),
            "skipped_images": skipped_items,
            "skipped_counts_by_reason": skipped_counts_by_reason,
            "image_scores": image_scores,
            "attempted_images": len(worker_results),
            "described_images": len(successful),
            "failed_images": len(failed),
            "title_audited_images": sum(
                1
                for item in [*successful, *failed]
                if item.get("initial_title_audit")
            ),
            "title_contract_violation_images": sum(
                1
                for item in [*successful, *failed]
                if (item.get("initial_title_audit") or {}).get("contract_violation")
            ),
            "title_contract_violation_rate": self._title_contract_violation_rate(
                [*successful, *failed]
            ),
            "title_audits": self._title_audits([*successful, *failed]),
            "verified_fact_count": sum(
                1
                for item in successful
                for fact in item.get("verified_facts") or []
                if fact.get("status") == "verified"
            ),
            "canonicalized_fact_count": sum(
                1
                for item in successful
                for fact in item.get("publishable_facts") or item.get("verified_facts") or []
                if fact.get("status") == "canonicalized"
            ),
            "confidence_selected_fact_count": sum(
                1
                for item in successful
                for fact in item.get("verified_facts") or []
                if fact.get("status") == "confidence_selected"
            ),
            "uncertain_fact_count": sum(
                1
                for item in successful
                for fact in (item.get("detail_verification") or {}).get("rejected_facts") or []
                if fact.get("status") == "uncertain"
            ),
            "detail_verification_error_images": sum(
                1
                for item in successful
                if (item.get("detail_verification") or {}).get("error")
            ),
            "summary_detail_warning_images": sum(
                1
                for item in successful
                if (item.get("detail_verification") or {}).get("summary_contains_precise_details")
            ),
            "summary_partially_verified_images": sum(
                1
                for item in successful
                if ((item.get("detail_verification") or {}).get("summary_verification") or {}).get("status")
                == "partially_verified"
            ),
            "summary_context_grounded_images": sum(
                1
                for item in successful
                if ((item.get("detail_verification") or {}).get("summary_verification") or {}).get("status")
                == "context_grounded"
            ),
            "summary_visual_grounded_images": sum(
                1
                for item in successful
                if ((item.get("detail_verification") or {}).get("summary_verification") or {}).get("status")
                == "visual_grounded"
            ),
            "summary_sanitized_images": sum(
                1
                for item in successful
                if int(
                    ((item.get("detail_verification") or {}).get("summary_verification") or {}).get(
                        "removed_precise_sentence_count"
                    )
                    or 0
                )
                > 0
            ),
            "type_warning_images": sum(
                1
                for item in successful
                if ((item.get("detail_verification") or {}).get("summary_verification") or {}).get(
                    "type_warning"
                )
            ),
            "skipped": [
                {
                    "index": index,
                    "filename": item.get("filename"),
                    "reason": item.get("description_skip_reason"),
                }
                for index, item in sorted(skipped.items())
            ],
            "failed": failed,
            "results": [
                {
                    "index": item.get("index"),
                    "filename": item.get("filename"),
                    "status": item.get("status"),
                    "result_path": item.get("result_path"),
                }
                for item in worker_results
            ],
        }

    @staticmethod
    def _boilerplate_bbox_available(features: dict[str, Any]) -> bool:
        return (
            features.get("area_ratio") is not None
            and features.get("position_band") is not None
        )

    @staticmethod
    def _boilerplate_bbox_unavailable_reason(
        item: dict[str, Any],
        features: dict[str, Any],
    ) -> str | None:
        if DriverDoclingImageDescriptionService._boilerplate_bbox_available(features):
            return None
        if not features:
            return "FEATURE_EXTRACTION_UNAVAILABLE"
        if item.get("bbox") is None:
            return "MAPPING_BBOX_MISSING"
        if item.get("page_width") is None or item.get("page_height") is None:
            return "MAPPING_PAGE_SIZE_MISSING"
        if features.get("area_ratio") is None:
            return "AREA_RATIO_MISSING"
        if features.get("position_band") is None:
            return "POSITION_BAND_MISSING"
        return "GEOMETRY_UNAVAILABLE"

    @staticmethod
    def _boilerplate_decision_basis(
        decision: Any,
        visual_only_decision: Any,
        duplicate_count: int,
    ) -> str:
        if not decision.would_skip:
            return "kept"
        if decision.decision_rule == DECISION_RULE_SMALL_HEADER_FOOTER:
            return "geometry_priority"
        if visual_only_decision.would_skip:
            return "visual_only"
        if duplicate_count >= 2:
            if visual_only_decision.logo_score >= visual_only_decision.logo_threshold:
                return "duplicate_assisted"
            return "duplicate_only"
        return "visual_only"

    @staticmethod
    def _boilerplate_filter_health(scored_items: list[dict[str, Any]]) -> dict[str, Any]:
        image_scores = []
        for scored in scored_items:
            decision = scored["decision"]
            image_scores.append(
                {
                    "decision": (
                        "skipped"
                        if decision.skip
                        else "would_skip"
                        if decision.would_skip
                        else "kept"
                    ),
                    "logo_score": decision.logo_score,
                    "base_logo_score_without_duplicate": scored[
                        "visual_only_decision"
                    ].logo_score,
                    "force_keep": decision.force_keep,
                    "decision_rule": decision.decision_rule,
                    "bbox_available": scored.get("bbox_available"),
                    "duplicate_count": scored.get("duplicate_count"),
                }
            )
        return DriverDoclingImageDescriptionService._boilerplate_report_health(image_scores)

    @staticmethod
    def _boilerplate_report_health(image_scores: list[dict[str, Any]]) -> dict[str, Any]:
        if not image_scores:
            return {
                "health": "unknown",
                "separation_margin": None,
                "guard_trigger_rate": 0.0,
                "guard_trigger_count": 0,
                "bbox_available_count": 0,
                "bbox_available_rate": 0.0,
                "decision_rule_counts": {},
                "separation_scope": "weighted_score_only",
            }

        weighted_score_items = [
            item
            for item in image_scores
            if item.get("decision_rule") != DECISION_RULE_SMALL_HEADER_FOOTER
        ]
        skipped_scores = [
            DriverDoclingImageDescriptionService._boilerplate_separation_score(item)
            for item in weighted_score_items
            if item.get("decision") in {"skipped", "would_skip"}
            and DriverDoclingImageDescriptionService._boilerplate_separation_score(item)
            is not None
        ]
        kept_scores = [
            DriverDoclingImageDescriptionService._boilerplate_separation_score(item)
            for item in weighted_score_items
            if item.get("decision") == "kept"
            and DriverDoclingImageDescriptionService._boilerplate_separation_score(item)
            is not None
        ]
        separation_margin = (
            min(skipped_scores) - max(kept_scores)
            if skipped_scores and kept_scores
            else None
        )
        if separation_margin is None:
            health = "unknown"
        elif separation_margin < 0.02:
            health = "degraded"
        elif separation_margin < 0.05:
            health = "warning"
        else:
            health = "ok"
        guard_trigger_count = sum(1 for item in image_scores if item.get("force_keep"))
        bbox_available_count = sum(1 for item in image_scores if item.get("bbox_available"))
        decision_rule_counts: dict[str, int] = {}
        for item in image_scores:
            rule = str(item.get("decision_rule") or "NONE")
            decision_rule_counts[rule] = decision_rule_counts.get(rule, 0) + 1
        return {
            "health": health,
            "separation_margin": (
                round(float(separation_margin), 4)
                if separation_margin is not None
                else None
            ),
            "guard_trigger_rate": round(guard_trigger_count / len(image_scores), 4),
            "guard_trigger_count": guard_trigger_count,
            "bbox_available_count": bbox_available_count,
            "bbox_available_rate": round(bbox_available_count / len(image_scores), 4),
            "decision_rule_counts": decision_rule_counts,
            "separation_scope": "weighted_score_only",
            "image_score_count": len(image_scores),
        }

    @staticmethod
    def _boilerplate_separation_score(item: dict[str, Any]) -> float | None:
        score = item.get("base_logo_score_without_duplicate")
        if score is None:
            score = item.get("logo_score")
        if score is None:
            return None
        return float(score)

    @staticmethod
    def _write_image_description_report(analysis_dir: Path, report: dict[str, Any]) -> None:
        try:
            (analysis_dir / IMAGE_DESCRIPTION_REPORT_FILENAME).write_text(
                json.dumps(report, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.warning("Failed to save image description report: {}", exc)

    @staticmethod
    def _boilerplate_report_features(features: dict[str, Any]) -> dict[str, Any]:
        allowed = {
            "feature_version",
            "sha256",
            "dhash",
            "width",
            "height",
            "normalized_width",
            "normalized_height",
            "dominant_color_ratio",
            "color_complexity",
            "edge_density",
            "ink_coverage",
            "long_run_count",
            "long_line_or_grid_score",
            "structure_occupancy",
            "area_ratio",
            "position_band",
            "page_edge_distance_ratio",
        }
        return {key: features.get(key) for key in sorted(allowed) if key in features}

    async def _describe_single_image_router(
        self,
        index: int,
        item: dict[str, Any],
        source_name: str,
        results_dir: Path,
        semaphore: asyncio.Semaphore,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        """Send one image directly as an Anthropic multimodal content block."""
        self._raise_if_cancelled(task_id)
        worker_dir = results_dir / f"image_{index + 1:04d}"
        worker_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = worker_dir / IMAGE_MANIFEST_FILENAME
        result_path = worker_dir / IMAGE_DESCRIPTION_RESULT_FILENAME
        try:
            result_path.unlink(missing_ok=True)
        except OSError as exc:
            return self._image_description_failure(
                index,
                item,
                result_path,
                f"could not reset result file: {exc}",
            )

        image_path = Path(item["path"]).resolve()
        request_manifest = {
            "index": index,
            "filename": item.get("filename"),
            "path": str(image_path),
            "page": item.get("page"),
            "placeholder_index": item.get("placeholder_index"),
            "width": item.get("width"),
            "height": item.get("height"),
            "area": item.get("area"),
            "file_size": item.get("file_size"),
            "description_eligibility_policy": item.get("description_eligibility_policy"),
            "document_context": item.get("document_context"),
            "figure_caption": item.get("figure_caption"),
            "expected_types": item.get("expected_types"),
        }
        try:
            manifest_path.write_text(
                json.dumps(request_manifest, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            image_data = base64.b64encode(image_path.read_bytes()).decode("ascii")
        except OSError as exc:
            return self._image_description_failure(index, item, result_path, str(exc))

        media_type = mimetypes.guess_type(image_path.name)[0] or "image/png"
        if media_type not in {"image/png", "image/jpeg", "image/gif", "image/webp"}:
            media_type = "image/png"
        prompt = self._build_router_image_description_prompt(
            source_name=source_name,
            document_context=str(item.get("document_context") or ""),
            figure_caption=str(item.get("figure_caption") or ""),
            expected_types=list(item.get("expected_types") or []),
        )
        logger.info(
            "Image description request queued: image={}, filename={}, page={}, expected_types={}",
            index + 1,
            item.get("filename"),
            item.get("page"),
            item.get("expected_types") or [],
        )
        try:
            payload = await self._vision.request_image_json(
                image_data=image_data,
                media_type=media_type,
                prompt=prompt,
                system_prompt=(
                    "You analyze one technical datasheet image and produce a detailed, evidence-grounded "
                    "English description. Enumerate as many distinct visible technical details as the image "
                    "supports without repetition or speculation. Exact labels and values may be included only "
                    "when they are clearly readable. Return strict JSON only."
                ),
                max_tokens=get_settings().DRIVER_DOCLING_IMAGE_DESCRIPTION_MAX_TOKENS,
                semaphore=semaphore,
                client=client,
                router_url=router_url,
                api_key=api_key,
                model=model,
                task_id=task_id,
                usage_source="docling_image_description",
                debug_dir=worker_dir,
                debug_prefix="summary_attempt_1",
            )
        except Exception as exc:
            return self._image_description_failure(index, item, result_path, str(exc))
        self._raise_if_cancelled(task_id)

        normalized = self._normalize_image_description_payload(payload)
        if normalized is None:
            return self._image_description_failure(
                index,
                item,
                result_path,
                "Router did not return a valid JSON image summary",
            )
        initial_title_audit = self._write_initial_title_audit(
            worker_dir,
            normalized,
        )
        validation_error = self._validate_image_description_payload(normalized, item)
        if validation_error:
            return self._image_description_failure(
                index,
                item,
                result_path,
                f"Router result rejected: {validation_error}",
                evidence={"initial_title_audit": initial_title_audit},
            )

        normalized, summary_audit = await self._verify_and_repair_image_summary(
            summary=normalized,
            item=item,
            image_data=image_data,
            media_type=media_type,
            semaphore=semaphore,
            client=client,
            router_url=router_url,
            api_key=api_key,
            model=model,
            task_id=task_id,
            debug_dir=worker_dir,
        )
        verified_facts: list[dict[str, Any]] = []
        detail_audit: dict[str, Any] = {
            "enabled": self._config.enable_image_detail_verification,
            "ocr_token_count": 0,
            "accepted_fact_count": 0,
            "rejected_facts": [],
            "summary_contains_precise_details": self._contains_unverified_summary_detail(
                normalized.get("description")
            ),
            "summary_verification": summary_audit,
        }
        if self._config.enable_image_detail_verification:
            try:
                self._raise_if_cancelled(task_id)
                ocr_tokens = await asyncio.to_thread(self._extract_image_ocr, image_path)
                self._raise_if_cancelled(task_id)
                detail_audit["ocr_token_count"] = len(ocr_tokens)
                ocr_path = worker_dir / "ocr.json"
                ocr_path.write_text(
                    json.dumps({"tokens": ocr_tokens}, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                detail_audit["ocr_path"] = str(ocr_path)
                usable_tokens = [
                    token
                    for token in ocr_tokens
                    if float(token.get("confidence") or 0.0) >= IMAGE_DETAIL_OCR_MIN_CONFIDENCE
                ]
                if usable_tokens:
                    detail_payload = await self._vision.request_image_json(
                        image_data=image_data,
                        media_type=media_type,
                        prompt=self._build_image_detail_verification_prompt(
                            summary=normalized,
                            ocr_tokens=usable_tokens,
                        ),
                        system_prompt=(
                            "You verify technical facts against one attached image and a server-owned OCR token list. "
                            "You may cite OCR token IDs but may not invent uncited facts. Return strict JSON only."
                        ),
                        max_tokens=get_settings().DRIVER_DOCLING_IMAGE_VERIFICATION_MAX_TOKENS,
                        semaphore=semaphore,
                        client=client,
                        router_url=router_url,
                        api_key=api_key,
                        model=model,
                        task_id=task_id,
                        usage_source="docling_image_detail_verification",
                        debug_dir=worker_dir,
                        debug_prefix="detail_verification",
                    )
                    self._raise_if_cancelled(task_id)
                    usable_tokens = await asyncio.to_thread(
                        self._enrich_ocr_tokens_with_local_candidates,
                        image_path,
                        usable_tokens,
                        detail_payload,
                    )
                    verified_facts, rejected_facts = self._validate_verified_facts(
                        detail_payload,
                        usable_tokens,
                        document_context=str(item.get("document_context") or ""),
                        document_vocabulary=item.get("document_vocabulary"),
                    )
                    detail_audit["accepted_fact_count"] = len(verified_facts)
                    detail_audit["rejected_facts"] = rejected_facts
            except Exception as exc:
                detail_audit["error"] = str(exc)
                logger.warning(
                    "Image detail verification skipped after failure: image={}, error={}",
                    index + 1,
                    exc,
                )

        normalized, removed_precise_sentences = self._sanitize_image_summary(
            normalized,
            item,
            verified_facts=verified_facts,
        )
        summary_audit["removed_precise_sentence_count"] = removed_precise_sentences
        detail_audit["summary_contains_precise_details"] = (
            self._contains_unverified_summary_detail(normalized.get("description"))
            or any(
                self._contains_unverified_summary_detail(point)
                for point in normalized.get("detail_points") or []
            )
        )
        type_warning = self._image_type_warning(normalized, item)
        if type_warning:
            summary_audit["type_warning"] = type_warning

        finalized = self._finalize_image_description(
            index,
            item,
            result_path,
            normalized,
            "Router",
            verified_facts=verified_facts,
            detail_verification=detail_audit,
            initial_title_audit=initial_title_audit,
        )
        detail_path = worker_dir / "detail_verification.json"
        try:
            detail_path.write_text(
                json.dumps(finalized.get("detail_verification") or {}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Failed to save image {} detail audit: {}", index + 1, exc)
        return finalized

    async def _describe_single_image(
        self,
        index: int,
        item: dict[str, Any],
        source_name: str,
        output_dir: Path,
        analysis_dir: Path,
        results_dir: Path,
        semaphore: asyncio.Semaphore,
        cli_path: str,
        model: str | None,
        monitor_factory: type,
        task_id: str | None = None,
    ) -> dict[str, Any]:
        """Run one isolated CLI task and return a server-owned result record."""
        self._raise_if_cancelled(task_id)
        worker_dir = results_dir / f"image_{index + 1:04d}"
        worker_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = worker_dir / IMAGE_MANIFEST_FILENAME
        result_path = worker_dir / IMAGE_DESCRIPTION_RESULT_FILENAME
        try:
            result_path.unlink(missing_ok=True)
        except OSError as exc:
            return self._image_description_failure(index, item, result_path, f"could not reset result file: {exc}")
        request = {
            "index": index,
            "filename": item.get("filename"),
            "path": str(Path(item["path"]).resolve()),
            "page": item.get("page"),
            "placeholder_index": item.get("placeholder_index"),
            "width": item.get("width"),
            "height": item.get("height"),
            "area": item.get("area"),
            "file_size": item.get("file_size"),
        }
        manifest_path.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
        prompt = self._build_image_description_prompt(
            manifest_path=manifest_path,
            output_path=result_path,
            source_name=source_name,
            image_count=1,
        )

        async with semaphore:
            try:
                loop = asyncio.get_running_loop()
                cli_result = await loop.run_in_executor(
                    None,
                    lambda: monitor_factory().execute_with_prodding(
                        cli_path=cli_path,
                        prompt=prompt,
                        system_prompt=(
                            "You are a technical datasheet image analyst. "
                            "Inspect exactly one image and output strict JSON only."
                        ),
                        model=model,
                        working_dir=worker_dir,
                        timeout=self._config.image_description_timeout,
                        activity_timeout=IMAGE_DESCRIPTION_ACTIVITY_TIMEOUT_SECONDS,
                        bypass_permissions=BYPASS_IMAGE_DESCRIPTION_PERMISSIONS,
                        allowed_dirs=[
                            str(output_dir.resolve()),
                            str(analysis_dir.resolve()),
                            str(worker_dir.resolve()),
                            str(Path(item["path"]).resolve().parent),
                        ],
                        task_id=task_id,
                    ),
                )
            except Exception as exc:
                return self._image_description_failure(index, item, result_path, str(exc))

        payload = self._read_image_description_payload(
            result_path,
            cli_result.get("output", "") if isinstance(cli_result, dict) else "",
        )
        if not isinstance(cli_result, dict) or cli_result.get("status") != "success":
            error = cli_result.get("error") if isinstance(cli_result, dict) else "unknown CLI error"
            if payload is None:
                return self._image_description_failure(index, item, result_path, error or "CLI failed")
        if payload is None:
            return self._image_description_failure(
                index,
                item,
                result_path,
                "Claude CLI did not produce a valid result.json payload",
            )

        return self._finalize_image_description(index, item, result_path, payload, "Claude CLI")

    def _finalize_image_description(
        self,
        index: int,
        item: dict[str, Any],
        result_path: Path,
        payload: Any,
        source: str,
        verified_facts: list[dict[str, Any]] | None = None,
        detail_verification: dict[str, Any] | None = None,
        initial_title_audit: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Normalize and validate a model result before it can reach Markdown."""
        normalized = self._normalize_image_description_payload(payload)
        if normalized is None:
            return self._image_description_failure(
                index,
                item,
                result_path,
                f"{source} result did not contain a valid description object",
            )
        if initial_title_audit is None:
            initial_title_audit = self._write_initial_title_audit(
                result_path.parent,
                normalized,
            )
        validation_error = self._validate_image_description_payload(normalized, item)
        if validation_error:
            return self._image_description_failure(
                index,
                item,
                result_path,
                f"{source} result rejected: {validation_error}",
                evidence={"initial_title_audit": initial_title_audit},
            )

        detail_audit = dict(detail_verification or {"enabled": False})
        normalized, removed_precise_items = self._sanitize_image_summary(
            normalized,
            item,
            verified_facts=verified_facts,
        )
        detail_audit.setdefault("removed_precise_item_count", removed_precise_items)
        normalized, hardening_audit = harden_image_summary(
            normalized,
            item,
            publishable_facts=list(verified_facts or []),
        )
        if not normalized.get("description"):
            normalized["description"] = self._safe_image_description(item, normalized)["description"]
        detail_audit["deterministic_hardening"] = hardening_audit
        detail_audit["summary_contains_precise_details"] = (
            self._contains_unverified_summary_detail(normalized.get("description"))
            or any(
                self._contains_unverified_summary_detail(point)
                for point in normalized.get("detail_points") or []
            )
        )

        # Identity fields always come from the server-side image mapping.
        normalized.update(
            {
                "status": "success",
                "index": index,
                "filename": item.get("filename"),
                "page": item.get("page"),
                "placeholder_index": item.get("placeholder_index"),
                "result_path": str(result_path),
                "expected_types": list(item.get("expected_types") or []),
                "publishable_facts": list(verified_facts or []),
                "verified_facts": list(verified_facts or []),
                "detail_verification": detail_audit,
                "initial_title_audit": initial_title_audit,
            }
        )
        try:
            result_path.write_text(
                json.dumps(normalized, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Failed to normalize image {} result: {}", index + 1, exc)
        logger.info(
            "Image description completed: image={}, filename={}, type={}, confidence={:.2f}",
            index + 1,
            item.get("filename"),
            normalized.get("type"),
            float((normalized.get("field_confidence") or {}).get("type") or 0.0),
        )
        return normalized

    @staticmethod
    def _image_description_failure(
        index: int,
        item: dict[str, Any],
        result_path: Path,
        error: str,
        evidence: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        failure = {
            "status": "failed",
            "index": index,
            "filename": item.get("filename"),
            "page": item.get("page"),
            "placeholder_index": item.get("placeholder_index"),
            "result_path": str(result_path),
            "error": str(error),
        }
        if evidence:
            failure.update(evidence)
        logger.warning(
            "Image description failed: image={}, filename={}, error={}",
            index + 1,
            item.get("filename"),
            error,
        )
        return failure

    @classmethod
    def _build_initial_title_audit(cls, payload: dict[str, Any]) -> dict[str, Any]:
        title = str(payload.get("title") or "").strip()
        matches = cls._summary_detail_matches(title)
        return {
            "initial_title": title,
            "matched_precise_values": matches,
            "contract_violation": bool(matches),
            "contract": (
                "Title must be a type-level searchable name. Alphanumeric model and "
                "package identifiers are allowed, but standalone engineering values, "
                "units, pin numbers, register addresses, and exact dimensions are not."
            ),
        }

    @classmethod
    def _write_initial_title_audit(
        cls,
        worker_dir: Path,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        audit = cls._build_initial_title_audit(payload)
        if audit["contract_violation"]:
            logger.warning(
                "Image title contract violation: title contains precise values: {}",
                audit["matched_precise_values"],
            )
        try:
            (worker_dir / INITIAL_TITLE_AUDIT_FILENAME).write_text(
                json.dumps(audit, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Failed to save initial title audit: {}", exc)
            audit["write_error"] = str(exc)
        return audit

    @staticmethod
    def _title_contract_violation_rate(items: list[dict[str, Any]]) -> float | None:
        audited = [item for item in items if item.get("initial_title_audit")]
        if not audited:
            return None
        violations = sum(
            1
            for item in audited
            if (item.get("initial_title_audit") or {}).get("contract_violation")
        )
        return round(violations / len(audited), 4)

    @staticmethod
    def _title_audits(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        audits = []
        for item in items:
            audit = item.get("initial_title_audit")
            if not audit:
                continue
            audits.append(
                {
                    "index": item.get("index"),
                    "filename": item.get("filename"),
                    "status": item.get("status"),
                    "initial_title": audit.get("initial_title"),
                    "matched_precise_values": audit.get("matched_precise_values", []),
                    "contract_violation": bool(audit.get("contract_violation")),
                    "final_title": item.get("title"),
                }
            )
        return sorted(audits, key=lambda item: (item.get("index") is None, item.get("index")))

    def _read_image_description_payload(self, result_path: Path, cli_output: str) -> Any:
        """Read a worker result file, with a small stdout fallback for CLI variants."""
        if result_path.exists():
            try:
                return json.loads(result_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                pass

        return self._vision.parse_json_response_text(cli_output)

    @staticmethod
    def _normalize_image_description_payload(payload: Any) -> dict[str, Any] | None:
        if isinstance(payload, dict) and isinstance(payload.get("descriptions"), list):
            payload = payload["descriptions"][0] if payload["descriptions"] else None
        elif isinstance(payload, list):
            payload = payload[0] if payload else None
        if not isinstance(payload, dict):
            return None

        raw_type = str(payload.get("type") or "other").strip().lower()
        normalized_type = re.sub(r"[\s-]+", "_", raw_type)
        type_aliases = {
            "blockdiagram": "block_diagram",
            "timingdiagram": "timing_diagram",
            "protocoldiagram": "protocol_diagram",
            "registertable": "register_table",
            "flow_chart": "flowchart",
            "circuit": "schematic",
            "chart": "plot",
            "layout": "pcb_layout",
            "pcb": "pcb_layout",
        }
        normalized_type = type_aliases.get(normalized_type, normalized_type)
        legacy_confidence = DriverDoclingImageDescriptionService._coerce_confidence(payload.get("confidence"))
        raw_field_confidence = payload.get("field_confidence") or {}
        if not isinstance(raw_field_confidence, dict):
            raw_field_confidence = {}
        field_confidence = {
            field: DriverDoclingImageDescriptionService._coerce_confidence(
                raw_field_confidence.get(field),
                legacy_confidence,
            )
            for field in ("type", "title", "description")
        }
        detail_point_records = DriverDoclingImageDescriptionService._normalize_detail_point_records(
            payload.get("detail_point_records") or payload.get("detail_points")
        )
        return {
            "type": normalized_type,
            "title": str(payload.get("title") or ""),
            "description": str(payload.get("description") or ""),
            "detail_points": [record["text"] for record in detail_point_records],
            "detail_point_records": detail_point_records,
            "field_confidence": field_confidence,
        }

    @classmethod
    def _normalize_detail_point_records(cls, value: Any) -> list[dict[str, Any]]:
        if not isinstance(value, list):
            return []

        normalized: list[dict[str, Any]] = []
        seen: set[str] = set()
        seen_ids: set[str] = set()
        for index, raw_point in enumerate(value, start=1):
            if isinstance(raw_point, dict):
                point = str(raw_point.get("text") or "").strip()
                raw_id = str(raw_point.get("id") or "").strip().upper()
                claim_type = str(raw_point.get("claim_type") or "").strip().lower()
                contains_precise_fact = bool(raw_point.get("contains_precise_fact"))
                raw_claims = raw_point.get("claims") or []
                verification_status = str(raw_point.get("verification_status") or "").strip().lower()
                verification_confidence = cls._coerce_confidence(
                    raw_point.get("verification_confidence")
                )
            else:
                point = str(raw_point or "").strip()
                raw_id = ""
                claim_type = ""
                contains_precise_fact = False
                raw_claims = []
                verification_status = ""
                verification_confidence = None
            dedupe_key = re.sub(r"\s+", " ", point).casefold()
            if not point or dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            point_id = raw_id if re.fullmatch(r"D\d+", raw_id) else f"D{index}"
            if point_id in seen_ids:
                point_id = f"D{index}"
            while point_id in seen_ids:
                point_id = f"D{len(seen_ids) + 1}"
            seen_ids.add(point_id)
            inferred_precise = cls._contains_unverified_summary_detail(point)
            record = {
                "id": point_id,
                "text": point,
                "claim_type": claim_type or cls._infer_detail_claim_type(point),
                "contains_precise_fact": contains_precise_fact or inferred_precise,
                "claims": [
                    {
                        "type": str(claim.get("type") or "other").strip().lower(),
                        "value": str(claim.get("value") or "").strip(),
                        "unit": str(claim.get("unit") or "").strip(),
                    }
                    for claim in raw_claims
                    if isinstance(claim, dict) and str(claim.get("value") or "").strip()
                ],
            }
            if verification_status:
                record["verification_status"] = verification_status
            if verification_confidence is not None:
                record["verification_confidence"] = verification_confidence
            normalized.append(record)
        return normalized

    @classmethod
    def _normalize_detail_points(cls, value: Any) -> list[str]:
        return [record["text"] for record in cls._normalize_detail_point_records(value)]

    @classmethod
    def _infer_detail_claim_type(cls, text: str) -> str:
        if cls._contains_unverified_summary_detail(text):
            return "precise"
        if re.search(r"\b(?:signal|pin|register|address|dimension|voltage|current|frequency)\b", text, re.IGNORECASE):
            return "technical_label"
        if re.search(r"\b(?:before|after|between|aligned|connected|flows?|transitions?|relative)\b", text, re.IGNORECASE):
            return "relationship"
        return "structure"

    @staticmethod
    def _coerce_confidence(value: Any, default: float | None = None) -> float | None:
        return coerce_confidence(value, default)

    @staticmethod
    def _validate_image_description_payload(
        payload: dict[str, Any],
        item: dict[str, Any],
    ) -> str | None:
        image_type = str(payload.get("type") or "").strip().lower()
        if image_type not in IMAGE_DESCRIPTION_TYPES:
            return f"unsupported image type '{image_type}'"
        title = str(payload.get("title") or "").strip()
        if not title:
            return "title is empty"
        description = str(payload.get("description") or "").strip()
        if not description:
            return "description is empty"
        detail_points = payload.get("detail_points", [])
        if detail_points is None:
            detail_points = []
        if not isinstance(detail_points, list):
            return "detail_points must be an array"
        if any(not isinstance(point, str) or not point.strip() for point in detail_points):
            return "detail_points contains an empty or non-string item"
        if DriverDoclingImageDescriptionService._contains_unverified_summary_detail(title):
            return "summary title contains unverified pins, registers, dimensions, or numeric values"

        field_confidence = payload.get("field_confidence") or {}
        confidence = field_confidence.get("type") if isinstance(field_confidence, dict) else None
        if not isinstance(confidence, (int, float)) or isinstance(confidence, bool):
            return "confidence is missing or not numeric"
        if not 0.0 <= float(confidence) <= 1.0:
            return "confidence must be between 0 and 1"
        if float(confidence) < IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            return (
                f"confidence {float(confidence):.2f} is below "
                f"{IMAGE_DESCRIPTION_MIN_CONFIDENCE:.2f}"
            )
        description_confidence = (
            field_confidence.get("description") if isinstance(field_confidence, dict) else None
        )
        if not isinstance(description_confidence, (int, float)) or isinstance(description_confidence, bool):
            return "description confidence is missing or not numeric"
        if float(description_confidence) < IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            return (
                f"description confidence {float(description_confidence):.2f} is below "
                f"{IMAGE_DESCRIPTION_MIN_CONFIDENCE:.2f}"
            )
        title_confidence = field_confidence.get("title") if isinstance(field_confidence, dict) else None
        if not isinstance(title_confidence, (int, float)) or isinstance(title_confidence, bool):
            return "title confidence is missing or not numeric"
        if float(title_confidence) < IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            return (
                f"title confidence {float(title_confidence):.2f} is below "
                f"{IMAGE_DESCRIPTION_MIN_CONFIDENCE:.2f}"
            )

        return None

    @staticmethod
    def _image_type_warning(
        payload: dict[str, Any],
        item: dict[str, Any],
    ) -> str | None:
        image_type = str(payload.get("type") or "").strip().lower()
        expected_types = {
            str(value).strip().lower()
            for value in item.get("expected_types") or []
            if str(value).strip()
        }
        if expected_types and image_type not in expected_types:
            return (
                f"type '{image_type}' conflicts with nearby document context; "
                f"expected one of {sorted(expected_types)}"
            )
        return None

    @classmethod
    def _contains_unverified_summary_detail(cls, value: Any) -> bool:
        return bool(cls._summary_detail_matches(value))

    @staticmethod
    def _raise_if_cancelled(task_id: str | None) -> None:
        if task_id and is_task_cancelled(task_id):
            raise asyncio.CancelledError(
                f"Task {task_id} cancelled during Docling image description"
            )

    @staticmethod
    def _summary_detail_matches(value: Any) -> list[str]:
        text = str(value or "")
        text = (
            text.replace(unicodedata.lookup("MICRO SIGN"), "u")
            .replace(unicodedata.lookup("GREEK SMALL LETTER MU"), "u")
            .replace(unicodedata.lookup("OHM SIGN"), "Ohm")
            .replace(unicodedata.lookup("GREEK CAPITAL LETTER OMEGA"), "Ohm")
            .replace(unicodedata.lookup("DEGREE SIGN"), "deg")
        )
        text = re.sub(r"deg\s*C\b", "degC", text, flags=re.IGNORECASE)
        detail_patterns = (
            r"(?i)\b0x[0-9a-f]+\b",
            r"(?i)pin\s*\d+\s*[:=]",
            r"(?i)\bREG(?:ISTER)?[_\s-]*(?:0x)?[0-9a-f]{1,4}\b",
            (
                r"(?i)(?<![A-Z])\d+(?:\.\d+)?\s*(?:-|to|~)?\s*"
                r"\d*(?:\.\d+)?\s*(?:mV|V|mA|A|uA|nF|uF|pF|"
                r"ns|us|ms|kOhm|ohm|mm|cm|MHz|kHz|Hz|degC|%)(?![A-Za-z0-9])"
            ),
        )
        return [
            match.group(0)
            for pattern in detail_patterns
            for match in re.finditer(pattern, text)
        ]

    async def _verify_and_repair_image_summary(
        self,
        *,
        summary: dict[str, Any],
        item: dict[str, Any],
        image_data: str,
        media_type: str,
        semaphore: asyncio.Semaphore,
        client: httpx.AsyncClient,
        router_url: str,
        api_key: str,
        model: str,
        task_id: str | None = None,
        debug_dir: str | Path | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self._raise_if_cancelled(task_id)
        current = dict(summary)
        records = self._normalize_detail_point_records(
            current.get("detail_point_records") or current.get("detail_points")
        )
        current["detail_point_records"] = records
        current["detail_points"] = [record["text"] for record in records]
        audit: dict[str, Any] = {"enabled": True, "detail_results": []}

        try:
            response = await self._vision.request_image_json(
                image_data=image_data,
                media_type=media_type,
                prompt=self._build_image_summary_verification_prompt(current, item),
                system_prompt=(
                    "You verify one technical image summary point by point against the attached pixels "
                    "and nearest figure caption. Preserve supported details, correct only what is visibly "
                    "grounded, and reject unsupported claims. Return strict JSON only."
                ),
                max_tokens=get_settings().DRIVER_DOCLING_IMAGE_VERIFICATION_MAX_TOKENS,
                semaphore=semaphore,
                client=client,
                router_url=router_url,
                api_key=api_key,
                model=model,
                task_id=task_id,
                usage_source="docling_image_summary_verification",
                debug_dir=debug_dir,
                debug_prefix="summary_verification",
            )
        except Exception as exc:
            audit["error"] = str(exc)
            return self._summary_verification_fallback(item, current, audit)
        self._raise_if_cancelled(task_id)

        if not isinstance(response, dict):
            audit["error"] = "point verification response is not an object"
            return self._summary_verification_fallback(item, current, audit)

        fallback = self._safe_image_description(item, current)
        current["type"], type_audit = self._apply_verified_summary_field(
            original=str(current.get("type") or "other"),
            result=response.get("image_type"),
            corrected_key="corrected_type",
            fallback=str(fallback.get("type") or "other"),
            allowed_values=IMAGE_DESCRIPTION_TYPES,
        )
        current["title"], title_audit = self._apply_verified_summary_field(
            original=str(current.get("title") or ""),
            result=response.get("title"),
            corrected_key="corrected_title",
            fallback=str(fallback.get("title") or "Image Structure Overview"),
        )
        current["description"], overview_audit = self._apply_verified_summary_field(
            original=str(current.get("description") or ""),
            result=response.get("overview"),
            corrected_key="corrected_description",
            fallback=str(fallback.get("description") or ""),
        )
        audit.update(
            {
                "image_type": type_audit,
                "title": title_audit,
                "overview": overview_audit,
            }
        )

        raw_results = response.get("detail_results")
        result_by_id = {
            str(result.get("id") or "").strip().upper(): result
            for result in raw_results or []
            if isinstance(result, dict) and str(result.get("id") or "").strip()
        } if isinstance(raw_results, list) else {}

        accepted_records: list[dict[str, Any]] = []
        for record in records:
            point_id = str(record.get("id") or "").upper()
            result = result_by_id.get(point_id)
            point_audit = self._apply_detail_verification_result(record, result)
            audit["detail_results"].append(point_audit)
            if point_audit["status"] not in {"accepted", "corrected"}:
                continue
            accepted_records.append(
                {
                    **record,
                    "text": point_audit["text"],
                    "verification_status": point_audit["status"],
                    "verification_confidence": point_audit["confidence"],
                }
            )

        if not accepted_records:
            audit["reason"] = "no detail point passed point-level verification"
            return self._summary_verification_fallback(item, current, audit)

        current["detail_point_records"] = accepted_records
        current["detail_points"] = [record["text"] for record in accepted_records]
        original_confidence = current.get("field_confidence") or {}
        fallback_confidence = fallback.get("field_confidence") or {}
        current["field_confidence"] = {
            "type": (
                fallback_confidence.get("type")
                if type_audit["status"] == "rejected"
                else type_audit["confidence"] or original_confidence.get("type")
            ),
            "title": (
                fallback_confidence.get("title")
                if title_audit["status"] == "rejected"
                else title_audit["confidence"] or original_confidence.get("title")
            ),
            "description": (
                fallback_confidence.get("description")
                if overview_audit["status"] == "rejected"
                else overview_audit["confidence"] or original_confidence.get("description")
            ),
        }
        rejected_count = sum(
            result["status"] == "rejected" for result in audit["detail_results"]
        )
        corrected_count = sum(
            result["status"] == "corrected" for result in audit["detail_results"]
        )
        audit["accepted_detail_count"] = len(accepted_records)
        audit["rejected_detail_count"] = rejected_count
        audit["corrected_detail_count"] = corrected_count
        audit["status"] = (
            "verified"
            if not rejected_count
            and not corrected_count
            and all(
                field["status"] == "accepted"
                for field in (type_audit, title_audit, overview_audit)
            )
            else "partially_verified"
        )
        return current, audit

    @classmethod
    def _apply_verified_summary_field(
        cls,
        *,
        original: str,
        result: Any,
        corrected_key: str,
        fallback: str,
        allowed_values: frozenset[str] | None = None,
    ) -> tuple[str, dict[str, Any]]:
        result = result if isinstance(result, dict) else {}
        status = str(result.get("status") or "rejected").strip().lower()
        confidence = cls._coerce_confidence(result.get("confidence"))
        corrected = str(result.get(corrected_key) or "").strip()
        if status == "accepted" and confidence is not None and confidence >= IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            value = original
        elif status == "corrected" and corrected and confidence is not None and confidence >= IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            value = corrected
        else:
            status = "rejected"
            value = fallback
        if allowed_values is not None:
            normalized_value = value.strip().lower().replace("-", "_").replace(" ", "_")
            if normalized_value in allowed_values:
                value = normalized_value
            else:
                status = "rejected"
                value = fallback
        return value, {
            "status": status,
            "confidence": confidence,
            "reason": str(result.get("reason") or ""),
        }

    @classmethod
    def _apply_detail_verification_result(
        cls,
        record: dict[str, Any],
        result: Any,
    ) -> dict[str, Any]:
        result = result if isinstance(result, dict) else {}
        status = str(result.get("status") or "rejected").strip().lower()
        confidence = cls._coerce_confidence(result.get("confidence"))
        corrected_text = str(result.get("corrected_text") or "").strip()
        text = str(record.get("text") or "").strip()
        if status == "accepted" and confidence is not None and confidence >= IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            output_text = text
        elif status == "corrected" and corrected_text and confidence is not None and confidence >= IMAGE_DESCRIPTION_MIN_CONFIDENCE:
            output_text = corrected_text
        else:
            status = "rejected"
            output_text = ""
        return {
            "id": record.get("id"),
            "status": status,
            "text": output_text,
            "confidence": confidence,
            "reason": str(result.get("reason") or ""),
        }

    @classmethod
    def _summary_verification_fallback(
        cls,
        item: dict[str, Any],
        current: dict[str, Any],
        audit: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        fallback = cls._safe_image_description(item, current)
        audit["status"] = (
            "context_grounded"
            if item.get("figure_caption") or item.get("expected_types") or item.get("document_context")
            else "visual_grounded"
        )
        return fallback, audit

    @staticmethod
    def _build_image_summary_verification_prompt(
        summary: dict[str, Any],
        item: dict[str, Any],
    ) -> str:
        detail_records = DriverDoclingImageDescriptionService._normalize_detail_point_records(
            summary.get("detail_point_records") or summary.get("detail_points")
        )
        candidate = {
            "type": summary.get("type"),
            "title": summary.get("title"),
            "description": summary.get("description"),
            "detail_points": detail_records,
        }
        return f"""Verify this proposed summary point by point against the attached technical image.

Nearest figure caption: {item.get('figure_caption') or '(none)'}
Expected types inferred from nearby text (advisory only): {item.get('expected_types') or []}
Nearby document context:
---
{item.get('document_context') or '(none)'}
---
Candidate summary with stable detail IDs:
{json.dumps(candidate, ensure_ascii=False)}

Evaluate the image type, title, overview, and every detail independently. Do not reject the whole
summary because one detail is wrong. Use accepted when the original text is fully supported,
corrected only when the replacement is directly visible, and rejected when the claim is unsupported.
Exact labels and values may remain in corrected text only when clearly readable; the server performs
a separate OCR-backed fact check before publishing them. Return one result for every supplied ID.

Return exactly this schema:
{{
  "image_type": {{
    "status": "accepted|corrected|rejected",
    "corrected_type": "supported image type or empty string",
    "confidence": 0.0,
    "reason": "evidence-based reason"
  }},
  "title": {{
    "status": "accepted|corrected|rejected",
    "corrected_title": "grounded English title or empty string",
    "confidence": 0.0,
    "reason": "evidence-based reason"
  }},
  "overview": {{
    "status": "accepted|corrected|rejected",
    "corrected_description": "grounded detailed overview or empty string",
    "confidence": 0.0,
    "reason": "evidence-based reason"
  }},
  "detail_results": [
    {{
      "id": "D1",
      "status": "accepted|corrected|rejected",
      "corrected_text": "replacement text only when corrected, otherwise empty string",
      "confidence": 0.0,
      "reason": "specific visual evidence or rejection reason"
    }}
  ]
}}
"""

    @classmethod
    def _safe_image_description(
        cls,
        item: dict[str, Any],
        candidate: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        caption = str(item.get("figure_caption") or "").strip()
        context = str(item.get("document_context") or "").strip()
        caption_types = cls._expected_image_types(caption)
        expected_types = caption_types or {
            str(value).strip().lower()
            for value in item.get("expected_types") or []
            if str(value).strip()
        }
        if not expected_types:
            expected_types = cls._expected_image_types(context)
        priority = (
            "flowchart",
            "timing_diagram",
            "plot",
            "pcb_layout",
            "package",
            "schematic",
            "block_diagram",
            "protocol_diagram",
            "waveform",
            "pinout",
            "register_table",
        )
        candidate_type = str((candidate or {}).get("type") or "").strip().lower()
        image_type = next(
            (value for value in priority if value in expected_types),
            candidate_type if candidate_type in IMAGE_DESCRIPTION_TYPES else "other",
        )

        # Keep the document's own figure title whenever it is available. The
        # fallback rules below classify the image; they must not rename it to
        # a device-specific title from a different datasheet.
        title = re.sub(
            r"^Figure\s*\d+(?:[-.]\d+)*(?:[.:\s]|$)\s*",
            "",
            caption,
            flags=re.IGNORECASE,
        ).strip()
        if not title:
            candidate_title = str((candidate or {}).get("title") or "").strip()
            title = candidate_title if candidate_title and candidate_title != "Technical Figure" else ""

        type_descriptions = {
            "flowchart": "Shows the processing nodes, branch conditions, and connections between nodes.",
            "timing_diagram": "Shows how multiple signals change over time and their relative ordering.",
            "plot": "Shows the axes, curves, and overall parameter trends along the horizontal axis.",
            "pcb_layout": "Shows the relative positions and layout relationships of PCB pads or component areas.",
            "package": "Shows the package outline and the relative positions of balls or pins.",
            "schematic": "Shows the main circuit components, connections, and signal paths.",
            "block_diagram": "Shows the functional blocks and data or control relationships between them.",
            "protocol_diagram": "Shows the timing relationship between communication signals and data-transfer stages.",
            "waveform": "Shows the overall characteristics of a waveform as time or conditions change.",
            "pinout": "Shows the arrangement and functional grouping of device pins or package balls.",
            "register_table": "Shows register fields, bit fields, and their layout structure.",
            "other": "Shows the main graphics, text labels, and relative positions of elements in the figure.",
        }
        type_detail_points = {
            "flowchart": [
                "Processing nodes and branch conditions form the main structure.",
                "Directed connections indicate the order of execution or transition.",
            ],
            "timing_diagram": [
                "Multiple signal traces are aligned to a common time axis.",
                "Transitions and active intervals show relative timing relationships.",
            ],
            "plot": [
                "Axes define the compared variables.",
                "Curves show how the measured parameter changes across the plotted range.",
            ],
            "pcb_layout": [
                "Pads, components, or routing regions are shown by relative position.",
                "Orientation and spacing relationships define the layout structure.",
            ],
            "package": [
                "The external package outline is visible.",
                "Pins or balls are arranged relative to package orientation marks.",
            ],
            "schematic": [
                "Circuit symbols represent the main electrical components.",
                "Nets and labels indicate power, control, and signal paths.",
            ],
            "block_diagram": [
                "Functional blocks divide the system into major responsibilities.",
                "Connections show data, signal, or control flow between blocks.",
            ],
            "protocol_diagram": [
                "Communication signals are aligned by transfer stage.",
                "Transitions indicate the relative order of protocol events.",
            ],
            "waveform": [
                "The trace shows signal behavior over time or operating conditions.",
                "Transitions and stable regions define the waveform structure.",
            ],
            "pinout": [
                "Pins or balls are organized by physical position.",
                "Visible labels indicate functional grouping when readable.",
            ],
            "register_table": [
                "Rows and columns organize registers or bit fields.",
                "Visible labels indicate field grouping and access structure.",
            ],
            "other": [
                "The figure contains graphics, labels, and spatial relationships.",
                "Only clearly visible structural information is retained.",
            ],
        }
        fallback_title = {
            "flowchart": "Flowchart Overview",
            "timing_diagram": "Timing Diagram Overview",
            "plot": "Parameter Plot",
            "pcb_layout": "PCB Layout",
            "package": "Package Structure",
            "schematic": "Circuit Schematic",
            "block_diagram": "System Block Diagram",
            "protocol_diagram": "Protocol Timing Diagram",
            "waveform": "Signal Waveform",
            "pinout": "Pin Configuration",
            "register_table": "Register Structure",
            "other": "Image Structure Overview",
        }.get(image_type, "Image Structure Overview")
        title = title or fallback_title
        description = (
            type_descriptions.get(image_type, type_descriptions["other"])
        )
        return {
            "type": image_type,
            "title": title[:80],
            "description": description,
            "detail_points": list(type_detail_points.get(image_type, type_detail_points["other"])),
            "field_confidence": {
                "type": 0.8 if image_type != "other" else IMAGE_DESCRIPTION_MIN_CONFIDENCE,
                "title": 0.95,
                "description": 0.95,
            },
        }

    @classmethod
    def _sanitize_image_summary(
        cls,
        summary: dict[str, Any],
        item: dict[str, Any],
        verified_facts: list[dict[str, Any]] | None = None,
    ) -> tuple[dict[str, Any], int]:
        description = str(summary.get("description") or "").strip()
        sentences = [
            sentence.strip()
            for sentence in re.split(r"(?<=[!?])\s*|(?<!\d)\.\s+", description)
            if sentence.strip()
        ]
        safe_sentences = [
            sentence for sentence in sentences
            if not cls._contains_unverified_summary_detail(sentence)
            or cls._all_precise_details_are_verified(sentence, verified_facts)
        ]
        detail_points = cls._normalize_detail_points(summary.get("detail_points"))
        safe_detail_points = [
            point for point in detail_points
            if not cls._contains_unverified_summary_detail(point)
            or cls._all_precise_details_are_verified(point, verified_facts)
        ]
        removed_count = (
            len(sentences) - len(safe_sentences)
            + len(detail_points) - len(safe_detail_points)
        )
        if removed_count == 0:
            return summary, 0

        sanitized = dict(summary)
        sanitized_description = " ".join(safe_sentences).strip()
        if not sanitized_description:
            sanitized_description = cls._safe_image_description(item)["description"]
        sanitized["description"] = sanitized_description
        sanitized["detail_points"] = safe_detail_points
        safe_text = {point.casefold() for point in safe_detail_points}
        sanitized["detail_point_records"] = [
            record
            for record in cls._normalize_detail_point_records(
                summary.get("detail_point_records") or summary.get("detail_points")
            )
            if str(record.get("text") or "").casefold() in safe_text
        ]
        return sanitized, removed_count

    @classmethod
    def _all_precise_details_are_verified(
        cls,
        text: str,
        verified_facts: list[dict[str, Any]] | None,
    ) -> bool:
        detail_matches = cls._summary_detail_matches(text)
        if not detail_matches:
            return True

        normalized_facts: list[str] = []
        for fact in verified_facts or []:
            if not isinstance(fact, dict):
                continue
            fact_text = " ".join(
                str(fact.get(field) or "")
                for field in ("label", "value", "unit")
            )
            normalized_fact = cls._normalize_fact_text(fact_text)
            if normalized_fact:
                normalized_facts.append(normalized_fact)

        return bool(normalized_facts) and all(
            any(
                normalized_match in normalized_fact
                for normalized_fact in normalized_facts
            )
            for normalized_match in (
                cls._normalize_fact_text(detail_match)
                for detail_match in detail_matches
            )
            if normalized_match
        )

    def _extract_image_ocr(self, image_path: Path) -> list[dict[str, Any]]:
        """Run the configured offline OCR engine once and return text evidence."""
        global _IMAGE_OCR_READER, _IMAGE_OCR_ENGINE

        with _IMAGE_OCR_LOCK:
            if _IMAGE_OCR_READER is None:
                engine = str(getattr(self._config, "ocr_engine", "easyocr")).lower()
                if engine == "rapidocr":
                    from rapidocr import EngineType, RapidOCR

                    rapidocr_root = Path(self._config.artifacts_path) / "RapidOcr"
                    _IMAGE_OCR_READER = RapidOCR(
                        params={
                            "Det.model_path": str(rapidocr_root / "onnx" / "PP-OCRv4" / "det" / "ch_PP-OCRv4_det_infer.onnx"),
                            "Cls.model_path": str(rapidocr_root / "onnx" / "PP-OCRv4" / "cls" / "ch_ppocr_mobile_v2.0_cls_infer.onnx"),
                            "Rec.model_path": str(rapidocr_root / "onnx" / "PP-OCRv4" / "rec" / "ch_PP-OCRv4_rec_infer.onnx"),
                            "Rec.rec_keys_path": str(rapidocr_root / "paddle" / "PP-OCRv4" / "rec" / "ch_PP-OCRv4_rec_infer" / "ppocr_keys_v1.txt"),
                            "Global.font_path": str(rapidocr_root / "fonts" / "FZYTK.TTF"),
                            "Det.engine_type": EngineType.ONNXRUNTIME,
                            "Cls.engine_type": EngineType.ONNXRUNTIME,
                            "Rec.engine_type": EngineType.ONNXRUNTIME,
                            "Det.use_dml": False,
                            "Cls.use_dml": False,
                            "Rec.use_dml": False,
                        },
                    )
                    _IMAGE_OCR_ENGINE = engine
                    raw_results = _IMAGE_OCR_READER(image_path)
                else:
                    import easyocr

                    _IMAGE_OCR_READER = easyocr.Reader(
                        list(self._config.ocr_languages),
                        gpu=False,
                        model_storage_directory=str(self._config.artifacts_path / "EasyOCR"),
                        download_enabled=False,
                        verbose=False,
                    )
                    _IMAGE_OCR_ENGINE = "easyocr"
                    raw_results = _IMAGE_OCR_READER.readtext(
                        str(image_path), detail=1, paragraph=False, decoder="greedy",
                        canvas_size=2560, mag_ratio=2.0,
                    )
            elif _IMAGE_OCR_ENGINE == "rapidocr":
                raw_results = _IMAGE_OCR_READER(image_path)
            else:
                raw_results = _IMAGE_OCR_READER.readtext(
                    str(image_path), detail=1, paragraph=False, decoder="greedy",
                    canvas_size=2560, mag_ratio=2.0,
                )

        if _IMAGE_OCR_ENGINE == "rapidocr":
            raw_results = _rapidocr_output_to_results(raw_results)

        tokens: list[dict[str, Any]] = []
        for raw in raw_results or []:
            if not isinstance(raw, (list, tuple)) or len(raw) < 3:
                continue
            bbox, text_value, confidence_value = raw[:3]
            text_value = str(text_value or "").strip()
            confidence = self._coerce_confidence(confidence_value)
            if not text_value or confidence is None:
                continue
            normalized_bbox: list[list[float]] = []
            for point in bbox if bbox is not None else []:
                point_values = point.tolist() if hasattr(point, "tolist") else point
                if isinstance(point_values, (list, tuple)) and len(point_values) >= 2:
                    normalized_bbox.append(
                        [round(float(point_values[0]), 2), round(float(point_values[1]), 2)]
                    )
            tokens.append(
                {
                    "id": len(tokens),
                    "text": text_value,
                    "confidence": round(confidence, 4),
                    "bbox": normalized_bbox,
                }
            )
        return tokens

    def _enrich_ocr_tokens_with_local_candidates(
        self,
        image_path: Path,
        ocr_tokens: list[dict[str, Any]],
        detail_payload: Any,
    ) -> list[dict[str, Any]]:
        """Re-read only OCR regions cited by the visual fact extractor."""
        facts = detail_payload.get("facts") if isinstance(detail_payload, dict) else None
        if not isinstance(facts, list):
            return ocr_tokens

        referenced_ids: list[int] = []
        for fact in facts:
            if not isinstance(fact, dict):
                continue
            for raw_id in fact.get("evidence_ids") or []:
                try:
                    token_id = int(raw_id)
                except (TypeError, ValueError):
                    continue
                if token_id not in referenced_ids:
                    referenced_ids.append(token_id)
        referenced_ids = referenced_ids[:IMAGE_LOCAL_OCR_MAX_TOKENS]
        if not referenced_ids:
            return ocr_tokens

        token_by_id = {
            int(token["id"]): dict(token)
            for token in ocr_tokens
            if isinstance(token, dict) and token.get("id") is not None
        }
        try:
            import numpy as np
            from PIL import Image

            image = Image.open(image_path).convert("RGB")
        except Exception as exc:
            logger.warning("Local OCR image preparation failed: {}", exc)
            return ocr_tokens

        allowlist = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_/-+().:%~"
        global _IMAGE_OCR_READER, _IMAGE_OCR_ENGINE
        with _IMAGE_OCR_LOCK:
            if _IMAGE_OCR_READER is None:
                return ocr_tokens
            for token_id in referenced_ids:
                token = token_by_id.get(token_id)
                bbox = token.get("bbox") if token else None
                if not token or not isinstance(bbox, list) or len(bbox) < 2:
                    continue
                try:
                    xs = [float(point[0]) for point in bbox if len(point) >= 2]
                    ys = [float(point[1]) for point in bbox if len(point) >= 2]
                    left = max(0, int(min(xs)) - 3)
                    top = max(0, int(min(ys)) - 3)
                    right = min(image.width, int(max(xs)) + 4)
                    bottom = min(image.height, int(max(ys)) + 4)
                except (TypeError, ValueError):
                    continue
                if right - left < 3 or bottom - top < 3:
                    continue
                crop = np.asarray(image.crop((left, top, right, bottom)))
                try:
                    if _IMAGE_OCR_ENGINE == "rapidocr":
                        local_output = _IMAGE_OCR_READER(crop)
                        local_results = _rapidocr_output_to_results(local_output)
                    else:
                        local_results = _IMAGE_OCR_READER.readtext(
                            crop, detail=1, paragraph=False, decoder="beamsearch",
                            allowlist=allowlist, canvas_size=1024, mag_ratio=1.0,
                        )
                except Exception as exc:
                    logger.debug("Local OCR failed for token {}: {}", token_id, exc)
                    continue

                candidates: list[dict[str, Any]] = []
                seen: set[str] = set()
                for raw in local_results or []:
                    if not isinstance(raw, (list, tuple)) or len(raw) < 3:
                        continue
                    text_value = str(raw[1] or "").strip()
                    confidence = self._coerce_confidence(raw[2])
                    key = self._normalize_fact_text(text_value)
                    if not key or confidence is None or key in seen:
                        continue
                    seen.add(key)
                    candidates.append(
                        {
                            "text": text_value,
                            "confidence": round(float(confidence), 4),
                        }
                    )
                candidates.sort(key=lambda candidate: candidate["confidence"], reverse=True)
                token["local_candidates"] = candidates[:3]

        return [token_by_id.get(int(token.get("id")), token) for token in ocr_tokens]

    @staticmethod
    def _build_image_detail_verification_prompt(
        summary: dict[str, Any],
        ocr_tokens: list[dict[str, Any]],
    ) -> str:
        token_payload = [
            {
                "id": token.get("id"),
                "text": token.get("text"),
                "confidence": token.get("confidence"),
                "bbox": token.get("bbox"),
            }
            for token in ocr_tokens[:200]
        ]
        return f"""Verify technical facts visible in the attached datasheet image.

Broad summary (not evidence):
{json.dumps({"type": summary.get("type"), "title": summary.get("title")}, ensure_ascii=False)}

Server-owned OCR tokens (the only admissible textual evidence):
{json.dumps(token_payload, ensure_ascii=False)}

Return only facts that are directly supported by both the pixels and cited OCR token IDs.
Allowed fact types: pin, register, dimension, numeric, signal, component_value, device_model.
Do not return broad concepts, inferred operating ranges, derived values, or facts copied only from context.
For pin mappings, cite both the pin number token and signal-name token.
For dimensions and numeric values, cite the exact visible value token and unit token when separate.
If no exact fact is safely supported, return an empty facts array.
Return at most 30 high-confidence facts. Keep labels concise and do not add explanations.

Return exactly:
{{
  "facts": [
    {{
      "fact_type": "pin|register|dimension|numeric|signal|component_value|device_model",
      "label": "English field name",
      "value": "exact visible value",
      "unit": "exact visible unit or empty string",
      "evidence_ids": [0, 1],
      "visual_confidence": 0.0
    }}
  ]
}}
"""

    @staticmethod
    def _normalize_fact_text(value: Any) -> str:
        return "".join(
            character.lower()
            for character in str(value or "")
            if character.isalnum()
        )

    @classmethod
    def _validate_verified_facts(
        cls,
        payload: Any,
        ocr_tokens: list[dict[str, Any]],
        document_context: str = "",
        document_vocabulary: dict[str, Any] | None = None,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        facts = payload.get("facts") if isinstance(payload, dict) else None
        if not isinstance(facts, list):
            return [], [{"reason": "detail response did not contain a facts array"}]

        token_by_id = {
            int(token["id"]): token
            for token in ocr_tokens
            if isinstance(token, dict) and token.get("id") is not None
        }
        vocabulary = document_vocabulary or build_document_vocabulary(document_context)
        allowed_types = {
            "pin",
            "register",
            "dimension",
            "numeric",
            "signal",
            "component_value",
            "device_model",
        }
        accepted: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []
        seen: set[tuple[str, str, str]] = set()

        for raw_fact in facts[:30]:
            if not isinstance(raw_fact, dict):
                rejected.append({"reason": "fact is not an object"})
                continue
            fact_type = str(raw_fact.get("fact_type") or "").strip().lower()
            label = str(raw_fact.get("label") or "").strip()
            value = str(raw_fact.get("value") or "").strip()
            unit = str(raw_fact.get("unit") or "").strip()
            evidence_ids = raw_fact.get("evidence_ids") or []
            visual_confidence = cls._coerce_confidence(raw_fact.get("visual_confidence"))
            reason = ""
            if fact_type not in allowed_types:
                reason = "unsupported fact type"
            elif not label or not value:
                reason = "label or value is empty"
            elif not isinstance(evidence_ids, list) or not evidence_ids:
                reason = "evidence_ids is empty"
            elif visual_confidence is None:
                reason = "visual_confidence is invalid"

            resolved_tokens: list[dict[str, Any]] = []
            if not reason:
                try:
                    resolved_tokens = [token_by_id[int(token_id)] for token_id in evidence_ids]
                except (KeyError, TypeError, ValueError):
                    reason = "evidence references an unknown OCR token"

            if not reason and fact_type in {"pin", "register"}:
                evidence_text = " ".join(str(token.get("text") or "") for token in resolved_tokens)
                normalized_evidence = cls._normalize_fact_text(evidence_text)
                if not cls._normalize_fact_text(value):
                    reason = "fact value is empty after normalization"
                else:
                    label_numbers = re.findall(r"\d+", label)
                    if label_numbers and not all(number in normalized_evidence for number in label_numbers):
                        reason = "pin/register number is not present in cited OCR evidence"

            if reason:
                rejected.append(
                    {
                        "fact_type": fact_type,
                        "label": label,
                        "value": value,
                        "reason": reason,
                    }
                )
                continue

            selection = cls._select_fact_candidate(
                visual_value=value,
                visual_confidence=float(visual_confidence),
                unit=unit,
                resolved_tokens=resolved_tokens,
                fact_type=fact_type,
                label=label,
                document_vocabulary=vocabulary,
            )
            selected_value = str(selection.get("value") or "").strip()
            if not selected_value:
                rejected.append(
                    {
                        "fact_type": fact_type,
                        "label": label,
                        "value": value,
                        "reason": "candidate scoring did not produce a value",
                    }
                )
                continue

            type_error = validate_fact_value(
                fact_type=fact_type,
                label=label,
                value=selected_value,
                unit=unit,
                vocabulary=vocabulary,
                document_match=bool(selection.get("document_match")),
            )
            if selection.get("status") == "uncertain" or type_error:
                rejected.append(
                    {
                        "fact_type": fact_type,
                        "label": label,
                        "value": value,
                        "selected_candidate": selected_value,
                        "status": "uncertain",
                        "confidence": selection.get("final_confidence"),
                        "candidate_scores": selection.get("candidate_scores") or [],
                        "reason": type_error or selection.get("selection_reason"),
                    }
                )
                continue

            signature = (fact_type, label.lower(), f"{selected_value} {unit}".strip().lower())
            if signature in seen:
                continue
            seen.add(signature)
            accepted.append(
                {
                    "fact_type": fact_type,
                    "label": label,
                    "value": selected_value,
                    "unit": unit,
                    "status": selection["status"],
                    "document_match": bool(selection.get("document_match")),
                    "score_margin": selection.get("score_margin"),
                    "selection_reason": selection["selection_reason"],
                    "alternatives": selection["alternatives"],
                    "candidate_scores": selection["candidate_scores"],
                    "evidence": [
                        {
                            "id": int(token["id"]),
                            "text": str(token.get("text") or ""),
                            "ocr_confidence": round(float(token["confidence"]), 4),
                            "bbox": token.get("bbox") or [],
                            "local_candidates": token.get("local_candidates") or [],
                        }
                        for token in resolved_tokens
                    ],
                    "field_confidence": {
                        "vision": round(float(visual_confidence), 4),
                        "ocr": round(
                            min(float(token["confidence"]) for token in resolved_tokens),
                            4,
                        ),
                        "final": selection["final_confidence"],
                    },
                }
            )
        return accepted, rejected

    @classmethod
    def _select_fact_candidate(
        cls,
        *,
        visual_value: str,
        visual_confidence: float,
        unit: str,
        resolved_tokens: list[dict[str, Any]],
        fact_type: str,
        label: str,
        document_vocabulary: dict[str, Any] | None,
    ) -> dict[str, Any]:
        primary_text = " ".join(str(token.get("text") or "") for token in resolved_tokens).strip()
        primary_confidence = min(float(token.get("confidence") or 0.0) for token in resolved_tokens)
        primary_value = cls._fact_value_from_source(visual_value, unit, primary_text)

        local_parts: list[str] = []
        local_confidences: list[float] = []
        for token in resolved_tokens:
            local_candidates = token.get("local_candidates") or []
            best = local_candidates[0] if local_candidates and isinstance(local_candidates[0], dict) else None
            if best and str(best.get("text") or "").strip():
                local_parts.append(str(best["text"]).strip())
                local_confidences.append(float(best.get("confidence") or 0.0))
            else:
                local_parts.append(str(token.get("text") or "").strip())
                local_confidences.append(0.0)
        has_local_evidence = bool(local_confidences) and all(
            confidence > 0 for confidence in local_confidences
        )
        local_text = " ".join(part for part in local_parts if part).strip()
        local_value = cls._fact_value_from_source(visual_value, unit, local_text)
        local_confidence = min(local_confidences) if local_confidences else 0.0

        source_candidates: list[dict[str, Any]] = [
            {
                "source": "primary_ocr",
                "family": "ocr",
                "value": primary_value,
                "confidence": primary_confidence,
                "weight": IMAGE_FACT_OCR_FAMILY_WEIGHT,
            },
            {
                "source": "visual",
                "family": "visual",
                "value": visual_value,
                "confidence": visual_confidence,
                "weight": IMAGE_FACT_VISUAL_WEIGHT,
            },
        ]
        if has_local_evidence:
            source_candidates.append(
                {
                    "source": "local_ocr",
                    "family": "ocr",
                    "value": local_value,
                    "confidence": local_confidence,
                    "weight": IMAGE_FACT_OCR_FAMILY_WEIGHT,
                }
            )

        canonicalized_candidates: list[dict[str, Any]] = []
        document_candidates: dict[str, dict[str, Any]] = {}
        for candidate in source_candidates:
            canonical = canonicalize_fact_value(
                str(candidate.get("value") or ""),
                fact_type=fact_type,
                label=label,
                vocabulary=document_vocabulary,
            )
            canonical_value = str(canonical.get("value") or "").strip()
            canonicalized_candidates.append(
                {
                    **candidate,
                    "raw_value": str(candidate.get("value") or "").strip(),
                    "value": canonical_value,
                    "canonicalization": canonical.get("reason"),
                    "document_match": bool(canonical.get("document_match")),
                }
            )
            authoritative_document_match = bool(canonical.get("document_match")) and (
                canonical.get("reason") == "structured pin mapping"
                or fact_type == "device_model"
            )
            if authoritative_document_match and canonical_value:
                document_candidates[cls._normalize_fact_text(canonical_value)] = {
                    "source": "document_vocabulary",
                    "family": "document",
                    "value": canonical_value,
                    "raw_value": canonical_value,
                    "confidence": float(canonical.get("document_confidence") or 0.0),
                    "weight": IMAGE_FACT_DOCUMENT_WEIGHT,
                    "canonicalization": canonical.get("reason"),
                }
        canonicalized_candidates.extend(document_candidates.values())

        groups: dict[str, dict[str, Any]] = {}
        for candidate in canonicalized_candidates:
            value = str(candidate.get("value") or "").strip()
            key = cls._normalize_fact_text(value)
            if not key:
                continue
            group = groups.setdefault(
                key,
                {
                    "value": value,
                    "family_contributions": {},
                    "source_names": [],
                    "raw_values": [],
                    "vocabulary_match": False,
                },
            )
            contribution = float(candidate["confidence"]) * float(candidate["weight"])
            family = str(candidate["family"])
            current = group["family_contributions"].get(family)
            if current is None or contribution > current["contribution"]:
                group["family_contributions"][family] = {
                    "confidence": float(candidate["confidence"]),
                    "weight": float(candidate["weight"]),
                    "contribution": contribution,
                }
            if candidate["source"] not in group["source_names"]:
                group["source_names"].append(candidate["source"])
            raw_value = str(candidate.get("raw_value") or value)
            if raw_value not in group["raw_values"]:
                group["raw_values"].append(raw_value)
            group["vocabulary_match"] = bool(
                group["vocabulary_match"] or candidate.get("document_match")
            )

        primary_key = cls._normalize_fact_text(primary_value)
        for key, group in groups.items():
            contributions = group["family_contributions"]
            weighted_confidence = sum(item["contribution"] for item in contributions.values())
            total_weight = sum(item["weight"] for item in contributions.values())
            penalty = 0.0
            if len(contributions) == 1 and cls._contains_ambiguous_identifier(group["value"]):
                penalty += IMAGE_FACT_AMBIGUITY_PENALTY
            if primary_key and key != primary_key and "document" not in contributions:
                penalty += IMAGE_FACT_CORRECTION_PENALTY
            group["penalty"] = penalty
            group["score"] = max(0.0, weighted_confidence - penalty)
            group["final_confidence"] = max(
                0.0,
                min(1.0, weighted_confidence / max(total_weight, 1e-9) - penalty),
            )
            group["sources"] = sorted(contributions)
            group["document_match"] = bool(group["vocabulary_match"])
            group["authoritative_document_support"] = "document" in contributions
            group["ocr_support"] = "ocr" in contributions
            group["visual_support"] = "visual" in contributions

        if not groups:
            return {
                "value": "",
                "status": "rejected",
                "final_confidence": 0.0,
                "selection_reason": "no usable candidates",
                "alternatives": [],
                "candidate_scores": [],
            }

        ranked = sorted(
            groups.values(),
            key=lambda group: (
                group["score"],
                group["document_match"],
                group["ocr_support"],
                group["visual_support"],
            ),
            reverse=True,
        )
        selected = ranked[0]
        has_conflict = len(ranked) > 1
        score_margin = selected["score"] - ranked[1]["score"] if has_conflict else selected["score"]
        independent_source_count = len(selected["sources"])
        requires_document_guard = fact_type in {"pin", "signal", "register", "device_model"}
        has_document_guard = (
            not requires_document_guard
            or selected["document_match"]
            or not (document_vocabulary or {}).get("identifiers")
        )
        was_canonicalized = any(
            cls._normalize_fact_text(raw_value)
            != cls._normalize_fact_text(selected["value"])
            for raw_value in selected.get("raw_values") or []
            if str(raw_value or "").strip()
        )
        if (
            independent_source_count >= 2
            and has_document_guard
            and selected["final_confidence"] >= IMAGE_DETAIL_FINAL_MIN_CONFIDENCE
            and (not has_conflict or score_margin >= IMAGE_FACT_SELECTED_MIN_MARGIN)
        ):
            status = "canonicalized" if was_canonicalized else "verified"
        elif (
            independent_source_count >= 2
            and has_document_guard
            and selected["final_confidence"] >= IMAGE_FACT_SELECTED_MIN_CONFIDENCE
            and (not has_conflict or score_margin >= IMAGE_FACT_SELECTED_MIN_MARGIN)
        ):
            status = "confidence_selected"
        else:
            status = "uncertain"
        return {
            "value": selected["value"],
            "status": status,
            "final_confidence": round(float(selected["final_confidence"]), 4),
            "document_match": bool(selected["document_match"]),
            "score_margin": round(float(score_margin), 4),
            "selection_reason": (
                "published after canonicalization against document evidence"
                if status == "canonicalized"
                else
                "independent evidence passed the strict publication gate"
                if status == "verified"
                else "selected the highest weighted confidence candidate"
                if status == "confidence_selected"
                else "highest candidate did not pass the publication gate"
            ),
            "alternatives": [
                {
                    "value": candidate["value"],
                    "confidence": round(float(candidate["final_confidence"]), 4),
                }
                for candidate in ranked[1:]
            ],
            "candidate_scores": [
                {
                    "value": candidate["value"],
                    "score": round(float(candidate["score"]), 4),
                    "confidence": round(float(candidate["final_confidence"]), 4),
                    "sources": list(candidate["sources"]),
                    "raw_values": list(candidate["raw_values"]),
                    "document_match": bool(candidate["document_match"]),
                    "authoritative_document_support": bool(
                        candidate["authoritative_document_support"]
                    ),
                    "penalty": round(float(candidate["penalty"]), 4),
                }
                for candidate in ranked
            ],
        }

    @classmethod
    def _fact_value_from_source(cls, visual_value: str, unit: str, source_text: str) -> str:
        visual = str(visual_value or "").strip()
        source = str(source_text or "").strip()
        normalized_visual = cls._normalize_fact_text(visual)
        normalized_source = cls._normalize_fact_text(source)
        if normalized_visual and normalized_visual in normalized_source:
            return visual
        if unit:
            source = re.sub(rf"\s*{re.escape(unit)}\s*$", "", source, flags=re.IGNORECASE)
        return source or visual

    @staticmethod
    def _contains_ambiguous_identifier(value: str) -> bool:
        text = str(value or "")
        if not re.fullmatch(r"[A-Za-z0-9_./+-]+", text):
            return False
        ambiguity_groups = ("0O", "1Il", "5S", "8B", "2Z", "6G")
        return any(any(character in text for character in group) for group in ambiguity_groups)

    @staticmethod
    def _locate_current_image_line(content: str, item: dict[str, Any]) -> int | None:
        lines = content.splitlines()
        filename = str(item.get("filename") or "").strip()
        if filename:
            for index, line in enumerate(lines):
                if filename in line and line.lstrip().startswith("!["):
                    return index

        image_lines = [
            index for index, line in enumerate(lines)
            if line.lstrip().startswith("![")
        ]
        try:
            placeholder_index = int(item.get("placeholder_index"))
        except (TypeError, ValueError):
            placeholder_index = -1
        if 0 <= placeholder_index < len(image_lines):
            return image_lines[placeholder_index]

        try:
            legacy_line = int(item.get("markdown_line"))
        except (TypeError, ValueError):
            return None
        return legacy_line if 0 <= legacy_line < len(lines) else None

    @staticmethod
    def _image_description_context(content: str, markdown_line: Any) -> str:
        """Return grounded headings, captions, and nearby text around one image."""
        try:
            line_index = int(markdown_line)
        except (TypeError, ValueError):
            return ""

        lines = content.splitlines()
        if line_index < 0 or line_index >= len(lines):
            return ""
        context_lines: list[tuple[int, str]] = []
        figure_caption_pattern = re.compile(
            r"^Figure\s*\d+(?:[-.]\d+)*(?:[.:\s]|$)",
            re.IGNORECASE,
        )

        def usable(line: str) -> bool:
            if not line or line.startswith("![") or line.startswith("<!-- image"):
                return False
            if re.match(r"^\*\*(?:Figure|Image)\s*\d+\s+Analysis:", line, re.IGNORECASE):
                return False
            return not line.startswith(
                (
                    "- Type:",
                    "- Description:",
                    "- Detail ",
                    "- Verified fact:",
                    "- Canonicalized fact:",
                    "- Selected fact:",
                )
            )

        # Preserve the nearest section hierarchy even when a long table sits before the image.
        heading_count = 0
        caption_found = False
        for index in range(line_index - 1, max(-1, line_index - 100), -1):
            line = lines[index].strip()
            if line.startswith("!["):
                break
            if figure_caption_pattern.match(line) and not caption_found:
                context_lines.append((index, line))
                caption_found = True
            elif re.match(r"^#{1,6}\s+", line) and heading_count < 3:
                context_lines.append((index, line))
                heading_count += 1
            if caption_found and heading_count >= 2:
                break

        # Add nearby prose/table labels before and after the image for semantic checks.
        start = max(0, line_index - 14)
        end = min(len(lines), line_index + 15)
        for index in range(start, end):
            if index == line_index:
                continue
            line = lines[index].strip()
            if index > line_index:
                if line.startswith("![") or re.match(r"^#{1,6}\s+", line):
                    break
                if figure_caption_pattern.match(line):
                    if not caption_found and index <= line_index + 4:
                        context_lines.append((index, line))
                    break
            if not usable(line):
                continue
            context_lines.append((index, line))

        deduplicated: dict[int, str] = {}
        for index, line in context_lines:
            deduplicated[index] = line
        ordered = [deduplicated[index] for index in sorted(deduplicated)]
        return "\n".join(ordered)[-3500:]

    @staticmethod
    def _figure_caption_from_context(context: str) -> str:
        pattern = re.compile(
            r"^Figure\s*\d+(?:[-.]\d+)*(?:[.:\s]|$).+",
            re.IGNORECASE,
        )
        for line in reversed(context.splitlines()):
            normalized = line.strip()
            if pattern.match(normalized):
                return normalized
        return ""

    @staticmethod
    def _expected_image_types(context: str) -> set[str]:
        """Infer a conservative expected type from the nearest clear caption."""
        strong_rules: tuple[tuple[re.Pattern[str], set[str]], ...] = (
            (
                re.compile(r"recommended\s+land\s+pattern|land\s+pattern|IPC-7351", re.IGNORECASE),
                {"pcb_layout"},
            ),
            (
                re.compile(r"operating\s+mode\s+map", re.IGNORECASE),
                {"flowchart"},
            ),
            (
                re.compile(r"scann?ing\s+timing", re.IGNORECASE),
                {"timing_diagram"},
            ),
            (
                re.compile(r"classification\s+(?:reflow\s+)?profile|reflow\s+profile", re.IGNORECASE),
                {"plot"},
            ),
            (
                re.compile(r"6\+4[-\s]?BIT\s+PWM\s+MODE", re.IGNORECASE),
                {"timing_diagram", "waveform"},
            ),
        )
        for pattern, expected_types in strong_rules:
            if pattern.search(context):
                return set(expected_types)

        rules: tuple[tuple[re.Pattern[str], set[str]], ...] = (
            (
                re.compile(
                    r"I\s*2\s*C|START\s*(?:/|and)?\s*STOP|"
                    r"single\s+read|single\s+write|multiple\s+read|multiple\s+write|bus\s+transaction",
                    re.IGNORECASE,
                ),
                {"protocol_diagram", "timing_diagram"},
            ),
            (
                re.compile(r"pin\s+(?:arrangement|configuration|distribution|diagram|function)|pinout", re.IGNORECASE),
                {"pinout"},
            ),
            (
                re.compile(
                    r"application\s+(?:diagram|schematic|circuit)|circuit\s+schematic|"
                    r"simplified\s+application|resistor\s+network",
                    re.IGNORECASE,
                ),
                {"schematic"},
            ),
            (
                re.compile(r"functional\s+block\s+diagram|block\s+diagram", re.IGNORECASE),
                {"block_diagram"},
            ),
            (
                re.compile(r"flowchart|process\s+flow", re.IGNORECASE),
                {"flowchart", "block_diagram"},
            ),
            (
                re.compile(r"operating\s+mode\s+map|mode\s+map", re.IGNORECASE),
                {"flowchart", "block_diagram"},
            ),
            (
                re.compile(r"STAT.*FLAG.*MASK.*relationship", re.IGNORECASE),
                {"timing_diagram", "waveform"},
            ),
            (
                re.compile(r"timing\s+diagram|timing|waveform", re.IGNORECASE),
                {"timing_diagram", "waveform", "protocol_diagram"},
            ),
            (
                re.compile(
                    r"register\s+(?:table|map|bit\s*field)|bit\s*field\s*table",
                    re.IGNORECASE,
                ),
                {"register_table"},
            ),
            (
                re.compile(
                    r"typical\s+characteristic|characteristic\s+curve|efficiency\s+curve|accuracy\s+curve|"
                    r"charging\s+curve|application\s+curve|temperature\s+window|detection\s+threshold|"
                    r"classification\s+(?:reflow\s+)?profile|reflow\s+profile",
                    re.IGNORECASE,
                ),
                {"plot"},
            ),
            (
                re.compile(r"high[-\s]+frequency\s+current\s+path", re.IGNORECASE),
                {"schematic", "pcb_layout"},
            ),
            (
                re.compile(r"layout\s+example|PCB\s*layout", re.IGNORECASE),
                {"pcb_layout"},
            ),
            (
                re.compile(
                    r"package\s+(?:drawing|dimensions)|mechanical\s+dimensions|package|tape\s+and\s+reel|"
                    r"pin\s*1\s+orientation\s+in\s+tape|flatpack|no\s+lead|"
                    r"solder\s+mask|solder\s+paste|IPC-7525|IPC-7351|WLCSP|land\s+pattern",
                    re.IGNORECASE,
                ),
                {"package"},
            ),
        )
        for line in reversed(context.splitlines()):
            for pattern, expected_types in rules:
                if pattern.search(line):
                    return set(expected_types)
        return set()

    def _image_description_metadata(self, image_path: str | Path | None) -> dict[str, Any]:
        """Return image metadata and whether it is large enough for reliable visual description."""
        metadata: dict[str, Any] = {
            "file_size": None,
            "width": None,
            "height": None,
            "area": None,
            "description_eligible": False,
            "description_eligibility_policy": None,
            "description_skip_reason": None,
        }
        if not image_path:
            metadata["description_skip_reason"] = "missing image path"
            return metadata

        path = Path(image_path)
        try:
            metadata["file_size"] = path.stat().st_size
        except OSError as exc:
            metadata["description_skip_reason"] = f"image file is not readable: {exc}"
            return metadata

        try:
            from PIL import Image
        except ImportError:
            logger.warning("Pillow is unavailable; image description size guard was skipped")
            metadata["description_eligible"] = True
            metadata["description_skip_reason"] = "size metadata unavailable"
            return metadata

        try:
            with Image.open(path) as image:
                width, height = image.size
        except (OSError, ValueError) as exc:
            metadata["description_skip_reason"] = f"image dimensions are not readable: {exc}"
            return metadata

        area = width * height
        metadata.update({"width": width, "height": height, "area": area})
        passes_standard_policy = (
            width >= MIN_IMAGE_DESCRIPTION_WIDTH_PX
            and height >= MIN_IMAGE_DESCRIPTION_HEIGHT_PX
            and area >= MIN_IMAGE_DESCRIPTION_AREA_PX
        )
        passes_wide_strip_policy = (
            width >= MIN_WIDE_IMAGE_DESCRIPTION_WIDTH_PX
            and height >= MIN_WIDE_IMAGE_DESCRIPTION_HEIGHT_PX
            and area >= MIN_WIDE_IMAGE_DESCRIPTION_AREA_PX
        )
        if not passes_standard_policy and not passes_wide_strip_policy:
            metadata["description_skip_reason"] = (
                "image too small for reliable description: "
                f"{width}x{height}, area={area}; does not satisfy standard or wide-strip policy"
            )
            return metadata

        metadata["description_eligible"] = True
        metadata["description_eligibility_policy"] = (
            "standard" if passes_standard_policy else "wide_strip"
        )
        return metadata

    @staticmethod
    def _build_router_image_description_prompt(
        source_name: str,
        document_context: str,
        figure_caption: str,
        expected_types: list[str],
    ) -> str:
        """Build the prompt paired with the directly attached image block."""
        expected_text = ", ".join(expected_types) if expected_types else "not determined"
        context_text = document_context or "(no reliable nearby text)"

        # Type-specific description guidelines
        type_guidelines = {
            "schematic": "describe the main functional modules, key chip models, power supply scheme, major signal flow, and critical component parameters",
            "block_diagram": "describe the functional module names, data flow and control relationships between modules, overall architecture characteristics, and key interfaces",
            "timing_diagram": "describe the signal names, qualitative timing relationships, and meanings of key timing parameters; leave exact values to the verification stage",
            "protocol_diagram": "describe the communication protocol type, transmission stages, key signals and their functions, and data transfer directions",
            "pinout": "describe the total pin count, major functional pin groupings (such as power, communication, IO), package type, and pin naming conventions",
            "register_table": "describe the functional classification of registers, address ranges, functions of main control bits, and access permissions",
            "waveform": "describe the waveform type, measurement conditions, and qualitative electrical behavior; leave exact values to the verification stage",
            "plot": "describe the meanings of horizontal and vertical axes, parameter relationships represented by curves, typical operating regions, and performance indicators",
            "pcb_layout": "describe the PCB layer count, key layout areas, characteristics of high-frequency or high-voltage traces, and shielding measures",
            "package": "describe the package type, dimension categories, pin layout or pitch relationships, special markings, and thermal features; leave exact dimensions to the verification stage",
            "flowchart": "describe the starting conditions of the flow, key decision nodes, main execution steps, and exception handling paths",
        }

        guideline = ""
        if expected_types:
            caption_types = DriverDoclingImageDescriptionService._expected_image_types(figure_caption)
            candidate_types = caption_types or set(expected_types)
            type_priority = (
                "flowchart",
                "timing_diagram",
                "plot",
                "package",
                "schematic",
                "block_diagram",
                "protocol_diagram",
                "waveform",
                "pinout",
                "register_table",
                "pcb_layout",
            )
            primary_type = next(
                (value for value in type_priority if value in candidate_types),
                "other",
            )
            if primary_type in type_guidelines:
                guideline = f"\n\nFor {primary_type} type images, focus on: {type_guidelines[primary_type]}."

        return f"""Analyze the single technical image attached to this request, which comes from technical datasheet '{source_name}'.

Adjacent text before the image (for cross-verification only):
---
{context_text}
---
Expected image type inferred from nearby headings: {expected_text}
Nearest figure caption: {figure_caption or '(none)'}

Analysis requirements:
1. The pixels in the attached image are the primary evidence; adjacent text can only help confirm the general image type and must never be used to fabricate image details
2. Treat the nearest figure caption as authoritative for the subject when it is consistent with the pixels
3. Produce a detailed first-pass analysis, not a one-sentence caption. Cover the technical purpose, visible structure, element groups, signal or data flow, spatial organization, and qualitative relationships{guideline}
4. Return as many distinct detail_points as the image supports. Do not impose an arbitrary count, merge unrelated observations, repeat the description, or add filler
5. Each detail_point must contain one concrete, independently useful observation grounded in the visible image
6. Clearly readable labels, signal names, component names, dimensions, and numeric values may be transcribed; never guess partially visible text or infer unsupported values
7. Do not infer protection modes, faults, register behavior, frequencies, dimensions, or operating ranges unless explicitly established by the figure caption and visible pixels
8. If the image is unreadable, blurry, or conflicts with the figure caption, set the confidence of affected fields to <= 0.4
9. For every exact identifier or engineering value in a detail point, add a separate claims entry; use an empty claims array when the point contains no exact claim
10. The title is a type-level search anchor. Preserve useful alphanumeric model or package identifiers, but do not put standalone engineering values, units, pin numbers, register addresses, or exact dimensions in it. Good: "WLCSP-12 Recommended Land Pattern". Bad: "WLCSP-12 Land Pattern with 0.4 mm Pitch". Bad: "Land Pattern".

Return strictly in this JSON format (no other text):
{{
  "type": "block_diagram|schematic|timing_diagram|protocol_diagram|flowchart|pinout|register_table|waveform|plot|pcb_layout|package|other",
  "title": "type-level searchable English title that preserves model/package identifiers but excludes standalone engineering values, units, pin numbers, register addresses, and exact dimensions",
  "description": "detailed grounded English overview",
  "detail_points": [
    {{
      "id": "D1",
      "text": "one distinct grounded technical observation in English",
      "claim_type": "structure|relationship|signal|pin|register|numeric|component|dimension|other",
      "contains_precise_fact": false,
      "claims": [
        {{"type": "signal|pin|register|device_model|engineering_value|other", "value": "exact visible value", "unit": "optional unit"}}
      ]
    }}
  ],
  "field_confidence": {{
    "type": 0.0,
    "title": 0.0,
    "description": 0.0
  }}
}}
"""

    def _build_image_description_prompt(
        self,
        manifest_path: Path,
        output_path: Path,
        source_name: str,
        image_count: int,
    ) -> str:
        """Build the Claude CLI prompt for describing extracted datasheet images."""
        return f"""Analyze exactly one embedded image extracted from technical datasheet '{source_name}'.

Read the single-image manifest JSON file:
{manifest_path}

Inspect the image at the manifest item's `path` and produce a detailed, technical English description.
Do not inspect or describe any other image. Do not compare it with other pages or images.

The manifest only includes images that passed the minimum size policy:
- standard: width >= {MIN_IMAGE_DESCRIPTION_WIDTH_PX}px, height >= {MIN_IMAGE_DESCRIPTION_HEIGHT_PX}px,
  area >= {MIN_IMAGE_DESCRIPTION_AREA_PX}px
- wide technical strip: width >= {MIN_WIDE_IMAGE_DESCRIPTION_WIDTH_PX}px,
  height >= {MIN_WIDE_IMAGE_DESCRIPTION_HEIGHT_PX}px,
  area >= {MIN_WIDE_IMAGE_DESCRIPTION_AREA_PX}px

Use only visible image content. Do not infer the image meaning from filename,
page number, surrounding text, or nearby document sections. If the visible image
is unreadable or ambiguous, say it cannot be reliably identified instead of guessing.

Describe the image type, technical purpose, visible structure, element groups, signal or data flow,
spatial organization, and qualitative relationships. Return as many distinct detail_points as the
image supports without repetition, filler, or an arbitrary maximum. Each point must contain one
independently useful visible observation. Clearly readable labels, signal names, component names,
dimensions, and numeric values may be transcribed, but partially visible or ambiguous details must
never be guessed.
The title is a type-level search anchor: preserve useful alphanumeric model or package identifiers,
but exclude standalone engineering values, units, pin numbers, register addresses, and exact dimensions. Good: "WLCSP-12 Recommended Land Pattern". Bad: "WLCSP-12 Land Pattern with 0.4 mm Pitch". Bad: "Land Pattern".
For every exact identifier or engineering value in a detail point, add a separate claims entry. Use
an empty claims array when the point contains no exact claim.

Write STRICT JSON to this exact file:
{output_path}

Required JSON schema:
{{
  "type": "block_diagram|schematic|timing_diagram|protocol_diagram|flowchart|pinout|register_table|waveform|plot|pcb_layout|package|other",
  "title": "type-level searchable English title that preserves model/package identifiers but excludes standalone engineering values, units, pin numbers, register addresses, and exact dimensions",
  "description": "detailed grounded English overview",
  "detail_points": [
    {{
      "id": "D1",
      "text": "one distinct grounded technical observation in English",
      "claim_type": "structure|relationship|signal|pin|register|numeric|component|dimension|other",
      "contains_precise_fact": false,
      "claims": [
        {{"type": "signal|pin|register|device_model|engineering_value|other", "value": "exact visible value", "unit": "optional unit"}}
      ]
    }}
  ],
  "field_confidence": {{
    "type": 0.0,
    "title": 0.0,
    "description": 0.0
  }}
}}

Do not wrap the JSON in Markdown fences. Do not include extra commentary.
"""

    def _inject_image_description_blocks(self, content: str, descriptions: dict[int, dict]) -> str:
        """Insert generated image descriptions directly below the matching Markdown image reference."""
        lines = content.split("\n")
        result_lines: list[str] = []
        pattern = re.compile(r"^!\[(?:Figure|Image)\s*(\d+)\]\(", re.IGNORECASE)

        for line in lines:
            result_lines.append(line)
            match = pattern.match(line.strip())
            if not match:
                continue

            index = int(match.group(1)) - 1
            desc = descriptions.get(index)
            if not desc:
                continue

            title = desc.get("title") or f"Image {index + 1} Analysis"
            image_type = desc.get("type") or "unknown"
            description = desc.get("description") or ""
            detail_points = self._normalize_detail_points(desc.get("detail_points"))
            field_confidence = desc.get("field_confidence") or {}
            publishable_facts = desc.get("publishable_facts") or desc.get("verified_facts") or []

            block = [
                "",
                f"**Image {index + 1} Analysis: {title}**",
                f"- Type: {image_type}",
            ]
            if description:
                block.append(f"- Description: {description}")
            for point_index, point in enumerate(detail_points, start=1):
                block.append(f"- Detail {point_index}: {point}")
            confidence_parts = []
            for field_name, display_name in (
                ("type", "type"),
                ("title", "title"),
                ("description", "description"),
            ):
                confidence = self._coerce_confidence(field_confidence.get(field_name))
                if confidence is not None:
                    confidence_parts.append(f"{display_name} {confidence:.2f}")
            if confidence_parts:
                block.append(f"- Field confidence: {'; '.join(confidence_parts)}")
            for fact in publishable_facts:
                if not isinstance(fact, dict):
                    continue
                label = str(fact.get("label") or "").strip()
                value = str(fact.get("value") or "").strip()
                unit = str(fact.get("unit") or "").strip()
                confidence = self._coerce_confidence(
                    (fact.get("field_confidence") or {}).get("final")
                    if isinstance(fact.get("field_confidence"), dict)
                    else None
                )
                if not label or not value or confidence is None:
                    continue
                rendered_value = f"{value} {unit}".strip()
                fact_status = str(fact.get("status") or "verified").strip().lower()
                fact_label = {
                    "verified": "Verified fact",
                    "canonicalized": "Canonicalized fact",
                    "confidence_selected": "Selected fact",
                }.get(fact_status, "Selected fact")
                selected_sources: list[str] = []
                for candidate in fact.get("candidate_scores") or []:
                    if not isinstance(candidate, dict):
                        continue
                    if self._normalize_fact_text(candidate.get("value")) == self._normalize_fact_text(value):
                        selected_sources = [
                            str(source)
                            for source in candidate.get("sources") or []
                            if str(source).strip()
                        ]
                        break
                source_text = ", ".join(selected_sources) or "validated evidence"
                block.append(
                    f"- {fact_label}: {label}: {rendered_value} "
                    f"(sources: {source_text}; confidence: {confidence:.2f})"
                )
            block.append("")
            result_lines.extend(block)

        return "\n".join(result_lines)
