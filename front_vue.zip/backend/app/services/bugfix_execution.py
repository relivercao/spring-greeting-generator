"""Shared execution lifecycle for single and batch BugFix tasks."""

import asyncio

from loguru import logger

from app.agents.impl import BugFixAgent
from app.agents.impl.bugfix_agent import BugFixContext
from app.services.agent_task_runtime import (
    agent_task_registry,
    complete_task,
    fail_task,
    mark_task_cancelled,
    serialize_agent_result,
    task_usage_for_agent,
    update_task_progress,
)

BUGFIX_STAGES = {"fetch", "read_code", "analyze", "module_expert", "fix", "report"}


async def run_bugfix_task(
    task_id: str, agent: BugFixAgent, task_desc: str, context: BugFixContext,
) -> None:
    """Execute a repair with durable progress and cancellation semantics."""
    current_stage = None
    try:
        async for update in agent.stream_execute(task_desc, context):
            if update.stage not in {"completed", "failed", "cancelled"}:
                if update.stage in BUGFIX_STAGES:
                    current_stage = update.stage
                await update_task_progress(task_id, update.progress, update.stage, update.message, update.details)
        result = agent.get_status(task_id)
        if result is None:
            raise RuntimeError("Bug-fix task completed without an Agent result")
        result_data = serialize_agent_result(result)
        if current_stage:
            result_data["_workflow_stage"] = current_stage
        result_data["token_usage"] = task_usage_for_agent(agent, task_id)
        await complete_task(result, result_data)
    except asyncio.CancelledError:
        await mark_task_cancelled(task_id, "Bug-fix task cancelled")
    except Exception as error:
        logger.exception("BugFix task {} failed: {}", task_id, error)
        await fail_task(task_id, str(error))
    finally:
        agent_task_registry.remove(task_id)
