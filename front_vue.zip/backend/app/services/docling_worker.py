"""Isolated Docling worker for a bounded PDF page range."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


_MAX_PDF_BYTES = 50 * 1024 * 1024


def _format_errors(errors: list[Any]) -> list[str]:
    formatted: list[str] = []
    for error in errors:
        message = getattr(error, "error_message", None) or getattr(error, "message", None)
        page_number = getattr(error, "page_no", None)
        prefix = f"Page {page_number}: " if page_number is not None else ""
        formatted.append(prefix + str(message or error))
    return formatted


def _build_converter(enable_ocr: bool):
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.pipeline_options import PdfPipelineOptions
    from docling.document_converter import DocumentConverter, PdfFormatOption

    pipeline_options = PdfPipelineOptions(
        document_timeout=10 * 60,
        do_ocr=enable_ocr,
        do_table_structure=True,
        ocr_batch_size=1,
        layout_batch_size=1,
        table_batch_size=1,
        queue_max_size=1,
    )
    return DocumentConverter(
        allowed_formats=[InputFormat.PDF],
        format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options),
        },
    )


def _range_requires_ocr(source_path: Path, start_page: int, end_page: int) -> bool:
    """Use OCR only when at least one page lacks usable embedded PDF text."""
    try:
        import pypdfium2 as pdfium

        document = pdfium.PdfDocument(source_path)
        try:
            for page_number in range(start_page, end_page + 1):
                page = document[page_number - 1]
                try:
                    text_page = page.get_textpage()
                    try:
                        text = text_page.get_text_range()
                    finally:
                        text_page.close()
                finally:
                    page.close()
                if len(re.sub(r"\s+", "", text)) < 24:
                    return True
        finally:
            document.close()
        return False
    except Exception:
        return True


def convert_page_range(
    source_path: Path,
    start_page: int,
    end_page: int,
    *,
    no_ocr: bool,
) -> dict[str, Any]:
    """Convert one bounded page range and return page-specific Markdown."""
    enable_ocr = not no_ocr and _range_requires_ocr(source_path, start_page, end_page)
    converter = _build_converter(enable_ocr=enable_ocr)
    result = converter.convert(
        source_path,
        max_file_size=_MAX_PDF_BYTES,
        page_range=(start_page, end_page),
    )
    status = getattr(result.status, "value", str(result.status)).lower()
    errors = _format_errors(list(getattr(result, "errors", []) or []))
    if status != "success" or errors:
        return {
            "status": "error",
            "start_page": start_page,
            "end_page": end_page,
            "errors": errors,
            "error": (
                f"Docling returned {status} for pages {start_page}-{end_page}."
                if not errors
                else "; ".join(errors)
            ),
        }

    document = result.document
    page_keys = sorted(int(page_number) for page_number in document.pages.keys())
    expected_count = end_page - start_page + 1
    if len(page_keys) != expected_count:
        return {
            "status": "error",
            "start_page": start_page,
            "end_page": end_page,
            "errors": [],
            "error": (
                f"Docling returned {len(page_keys)} pages for the expected "
                f"range {start_page}-{end_page}."
            ),
        }

    pages = [
                {
                    "page_number": absolute_page,
                    # Keep Docling's page text exactly as returned.  The
                    # parent converter adds page markers without trimming
                    # source whitespace or blank lines.
                    "markdown": document.export_to_markdown(page_no=docling_page),
                }
        for absolute_page, docling_page in zip(
            range(start_page, end_page + 1),
            page_keys,
        )
    ]
    return {
        "status": "success",
        "start_page": start_page,
        "end_page": end_page,
        "pages": pages,
        "tables": len(document.tables),
        "ocr_used": enable_ocr,
        "errors": [],
        "document": document.export_to_dict(),
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert a bounded PDF range with Docling.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--start-page", required=True, type=int)
    parser.add_argument("--end-page", required=True, type=int)
    parser.add_argument("--no-ocr", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        payload = convert_page_range(
            Path(args.input),
            args.start_page,
            args.end_page,
            no_ocr=args.no_ocr,
        )
    except Exception as error:
        payload = {
            "status": "error",
            "start_page": args.start_page,
            "end_page": args.end_page,
            "errors": [],
            "error": f"Docling worker failed: {error}",
        }
    output_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return 0 if payload.get("status") == "success" else 2


if __name__ == "__main__":
    raise SystemExit(main())
