"""Composio-backed user application connections."""

from __future__ import annotations

import hashlib
import hmac
import json
from collections import defaultdict
from typing import Any
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

import httpx

from app.core.config import Settings, get_settings


APP_CATALOG: tuple[dict[str, str], ...] = (
    {"slug": "github", "name": "GitHub", "description": "Repositories, pull requests, issues, and code collaboration."},
    {"slug": "notion", "name": "Notion", "description": "Pages, databases, notes, and team workspaces."},
    {"slug": "gmail", "name": "Gmail", "description": "Search, read, and manage email with your account permissions."},
    {"slug": "slack", "name": "Slack", "description": "Search messages and collaborate in your workspace."},
    {"slug": "telegram", "name": "Telegram", "description": "Connect Telegram tools supported by your Composio project."},
    {"slug": "google-drive", "name": "Google Drive", "description": "Find, read, and organize files in cloud storage."},
    {"slug": "outlook", "name": "Outlook", "description": "Connect Microsoft email and calendar tools."},
    {"slug": "google-calendar", "name": "Google Calendar", "description": "Read and manage calendar events."},
    {"slug": "jira", "name": "Jira", "description": "Issues, projects, and engineering workflows."},
    {"slug": "bitbucket", "name": "Bitbucket", "description": "Repositories, pull requests, and code review."},
    {"slug": "linear", "name": "Linear", "description": "Issues, projects, and product planning."},
    {"slug": "discord", "name": "Discord", "description": "Connect servers and messaging tools."},
)

_APPS_BY_SLUG = {app["slug"]: app for app in APP_CATALOG}


class AppConnectionError(Exception):
    """An expected, safe-to-display application connection error."""

    def __init__(self, message: str, status_code: int = 502):
        self.status_code = status_code
        super().__init__(message)


class AppConnectionsService:
    """Manage hosted OAuth links and account state without storing provider tokens."""

    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()

    def _auth_configs(self) -> dict[str, str]:
        raw = str(self.settings.COMPOSIO_AUTH_CONFIGS or "").strip()
        if not raw:
            return {}
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            return {}
        if not isinstance(payload, dict):
            return {}
        return {
            str(slug): str(config_id).strip()
            for slug, config_id in payload.items()
            if str(slug) in _APPS_BY_SLUG and isinstance(config_id, str) and config_id.strip()
        }

    def _require_provider(self, app_slug: str | None = None) -> dict[str, str]:
        if not str(self.settings.COMPOSIO_API_KEY or "").strip():
            raise AppConnectionError("Application connections are not configured by the administrator.", 503)
        auth_configs = self._auth_configs()
        if app_slug and app_slug not in auth_configs:
            raise AppConnectionError("This application is not configured for connections yet.", 503)
        return auth_configs

    def _user_id(self, user_id: str) -> str:
        digest = hmac.new(
            str(self.settings.SECRET_KEY).encode("utf-8"),
            str(user_id).encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return f"macode_{digest}"

    def _api_url(self, path: str) -> str:
        return f"{str(self.settings.COMPOSIO_API_BASE_URL).rstrip('/')}/{path.lstrip('/')}"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        payload: dict[str, Any] | None = None,
        allow_not_found: bool = False,
    ) -> dict[str, Any]:
        headers = {"x-api-key": str(self.settings.COMPOSIO_API_KEY or "")}
        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                response = await client.request(
                    method,
                    self._api_url(path),
                    headers=headers,
                    params=params,
                    json=payload,
                )
        except httpx.RequestError as error:
            raise AppConnectionError("The application connection provider is unreachable.") from error
        if allow_not_found and response.status_code == 404:
            return {}
        if not 200 <= response.status_code < 300:
            raise AppConnectionError(
                f"The application connection provider returned HTTP {response.status_code}."
            )
        if response.status_code == 204 or not response.content:
            return {}
        try:
            data = response.json()
        except ValueError as error:
            raise AppConnectionError("The application connection provider returned an invalid response.") from error
        if not isinstance(data, dict):
            raise AppConnectionError("The application connection provider returned an invalid response.")
        return data

    @staticmethod
    def _account_auth_config_id(account: dict[str, Any]) -> str:
        value = account.get("auth_config_id")
        if not value and isinstance(account.get("auth_config"), dict):
            value = account["auth_config"].get("id")
        return str(value or "")

    async def _list_accounts(self, user_id: str) -> list[dict[str, Any]]:
        self._require_provider()
        provider_user_id = self._user_id(user_id)
        matching_accounts = []
        params = {"user_ids": provider_user_id, "limit": "100"}
        seen_cursors = set()
        for _page in range(20):
            data = await self._request("GET", "/connected_accounts", params=params)
            accounts = data.get("items", [])
            if not isinstance(accounts, list):
                raise AppConnectionError("The application connection provider returned an invalid account list.")
            for account in accounts:
                if not isinstance(account, dict):
                    continue
                account_user_id = str(account.get("user_id") or "")
                if not account_user_id or not hmac.compare_digest(account_user_id, provider_user_id):
                    continue
                matching_accounts.append(account)
            cursor = data.get("next_cursor")
            if not cursor:
                return matching_accounts
            if not isinstance(cursor, str) or cursor in seen_cursors:
                break
            seen_cursors.add(cursor)
            params = {**params, "cursor": cursor}
        raise AppConnectionError("The application account list could not be fully retrieved.")

    async def list_apps(self, user_id: str) -> dict[str, Any]:
        api_key_configured = bool(str(self.settings.COMPOSIO_API_KEY or "").strip())
        auth_configs = self._auth_configs()
        accounts: list[dict[str, Any]] = []
        if api_key_configured and auth_configs:
            accounts = await self._list_accounts(user_id)

        accounts_by_config: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for account in accounts:
            config_id = self._account_auth_config_id(account)
            if config_id in auth_configs.values():
                accounts_by_config[config_id].append(account)

        apps = []
        for app in APP_CATALOG:
            config_id = auth_configs.get(app["slug"])
            connected_accounts = accounts_by_config.get(config_id, []) if config_id else []
            statuses = [str(item.get("status") or "UNKNOWN").upper() for item in connected_accounts]
            if "ACTIVE" in statuses:
                connection_status = "ACTIVE"
            elif "INITIATED" in statuses:
                connection_status = "INITIATED"
            elif statuses:
                connection_status = statuses[0]
            else:
                connection_status = "NOT_CONNECTED"
            apps.append({
                **app,
                "configured": bool(api_key_configured and config_id),
                "connected": "ACTIVE" in statuses,
                "has_account": bool(connected_accounts),
                "connection_status": connection_status,
                "account_count": len(connected_accounts),
            })
        return {
            "provider": {
                "name": "Composio",
                "configured": bool(api_key_configured and auth_configs),
            },
            "apps": apps,
        }

    @staticmethod
    def _callback_url(frontend_base_url: str, return_path: str, app_slug: str) -> str:
        parsed_return = urlsplit(return_path or "/")
        if (
            parsed_return.scheme
            or parsed_return.netloc
            or not parsed_return.path.startswith("/")
            or parsed_return.path.startswith("//")
            or "\\" in parsed_return.path
        ):
            raise AppConnectionError("The return path must stay within this application.", 422)
        base = urlsplit(str(frontend_base_url).rstrip("/"))
        callback_path = f"{base.path.rstrip('/')}{parsed_return.path}" or "/"
        query = [
            (key, value)
            for key, value in parse_qsl(parsed_return.query, keep_blank_values=True)
            if key not in {"app_connection", "connected_account_id", "status"}
        ]
        query.append(("app_connection", app_slug))
        return urlunsplit((base.scheme, base.netloc, callback_path, urlencode(query), ""))

    async def create_link(self, user_id: str, app_slug: str, return_path: str = "/") -> dict[str, str]:
        if app_slug not in _APPS_BY_SLUG:
            raise AppConnectionError("Unknown application.", 404)
        auth_configs = self._require_provider(app_slug)
        provider_user_id = self._user_id(user_id)
        current_accounts = await self._list_accounts(user_id)
        config_id = auth_configs[app_slug]
        if any(
            self._account_auth_config_id(item) == config_id
            and str(item.get("status") or "").upper() == "ACTIVE"
            for item in current_accounts
        ):
            raise AppConnectionError("This application is already connected.", 409)
        callback_url = self._callback_url(
            getattr(self.settings, "COMPOSIO_FRONTEND_BASE_URL", "")
            or self.settings.PUBLIC_FRONTEND_BASE_URL,
            return_path,
            app_slug,
        )
        result = await self._request(
            "POST",
            "/connected_accounts/link",
            payload={
                "user_id": provider_user_id,
                "auth_config_id": config_id,
                "callback_url": callback_url,
            },
        )
        redirect_url = str(result.get("redirect_url") or "")
        parsed_redirect = urlsplit(redirect_url)
        if parsed_redirect.scheme != "https" or not parsed_redirect.netloc:
            raise AppConnectionError("The provider did not return a valid authorization link.")
        return {"redirect_url": redirect_url}

    async def disconnect(self, user_id: str, app_slug: str) -> dict[str, int]:
        if app_slug not in _APPS_BY_SLUG:
            raise AppConnectionError("Unknown application.", 404)
        auth_configs = self._require_provider(app_slug)
        config_id = auth_configs[app_slug]
        accounts = await self._list_accounts(user_id)
        matches = [
            item for item in accounts
            if self._account_auth_config_id(item) == config_id and item.get("id")
        ]
        deleted_count = 0
        for account in matches:
            await self._request(
                "DELETE",
                f"/connected_accounts/{quote(str(account['id']), safe='')}",
                allow_not_found=True,
            )
            deleted_count += 1
        return {"deleted_count": deleted_count}


__all__ = ["APP_CATALOG", "AppConnectionError", "AppConnectionsService"]
