"""Registration and login orchestration for the enhanced auth flow.

:class:`register_user` implements the toggle-aware registration
pipeline (master switch -> email verification -> invitation code ->
uniqueness -> user creation -> signup/promo bonuses) exactly in that
order, so each gate fails fast before any persistent side effect of
the later steps.  All database access goes through repositories.
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, Optional

from fastapi import HTTPException, status
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.security import get_password_hash
from app.models.balance_transaction import TransactionType
from app.models.redeem_code import RedeemCodeType
from app.models.user import User
from app.repositories.app_setting import AppSettingRepository
from app.repositories.balance_transaction import BalanceTransactionRepository
from app.repositories.redeem_code import RedeemCodeRepository
from app.repositories.user import UserRepository
from app.schemas.auth import UserRegisterRequest
from app.services import email_service

REGISTRATION_SETTING_KEY = "registration"
DEFAULT_REGISTRATION_SETTINGS: Dict[str, Any] = {
    "enabled": True,
    "email_verify_enabled": False,
    "invite_required": False,
    "signup_bonus": 0.0,
}


async def get_registration_settings(db: AsyncSession) -> Dict[str, Any]:
    """
    Load the ``registration`` toggles merged over their defaults.

    Missing keys and corrupt stored values both fall back to the
    defaults, so a partially-written setting row can never lock users
    out of registration or silently enable a gate.
    """
    stored = await AppSettingRepository(db).get_json(
        REGISTRATION_SETTING_KEY, default=DEFAULT_REGISTRATION_SETTINGS
    )
    merged = dict(DEFAULT_REGISTRATION_SETTINGS)
    if isinstance(stored, dict):
        merged.update(
            {key: value for key, value in stored.items() if key in merged}
        )
    return merged


async def register_user(payload: UserRegisterRequest, db: AsyncSession) -> User:
    """
    Run the full enhanced registration pipeline and return the new user.

    Args:
        payload: Validated registration request.
        db: Async session (committed by the request-scoped dependency).

    Returns:
        The persisted :class:`User` row.

    Raises:
        HTTPException: 403 when registration is disabled or a valid
            invitation code is missing; 400 for email-code, uniqueness
            and promotional-code failures.
    """
    toggles = await get_registration_settings(db)
    user_repo = UserRepository(db)
    redeem_repo = RedeemCodeRepository(db)

    # (1) Master switch.
    if not toggles.get("enabled", True):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Registration is currently disabled",
        )

    # (2) Email verification code gate.
    if toggles.get("email_verify_enabled", False):
        if not await email_service.verify_email_code(payload.email, payload.email_code):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email verification code required or invalid",
            )

    # (3) Invitation code gate (consume before any user row exists).
    inviter_user_id: Optional[str] = None
    if toggles.get("invite_required", False):
        invite_code = str(payload.invite_code or "")
        invite_row = await redeem_repo.get_by_code(invite_code)
        if invite_row is None or invite_row.code_type != RedeemCodeType.INVITATION:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Valid invitation code required",
            )
        consumed = await redeem_repo.try_use(invite_code, used_by="pending")
        if consumed is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Valid invitation code required",
            )
        inviter_user_id = consumed.created_by

    # (4) Uniqueness checks (same messages as the legacy endpoint).
    if await user_repo.get_by_username(payload.username):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already registered",
        )
    if await user_repo.get_by_email(payload.email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered",
        )

    # (5) Create the user (verified flag follows the toggle).
    user = User(
        id=str(uuid.uuid4()),
        username=payload.username,
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        email_verified=bool(toggles.get("email_verify_enabled", False)),
        invited_by_user_id=inviter_user_id,
    )
    user = await user_repo.create(user)

    txn_repo = BalanceTransactionRepository(db)

    # (6) Signup bonus.
    signup_bonus = float(toggles.get("signup_bonus") or 0.0)
    if signup_bonus > 0:
        user = await user_repo.add_balance(user.id, signup_bonus) or user
        await txn_repo.create_row(
            user_id=user.id,
            amount=signup_bonus,
            balance_after=user.balance,
            type=TransactionType.SIGNUP_BONUS,
            description="Registration signup bonus",
        )

    # (7) Promotional code bonus.
    if payload.promo_code:
        promo_row = await redeem_repo.get_by_code(payload.promo_code)
        if promo_row is None or promo_row.code_type != RedeemCodeType.PROMO:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid promotional code",
            )
        consumed_promo = await redeem_repo.try_use(payload.promo_code, used_by=user.id)
        if consumed_promo is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid promotional code",
            )
        promo_bonus = float(consumed_promo.bonus_amount or 0.0)
        if promo_bonus > 0:
            user = await user_repo.add_balance(user.id, promo_bonus) or user
            await txn_repo.create_row(
                user_id=user.id,
                amount=promo_bonus,
                balance_after=user.balance,
                type=TransactionType.PROMO_BONUS,
                reference_id=payload.promo_code,
                description="Promotional code bonus",
            )

    # (8) invited_by_user_id was set at creation time from the consumed
    # invitation code's creator.
    return user


async def resolve_by_login(db: AsyncSession, login: str) -> Optional[User]:
    """
    Resolve a login identifier to a user.

    Args:
        db: Async session.
        login: Username or email address.

    Returns:
        The matching user, or ``None`` when no single match exists.
    """
    return await UserRepository(db).get_by_username_or_email(login)


async def bootstrap_admin(user: User, db: AsyncSession) -> User:
    """
    Promote a user to administrator when listed in ``ADMIN_BOOTSTRAP_EMAILS``.

    The check is case-insensitive and idempotent: already-promoted
    users are returned unchanged, which makes it safe to call on every
    login.

    Args:
        user: The freshly authenticated user.
        db: Async session.

    Returns:
        The (possibly promoted) user row.
    """
    if user.is_admin:
        return user
    raw = str(get_settings().ADMIN_BOOTSTRAP_EMAILS or "")
    configured = {part.strip().lower() for part in raw.split(",") if part.strip()}
    if not configured:
        return user
    if str(user.email or "").strip().lower() not in configured:
        return user
    promoted = await UserRepository(db).set_admin(user.id, True)
    logger.info("Promoted user {} to administrator via ADMIN_BOOTSTRAP_EMAILS", user.email)
    return promoted or user
