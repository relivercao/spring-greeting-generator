"""
@file base.py
@brief Base service class for all service layer implementations.

@version 3.2
@date 2026-07-31

@copyright Copyright (c) 2025 relivercao@gmail.com
All rights reserved.
"""

from abc import ABC
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession


class BaseService(ABC):
    """
    Base class for all service layer classes.

    Services encapsulate business logic and provide a clean separation
    between API endpoints and domain logic.

    Design Guidelines:
    - Services should be stateless (except for injected dependencies)
    - All database operations should go through repositories
    - Services return domain objects (ORM models), not schemas
    - No HTTP-specific logic (Request, Response, status codes)
    """

    def __init__(self, db: AsyncSession):
        """
        Initialize base service.

        Args:
            db: Async database session (injected via Depends)
        """
        self._db = db

    async def _commit(self) -> None:
        """Commit current transaction."""
        await self._db.commit()

    async def _rollback(self) -> None:
        """Rollback current transaction."""
        await self._db.rollback()

    async def _flush(self) -> None:
        """Flush pending changes without committing."""
        await self._db.flush()

    async def _refresh(self, instance) -> None:
        """Refresh instance from database."""
        await self._db.refresh(instance)


class ServiceError(Exception):
    """Base exception for service layer errors."""
    pass


class ResourceNotFoundError(ServiceError):
    """Raised when a requested resource does not exist."""

    def __init__(self, resource_type: str, resource_id: str):
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(f"{resource_type} not found: {resource_id}")


class ValidationError(ServiceError):
    """Raised when business validation fails."""

    def __init__(self, message: str, field: Optional[str] = None):
        self.field = field
        super().__init__(message)


class AuthorizationError(ServiceError):
    """Raised when user lacks permission for an operation."""

    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(message)
